/**
 * OAuth2 / OIDC authentication + JWT session tokens.
 *
 * Flow:
 *   1. GET  /auth/login           → redirect to OIDC provider (PKCE + nonce)
 *   2. GET  /auth/callback        → exchange code, issue GreenFrog JWT, redirect to UI
 *   3. GET  /auth/logout          → clear cookie, redirect to /
 *   4. GET  /auth/userinfo        → return claims from current JWT (JSON)
 *   5. All protected API routes   → verify JWT Bearer token or session cookie
 *
 * Backwards compat:
 *   When auth.enabled = false (default) the existing HMAC/Bearer flow is unchanged.
 *
 * JWT payload:
 *   { sub, email, name, picture, role: 'admin'|'user'|'readonly', iat, exp }
 */
import { createLogger } from '../utils/logger.js';
import { authAttemptsTotal } from '../metrics/index.js';
import { resolveRoleFromConfig } from '../authz/roles.js';
import { memoryStore } from '../memory/store.js';
const log = createLogger('auth');
const STATE_TTL_MS = 10 * 60_000;
const STATE_TTL_S = 600; // Redis TTL in seconds
// In-memory fallback store
const _memStateStore = new Map();
// Optional Redis client for distributed state (set during initAuth when Redis is configured)
let _redis = null;
async function stateSet(key, state) {
    if (_redis) {
        await _redis.set(`gf:oidc:${key}`, JSON.stringify(state), 'EX', STATE_TTL_S);
    }
    else {
        _memStateStore.set(key, state);
        pruneMemStates();
    }
}
async function stateGet(key) {
    if (_redis) {
        const raw = await _redis.get(`gf:oidc:${key}`);
        return raw ? JSON.parse(raw) : null;
    }
    const v = _memStateStore.get(key);
    return (v && Date.now() <= v.exp) ? v : null;
}
async function stateDel(key) {
    if (_redis) {
        await _redis.del(`gf:oidc:${key}`);
    }
    else {
        _memStateStore.delete(key);
    }
}
function pruneMemStates() {
    const now = Date.now();
    for (const [k, v] of _memStateStore) {
        if (now > v.exp)
            _memStateStore.delete(k);
    }
    // Guard against unbounded growth (max 1000 pending OIDC flows)
    if (_memStateStore.size > 1000) {
        const oldest = [..._memStateStore.entries()].sort((a, b) => a[1].exp - b[1].exp);
        for (const [k] of oldest.slice(0, 100))
            _memStateStore.delete(k);
    }
}
let _client = null;
let _jwtSecret = null;
export async function initAuth() {
    const { config } = await import('../config/index.js');
    if (!config.auth?.enabled)
        return;
    const { issuer, clientId, clientSecret, jwtSecret } = config.auth;
    if (!issuer || !clientId || !clientSecret) {
        log.warn('auth.enabled=true but issuer/clientId/clientSecret not configured — OIDC disabled');
        return;
    }
    // Derive 32-byte key from jwtSecret string (HMAC-SHA256 over the raw string)
    const rawSecret = jwtSecret ?? clientSecret;
    _jwtSecret = new TextEncoder().encode(rawSecret.padEnd(32, '0').slice(0, 64));
    // Initialise Redis state store if queue.redisUrl is configured
    try {
        const redisUrl = config.queue?.redisUrl;
        if (redisUrl) {
            const RedisCtor = (await import('ioredis')).default;
            const redisClient = new RedisCtor(redisUrl, { lazyConnect: true, enableOfflineQueue: false });
            await redisClient.connect();
            _redis = redisClient;
            log.info('OIDC state store: Redis');
        }
    }
    catch (err) {
        log.warn({ err }, 'Redis unavailable — OIDC state store falling back to in-memory Map');
        _redis = null;
    }
    try {
        const { Issuer } = await import('openid-client');
        const discovered = await Issuer.discover(issuer);
        _client = new discovered.Client({
            client_id: clientId,
            client_secret: clientSecret,
            response_types: ['code'],
        });
        log.info({ issuer }, 'OIDC client initialised');
    }
    catch (err) {
        log.error({ err }, 'OIDC discovery failed — auth will fall back to Bearer-only');
        _client = null;
    }
}
// ── JWT helpers ───────────────────────────────────────────────────────────────
async function signJwt(user) {
    const { config } = await import('../config/index.js');
    const { SignJWT } = await import('jose');
    const expiresIn = config.auth?.jwtExpiresIn ?? '24h';
    const seconds = parseExpiry(expiresIn);
    return new SignJWT({ ...user })
        .setProtectedHeader({ alg: 'HS256' })
        .setIssuedAt()
        .setExpirationTime(Math.floor(Date.now() / 1000) + seconds)
        .setSubject(user.sub)
        .sign(_jwtSecret);
}
async function verifyJwtToken(token) {
    if (!_jwtSecret)
        return null;
    try {
        const { jwtVerify } = await import('jose');
        const { payload } = await jwtVerify(token, _jwtSecret, { algorithms: ['HS256'] });
        const user = payload;
        if (typeof user.sub !== 'string' || !user.sub)
            return null;
        const revokedAfter = await memoryStore.getAuthRevokedAfter(user.sub);
        if (revokedAfter !== null) {
            const issuedAt = typeof user.iat === 'number' ? user.iat : 0;
            if (issuedAt <= revokedAfter)
                return null;
        }
        return user;
    }
    catch {
        return null;
    }
}
function extractClaimStrings(claim) {
    if (typeof claim === 'string') {
        return claim.split(/[,\s]+/).map((value) => value.trim()).filter(Boolean);
    }
    if (Array.isArray(claim)) {
        return claim.filter((value) => typeof value === 'string')
            .map((value) => value.trim())
            .filter(Boolean);
    }
    return [];
}
export async function resolveAuthRole(sub, email, externalGroups) {
    const { config } = await import('../config/index.js');
    const principals = [sub, email].filter((v) => typeof v === 'string' && v.length > 0);
    const normalizedExternalGroups = [...new Set((externalGroups ?? []).map((value) => value.trim()).filter(Boolean))];
    let resolved = 'deny';
    for (const principal of principals) {
        const role = resolveRoleFromConfig(config.roles, principal, 'web', {
            externalGroups: normalizedExternalGroups,
        });
        if (role === 'admin')
            return 'admin';
        if (role === 'user')
            resolved = resolved === 'deny' || resolved === 'readonly' ? 'user' : resolved;
        if (role === 'readonly' && resolved === 'deny')
            resolved = 'readonly';
    }
    return resolved;
}
function parseExpiry(s) {
    const m = /^(\d+)([smhd])$/.exec(s);
    if (!m)
        return 86_400;
    const n = parseInt(m[1]);
    return n * ({ s: 1, m: 60, h: 3_600, d: 86_400 }[m[2]] ?? 3_600);
}
// ── Route handlers ────────────────────────────────────────────────────────────
/** GET /auth/login — initiate OIDC authorization code + PKCE flow */
export async function handleLogin(req, res) {
    const { config } = await import('../config/index.js');
    if (!_client) {
        res.status(503).json({ error: 'OIDC not configured' });
        return;
    }
    // PKCE
    const { generators } = await import('openid-client');
    const codeVerifier = generators.codeVerifier();
    const codeChallenge = generators.codeChallenge(codeVerifier);
    const nonce = generators.nonce();
    const stateKey = generators.state();
    await stateSet(stateKey, {
        codeVerifier,
        nonce,
        redirectAfter: req.query.redirect ?? '/',
        exp: Date.now() + STATE_TTL_MS,
    });
    const redirectUri = config.auth?.redirectUri ?? `${req.protocol}://${req.get('host')}/auth/callback`;
    const scopes = [...new Set([
            'openid',
            'email',
            'profile',
            ...(config.auth?.scopes ?? []),
        ])];
    const url = _client.authorizationUrl({
        scope: scopes.join(' '),
        redirect_uri: redirectUri,
        state: stateKey,
        nonce,
        code_challenge: codeChallenge,
        code_challenge_method: 'S256',
    });
    authAttemptsTotal.inc({ method: 'oidc', result: 'redirect' });
    res.redirect(url);
}
/** GET /auth/callback — OIDC code exchange → issue JWT → redirect to UI */
export async function handleCallback(req, res) {
    const { config } = await import('../config/index.js');
    if (!_client) {
        res.status(503).json({ error: 'OIDC not configured' });
        return;
    }
    const stateKey = req.query.state;
    const stored = await stateGet(stateKey);
    if (!stored || Date.now() > stored.exp) {
        authAttemptsTotal.inc({ method: 'oidc', result: 'fail' });
        res.status(400).json({ error: 'Invalid or expired state — please login again' });
        return;
    }
    await stateDel(stateKey);
    const redirectUri = config.auth?.redirectUri ?? `${req.protocol}://${req.get('host')}/auth/callback`;
    try {
        const params = _client.callbackParams(req);
        const tokenSet = await _client.callback(redirectUri, params, {
            code_verifier: stored.codeVerifier,
            nonce: stored.nonce,
            state: stateKey,
        });
        const claims = tokenSet.claims();
        const sub = claims.sub;
        const groupClaim = config.auth?.groupClaim ?? 'groups';
        const groups = extractClaimStrings(claims[groupClaim]);
        const authRole = await resolveAuthRole(sub, claims.email, groups);
        if (authRole === 'deny') {
            authAttemptsTotal.inc({ method: 'oidc', result: 'fail' });
            log.warn({ sub, email: claims.email, groups }, 'OIDC login denied by role policy');
            res.status(403).json({ error: 'Access denied by role policy' });
            return;
        }
        const user = {
            sub,
            email: claims.email,
            name: claims.name,
            picture: claims.picture,
            groups,
            role: authRole,
        };
        const jwt = await signJwt(user);
        // Set as httpOnly cookie + redirect
        res.cookie('gf_token', jwt, {
            httpOnly: true,
            secure: req.secure,
            sameSite: 'lax',
            maxAge: 24 * 3_600_000,
            path: '/',
        });
        authAttemptsTotal.inc({ method: 'oidc', result: 'ok' });
        log.info({ sub, email: user.email, role: authRole, groups }, 'OIDC login successful');
        res.redirect(stored.redirectAfter);
    }
    catch (err) {
        authAttemptsTotal.inc({ method: 'oidc', result: 'fail' });
        log.warn({ err }, 'OIDC callback failed');
        res.status(401).json({ error: 'Authentication failed', detail: String(err) });
    }
}
/** GET /auth/logout */
export function handleLogout(_req, res) {
    res.clearCookie('gf_token', { path: '/' });
    res.redirect('/');
}
export async function handleLogoutAll(req, res) {
    const token = extractToken(req);
    if (!token) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const user = await verifyJwtToken(token);
    if (!user) {
        res.status(401).json({ error: 'Token invalid or expired' });
        return;
    }
    await memoryStore.revokeAuthSessions(user.sub, {
        revokedAfter: Math.floor(Date.now() / 1000),
        revokedBy: user.sub,
        reason: 'self-service logout-all',
    });
    res.clearCookie('gf_token', { path: '/' });
    res.json({ ok: true, userId: user.sub });
}
/** GET /auth/userinfo */
export async function handleUserinfo(req, res) {
    const { config } = await import('../config/index.js');
    const token = extractToken(req);
    if (!token) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const user = await verifyJwtToken(token);
    if (user) {
        res.json({ ...user, authMode: 'oidc' });
        return;
    }
    if (!config.auth?.enabled && token === config.gateway.secret) {
        res.json({
            sub: 'gateway-admin',
            name: 'Gateway Token',
            role: 'admin',
            groups: [],
            authMode: 'bearer',
        });
        return;
    }
    res.status(401).json({ error: 'Token invalid or expired' });
}
// ── Middleware ────────────────────────────────────────────────────────────────
/**
 * Express middleware — verifies JWT from Authorization header or cookie.
 * Falls back to the existing gateway.secret Bearer check when OIDC is disabled.
 *
 * On success: attaches req.authUser and calls next().
 * On failure: 401 JSON response.
 */
export async function requireAuthMiddleware(req, res, next) {
    const { config } = await import('../config/index.js');
    // ── OIDC/JWT mode ────────────────────────────────────────────────────────
    if (config.auth?.enabled && _jwtSecret) {
        const token = extractToken(req);
        if (!token) {
            authAttemptsTotal.inc({ method: 'jwt', result: 'fail' });
            res.status(401).json({ error: 'Authorization required' });
            return;
        }
        const user = await verifyJwtToken(token);
        if (!user) {
            authAttemptsTotal.inc({ method: 'jwt', result: 'fail' });
            res.status(401).json({ error: 'Token invalid or expired' });
            return;
        }
        req.authUser = user;
        authAttemptsTotal.inc({ method: 'jwt', result: 'ok' });
        next();
        return;
    }
    // ── Legacy Bearer (gateway.secret) ──────────────────────────────────────
    const header = req.headers.authorization ?? '';
    if (!header.startsWith('Bearer ')) {
        res.status(401).json({ error: 'Authorization required (Bearer token)' });
        return;
    }
    if (header.slice(7) !== config.gateway.secret) {
        authAttemptsTotal.inc({ method: 'bearer', result: 'fail' });
        res.status(403).json({ error: 'Invalid token' });
        return;
    }
    authAttemptsTotal.inc({ method: 'bearer', result: 'ok' });
    // Set synthetic admin identity so requireAdminAccess works in legacy bearer mode.
    req.authUser = { sub: 'gateway-admin', role: 'admin', groups: [] };
    next();
}
// ── Helpers ───────────────────────────────────────────────────────────────────
function extractToken(req) {
    const header = req.headers.authorization ?? '';
    if (header.startsWith('Bearer '))
        return header.slice(7);
    // Also accept httpOnly cookie (for browser UI sessions)
    const cookie = req.cookies?.gf_token;
    return cookie ?? null;
}
//# sourceMappingURL=index.js.map