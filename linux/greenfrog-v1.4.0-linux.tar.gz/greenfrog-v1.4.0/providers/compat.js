/**
 * OpenAI-compatible providers: Mistral, Groq, DeepSeek, Qwen, Kimi, GLM
 *
 * All use the OpenAI SDK with a custom baseURL — no extra dependencies needed.
 */
import { OpenAIProvider } from './openai.js';
// ── Mistral AI ────────────────────────────────────────────────────────────────
// Docs: https://docs.mistral.ai/api/
// Compatible with OpenAI SDK via https://api.mistral.ai/v1
export class MistralProvider extends OpenAIProvider {
    name = 'mistral';
    defaultModel = 'mistral-large-latest';
    constructor(apiKey, model, baseUrl, authMode, authHeader, authScheme, extraHeaders, disableResponseStorage) {
        super(apiKey, model ?? 'mistral-large-latest', baseUrl ?? 'https://api.mistral.ai/v1', undefined, undefined, authMode, authHeader, authScheme, extraHeaders, undefined, disableResponseStorage);
    }
    async listModels() {
        try {
            return await super.listModels();
        }
        catch {
            return [
                'mistral-large-latest',
                'mistral-medium-latest',
                'mistral-small-latest',
                'codestral-latest',
                'open-mistral-nemo',
                'open-mixtral-8x22b',
            ];
        }
    }
}
// ── Groq ──────────────────────────────────────────────────────────────────────
// Docs: https://console.groq.com/docs/openai
// Ultra-fast inference via https://api.groq.com/openai/v1
export class GroqProvider extends OpenAIProvider {
    name = 'groq';
    defaultModel = 'llama-3.3-70b-versatile';
    constructor(apiKey, model, baseUrl, authMode, authHeader, authScheme, extraHeaders, disableResponseStorage) {
        super(apiKey, model ?? 'llama-3.3-70b-versatile', baseUrl ?? 'https://api.groq.com/openai/v1', undefined, undefined, authMode, authHeader, authScheme, extraHeaders, undefined, disableResponseStorage);
    }
    async listModels() {
        try {
            return await super.listModels();
        }
        catch {
            return [
                'llama-3.3-70b-versatile',
                'llama-3.1-8b-instant',
                'llama-3.2-90b-vision-preview',
                'mixtral-8x7b-32768',
                'gemma2-9b-it',
                'deepseek-r1-distill-llama-70b',
            ];
        }
    }
}
// ── DeepSeek ──────────────────────────────────────────────────────────────────
// Docs: https://platform.deepseek.com/api-docs/
// OpenAI-compatible via https://api.deepseek.com/v1
export class DeepSeekProvider extends OpenAIProvider {
    name = 'deepseek';
    defaultModel = 'deepseek-chat';
    constructor(apiKey, model, baseUrl, authMode, authHeader, authScheme, extraHeaders, disableResponseStorage) {
        super(apiKey, model ?? 'deepseek-chat', baseUrl ?? 'https://api.deepseek.com/v1', undefined, undefined, authMode, authHeader, authScheme, extraHeaders, undefined, disableResponseStorage);
    }
    async listModels() {
        try {
            return await super.listModels();
        }
        catch {
            return [
                'deepseek-chat', // DeepSeek-V3 — general purpose
                'deepseek-reasoner', // DeepSeek-R1 — chain-of-thought reasoning
            ];
        }
    }
}
// ── Alibaba Qwen (通义千问) ────────────────────────────────────────────────────
// Docs: https://help.aliyun.com/zh/dashscope/developer-reference/compatibility-of-openai-with-dashscope
// OpenAI-compatible via https://dashscope.aliyuncs.com/compatible-mode/v1
export class QwenProvider extends OpenAIProvider {
    name = 'qwen';
    defaultModel = 'qwen-max';
    constructor(apiKey, model, baseUrl, authMode, authHeader, authScheme, extraHeaders, disableResponseStorage) {
        super(apiKey, model ?? 'qwen-max', baseUrl ?? 'https://dashscope.aliyuncs.com/compatible-mode/v1', undefined, undefined, authMode, authHeader, authScheme, extraHeaders, undefined, disableResponseStorage);
    }
    async listModels() {
        try {
            return await super.listModels();
        }
        catch {
            return [
                'qwen-max', // 旗舰模型
                'qwen-plus', // 均衡模型
                'qwen-turbo', // 快速模型
                'qwen-long', // 长文本模型（1M context）
                'qwen2.5-72b-instruct',
                'qwen2.5-coder-32b-instruct',
                'qwq-32b', // 推理模型
            ];
        }
    }
}
// ── Kimi (Moonshot AI) ────────────────────────────────────────────────────────
// Docs: https://platform.moonshot.cn/docs/api/chat
// OpenAI-compatible via https://api.moonshot.cn/v1
export class KimiProvider extends OpenAIProvider {
    name = 'kimi';
    defaultModel = 'kimi-latest';
    constructor(apiKey, model, baseUrl, authMode, authHeader, authScheme, extraHeaders, disableResponseStorage) {
        super(apiKey, model ?? 'kimi-latest', baseUrl ?? 'https://api.moonshot.cn/v1', undefined, undefined, authMode, authHeader, authScheme, extraHeaders, undefined, disableResponseStorage);
    }
    async listModels() {
        try {
            return await super.listModels();
        }
        catch {
            return [
                'kimi-latest', // 最新旗舰（Kimi 2.5）
                'kimi-thinking-preview', // 深度思考模型
                'moonshot-v1-8k', // 8K 上下文
                'moonshot-v1-32k', // 32K 上下文
                'moonshot-v1-128k', // 128K 长文本
            ];
        }
    }
}
// ── GLM (智谱 AI) ─────────────────────────────────────────────────────────────
// Docs: https://open.bigmodel.cn/dev/api
// OpenAI-compatible via https://open.bigmodel.cn/api/paas/v4
export class GLMProvider extends OpenAIProvider {
    name = 'glm';
    defaultModel = 'glm-4-plus';
    constructor(apiKey, model, baseUrl, authMode, authHeader, authScheme, extraHeaders, disableResponseStorage) {
        super(apiKey, model ?? 'glm-4-plus', baseUrl ?? 'https://open.bigmodel.cn/api/paas/v4', undefined, undefined, authMode, authHeader, authScheme, extraHeaders, undefined, disableResponseStorage);
    }
    async listModels() {
        try {
            return await super.listModels();
        }
        catch {
            return [
                'glm-4-plus', // 旗舰模型
                'glm-4-0520', // 高性能版本
                'glm-4-air', // 均衡模型
                'glm-4-airx', // 极速推理
                'glm-4-flash', // 免费快速模型
                'glm-4-long', // 长文本（1M context）
                'glm-z1-preview', // 深度推理模型
                'codegeex-4', // 代码专用模型
            ];
        }
    }
}
// ── Gemini Relay ──────────────────────────────────────────────────────────────
// Routes Gemini calls through any OpenAI-compatible relay (e.g. domestic proxies).
// Activated when providers.gemini.baseUrl is set in config.
// Default relay target: Google's own OpenAI-compatible endpoint.
//
// Typical Chinese relay usage:
//   providers.gemini:
//     apiKey: <relay-api-key>
//     baseUrl: https://your-relay.example.com/v1
//     model: gemini-2.0-flash
export class GeminiRelayProvider extends OpenAIProvider {
    name = 'gemini';
    defaultModel = 'gemini-2.0-flash';
    constructor(apiKey, model, baseUrl, authMode, authHeader, authScheme, extraHeaders, disableResponseStorage) {
        super(apiKey, model ?? 'gemini-2.0-flash', baseUrl ?? 'https://generativelanguage.googleapis.com/v1beta/openai', undefined, // useResponsesApi
        undefined, // reasoningEffort
        authMode, authHeader, authScheme, extraHeaders, undefined, // sendClientRequestId
        disableResponseStorage);
    }
    async listModels() {
        try {
            return await super.listModels();
        }
        catch {
            return [
                'gemini-2.0-flash',
                'gemini-2.0-flash-lite',
                'gemini-1.5-pro',
                'gemini-1.5-flash',
                'gemini-1.5-flash-8b',
            ];
        }
    }
}
//# sourceMappingURL=compat.js.map