import { providerRegistry } from '../providers/index.js';
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('memory:reflection');
const REFLECTION_SYSTEM = `You are an AI assistant analyzing your own past performance to improve.
You will be given a list of recent interactions where the user gave negative feedback or corrected you.
Your job: identify recurring behavioral patterns and extract actionable rules to improve future responses.

Output a JSON array of rules. Each rule:
{
  "rule": "concise instruction in imperative form (max 120 chars)",
  "category": "style|format|content|tone|workflow",
  "confidence": 50-95,
  "rationale": "brief explanation of the pattern observed (max 100 chars)"
}

Category meanings:
  style   - how to write (length, markdown, bullet points, code blocks)
  format  - structure of responses (headers, lists, tables)
  content - what to include/exclude (examples, explanations, details)
  tone    - voice and register (formal, casual, direct, empathetic)
  workflow - how to approach tasks (ask before doing, show plan first, etc.)

Rules:
- Only extract rules supported by multiple examples in the data
- Rules must be actionable and specific, not generic ("be helpful")
- Prefer rules about things the AI consistently got wrong
- Return [] if no clear patterns emerge
- Max 5 rules per reflection`;
function buildReflectionPrompt(interactions, corrections, existingRules) {
    const interactionSamples = interactions.slice(0, 15).map((x, i) => `[${i + 1}] Signal: ${x.signal ?? x.feedbackType}\n` +
        `User: ${x.userMessage.slice(0, 200)}\n` +
        `AI: ${x.aiResponse.slice(0, 300)}`).join('\n\n');
    const correctionSamples = corrections.slice(0, 8).map((c) => `- ${c.key}: ${c.value}`).join('\n');
    const existingRulesList = existingRules.map((r) => `- [${r.category}] ${r.rule}`).join('\n');
    return (`Recent negative interactions:\n${interactionSamples || '(none)'}\n\n` +
        `Corrections already learned:\n${correctionSamples || '(none)'}\n\n` +
        `Rules already in effect (do not duplicate):\n${existingRulesList || '(none)'}\n\n` +
        'Analyze the patterns and output new behavioral rules as JSON array:');
}
export async function runReflection(userId, channel, minSamples = 5) {
    return runScopedReflection({ userId, channel }, minSamples);
}
export async function runScopedReflection(scope, minSamples = 5) {
    const allFeedback = await memoryStore.getRecentScopedFeedback(scope, 50);
    const negativeFeedback = allFeedback.filter((f) => f.score < 0 || f.feedbackType === 'correction');
    if (negativeFeedback.length < minSamples) {
        return {
            rulesAdded: 0,
            rulesReinforced: 0,
            summary: `Reflection needs at least ${minSamples} negative samples. Current: ${negativeFeedback.length}.`,
            rules: [],
        };
    }
    const allMem = await memoryStore.getAllScopedMemory(scope);
    const corrections = Object.entries(allMem)
        .filter(([key]) => key.startsWith('correction:'))
        .map(([key, value]) => ({ key, value }));
    const existingRules = await memoryStore.getScopedBehavioralRules(scope, 0);
    const prompt = buildReflectionPrompt(negativeFeedback, corrections, existingRules);
    let newRules = [];
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: prompt }],
            systemPrompt: REFLECTION_SYSTEM,
            maxTokens: 800,
            temperature: 0.2,
        });
        const match = (res.content ?? '').match(/\[[\s\S]*\]/);
        if (match)
            newRules = JSON.parse(match[0]);
    }
    catch (err) {
        log.warn({ err: String(err) }, 'Reflection LLM call failed');
        return { rulesAdded: 0, rulesReinforced: 0, summary: `Reflection failed: ${String(err)}`, rules: [] };
    }
    const validCategories = new Set(['style', 'format', 'content', 'tone', 'workflow']);
    let added = 0;
    let reinforced = 0;
    const savedRules = [];
    for (const candidate of newRules) {
        if (!candidate.rule || !candidate.category || !validCategories.has(candidate.category))
            continue;
        const rule = String(candidate.rule).trim().slice(0, 120);
        if (!rule)
            continue;
        const confidence = Math.min(95, Math.max(40, typeof candidate.confidence === 'number' ? candidate.confidence : 60));
        const existing = existingRules.find((entry) => entry.rule.toLowerCase() === rule.toLowerCase());
        await memoryStore.upsertScopedBehavioralRule(scope, {
            rule,
            category: candidate.category,
            confidence,
            source: 'reflection',
        });
        if (existing) {
            reinforced++;
        }
        else {
            added++;
        }
        savedRules.push({ rule, category: candidate.category, confidence });
    }
    const stats = await memoryStore.getScopedFeedbackStats(scope);
    const satisfaction = stats.total > 0 ? Math.round((stats.positive / stats.total) * 100) : 0;
    const summary = `Reflection complete. Analyzed ${negativeFeedback.length} negative interactions, ` +
        `added ${added} rules, reinforced ${reinforced} rules. ` +
        `Overall satisfaction: ${satisfaction}% across ${stats.total} feedback events.`;
    log.info({
        userId: scope.userId,
        workspaceId: scope.workspaceId ?? null,
        agentId: scope.agentId ?? null,
        added,
        reinforced,
        total: negativeFeedback.length,
    }, 'Reflection complete');
    return { rulesAdded: added, rulesReinforced: reinforced, summary, rules: savedRules };
}
//# sourceMappingURL=reflection.js.map