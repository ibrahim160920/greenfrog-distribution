/**
 * i18n loader for GreenFrog child distribution system.
 *
 * Key design decisions:
 *   - Locale JSON files use nested objects; they are flattened to dot-notation keys at load time.
 *   - Fallback chain: <full-locale> → <language-only> → 'en'
 *     e.g. zh-CN → zh → en; pt-BR → pt → en; en-GB → en
 *   - Variable interpolation: {key} in message strings.
 *   - Missing keys fall back to the key itself (never throws).
 *   - All locale files are loaded lazily and cached.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SUPPORTED_LOCALES, DEFAULT_LOCALE, } from './types.js';
const _dirname = path.dirname(fileURLToPath(import.meta.url));
const LOCALES_DIR = path.join(_dirname, 'locales');
/** Cache: locale code → flattened message map */
const _cache = new Map();
// ── Utilities ─────────────────────────────────────────────────────────────────
/**
 * Flatten a nested message object to dot-notation keys.
 * { "firstBoot": { "title": "Welcome" } } → { "firstBoot.title": "Welcome" }
 */
function flattenMessages(obj, prefix = '') {
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
        const fullKey = prefix ? `${prefix}.${key}` : key;
        if (typeof value === 'string') {
            result[fullKey] = value;
        }
        else if (value && typeof value === 'object') {
            Object.assign(result, flattenMessages(value, fullKey));
        }
    }
    return result;
}
/**
 * Resolve a raw locale string to a supported locale + fallback chain.
 * 'zh-CN' → ['zh-CN', 'zh', 'en']
 * 'pt-BR' → ['pt-BR', 'pt', 'en']
 * 'en-GB' → ['en-GB', 'en']
 * 'en'    → ['en']
 * unknown → ['en']
 */
export function resolveLocaleChain(raw) {
    const normalized = raw.replace('_', '-');
    const [lang] = normalized.split('-');
    const chain = [];
    // Full locale (e.g. zh-CN)
    if (normalized !== lang)
        chain.push(normalized);
    // Language-only (e.g. zh, pt, en)
    chain.push(lang);
    // Default fallback
    if (lang !== DEFAULT_LOCALE)
        chain.push(DEFAULT_LOCALE);
    // Remove duplicates while preserving order
    return [...new Set(chain)];
}
/** Load a single locale file, returning flattened messages or null if not found. */
function loadLocaleFile(code) {
    if (_cache.has(code))
        return _cache.get(code);
    // Try exact match, then language-only
    const candidates = [
        path.join(LOCALES_DIR, `${code}.json`),
        path.join(LOCALES_DIR, `${code.split('-')[0]}.json`),
    ];
    for (const filePath of candidates) {
        if (fs.existsSync(filePath)) {
            try {
                const raw = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
                const flat = flattenMessages(raw);
                _cache.set(code, flat);
                return flat;
            }
            catch {
                // corrupted file — fall through
            }
        }
    }
    return null;
}
// ── I18n class ─────────────────────────────────────────────────────────────────
export class I18n {
    _locale;
    _messages = {};
    _fallbackMessages = {};
    constructor(locale) {
        this._locale = locale ?? detectSystemLocale();
        this._loadMessages();
    }
    /** Return the currently active locale code. */
    get locale() { return this._locale; }
    /** Switch to a different locale. */
    setLocale(locale) {
        this._locale = locale;
        this._loadMessages();
    }
    /**
     * Translate a dot-notation key with optional variable interpolation.
     * t('firstBoot.title')
     * t('update.version', { version: '1.2.0' })
     *
     * Falls back to key if missing in all locales.
     */
    t(key, vars) {
        let msg = this._messages[key] ?? this._fallbackMessages[key] ?? key;
        if (vars) {
            for (const [k, v] of Object.entries(vars)) {
                msg = msg.replaceAll(`{${k}}`, v);
            }
        }
        return msg;
    }
    /** Load messages for the current locale chain. */
    _loadMessages() {
        const chain = resolveLocaleChain(this._locale);
        this._messages = {};
        this._fallbackMessages = {};
        // Primary: try each locale in chain until we get messages
        for (const code of chain) {
            const msgs = loadLocaleFile(code);
            if (msgs) {
                this._messages = msgs;
                break;
            }
        }
        // Fallback: always load English as the safety net
        const en = loadLocaleFile(DEFAULT_LOCALE);
        if (en)
            this._fallbackMessages = en;
    }
}
// ── System locale detection ────────────────────────────────────────────────────
export function detectSystemLocale() {
    // Node.js doesn't expose system locale natively — check common env vars
    const raw = process.env['LANG'] ??
        process.env['LANGUAGE'] ??
        process.env['LC_ALL'] ??
        process.env['LC_MESSAGES'] ??
        'en';
    // Strip encoding suffix: 'zh_CN.UTF-8' → 'zh_CN'
    const cleaned = raw.split('.')[0].replace('_', '-');
    // Check if it's a supported locale (or close enough — chain will handle fallback)
    const supported = SUPPORTED_LOCALES.find(l => l.code === cleaned || l.code.split('-')[0] === cleaned.split('-')[0]);
    return supported?.code ?? DEFAULT_LOCALE;
}
// ── Module-level singleton ────────────────────────────────────────────────────
let _globalI18n = null;
export function getI18n(locale) {
    if (!_globalI18n)
        _globalI18n = new I18n(locale);
    return _globalI18n;
}
export function resetI18n() {
    _globalI18n = null;
    _cache.clear();
}
//# sourceMappingURL=loader.js.map