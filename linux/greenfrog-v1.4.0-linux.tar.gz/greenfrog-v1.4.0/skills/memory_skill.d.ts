import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class MemorySkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=memory_skill.d.ts.map