const ROLE_PRIORITY = {
    readonly: 1,
    user: 2,
    admin: 3,
};
const ROLE_GROUP_ID_PATTERN = /^[A-Za-z0-9._:-]{1,64}$/;
export const MAX_ROLE_GROUP_MEMBERS = 1000;
export const MAX_ROLE_GROUP_EXTERNALS = 100;
export function isValidRoleGroupId(groupId) {
    return ROLE_GROUP_ID_PATTERN.test(groupId);
}
export function normalizeRoleGroupMembers(members) {
    if (!Array.isArray(members))
        return [];
    const uniqueMembers = new Set();
    for (const member of members) {
        if (typeof member !== 'string')
            continue;
        const normalized = member.trim();
        if (!normalized)
            continue;
        uniqueMembers.add(normalized);
        if (uniqueMembers.size >= MAX_ROLE_GROUP_MEMBERS)
            break;
    }
    return [...uniqueMembers];
}
export function normalizeExternalGroups(groups) {
    if (!Array.isArray(groups))
        return [];
    const uniqueGroups = new Set();
    for (const group of groups) {
        if (typeof group !== 'string')
            continue;
        const normalized = group.trim();
        if (!normalized)
            continue;
        uniqueGroups.add(normalized);
        if (uniqueGroups.size >= MAX_ROLE_GROUP_EXTERNALS)
            break;
    }
    return [...uniqueGroups];
}
export function resolveRoleFromConfig(roles, userId, channel, opts) {
    if (!roles)
        return 'user';
    const principals = [`${channel}:${userId}`, userId];
    for (const principal of principals) {
        if (roles.admin?.includes(principal))
            return 'admin';
        if (roles.user?.includes(principal))
            return 'user';
        if (roles.readonly?.includes(principal))
            return 'readonly';
    }
    let groupRole = null;
    const externalGroups = new Set(opts?.externalGroups ?? []);
    for (const group of Object.values(roles.groups ?? {})) {
        if (!group || !Array.isArray(group.members))
            continue;
        const matches = principals.some((principal) => group.members.includes(principal));
        const externalMatches = Array.isArray(group.externalGroups)
            && group.externalGroups.some((externalGroup) => externalGroups.has(externalGroup));
        if (!matches && !externalMatches)
            continue;
        if (!groupRole || ROLE_PRIORITY[group.role] > ROLE_PRIORITY[groupRole]) {
            groupRole = group.role;
        }
    }
    if (groupRole)
        return groupRole;
    return roles.defaultRole ?? 'user';
}
//# sourceMappingURL=roles.js.map