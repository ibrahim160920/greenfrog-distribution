import { BaseSkill } from './base.js';
export class WebFetchSkill extends BaseSkill {
    definition = {
        name: 'web_fetch',
        description: 'Fetch and read the content of any URL. Can extract text from web pages, APIs, or raw URLs.',
        category: 'information',
        parameters: [
            { name: 'url', type: 'string', required: true, description: 'URL to fetch' },
            { name: 'extract', type: 'string', description: 'What to extract: text (default), links, or raw', enum: ['text', 'links', 'raw'], default: 'text' },
            { name: 'max_chars', type: 'number', description: 'Maximum characters to return (default: 3000)', default: 3000 },
        ],
    };
    async execute(params, _ctx) {
        const url = params.url;
        const extract = params.extract ?? 'text';
        const maxChars = params.max_chars ?? 3000;
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            return this.err('URL must start with http:// or https://');
        }
        try {
            const res = await fetch(url, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (compatible; GreenFrog-Agent/1.0)',
                    'Accept': 'text/html,application/json,*/*',
                },
                signal: AbortSignal.timeout(15000),
            });
            if (!res.ok)
                return this.err(`HTTP ${res.status}: ${res.statusText}`);
            const contentType = res.headers.get('content-type') ?? '';
            // JSON response
            if (contentType.includes('application/json')) {
                const json = await res.json();
                const text = JSON.stringify(json, null, 2).slice(0, maxChars);
                return this.text(`📄 **${url}** (JSON)\n\`\`\`json\n${text}\n\`\`\``);
            }
            const html = await res.text();
            if (extract === 'raw') {
                return this.text(`📄 **${url}**\n\`\`\`\n${html.slice(0, maxChars)}\n\`\`\``);
            }
            // Strip HTML tags for text extraction
            const text = html
                .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
                .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
                .replace(/<[^>]+>/g, ' ')
                .replace(/&nbsp;/g, ' ')
                .replace(/&amp;/g, '&')
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&quot;/g, '"')
                .replace(/\s{2,}/g, ' ')
                .trim();
            if (extract === 'links') {
                const links = [...html.matchAll(/href=["']([^"']+)["']/g)]
                    .map((m) => m[1])
                    .filter((l) => l.startsWith('http'))
                    .slice(0, 20);
                return this.text(`🔗 **Links from ${url}:**\n${links.join('\n')}`);
            }
            return this.text(`📄 **${url}**\n\n${text.slice(0, maxChars)}${text.length > maxChars ? '\n...(truncated)' : ''}`);
        }
        catch (err) {
            return this.err(`Fetch error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=web_fetch.js.map