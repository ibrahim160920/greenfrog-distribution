/**
 * Legacy Bearer-only mode does not attach a user identity. In that mode we
 * preserve backward compatibility by treating the caller as trusted.
 */
export function canAccessUserScope(authUser, targetUserId) {
    if (!authUser)
        return true;
    return authUser.role === 'admin' || authUser.sub === targetUserId;
}
export function isAdminUser(authUser) {
    return authUser?.role === 'admin';
}
//# sourceMappingURL=access.js.map