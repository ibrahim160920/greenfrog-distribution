import { BaseSkill } from './base.js';
export class TimezoneSkill extends BaseSkill {
    definition = {
        name: 'time_and_timezone',
        description: 'Get current time in any timezone, convert between timezones, list timezones',
        category: 'utilities',
        parameters: [
            {
                name: 'action',
                type: 'string',
                required: true,
                description: 'Action to perform',
                enum: ['current_time', 'convert', 'list_zones'],
            },
            { name: 'timezone', type: 'string', description: 'Timezone name (e.g. "America/New_York", "Asia/Shanghai", "Europe/London")' },
            { name: 'from_timezone', type: 'string', description: 'Source timezone (for convert action)' },
            { name: 'to_timezone', type: 'string', description: 'Target timezone (for convert action)' },
            { name: 'time', type: 'string', description: 'Time to convert in ISO format or "HH:MM"' },
        ],
    };
    async execute(params, _ctx) {
        switch (params.action) {
            case 'current_time': {
                const tz = params.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
                try {
                    const now = new Date();
                    const formatted = new Intl.DateTimeFormat('en-US', {
                        timeZone: tz,
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        timeZoneName: 'long',
                    }).format(now);
                    return this.text(`🕐 **Current time in ${tz}:**\n${formatted}`);
                }
                catch {
                    return this.err(`Invalid timezone: ${tz}`);
                }
            }
            case 'convert': {
                if (!params.time || !params.from_timezone || !params.to_timezone) {
                    return this.err('time, from_timezone, and to_timezone are required');
                }
                try {
                    // Parse the time
                    const [hours, minutes] = params.time.split(':').map(Number);
                    const now = new Date();
                    now.setHours(hours, minutes, 0, 0);
                    const fromFormatted = new Intl.DateTimeFormat('en-US', {
                        timeZone: params.from_timezone,
                        hour: '2-digit', minute: '2-digit', timeZoneName: 'short',
                    }).format(now);
                    const toFormatted = new Intl.DateTimeFormat('en-US', {
                        timeZone: params.to_timezone,
                        hour: '2-digit', minute: '2-digit', timeZoneName: 'short',
                    }).format(now);
                    return this.text(`🕐 **Time Conversion:**\n${fromFormatted} → ${toFormatted}`);
                }
                catch (err) {
                    return this.err(`Conversion error: ${String(err)}`);
                }
            }
            case 'list_zones': {
                const zones = [
                    'UTC', 'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
                    'America/Toronto', 'America/Sao_Paulo', 'Europe/London', 'Europe/Paris', 'Europe/Berlin',
                    'Europe/Moscow', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Shanghai', 'Asia/Tokyo',
                    'Asia/Seoul', 'Asia/Singapore', 'Australia/Sydney', 'Pacific/Auckland',
                ].map((tz) => {
                    try {
                        const t = new Intl.DateTimeFormat('en-US', {
                            timeZone: tz, hour: '2-digit', minute: '2-digit', timeZoneName: 'short',
                        }).format(new Date());
                        return `• ${tz} — ${t}`;
                    }
                    catch {
                        return `• ${tz}`;
                    }
                });
                return this.text(`🌍 **Common Timezones:**\n\n${zones.join('\n')}`);
            }
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
}
//# sourceMappingURL=timezone.js.map