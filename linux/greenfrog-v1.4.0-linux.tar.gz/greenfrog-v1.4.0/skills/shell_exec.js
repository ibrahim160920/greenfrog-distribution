import { spawnSync } from 'child_process';
import { resolve } from 'path';
import { homedir } from 'os';
import { BaseSkill } from './base.js';
import { dockerSandbox } from '../sandbox/docker.js';
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';
// Hard cap: no single shell command should run longer than 5 minutes
const MAX_TIMEOUT_MS = 5 * 60 * 1000;
const log = createLogger('skill:shell');
/**
 * Allowlist of safe base commands.
 *
 * Security design (allowlist > blocklist):
 * A blocklist is inherently incomplete — an attacker can always find a vector
 * not covered by the list.  An allowlist inverts this: only known-safe commands
 * are permitted, and everything else is denied by default.
 *
 * The allowlist is matched against the FIRST token of the command (the
 * executable name, after splitting on whitespace).  This prevents bypasses
 * like `;` chaining to a blocked command.
 *
 * Commands that need shell-level features (pipes, redirection, glob) are
 * executed through `sh -c` on Unix / `cmd /c` on Windows.  Operators that
 * allow command injection (`;`, `|`, `&&`, `` ` ``) are separately detected
 * and restricted to the explicit shell-operator allowlist below.
 */
const SAFE_COMMANDS = new Set([
    // Navigation / listing
    'ls', 'dir', 'pwd', 'cd', 'echo', 'cat', 'head', 'tail', 'less', 'more', 'find',
    'stat', 'file', 'wc', 'diff', 'grep', 'awk', 'sed', 'sort', 'uniq', 'cut', 'tr',
    'tee', 'which', 'whereis', 'type', 'env', 'printenv', 'date', 'uptime',
    // Version control
    'git',
    // Package managers
    'npm', 'npx', 'pnpm', 'yarn', 'bun',
    'pip', 'pip3', 'uv', 'poetry',
    'cargo', 'go', 'rustup',
    // Build / test tools
    'make', 'cmake', 'ninja',
    'node', 'ts-node', 'tsx', 'deno',
    'python', 'python3', 'ruby', 'perl',
    'java', 'javac', 'mvn', 'gradle',
    'dotnet',
    'gcc', 'g++', 'clang',
    'vitest', 'jest', 'mocha', 'pytest', 'rspec',
    // File operations (non-destructive)
    'cp', 'mv', 'mkdir', 'touch', 'ln', 'readlink',
    // Archiving
    'tar', 'zip', 'unzip', 'gzip', 'gunzip', 'xz',
    // Network (read-only)
    'curl', 'wget', 'ping', 'nslookup', 'dig', 'host',
    // Process / resource info (read-only)
    'ps', 'top', 'htop', 'lsof', 'netstat', 'ss', 'df', 'du', 'free', 'iostat',
    'systemctl', 'journalctl', 'dmesg',
    // Text editors (non-interactive usage)
    'vim', 'nvim', 'nano', 'emacs',
    // Clipboard / misc
    'pbcopy', 'pbpaste', 'xclip', 'xsel',
    // Windows-specific read-only commands
    'Get-ChildItem', 'Get-Content', 'Get-Item', 'Get-Location', 'Get-Process',
    'Get-Service', 'Invoke-WebRequest', 'Write-Output', 'Write-Host',
]);
/**
 * Operators that enable shell-level composition.  We allow pipes and
 * redirections for legitimate use (e.g. `grep foo file | sort`) but block
 * operators that can chain arbitrary commands to bypass the allowlist.
 */
const BLOCKED_OPERATORS = [
    /;\s*\S/, // command chaining: cmd1; cmd2
    /`[^`]*`/, // backtick sub-shell
    /\$\([^)]*\)/, // $() sub-shell
    /\|\s*(bash|sh|zsh|fish|cmd|powershell|pwsh)\b/i, // pipe into a shell
    /\b(eval|exec)\s*[("'`]/, // eval / exec with string argument
    /:\s*\(\s*\)\s*\{/, // fork bomb
];
/** Patterns that remain unconditionally blocked regardless of the allowlist */
const ALWAYS_BLOCKED = [
    /\brm\b.*-[a-z]*r/i, // recursive deletion
    /\bmkfs\b/i, // format filesystem
    /\bdd\b.*\bif=/i, // disk dump
    /\bshred\b/i, // secure delete
    /\bformat\s+[a-z]:/i, // Windows format drive
    /\b(shutdown|reboot|halt|poweroff)\b/i, // system power
    /\binit\s+[06]\b/, // system runlevel
    /\b(sudo|su\s|doas)\b/, // privilege escalation
    />\s*(\/etc\/|\/boot\/|\/sys\/|C:\\Windows\\)/i, // overwrite system files
    /\b(useradd|userdel|usermod|passwd|chpasswd|visudo)\b/i, // user management
    /\biptables\s+-F\b/i, // flush firewall rules
    /powershell[^|]*-e(nc(odedcommand)?)?\s+[a-z0-9+/]{20}/i, // PS encoded cmd
];
/**
 * Git sub-command allowlist.
 *
 * `git` without a sub-command allowlist is dangerous:
 *   - `git config --global core.hooksPath /tmp/evil` installs malicious hooks
 *   - `git clone <url> --recurse-submodules` can run submodule scripts
 *   - `git filter-branch`, `git bisect run` execute arbitrary commands
 *   - `git credential` can exfiltrate stored credentials
 *
 * Only read-only / safe write sub-commands are permitted here.
 */
const SAFE_GIT_SUBCOMMANDS = new Set([
    'status', 'log', 'diff', 'show', 'blame', 'shortlog', 'describe',
    'branch', 'tag', 'stash', 'remote',
    'add', 'commit', 'push', 'pull', 'fetch',
    'checkout', 'switch', 'restore', 'merge', 'rebase',
    'cherry-pick', 'revert', 'reset',
    'clone', 'init', 'submodule',
    'ls-files', 'ls-tree', 'cat-file', 'rev-parse', 'rev-list',
    'format-patch', 'apply', 'am',
    'archive', 'bundle',
    'worktree',
    'help', 'version',
]);
/**
 * Git flags that are unconditionally dangerous regardless of sub-command.
 * These allow hook injection or arbitrary command execution.
 */
const BLOCKED_GIT_FLAGS = [
    /--exec\s*=/i,
    /--upload-pack\s*=/i,
    /--receive-pack\s*=/i,
    /core\.hookspath/i,
    /core\.sshcommand/i,
    /-c\s+core\./i,
    /--config\s+core\./i,
    /filter-branch/i,
    /bisect\s+run/i,
    /credential/i,
];
// Curl argument-level blocks — prevent file upload/exfiltration
const BLOCKED_CURL_PATTERNS = [
    /\s-[a-zA-Z]*[dT][a-zA-Z]*\s+@/, // -d @file or -T @file (upload file content)
    /--data(?:-binary|-urlencode|-raw)?\s+@/i, // --data* @file variants
    /--upload-file\s/i, // --upload-file
    /--data-binary\s+@/i, // --data-binary @file
    /\s-[a-zA-Z]*o\s+\/(?!tmp\/)/, // -o /path (write outside /tmp)
    /--output\s+\/(?!tmp\/)/i, // --output /path (write outside /tmp)
    /\s-[a-zA-Z]*o\s+[A-Za-z]:\\/, // -o C:\path (Windows)
    /--output\s+[A-Za-z]:\\/i, // --output C:\path (Windows)
];
// Wget argument-level blocks
const BLOCKED_WGET_PATTERNS = [
    /\s-[a-zA-Z]*O\s+\/(?!tmp\/)/, // -O /path (write outside /tmp)
    /--output-document\s+\/(?!tmp\/)/i, // --output-document /path
    /\s-[a-zA-Z]*O\s+[A-Za-z]:\\/, // -O C:\path (Windows)
    /--output-document\s+[A-Za-z]:\\/i, // --output-document C:\path (Windows)
    /--post-file\s/i, // --post-file (upload)
    /--post-data\s+@/i, // --post-data @file
];
function checkCurlCommand(cmd) {
    for (const p of BLOCKED_CURL_PATTERNS) {
        if (p.test(cmd))
            return { safe: false, reason: 'curl flag blocked: potential file upload or unsafe output path' };
    }
    return { safe: true };
}
function checkWgetCommand(cmd) {
    for (const p of BLOCKED_WGET_PATTERNS) {
        if (p.test(cmd))
            return { safe: false, reason: 'wget flag blocked: potential file upload or unsafe output path' };
    }
    return { safe: true };
}
function getBaseCommand(cmd) {
    // First token, stripping any path prefix
    const first = cmd.trim().split(/\s+/)[0] ?? '';
    // Handle paths like /usr/bin/python3 → python3
    return first.split(/[/\\]/).pop()?.toLowerCase() ?? first.toLowerCase();
}
function checkGitCommand(cmd) {
    // Check for dangerous flags first
    for (const p of BLOCKED_GIT_FLAGS) {
        if (p.test(cmd))
            return { safe: false, reason: 'blocked git flag (hook/credential injection risk)' };
    }
    // Extract sub-command: `git [flags] <subcommand>`
    const tokens = cmd.trim().split(/\s+/);
    // Find first token that doesn't start with '-' (after 'git')
    const subCmd = tokens.slice(1).find((t) => !t.startsWith('-'));
    if (!subCmd)
        return { safe: true }; // bare `git` with no sub-command is fine
    if (!SAFE_GIT_SUBCOMMANDS.has(subCmd.toLowerCase())) {
        return { safe: false, reason: `git sub-command "${subCmd}" is not in the allowlist` };
    }
    return { safe: true };
}
function isSafeCommand(cmd) {
    // 1. Unconditional blocks (highest priority)
    for (const p of ALWAYS_BLOCKED) {
        if (p.test(cmd))
            return { safe: false, reason: 'unconditionally blocked pattern' };
    }
    // 2. Blocked shell operators
    for (const p of BLOCKED_OPERATORS) {
        if (p.test(cmd))
            return { safe: false, reason: 'blocked shell operator' };
    }
    // 3. Allowlist check on base command
    const base = getBaseCommand(cmd);
    if (!SAFE_COMMANDS.has(base)) {
        return { safe: false, reason: `command "${base}" is not in the allowlist` };
    }
    // 4. Git-specific sub-command validation
    if (base === 'git') {
        return checkGitCommand(cmd);
    }
    // 5. Curl argument-level validation
    if (base === 'curl') {
        return checkCurlCommand(cmd);
    }
    // 6. Wget argument-level validation
    if (base === 'wget') {
        return checkWgetCommand(cmd);
    }
    return { safe: true };
}
/** Resolve and reject paths that point into sensitive system directories. */
function sanitiseCwd(cwd) {
    const resolved = resolve(cwd);
    const SENSITIVE = [
        'C:\\Windows', 'C:\\System32', 'C:\\SysWOW64',
        '/etc', '/boot', '/sys', '/proc', '/dev',
    ];
    for (const dir of SENSITIVE) {
        if (resolved.toLowerCase().startsWith(dir.toLowerCase())) {
            return homedir();
        }
    }
    return resolved;
}
export class ShellExecSkill extends BaseSkill {
    definition = {
        name: 'shell',
        description: 'Execute shell/terminal commands on the local computer. Can run git, npm, pip, system commands, etc.',
        category: 'system',
        parameters: [
            { name: 'command', type: 'string', description: 'Shell command to execute', required: true },
            { name: 'cwd', type: 'string', description: 'Working directory for the command' },
            { name: 'timeout', type: 'number', description: 'Timeout in seconds (default: 60, max: 300)', default: 60 },
        ],
        examples: ['Run git status', 'Install npm packages', 'Check git log', 'Run build command'],
    };
    async execute(params, _ctx) {
        const command = params.command;
        const cwd = sanitiseCwd(params.cwd ?? process.cwd());
        const timeoutSecs = Math.min(params.timeout ?? 60, 300);
        const timeoutMs = Math.min(timeoutSecs * 1000, MAX_TIMEOUT_MS);
        const check = isSafeCommand(command);
        if (!check.safe) {
            return this.err(`⚠️ Command blocked: ${check.reason}. ` +
                `Only commands from the safe allowlist are permitted. ` +
                `If you need a specific command added to the allowlist, adjust the configuration.`);
        }
        // ── Docker container sandbox (preferred) ─────────────────────────────────
        if (await dockerSandbox.isAvailable()) {
            try {
                const output = await dockerSandbox.runShell(command, cwd, timeoutMs);
                const prefix = `$ ${command}\n`;
                if (output.startsWith('Exit code')) {
                    return this.text(`\`\`\`\n${prefix}❌ ${output}\n\`\`\``);
                }
                return this.text(`\`\`\`\n${prefix}${output}\n\`\`\``);
            }
            catch (err) {
                const msg = err instanceof Error ? err.message : String(err);
                if (msg.includes('timeout'))
                    return this.err(`Command timed out after ${timeoutSecs}s`);
                return this.err(`Shell error: ${msg}`);
            }
        }
        // ── Fallback policy check ──────────────────────────────────────────────
        const fallbackPolicy = config.sandbox?.fallbackPolicy ?? 'allow';
        const fallbackWarning = dockerSandbox.getFallbackWarning();
        if (fallbackWarning) {
            if (fallbackPolicy === 'deny') {
                return this.err('Docker sandbox is required but unavailable. Shell execution denied by fallbackPolicy=deny.');
            }
            if (fallbackPolicy === 'warn') {
                log.warn({ command }, 'Docker unavailable — falling back to host process sandbox');
            }
        }
        // ── Fallback: spawnSync with shell ────────────────────────────────────────
        const result = spawnSync(command, {
            cwd,
            timeout: timeoutMs,
            encoding: 'utf8',
            maxBuffer: 2 * 1024 * 1024, // 2 MB
            shell: process.platform === 'win32' ? 'cmd.exe' : '/bin/bash',
        });
        if (result.error) {
            const code = result.error.code;
            if (code === 'ETIMEDOUT' || code === 'ESRCH') {
                return this.err(`Command timed out after ${timeoutSecs}s`);
            }
            return this.err(`Shell error: ${String(result.error)}`);
        }
        const stdout = (result.stdout ?? '').trim();
        const stderr = (result.stderr ?? '').trim();
        const exitCode = result.status ?? 0;
        const output = stdout || stderr || '(no output)';
        if (exitCode !== 0) {
            return this.text(`\`\`\`\n$ ${command}\n❌ Exit ${exitCode}:\n${output}\n\`\`\``);
        }
        return this.text(`\`\`\`\n$ ${command}\n${output}\n\`\`\``);
    }
}
//# sourceMappingURL=shell_exec.js.map