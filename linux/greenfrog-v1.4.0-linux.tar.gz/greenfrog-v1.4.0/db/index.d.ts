import type { IMemoryStore } from './types.js';
export type { IMemoryStore };
export declare function createStore(): Promise<IMemoryStore>;
//# sourceMappingURL=index.d.ts.map