import { createHmac } from 'crypto';
import { nanoid } from 'nanoid';
import { config } from '../config/index.js';
export function createConversationStore(db) {
    const api = {
        addMessage(sessionId, userId, channel, message) {
            db.prepare(`INSERT INTO conversations (id, session_id, user_id, channel, role, content, tool_call_id, tool_name, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), sessionId, userId, channel, message.role, message.content, message.toolCallId ?? null, message.toolName ?? null, Date.now());
        },
        getHistory(sessionId, limit = 20) {
            const rows = db.prepare(`SELECT role, content, tool_call_id, tool_name FROM conversations
         WHERE session_id = ? ORDER BY rowid DESC LIMIT ?`).all(sessionId, limit);
            return rows.reverse().map((r) => ({
                role: r.role,
                content: r.content,
                toolCallId: r.tool_call_id ?? undefined,
                toolName: r.tool_name ?? undefined,
            }));
        },
        clearHistory(sessionId) {
            db.prepare(`DELETE FROM conversations WHERE session_id = ?`).run(sessionId);
        },
        getHistoryForUser(sessionId, userId, limit = 20) {
            const session = db.prepare(`SELECT user_id FROM sessions WHERE id = ?`)
                .get(sessionId);
            if (!session || session.user_id !== userId)
                return null;
            return api.getHistory(sessionId, limit);
        },
        clearHistoryForUser(sessionId, userId) {
            const session = db.prepare(`SELECT user_id FROM sessions WHERE id = ?`)
                .get(sessionId);
            if (!session || session.user_id !== userId)
                return false;
            api.clearHistory(sessionId);
            return true;
        },
        getOrCreateSession(userId, channel, chatId) {
            const existing = db.prepare(`SELECT id FROM sessions WHERE user_id = ? AND channel = ? AND chat_id = ?`).get(userId, channel, chatId);
            if (existing) {
                db.prepare(`UPDATE sessions SET last_active = ? WHERE id = ?`).run(Date.now(), existing.id);
                return existing.id;
            }
            const hmacKey = config.gateway.secret || 'greenfrog-fallback';
            const id = createHmac('sha256', hmacKey)
                .update(`${userId}:${channel}:${chatId}`)
                .digest('hex')
                .slice(0, 32);
            db.prepare(`INSERT INTO sessions (id, user_id, channel, chat_id, created_at, last_active) VALUES (?, ?, ?, ?, ?, ?)`).run(id, userId, channel, chatId, Date.now(), Date.now());
            return id;
        },
        getSessionOwner(sessionId) {
            const row = db.prepare(`SELECT user_id FROM sessions WHERE id = ?`)
                .get(sessionId);
            return row?.user_id ?? null;
        },
        searchConversations(userId, channel, query, limit = 20) {
            const pattern = `%${query.replace(/[%_]/g, '\\$&')}%`;
            const rows = db.prepare(`SELECT c.session_id, c.role, c.content, c.created_at
         FROM conversations c
         JOIN sessions s ON s.id = c.session_id
         WHERE s.user_id = ? AND s.channel = ?
           AND c.role IN ('user','assistant')
           AND c.content LIKE ? ESCAPE '\\'
         ORDER BY c.created_at DESC
         LIMIT ?`).all(userId, channel, pattern, limit);
            return rows.map((r) => ({
                sessionId: r.session_id,
                role: r.role,
                content: r.content,
                createdAt: new Date(r.created_at),
            }));
        },
        exportConversation(sessionId, format) {
            const rows = db.prepare(`SELECT role, content, created_at FROM conversations
         WHERE session_id = ? AND role IN ('user','assistant')
         ORDER BY created_at ASC`).all(sessionId);
            if (format === 'json') {
                return JSON.stringify(rows.map((r) => ({ role: r.role, content: r.content, timestamp: new Date(r.created_at).toISOString() })), null, 2);
            }
            const lines = [`# Conversation Export\n\nSession: \`${sessionId}\`\n`];
            for (const r of rows) {
                const ts = new Date(r.created_at).toLocaleString();
                const label = r.role === 'user' ? '**You**' : '**GreenFrog**';
                lines.push(`### ${label} - ${ts}\n\n${r.content}\n`);
            }
            return lines.join('\n---\n\n');
        },
    };
    return api;
}
//# sourceMappingURL=store_conversation.js.map