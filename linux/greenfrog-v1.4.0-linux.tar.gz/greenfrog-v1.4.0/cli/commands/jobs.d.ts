export declare function manageJobs(opts: {
    list?: boolean;
    delete?: string;
}): Promise<void>;
//# sourceMappingURL=jobs.d.ts.map