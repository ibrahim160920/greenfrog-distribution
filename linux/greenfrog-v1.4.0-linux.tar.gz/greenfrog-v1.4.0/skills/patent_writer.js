import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
const PATENT_SYSTEM = `你是一位资深的专利代理师，拥有丰富的中国专利申请经验，熟悉《专利法》及《专利审查指南》。
你能够撰写符合国家知识产权局规范的专利文件，包括权利要求书、说明书和摘要。
撰写原则：权利要求保护范围尽量宽泛但有支撑；说明书充分公开技术方案；语言规范、逻辑严密。`;
const REVIEW_SYSTEM = `你是一位资深的专利审查专家，熟悉专利审查标准和常见驳回理由。
你能够从新颖性、创造性、实用性、说明书充分公开等角度对专利文件进行专业审查，
识别潜在问题并提出具体修改建议。`;
export class PatentWriterSkill extends BaseSkill {
    definition = {
        name: 'patent_writer',
        description: '专利文件撰写与审核。支持撰写发明专利、实用新型、外观设计的完整专利文件（权利要求书/说明书/摘要），或对已有专利文件进行专业审核，评估新颖性/创造性并提出修改建议。',
        category: 'professional',
        parameters: [
            { name: 'action', type: 'string', required: true, description: '操作类型：write=撰写专利，review=审核专利，search_prior_art=现有技术分析', enum: ['write', 'review', 'search_prior_art'] },
            { name: 'invention_name', type: 'string', required: true, description: '发明/实用新型名称' },
            { name: 'technical_field', type: 'string', required: true, description: '技术领域，如：计算机软件、电子电路、机械装置等' },
            { name: 'description', type: 'string', required: true, description: '发明内容详细描述（技术问题、解决方案、技术效果）' },
            { name: 'type', type: 'string', required: false, description: '专利类型：invention=发明专利，utility_model=实用新型，design=外观设计', default: 'invention', enum: ['invention', 'utility_model', 'design'] },
            { name: 'claims_count', type: 'number', required: false, description: '权利要求数量（建议3-10个），默认5', default: 5 },
            { name: 'document', type: 'string', required: false, description: '待审核的专利文件内容（review时必需）' },
        ],
        examples: [
            'patent_writer action=write invention_name="一种基于深度学习的图像识别方法" technical_field="计算机视觉" description="通过多尺度特征提取网络..."',
            'patent_writer action=review invention_name="智能温控装置" technical_field="电子电路" description="..." document="[专利文件内容]"',
        ],
    };
    async execute(params, _ctx) {
        const action = String(params.action ?? '').trim();
        const inventionName = String(params.invention_name ?? '').trim();
        const technicalField = String(params.technical_field ?? '').trim();
        const description = String(params.description ?? '').trim();
        const patentType = String(params.type ?? 'invention').trim();
        const claimsCount = Math.min(Math.max(parseInt(String(params.claims_count ?? '5')), 1), 15);
        const document = String(params.document ?? '').trim();
        if (!action)
            return this.err('请指定操作类型：write、review 或 search_prior_art');
        if (!inventionName)
            return this.err('请提供发明名称');
        if (!technicalField)
            return this.err('请提供技术领域');
        if (!description)
            return this.err('请提供发明内容描述');
        if (action === 'write')
            return this.writePatent(inventionName, technicalField, description, patentType, claimsCount);
        if (action === 'review') {
            if (!document)
                return this.err('审核模式需要提供待审核的专利文件内容（document参数）');
            return this.reviewPatent(inventionName, technicalField, description, document);
        }
        if (action === 'search_prior_art')
            return this.searchPriorArt(inventionName, technicalField, description);
        return this.err(`不支持的操作类型：${action}`);
    }
    async writePatent(inventionName, technicalField, description, patentType, claimsCount) {
        const typeLabel = { invention: '发明专利', utility_model: '实用新型专利', design: '外观设计专利' }[patentType] ?? '发明专利';
        const prompt = `请为以下发明撰写完整的${typeLabel}申请文件：

发明名称：${inventionName}
技术领域：${technicalField}
发明内容描述：
${description}

要求权利要求数量：${claimsCount}个（1个独立权利要求 + ${claimsCount - 1}个从属权利要求）

请按以下格式输出完整专利文件：

---
# 权利要求书

**权利要求1**（独立权利要求，保护范围最宽）
一种${inventionName}，其特征在于，包括：
[详细描述核心技术特征]

**权利要求2**（从属于权利要求1）
[进一步限定的技术特征]

[继续列出其余权利要求...]

---
# 说明书

## 技术领域
本发明涉及${technicalField}领域，具体涉及[具体方向]。

## 背景技术
[现有技术描述及其存在的缺陷/不足]

## 发明内容
### 技术问题
[本发明要解决的技术问题]

### 技术方案
[详细的技术方案描述，与权利要求对应]

### 有益效果
[本发明相对于现有技术的优点和积极效果]

## 附图说明
[附图编号及说明，如：图1为本发明的整体结构示意图]

## 具体实施方式
[至少一个具体实施例的详细描述，结合附图说明]

---
# 说明书摘要
[150字以内，概括技术方案的主要内容]

---
# 摘要附图说明
[指定最能说明发明的一幅附图]`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt: PATENT_SYSTEM,
                maxTokens: 4000,
                temperature: 0.2,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err('专利文件生成失败，请重试');
            return this.text(`# ${typeLabel}申请文件\n\n**发明名称：${inventionName}**\n\n${output}`);
        }
        catch (err) {
            return this.err(`专利文件生成失败：${String(err)}`);
        }
    }
    async reviewPatent(inventionName, technicalField, description, document) {
        const docSnippet = document.slice(0, 5000);
        const prompt = `请对以下专利文件进行专业审查：

发明名称：${inventionName}
技术领域：${technicalField}
发明人描述：${description}

【待审查专利文件】
${docSnippet}${document.length > 5000 ? '\n[文件较长，已截取前5000字]' : ''}

请输出专业审查意见：

## 一、权利要求书审查
### 1.1 独立权利要求分析
- 保护范围评估（过宽/适中/过窄）
- 技术特征完整性
- 语言规范性

### 1.2 从属权利要求分析
- 层次结构合理性
- 保护梯度设计

## 二、新颖性初步评估
（基于技术描述，分析是否可能存在新颖性问题）

## 三、创造性初步评估
（分析技术方案相对于现有技术的创造性高度）

## 四、说明书充分公开性检查
- 技术方案是否充分公开
- 实施例是否足够支撑权利要求
- 说明书与权利要求的对应关系

## 五、形式规范性检查
（格式、用语、编号等规范性问题）

## 六、修改建议（按优先级）
### 必须修改
### 建议修改
### 可选优化

## 七、综合评估
（授权前景预测、主要风险点、核心建议）`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt: REVIEW_SYSTEM,
                maxTokens: 3000,
                temperature: 0.2,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err('专利审查失败，请重试');
            return this.text(`# 专利文件审查意见\n\n**发明名称：${inventionName}**\n\n${output}`);
        }
        catch (err) {
            return this.err(`专利审查失败：${String(err)}`);
        }
    }
    async searchPriorArt(inventionName, technicalField, description) {
        const prompt = `请对以下发明进行现有技术分析：

发明名称：${inventionName}
技术领域：${technicalField}
技术方案描述：${description}

请输出：

## 一、技术分解
（将发明分解为核心技术特征，逐一分析）

## 二、可能的现有技术领域
（列出可能存在相关现有技术的技术领域和方向）

## 三、关键词检索建议
（用于专利数据库检索的关键词组合，中英文）

## 四、潜在对比文件类型
（可能影响新颖性/创造性的现有技术类型）

## 五、规避设计建议
（如何调整技术方案以增强专利保护性）

## 六、检索数据库推荐
- 国内：CNIPA（国家知识产权局）、佰腾网、智慧芽
- 国际：USPTO、EPO Espacenet、Google Patents`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt: PATENT_SYSTEM,
                maxTokens: 2000,
                temperature: 0.3,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err('现有技术分析失败，请重试');
            return this.text(`# 现有技术分析报告\n\n**发明名称：${inventionName}**\n\n${output}`);
        }
        catch (err) {
            return this.err(`现有技术分析失败：${String(err)}`);
        }
    }
}
//# sourceMappingURL=patent_writer.js.map