import { nanoid } from 'nanoid';
export function createOpsStore(db) {
    const api = {
        saveJob(job) {
            const id = nanoid();
            db.prepare(`INSERT INTO scheduled_jobs (id, name, cron, prompt, channel, chat_id, user_id, status, last_run, next_run, run_count, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`).run(id, job.name, job.cron, job.prompt, job.channel, job.chatId, job.userId, job.status, job.lastRun?.getTime() ?? null, job.nextRun?.getTime() ?? null, Date.now());
            return id;
        },
        getJobs(userId) {
            const rows = (userId
                ? db.prepare(`SELECT * FROM scheduled_jobs WHERE user_id = ?`).all(userId)
                : db.prepare(`SELECT * FROM scheduled_jobs`).all());
            return rows.map((r) => ({
                id: r['id'], name: r['name'], cron: r['cron'],
                prompt: r['prompt'], channel: r['channel'],
                chatId: r['chat_id'], userId: r['user_id'],
                status: r['status'],
                lastRun: r['last_run'] ? new Date(r['last_run']) : undefined,
                nextRun: r['next_run'] ? new Date(r['next_run']) : undefined,
                runCount: r['run_count'], createdAt: new Date(r['created_at']),
            }));
        },
        updateJobRun(id, nextRun) {
            db.prepare(`UPDATE scheduled_jobs SET last_run = ?, next_run = ?, run_count = run_count + 1 WHERE id = ?`).run(Date.now(), nextRun?.getTime() ?? null, id);
        },
        updateJobStatus(id, status) {
            db.prepare(`UPDATE scheduled_jobs SET status = ? WHERE id = ?`).run(status, id);
        },
        deleteJob(id) {
            const result = db.prepare(`DELETE FROM scheduled_jobs WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        updateJobNotifyIf(id, notifyIf) {
            db.prepare(`UPDATE scheduled_jobs SET notify_if = ? WHERE id = ?`).run(notifyIf, id);
        },
        updateJobLastResult(id, lastResult) {
            db.prepare(`UPDATE scheduled_jobs SET last_result = ? WHERE id = ?`).run(lastResult, id);
        },
        savePatrolCheck(check) {
            const id = nanoid();
            db.prepare(`INSERT INTO patrol_checks (id, name, type, target, interval_min, method, expected_status, keyword,
         timeout_ms, alert_threshold, channel, chat_id, user_id, status, consecutive_failures, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`).run(id, check.name, check.type, check.target, check.intervalMin, check.method ?? null, check.expectedStatus ?? null, check.keyword ?? null, check.timeoutMs, check.alertThreshold, check.channel, check.chatId, check.userId, check.status, Date.now());
            return id;
        },
        getPatrolChecks(userId) {
            const rows = (userId
                ? db.prepare(`SELECT * FROM patrol_checks WHERE user_id = ?`).all(userId)
                : db.prepare(`SELECT * FROM patrol_checks`).all());
            return rows.map((r) => ({
                id: r['id'],
                name: r['name'],
                type: r['type'],
                target: r['target'],
                intervalMin: r['interval_min'],
                method: r['method'],
                expectedStatus: r['expected_status'],
                keyword: r['keyword'],
                timeoutMs: r['timeout_ms'],
                alertThreshold: r['alert_threshold'],
                channel: r['channel'],
                chatId: r['chat_id'],
                userId: r['user_id'],
                status: r['status'],
                consecutiveFailures: r['consecutive_failures'],
                lastCheck: r['last_check'] ? new Date(r['last_check']) : undefined,
                lastStatus: r['last_status'],
                createdAt: new Date(r['created_at']),
            }));
        },
        updatePatrolResult(id, ok, status, consecutiveFailures) {
            db.prepare(`UPDATE patrol_checks SET last_check = ?, last_status = ?, consecutive_failures = ? WHERE id = ?`).run(Date.now(), status, consecutiveFailures, id);
        },
        updatePatrolStatus(id, status) {
            db.prepare(`UPDATE patrol_checks SET status = ? WHERE id = ?`).run(status, id);
        },
        deletePatrolCheck(id) {
            db.prepare(`DELETE FROM patrol_results WHERE check_id = ?`).run(id);
            const result = db.prepare(`DELETE FROM patrol_checks WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        savePatrolResult(result) {
            db.prepare(`INSERT INTO patrol_results (id, check_id, ok, status_code, latency_ms, error, checked_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), result.checkId, result.ok ? 1 : 0, result.statusCode ?? null, result.latencyMs, result.error ?? null, Date.now());
        },
        getPatrolHistory(checkId, limit = 20) {
            const rows = db.prepare(`SELECT * FROM patrol_results WHERE check_id = ? ORDER BY checked_at DESC LIMIT ?`).all(checkId, limit);
            return rows.map((r) => ({
                id: r['id'], checkId: r['check_id'],
                ok: r['ok'] === 1,
                statusCode: r['status_code'],
                latencyMs: r['latency_ms'],
                error: r['error'],
                checkedAt: new Date(r['checked_at']),
            }));
        },
        saveWorkflow(wf) {
            const id = nanoid();
            db.prepare(`INSERT INTO workflows (id, name, description, trigger, steps, channel, chat_id, user_id, status, run_count, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', 0, ?)`).run(id, wf.name, wf.description ?? null, wf.trigger, JSON.stringify(wf.steps), wf.channel, wf.chatId, wf.userId, Date.now());
            return id;
        },
        getWorkflows(userId) {
            const rows = (userId
                ? db.prepare(`SELECT * FROM workflows WHERE user_id = ?`).all(userId)
                : db.prepare(`SELECT * FROM workflows`).all());
            return rows.map((r) => ({
                id: r['id'], name: r['name'],
                description: r['description'],
                trigger: r['trigger'],
                steps: JSON.parse(r['steps']),
                channel: r['channel'], chatId: r['chat_id'],
                userId: r['user_id'], status: r['status'],
                lastRun: r['last_run'] ? new Date(r['last_run']) : undefined,
                runCount: r['run_count'], createdAt: new Date(r['created_at']),
            }));
        },
        updateWorkflowRun(id) {
            db.prepare(`UPDATE workflows SET last_run = ?, run_count = run_count + 1 WHERE id = ?`).run(Date.now(), id);
        },
        updateWorkflowStatus(id, status) {
            db.prepare(`UPDATE workflows SET status = ? WHERE id = ?`).run(status, id);
        },
        deleteWorkflow(id) {
            const result = db.prepare(`DELETE FROM workflows WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        /** Returns the timestamp (ms) of the most recently completed scheduled job run, or null. */
        getLastJobRunTime() {
            const row = db.prepare(`SELECT last_run FROM scheduled_jobs WHERE last_run IS NOT NULL ORDER BY last_run DESC LIMIT 1`).get();
            return row?.last_run ?? null;
        },
        /** Returns the timestamp (ms) of the most recently completed workflow run, or null. */
        getLastWorkflowRunTime() {
            const row = db.prepare(`SELECT last_run FROM workflows WHERE last_run IS NOT NULL ORDER BY last_run DESC LIMIT 1`).get();
            return row?.last_run ?? null;
        },
    };
    return api;
}
//# sourceMappingURL=store_ops.js.map