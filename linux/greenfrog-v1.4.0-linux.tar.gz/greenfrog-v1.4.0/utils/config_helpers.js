/**
 * Shared config helper — extracted so server (web/index.ts) and test suites
 * can import the same function without duplicating it.
 */
export const CONFIG_MASKED_SENTINEL = '__GF_MASKED__';
/**
 * Recursively remove sentinel values so configManager.set() does not overwrite
 * unchanged secrets that the client sent back as __GF_MASKED__.
 */
export function stripMaskedFields(obj) {
    if (typeof obj === 'string')
        return obj === CONFIG_MASKED_SENTINEL ? undefined : obj;
    if (typeof obj !== 'object' || obj === null)
        return obj;
    if (Array.isArray(obj))
        return obj.map(stripMaskedFields).filter((v) => v !== undefined);
    const out = {};
    for (const [k, v] of Object.entries(obj)) {
        const stripped = stripMaskedFields(v);
        if (stripped !== undefined)
            out[k] = stripped;
    }
    return out;
}
//# sourceMappingURL=config_helpers.js.map