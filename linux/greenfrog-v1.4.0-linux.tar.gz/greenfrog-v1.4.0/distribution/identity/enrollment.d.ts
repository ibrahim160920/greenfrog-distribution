/**
 * enrollment.ts — Identity generation and enrollment key management.
 *
 * Responsibilities:
 *   - Generate installId (128-bit random UUID, stable per installation)
 *   - Derive instanceId (SHA-256 anonymized, safe to send externally)
 *   - Generate enrollmentKey (256-bit cryptographic random hex)
 *   - Persist to .greenfrog/identity/install.json
 *   - Read back on subsequent boots (idempotent)
 *
 * The enrollmentKey is NEVER user-typed. It is:
 *   1. Auto-generated at first boot
 *   2. Auto-filled in the UI (read-only display)
 *   3. Auto-saved locally
 *   4. Used for registration with the mother-body
 */
import type { InstallRecord } from './types.js';
/**
 * Load existing install record, or generate + persist a new one.
 * Idempotent: calling multiple times returns the same record.
 *
 * @param baseDir  Override for the .greenfrog root (used in tests)
 */
export declare function loadOrCreateInstallRecord(baseDir?: string): InstallRecord;
/**
 * Read an existing install record without creating one.
 * Returns null if not yet initialized.
 */
export declare function readInstallRecord(baseDir?: string): InstallRecord | null;
/**
 * Return true if this installation has been initialized (install.json exists
 * with valid content).
 */
export declare function isInstallInitialized(baseDir?: string): boolean;
//# sourceMappingURL=enrollment.d.ts.map