import { existsSync, readFileSync, statSync } from 'fs';
import { isAbsolute, relative, resolve } from 'path';
import { spawnSync } from 'child_process';
import { providerRegistry } from '../providers/index.js';
import { recordSourceRepoCodeCandidate } from './source_repo_code_sync.js';
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
import { writeEvolutionOperationStatus } from './evolution_operation_status.js';
const log = createLogger('source-repo-code-generator');
const DEFAULT_SKILLS = ['coding_agent', 'file_ops', 'shell', 'git', 'code_exec', 'skill_creator'];
const ALLOWED_EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs']);
const CODE_GENERATION_SYSTEM = `You are promoting runtime learnings into a small, safe source-repository code patch.
You will receive:
- one repository-relative source file
- recent runtime evidence tied to that file
- the current file content

Return ONLY JSON with this shape:
{
  "title": "short change title",
  "summary": "one-sentence summary",
  "rationale": "why this change should be promoted into the source repository",
  "confidence": 0-100,
  "patch": "git unified diff that applies cleanly to the current file"
}

Rules:
- Prefer tiny deterministic patches over broad rewrites
- Modify only the provided file
- Patch must begin with diff --git and be valid unified diff
- Keep title under 80 chars
- Keep summary under 180 chars
- Keep rationale under 300 chars
- If the evidence is too weak or no safe patch is justified, return {}
- Do not include markdown fences or prose outside JSON`;
function buildDefaultConfig(partial) {
    return {
        enabled: false,
        repoPath: '',
        lookbackDays: 14,
        maxAuditEntries: 200,
        maxCandidates: 3,
        maxEvidencePerCandidate: 8,
        maxFileContextChars: 8000,
        minEvidenceCount: 4,
        minFailureCount: 2,
        minSuccessCount: 1,
        skills: DEFAULT_SKILLS,
        ...partial,
    };
}
function normalizeRepoRelativePath(repoRoot, raw) {
    const trimmed = raw.trim().replace(/^["'`]+|["'`]+$/g, '');
    if (!trimmed)
        return null;
    const candidates = new Set([trimmed]);
    const pathMatches = trimmed.match(/[A-Za-z0-9_./\\-]+\.(?:ts|tsx|js|jsx|mjs|cjs)/g);
    for (const match of pathMatches ?? []) {
        candidates.add(match);
    }
    for (const candidate of candidates) {
        const normalized = candidate.replace(/\//g, '\\');
        const absolute = normalized.includes(':\\') || normalized.startsWith('\\\\')
            ? normalized
            : resolve(repoRoot, normalized);
        const rel = relative(repoRoot, absolute);
        if (rel.startsWith('..') || rel.includes(`..\\`) || rel.includes('../'))
            continue;
        if (!existsSync(absolute))
            continue;
        if (!statSync(absolute).isFile())
            continue;
        const ext = absolute.slice(absolute.lastIndexOf('.')).toLowerCase();
        if (!ALLOWED_EXTENSIONS.has(ext))
            continue;
        return rel.replace(/\\/g, '/');
    }
    return null;
}
function collectStringLeaves(value, output = []) {
    if (typeof value === 'string') {
        output.push(value);
        return output;
    }
    if (Array.isArray(value)) {
        for (const item of value)
            collectStringLeaves(item, output);
        return output;
    }
    if (value && typeof value === 'object') {
        for (const item of Object.values(value))
            collectStringLeaves(item, output);
    }
    return output;
}
async function collectAuditEntries(config) {
    const lookbackMs = Math.max(1, config.lookbackDays) * 24 * 60 * 60 * 1000;
    const entries = [];
    for (const skillName of config.skills) {
        const rows = await memoryStore.queryAuditLog({
            skillName,
            sinceMs: lookbackMs,
            limit: config.maxAuditEntries,
        });
        entries.push(...rows);
    }
    return entries
        .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
        .slice(0, config.maxAuditEntries);
}
function buildEvidenceMap(repoRoot, entries) {
    const byFile = new Map();
    for (const entry of entries) {
        const strings = [
            ...collectStringLeaves(entry.params),
            entry.error ?? '',
        ];
        const files = new Set();
        for (const text of strings) {
            const path = normalizeRepoRelativePath(repoRoot, text);
            if (path)
                files.add(path);
        }
        for (const file of files) {
            const bucket = byFile.get(file) ?? {
                file,
                entries: [],
                successCount: 0,
                failureCount: 0,
                sources: new Set(),
            };
            bucket.entries.push(entry);
            bucket.sources.add(entry.skillName);
            if (entry.success)
                bucket.successCount += 1;
            else
                bucket.failureCount += 1;
            byFile.set(file, bucket);
        }
    }
    return [...byFile.values()].sort((a, b) => b.failureCount - a.failureCount
        || b.entries.length - a.entries.length
        || a.file.localeCompare(b.file));
}
function summarizeEvidence(file, evidence, maxItems) {
    const lines = [
        `Target file: ${file}`,
        `Observed successes: ${evidence.successCount}`,
        `Observed failures: ${evidence.failureCount}`,
        `Total evidence count: ${evidence.entries.length}`,
        `Sources: ${[...evidence.sources].sort().join(', ')}`,
        '',
        'Recent evidence:',
    ];
    for (const entry of evidence.entries.slice(0, maxItems)) {
        const parts = [
            `${entry.success ? 'SUCCESS' : 'FAILURE'} ${entry.skillName}`,
            `time=${entry.timestamp.toISOString()}`,
            `durationMs=${entry.durationMs}`,
        ];
        const errorText = entry.error ? ` error=${entry.error}` : '';
        const paramsText = entry.params ? ` params=${JSON.stringify(entry.params).slice(0, 400)}` : '';
        lines.push(`- ${parts.join(' ')}${errorText}${paramsText}`);
    }
    return lines.join('\n');
}
function extractJsonObject(raw) {
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match)
        return null;
    try {
        return JSON.parse(match[0]);
    }
    catch {
        return null;
    }
}
function validatePatch(repoRoot, file, patch) {
    const normalizedPatch = patch.replace(/\r\n/g, '\n').trim();
    if (!normalizedPatch.startsWith(`diff --git a/${file} b/${file}`))
        return false;
    const result = spawnSync('git', ['apply', '--check', '-'], {
        cwd: repoRoot,
        encoding: 'utf8',
        timeout: 30_000,
        input: normalizedPatch.endsWith('\n') ? normalizedPatch : `${normalizedPatch}\n`,
        stdio: ['pipe', 'pipe', 'pipe'],
    });
    return !result.error && result.status === 0;
}
function computeDecisionScore(confidence, evidence) {
    const evidenceScore = Math.min(100, 45
        + Math.min(20, evidence.failureCount * 8)
        + Math.min(20, evidence.successCount * 10)
        + Math.min(15, Math.max(0, evidence.entries.length - 1) * 4));
    return Number(((confidence * 0.6) + (evidenceScore * 0.4)).toFixed(1));
}
export async function generateSourceRepoCodeCandidates(partial) {
    const config = buildDefaultConfig(partial);
    const repoRoot = config.repoPath
        ? (isAbsolute(config.repoPath) ? config.repoPath : resolve(process.cwd(), config.repoPath))
        : null;
    if (!config.enabled) {
        const result = { generated: 0, consideredFiles: 0, candidateIds: [], skippedReason: 'source repo code generation disabled' };
        if (repoRoot) {
            writeEvolutionOperationStatus(repoRoot, 'source_repo_code_generation', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    generated: result.generated,
                    consideredFiles: result.consideredFiles,
                    candidateIds: result.candidateIds,
                },
            });
        }
        return result;
    }
    if (!config.repoPath) {
        return { generated: 0, consideredFiles: 0, candidateIds: [], skippedReason: 'source repo path not configured' };
    }
    const resolvedRepoRoot = repoRoot;
    if (!resolvedRepoRoot) {
        return { generated: 0, consideredFiles: 0, candidateIds: [], skippedReason: 'source repo path not configured' };
    }
    try {
        const evidenceMap = buildEvidenceMap(resolvedRepoRoot, await collectAuditEntries(config));
        const eligibleFiles = evidenceMap.filter((evidence) => evidence.entries.length >= config.minEvidenceCount
            && evidence.failureCount >= config.minFailureCount
            && evidence.successCount >= config.minSuccessCount);
        if (eligibleFiles.length === 0) {
            const result = { generated: 0, consideredFiles: evidenceMap.length, candidateIds: [], skippedReason: 'no files met evidence gates' };
            writeEvolutionOperationStatus(resolvedRepoRoot, 'source_repo_code_generation', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    generated: result.generated,
                    consideredFiles: result.consideredFiles,
                    candidateIds: result.candidateIds,
                },
            });
            return result;
        }
        const candidateIds = [];
        for (const evidence of eligibleFiles.slice(0, config.maxCandidates)) {
            const filePath = resolve(resolvedRepoRoot, evidence.file);
            const fileContent = readFileSync(filePath, 'utf8').slice(0, config.maxFileContextChars);
            const prompt = [
                summarizeEvidence(evidence.file, evidence, config.maxEvidencePerCandidate),
                '',
                'Current file content:',
                fileContent,
                '',
                'Generate a safe repository patch candidate for this file only.',
            ].join('\n');
            const response = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt: CODE_GENERATION_SYSTEM,
                maxTokens: 1800,
                temperature: 0.1,
                ...(config.model ? { model: config.model } : {}),
            }, config.provider ?? undefined);
            const parsed = extractJsonObject(response.content ?? '');
            if (!parsed)
                continue;
            const title = typeof parsed['title'] === 'string' ? parsed['title'].trim().slice(0, 80) : '';
            const summary = typeof parsed['summary'] === 'string' ? parsed['summary'].trim().slice(0, 180) : '';
            const rationale = typeof parsed['rationale'] === 'string' ? parsed['rationale'].trim().slice(0, 300) : '';
            const patch = typeof parsed['patch'] === 'string' ? parsed['patch'] : '';
            const confidence = Math.max(0, Math.min(100, typeof parsed['confidence'] === 'number' ? parsed['confidence'] : 0));
            if (!title || !summary || !rationale || !patch || confidence <= 0)
                continue;
            if (!validatePatch(resolvedRepoRoot, evidence.file, patch)) {
                log.warn({ file: evidence.file }, 'Skipping generated code candidate because patch validation failed');
                continue;
            }
            const candidate = await recordSourceRepoCodeCandidate({
                title,
                summary,
                rationale,
                patch,
                targetFiles: [evidence.file],
                decisionScore: computeDecisionScore(confidence, evidence),
                validationCount: evidence.entries.length,
                successRate: evidence.successCount / evidence.entries.length,
                evidenceCount: evidence.entries.length,
                status: 'accepted',
                sources: [...evidence.sources].sort(),
            });
            candidateIds.push(candidate.id);
        }
        const result = {
            generated: candidateIds.length,
            consideredFiles: evidenceMap.length,
            candidateIds,
            skippedReason: candidateIds.length > 0 ? null : 'no valid code candidates generated',
        };
        writeEvolutionOperationStatus(resolvedRepoRoot, 'source_repo_code_generation', {
            status: result.generated > 0 ? 'success' : 'skipped',
            skippedReason: result.skippedReason,
            summary: {
                generated: result.generated,
                consideredFiles: result.consideredFiles,
                candidateIds: result.candidateIds,
            },
        });
        return result;
    }
    catch (err) {
        writeEvolutionOperationStatus(resolvedRepoRoot, 'source_repo_code_generation', {
            status: 'error',
            skippedReason: err instanceof Error ? err.message : String(err),
        });
        throw err;
    }
}
//# sourceMappingURL=source_repo_code_generator.js.map