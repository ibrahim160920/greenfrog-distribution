/**
 * Stale Task Recovery for GreenFrog P4.2.
 *
 * Detects and recovers tasks that are stuck in `in_progress` due to:
 *   - Process crash / restart mid-execution
 *   - Synchronous loop timeout (runDispatchLoop hung)
 *   - Network failure that never triggered the catch block
 *
 * Design:
 *   - A task is "stale" if: status=in_progress AND lastRunAt older than
 *     STALE_THRESHOLD_MS AND currentRunId is set (meaning a run was started
 *     but never completed the cleanup path).
 *   - Recovery: reset to queued state (claimed/open), set executionPhase=
 *     'interrupted', write lastRunStatus='interrupted' so the next run's
 *     context assembly can inject a "previous attempt was interrupted" hint.
 *   - Called at startup and optionally on a periodic schedule.
 *
 * Hardening principle:
 *   System must never leave tasks in semantically ambiguous in_progress state.
 *   A stale task is better reset to queued than left hanging indefinitely.
 */
/** A task is considered stale if it has been in_progress longer than this */
export declare const STALE_THRESHOLD_MS: number;
/**
 * Detect tasks stuck in `in_progress` past the stale threshold and reset them
 * to their queued state so they can be re-dispatched.
 *
 * Returns the number of tasks recovered and diagnostic details.
 */
export declare function detectAndRecoverStaleTasks(): Promise<{
    recovered: number;
    details: string[];
}>;
/**
 * Check a single task for staleness.
 * Returns true if the task was stale and has been reset.
 */
export declare function recoverStaleTaskIfNeeded(taskId: string): Promise<boolean>;
//# sourceMappingURL=stale_recovery.d.ts.map