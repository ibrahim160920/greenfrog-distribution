/**
 * Workflow executor registry.
 *
 * Solves the circular-dependency problem between workflow.ts (skill layer)
 * and index.ts (application bootstrap):
 *
 *   - workflow.ts needs to trigger executeWorkflow() on run_now
 *   - executeWorkflow() lives in index.ts (depends on runControlledAgentMessage,
 *     channelManager, etc. which are also in index.ts)
 *   - index.ts → skill layer is fine; skill layer → index.ts is circular
 *
 * Solution: index.ts registers the executor here at startup. workflow.ts
 * calls triggerWorkflowNow(), which delegates to the registered executor.
 * No circular dependency — this module has no imports from either layer.
 *
 * Registration must happen before any run_now call. If not registered
 * (e.g. in tests), triggerWorkflowNow() still creates the run record
 * but logs a warning and skips actual execution.
 */
import { createLogger } from '../utils/logger.js';
import { createWorkflowRun, failWorkflowRun, } from './run_records.js';
const log = createLogger('workflow-executor');
let _executor = null;
/** Called by index.ts at startup to provide the real executeWorkflow logic. */
export function registerWorkflowExecutor(fn) {
    _executor = fn;
}
/** Exposed for tests that need to verify an executor was registered. */
export function getWorkflowExecutor() {
    return _executor;
}
// ── Public trigger ────────────────────────────────────────────────────────────
/**
 * Trigger a workflow to execute immediately (fire-and-forget).
 *
 * Creates a run record synchronously (so callers can return the runId
 * to the user immediately), then starts execution asynchronously.
 *
 * Returns the run record. Execution errors are caught internally and
 * written to the run record.
 */
export function triggerWorkflowNow(wf) {
    const rec = createWorkflowRun(wf.id, wf.name, 'manual');
    if (!_executor) {
        // Server not fully initialized or running in test context without registration.
        // Mark the run as failed immediately so the record is not left as 'running'.
        failWorkflowRun(rec.runId, 'Workflow executor not registered — server not initialized', 0);
        log.warn({ workflowId: wf.id }, 'triggerWorkflowNow called but no executor registered');
        return rec;
    }
    const start = Date.now();
    _executor(wf, rec.runId).catch((err) => {
        failWorkflowRun(rec.runId, String(err), Date.now() - start);
        log.error({ workflowId: wf.id, runId: rec.runId, err: String(err) }, 'Workflow run failed');
    });
    return rec;
}
//# sourceMappingURL=workflow_executor.js.map