import { BaseSkill } from './base.js';
import { setScopedMemoryForContext, getScopedMemoryForContext, deleteScopedMemoryForContext, getAllScopedMemoryForContext, searchScopedMemoryForContext, } from '../memory/index.js';
export class NotesSkill extends BaseSkill {
    definition = {
        name: 'notes',
        description: 'Create, read, list, search, and delete personal notes. Notes persist across conversations.',
        category: 'productivity',
        parameters: [
            {
                name: 'action',
                type: 'string',
                description: 'Action to perform',
                required: true,
                enum: ['create', 'read', 'list', 'search', 'delete', 'update'],
            },
            { name: 'title', type: 'string', description: 'Note title' },
            { name: 'content', type: 'string', description: 'Note content' },
            { name: 'query', type: 'string', description: 'Search query (for search action)' },
        ],
    };
    async execute(params, ctx) {
        switch (params.action) {
            case 'create': {
                if (!params.title)
                    return this.err('title is required');
                const key = `note:${params.title}`;
                const content = params.content ?? '';
                const ts = new Date().toISOString();
                await setScopedMemoryForContext(ctx, key, JSON.stringify({ content, createdAt: ts, updatedAt: ts }));
                return this.text(`📝 Note saved: **${params.title}**`);
            }
            case 'read': {
                if (!params.title)
                    return this.err('title is required');
                const raw = await getScopedMemoryForContext(ctx, `note:${params.title}`);
                if (!raw)
                    return this.text(`Note not found: "${params.title}"`);
                const note = JSON.parse(raw);
                return this.text(`📝 **${params.title}**\n*Updated: ${note.updatedAt}*\n\n${note.content}`);
            }
            case 'update': {
                if (!params.title)
                    return this.err('title is required');
                const key = `note:${params.title}`;
                const existing = await getScopedMemoryForContext(ctx, key);
                const prev = existing ? JSON.parse(existing) : { createdAt: new Date().toISOString() };
                await setScopedMemoryForContext(ctx, key, JSON.stringify({
                    content: params.content ?? '',
                    createdAt: prev.createdAt,
                    updatedAt: new Date().toISOString(),
                }));
                return this.text(`✅ Note updated: **${params.title}**`);
            }
            case 'delete': {
                if (!params.title)
                    return this.err('title is required');
                const deleted = await deleteScopedMemoryForContext(ctx, `note:${params.title}`);
                return this.text(deleted ? `🗑 Deleted note: ${params.title}` : `Note not found: ${params.title}`);
            }
            case 'list': {
                const all = await getAllScopedMemoryForContext(ctx);
                const notes = Object.entries(all)
                    .filter(([k]) => k.startsWith('note:'))
                    .map(([k, v]) => {
                    const title = k.replace('note:', '');
                    const data = JSON.parse(v);
                    return `• **${title}** (${data.updatedAt.slice(0, 10)})`;
                });
                if (notes.length === 0)
                    return this.text('No notes yet. Create one with the notes skill!');
                return this.text(`📝 **Your notes (${notes.length}):**\n\n${notes.join('\n')}`);
            }
            case 'search': {
                if (!params.query)
                    return this.err('query is required');
                const results = (await searchScopedMemoryForContext(ctx, params.query))
                    .filter((e) => e.key.startsWith('note:'));
                if (results.length === 0)
                    return this.text(`No notes matching "${params.query}"`);
                const lines = results.map((r) => {
                    const title = r.key.replace('note:', '');
                    const data = JSON.parse(r.value);
                    return `• **${title}**: ${data.content.slice(0, 100)}...`;
                });
                return this.text(`🔍 Notes matching "${params.query}":\n\n${lines.join('\n')}`);
            }
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
}
//# sourceMappingURL=notes.js.map