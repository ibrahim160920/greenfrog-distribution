import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
import { createRequire } from 'module';
import { mkdirSync } from 'fs';
import { join, resolve } from 'path';
import { homedir } from 'os';
// pptxgenjs is a CommonJS module — use createRequire for ESM compatibility
const require = createRequire(import.meta.url);
const PPTX_SYSTEM = `你是一位专业的演示文稿设计师，擅长将复杂内容转化为清晰、有逻辑的PPT结构。
你能够根据主题和内容要点，设计出层次分明、重点突出的幻灯片大纲。
每张幻灯片的要点应简洁（每条不超过20字），逻辑清晰，便于演讲者讲解。`;
// Color themes per style
const THEMES = {
    business: { bg: '1F3864', title: 'FFFFFF', accent: '2E75B6', text: 'FFFFFF', slide_bg: 'FFFFFF', slide_title: '1F3864', slide_text: '333333' },
    academic: { bg: '2C3E50', title: 'FFFFFF', accent: '27AE60', text: 'FFFFFF', slide_bg: 'FAFAFA', slide_title: '2C3E50', slide_text: '2C3E50' },
    creative: { bg: '6C3483', title: 'FFFFFF', accent: 'E74C3C', text: 'FFFFFF', slide_bg: 'FFFFFF', slide_title: '6C3483', slide_text: '333333' },
};
export class PresentationSkill extends BaseSkill {
    definition = {
        name: 'presentation',
        description: '生成PPT演示文稿（.pptx格式）。根据主题和内容要点，自动生成结构完整的幻灯片，包含封面、目录、内容页和结尾页。支持商务、学术、创意三种风格。',
        category: 'professional',
        parameters: [
            { name: 'topic', type: 'string', required: true, description: 'PPT主题/标题' },
            { name: 'content', type: 'string', required: true, description: '内容要点、大纲或详细描述' },
            { name: 'style', type: 'string', required: false, description: '风格：business=商务（深蓝），academic=学术（深绿），creative=创意（紫色）', default: 'business', enum: ['business', 'academic', 'creative'] },
            { name: 'slides', type: 'number', required: false, description: '幻灯片数量（不含封面/目录/结尾），默认8，最多25', default: 8 },
            { name: 'language', type: 'string', required: false, description: '语言：zh=中文，en=英文', default: 'zh', enum: ['zh', 'en'] },
            { name: 'author', type: 'string', required: false, description: '作者/单位名称', default: '' },
            { name: 'output_path', type: 'string', required: false, description: '输出目录路径，默认为用户Downloads目录' },
        ],
        examples: [
            'presentation topic="2025年Q1销售总结" content="销售额增长20%，新客户50家，主要市场华东区..." style=business',
            'presentation topic="深度学习在医学影像中的应用" content="CNN架构、数据增强、迁移学习..." style=academic language=zh slides=10',
        ],
    };
    async execute(params, _ctx) {
        const topic = String(params.topic ?? '').trim();
        const content = String(params.content ?? '').trim();
        const style = (String(params.style ?? 'business').trim());
        const slideCount = Math.min(Math.max(parseInt(String(params.slides ?? '8')), 3), 25);
        const language = String(params.language ?? 'zh').trim();
        const author = String(params.author ?? '').trim();
        const outputPath = String(params.output_path ?? '').trim() || join(homedir(), 'Downloads');
        if (!topic)
            return this.err('请提供PPT主题');
        if (!content)
            return this.err('请提供内容要点或大纲');
        const theme = THEMES[style] ?? THEMES.business;
        const isEn = language === 'en';
        // Step 1: LLM generates slide structure
        let pptData;
        try {
            pptData = await this.generateStructure(topic, content, slideCount, isEn, author);
        }
        catch (err) {
            return this.err(`幻灯片结构生成失败：${String(err)}`);
        }
        // Step 2: Render PPTX
        try {
            const filePath = await this.renderPptx(pptData, theme, outputPath, topic);
            const slideList = pptData.slides.map((s, i) => `  ${i + 1}. ${s.title}`).join('\n');
            return this.text(`# PPT生成完成\n\n` +
                `**文件路径：** \`${filePath}\`\n\n` +
                `**幻灯片列表（共${pptData.slides.length}页）：**\n${slideList}\n\n` +
                `> 提示：用 Microsoft PowerPoint 或 WPS 打开 .pptx 文件`);
        }
        catch (err) {
            return this.err(`PPTX文件生成失败：${String(err)}`);
        }
    }
    async generateStructure(topic, content, slideCount, isEn, author) {
        const today = new Date().toLocaleDateString(isEn ? 'en-US' : 'zh-CN');
        const prompt = isEn
            ? `Generate a PowerPoint presentation structure for the following topic.
Output ONLY valid JSON, no markdown, no explanation.

Topic: ${topic}
Content/Key Points: ${content}
Number of content slides: ${slideCount}

JSON format:
{
  "title": "presentation title",
  "subtitle": "subtitle or tagline",
  "author": "${author || 'Presenter'}",
  "date": "${today}",
  "slides": [
    {"type": "cover", "title": "...", "subtitle": "..."},
    {"type": "toc", "title": "Agenda", "bullets": ["Section 1", "Section 2", ...]},
    {"type": "content", "title": "slide title", "bullets": ["point 1 (max 20 chars)", "point 2", ...], "notes": "speaker notes"},
    ... (${slideCount} content slides total),
    {"type": "end", "title": "Thank You", "subtitle": "Q&A"}
  ]
}`
            : `为以下主题生成PPT幻灯片结构。
只输出有效的JSON，不要markdown格式，不要解释。

主题：${topic}
内容要点：${content}
内容幻灯片数量：${slideCount}

JSON格式：
{
  "title": "PPT标题",
  "subtitle": "副标题",
  "author": "${author || '演讲者'}",
  "date": "${today}",
  "slides": [
    {"type": "cover", "title": "...", "subtitle": "..."},
    {"type": "toc", "title": "目录", "bullets": ["第一部分", "第二部分", ...]},
    {"type": "content", "title": "幻灯片标题", "bullets": ["要点1（不超过20字）", "要点2", ...], "notes": "演讲备注"},
    ... (共${slideCount}张内容幻灯片),
    {"type": "end", "title": "谢谢", "subtitle": "Q&A"}
  ]
}`;
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: prompt }],
            systemPrompt: PPTX_SYSTEM,
            maxTokens: 3000,
            temperature: 0.3,
        });
        const raw = res.content?.trim() ?? '';
        // Extract JSON from response (may be wrapped in ```json ... ```)
        const jsonMatch = raw.match(/\{[\s\S]*\}/);
        if (!jsonMatch)
            throw new Error('LLM未返回有效JSON结构');
        const data = JSON.parse(jsonMatch[0]);
        if (!data.slides || !Array.isArray(data.slides))
            throw new Error('JSON结构无效：缺少slides数组');
        return data;
    }
    async renderPptx(data, theme, outputDir, topic) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const PptxGenJS = require('pptxgenjs');
        const pptx = new PptxGenJS();
        pptx.layout = 'LAYOUT_WIDE'; // 16:9
        pptx.author = data.author;
        pptx.title = data.title;
        for (const slide of data.slides) {
            const s = pptx.addSlide();
            if (slide.type === 'cover') {
                // Dark background cover
                s.background = { color: theme.bg };
                s.addText(slide.title, {
                    x: 0.5, y: 2.5, w: '90%', h: 1.2,
                    fontSize: 36, bold: true, color: theme.title,
                    align: 'center', fontFace: 'Microsoft YaHei',
                });
                if (slide.subtitle) {
                    s.addText(slide.subtitle, {
                        x: 0.5, y: 3.9, w: '90%', h: 0.6,
                        fontSize: 20, color: theme.accent,
                        align: 'center', fontFace: 'Microsoft YaHei',
                    });
                }
                s.addText(`${data.author}  |  ${data.date}`, {
                    x: 0.5, y: 6.5, w: '90%', h: 0.4,
                    fontSize: 14, color: 'AAAAAA',
                    align: 'center', fontFace: 'Microsoft YaHei',
                });
            }
            else if (slide.type === 'toc') {
                s.background = { color: theme.slide_bg };
                s.addText(slide.title, {
                    x: 0.5, y: 0.3, w: '90%', h: 0.8,
                    fontSize: 28, bold: true, color: theme.slide_title,
                    fontFace: 'Microsoft YaHei',
                });
                // Accent line
                s.addShape(pptx.ShapeType.rect, {
                    x: 0.5, y: 1.1, w: 1.5, h: 0.06,
                    fill: { color: theme.accent }, line: { color: theme.accent },
                });
                const bullets = slide.bullets ?? [];
                bullets.forEach((b, i) => {
                    s.addText(`${i + 1}.  ${b}`, {
                        x: 0.8, y: 1.4 + i * 0.65, w: '85%', h: 0.55,
                        fontSize: 18, color: theme.slide_text,
                        fontFace: 'Microsoft YaHei',
                    });
                });
            }
            else if (slide.type === 'content') {
                s.background = { color: theme.slide_bg };
                // Title bar
                s.addShape(pptx.ShapeType.rect, {
                    x: 0, y: 0, w: '100%', h: 1.1,
                    fill: { color: theme.bg }, line: { color: theme.bg },
                });
                s.addText(slide.title, {
                    x: 0.4, y: 0.15, w: '92%', h: 0.8,
                    fontSize: 24, bold: true, color: theme.title,
                    fontFace: 'Microsoft YaHei',
                });
                // Bullets
                const bullets = slide.bullets ?? [];
                bullets.slice(0, 6).forEach((b, i) => {
                    s.addText(`▸  ${b}`, {
                        x: 0.6, y: 1.3 + i * 0.85, w: '88%', h: 0.75,
                        fontSize: 18, color: theme.slide_text,
                        fontFace: 'Microsoft YaHei',
                    });
                });
                if (slide.notes) {
                    s.addNotes(slide.notes);
                }
            }
            else if (slide.type === 'end') {
                s.background = { color: theme.bg };
                s.addText(slide.title, {
                    x: 0.5, y: 2.8, w: '90%', h: 1.0,
                    fontSize: 40, bold: true, color: theme.title,
                    align: 'center', fontFace: 'Microsoft YaHei',
                });
                if (slide.subtitle) {
                    s.addText(slide.subtitle, {
                        x: 0.5, y: 4.0, w: '90%', h: 0.6,
                        fontSize: 22, color: theme.accent,
                        align: 'center', fontFace: 'Microsoft YaHei',
                    });
                }
            }
        }
        // Ensure output directory exists
        mkdirSync(outputDir, { recursive: true });
        const safeName = topic.replace(/[\\/:*?"<>|]/g, '_').slice(0, 50);
        const fileName = `${safeName}_${Date.now()}.pptx`;
        const filePath = resolve(join(outputDir, fileName));
        // pptxgenjs writeFile returns a promise in newer versions
        await pptx.writeFile({ fileName: filePath });
        return filePath;
    }
}
//# sourceMappingURL=presentation.js.map