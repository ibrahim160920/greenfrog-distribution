/**
 * Recovery Policy layer for GreenFrog P4.
 *
 * Provides structured error classification and differentiated recovery
 * planning. Instead of uniform retry-or-escalate, errors are classified
 * and each class gets a tailored recovery action.
 *
 * This is a pure module — no I/O, no DB access.
 * The caller (team.ts dispatchTeamTaskById) executes the plan.
 */
// ── Error classification ──────────────────────────────────────────────────────
// Patterns that identify each error class (case-insensitive)
const CLASS_PATTERNS = [
    {
        cls: 'provider_error',
        patterns: [
            /overloaded/i,
            /rate.?limit/i,
            /too many requests/i,
            /529/,
            /503/,
            /502/,
            /anthropic.*error/i,
            /openai.*error/i,
            /provider.*error/i,
            /network.*error/i,
            /ECONNRESET/,
            /ETIMEDOUT/,
            /ENOTFOUND/,
            /fetch.*failed/i,
            /socket hang up/i,
            /runtime is saturated/i,
            /concurrency limit reached/i,
        ],
    },
    {
        cls: 'tool_error',
        patterns: [
            /tool.*not found/i,
            /skill.*not found/i,
            /unknown tool/i,
            /invalid tool/i,
            /tool.*failed/i,
            /skill.*error/i,
            /permission denied/i,
            /access denied/i,
        ],
    },
    {
        cls: 'context_missing',
        patterns: [
            /context.*missing/i,
            /no context/i,
            /missing.*input/i,
            /required.*parameter/i,
            /undefined.*variable/i,
            /cannot read.*undefined/i,
            /null.*reference/i,
        ],
    },
    {
        cls: 'environment_issue',
        patterns: [
            /ENOENT/,
            /EACCES/,
            /file.*not found/i,
            /directory.*not found/i,
            /command.*not found/i,
            /ENOTEMPTY/,
            /disk.*full/i,
            /out of memory/i,
        ],
    },
    {
        cls: 'unclear_goal',
        patterns: [
            /unclear.*goal/i,
            /ambiguous/i,
            /don.*understand/i,
            /what.*should/i,
            /need.*clarification/i,
            /not sure.*what/i,
        ],
    },
    {
        cls: 'quality_insufficient',
        patterns: [
            /quality.*insufficient/i,
            /does not meet/i,
            /criteria.*not met/i,
            /failed.*validation/i,
            /assertion.*failed/i,
        ],
    },
];
/**
 * Classify an error message into a known ErrorClass.
 * Falls through to 'unknown' if no pattern matches.
 */
export function classifyError(err) {
    const msg = err instanceof Error ? err.message : String(err);
    for (const { cls, patterns } of CLASS_PATTERNS) {
        if (patterns.some(p => p.test(msg)))
            return cls;
    }
    return 'unknown';
}
// ── Recovery planning ─────────────────────────────────────────────────────────
/**
 * Determine what to do given an error class, remaining attempts, and policy.
 *
 * P4.2: `attemptsRemaining` is now passed explicitly by the caller, computed
 * from the unified `effectiveMaxAttempts` in team.ts. This removes the previous
 * dependency on `task.metadata.retryCount` and makes the boundary consistent
 * with `task.maxAttempts`.
 *
 * @param attemptsRemaining — how many more runs are permitted after this one
 */
export function planRecovery(errorClass, attemptsRemaining, policy) {
    const isRetryable = policy.retryOn.includes(errorClass);
    // If no attempts remain, escalate or fail permanently
    if (attemptsRemaining <= 0) {
        if (errorClass === 'unclear_goal' || errorClass === 'context_missing') {
            return {
                action: 'escalate',
                errorClass,
                delayMs: 0,
                reason: `已达最大重试次数（${policy.maxAttempts}），且问题需要人工介入（${errorClass}）`,
            };
        }
        return {
            action: 'fail_permanent',
            errorClass,
            delayMs: 0,
            reason: `已达最大重试次数（${policy.maxAttempts}），标记为永久失败`,
        };
    }
    // Class-specific recovery strategies
    switch (errorClass) {
        case 'provider_error':
            if (!isRetryable) {
                return {
                    action: 'escalate',
                    errorClass,
                    delayMs: 0,
                    reason: '提供商错误不在重试列表，升级处理',
                };
            }
            return {
                action: 'retry_with_delay',
                errorClass,
                delayMs: Math.max(policy.retryDelayMs, 3000), // at least 3s for provider errors
                reason: '提供商暂时不可用，稍后重试',
            };
        case 'tool_error':
            if (!isRetryable) {
                return {
                    action: 'fail_permanent',
                    errorClass,
                    delayMs: 0,
                    reason: '工具错误不在重试列表，标记失败',
                };
            }
            return {
                action: 'retry_with_hint',
                errorClass,
                hint: '上一次运行遇到工具调用错误。请检查工具名称和参数格式，谨慎地重新尝试。',
                delayMs: policy.retryDelayMs,
                reason: '工具错误，附带提示重试',
            };
        case 'context_missing':
            // Auto-recover first: ask the agent to proceed with available info.
            // Only escalate if attempts exhausted (checked above).
            return {
                action: 'retry_with_hint',
                errorClass,
                hint: '上一次运行因缺少上下文而失败。请基于现有信息做出合理假设，尽力完成任务目标。如果某个输入确实不可得，请在结果摘要中说明你的假设。',
                delayMs: policy.retryDelayMs,
                reason: '上下文缺失，尝试基于现有信息自动恢复',
            };
        case 'environment_issue':
            if (!isRetryable) {
                return {
                    action: 'fail_permanent',
                    errorClass,
                    delayMs: 0,
                    reason: '环境问题不在重试列表，标记失败',
                };
            }
            return {
                action: 'retry_with_hint',
                errorClass,
                hint: '上一次运行遇到环境问题（文件/目录/权限）。请检查路径和权限后重试。',
                delayMs: policy.retryDelayMs,
                reason: '环境问题，附带提示重试',
            };
        case 'unclear_goal':
            // Auto-recover first: instruct the agent to pick the most reasonable
            // interpretation and proceed. Only escalate if attempts exhausted.
            return {
                action: 'retry_with_hint',
                errorClass,
                hint: '上一次运行因目标不清晰而失败。请选择最合理的任务解释，以最简单直接的方式完成目标，并在结果摘要中说明你采用的解释。不要反复请求澄清——请直接行动。',
                delayMs: policy.retryDelayMs,
                reason: '目标不明确，尝试简化目标后自动恢复',
            };
        case 'quality_insufficient':
            if (attemptsRemaining > 0) {
                return {
                    action: 'retry_with_hint',
                    errorClass,
                    hint: '上一次执行结果质量不足，未满足验收标准。请更仔细地完成任务要求。',
                    delayMs: policy.retryDelayMs,
                    reason: '质量不足，附带提示重试',
                };
            }
            return {
                action: 'escalate',
                errorClass,
                delayMs: 0,
                reason: '多次尝试后质量仍不足，需要人工审查',
            };
        case 'unknown':
        default:
            if (!isRetryable) {
                return {
                    action: 'fail_permanent',
                    errorClass,
                    delayMs: 0,
                    reason: '未知错误不在重试列表，标记失败',
                };
            }
            return {
                action: 'retry_immediately',
                errorClass,
                delayMs: policy.retryDelayMs,
                reason: '未分类错误，尝试重试',
            };
    }
}
//# sourceMappingURL=recovery.js.map