import chalk from 'chalk';
import { config } from '../../config/index.js';
import { getProjectEvolutionCapabilities, resolveProjectEvolutionMode } from '../../memory/evolution_mode.js';
import { applyProjectUpgrade, checkForProjectUpgrade } from '../../runtime/project_upgrade.js';
function resolveUpgradeConfig(overrides) {
    const mode = resolveProjectEvolutionMode(config.evolution);
    const caps = getProjectEvolutionCapabilities(mode);
    const upgrade = config.evolution?.upgrade;
    return {
        enabled: caps.allowUpgradeAutomation && Boolean(upgrade?.enabled),
        repoPath: upgrade?.repoPath ?? process.cwd(),
        manifestPath: upgrade?.manifestPath ?? '.greenfrog/releases/latest.json',
        remote: upgrade?.remote ?? 'origin',
        baseBranch: upgrade?.baseBranch ?? 'main',
        autoApply: overrides?.autoApply ?? upgrade?.autoApply ?? false,
        approvalWindowStartHourUtc: upgrade?.approvalWindowStartHourUtc,
        approvalWindowEndHourUtc: upgrade?.approvalWindowEndHourUtc,
        approvedWeekdaysUtc: upgrade?.approvedWeekdaysUtc,
        rolloutPercentage: upgrade?.rolloutPercentage ?? 100,
        rolloutSeed: upgrade?.rolloutSeed,
        healthCheckCommands: upgrade?.healthCheckCommands ?? [],
        minHealthChecksPassing: upgrade?.minHealthChecksPassing ?? 0,
        verificationCommands: upgrade?.verificationCommands ?? [],
        minVerificationChecksPassing: upgrade?.minVerificationChecksPassing ?? 0,
        autoRollbackOnVerificationFailure: upgrade?.autoRollbackOnVerificationFailure ?? false,
        requireCleanWorkingTree: upgrade?.requireCleanWorkingTree ?? true,
        installCommand: upgrade?.installCommand,
        buildCommand: upgrade?.buildCommand,
        restartOnApply: upgrade?.restartOnApply ?? true,
    };
}
export async function manageUpgrade(opts) {
    const upgradeConfig = resolveUpgradeConfig({ autoApply: opts.apply === true });
    const result = opts.apply
        ? await applyProjectUpgrade(upgradeConfig)
        : await checkForProjectUpgrade(upgradeConfig);
    if (!result.enabled) {
        console.log(chalk.yellow('Project upgrade is disabled.'));
        return;
    }
    console.log(chalk.bold('\nProject Upgrade Status'));
    console.log(`  ${chalk.cyan('Current version:')} ${result.currentVersion}`);
    console.log(`  ${chalk.cyan('Target version:')} ${result.targetVersion ?? 'none'}`);
    console.log(`  ${chalk.cyan('Current Git SHA:')} ${result.currentGitSha ?? 'unknown'}`);
    console.log(`  ${chalk.cyan('Target Git SHA:')} ${result.targetGitSha ?? 'unknown'}`);
    console.log(`  ${chalk.cyan('Update available:')} ${result.available ? 'yes' : 'no'}`);
    console.log(`  ${chalk.cyan('Source:')} ${result.source}`);
    if ('applied' in result) {
        const applyResult = result;
        console.log(`  ${chalk.cyan('Applied:')} ${applyResult.applied ? 'yes' : 'no'}`);
        console.log(`  ${chalk.cyan('Rolled back:')} ${applyResult.rolledBack ? 'yes' : 'no'}`);
        console.log(`  ${chalk.cyan('Commands run:')} ${applyResult.commandsRun.length > 0 ? applyResult.commandsRun.join(', ') : 'none'}`);
        console.log(`  ${chalk.cyan('Rollback commands:')} ${applyResult.rollbackCommandsRun.length > 0 ? applyResult.rollbackCommandsRun.join(', ') : 'none'}`);
    }
    if (result.skippedReason) {
        console.log(`  ${chalk.yellow('Reason:')} ${result.skippedReason}`);
    }
    if ('applied' in result && result.applied && upgradeConfig.restartOnApply) {
        console.log(chalk.yellow('\nUpgrade applied. Restart the process to load the new code.'));
    }
}
//# sourceMappingURL=upgrade.js.map