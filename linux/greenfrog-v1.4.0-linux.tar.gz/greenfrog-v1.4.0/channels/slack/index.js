import { App } from '@slack/bolt';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { config } from '../../config/index.js';
export class SlackChannel extends BaseChannel {
    name = 'slack';
    app = null;
    _running = false;
    async start() {
        const cfg = config.channels.slack;
        const isPlaceholder = (s) => !s || s.startsWith('xoxb-xxxx') || s.startsWith('xapp-xxxx') || s === 'placeholder';
        if (!cfg?.enabled || !cfg.botToken || isPlaceholder(cfg.botToken)) {
            this.log.info('Slack not configured, skipping');
            return;
        }
        this.app = new App({
            token: cfg.botToken,
            socketMode: !!cfg.appToken,
            appToken: cfg.appToken || undefined,
            signingSecret: cfg.signingSecret || 'placeholder',
        });
        const allowedUsers = cfg.allowedUsers ?? [];
        const isAllowed = (userId) => {
            if (allowedUsers.length === 0)
                return true;
            return allowedUsers.includes(userId);
        };
        // Handle mentions
        this.app.event('app_mention', async ({ event, say }) => {
            const userId = event.user;
            if (!userId)
                return; // bot messages have no user
            if (!isAllowed(userId)) {
                await say('⛔ You are not authorized to use GreenFrog.');
                return;
            }
            const text = event.text.replace(/<@[A-Z0-9]+>/g, '').trim();
            if (!text)
                return;
            const msg = {
                id: nanoid(),
                channel: 'slack',
                userId,
                chatId: event.channel,
                text,
                timestamp: new Date(parseFloat(event.ts) * 1000),
                raw: event,
            };
            await this.handleMessage(msg);
        });
        // Handle DMs
        this.app.message(async ({ message }) => {
            const msg = message;
            if (msg.subtype || !msg.text || !msg.user)
                return;
            if (!isAllowed(msg.user))
                return;
            const inMsg = {
                id: nanoid(),
                channel: 'slack',
                userId: msg.user,
                chatId: msg.channel,
                text: msg.text,
                timestamp: new Date(parseFloat(msg.ts) * 1000),
                raw: message,
            };
            await this.handleMessage(inMsg);
        });
        if (cfg.appToken) {
            await this.app.start();
        }
        else {
            await this.app.start({ port: 3001 });
        }
        this._running = true;
        this.log.info('Slack channel started');
    }
    async stop() {
        await this.app?.stop();
        this._running = false;
    }
    async send(message) {
        if (!this.app || !message.chatId)
            return;
        try {
            const text = (message.text ?? '')
                .replace(/\*\*(.+?)\*\*/g, '*$1*') // bold
                .replace(/`{3}[\w]*\n([\s\S]+?)`{3}/g, '```$1```') // code blocks
                .trim();
            await this.app.client.chat.postMessage({
                channel: message.chatId,
                text: text.slice(0, 3000),
                mrkdwn: true,
            });
        }
        catch (err) {
            this.log.error({ err }, 'Slack send error');
        }
    }
    isRunning() {
        return this._running;
    }
}
//# sourceMappingURL=index.js.map