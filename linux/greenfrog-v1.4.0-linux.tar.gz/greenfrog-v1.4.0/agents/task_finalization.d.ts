/**
 * Shared task-done finalization logic for GreenFrog P4.6.2.
 *
 * Both the worker loop done path (team.ts) and the heartbeat done path
 * (heartbeat.ts) must run the same evaluation + artifact detection pipeline
 * when a task transitions to `done`. This module provides a single shared
 * helper so the logic is never duplicated.
 *
 * Callers are responsible for writing the returned fields into the task
 * metadata update — this function performs no DB writes.
 */
import type { TeamTask } from '../utils/types.js';
import type { EvaluateResult } from './evaluate.js';
import type { TaskArtifact } from './artifact.js';
export interface TaskDoneEvaluation {
    /** Full evaluation result (pass/fail + all evidence fields) */
    evalResult: EvaluateResult;
    /** Merged artifact list — may be empty if nothing detected */
    artifacts: TaskArtifact[];
    /** Number of effective acceptance checks that were evaluated (0 if none) */
    effectiveChecksCount: number;
}
/**
 * Run artifact detection + acceptance evaluation for a completed task.
 *
 * Pure evaluation — no DB access, no side effects.
 * The caller merges the returned fields into its metadata update payload.
 *
 * @param task          The task record as it exists just before done write
 * @param resultSummary The agent's result text (may be null)
 * @param runId         The run ID for artifact provenance
 */
export declare function finalizeTaskDone(task: TeamTask, resultSummary: string | null, runId: string): Promise<TaskDoneEvaluation>;
//# sourceMappingURL=task_finalization.d.ts.map