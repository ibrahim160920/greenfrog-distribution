/**
 * auto_hard_evidence.ts — Sprint M5 + Federated Sprint
 *
 * Wires task verification results into two paths:
 *
 *   Path 1 (M5): Local hard evidence
 *     task workspace rules → findUnitsByPayload() → recordHardEvidence()
 *     Updates the local capability_units.json store.
 *
 *   Path 2 (Federated Sprint): Instance federated upload
 *     Same eligible events → buildFederatedEvidenceEntry() → appendToInstanceUploadBundle()
 *     Appends to the local instance_upload_bundle.json (bundleType: 'instance_upload').
 *     This bundle is the uplink artifact — it must NOT be directly imported by any instance.
 *     It can only enter another instance after passing through mother-body aggregation.
 *
 * Gate (all three required for both paths):
 *   1. evalResult.pass === true
 *   2. evalResult.verificationMode === 'evidence_verified'  (real I/O checks passed)
 *   3. evalResult.acceptanceChecksPassed > 0                (at least one check confirmed)
 *
 * Skip semantics: safe to call unconditionally — never throws.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createLogger } from '../utils/logger.js';
import { memoryStore } from '../memory/store.js';
import { findUnitsByPayload, recordHardEvidence } from './capability_unit.js';
import { buildFederatedEvidenceEntry, createInstanceUploadBundle, generateInstanceId, } from './federated_aggregate.js';
import { configManager } from '../config/index.js';
const log = createLogger('auto-hard-evidence');
// ── Gate check ────────────────────────────────────────────────────────────────
function isEligibleForHardEvidence(evalResult) {
    if (!evalResult.pass)
        return 'task_not_passed';
    if (evalResult.verificationMode !== 'evidence_verified')
        return 'not_evidence_verified';
    if ((evalResult.acceptanceChecksPassed ?? 0) <= 0)
        return 'no_checks_passed';
    return null;
}
// ── Instance upload bundle I/O ────────────────────────────────────────────────
function resolveInstanceUploadBundlePath() {
    const dataDir = configManager.get().dataDir;
    // Alongside the source-repo evolution artifacts
    return path.join(dataDir, '..', '.greenfrog', 'evolution', 'instance_upload_bundle.json');
}
/**
 * Append federated evidence entries to this instance's upload bundle.
 * Creates the bundle file (with correct bundleType: 'instance_upload' header) if it
 * does not yet exist. Safe to call repeatedly — idempotent per entry.
 *
 * The bundleType tag is the governance marker: any import path that calls
 * validateMotherApprovedBundle() will reject this file, ensuring it cannot
 * bypass the mother-body aggregation step.
 */
export async function appendToInstanceUploadBundle(entries) {
    if (entries.length === 0)
        return;
    const bundlePath = resolveInstanceUploadBundlePath();
    try {
        // Ensure directory exists
        fs.mkdirSync(path.dirname(bundlePath), { recursive: true });
        let bundle;
        if (fs.existsSync(bundlePath)) {
            const raw = fs.readFileSync(bundlePath, 'utf-8');
            const parsed = JSON.parse(raw);
            bundle = parsed;
        }
        else {
            const instanceId = await generateInstanceId();
            bundle = createInstanceUploadBundle(instanceId);
        }
        // Append new entries
        bundle.entries.push(...entries);
        bundle.exportedAt = new Date().toISOString();
        fs.writeFileSync(bundlePath, JSON.stringify(bundle, null, 2), 'utf-8');
        log.info({ entriesAdded: entries.length, totalEntries: bundle.entries.length, bundlePath }, 'auto-hard-evidence: appended to instance upload bundle');
    }
    catch (err) {
        log.warn({ err: String(err), bundlePath }, 'auto-hard-evidence: failed to append to instance upload bundle');
    }
}
// ── Main export ───────────────────────────────────────────────────────────────
/**
 * Attempt to record automated hard evidence for all capability units whose
 * payload matches a behavioral rule active in the task's workspace.
 *
 * Also appends eligible evidence to the local instance upload bundle for
 * future mother-body federated aggregation.
 *
 * Safe to call unconditionally — never throws.
 */
export async function recordAutoHardEvidenceForTask(task, evalResult, runId) {
    const notEligible = isEligibleForHardEvidence(evalResult);
    if (notEligible) {
        return { eligible: false, skipReason: notEligible, rulesChecked: 0, unitsMatched: 0, evidenceRecorded: 0, unitsAdvanced: 0, federatedUploadCount: 0 };
    }
    // Fetch behavioral rules for the task's workspace scope
    let rules = [];
    try {
        rules = await memoryStore.getScopedBehavioralRules({ userId: task.createdBy, channel: 'web', workspaceId: task.workspaceId }, 0);
    }
    catch (err) {
        log.warn({ err: String(err), taskId: task.id }, 'auto-hard-evidence: failed to fetch behavioral rules — skipping');
        return { eligible: true, skipReason: 'no_rules_found', rulesChecked: 0, unitsMatched: 0, evidenceRecorded: 0, unitsAdvanced: 0, federatedUploadCount: 0 };
    }
    if (rules.length === 0) {
        return { eligible: true, skipReason: 'no_rules_found', rulesChecked: 0, unitsMatched: 0, evidenceRecorded: 0, unitsAdvanced: 0, federatedUploadCount: 0 };
    }
    const sourceRef = `auto:task:${task.id}:${runId}`;
    const description = `Task verified: ${task.title.slice(0, 120)} ` +
        `[verificationMode=evidence_verified, checksPassed=${evalResult.acceptanceChecksPassed ?? 0}` +
        `${evalResult.acceptanceChecksTotal ? `/${evalResult.acceptanceChecksTotal}` : ''}]`;
    let unitsMatched = 0;
    let evidenceRecorded = 0;
    let unitsAdvanced = 0;
    const federatedEntries = [];
    const instanceId = await generateInstanceId();
    for (const r of rules) {
        // Exact payload match only — safe skip if no match
        const matchedUnits = findUnitsByPayload(r.rule);
        if (matchedUnits.length === 0)
            continue;
        unitsMatched += matchedUnits.length;
        for (const unit of matchedUnits) {
            // ── Path 1: Local hard evidence ────────────────────────────────────────
            try {
                const result = recordHardEvidence({
                    unitId: unit.id,
                    description,
                    sourceRef,
                    tryAdvance: true,
                });
                if (result.ok) {
                    evidenceRecorded++;
                    if (result.advanced)
                        unitsAdvanced++;
                }
                else {
                    log.debug({ unitId: unit.id, reason: result.reason, taskId: task.id }, 'auto-hard-evidence: recordHardEvidence rejected');
                }
            }
            catch (err) {
                log.warn({ err: String(err), unitId: unit.id, taskId: task.id }, 'auto-hard-evidence: unexpected error recording local evidence');
            }
            // ── Path 2: Federated upload entry ────────────────────────────────────
            // Build from the unit's current evidence strength after local recording
            const refreshedUnits = findUnitsByPayload(unit.payload);
            const refreshed = refreshedUnits.find(u => u.id === unit.id) ?? unit;
            const evidenceStrength = refreshed.evidenceStrength === 'placeholder' ? 'placeholder'
                : refreshed.evidenceStrength === 'hard' ? 'hard' : 'soft';
            if (evidenceStrength !== 'placeholder') {
                const entry = buildFederatedEvidenceEntry({
                    payload: unit.payload,
                    category: unit.category,
                    instanceId,
                    workspaceId: task.workspaceId,
                    channel: 'web',
                    evidenceStrength,
                    autoVerified: true, // gate already confirmed this is evidence_verified
                    humanConfirmed: false,
                    totalApplications: evalResult.acceptanceChecksPassed ?? 1,
                    successfulApplications: evalResult.acceptanceChecksPassed ?? 1,
                    sourceRef,
                });
                if (entry)
                    federatedEntries.push(entry);
            }
        }
    }
    if (unitsMatched === 0) {
        return { eligible: true, skipReason: 'no_units_matched', rulesChecked: rules.length, unitsMatched: 0, evidenceRecorded: 0, unitsAdvanced: 0, federatedUploadCount: 0 };
    }
    // Append federated entries to the instance upload bundle (non-blocking)
    if (federatedEntries.length > 0) {
        appendToInstanceUploadBundle(federatedEntries).catch(() => { });
    }
    log.info({
        taskId: task.id,
        runId,
        rulesChecked: rules.length,
        unitsMatched,
        evidenceRecorded,
        unitsAdvanced,
        federatedUploadCount: federatedEntries.length,
    }, 'auto-hard-evidence: recorded evidence from verified task');
    return { eligible: true, rulesChecked: rules.length, unitsMatched, evidenceRecorded, unitsAdvanced, federatedUploadCount: federatedEntries.length };
}
//# sourceMappingURL=auto_hard_evidence.js.map