import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
/**
 * audit — Admin-only skill for querying the persistent audit log.
 * Records every skill call: who, when, what skill, success/failure, duration.
 */
export declare class AuditSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private _formatRows;
}
//# sourceMappingURL=audit.d.ts.map