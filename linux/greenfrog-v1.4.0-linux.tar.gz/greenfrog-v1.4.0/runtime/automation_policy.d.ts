export interface ApprovalWindowPolicy {
    startHourUtc?: number;
    endHourUtc?: number;
    approvedWeekdaysUtc?: number[];
}
export interface ApprovalWindowEvaluation {
    allowed: boolean;
    currentHourUtc: number;
    currentWeekdayUtc: number;
    hourAllowed: boolean;
    weekdayAllowed: boolean;
    reason: string | null;
}
export interface HealthCheckPolicy {
    commands?: string[];
    minPassing?: number;
}
export interface HealthCheckResultItem {
    command: string;
    success: boolean;
    error: string | null;
}
export interface HealthCheckEvaluation {
    allowed: boolean;
    total: number;
    passed: number;
    required: number;
    results: HealthCheckResultItem[];
    reason: string | null;
}
export interface RolloutPolicy {
    percentage?: number;
    seed?: string;
}
export interface RolloutEvaluation {
    allowed: boolean;
    percentage: number;
    bucket: number;
    seed: string;
    reason: string | null;
}
export declare function evaluateApprovalWindow(policy?: ApprovalWindowPolicy, now?: Date): ApprovalWindowEvaluation;
export declare function evaluateHealthChecks(policy: HealthCheckPolicy | undefined, runCommand: (command: string) => void | Promise<void>): Promise<HealthCheckEvaluation>;
export declare function evaluateRollout(policy: RolloutPolicy | undefined, fallbackSeed: string): RolloutEvaluation;
//# sourceMappingURL=automation_policy.d.ts.map