/**
 * instance_identity.ts — Stable Persistent Instance Identity
 *
 * Replaces the hardware-fingerprint-based generateInstanceId() with a stable
 * identity that:
 *   1. Is generated once (random, not hardware-derived)
 *   2. Persisted to {dataDir}/instance_id.json
 *   3. Reused on every restart, upgrade, or process restart
 *   4. Does not expose sensitive machine information (no hostname, no MAC)
 *
 * Governance meaning of identity change:
 *   - If the instance_id.json file is deleted, a new identity is generated.
 *   - The mother-body will treat this as a NEW instance (evidence provenance
 *     will not be aggregated with the old identity's contributions).
 *   - This is intentional: identity reset = fresh start in the federation.
 *
 * Override:
 *   - GF_INSTANCE_ID_FILE — override path to instance_id.json
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createLogger } from '../utils/logger.js';
const log = createLogger('instance-identity');
// Version tag so we can detect format changes in the future
const CURRENT_VERSION = 1;
const ID_FILENAME = 'instance_id.json';
/**
 * Resolve the path to the instance ID file.
 * GF_INSTANCE_ID_FILE overrides the default location.
 */
export function resolveInstanceIdFilePath(dataDir) {
    const override = process.env['GF_INSTANCE_ID_FILE'];
    if (override)
        return override;
    return path.join(dataDir, ID_FILENAME);
}
/**
 * Read an existing instance ID record from disk.
 * Returns null if the file does not exist or is invalid.
 */
export function readInstanceIdRecord(dataDir) {
    const filePath = resolveInstanceIdFilePath(dataDir);
    try {
        if (!fs.existsSync(filePath))
            return null;
        const raw = fs.readFileSync(filePath, 'utf-8');
        const record = JSON.parse(raw);
        if (typeof record.instanceId === 'string' &&
            record.instanceId.startsWith('gf-') &&
            record.instanceId.length >= 10 &&
            record.version === CURRENT_VERSION) {
            return record;
        }
        log.warn({ filePath }, 'instance-identity: existing record is malformed — will regenerate');
        return null;
    }
    catch (err) {
        log.warn({ err: String(err), filePath }, 'instance-identity: failed to read instance ID file');
        return null;
    }
}
/**
 * Generate a new random instance ID and persist it to disk.
 * Idempotent if the file already exists and is valid — returns the existing ID.
 */
export function generateNewInstanceId(dataDir) {
    // Use crypto.randomBytes — not hardware-derived, not reversible, no sensitive info
    const instanceId = 'gf-' + crypto.randomBytes(16).toString('hex');
    const record = {
        instanceId,
        createdAt: new Date().toISOString(),
        version: CURRENT_VERSION,
    };
    const filePath = resolveInstanceIdFilePath(dataDir);
    try {
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        fs.writeFileSync(filePath, JSON.stringify(record, null, 2), 'utf-8');
        log.info({ instanceId, filePath }, 'instance-identity: generated new stable instance ID');
    }
    catch (err) {
        log.warn({ err: String(err), filePath }, 'instance-identity: failed to persist instance ID — using in-memory only');
    }
    return instanceId;
}
/**
 * Get or create the stable instance ID for this GreenFrog instance.
 *
 * - First call: generates a random ID and persists it to {dataDir}/instance_id.json
 * - Subsequent calls (same process OR after restart): reads from disk
 *
 * This is the canonical entry point for obtaining instance identity.
 * All federated evidence should use this ID.
 */
export function getOrCreateInstanceId(dataDir) {
    const existing = readInstanceIdRecord(dataDir);
    if (existing)
        return existing.instanceId;
    return generateNewInstanceId(dataDir);
}
// ── In-process cache ──────────────────────────────────────────────────────────
// After the first resolve, cache in memory to avoid repeated disk reads.
let _cachedInstanceId = null;
let _cachedDataDir = null;
/**
 * Cached variant — resolves once per process lifetime.
 * Safe to call from hot paths (e.g. per-task evidence recording).
 */
export function getCachedInstanceId(dataDir) {
    if (_cachedInstanceId && _cachedDataDir === dataDir) {
        return _cachedInstanceId;
    }
    _cachedInstanceId = getOrCreateInstanceId(dataDir);
    _cachedDataDir = dataDir;
    return _cachedInstanceId;
}
/**
 * Reset the in-process cache.
 * Used in tests to simulate process restarts with a fresh dataDir.
 */
export function resetInstanceIdCache() {
    _cachedInstanceId = null;
    _cachedDataDir = null;
}
//# sourceMappingURL=instance_identity.js.map