/**
 * Rule Usage Tracking System
 *
 * Tracks when and how behavioral rules are applied to provide data for quality scoring.
 */
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('rule-tracking');
// In-memory cache for per-request performance (write-through to SQLite)
const ruleApplicationCache = new Map();
/**
 * Track a rule application event.
 * Write-through: persists to SQLite immediately so stats survive restarts.
 * Also updates the in-memory cache for fast within-session reads.
 */
export async function trackRuleApplication(event) {
    const cacheKey = `${event.workspaceId}:${event.channel}`;
    if (!ruleApplicationCache.has(cacheKey)) {
        ruleApplicationCache.set(cacheKey, []);
    }
    const events = ruleApplicationCache.get(cacheKey);
    events.push(event);
    // Keep only last 10000 events per workspace to avoid memory issues
    if (events.length > 10000) {
        events.shift();
    }
    // Persist to SQLite — synchronous under the hood (better-sqlite3)
    try {
        await memoryStore.upsertRuleTrackingStat(event.workspaceId, event.channel, event.ruleId, event.success);
    }
    catch (err) {
        // Non-fatal: in-memory cache still has the event
        log.warn({ err: String(err), ruleId: event.ruleId }, 'Failed to persist rule tracking stat');
    }
    log.debug({
        ruleId: event.ruleId,
        success: event.success,
        workspaceId: event.workspaceId,
    }, 'Tracked rule application');
}
/**
 * Get usage statistics for a specific rule.
 * Reads from the durable SQLite store first, then merges with any in-memory
 * events not yet visible in the DB (same-request writes arrive here via cache).
 */
export async function getRuleUsageStats(ruleId, workspaceId, channel) {
    // Read durable stats from SQLite
    let persisted = null;
    try {
        persisted = await memoryStore.getPersistedRuleStats(workspaceId, channel, ruleId);
    }
    catch {
        // Store not yet ready in tests — fall through to cache-only
    }
    // In-memory events for same-session freshness
    const cacheKey = `${workspaceId}:${channel}`;
    const events = ruleApplicationCache.get(cacheKey) ?? [];
    const ruleEvents = events.filter(e => e.ruleId === ruleId);
    const totalApplications = persisted?.totalApplications ?? ruleEvents.length;
    const successfulApplications = persisted?.successfulApplications ?? ruleEvents.filter(e => e.success).length;
    const failedApplications = persisted?.failedApplications ?? ruleEvents.filter(e => !e.success).length;
    if (totalApplications === 0) {
        return {
            totalApplications: 0,
            successfulApplications: 0,
            failedApplications: 0,
            successRate: 0,
            lastUsedAt: null,
            firstUsedAt: null,
        };
    }
    const successRate = successfulApplications / totalApplications;
    const lastUsedAt = persisted?.lastUsedAt ?? (ruleEvents.length > 0
        ? ruleEvents.reduce((latest, e) => e.appliedAt > latest ? e.appliedAt : latest, ruleEvents[0].appliedAt)
        : null);
    const firstUsedAt = persisted?.createdAt ?? (ruleEvents.length > 0
        ? ruleEvents.reduce((earliest, e) => e.appliedAt < earliest ? e.appliedAt : earliest, ruleEvents[0].appliedAt)
        : null);
    return {
        totalApplications,
        successfulApplications,
        failedApplications,
        successRate,
        lastUsedAt,
        firstUsedAt,
    };
}
/**
 * Get usage statistics for all rules in a workspace.
 * Reads from durable SQLite store, which survives restarts.
 */
export async function getAllRuleUsageStats(workspaceId, channel) {
    // Primary: durable SQLite stats
    let persistedMap = new Map();
    try {
        const raw = await memoryStore.getAllPersistedRuleStats(workspaceId, channel);
        persistedMap = raw;
    }
    catch {
        // Store not yet ready — fall through to cache-only
    }
    const statsMap = new Map();
    // Populate from persisted stats
    for (const [ruleId, s] of persistedMap) {
        statsMap.set(ruleId, {
            totalApplications: s.totalApplications,
            successfulApplications: s.successfulApplications,
            failedApplications: s.failedApplications,
            successRate: s.totalApplications > 0 ? s.successfulApplications / s.totalApplications : 0,
            lastUsedAt: s.lastUsedAt,
        });
    }
    // Merge any same-session in-memory events not yet in DB (shouldn't happen with write-through, but safe fallback)
    const cacheKey = `${workspaceId}:${channel}`;
    const events = ruleApplicationCache.get(cacheKey) ?? [];
    const eventsByRule = new Map();
    for (const event of events) {
        if (!eventsByRule.has(event.ruleId))
            eventsByRule.set(event.ruleId, []);
        eventsByRule.get(event.ruleId).push(event);
    }
    for (const [ruleId, ruleEvents] of eventsByRule) {
        if (statsMap.has(ruleId))
            continue; // DB already has it
        const successfulApplications = ruleEvents.filter(e => e.success).length;
        const failedApplications = ruleEvents.filter(e => !e.success).length;
        const lastUsedAt = ruleEvents.reduce((latest, event) => event.appliedAt > latest ? event.appliedAt : latest, ruleEvents[0].appliedAt);
        statsMap.set(ruleId, {
            totalApplications: ruleEvents.length,
            successfulApplications,
            failedApplications,
            successRate: successfulApplications / ruleEvents.length,
            lastUsedAt,
        });
    }
    return statsMap;
}
export async function getRecentRuleValidationSamples(ruleId, opts) {
    const workspaceFilter = opts?.workspaceIds ? new Set(opts.workspaceIds) : null;
    const collected = [];
    for (const events of ruleApplicationCache.values()) {
        for (const event of events) {
            if (event.ruleId !== ruleId)
                continue;
            if (workspaceFilter && !workspaceFilter.has(event.workspaceId))
                continue;
            collected.push({
                workspaceId: event.workspaceId,
                channel: event.channel,
                userId: event.userId,
                appliedAt: event.appliedAt,
                success: event.success,
                ...(event.context ? { context: event.context } : {}),
                ...(event.errorMessage ? { errorMessage: event.errorMessage } : {}),
            });
        }
    }
    collected.sort((a, b) => b.appliedAt.getTime() - a.appliedAt.getTime());
    return collected.slice(0, Math.max(1, opts?.limit ?? 5));
}
export async function getAggregatedRuleValidationStats(ruleId, opts) {
    const samples = await getRecentRuleValidationSamples(ruleId, {
        workspaceIds: opts?.workspaceIds,
        limit: opts?.sampleLimit ?? 5,
    });
    const workspaceFilter = opts?.workspaceIds ? new Set(opts.workspaceIds) : null;
    let totalApplications = 0;
    let successfulApplications = 0;
    let failedApplications = 0;
    for (const events of ruleApplicationCache.values()) {
        for (const event of events) {
            if (event.ruleId !== ruleId)
                continue;
            if (workspaceFilter && !workspaceFilter.has(event.workspaceId))
                continue;
            totalApplications += 1;
            if (event.success) {
                successfulApplications += 1;
            }
            else {
                failedApplications += 1;
            }
        }
    }
    return {
        totalApplications,
        successfulApplications,
        failedApplications,
        successRate: totalApplications > 0 ? successfulApplications / totalApplications : null,
        recentSamples: samples,
    };
}
/**
 * Clear old tracking data (for memory management)
 */
export async function clearOldTrackingData(olderThanDays = 90) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);
    let totalCleared = 0;
    for (const [cacheKey, events] of ruleApplicationCache) {
        const originalLength = events.length;
        const filtered = events.filter(e => e.appliedAt >= cutoffDate);
        ruleApplicationCache.set(cacheKey, filtered);
        totalCleared += originalLength - filtered.length;
    }
    log.info({ totalCleared, olderThanDays }, 'Cleared old tracking data');
    return totalCleared;
}
/**
 * Get tracking statistics summary
 */
export async function getTrackingStatsSummary() {
    let totalEvents = 0;
    let oldestEvent = null;
    let newestEvent = null;
    for (const events of ruleApplicationCache.values()) {
        totalEvents += events.length;
        for (const event of events) {
            if (!oldestEvent || event.appliedAt < oldestEvent) {
                oldestEvent = event.appliedAt;
            }
            if (!newestEvent || event.appliedAt > newestEvent) {
                newestEvent = event.appliedAt;
            }
        }
    }
    return {
        totalEvents,
        totalWorkspaces: ruleApplicationCache.size,
        oldestEvent,
        newestEvent,
    };
}
export function resetRuleTrackingForTests() {
    ruleApplicationCache.clear();
}
//# sourceMappingURL=rule_tracking.js.map