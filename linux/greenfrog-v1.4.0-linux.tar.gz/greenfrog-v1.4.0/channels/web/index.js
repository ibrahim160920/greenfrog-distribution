import express from 'express';
import { createServer as createHttpServer } from 'http';
import { createServer as createHttpsServer } from 'https';
import { fileURLToPath } from 'url';
import { dirname, isAbsolute, join, resolve } from 'path';
import { createHash, createHmac, timingSafeEqual } from 'crypto';
import { spawnSync } from 'child_process';
import { readFileSync, readdirSync, statSync, writeFileSync, unlinkSync, existsSync, mkdirSync } from 'fs';
import { WebSocketServer, WebSocket } from 'ws';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { config, configManager } from '../../config/index.js';
import { stripMaskedFields } from '../../utils/config_helpers.js';
import helmet from 'helmet';
import { skillRegistry } from '../../skills/registry.js';
import { providerRegistry } from '../../providers/index.js';
import { vetCode } from '../../skills/vetter.js';
import { getMarketplacePlugins, getMarketplacePlugin, searchMarketplacePlugins } from '../../marketplace/index.js';
import { getSubscriptionTiers, getSubscriptionTier, checkTierLimits } from '../../billing/index.js';
import { buildDefaultTeamPolicy, claimTeamTaskById, deliverTeamNotification, dispatchTeamTaskById, instantiateTeamTemplateById, instantiateTeamTopologyById, isTeamSharedMemoryMetaKey, parseTeamTemplateVariableDefinitions, parseTeamTemplateVariableValues, raiseTeamTaskChallengeById, rollbackTeamSharedMemoryEntry, retrySharedMemoryGovernanceTaskById, requestTeamTaskConsensusById, doesNotificationRouteMatch, resolveApprovalEscalationRecipient, resolveTeamApprovalById, writeTeamSharedMemoryEntry, } from '../../skills/team.js';
import { agent } from '../../agents/agent.js';
import { computeStrategyTrackSwarmMetrics, computeSwarmMetrics, parseAdaptiveOrchestratorPolicy, parseOrchestratorRules } from '../../agents/orchestrator.js';
import { deriveVerdict } from '../../agents/verdict.js';
import { memoryStore } from '../../memory/store.js';
import { register as metricsRegister, httpMetricsMiddleware, wsClients, messagesTotal } from '../../metrics/index.js';
import { appendCandidateRolloutAuditEvent, buildPromoteCandidateStrategyUpdates, findTeamTopologyStrategySnapshot, parseAdaptiveModelPolicyInput, parseTeamTopologyCandidateRolloutControl, parseTeamTopologyCandidateStrategy, parseTeamTopologyCandidateRolloutPolicy, parseTeamTopologyModelRoutes, resolveTeamTopologyModelRoute, } from '../../utils/team_topology.js';
import { isQueueEnabled, enqueueMessage, getJobResult, getQueue, onJobResult } from '../../queue/index.js';
import { initAuth, handleLogin, handleCallback, handleLogout, handleLogoutAll, handleUserinfo, requireAuthMiddleware, } from '../../auth/index.js';
import { canAccessUserScope, isAdminUser } from '../../auth/access.js';
import { acquireAgentExecutionLease, getAgentRuntimeOverview, getAgentRuntimeSnapshot } from '../../runtime/agent_runtime_guard.js';
import { cancelAgentRun, getActiveAgentRunsOverview, getAgentRun, startAgentRun } from '../../runtime/agent_run_control.js';
import { getQuotaReservationOverview } from '../../providers/index.js';
import { getBehavioralRuleMaintenanceOverview } from '../../memory/rule_maintenance.js';
import { getEmbeddingRuntimeOverview } from '../../memory/embedding.js';
import { buildProjectEvolutionStatus } from '../../memory/evolution_status.js';
import { resolveProjectEvolutionMode, getProjectEvolutionCapabilities } from '../../memory/evolution_mode.js';
import { runProjectEvolutionGateMonitor } from '../../memory/project_evolution_gate_monitor.js';
import { recordProjectEvolutionRecoverySignalWithPolicy } from '../../memory/project_evolution_recovery_signal_policy.js';
import { buildProjectEvolutionAdminActionFingerprint, classifyProjectEvolutionAdminActionResult, evaluateProjectEvolutionAdminActionSafety, readProjectEvolutionAdminActionLog, recordProjectEvolutionAdminActionOutcome, } from '../../memory/project_evolution_admin_actions.js';
import { emitProjectEvolutionAdminActionNotification } from '../../memory/project_evolution_admin_action_notifications.js';
import { generateProjectRelease } from '../../release/project_release.js';
import { checkForProjectUpgrade } from '../../runtime/project_upgrade.js';
import { RuntimeLimitError } from '../../utils/errors.js';
import { isValidRoleGroupId, normalizeExternalGroups, normalizeRoleGroupMembers, resolveRoleFromConfig, } from '../../authz/roles.js';
import { extractionQueue } from '../../memory/extraction_queue.js';
import { buildMotherBodyStatus } from '../../memory/mother_body_status.js';
import { uplinkToMotherRepo, runMotherAggregation, downlinkFromMotherRepo, listContradictionRecords, reviewContradictionRecord, getMotherRepoStatus, resolveConfiguredMotherRepoPath, resolveMotherRepoDirs, } from '../../memory/mother_repo.js';
import { tryValidateMotherApprovedBundle } from '../../memory/federated_aggregate.js';
import { startMotherRepoScheduler, stopMotherRepoScheduler, getMotherRepoSchedulerState, } from '../../memory/mother_repo_scheduler.js';
import { listKernelCandidates, promoteKernelCandidate, rejectKernelCandidate, expireStaleKernelCandidates, } from '../../memory/owner_kernel.js';
import { getCapabilityUnit, listCapabilityUnits, recordHardEvidence, advanceCapabilityUnit, } from '../../memory/capability_unit.js';
import { getTrace, getTraceByRunId, getRecentTraces, getTraceStatistics, } from '../../runtime/execution_trace.js';
import { getHeartbeats } from '../../runtime/agent_heartbeat.js';
import { getWorkflowRunsForWorkflow, getAllWorkflowRuns, getJobRunsForJob, getAllJobRuns, } from '../../runtime/run_records.js';
import { handleEnroll, handleBackflow, handleInheritanceLatest, handleInheritanceById, handleRevoke, makeChildAuthMiddleware, } from '../../distribution/server/index.js';
import { getEnrollmentState } from '../../distribution/identity/first_boot.js';
import { readInstallRecord } from '../../distribution/identity/enrollment.js';
import { readInheritanceConfig } from '../../distribution/inheritance/client.js';
import { queueDepth } from '../../distribution/backflow/queue.js';
import { loadCredential } from '../../distribution/identity/credential.js';
const RATE_LIMIT = 60;
const RATE_WINDOW_MS = 60_000;
const LONG_RUNNING_TASK_AGE_MS = 4 * 60 * 60 * 1000;
// Auth rate limit: max attempts per 15 minutes per IP (brute-force protection)
// 300 allows normal API usage while still blocking automated brute-force attacks
const AUTH_RATE_LIMIT = 300;
const AUTH_RATE_WINDOW_MS = 15 * 60_000;
// Module-level server start time — used for systemHealth in /api/status
const _serverStartedAt = Date.now();
// ── Express middlewares ───────────────────────────────────────────────────────
async function rateLimitMiddleware(req, res, next) {
    const ip = (req.ip ?? req.socket.remoteAddress ?? '127.0.0.1');
    // Use persistent SQLite-backed rate limiter so limits survive restarts
    if (!await memoryStore.checkRateLimit(`web:${ip}`, RATE_LIMIT, RATE_WINDOW_MS)) {
        res.status(429).json({ error: 'Rate limit exceeded. Try again in a minute.' });
        return;
    }
    next();
}
async function requireAuth(req, res, next) {
    const ip = req.ip ?? req.socket.remoteAddress ?? '127.0.0.1';
    // Strict per-IP rate limit for auth attempts to prevent brute-force
    if (!await memoryStore.checkRateLimit(`auth:${ip}`, AUTH_RATE_LIMIT, AUTH_RATE_WINDOW_MS)) {
        res.status(429).json({ error: 'Too many authentication attempts. Try again in 15 minutes.' });
        return;
    }
    // Delegate to unified auth middleware (supports JWT/OIDC + legacy Bearer)
    return requireAuthMiddleware(req, res, next);
}
function requireAdminAccess(req, res, next) {
    if (!isAdminUser(req.authUser)) {
        res.status(403).json({ error: 'Admin role required' });
        return;
    }
    next();
}
function requireSelfOrAdmin(req, res, next) {
    const targetUserId = String(req.params.userId ?? '');
    if (canAccessUserScope(req.authUser, targetUserId)) {
        next();
        return;
    }
    res.status(403).json({ error: 'Forbidden: you can only access your own data.' });
}
function getScopedUserId(req) {
    return isAdminUser(req.authUser) ? undefined : req.authUser?.sub;
}
function getAdminActor(req) {
    return {
        userId: req.authUser?.sub ?? '[admin]',
        role: req.authUser?.role,
    };
}
function logAdminAudit(req, skillName, params, success = true, error) {
    const actor = getAdminActor(req);
    memoryStore.logAudit({
        userId: actor.userId,
        channel: 'web',
        chatId: req.authUser?.sub,
        skillName,
        params,
        success,
        durationMs: 0,
        error,
        role: actor.role,
    });
}
function resolveEvolutionRepoPath(candidate) {
    if (!candidate || !candidate.trim())
        return null;
    return isAbsolute(candidate) ? candidate : resolve(process.cwd(), candidate);
}
function resolveEvolutionGitBranch(repoPath) {
    if (!repoPath)
        return null;
    const result = spawnSync('git', ['symbolic-ref', '--quiet', '--short', 'HEAD'], {
        cwd: repoPath,
        encoding: 'utf8',
        timeout: 10_000,
        stdio: ['ignore', 'pipe', 'pipe'],
    });
    if (result.error || result.status !== 0)
        return null;
    return (result.stdout ?? '').trim() || null;
}
function readEvolutionJsonArtifact(repoPath, artifactPath) {
    if (!repoPath)
        return null;
    const filePath = resolve(repoPath, artifactPath);
    if (!existsSync(filePath))
        return null;
    try {
        return JSON.parse(readFileSync(filePath, 'utf8'));
    }
    catch {
        return null;
    }
}
function resolveProjectEvolutionWebConfigs(cfg) {
    const mode = resolveProjectEvolutionMode(cfg.evolution);
    const caps = getProjectEvolutionCapabilities(mode);
    const sourceRepo = cfg.evolution?.sourceRepo;
    const codeRepo = cfg.evolution?.codeRepo;
    const release = cfg.evolution?.release;
    const upgrade = cfg.evolution?.upgrade;
    return {
        sourceRepoConfig: {
            enabled: caps.allowLocalArtifacts && Boolean(sourceRepo?.enabled),
            repoPath: resolveEvolutionRepoPath(sourceRepo?.repoPath),
            autoCommit: caps.allowSourceRepoMutation ? (sourceRepo?.autoCommit ?? false) : false,
            autoPush: caps.allowSourceRepoMutation ? (sourceRepo?.autoPush ?? false) : false,
            createPullRequest: caps.allowSourceRepoMutation ? (sourceRepo?.createPullRequest ?? false) : false,
        },
        codeRepoConfig: {
            enabled: caps.allowLocalArtifacts && Boolean(codeRepo?.enabled),
            repoPath: resolveEvolutionRepoPath(codeRepo?.repoPath),
            autoApplyPatch: caps.allowSourceRepoMutation ? (codeRepo?.autoApplyPatch ?? false) : false,
            autoCommit: caps.allowSourceRepoMutation ? (codeRepo?.autoCommit ?? false) : false,
            autoPush: caps.allowSourceRepoMutation ? (codeRepo?.autoPush ?? false) : false,
            createPullRequest: caps.allowSourceRepoMutation ? (codeRepo?.createPullRequest ?? false) : false,
        },
        releaseConfig: {
            enabled: caps.allowReleaseAutomation && Boolean(release?.enabled),
            repoPath: resolveEvolutionRepoPath(release?.repoPath) ?? process.cwd(),
            manifestPath: release?.manifestPath ?? '.greenfrog/releases/latest.json',
            notesPath: release?.notesPath ?? '.greenfrog/releases/RELEASE_NOTES.md',
            bump: release?.bump ?? 'patch',
            approvalWindowStartHourUtc: release?.approvalWindowStartHourUtc,
            approvalWindowEndHourUtc: release?.approvalWindowEndHourUtc,
            approvedWeekdaysUtc: release?.approvedWeekdaysUtc,
            healthCheckCommands: release?.healthCheckCommands ?? [],
            minHealthChecksPassing: release?.minHealthChecksPassing ?? 0,
            autoCommit: caps.allowReleaseAutomation ? (release?.autoCommit ?? false) : false,
            autoPush: caps.allowReleaseAutomation ? (release?.autoPush ?? false) : false,
            autoTag: caps.allowReleaseAutomation ? (release?.autoTag ?? false) : false,
            createGithubRelease: caps.allowReleaseAutomation ? (release?.createGithubRelease ?? false) : false,
            remote: release?.remote ?? 'origin',
            repo: release?.repo,
            baseBranch: release?.baseBranch ?? 'main',
            githubToken: cfg.skills.github?.token,
            releaseTitle: release?.releaseTitle ?? 'GreenFrog automated release',
            branchPrefix: release?.branchPrefix ?? 'greenfrog-evolution',
            commitMessage: release?.commitMessage ?? 'chore(release): publish automated release metadata',
            tagPrefix: release?.tagPrefix ?? 'v',
            respectAutomationPolicies: true,
        },
        upgradeConfig: {
            enabled: caps.allowUpgradeAutomation && Boolean(upgrade?.enabled),
            repoPath: resolveEvolutionRepoPath(upgrade?.repoPath) ?? process.cwd(),
            manifestPath: upgrade?.manifestPath ?? '.greenfrog/releases/latest.json',
            remote: upgrade?.remote ?? 'origin',
            baseBranch: upgrade?.baseBranch ?? 'main',
            autoApply: caps.allowUpgradeAutomation ? (upgrade?.autoApply ?? false) : false,
            requireCleanWorkingTree: upgrade?.requireCleanWorkingTree ?? true,
            installCommand: upgrade?.installCommand,
            buildCommand: upgrade?.buildCommand,
            restartOnApply: upgrade?.restartOnApply ?? true,
            approvalWindowStartHourUtc: upgrade?.approvalWindowStartHourUtc,
            approvalWindowEndHourUtc: upgrade?.approvalWindowEndHourUtc,
            approvedWeekdaysUtc: upgrade?.approvedWeekdaysUtc,
            rolloutPercentage: upgrade?.rolloutPercentage ?? 100,
            rolloutSeed: upgrade?.rolloutSeed,
            healthCheckCommands: upgrade?.healthCheckCommands ?? [],
            minHealthChecksPassing: upgrade?.minHealthChecksPassing ?? 0,
            verificationCommands: upgrade?.verificationCommands ?? [],
            minVerificationChecksPassing: upgrade?.minVerificationChecksPassing ?? 0,
            autoRollbackOnVerificationFailure: upgrade?.autoRollbackOnVerificationFailure ?? false,
            respectAutomationPolicies: true,
        },
    };
}
function rerunProjectEvolutionGateMonitor(cfg) {
    const runtime = resolveProjectEvolutionWebConfigs(cfg);
    return runProjectEvolutionGateMonitor({
        sourceRuleMutation: runtime.sourceRepoConfig.repoPath ? {
            enabled: runtime.sourceRepoConfig.enabled,
            repoPath: runtime.sourceRepoConfig.repoPath,
            branch: resolveEvolutionGitBranch(runtime.sourceRepoConfig.repoPath),
            requireAutomation: Boolean(runtime.sourceRepoConfig.autoCommit || runtime.sourceRepoConfig.autoPush || runtime.sourceRepoConfig.createPullRequest),
        } : undefined,
        sourceCodeMutation: runtime.codeRepoConfig.repoPath ? {
            enabled: runtime.codeRepoConfig.enabled,
            repoPath: runtime.codeRepoConfig.repoPath,
            branch: resolveEvolutionGitBranch(runtime.codeRepoConfig.repoPath),
            requireAutomation: Boolean(runtime.codeRepoConfig.autoApplyPatch || runtime.codeRepoConfig.autoCommit || runtime.codeRepoConfig.autoPush || runtime.codeRepoConfig.createPullRequest),
        } : undefined,
        release: runtime.releaseConfig.repoPath ? {
            enabled: runtime.releaseConfig.enabled,
            repoPath: runtime.releaseConfig.repoPath,
            branch: resolveEvolutionGitBranch(runtime.releaseConfig.repoPath),
            respectAutomationPolicies: runtime.releaseConfig.respectAutomationPolicies !== false,
        } : undefined,
        upgrade: runtime.upgradeConfig.repoPath ? {
            enabled: runtime.upgradeConfig.enabled,
            repoPath: runtime.upgradeConfig.repoPath,
            branch: resolveEvolutionGitBranch(runtime.upgradeConfig.repoPath),
            respectAutomationPolicies: runtime.upgradeConfig.respectAutomationPolicies !== false,
            manifest: readEvolutionJsonArtifact(runtime.upgradeConfig.repoPath, runtime.upgradeConfig.manifestPath),
        } : undefined,
    });
}
function summarizeTopologyAuditParams(topology) {
    return {
        topologyId: topology.id,
        workspaceId: topology.workspaceId,
        topologyName: topology.name,
        strategyVersion: topology.strategyVersion ?? 1,
    };
}
function getControlPlaneReason(body) {
    return typeof body['reason'] === 'string' && body['reason'].trim()
        ? body['reason'].trim()
        : null;
}
function buildTopologyControlPhrase(action, topology, extra) {
    const suffix = extra ? ` ${extra}` : '';
    return `${action.toUpperCase()} ${topology.id}${suffix}`;
}
function requireTopologyControlConfirmation(params) {
    const reason = getControlPlaneReason(params.body);
    const confirmationText = typeof params.body['confirmationText'] === 'string' && params.body['confirmationText'].trim()
        ? params.body['confirmationText'].trim()
        : null;
    const needsConfirmation = params.risk === 'high' || params.risk === 'critical';
    const expectedPhrase = params.confirmationPhrase ?? buildTopologyControlPhrase(params.action, params.topology);
    if ((params.requiredReason || params.risk !== 'low') && !reason) {
        logAdminAudit(params.req, `admin.team_topology.${params.action}`, {
            ...summarizeTopologyAuditParams(params.topology),
            riskLevel: params.risk,
            confirmationRequired: needsConfirmation,
        }, false, 'reason is required');
        params.res.status(400).json({ error: 'reason is required', requiredReason: true, riskLevel: params.risk, expectedConfirmation: needsConfirmation ? expectedPhrase : null });
        return { ok: false };
    }
    if (needsConfirmation && confirmationText !== expectedPhrase) {
        logAdminAudit(params.req, `admin.team_topology.${params.action}`, {
            ...summarizeTopologyAuditParams(params.topology),
            riskLevel: params.risk,
            confirmationRequired: true,
        }, false, 'confirmationText mismatch');
        params.res.status(400).json({
            error: 'confirmationText mismatch',
            riskLevel: params.risk,
            expectedConfirmation: expectedPhrase,
        });
        return { ok: false };
    }
    return { ok: true, reason, confirmationText };
}
function buildTopologyControlRequirements(topology) {
    return {
        promoteStrategy: {
            riskLevel: 'high',
            expectedConfirmation: buildTopologyControlPhrase('promote-strategy', topology),
            requiresReason: true,
        },
        promoteCandidate: {
            riskLevel: 'high',
            expectedConfirmation: buildTopologyControlPhrase('promote-candidate', topology),
            requiresReason: true,
        },
        candidateRolloutFreeze: {
            riskLevel: 'medium',
            expectedConfirmation: null,
            requiresReason: true,
        },
        candidateRolloutDisable: {
            riskLevel: 'high',
            expectedConfirmation: buildTopologyControlPhrase('disable-rollout', topology),
            requiresReason: true,
        },
        orchestratorFreeze: {
            riskLevel: 'medium',
            expectedConfirmation: null,
            requiresReason: true,
        },
        rollbackStrategy: {
            riskLevel: 'critical',
            expectedConfirmationPrefix: buildTopologyControlPhrase('rollback', topology),
            requiresReason: true,
        },
        deleteTopology: {
            riskLevel: 'critical',
            expectedConfirmation: buildTopologyControlPhrase('delete', topology),
            requiresReason: true,
        },
    };
}
function normalizeStringList(value) {
    const source = Array.isArray(value)
        ? value
        : (typeof value === 'string' && value.trim()
            ? value.split(',')
            : null);
    if (!source)
        return [];
    const seen = new Set();
    const normalized = [];
    for (const item of source) {
        if (typeof item !== 'string')
            return null;
        const trimmed = item.trim();
        if (!trimmed || seen.has(trimmed))
            continue;
        seen.add(trimmed);
        normalized.push(trimmed);
    }
    return normalized;
}
function normalizeRoleGroupIdList(value) {
    const normalized = normalizeStringList(value);
    if (normalized === null)
        return null;
    for (const groupId of normalized) {
        if (!isValidRoleGroupId(groupId))
            return null;
    }
    return normalized;
}
function normalizePositiveIntegerOrNull(value) {
    if (value === null)
        return null;
    if (value === undefined || value === '')
        return null;
    const parsed = Number(value);
    if (!Number.isFinite(parsed))
        return null;
    return Math.max(1, Math.floor(parsed));
}
function parseTopologyControlEscalationLevel(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const source = raw;
    const approverUserIds = normalizeStringList(source['approverUserIds'] ?? source['approvers']);
    const approverRoleGroups = normalizeRoleGroupIdList(source['approverRoleGroups'] ?? source['approverGroups']);
    if (!approverUserIds || !approverRoleGroups)
        return null;
    if (approverUserIds.length === 0 && approverRoleGroups.length === 0)
        return null;
    const reminderAfterMinutes = normalizePositiveIntegerOrNull(source['reminderAfterMinutes']);
    const escalationAfterMinutes = normalizePositiveIntegerOrNull(source['escalationAfterMinutes']);
    return {
        approverUserIds,
        approverRoleGroups,
        ...(reminderAfterMinutes !== null ? { reminderAfterMinutes } : {}),
        ...(escalationAfterMinutes !== null ? { escalationAfterMinutes } : {}),
        ...(typeof source['label'] === 'string' && source['label'].trim() ? { label: source['label'].trim().slice(0, 80) } : {}),
    };
}
function parseTopologyControlEscalationChain(value) {
    if (value === undefined)
        return [];
    if (!Array.isArray(value))
        return null;
    const parsed = [];
    for (const entry of value) {
        const normalized = parseTopologyControlEscalationLevel(entry);
        if (!normalized)
            return null;
        parsed.push(normalized);
    }
    return parsed;
}
function parseTopologyControlAccessScope(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const source = raw;
    const requesterUserIds = normalizeStringList(source['requesterUserIds'] ?? source['requesters']);
    const requesterRoleGroups = normalizeRoleGroupIdList(source['requesterRoleGroups'] ?? source['requesterGroups']);
    const approverUserIds = normalizeStringList(source['approverUserIds'] ?? source['approvers']);
    const approverRoleGroups = normalizeRoleGroupIdList(source['approverRoleGroups'] ?? source['approverGroups']);
    const escalationChain = parseTopologyControlEscalationChain(source['escalationChain']);
    if (!requesterUserIds || !requesterRoleGroups || !approverUserIds || !approverRoleGroups || escalationChain === null)
        return null;
    return {
        requesterUserIds,
        requesterRoleGroups,
        approverUserIds,
        approverRoleGroups,
        escalationChain,
    };
}
function parseTopologyControlAccessScopeOverride(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const source = raw;
    const requesterUserIds = Object.prototype.hasOwnProperty.call(source, 'requesterUserIds') || Object.prototype.hasOwnProperty.call(source, 'requesters')
        ? normalizeStringList(source['requesterUserIds'] ?? source['requesters'])
        : undefined;
    const requesterRoleGroups = Object.prototype.hasOwnProperty.call(source, 'requesterRoleGroups') || Object.prototype.hasOwnProperty.call(source, 'requesterGroups')
        ? normalizeRoleGroupIdList(source['requesterRoleGroups'] ?? source['requesterGroups'])
        : undefined;
    const approverUserIds = Object.prototype.hasOwnProperty.call(source, 'approverUserIds') || Object.prototype.hasOwnProperty.call(source, 'approvers')
        ? normalizeStringList(source['approverUserIds'] ?? source['approvers'])
        : undefined;
    const approverRoleGroups = Object.prototype.hasOwnProperty.call(source, 'approverRoleGroups') || Object.prototype.hasOwnProperty.call(source, 'approverGroups')
        ? normalizeRoleGroupIdList(source['approverRoleGroups'] ?? source['approverGroups'])
        : undefined;
    const escalationChain = Object.prototype.hasOwnProperty.call(source, 'escalationChain')
        ? parseTopologyControlEscalationChain(source['escalationChain'])
        : undefined;
    if (requesterUserIds === null || requesterRoleGroups === null || approverUserIds === null || approverRoleGroups === null || escalationChain === null)
        return null;
    return {
        ...(requesterUserIds !== undefined ? { requesterUserIds } : {}),
        ...(requesterRoleGroups !== undefined ? { requesterRoleGroups } : {}),
        ...(approverUserIds !== undefined ? { approverUserIds } : {}),
        ...(approverRoleGroups !== undefined ? { approverRoleGroups } : {}),
        ...(escalationChain !== undefined ? { escalationChain } : {}),
    };
}
function parseTopologyControlAccessPolicy(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const source = raw;
    const defaultScope = parseTopologyControlAccessScope(source['default'] ?? source);
    if (!defaultScope)
        return null;
    const rawActions = source['actions'];
    const actions = {};
    const allowedActionKeys = [
        'promote_strategy',
        'promote_candidate',
        'candidate_rollout_disable',
        'candidate_rollout_freeze',
        'orchestrator_control',
        'rollback_strategy',
        'delete_topology',
    ];
    if (rawActions !== undefined) {
        if (!rawActions || typeof rawActions !== 'object' || Array.isArray(rawActions))
            return null;
        for (const [actionKey, actionValue] of Object.entries(rawActions)) {
            if (!allowedActionKeys.includes(actionKey))
                return null;
            const parsedOverride = parseTopologyControlAccessScopeOverride(actionValue);
            if (!parsedOverride)
                return null;
            actions[actionKey] = parsedOverride;
        }
    }
    return {
        default: defaultScope,
        actions,
    };
}
function buildEmptyTopologyControlAccessPolicy() {
    return {
        default: {
            requesterUserIds: [],
            requesterRoleGroups: [],
            approverUserIds: [],
            approverRoleGroups: [],
            escalationChain: [],
        },
        actions: {},
    };
}
function getTopologyControlAccessPolicy(topology) {
    const parsed = parseTopologyControlAccessPolicy(topology.metadata?.['controlAccessPolicy']);
    return parsed ?? buildEmptyTopologyControlAccessPolicy();
}
function resolveTopologyControlActionScope(policy, action) {
    if (action === 'default')
        return policy.default;
    const override = policy.actions[action] ?? {};
    return {
        requesterUserIds: override.requesterUserIds ?? policy.default.requesterUserIds,
        requesterRoleGroups: override.requesterRoleGroups ?? policy.default.requesterRoleGroups,
        approverUserIds: override.approverUserIds ?? policy.default.approverUserIds,
        approverRoleGroups: override.approverRoleGroups ?? policy.default.approverRoleGroups,
        escalationChain: override.escalationChain ?? policy.default.escalationChain,
    };
}
function getWebUserIdsForRoleGroups(groupIds) {
    const groups = configManager.get().roles?.groups ?? {};
    const userIds = [];
    const seen = new Set();
    for (const groupId of groupIds) {
        const group = groups[groupId];
        if (!group)
            continue;
        for (const member of group.members ?? []) {
            const normalized = typeof member === 'string' ? member.trim() : '';
            if (!normalized)
                continue;
            const userId = normalized.startsWith('web:')
                ? normalized.slice(4)
                : (normalized.includes(':') ? '' : normalized);
            if (!userId || seen.has(userId))
                continue;
            seen.add(userId);
            userIds.push(userId);
        }
    }
    return userIds;
}
function resolveTopologyControlEscalationChain(escalationChain, fallbackApproverUserId) {
    return escalationChain.map((level, index) => {
        const effectiveApproverUserIds = Array.from(new Set([
            ...level.approverUserIds,
            ...getWebUserIdsForRoleGroups(level.approverRoleGroups),
        ].filter((value) => typeof value === 'string' && value.trim().length > 0)));
        if (effectiveApproverUserIds.length === 0 && fallbackApproverUserId) {
            effectiveApproverUserIds.push(fallbackApproverUserId);
        }
        return {
            ...level,
            level: index + 1,
            effectiveApproverUserIds,
            primaryApproverUserId: effectiveApproverUserIds[0] ?? fallbackApproverUserId ?? null,
        };
    });
}
function buildApprovalRoutingLevelsMetadata(params) {
    return {
        approvalRoutingLevels: [
            {
                level: 0,
                label: 'initial',
                approverUserIds: params.approverUserIds,
                approverRoleGroups: params.approverRoleGroups,
                effectiveApproverUserIds: params.effectiveApproverUserIds,
                primaryApproverUserId: params.primaryApproverUserId,
                reminderAfterMinutes: null,
                escalationAfterMinutes: null,
            },
            ...params.escalationChain.map((level) => ({
                level: level.level,
                label: level.label ?? null,
                approverUserIds: level.approverUserIds,
                approverRoleGroups: level.approverRoleGroups,
                effectiveApproverUserIds: level.effectiveApproverUserIds,
                primaryApproverUserId: level.primaryApproverUserId,
                reminderAfterMinutes: level.reminderAfterMinutes ?? null,
                escalationAfterMinutes: level.escalationAfterMinutes ?? null,
            })),
        ],
        approvalCurrentLevelIndex: 0,
        approvalCurrentLevelStartedAt: new Date().toISOString(),
    };
}
function getMatchingRoleGroups(userId, externalGroups) {
    const principals = [`web:${userId}`, userId];
    const normalizedExternalGroups = new Set(normalizeExternalGroups(externalGroups ?? []));
    return Object.entries(configManager.get().roles?.groups ?? {})
        .filter(([, group]) => {
        const memberMatch = principals.some((principal) => group.members.includes(principal));
        const externalMatch = Array.isArray(group.externalGroups)
            && group.externalGroups.some((groupId) => normalizedExternalGroups.has(groupId));
        return memberMatch || externalMatch;
    })
        .map(([id]) => id)
        .sort((a, b) => a.localeCompare(b));
}
function matchesTopologyControlScope(actorUserId, actorRoleGroups, scope) {
    if (actorUserId) {
        if ('requesterUserIds' in scope && scope.requesterUserIds.includes(actorUserId))
            return true;
        if ('approverUserIds' in scope && scope.approverUserIds.includes(actorUserId))
            return true;
    }
    const allowedGroups = 'requesterRoleGroups' in scope ? scope.requesterRoleGroups : scope.approverRoleGroups;
    return allowedGroups.some((groupId) => actorRoleGroups.includes(groupId));
}
function resolveTopologyGovernanceApprovalScope(topology, action, governanceKind) {
    const policy = getTopologyControlAccessPolicy(topology);
    const actionScope = resolveTopologyControlActionScope(policy, action);
    const rolloutControl = topology.candidateRolloutControl ?? null;
    const fallbackApproverUserId = topology.defaultHumanOwnerUserId ?? topology.createdBy ?? null;
    const approverUserIds = Array.from(new Set([
        ...(governanceKind === 'topology_candidate_promotion' ? (rolloutControl?.approvalUserIds ?? []) : []),
        ...actionScope.approverUserIds,
    ].filter((value) => typeof value === 'string' && value.trim().length > 0)));
    const effectiveRequesterUserIds = Array.from(new Set([
        ...actionScope.requesterUserIds,
        ...getWebUserIdsForRoleGroups(actionScope.requesterRoleGroups),
    ]));
    const effectiveApproverUserIds = Array.from(new Set([
        ...approverUserIds,
        ...getWebUserIdsForRoleGroups(actionScope.approverRoleGroups),
        ...(fallbackApproverUserId ? [fallbackApproverUserId] : []),
    ]));
    const escalationChain = resolveTopologyControlEscalationChain(actionScope.escalationChain, fallbackApproverUserId);
    return {
        action,
        requesterUserIds: actionScope.requesterUserIds,
        requesterRoleGroups: actionScope.requesterRoleGroups,
        approverUserIds,
        approverRoleGroups: actionScope.approverRoleGroups,
        escalationChain,
        fallbackApproverUserId,
        effectiveRequesterUserIds,
        effectiveApproverUserIds,
        primaryApproverUserId: effectiveApproverUserIds[0] ?? fallbackApproverUserId ?? null,
    };
}
function getTopologyControlActor(req) {
    const authUser = req.authUser;
    const userId = typeof authUser?.sub === 'string' && authUser.sub.trim() ? authUser.sub.trim() : null;
    return {
        userId,
        roleGroups: userId ? getMatchingRoleGroups(userId, authUser?.groups) : [],
        isAdmin: isAdminUser(authUser),
    };
}
function normalizeRouteFilterPreviewList(value) {
    if (typeof value === 'string' && value.trim())
        return [value.trim()];
    if (!Array.isArray(value))
        return [];
    return value
        .filter((item) => typeof item === 'string' && item.trim().length > 0)
        .map((item) => item.trim());
}
function buildNotificationRoutePreview(route) {
    const metadata = route.metadata ?? {};
    return {
        routeId: route.id,
        recipientUserId: route.recipientUserId,
        channel: route.channel,
        chatId: route.chatId,
        enabled: route.enabled !== false,
        filterSummary: {
            notificationTypes: normalizeRouteFilterPreviewList(metadata['notificationTypes'] ?? metadata['notificationType'] ?? metadata['types'] ?? metadata['type']),
            governanceKinds: normalizeRouteFilterPreviewList(metadata['governanceKinds'] ?? metadata['governanceKind']),
            topologyControlActions: normalizeRouteFilterPreviewList(metadata['topologyControlActions'] ?? metadata['topologyControlAction']),
            topologyIds: normalizeRouteFilterPreviewList(metadata['topologyIds'] ?? metadata['topologyId']),
            severities: normalizeRouteFilterPreviewList(metadata['severities'] ?? metadata['severity']),
        },
    };
}
function parseApprovalRoutingLevelsFromMetadata(metadata) {
    const raw = metadata['approvalRoutingLevels'];
    if (!Array.isArray(raw))
        return [];
    const levels = [];
    for (const entry of raw) {
        if (!entry || typeof entry !== 'object' || Array.isArray(entry))
            continue;
        const source = entry;
        const approverUserIds = normalizeStringList(source['approverUserIds']) ?? [];
        const approverRoleGroups = normalizeRoleGroupIdList(source['approverRoleGroups']) ?? [];
        const effectiveApproverUserIds = normalizeStringList(source['effectiveApproverUserIds']) ?? [];
        const primaryApproverUserId = typeof source['primaryApproverUserId'] === 'string' && source['primaryApproverUserId'].trim()
            ? source['primaryApproverUserId'].trim()
            : null;
        levels.push({
            level: Number.isFinite(Number(source['level'])) ? Math.max(0, Math.floor(Number(source['level']))) : levels.length,
            approverUserIds,
            approverRoleGroups,
            effectiveApproverUserIds,
            primaryApproverUserId,
            reminderAfterMinutes: normalizePositiveIntegerOrNull(source['reminderAfterMinutes']),
            escalationAfterMinutes: normalizePositiveIntegerOrNull(source['escalationAfterMinutes']),
            label: typeof source['label'] === 'string' && source['label'].trim() ? source['label'].trim() : null,
        });
    }
    return levels.sort((a, b) => a.level - b.level);
}
function resolveApprovalRoutingSummary(params) {
    const metadata = params.task.metadata ?? {};
    const levels = parseApprovalRoutingLevelsFromMetadata(metadata);
    const fallbackLevel = {
        level: 0,
        approverUserIds: [params.approval.requestedForUserId],
        approverRoleGroups: [],
        effectiveApproverUserIds: [params.approval.requestedForUserId],
        primaryApproverUserId: params.approval.requestedForUserId,
        reminderAfterMinutes: null,
        escalationAfterMinutes: null,
        label: 'initial',
    };
    const sortedLevels = levels.length > 0 ? levels : [fallbackLevel];
    let currentLevelIndex = Number.isFinite(Number(metadata['approvalCurrentLevelIndex']))
        ? Math.max(0, Math.min(sortedLevels.length - 1, Math.floor(Number(metadata['approvalCurrentLevelIndex']))))
        : sortedLevels.findIndex((level) => level.primaryApproverUserId === params.approval.requestedForUserId);
    if (currentLevelIndex < 0
        || ((sortedLevels[currentLevelIndex]?.primaryApproverUserId !== params.approval.requestedForUserId)
            && !(sortedLevels[currentLevelIndex]?.effectiveApproverUserIds.includes(params.approval.requestedForUserId)))) {
        currentLevelIndex = sortedLevels.findIndex((level) => level.primaryApproverUserId === params.approval.requestedForUserId);
    }
    if (currentLevelIndex < 0) {
        currentLevelIndex = sortedLevels.findIndex((level) => level.effectiveApproverUserIds.includes(params.approval.requestedForUserId));
    }
    if (currentLevelIndex < 0)
        currentLevelIndex = 0;
    const currentLevel = sortedLevels[currentLevelIndex] ?? fallbackLevel;
    const nextLevel = sortedLevels.slice(currentLevelIndex + 1).find((level) => level.primaryApproverUserId && level.primaryApproverUserId !== params.approval.requestedForUserId) ?? null;
    const levelStartedAt = typeof metadata['approvalCurrentLevelStartedAt'] === 'string' && metadata['approvalCurrentLevelStartedAt'].trim()
        ? metadata['approvalCurrentLevelStartedAt']
        : params.approval.createdAt.toISOString();
    const reminderAfterMinutes = currentLevel.reminderAfterMinutes ?? params.policy.approvalReminderAfterMinutes;
    const escalationAfterMinutes = currentLevel.escalationAfterMinutes ?? params.policy.approvalEscalationAfterMinutes;
    const fallbackRecipient = params.policy.escalationOwnerUserId ?? params.task.createdBy ?? null;
    return {
        currentLevelIndex,
        currentLevel,
        nextLevel,
        levelStartedAt,
        reminderAfterMinutes,
        escalationAfterMinutes,
        escalationRecipient: nextLevel?.primaryApproverUserId ?? (fallbackRecipient !== params.approval.requestedForUserId ? fallbackRecipient : null),
        escalationAudienceUserIds: nextLevel?.effectiveApproverUserIds ?? [],
    };
}
function previewMatchingNotificationRoutes(params) {
    const recipientUserIds = Array.from(new Set([
        ...(Array.isArray(params.recipientUserIds) ? params.recipientUserIds : []),
        params.recipientUserId,
    ].filter((value) => typeof value === 'string' && value.trim().length > 0).map((value) => value.trim())));
    if (recipientUserIds.length === 0)
        return [];
    return params.routes
        .filter((route) => route.workspaceId === params.workspaceId
        && route.enabled !== false
        && recipientUserIds.includes(route.recipientUserId)
        && doesNotificationRouteMatch(route, {
            id: 'preview',
            workspaceId: params.workspaceId,
            recipientUserId: route.recipientUserId,
            type: params.type,
            severity: params.severity,
            status: 'unread',
            deliveryStatus: 'pending',
            deliveryAttemptCount: 0,
            title: 'preview',
            message: 'preview',
            metadata: params.metadata,
            createdAt: new Date(0),
            updatedAt: new Date(0),
            readAt: null,
            lastDeliveryAttemptAt: null,
            deliveredAt: null,
            lastDeliveryError: null,
        }))
        .map((route) => buildNotificationRoutePreview(route));
}
function canActorRequestTopologyControl(topology, action, actor) {
    if (actor.isAdmin)
        return true;
    if (!actor.userId)
        return false;
    const policy = getTopologyControlAccessPolicy(topology);
    const actionScope = resolveTopologyControlActionScope(policy, action);
    return matchesTopologyControlScope(actor.userId, actor.roleGroups, {
        requesterUserIds: actionScope.requesterUserIds,
        requesterRoleGroups: actionScope.requesterRoleGroups,
    });
}
function canActorApproveTopologyGovernanceTask(task, actor) {
    if (actor.isAdmin)
        return true;
    if (!actor.userId)
        return false;
    const metadata = task.metadata ?? {};
    const governanceKind = metadata['governanceKind'];
    if (governanceKind !== 'topology_control_action' && governanceKind !== 'topology_candidate_promotion') {
        return false;
    }
    const userIds = normalizeStringList(governanceKind === 'topology_control_action'
        ? metadata['topologyControlApproverUserIds']
        : metadata['candidatePromotionApproverUserIds']);
    const roleGroups = normalizeRoleGroupIdList(governanceKind === 'topology_control_action'
        ? metadata['topologyControlApproverRoleGroups']
        : metadata['candidatePromotionApproverRoleGroups']);
    return matchesTopologyControlScope(actor.userId, actor.roleGroups, {
        approverUserIds: userIds ?? [],
        approverRoleGroups: roleGroups ?? [],
    });
}
async function ensureTopologyControlApprovalTask(params) {
    const existingTasks = await memoryStore.listTeamTasks({ workspaceId: params.topology.workspaceId });
    const existing = existingTasks.find((task) => {
        if (task.status === 'done' || task.status === 'cancelled')
            return false;
        const metadata = task.metadata ?? {};
        return metadata['governanceKind'] === 'topology_control_action'
            && metadata['topologyControlAction'] === params.action
            && metadata['topologyId'] === params.topology.id
            && metadata['topologyControlApprovalStatus'] === 'pending';
    });
    const baseMetadata = {
        requestUserId: params.requestedByUserId,
        requestChannel: 'web',
        requestChatId: params.topology.workspaceId,
        topologyId: params.topology.id,
        topologyName: params.topology.name,
        governanceKind: 'topology_control_action',
        topologyControlAction: params.action,
        topologyControlApprovalRequired: true,
        topologyControlApprovalStatus: 'pending',
        topologyControlExecutionStatus: 'pending',
        topologyControlRequestedForUserId: params.requestedForUserId,
        topologyControlRequestedByUserId: params.requestedByUserId,
        topologyControlRequestedAt: new Date().toISOString(),
        topologyControlApproverUserIds: params.approverUserIds ?? [],
        topologyControlApproverRoleGroups: params.approverRoleGroups ?? [],
        topologyControlEffectiveApproverUserIds: params.effectiveApproverUserIds ?? [],
        approvalBroadcastUserIds: params.effectiveApproverUserIds ?? [],
        ...buildApprovalRoutingLevelsMetadata({
            approverUserIds: params.approverUserIds ?? [],
            approverRoleGroups: params.approverRoleGroups ?? [],
            effectiveApproverUserIds: params.effectiveApproverUserIds ?? [],
            primaryApproverUserId: params.requestedForUserId,
            escalationChain: params.escalationChain ?? [],
        }),
        ...params.metadata,
    };
    const task = existing
        ? await memoryStore.updateTeamTask(existing.id, {
            status: 'blocked',
            priority: 'high',
            blockedReason: params.summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: params.summary.slice(0, 500),
            humanOwnerUserId: params.requestedForUserId,
            description: params.summary.slice(0, 2000),
            metadata: {
                ...(existing.metadata ?? {}),
                ...baseMetadata,
            },
        })
        : await memoryStore.createTeamTask({
            workspaceId: params.topology.workspaceId,
            title: params.title.slice(0, 120),
            description: params.summary.slice(0, 2000),
            status: 'blocked',
            priority: 'high',
            assignedAgentId: null,
            reviewRequired: false,
            reviewStatus: 'not_required',
            maxAttempts: 1,
            humanOwnerUserId: params.requestedForUserId,
            blockedReason: params.summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: params.summary.slice(0, 500),
            dueAt: new Date(Date.now() + 24 * 3600 * 1000),
            createdBy: params.requestedByUserId,
            metadata: baseMetadata,
        });
    if (!task)
        return null;
    const existingApprovals = await memoryStore.listTeamTaskApprovals({
        workspaceId: params.topology.workspaceId,
        taskId: task.id,
        status: 'pending',
        requestedForUserId: params.requestedForUserId,
    });
    if (existingApprovals.length > 0) {
        return {
            taskId: task.id,
            approvalId: existingApprovals[0]?.id ?? null,
            approvalCreated: false,
        };
    }
    const approval = await memoryStore.createTeamTaskApproval({
        workspaceId: params.topology.workspaceId,
        taskId: task.id,
        requestedBy: params.requestedByUserId,
        requestedForUserId: params.requestedForUserId,
        reason: params.summary,
    });
    await memoryStore.createTeamNotification({
        workspaceId: params.topology.workspaceId,
        recipientUserId: params.requestedForUserId,
        type: 'approval_requested',
        severity: 'critical',
        title: `Approval required: ${params.title}`.slice(0, 160),
        message: params.summary,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            governanceKind: 'topology_control_action',
            topologyId: params.topology.id,
            topologyControlAction: params.action,
            ...(params.effectiveApproverUserIds && params.effectiveApproverUserIds.length > 1
                ? { additionalRecipientUserIds: params.effectiveApproverUserIds.filter((userId) => userId !== params.requestedForUserId) }
                : {}),
        },
    });
    await memoryStore.createTeamNotification({
        workspaceId: params.topology.workspaceId,
        recipientUserId: params.requestedForUserId,
        type: 'task_escalated',
        severity: 'critical',
        title: `Topology control pending approval: ${params.topology.name}`.slice(0, 160),
        message: params.summary,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            governanceKind: 'topology_control_action',
            topologyId: params.topology.id,
            topologyControlAction: params.action,
            ...(params.effectiveApproverUserIds && params.effectiveApproverUserIds.length > 1
                ? { additionalRecipientUserIds: params.effectiveApproverUserIds.filter((userId) => userId !== params.requestedForUserId) }
                : {}),
        },
    });
    return {
        taskId: task.id,
        approvalId: approval.id,
        approvalCreated: true,
    };
}
async function ensureManualCandidatePromotionApprovalTask(params) {
    const candidate = params.topology.candidateStrategy;
    if (!candidate)
        return null;
    const existingTasks = await memoryStore.listTeamTasks({ workspaceId: params.topology.workspaceId });
    const existing = existingTasks.find((task) => {
        if (task.status === 'done' || task.status === 'cancelled')
            return false;
        const metadata = task.metadata ?? {};
        return metadata['governanceKind'] === 'topology_candidate_promotion'
            && metadata['topologyId'] === params.topology.id
            && Number(metadata['candidatePromotionCandidateVersion']) === candidate.version
            && metadata['candidatePromotionApprovalStatus'] === 'pending';
    });
    const summary = [
        `Manual promotion requested for candidate strategy v${candidate.version} in topology ${params.topology.name}.`,
        `Current rollout: ${(candidate.rolloutPercent * 100).toFixed(1)}%.`,
        `Reason: ${params.reason}`,
    ].join('\n');
    const metadata = {
        requestUserId: params.requestedByUserId,
        requestChannel: 'web',
        requestChatId: params.topology.workspaceId,
        topologyId: params.topology.id,
        topologyName: params.topology.name,
        governanceKind: 'topology_candidate_promotion',
        candidatePromotionApprovalRequired: true,
        candidatePromotionApprovalStatus: 'pending',
        candidatePromotionExecutionStatus: 'pending',
        candidatePromotionCandidateVersion: candidate.version,
        candidatePromotionStableVersion: params.topology.strategyVersion ?? 1,
        candidatePromotionRequestedForUserId: params.requestedForUserId,
        candidatePromotionRequestedByUserId: params.requestedByUserId,
        candidatePromotionRequestedAt: new Date().toISOString(),
        candidatePromotionRolloutPercent: candidate.rolloutPercent,
        candidatePromotionReason: params.reason,
        candidatePromotionStrategySnapshot: candidate,
        candidatePromotionApproverUserIds: params.approverUserIds ?? [],
        candidatePromotionApproverRoleGroups: params.approverRoleGroups ?? [],
        candidatePromotionEffectiveApproverUserIds: params.effectiveApproverUserIds ?? [],
        approvalBroadcastUserIds: params.effectiveApproverUserIds ?? [],
        ...buildApprovalRoutingLevelsMetadata({
            approverUserIds: params.approverUserIds ?? [],
            approverRoleGroups: params.approverRoleGroups ?? [],
            effectiveApproverUserIds: params.effectiveApproverUserIds ?? [],
            primaryApproverUserId: params.requestedForUserId,
            escalationChain: params.escalationChain ?? [],
        }),
    };
    const task = existing
        ? await memoryStore.updateTeamTask(existing.id, {
            status: 'blocked',
            priority: 'high',
            blockedReason: summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: summary.slice(0, 500),
            humanOwnerUserId: params.requestedForUserId,
            description: summary.slice(0, 2000),
            metadata: {
                ...(existing.metadata ?? {}),
                ...metadata,
            },
        })
        : await memoryStore.createTeamTask({
            workspaceId: params.topology.workspaceId,
            title: `[Governance] Approve topology promotion: ${params.topology.name}`.slice(0, 120),
            description: summary.slice(0, 2000),
            status: 'blocked',
            priority: 'high',
            assignedAgentId: null,
            reviewRequired: false,
            reviewStatus: 'not_required',
            maxAttempts: 1,
            humanOwnerUserId: params.requestedForUserId,
            blockedReason: summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: summary.slice(0, 500),
            dueAt: new Date(Date.now() + 24 * 3600 * 1000),
            createdBy: params.requestedByUserId,
            metadata,
        });
    if (!task)
        return null;
    const existingApprovals = await memoryStore.listTeamTaskApprovals({
        workspaceId: params.topology.workspaceId,
        taskId: task.id,
        status: 'pending',
        requestedForUserId: params.requestedForUserId,
    });
    if (existingApprovals.length > 0) {
        return {
            taskId: task.id,
            approvalId: existingApprovals[0]?.id ?? null,
            approvalCreated: false,
        };
    }
    const approval = await memoryStore.createTeamTaskApproval({
        workspaceId: params.topology.workspaceId,
        taskId: task.id,
        requestedBy: params.requestedByUserId,
        requestedForUserId: params.requestedForUserId,
        reason: summary,
    });
    await memoryStore.createTeamNotification({
        workspaceId: params.topology.workspaceId,
        recipientUserId: params.requestedForUserId,
        type: 'approval_requested',
        severity: 'critical',
        title: `Approval required for topology promotion: ${params.topology.name}`,
        message: summary,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            governanceKind: 'topology_candidate_promotion',
            topologyId: params.topology.id,
            candidateVersion: candidate.version,
            ...(params.effectiveApproverUserIds && params.effectiveApproverUserIds.length > 1
                ? { additionalRecipientUserIds: params.effectiveApproverUserIds.filter((userId) => userId !== params.requestedForUserId) }
                : {}),
        },
    });
    return {
        taskId: task.id,
        approvalId: approval.id,
        approvalCreated: true,
    };
}
function getDirectAssignedRole(userId) {
    const roles = configManager.get().roles;
    const principals = [`web:${userId}`, userId];
    for (const principal of principals) {
        if (roles?.admin?.includes(principal))
            return 'admin';
        if (roles?.user?.includes(principal))
            return 'user';
        if (roles?.readonly?.includes(principal))
            return 'readonly';
    }
    return null;
}
function summarizeConfigUpdate(updates) {
    return {
        sections: Object.keys(updates),
        rolesUpdated: Boolean(updates.roles),
        providersUpdated: Object.keys(updates.providers ?? {}),
        channelsUpdated: Object.keys(updates.channels ?? {}),
        skillsUpdated: Object.keys(updates.skills ?? {}),
    };
}
function parseStringArrayInput(value) {
    if (Array.isArray(value)) {
        return value
            .filter((item) => typeof item === 'string' && item.trim().length > 0)
            .map((item) => item.trim());
    }
    if (typeof value === 'string' && value.trim()) {
        return value
            .split(',')
            .map((item) => item.trim())
            .filter(Boolean);
    }
    if (value === null)
        return [];
    return undefined;
}
function parseTeamTaskStatus(value) {
    return value === 'todo'
        || value === 'open'
        || value === 'proposed'
        || value === 'claimed'
        || value === 'assigned'
        || value === 'in_progress'
        || value === 'review_pending'
        || value === 'challenge_open'
        || value === 'consensus_pending'
        || value === 'blocked'
        || value === 'escalated'
        || value === 'done'
        || value === 'cancelled'
        ? value
        : undefined;
}
function parseReviewStatus(value) {
    return value === 'not_required' || value === 'pending' || value === 'approved' || value === 'changes_requested'
        ? value
        : undefined;
}
function summarizeHeartbeatAgent(agentDef) {
    const metadata = agentDef.metadata ?? {};
    return {
        id: agentDef.id,
        name: agentDef.name,
        workspaceId: agentDef.workspaceId,
        ownerUserId: agentDef.ownerUserId,
        status: agentDef.status,
        memoryScope: agentDef.memoryScope,
        provider: agentDef.provider ?? null,
        model: agentDef.model ?? null,
        heartbeatFailureCount: Number(metadata['heartbeatFailureCount'] ?? 0),
        heartbeatPausedBySystem: Boolean(metadata['heartbeatPausedBySystem']),
        lastHeartbeatStatus: typeof metadata['lastHeartbeatStatus'] === 'string' ? metadata['lastHeartbeatStatus'] : null,
        lastHeartbeatAt: typeof metadata['lastHeartbeatAt'] === 'string' ? metadata['lastHeartbeatAt'] : null,
        lastHeartbeatSummary: typeof metadata['lastHeartbeatSummary'] === 'string' ? metadata['lastHeartbeatSummary'] : null,
        lastHeartbeatError: typeof metadata['lastHeartbeatError'] === 'string' ? metadata['lastHeartbeatError'] : null,
        heartbeatCircuitOpenUntil: typeof metadata['heartbeatCircuitOpenUntil'] === 'string' ? metadata['heartbeatCircuitOpenUntil'] : null,
        heartbeatFailureThreshold: Number(metadata['heartbeatFailureThreshold'] ?? 3),
        heartbeatCircuitOpenMinutes: Number(metadata['heartbeatCircuitOpenMinutes'] ?? 15),
    };
}
function parseIsoTime(value) {
    if (typeof value !== 'string' || !value.trim())
        return null;
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
}
function isOpenTeamTask(task) {
    return task.status !== 'done' && task.status !== 'cancelled';
}
function isCurrentHeartbeatCircuitOpen(agent, now = Date.now()) {
    const circuitOpenUntil = parseIsoTime(agent.heartbeatCircuitOpenUntil);
    return agent.heartbeatPausedBySystem || (circuitOpenUntil !== null && circuitOpenUntil > now);
}
function summarizeDashboardHeartbeat(agents, now = Date.now()) {
    const summaries = agents.map((agentDef) => summarizeHeartbeatAgent(agentDef));
    return {
        totalAgents: summaries.length,
        activeAgents: summaries.filter((agent) => agent.status === 'active').length,
        systemPausedAgents: summaries.filter((agent) => agent.heartbeatPausedBySystem).length,
        circuitOpenAgents: summaries.filter((agent) => isCurrentHeartbeatCircuitOpen(agent, now)).length,
        healthyAgents: summaries.filter((agent) => !isCurrentHeartbeatCircuitOpen(agent, now)
            && (agent.lastHeartbeatStatus === 'idle' || agent.lastHeartbeatStatus === 'actionable' || agent.lastHeartbeatStatus === 'recovered')).length,
        errorAgents: summaries.filter((agent) => agent.lastHeartbeatStatus === 'error').length,
        recentHeartbeatAgents: summaries
            .filter((agent) => parseIsoTime(agent.lastHeartbeatAt) !== null)
            .sort((a, b) => (parseIsoTime(b.lastHeartbeatAt) ?? 0) - (parseIsoTime(a.lastHeartbeatAt) ?? 0))
            .slice(0, 6),
    };
}
function isLongRunningTask(task, now = Date.now()) {
    if (!isOpenTeamTask(task))
        return false;
    const metadata = task.metadata ?? {};
    const ageMs = now - task.createdAt.getTime();
    return task.status === 'in_progress'
        || task.status === 'blocked'
        || task.status === 'review_pending'
        || parseIsoTime(metadata['heartbeatSeenAt']) !== null
        || parseIsoTime(metadata['heartbeatUpdatedAt']) !== null
        || Boolean(task.assignedAgentId && ageMs >= LONG_RUNNING_TASK_AGE_MS);
}
function summarizeDashboardLongRunningTask(task, agentsById, now = Date.now()) {
    const metadata = task.metadata ?? {};
    const assignedAgent = task.assignedAgentId ? agentsById.get(task.assignedAgentId) ?? null : null;
    return {
        id: task.id,
        title: task.title,
        workspaceId: task.workspaceId,
        assignedAgentId: task.assignedAgentId ?? null,
        assignedAgentName: assignedAgent?.name ?? null,
        status: task.status,
        priority: task.priority,
        dueAt: task.dueAt ? task.dueAt.toISOString() : null,
        updatedAt: task.updatedAt.toISOString(),
        overdue: Boolean(task.dueAt && task.dueAt.getTime() < now && isOpenTeamTask(task)),
        lastHeartbeatAt: (typeof metadata['heartbeatSeenAt'] === 'string' ? metadata['heartbeatSeenAt'] : null)
            ?? (typeof metadata['heartbeatUpdatedAt'] === 'string' ? metadata['heartbeatUpdatedAt'] : null),
        lastHeartbeatSummary: typeof metadata['heartbeatProgressSummary'] === 'string' ? metadata['heartbeatProgressSummary'] : null,
        nextAction: typeof metadata['heartbeatNextAction'] === 'string' ? metadata['heartbeatNextAction'] : null,
        blockedReason: task.blockedReason ?? null,
    };
}
function summarizeDashboardTeamProgress(tasks, agents, now = Date.now()) {
    const openTasks = tasks.filter((task) => isOpenTeamTask(task));
    const longRunningTasks = openTasks.filter((task) => isLongRunningTask(task, now));
    const agentsById = new Map(agents.map((agentDef) => [agentDef.id, agentDef]));
    return {
        openTasks: openTasks.length,
        inProgressTasks: openTasks.filter((task) => task.status === 'in_progress').length,
        blockedTasks: openTasks.filter((task) => task.status === 'blocked').length,
        reviewPendingTasks: openTasks.filter((task) => task.status === 'review_pending').length,
        overdueTasks: openTasks.filter((task) => Boolean(task.dueAt && task.dueAt.getTime() < now)).length,
        longRunningTasks: longRunningTasks.length,
        recentLongRunningTasks: longRunningTasks
            .map((task) => summarizeDashboardLongRunningTask(task, agentsById, now))
            .sort((a, b) => Number(b.overdue) - Number(a.overdue)
            || (parseIsoTime(b.lastHeartbeatAt) ?? Date.parse(b.updatedAt)) - (parseIsoTime(a.lastHeartbeatAt) ?? Date.parse(a.updatedAt)))
            .slice(0, 8),
    };
}
function summarizeDashboardProtocolTask(task) {
    const metadata = task.metadata ?? {};
    const consensus = metadata['consensus'] && typeof metadata['consensus'] === 'object'
        ? metadata['consensus']
        : {};
    if (task.status === 'open' || task.status === 'proposed') {
        const participantAgentIds = Array.isArray(metadata['protocolAnnouncedAgentIds'])
            ? metadata['protocolAnnouncedAgentIds'].filter((item) => typeof item === 'string')
            : [];
        if (!metadata['protocolAnnouncedAt'] && !consensus['resolvedAt'])
            return null;
        return {
            id: task.id,
            title: task.title,
            workspaceId: task.workspaceId,
            status: task.status,
            assignedAgentId: task.assignedAgentId ?? null,
            protocolKind: typeof consensus['protocolKind'] === 'string' ? consensus['protocolKind'] : null,
            protocolState: consensus['resolvedAt'] ? 'consensus_resolved' : 'announcement_pending',
            participantAgentIds: Array.isArray(consensus['participantAgentIds'])
                ? consensus['participantAgentIds'].filter((item) => typeof item === 'string')
                : participantAgentIds,
            responseCount: Number(consensus['responseCount'] ?? 0),
            awaitingAgentIds: Array.isArray(consensus['awaitingAgentIds'])
                ? consensus['awaitingAgentIds'].filter((item) => typeof item === 'string')
                : participantAgentIds,
            approveWeight: Number(consensus['approveWeight'] ?? 0),
            changesRequestedWeight: Number(consensus['changesRequestedWeight'] ?? 0),
            quorumWeight: Number.isFinite(Number(consensus['quorumWeight'])) ? Number(consensus['quorumWeight']) : null,
            resolution: typeof consensus['resolution'] === 'string' ? consensus['resolution'] : null,
            conflictKey: typeof consensus['conflictKey'] === 'string' ? consensus['conflictKey'] : null,
            expectedVersion: Number.isFinite(Number(consensus['expectedVersion'])) ? Number(consensus['expectedVersion']) : null,
            currentVersion: Number.isFinite(Number(consensus['currentVersion'])) ? Number(consensus['currentVersion']) : null,
            updatedAt: task.updatedAt.toISOString(),
        };
    }
    if (task.status !== 'challenge_open' && task.status !== 'consensus_pending' && !consensus['resolvedAt'])
        return null;
    const participantAgentIds = Array.isArray(consensus['participantAgentIds'])
        ? consensus['participantAgentIds'].filter((item) => typeof item === 'string')
        : [];
    const responseAgentIds = Array.isArray(consensus['responseAgentIds'])
        ? consensus['responseAgentIds'].filter((item) => typeof item === 'string')
        : [];
    const awaitingAgentIds = participantAgentIds.filter((agentId) => !responseAgentIds.includes(agentId));
    return {
        id: task.id,
        title: task.title,
        workspaceId: task.workspaceId,
        status: task.status,
        assignedAgentId: task.assignedAgentId ?? null,
        protocolKind: typeof consensus['protocolKind'] === 'string' ? consensus['protocolKind'] : null,
        protocolState: task.status === 'challenge_open'
            ? 'challenge_open'
            : (consensus['resolvedAt'] ? 'consensus_resolved' : 'consensus_pending'),
        participantAgentIds,
        responseCount: Number(consensus['responseCount'] ?? 0),
        awaitingAgentIds,
        approveWeight: Number(consensus['approveWeight'] ?? 0),
        changesRequestedWeight: Number(consensus['changesRequestedWeight'] ?? 0),
        quorumWeight: Number.isFinite(Number(consensus['quorumWeight'])) ? Number(consensus['quorumWeight']) : null,
        resolution: typeof consensus['resolution'] === 'string' ? consensus['resolution'] : null,
        conflictKey: typeof consensus['conflictKey'] === 'string' ? consensus['conflictKey'] : null,
        expectedVersion: Number.isFinite(Number(consensus['expectedVersion'])) ? Number(consensus['expectedVersion']) : null,
        currentVersion: Number.isFinite(Number(consensus['currentVersion'])) ? Number(consensus['currentVersion']) : null,
        updatedAt: task.updatedAt.toISOString(),
    };
}
function summarizeDashboardProtocol(tasks) {
    const protocolTasks = tasks
        .map((task) => summarizeDashboardProtocolTask(task))
        .filter((task) => Boolean(task))
        .sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
    return {
        protocolTasks: protocolTasks.length,
        memoryConflictTasks: protocolTasks.filter((task) => task.protocolKind === 'memory_conflict').length,
        challengeOpenTasks: protocolTasks.filter((task) => task.protocolState === 'challenge_open').length,
        consensusPendingTasks: protocolTasks.filter((task) => task.protocolState === 'consensus_pending').length,
        announcementPendingTasks: protocolTasks.filter((task) => task.protocolState === 'announcement_pending').length,
        recentProtocolTasks: protocolTasks.slice(0, 8),
    };
}
function summarizeDashboardGovernanceTask(task) {
    const metadata = task.metadata ?? {};
    if (metadata['governanceKind'] !== 'shared_memory_authority')
        return null;
    const actionRaw = metadata['sharedMemoryAction'];
    const action = actionRaw === 'write' || actionRaw === 'rollback' ? actionRaw : null;
    const approvalStatusRaw = metadata['sharedMemoryApprovalStatus'];
    const approvalStatus = approvalStatusRaw === 'pending' || approvalStatusRaw === 'approved' || approvalStatusRaw === 'rejected'
        ? approvalStatusRaw
        : null;
    const executionStatusRaw = metadata['sharedMemoryExecutionStatus'];
    const executionStatus = executionStatusRaw === 'pending' || executionStatusRaw === 'applied' || executionStatusRaw === 'failed'
        ? executionStatusRaw
        : null;
    return {
        id: task.id,
        title: task.title,
        workspaceId: task.workspaceId,
        status: task.status,
        priority: task.priority,
        action,
        key: typeof metadata['sharedMemoryKey'] === 'string' ? metadata['sharedMemoryKey'] : null,
        approvalStatus,
        executionStatus,
        requestedForUserId: typeof metadata['sharedMemoryRequestedForUserId'] === 'string' ? metadata['sharedMemoryRequestedForUserId'] : task.humanOwnerUserId ?? null,
        requestedByUserId: typeof metadata['sharedMemoryRequesterUserId'] === 'string' ? metadata['sharedMemoryRequesterUserId'] : task.createdBy,
        approvedByUserId: typeof metadata['sharedMemoryApprovedByUserId'] === 'string' ? metadata['sharedMemoryApprovedByUserId'] : null,
        lastError: typeof metadata['sharedMemoryExecutionError'] === 'string' ? metadata['sharedMemoryExecutionError'] : null,
        appliedVersion: Number.isFinite(Number(metadata['sharedMemoryAppliedVersion'])) ? Number(metadata['sharedMemoryAppliedVersion']) : null,
        updatedAt: task.updatedAt.toISOString(),
    };
}
function summarizeDashboardGovernance(tasks) {
    const governanceTasks = tasks
        .map((task) => summarizeDashboardGovernanceTask(task))
        .filter((task) => Boolean(task))
        .sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
    return {
        governanceTasks: governanceTasks.length,
        pendingApprovalTasks: governanceTasks.filter((task) => task.approvalStatus === 'pending').length,
        approvedPendingExecutionTasks: governanceTasks.filter((task) => task.approvalStatus === 'approved' && task.executionStatus !== 'applied').length,
        failedExecutionTasks: governanceTasks.filter((task) => task.executionStatus === 'failed').length,
        recentGovernanceTasks: governanceTasks.slice(0, 8),
    };
}
function canViewGovernanceTask(task, actorUserId, admin = false) {
    if (!task)
        return false;
    if (admin)
        return true;
    if (!actorUserId)
        return false;
    const metadata = task.metadata ?? {};
    return task.createdBy === actorUserId
        || task.humanOwnerUserId === actorUserId
        || metadata['sharedMemoryRequestedForUserId'] === actorUserId
        || metadata['sharedMemoryRequesterUserId'] === actorUserId;
}
function parseEscalationStatus(value) {
    return value === 'none' || value === 'pending' || value === 'acknowledged'
        ? value
        : undefined;
}
function parseTeamNotificationStatus(value) {
    return value === 'unread' || value === 'read' || value === 'archived'
        ? value
        : undefined;
}
function parseTeamNotificationDeliveryStatus(value) {
    return value === 'pending' || value === 'sent' || value === 'partial' || value === 'failed'
        ? value
        : undefined;
}
function parseTeamMailboxType(value) {
    return value === 'direct'
        || value === 'broadcast'
        || value === 'task_event'
        || value === 'challenge'
        || value === 'consensus_request'
        || value === 'consensus_response'
        ? value
        : undefined;
}
function parseTeamMailboxStatus(value) {
    return value === 'pending' || value === 'acknowledged' || value === 'archived' || value === 'dead_letter'
        ? value
        : undefined;
}
function parseChannelName(value) {
    return value === 'telegram'
        || value === 'discord'
        || value === 'slack'
        || value === 'whatsapp'
        || value === 'web'
        || value === 'wecom'
        || value === 'feishu'
        || value === 'dingtalk'
        || value === 'teams'
        || value === 'line'
        || value === 'matrix'
        ? value
        : undefined;
}
function parseOnCallScheduleType(value) {
    return value === 'daily' || value === 'weekly' ? value : undefined;
}
function getErrorMessage(err) {
    return err instanceof Error ? err.message : String(err);
}
function respondKnownTeamError(res, err) {
    const message = getErrorMessage(err);
    if (message === 'Forbidden: approval belongs to another user') {
        res.status(403).json({ error: message });
        return true;
    }
    if (err instanceof SyntaxError) {
        res.status(400).json({ error: 'Invalid JSON input' });
        return true;
    }
    if (message.startsWith('Missing required template variables:')
        || message.startsWith('Template not found in topology workspace:')) {
        res.status(400).json({ error: message });
        return true;
    }
    return false;
}
function formatConversationExport(rows, sessionId, format) {
    const visibleRows = rows.filter((r) => r.role === 'user' || r.role === 'assistant');
    if (format === 'json') {
        return JSON.stringify(visibleRows.map((r) => ({
            role: r.role,
            content: r.content,
            timestamp: r.createdAt.toISOString(),
        })), null, 2);
    }
    const lines = [`# Conversation Export\n\nSession: \`${sessionId}\`\n`];
    for (const r of visibleRows) {
        const ts = r.createdAt.toLocaleString();
        const label = r.role === 'user' ? '**You**' : '**GreenFrog**';
        lines.push(`### ${label} - ${ts}\n\n${r.content}\n`);
    }
    return lines.join('\n---\n\n');
}
// stripMaskedFields is imported from ../../utils/config_helpers.js
/**
 * Stable identifier derived from the gateway secret.
 * All browser sessions that authenticate with the same secret share this ID,
 * so scheduled job responses can always be delivered regardless of reconnection.
 */
function getStableWebId() {
    return createHash('sha256').update(config.gateway.secret).digest('hex').slice(0, 16);
}
function summarizeTeamTaskRuntime(task) {
    const metadata = task.metadata ?? {};
    const currentRunId = typeof metadata['currentRunId'] === 'string' && metadata['currentRunId'].trim()
        ? metadata['currentRunId'].trim()
        : null;
    const lastRunId = typeof metadata['lastRunId'] === 'string' && metadata['lastRunId'].trim()
        ? metadata['lastRunId'].trim()
        : null;
    const currentRun = currentRunId ? getAgentRun(currentRunId) : null;
    const trace = getTraceByRunId(currentRunId ?? lastRunId ?? '');
    const lastRunStatus = typeof metadata['lastRunStatus'] === 'string' && metadata['lastRunStatus'].trim()
        ? metadata['lastRunStatus'].trim()
        : null;
    const lastRunAt = typeof metadata['lastRunAt'] === 'string' && metadata['lastRunAt'].trim()
        ? metadata['lastRunAt'].trim()
        : null;
    const lastRunCompletedAt = typeof metadata['lastRunCompletedAt'] === 'string' && metadata['lastRunCompletedAt'].trim()
        ? metadata['lastRunCompletedAt'].trim()
        : null;
    const lastRunError = typeof metadata['lastRunError'] === 'string' && metadata['lastRunError'].trim()
        ? metadata['lastRunError'].trim()
        : null;
    return {
        isRunning: Boolean(currentRun),
        currentRunId,
        lastRunId,
        lastRunStatus,
        lastRunAt,
        lastRunCompletedAt,
        lastRunError,
        currentRun,
        trace: trace
            ? {
                traceId: trace.traceId,
                runId: trace.runId,
                status: trace.status,
                startedAt: new Date(trace.startedAt).toISOString(),
                completedAt: trace.completedAt ? new Date(trace.completedAt).toISOString() : null,
                durationMs: trace.durationMs,
                errorMessage: trace.metadata.errorMessage ?? null,
                iterationCount: trace.metadata.iterationCount ?? 0,
                toolCallCount: trace.metadata.toolCallCount ?? 0,
                providerCallCount: trace.metadata.providerCallCount ?? 0,
            }
            : null,
    };
}
/**
 * Verify a HMAC-SHA256 signature on a WS message payload.
 * The payload is the string that was signed (e.g. the `text` field content).
 * Uses timing-safe comparison to prevent timing attacks.
 */
function verifyMessageSig(secret, payload, sig) {
    try {
        const expected = createHmac('sha256', secret).update(payload).digest();
        // sig is hex-encoded
        if (sig.length !== expected.length * 2)
            return false;
        const actual = Buffer.from(sig, 'hex');
        if (actual.length !== expected.length)
            return false;
        return timingSafeEqual(expected, actual);
    }
    catch {
        return false;
    }
}
export class WebChannel extends BaseChannel {
    name = 'web';
    httpServer = null;
    wss = null;
    clients = new Map();
    _running = false;
    async start() {
        const cfg = config.channels.web;
        if (cfg?.enabled === false) {
            this.log.info('Web channel disabled');
            return;
        }
        const port = cfg?.port ?? config.webui.port;
        const host = config.webui.host;
        const app = express();
        const __dirname = dirname(fileURLToPath(import.meta.url));
        app.use(helmet({
            contentSecurityPolicy: {
                directives: {
                    defaultSrc: ["'self'"],
                    scriptSrc: ["'self'", "'unsafe-inline'"],
                    scriptSrcAttr: ["'unsafe-inline'"],
                    styleSrc: ["'self'", "'unsafe-inline'"],
                    imgSrc: ["'self'", 'data:'],
                    connectSrc: ["'self'", 'ws:', 'wss:'],
                    fontSrc: ["'self'"],
                    objectSrc: ["'none'"],
                    upgradeInsecureRequests: [],
                },
            },
            crossOriginEmbedderPolicy: false,
        }));
        // Serve new Vite build (ui/dist/) when available, fall back to legacy ui/
        const uiDistPath = join(__dirname, '..', '..', '..', 'ui', 'dist');
        const uiLegacyPath = join(__dirname, '..', '..', '..', 'ui');
        const uiRoot = existsSync(join(uiDistPath, 'index.html')) ? uiDistPath : uiLegacyPath;
        app.use(express.static(uiRoot, {
            setHeaders: (res, filePath) => {
                if (filePath.endsWith('.html')) {
                    res.setHeader('Content-Type', 'text/html; charset=utf-8');
                    res.setHeader('Cache-Control', 'no-store');
                }
            },
        }));
        app.use(express.json({ limit: '512kb' }));
        // Inline cookie parser (no extra dependency)
        app.use((req, _res, next) => {
            const raw = req.headers.cookie ?? '';
            const cookies = {};
            for (const part of raw.split(';')) {
                const eq = part.indexOf('=');
                if (eq < 1)
                    continue;
                cookies[part.slice(0, eq).trim()] = decodeURIComponent(part.slice(eq + 1).trim());
            }
            req.cookies = cookies;
            next();
        });
        // Apply rate limiter globally
        app.use(rateLimitMiddleware);
        // Prometheus HTTP request timing (must be after rate limiter so aborted requests are counted)
        app.use(httpMetricsMiddleware);
        // ── OIDC auth routes (public — no requireAuth) ──────────────────────────
        await initAuth();
        app.get('/auth/login', (req, res) => void handleLogin(req, res));
        app.get('/auth/callback', (req, res) => void handleCallback(req, res));
        app.get('/auth/logout', handleLogout);
        app.post('/auth/logout-all', (req, res) => void handleLogoutAll(req, res));
        app.get('/auth/userinfo', (req, res) => void handleUserinfo(req, res));
        // ── REST API: send a message ─────────────────────────────────────────────
        app.post('/api/message', requireAuth, async (req, res) => {
            const { text, userId = 'web-user', chatId = 'web', agentId, workspaceId } = req.body;
            if (!text || typeof text !== 'string') {
                res.status(400).json({ error: 'text is required' });
                return;
            }
            const resolvedUserId = req.authUser?.sub ?? userId;
            const msg = {
                id: nanoid(),
                channel: 'web',
                userId: resolvedUserId,
                chatId: chatId ?? 'web',
                text: text.slice(0, 8192),
                timestamp: new Date(),
                metadata: {
                    ...(typeof agentId === 'string' && agentId.trim() ? { agentId: agentId.trim() } : {}),
                    ...(typeof workspaceId === 'string' && workspaceId.trim() ? { workspaceId: workspaceId.trim() } : {}),
                },
            };
            messagesTotal.inc({ channel: 'web' });
            // ── Queue mode: enqueue and return request ID immediately ────────────
            try {
                if (isQueueEnabled()) {
                    const sessionId = await memoryStore.getOrCreateSession(resolvedUserId, 'web', chatId ?? 'web');
                    const requestId = nanoid();
                    await enqueueMessage({
                        type: 'process_message',
                        requestId, userId: resolvedUserId,
                        channel: 'web', chatId: chatId ?? 'web',
                        sessionId, text: text.slice(0, 8192),
                        ...(typeof agentId === 'string' && agentId.trim() ? { agentId: agentId.trim() } : {}),
                        ...(typeof workspaceId === 'string' && workspaceId.trim() ? { workspaceId: workspaceId.trim() } : {}),
                    });
                    res.status(202).json({ requestId, status: 'queued' });
                    return;
                }
                // ── Direct mode (no Redis): synchronous processing ───────────────────
                if (this.messageHandler) {
                    const lease = acquireAgentExecutionLease({
                        userId: msg.userId,
                        channel: msg.channel,
                        label: 'web_rest_message',
                    });
                    try {
                        const response = await agent.processMessage(msg);
                        res.json({ text: response.text });
                    }
                    finally {
                        lease.release();
                    }
                }
                else {
                    res.status(503).json({ error: 'No message handler' });
                }
            }
            catch (err) {
                if (err instanceof RuntimeLimitError) {
                    res.status(429).json({ error: err.message, details: err.details });
                    return;
                }
                throw err;
            }
        });
        // ── Poll for a queued job result ─────────────────────────────────────────
        app.get('/api/jobs/:requestId', requireAuth, (req, res) => {
            const result = getJobResult(String(req.params.requestId));
            if (!result) {
                res.status(202).json({ status: 'pending' });
                return;
            }
            if (result.error) {
                res.status(500).json({ status: 'error', error: result.error });
                return;
            }
            res.json({ status: 'done', text: result.text });
        });
        // ── Register result callback for WS push ────────────────────────────────
        onJobResult((result) => {
            for (const client of this.clients.values()) {
                if (client.authenticated && client.ws.readyState === WebSocket.OPEN) {
                    client.ws.send(JSON.stringify({ type: 'job_result', ...result }));
                }
            }
        });
        // ── Prometheus metrics (protected by optional bearer token) ─────────────
        app.get('/metrics', async (req, res) => {
            const metricsToken = config.metrics?.token;
            if (metricsToken) {
                const bearer = req.headers.authorization ?? '';
                if (bearer !== `Bearer ${metricsToken}`) {
                    res.status(401).send('Unauthorized');
                    return;
                }
            }
            res.set('Content-Type', metricsRegister.contentType);
            res.end(await metricsRegister.metrics());
        });
        // ── Health check (public) ────────────────────────────────────────────────
        app.get('/health', (_req, res) => {
            res.json({ status: 'ok', uptime: process.uptime() });
        });
        // ── Detailed health endpoint (public — no secrets exposed) ───────────────
        app.get('/health/detailed', async (_req, res) => {
            const mem = process.memoryUsage();
            res.json({
                status: 'ok',
                uptime: process.uptime(),
                memory: {
                    rss: mem.rss,
                    heapUsed: mem.heapUsed,
                    heapTotal: mem.heapTotal,
                    external: mem.external,
                },
                skills: {
                    total: skillRegistry.list().length,
                    names: skillRegistry.list().map((s) => s.definition.name),
                },
                provider: {
                    default: config.defaultProvider,
                    model: config.defaultModel,
                },
                websocketClients: this.clients.size,
                tls: !!(config.tls?.certFile && config.tls?.keyFile),
                node: process.version,
                platform: process.platform,
                recentErrors: (await memoryStore.getRecentErrors(10)).map((e) => ({
                    level: e.level,
                    message: e.message,
                    ts: e.createdAt.toISOString(),
                })),
            });
        });
        // ── Status API (public — no secrets exposed) ─────────────────────────────
        app.get('/api/status', async (_req, res) => {
            const { degraded: embeddingDegraded, mode: embeddingMode } = getEmbeddingRuntimeOverview();
            const queueStats = extractionQueue.getStats();
            const runtimeOverview = getAgentRuntimeOverview();
            const activeRuns = getActiveAgentRunsOverview();
            // Calculate quota pressure (percentage of capacity used)
            const globalPressure = runtimeOverview.maxConcurrent > 0
                ? Math.round((runtimeOverview.active / runtimeOverview.maxConcurrent) * 100)
                : 0;
            const queuePressure = extractionQueue.isUnderPressure() ? 100 :
                Math.round((queueStats.queueSize / 50) * 100); // Assuming max queue size of 50
            // Calculate average execution time for active runs
            const now = Date.now();
            const activeRunDetails = activeRuns.runs.map((run) => ({
                runId: run.runId,
                userId: run.userId,
                channel: run.channel,
                label: run.label,
                taskId: run.taskId ?? null,
                workspaceId: run.workspaceId ?? null,
                agentId: run.agentId ?? null,
                startedAt: run.startedAt,
                runningMs: run.runningMs,
                cancellationPending: run.cancellationPending,
            }));
            const avgRunningMs = activeRunDetails.length > 0
                ? Math.round(activeRunDetails.reduce((sum, r) => sum + r.runningMs, 0) / activeRunDetails.length)
                : 0;
            const providerFallbacks = providerRegistry.getFallbackCount();
            const fallbackStats = {
                providerFallbacks,
                totalFallbacks: providerFallbacks,
            };
            res.json({
                status: 'running',
                skills: skillRegistry.list().length,
                provider: config.defaultProvider,
                model: config.defaultModel,
                embeddingDegraded,
                embeddingMode,
                memoryExtractionQueue: {
                    queueSize: queueStats.queueSize,
                    activeCount: queueStats.activeCount,
                    totalProcessed: queueStats.totalProcessed,
                    totalRejected: queueStats.totalRejected,
                    totalRetried: queueStats.totalRetried,
                    avgProcessingTimeMs: queueStats.avgProcessingTimeMs,
                    underPressure: extractionQueue.isUnderPressure(),
                    pressurePercent: queuePressure,
                },
                agentRuntime: {
                    active: runtimeOverview.active,
                    maxConcurrent: runtimeOverview.maxConcurrent,
                    maxConcurrentPerUser: runtimeOverview.maxConcurrentPerUser,
                    activeUsers: runtimeOverview.activeUsers,
                    totalRejectedGlobal: runtimeOverview.totalRejectedGlobal,
                    totalRejectedPerUser: runtimeOverview.totalRejectedPerUser,
                    busiestUsers: runtimeOverview.busiestUsers,
                    pressurePercent: globalPressure,
                },
                activeAgentRuns: {
                    total: activeRuns.activeRuns,
                    cancellationPending: activeRuns.cancellationPending,
                    stuckRuns: activeRunDetails.filter((r) => r.runningMs > 120_000 && !r.cancellationPending).length,
                    avgRunningMs,
                    runs: activeRunDetails,
                },
                fallbacks: fallbackStats,
                systemHealth: {
                    startedAt: _serverStartedAt,
                    uptimeMs: Date.now() - _serverStartedAt,
                    lastJobRunAt: await memoryStore.getLastJobRunTime(),
                    lastWorkflowRunAt: await memoryStore.getLastWorkflowRunTime(),
                },
                heartbeats: getHeartbeats(),
            });
        });
        // ── Execution Trace API ───────────────────────────────────────────────────
        app.get('/api/traces', requireAuth, (_req, res) => {
            const traces = getRecentTraces(20);
            const stats = getTraceStatistics();
            res.json({ traces, stats });
        });
        app.get('/api/traces/:traceId', requireAuth, (req, res) => {
            const trace = getTrace(String(req.params.traceId));
            if (!trace) {
                res.status(404).json({ error: 'Trace not found' });
                return;
            }
            res.json(trace);
        });
        // ── Performance metrics ────────────────────────────────────────────────────
        app.get('/api/performance', requireAuth, (_req, res) => {
            const traces = getRecentTraces(100);
            // Calculate performance metrics from traces
            const now = Date.now();
            const oneHourAgo = now - 3600000;
            const sixHoursAgo = now - 21600000;
            const oneDayAgo = now - 86400000;
            const recentTraces = {
                oneHour: traces.filter(t => t.startedAt >= oneHourAgo),
                sixHours: traces.filter(t => t.startedAt >= sixHoursAgo),
                oneDay: traces.filter(t => t.startedAt >= oneDayAgo),
            };
            // Provider latency metrics
            const providerLatencies = {};
            traces.forEach(trace => {
                trace.events.forEach(event => {
                    if (event.eventType === 'provider_call_complete' && event.data.durationMs) {
                        const provider = String(event.data.provider || 'unknown');
                        if (!providerLatencies[provider])
                            providerLatencies[provider] = [];
                        providerLatencies[provider].push(Number(event.data.durationMs));
                    }
                });
            });
            // Tool execution metrics
            const toolDurations = {};
            traces.forEach(trace => {
                trace.events.forEach(event => {
                    if (event.eventType === 'tool_call_complete' && event.data.durationMs) {
                        const tool = String(event.data.toolName || 'unknown');
                        if (!toolDurations[tool])
                            toolDurations[tool] = [];
                        toolDurations[tool].push(Number(event.data.durationMs));
                    }
                });
            });
            // Error rate over time (hourly buckets for last 24h)
            const errorBuckets = {};
            traces.forEach(trace => {
                const hourBucket = Math.floor(trace.startedAt / 3600000) * 3600000;
                if (!errorBuckets[hourBucket])
                    errorBuckets[hourBucket] = { total: 0, errors: 0 };
                errorBuckets[hourBucket].total++;
                if (trace.status === 'error')
                    errorBuckets[hourBucket].errors++;
            });
            res.json({
                recentTraces: {
                    oneHour: recentTraces.oneHour.length,
                    sixHours: recentTraces.sixHours.length,
                    oneDay: recentTraces.oneDay.length,
                },
                providerLatencies,
                toolDurations,
                errorBuckets,
                throughput: {
                    oneHour: recentTraces.oneHour.length,
                    sixHours: Math.round(recentTraces.sixHours.length / 6),
                    oneDay: Math.round(recentTraces.oneDay.length / 24),
                },
            });
        });
        // ── Prometheus metrics export ──────────────────────────────────────────────
        app.get('/metrics', (_req, res) => {
            const stats = getTraceStatistics();
            const traces = getRecentTraces(100);
            // Calculate runtime metrics
            const runtimeOverview = getAgentRuntimeOverview();
            const activeAgents = runtimeOverview.active;
            const maxAgents = runtimeOverview.maxConcurrent;
            const queueSize = 0;
            // Calculate provider metrics from traces
            const providerMetrics = {};
            traces.forEach(trace => {
                trace.events.forEach(event => {
                    if (event.eventType === 'provider_call_complete' || event.eventType === 'provider_call_error') {
                        const provider = String(event.data.provider || 'unknown');
                        if (!providerMetrics[provider]) {
                            providerMetrics[provider] = { calls: 0, errors: 0, totalLatency: 0 };
                        }
                        providerMetrics[provider].calls++;
                        if (event.eventType === 'provider_call_error') {
                            providerMetrics[provider].errors++;
                        }
                        if (event.data.durationMs) {
                            providerMetrics[provider].totalLatency += Number(event.data.durationMs);
                        }
                    }
                });
            });
            // Calculate tool metrics from traces
            const toolMetrics = {};
            traces.forEach(trace => {
                trace.events.forEach(event => {
                    if (event.eventType === 'tool_call_complete' || event.eventType === 'tool_call_error') {
                        const tool = String(event.data.toolName || 'unknown');
                        if (!toolMetrics[tool]) {
                            toolMetrics[tool] = { calls: 0, errors: 0, totalDuration: 0 };
                        }
                        toolMetrics[tool].calls++;
                        if (event.eventType === 'tool_call_error') {
                            toolMetrics[tool].errors++;
                        }
                        if (event.data.durationMs) {
                            toolMetrics[tool].totalDuration += Number(event.data.durationMs);
                        }
                    }
                });
            });
            // Build Prometheus text format
            const lines = [];
            // Runtime capacity metrics
            lines.push('# HELP greenfrog_runtime_active_agents Number of currently active agent runs');
            lines.push('# TYPE greenfrog_runtime_active_agents gauge');
            lines.push(`greenfrog_runtime_active_agents ${activeAgents}`);
            lines.push('# HELP greenfrog_runtime_max_agents Maximum concurrent agents allowed');
            lines.push('# TYPE greenfrog_runtime_max_agents gauge');
            lines.push(`greenfrog_runtime_max_agents ${maxAgents}`);
            lines.push('# HELP greenfrog_runtime_capacity_utilization Runtime capacity utilization ratio (0-1)');
            lines.push('# TYPE greenfrog_runtime_capacity_utilization gauge');
            lines.push(`greenfrog_runtime_capacity_utilization ${maxAgents > 0 ? activeAgents / maxAgents : 0}`);
            // Queue metrics
            lines.push('# HELP greenfrog_queue_size Number of items in the queue');
            lines.push('# TYPE greenfrog_queue_size gauge');
            lines.push(`greenfrog_queue_size ${queueSize}`);
            // Trace metrics
            lines.push('# HELP greenfrog_traces_total Total number of execution traces');
            lines.push('# TYPE greenfrog_traces_total counter');
            lines.push(`greenfrog_traces_total ${stats.totalTraces || 0}`);
            lines.push('# HELP greenfrog_traces_running Number of currently running traces');
            lines.push('# TYPE greenfrog_traces_running gauge');
            lines.push(`greenfrog_traces_running ${stats.runningTraces || 0}`);
            lines.push('# HELP greenfrog_traces_completed_total Total number of completed traces');
            lines.push('# TYPE greenfrog_traces_completed_total counter');
            lines.push(`greenfrog_traces_completed_total ${stats.completedTraces || 0}`);
            lines.push('# HELP greenfrog_traces_errors_total Total number of failed traces');
            lines.push('# TYPE greenfrog_traces_errors_total counter');
            lines.push(`greenfrog_traces_errors_total ${stats.errorTraces || 0}`);
            lines.push('# HELP greenfrog_traces_avg_duration_ms Average trace duration in milliseconds');
            lines.push('# TYPE greenfrog_traces_avg_duration_ms gauge');
            lines.push(`greenfrog_traces_avg_duration_ms ${stats.avgDurationMs || 0}`);
            // Provider metrics
            lines.push('# HELP greenfrog_provider_calls_total Total number of provider API calls');
            lines.push('# TYPE greenfrog_provider_calls_total counter');
            Object.entries(providerMetrics).forEach(([provider, metrics]) => {
                lines.push(`greenfrog_provider_calls_total{provider="${provider}"} ${metrics.calls}`);
            });
            lines.push('# HELP greenfrog_provider_errors_total Total number of provider API errors');
            lines.push('# TYPE greenfrog_provider_errors_total counter');
            Object.entries(providerMetrics).forEach(([provider, metrics]) => {
                lines.push(`greenfrog_provider_errors_total{provider="${provider}"} ${metrics.errors}`);
            });
            lines.push('# HELP greenfrog_provider_latency_ms_total Total provider API latency in milliseconds');
            lines.push('# TYPE greenfrog_provider_latency_ms_total counter');
            Object.entries(providerMetrics).forEach(([provider, metrics]) => {
                lines.push(`greenfrog_provider_latency_ms_total{provider="${provider}"} ${metrics.totalLatency}`);
            });
            // Tool metrics
            lines.push('# HELP greenfrog_tool_calls_total Total number of tool executions');
            lines.push('# TYPE greenfrog_tool_calls_total counter');
            Object.entries(toolMetrics).forEach(([tool, metrics]) => {
                lines.push(`greenfrog_tool_calls_total{tool="${tool}"} ${metrics.calls}`);
            });
            lines.push('# HELP greenfrog_tool_errors_total Total number of tool execution errors');
            lines.push('# TYPE greenfrog_tool_errors_total counter');
            Object.entries(toolMetrics).forEach(([tool, metrics]) => {
                lines.push(`greenfrog_tool_errors_total{tool="${tool}"} ${metrics.errors}`);
            });
            lines.push('# HELP greenfrog_tool_duration_ms_total Total tool execution duration in milliseconds');
            lines.push('# TYPE greenfrog_tool_duration_ms_total counter');
            Object.entries(toolMetrics).forEach(([tool, metrics]) => {
                lines.push(`greenfrog_tool_duration_ms_total{tool="${tool}"} ${metrics.totalDuration}`);
            });
            res.setHeader('Content-Type', 'text/plain; version=0.0.4');
            res.send(lines.join('\n') + '\n');
        });
        // ── Auto-scaling recommendations ───────────────────────────────────────────
        app.get('/api/scaling-recommendations', requireAuth, requireAdminAccess, (_req, res) => {
            const traces = getRecentTraces(100);
            const runtimeOverview = getAgentRuntimeOverview();
            // Analyze queue depth patterns
            const queueDepths = [];
            const now = Date.now();
            const oneDayAgo = now - 86400000;
            const recentTraces = traces.filter(t => t.startedAt >= oneDayAgo);
            // Calculate peak load times
            const hourlyLoad = {};
            recentTraces.forEach(trace => {
                const hour = new Date(trace.startedAt).getHours();
                hourlyLoad[hour] = (hourlyLoad[hour] || 0) + 1;
            });
            const peakHour = Object.entries(hourlyLoad).reduce((max, [hour, load]) => load > max.load ? { hour: parseInt(hour), load } : max, { hour: 0, load: 0 });
            // Calculate average agent utilization
            const maxAgents = runtimeOverview.maxConcurrent || 1;
            const avgActiveAgents = recentTraces.length > 0 ? recentTraces.length / 24 : 0;
            const utilization = avgActiveAgents / maxAgents;
            // Calculate provider quota pressure
            const quotaPressure = recentTraces.filter(t => t.events.some(e => e.eventType === 'provider_call_error' &&
                String(e.data.error || '').includes('quota'))).length / Math.max(recentTraces.length, 1);
            // Generate recommendations
            const recommendations = [];
            // Recommendation: Increase maxConcurrentAgents
            if (utilization > 0.8) {
                const suggestedMax = Math.ceil(maxAgents * 1.5);
                recommendations.push({
                    type: 'maxConcurrentAgents',
                    priority: 'high',
                    title: 'Increase Maximum Concurrent Agents',
                    description: `Current utilization is ${(utilization * 100).toFixed(1)}%. System is running near capacity during peak hours.`,
                    suggestedValue: suggestedMax,
                    currentValue: maxAgents,
                });
            }
            else if (utilization > 0.6) {
                const suggestedMax = Math.ceil(maxAgents * 1.25);
                recommendations.push({
                    type: 'maxConcurrentAgents',
                    priority: 'medium',
                    title: 'Consider Increasing Concurrent Agents',
                    description: `Current utilization is ${(utilization * 100).toFixed(1)}%. Consider increasing capacity for future growth.`,
                    suggestedValue: suggestedMax,
                    currentValue: maxAgents,
                });
            }
            // Recommendation: Adjust provider quotas
            if (quotaPressure > 0.1) {
                recommendations.push({
                    type: 'providerQuotas',
                    priority: 'high',
                    title: 'Increase Provider Quotas',
                    description: `${(quotaPressure * 100).toFixed(1)}% of recent calls hit quota limits. This is causing service degradation.`,
                    suggestedValue: 'Review and increase provider API quotas',
                });
            }
            // Recommendation: Optimize peak load handling
            if (peakHour.load > avgActiveAgents * 2) {
                recommendations.push({
                    type: 'peakLoadHandling',
                    priority: 'medium',
                    title: 'Optimize Peak Load Handling',
                    description: `Peak load at ${peakHour.hour}:00 is ${peakHour.load} requests, significantly higher than average. Consider load balancing or scheduling.`,
                    suggestedValue: `Peak hour: ${peakHour.hour}:00`,
                });
            }
            // Recommendation: Queue size optimization
            const avgQueueSize = 0;
            if (avgQueueSize > 20) {
                recommendations.push({
                    type: 'queueSize',
                    priority: 'medium',
                    title: 'Queue Backlog Detected',
                    description: `Current queue has ${avgQueueSize} items. Consider increasing concurrent agents or optimizing task processing.`,
                    currentValue: avgQueueSize,
                });
            }
            res.json({
                recommendations,
                metrics: {
                    utilization: (utilization * 100).toFixed(1) + '%',
                    avgActiveAgents: avgActiveAgents.toFixed(1),
                    maxAgents,
                    peakHour: peakHour.hour,
                    peakLoad: peakHour.load,
                    quotaPressure: (quotaPressure * 100).toFixed(1) + '%',
                    queueSize: avgQueueSize,
                },
            });
        });
        // ── Custom skills management ──────────────────────────────────────────────
        const customSkillsDir = join(config.dataDir, 'custom_skills');
        app.get('/api/plugins', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                mkdirSync(customSkillsDir, { recursive: true });
                const files = readdirSync(customSkillsDir)
                    .filter((f) => f.endsWith('.js'))
                    .map((f) => {
                    const st = statSync(join(customSkillsDir, f));
                    return { name: f.replace(/\.js$/, ''), size: st.size, updatedAt: st.mtime.toISOString() };
                });
                res.json({ plugins: files });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.put('/api/plugins/:name', requireAuth, requireAdminAccess, (req, res) => {
            const rawName = String(req.params.name);
            if (!/^[a-z0-9_]{1,50}$/.test(rawName)) {
                res.status(400).json({ error: 'Invalid skill name (use lowercase letters, numbers, underscores, max 50 chars)' });
                return;
            }
            const { code } = req.body;
            if (!code || typeof code !== 'string') {
                res.status(400).json({ error: 'code is required' });
                return;
            }
            if (code.length > 50 * 1024) {
                res.status(400).json({ error: 'Skill code too large (max 50KB)' });
                return;
            }
            // Security scan before saving
            const vetResult = vetCode(code);
            if (vetResult.blocked) {
                res.status(400).json({
                    error: `Plugin rejected (risk: ${vetResult.risk}, score: ${vetResult.score}/100): ${vetResult.summary}`,
                    findings: vetResult.findings.slice(0, 5),
                });
                return;
            }
            try {
                mkdirSync(customSkillsDir, { recursive: true });
                writeFileSync(join(customSkillsDir, `${rawName}.js`), code, 'utf8');
                res.json({ ok: true, risk: vetResult.risk, score: vetResult.score });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/plugins/:name', requireAuth, requireAdminAccess, (req, res) => {
            const rawName = String(req.params.name);
            if (!/^[a-z0-9_]{1,50}$/.test(rawName)) {
                res.status(400).json({ error: 'Invalid skill name' });
                return;
            }
            const filePath = join(customSkillsDir, `${rawName}.js`);
            if (!existsSync(filePath)) {
                res.status(404).json({ error: 'Skill not found' });
                return;
            }
            try {
                unlinkSync(filePath);
                res.json({ ok: true });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Plugin Marketplace (MVP) ───────────────────────────────────────────────
        app.get('/api/marketplace/plugins', requireAuth, (_req, res) => {
            try {
                const plugins = getMarketplacePlugins();
                res.json({ plugins });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/marketplace/plugins/:id', requireAuth, (req, res) => {
            try {
                const plugin = getMarketplacePlugin(String(req.params.id));
                if (!plugin) {
                    res.status(404).json({ error: 'Plugin not found' });
                    return;
                }
                res.json({ plugin });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/marketplace/search', requireAuth, (req, res) => {
            try {
                const query = String(req.query.q || '');
                const plugins = searchMarketplacePlugins(query);
                res.json({ plugins });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/marketplace/plugins/:id/install', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const plugin = getMarketplacePlugin(String(req.params.id));
                if (!plugin) {
                    res.status(404).json({ error: 'Plugin not found' });
                    return;
                }
                // Fetch plugin code from sourceUrl
                const response = await fetch(plugin.sourceUrl);
                if (!response.ok) {
                    res.status(500).json({ error: 'Failed to download plugin' });
                    return;
                }
                const code = await response.text();
                // Security scan before installing
                const vetResult = vetCode(code);
                if (vetResult.blocked) {
                    res.status(400).json({
                        error: `Plugin rejected (risk: ${vetResult.risk}, score: ${vetResult.score}/100)`,
                        findings: vetResult.findings.slice(0, 5),
                    });
                    return;
                }
                // Save to custom_skills directory
                mkdirSync(customSkillsDir, { recursive: true });
                const filename = `${plugin.id}.js`;
                writeFileSync(join(customSkillsDir, filename), code, 'utf8');
                res.json({
                    ok: true,
                    plugin: plugin.name,
                    risk: vetResult.risk,
                    score: vetResult.score,
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Billing & Subscription Management (MVP) ───────────────────────────────
        app.get('/api/billing/tiers', requireAuth, (_req, res) => {
            try {
                const tiers = getSubscriptionTiers();
                res.json({ tiers });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/billing/tiers/:id', requireAuth, (req, res) => {
            try {
                const tier = getSubscriptionTier(String(req.params.id));
                if (!tier) {
                    res.status(404).json({ error: 'Tier not found' });
                    return;
                }
                res.json({ tier });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/billing/usage/:userId', requireAuth, async (req, res) => {
            try {
                const userId = String(req.params.userId);
                const period = String(req.query.period || new Date().toISOString().slice(0, 7)); // YYYY-MM
                // Get token usage for the period
                const [year, month] = period.split('-').map(Number);
                const startDate = new Date(year, month - 1, 1);
                const endDate = new Date(year, month, 0, 23, 59, 59);
                const allRecords = await memoryStore.getTokenUsageDetail({ userId, limit: 10000 });
                const usageRecords = allRecords.filter((r) => r.recordedAt >= startDate && r.recordedAt <= endDate);
                // Calculate totals and breakdown
                let totalTokens = 0;
                let totalCostUsd = 0;
                const breakdown = new Map();
                for (const record of usageRecords) {
                    totalTokens += record.totalTokens;
                    totalCostUsd += record.costUsd || 0;
                    const key = `${record.provider}:${record.model}`;
                    const existing = breakdown.get(key);
                    if (existing) {
                        existing.tokens += record.totalTokens;
                        existing.costUsd += record.costUsd || 0;
                    }
                    else {
                        breakdown.set(key, {
                            provider: record.provider,
                            model: record.model,
                            tokens: record.totalTokens,
                            costUsd: record.costUsd || 0,
                        });
                    }
                }
                res.json({
                    userId,
                    period,
                    totalTokens,
                    totalCostUsd,
                    apiCalls: usageRecords.length,
                    breakdown: Array.from(breakdown.values()),
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/billing/check-limits', requireAuth, async (req, res) => {
            try {
                const { tierId, usage } = req.body;
                const tier = getSubscriptionTier(tierId);
                if (!tier) {
                    res.status(404).json({ error: 'Tier not found' });
                    return;
                }
                const result = checkTierLimits(tier, usage);
                res.json(result);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Plugin manifest & enable/disable ──────────────────────────────────────
        app.get('/api/plugins/:name/manifest', requireAuth, requireAdminAccess, async (req, res) => {
            const name = String(req.params.name);
            try {
                const manifestPath = join(customSkillsDir, '.skill-manifest.json');
                if (!existsSync(manifestPath))
                    return res.json({ manifest: null });
                const manifest = JSON.parse(readFileSync(manifestPath, 'utf-8'));
                const skillManifest = manifest[name];
                if (!skillManifest)
                    return res.json({ manifest: null });
                res.json({ manifest: skillManifest });
            }
            catch (err) {
                res.status(500).json({ error: 'Failed to read manifest' });
            }
        });
        app.post('/api/plugins/:name/enable', requireAuth, requireAdminAccess, async (req, res) => {
            const name = req.params.name;
            try {
                const skillPath = join(customSkillsDir, `${name}.js`);
                if (!existsSync(skillPath))
                    return res.status(404).json({ error: 'Skill not found' });
                res.json({ enabled: true, name });
            }
            catch (err) {
                res.status(500).json({ error: 'Failed to enable plugin' });
            }
        });
        app.post('/api/plugins/:name/disable', requireAuth, requireAdminAccess, async (req, res) => {
            const name = req.params.name;
            try {
                res.json({ disabled: true, name });
            }
            catch (err) {
                res.status(500).json({ error: 'Failed to disable plugin' });
            }
        });
        // ── Dashboard API ─────────────────────────────────────────────────────────
        app.get('/api/dashboard', requireAuth, async (req, res) => {
            try {
                const scopedUserId = getScopedUserId(req);
                const adminView = !scopedUserId;
                const queue = getQueue();
                const [jobs, patrols, workflows, recentAudit, allAgents, allTeamTasks, recentErrors, ruleSummary, queueCounts,] = await Promise.all([
                    memoryStore.getJobs(scopedUserId),
                    memoryStore.getPatrolChecks(scopedUserId),
                    memoryStore.getWorkflows(scopedUserId),
                    memoryStore.queryAuditLog({
                        limit: 5,
                        ...(scopedUserId ? { userId: scopedUserId } : {}),
                    }),
                    memoryStore.listAgents(),
                    memoryStore.listTeamTasks(),
                    scopedUserId ? Promise.resolve([]) : memoryStore.getRecentErrors(5),
                    adminView ? memoryStore.summarizeBehavioralRules() : Promise.resolve(null),
                    adminView && queue
                        ? queue.getJobCounts('waiting', 'active', 'delayed', 'prioritized', 'completed', 'failed')
                        : Promise.resolve(null),
                ]);
                const skills = skillRegistry.list();
                const skillStats = scopedUserId ? [] : (await memoryStore.getSkillStats()).slice(0, 10);
                const visibleAgents = scopedUserId
                    ? allAgents.filter((agentDef) => agentDef.ownerUserId === scopedUserId)
                    : allAgents;
                const visibleAgentIds = new Set(visibleAgents.map((agentDef) => agentDef.id));
                const visibleTeamTasks = scopedUserId
                    ? allTeamTasks.filter((task) => task.createdBy === scopedUserId
                        || task.humanOwnerUserId === scopedUserId
                        || (task.assignedAgentId ? visibleAgentIds.has(task.assignedAgentId) : false))
                    : allTeamTasks;
                const runtimeSummary = adminView
                    ? {
                        scope: 'admin',
                        global: getAgentRuntimeOverview(),
                        runs: getActiveAgentRunsOverview(),
                        limits: {
                            maxIterations: config.agentMaxIterations ?? 10,
                            maxExecutionMs: config.agentMaxExecutionMs ?? 120000,
                            skillTimeoutMs: config.skillTimeoutMs ?? 60000,
                        },
                    }
                    : {
                        scope: 'user',
                        currentUser: getAgentRuntimeSnapshot(scopedUserId, 'web'),
                        limits: {
                            maxIterations: config.agentMaxIterations ?? 10,
                            maxExecutionMs: config.agentMaxExecutionMs ?? 120000,
                            skillTimeoutMs: config.skillTimeoutMs ?? 60000,
                        },
                    };
                const queueSummary = adminView
                    ? {
                        enabled: Boolean(queue),
                        counts: {
                            waiting: queueCounts?.waiting ?? 0,
                            active: queueCounts?.active ?? 0,
                            delayed: queueCounts?.delayed ?? 0,
                            prioritized: queueCounts?.prioritized ?? 0,
                            completed: queueCounts?.completed ?? 0,
                            failed: queueCounts?.failed ?? 0,
                        },
                    }
                    : null;
                const quotaReservationSummary = adminView ? getQuotaReservationOverview() : null;
                const ruleMaintenanceSummary = adminView ? getBehavioralRuleMaintenanceOverview() : null;
                const embeddingSummary = getEmbeddingRuntimeOverview();
                res.json({
                    uptime: process.uptime(),
                    skills: skills.length,
                    activeJobs: jobs.filter(j => j.status === 'active').length,
                    activePatrols: patrols.filter(p => p.status === 'active').length,
                    activeWorkflows: workflows.filter(w => w.status === 'active').length,
                    recentAudit,
                    recentErrors,
                    skillStats,
                    heartbeatSummary: summarizeDashboardHeartbeat(visibleAgents),
                    teamProgressSummary: summarizeDashboardTeamProgress(visibleTeamTasks, visibleAgents),
                    protocolSummary: summarizeDashboardProtocol(visibleTeamTasks),
                    governanceSummary: summarizeDashboardGovernance(visibleTeamTasks),
                    memoryVersion: config.memory?.enabled ? 'enabled' : 'disabled',
                    runtimeSummary,
                    queueSummary,
                    quotaReservationSummary,
                    ruleSummary,
                    ruleMaintenanceSummary,
                    embeddingSummary,
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Audit API ─────────────────────────────────────────────────────────────
        app.post('/api/admin/runtime/runs/:runId/cancel', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const runId = String(req.params.runId ?? '').trim();
                if (!runId) {
                    res.status(400).json({ error: 'runId is required' });
                    return;
                }
                const body = (req.body ?? {});
                const reason = typeof body['reason'] === 'string' && body['reason'].trim()
                    ? body['reason'].trim().slice(0, 500)
                    : 'Cancelled from admin dashboard';
                const accepted = cancelAgentRun(runId, reason);
                const updatedRun = getAgentRun(runId);
                if (!accepted || !updatedRun) {
                    logAdminAudit(req, 'admin.runtime_run.cancel', { runId, reason }, false, 'run not found');
                    res.status(404).json({ error: 'run not found', runId });
                    return;
                }
                logAdminAudit(req, 'admin.runtime_run.cancel', {
                    runId,
                    reason,
                    userId: updatedRun.userId,
                    channel: updatedRun.channel,
                    label: updatedRun.label,
                });
                res.json({
                    ok: true,
                    runId,
                    run: updatedRun,
                    overview: getActiveAgentRunsOverview(),
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-protocol', requireAuth, async (req, res) => {
            try {
                const scopedUserId = getScopedUserId(req);
                const [allAgents, allTeamTasks] = await Promise.all([
                    memoryStore.listAgents(),
                    memoryStore.listTeamTasks(),
                ]);
                const visibleAgents = scopedUserId
                    ? allAgents.filter((agentDef) => agentDef.ownerUserId === scopedUserId)
                    : allAgents;
                const visibleAgentIds = new Set(visibleAgents.map((agentDef) => agentDef.id));
                const visibleTeamTasks = scopedUserId
                    ? allTeamTasks.filter((task) => task.createdBy === scopedUserId
                        || task.humanOwnerUserId === scopedUserId
                        || (task.assignedAgentId ? visibleAgentIds.has(task.assignedAgentId) : false))
                    : allTeamTasks;
                res.json({ protocolSummary: summarizeDashboardProtocol(visibleTeamTasks) });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-governance', requireAuth, async (req, res) => {
            try {
                const actorUserId = String(req.authUser?.sub ?? '').trim() || null;
                const admin = isAdminUser(req.authUser);
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId.trim() : '';
                const status = parseTeamTaskStatus(req.query.status);
                const actionFilter = req.query.action === 'write' || req.query.action === 'rollback' ? req.query.action : null;
                const approvalStatusFilter = req.query.approvalStatus === 'pending' || req.query.approvalStatus === 'approved' || req.query.approvalStatus === 'rejected'
                    ? req.query.approvalStatus
                    : null;
                const executionStatusFilter = req.query.executionStatus === 'pending' || req.query.executionStatus === 'applied' || req.query.executionStatus === 'failed'
                    ? req.query.executionStatus
                    : null;
                const tasks = await memoryStore.listTeamTasks(workspaceId ? { workspaceId } : undefined);
                const governance = tasks
                    .filter((task) => canViewGovernanceTask(task, actorUserId, admin))
                    .map((task) => summarizeDashboardGovernanceTask(task))
                    .filter((task) => Boolean(task))
                    .filter((task) => !status || task.status === status)
                    .filter((task) => !actionFilter || task.action === actionFilter)
                    .filter((task) => !approvalStatusFilter || task.approvalStatus === approvalStatusFilter)
                    .filter((task) => !executionStatusFilter || task.executionStatus === executionStatusFilter)
                    .sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
                res.json({
                    governance,
                    summary: {
                        total: governance.length,
                        pendingApproval: governance.filter((task) => task.approvalStatus === 'pending').length,
                        approvedPendingExecution: governance.filter((task) => task.approvalStatus === 'approved' && task.executionStatus !== 'applied').length,
                        failedExecution: governance.filter((task) => task.executionStatus === 'failed').length,
                    },
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/audit', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const limit = Math.min(parseInt(req.query.limit) || 50, 200);
                const skillName = req.query.skill;
                const userId = req.query.userId;
                const entries = await memoryStore.queryAuditLog({ limit, skillName, userId });
                // Apply additional filters (client-side for now, can be moved to DB later)
                let filtered = entries;
                // Filter by success status
                const successFilter = req.query.success;
                if (successFilter === 'true') {
                    filtered = filtered.filter(e => e.success);
                }
                else if (successFilter === 'false') {
                    filtered = filtered.filter(e => !e.success);
                }
                // Filter by time range
                const startTime = req.query.startTime ? parseInt(req.query.startTime) : undefined;
                const endTime = req.query.endTime ? parseInt(req.query.endTime) : undefined;
                if (startTime) {
                    filtered = filtered.filter(e => new Date(e.timestamp).getTime() >= startTime);
                }
                if (endTime) {
                    filtered = filtered.filter(e => new Date(e.timestamp).getTime() <= endTime);
                }
                // Export format
                const format = req.query.format;
                if (format === 'csv') {
                    const csv = [
                        'Timestamp,Skill,User,Role,Success,Duration (ms),Params',
                        ...filtered.map(e => `"${new Date(e.timestamp).toISOString()}","${e.skillName}","${e.userId}","${e.role || ''}","${e.success}","${e.durationMs}","${JSON.stringify(e.params || {}).replace(/"/g, '""')}"`)
                    ].join('\n');
                    res.setHeader('Content-Type', 'text/csv');
                    res.setHeader('Content-Disposition', `attachment; filename="audit-log-${Date.now()}.csv"`);
                    return res.send(csv);
                }
                else if (format === 'json') {
                    res.setHeader('Content-Type', 'application/json');
                    res.setHeader('Content-Disposition', `attachment; filename="audit-log-${Date.now()}.json"`);
                    return res.json(filtered);
                }
                res.json({ entries: filtered, limit, total: filtered.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Patrol API ────────────────────────────────────────────────────────────
        app.get('/api/admin/evolution-status', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                res.json(buildProjectEvolutionStatus(config));
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/admin/evolution-actions', requireAuth, requireAdminAccess, async (req, res) => {
            const body = (req.body ?? {});
            const alertId = typeof body.alertId === 'string' ? body.alertId.trim() : '';
            const actionId = typeof body.actionId === 'string' ? body.actionId.trim() : '';
            let actionKindForError = null;
            if (!alertId || !actionId) {
                res.status(400).json({ error: 'alertId and actionId are required' });
                return;
            }
            try {
                const status = buildProjectEvolutionStatus(config);
                const alert = (status.activeGateAlerts ?? []).find((item) => item.id === alertId);
                if (!alert) {
                    res.status(404).json({ error: 'Active gate alert not found or already resolved' });
                    return;
                }
                const repairAction = (alert.repairActions ?? []).find((item) => item.id === actionId);
                if (!repairAction) {
                    res.status(404).json({ error: 'Repair action not found for active alert' });
                    return;
                }
                actionKindForError = repairAction.kind;
                const fingerprint = repairAction.kind === 'record_recovery_signal'
                    ? buildProjectEvolutionAdminActionFingerprint({
                        title: typeof body.title === 'string' ? body.title.trim() : '',
                        summary: typeof body.summary === 'string' ? body.summary.trim() : '',
                        source: typeof body.source === 'string' ? body.source.trim() : '',
                        priority: body.priority === 'critical' || body.priority === 'high' || body.priority === 'medium'
                            ? body.priority
                            : 'high',
                        details: typeof body.details === 'object' && body.details !== null
                            ? body.details
                            : {},
                    })
                    : null;
                const safety = evaluateProjectEvolutionAdminActionSafety({
                    repoPath: alert.repoPath,
                    kind: repairAction.kind,
                    actionId,
                    fingerprint,
                });
                if (!safety.allowed) {
                    recordProjectEvolutionAdminActionOutcome({
                        repoPath: alert.repoPath,
                        kind: repairAction.kind,
                        actionId,
                        status: safety.outcome.status,
                        category: safety.outcome.category,
                        message: safety.outcome.message,
                        fingerprint,
                    });
                    logAdminAudit(req, 'admin.project_evolution.action.blocked', {
                        alertId,
                        actionId,
                        actionKind: repairAction.kind,
                        alertScope: alert.scope,
                        repoPath: alert.repoPath,
                        category: safety.outcome.category,
                    }, false, safety.outcome.message);
                    res.status(409).json({
                        ok: false,
                        error: safety.outcome.message,
                        actionOutcome: safety.outcome,
                        status,
                    });
                    return;
                }
                let result;
                if (repairAction.kind === 'rerun_gate_monitor') {
                    result = {
                        activeAlerts: rerunProjectEvolutionGateMonitor(config),
                    };
                }
                else if (repairAction.kind === 'rerun_release') {
                    const { releaseConfig } = resolveProjectEvolutionWebConfigs(config);
                    result = await generateProjectRelease(releaseConfig);
                }
                else if (repairAction.kind === 'check_upgrade') {
                    const { upgradeConfig } = resolveProjectEvolutionWebConfigs(config);
                    result = await checkForProjectUpgrade(upgradeConfig);
                }
                else if (repairAction.kind === 'record_recovery_signal') {
                    const signalKind = repairAction.signalKind;
                    if (!signalKind) {
                        res.status(400).json({ error: 'Repair action is missing signal kind metadata' });
                        return;
                    }
                    const title = typeof body.title === 'string' ? body.title.trim() : '';
                    const summary = typeof body.summary === 'string' ? body.summary.trim() : '';
                    const source = typeof body.source === 'string' ? body.source.trim() : '';
                    if (!title || !summary || !source) {
                        res.status(400).json({ error: 'title, summary, and source are required for recovery signals' });
                        return;
                    }
                    const priority = body.priority === 'critical' || body.priority === 'high' || body.priority === 'medium'
                        ? body.priority
                        : 'high';
                    const details = typeof body.details === 'object' && body.details !== null
                        ? body.details
                        : {};
                    result = recordProjectEvolutionRecoverySignalWithPolicy(alert.repoPath, {
                        id: nanoid(),
                        kind: signalKind,
                        priority,
                        createdAt: new Date().toISOString(),
                        passed: true,
                        title,
                        summary,
                        source,
                        details,
                    });
                }
                else {
                    res.status(400).json({ error: `Unsupported repair action: ${repairAction.kind}` });
                    return;
                }
                rerunProjectEvolutionGateMonitor(config);
                const nextStatus = buildProjectEvolutionStatus(config);
                const actionOutcome = classifyProjectEvolutionAdminActionResult({
                    kind: repairAction.kind,
                    result,
                });
                recordProjectEvolutionAdminActionOutcome({
                    repoPath: alert.repoPath,
                    kind: repairAction.kind,
                    actionId,
                    status: actionOutcome.status,
                    category: actionOutcome.category,
                    message: actionOutcome.message,
                    fingerprint,
                });
                if (Array.isArray(config.roles?.admin) && config.roles.admin.length > 0) {
                    try {
                        const notificationActionUrl = config.webui?.enabled !== false
                            ? `http://${config.webui.host}:${config.webui.port}/`
                            : null;
                        const actionRecord = readProjectEvolutionAdminActionLog(alert.repoPath).entries
                            .find((entry) => entry.actionId === actionId && entry.kind === repairAction.kind) ?? null;
                        await emitProjectEvolutionAdminActionNotification({
                            alert,
                            actionKind: repairAction.kind,
                            actionId,
                            outcome: actionOutcome,
                            record: actionRecord,
                            actorUserId: req.authUser?.sub ?? null,
                            cfg: {
                                adminPrincipals: config.roles.admin,
                                workspaceId: 'project-evolution-private',
                                actionUrl: notificationActionUrl,
                            },
                        });
                    }
                    catch (notificationErr) {
                        this.log.warn({ err: String(notificationErr), actionId, actionKind: repairAction.kind }, 'Failed to deliver private admin action notification');
                    }
                }
                logAdminAudit(req, `admin.project_evolution.${repairAction.kind}`, {
                    alertId,
                    actionId,
                    actionKind: repairAction.kind,
                    alertScope: alert.scope,
                    repoPath: alert.repoPath,
                    actionStatus: actionOutcome.status,
                    actionCategory: actionOutcome.category,
                });
                res.json({
                    ok: true,
                    alertId,
                    actionId,
                    actionKind: repairAction.kind,
                    actionOutcome,
                    result,
                    status: nextStatus,
                });
            }
            catch (err) {
                const message = err instanceof Error ? err.message : String(err);
                const errorOutcome = classifyProjectEvolutionAdminActionResult({
                    kind: actionKindForError === 'rerun_release'
                        || actionKindForError === 'check_upgrade'
                        || actionKindForError === 'record_recovery_signal'
                        || actionKindForError === 'rerun_gate_monitor'
                        ? actionKindForError
                        : 'rerun_gate_monitor',
                    error: err,
                });
                const status = buildProjectEvolutionStatus(config);
                if (status.activeGateAlerts.some((item) => item.id === alertId)) {
                    const alert = status.activeGateAlerts.find((item) => item.id === alertId);
                    const repairAction = alert?.repairActions?.find((item) => item.id === actionId);
                    if (alert && repairAction) {
                        recordProjectEvolutionAdminActionOutcome({
                            repoPath: alert.repoPath,
                            kind: repairAction.kind,
                            actionId,
                            status: errorOutcome.status,
                            category: errorOutcome.category,
                            message,
                        });
                    }
                }
                logAdminAudit(req, 'admin.project_evolution.action', {
                    alertId,
                    actionId,
                }, false, message);
                res.status(500).json({ error: message, actionOutcome: errorOutcome });
            }
        });
        app.get('/api/patrols', requireAuth, async (req, res) => {
            try {
                const checks = await memoryStore.getPatrolChecks(getScopedUserId(req));
                res.json({ checks });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/patrols/:id/results', requireAuth, async (req, res) => {
            try {
                const scopedUserId = getScopedUserId(req);
                if (scopedUserId) {
                    const ownedChecks = await memoryStore.getPatrolChecks(scopedUserId);
                    if (!ownedChecks.some((check) => check.id === String(req.params.id))) {
                        return res.status(403).json({ error: 'Forbidden: patrol check does not belong to you.' });
                    }
                }
                const limit = Math.min(parseInt(req.query.limit) || 50, 200);
                const results = await memoryStore.getPatrolHistory(String(req.params.id), limit);
                res.json({ results });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Workflow API ──────────────────────────────────────────────────────────
        app.get('/api/workflows', requireAuth, async (req, res) => {
            try {
                const workflows = await memoryStore.getWorkflows(getScopedUserId(req));
                res.json({ workflows });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Scheduled jobs list (for Task Center UI) ──────────────────────────────
        app.get('/api/scheduled-jobs', requireAuth, async (req, res) => {
            try {
                const jobs = await memoryStore.getJobs(getScopedUserId(req));
                res.json({ jobs });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Memory API ────────────────────────────────────────────────────────────
        app.get('/api/memory/:userId', requireAuth, requireSelfOrAdmin, async (req, res) => {
            try {
                const channel = req.query.channel || 'web';
                const userId = String(req.params.userId);
                // Extraction writes to scoped_memory (null workspace/agent scope); read from there.
                // Also merge legacy memory table so manually set entries still appear.
                const scopedEntries = await memoryStore.getAllScopedMemory({ userId, channel: channel });
                const flatEntries = await memoryStore.getAllMemory(userId, channel);
                const entries = { ...flatEntries, ...scopedEntries }; // scoped wins on key conflict
                const entities = await memoryStore.getEntities(userId, channel);
                res.json({ entries, entities });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // GET /api/memory/:userId/history
        app.get('/api/memory/:userId/history', requireAuth, requireSelfOrAdmin, async (req, res) => {
            try {
                const userId = String(req.params.userId);
                const channel = req.query.channel || 'web';
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const agentId = typeof req.query.agentId === 'string' ? req.query.agentId : undefined;
                const limit = Math.min(parseInt(req.query.limit) || 50, 200);
                const history = (workspaceId || agentId)
                    ? await memoryStore.getScopedMemoryHistory({ userId, channel: channel, workspaceId, agentId }, limit)
                    : await memoryStore.getMemoryHistory(userId, channel, limit);
                res.json({ history });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // POST /api/memory/:userId/rollback
        app.post('/api/memory/:userId/rollback', requireAuth, requireSelfOrAdmin, async (req, res) => {
            try {
                const userId = String(req.params.userId);
                const channel = req.body?.channel || 'web';
                const workspaceId = typeof req.body?.workspaceId === 'string'
                    ? req.body.workspaceId
                    : undefined;
                const agentId = typeof req.body?.agentId === 'string'
                    ? req.body.agentId
                    : undefined;
                const historyId = req.body?.historyId;
                if (!historyId)
                    return res.status(400).json({ error: 'historyId required' });
                const ok = (workspaceId || agentId)
                    ? await memoryStore.rollbackScopedMemory({ userId, channel: channel, workspaceId, agentId }, historyId)
                    : await memoryStore.rollbackMemory(userId, channel, historyId);
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // DELETE /api/memory/:userId/:key
        app.delete('/api/memory/:userId/:key', requireAuth, requireSelfOrAdmin, async (req, res) => {
            try {
                const userId = String(req.params.userId);
                const key = String(req.params.key);
                const channel = req.query.channel || 'web';
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const agentId = typeof req.query.agentId === 'string' ? req.query.agentId : undefined;
                // Always use scoped path — extraction writes to scoped_memory, not memory table.
                const scope = { userId, channel: channel, workspaceId, agentId };
                const oldValue = await memoryStore.getScopedMemory(scope, key)
                    ?? await memoryStore.getMemory(userId, channel, key);
                if (oldValue !== null) {
                    await memoryStore.recordScopedMemoryChange(scope, key, oldValue, '', 'manual');
                }
                // Delete from both tables — same key may exist in both; avoid "deleted but resurfaces" bug.
                const okScoped = await memoryStore.deleteScopedMemory(scope, key);
                const okFlat = await memoryStore.deleteMemory(userId, channel, key);
                const ok = okScoped || okFlat;
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Skills API ────────────────────────────────────────────────────────────
        app.get('/api/agents', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                let agents = await memoryStore.listAgents(workspaceId);
                // Fallback: if workspace-scoped query returns nothing, return all agents
                // (agents in DB may have null workspaceId — personal version uses all agents)
                if (workspaceId && agents.length === 0) {
                    agents = await memoryStore.listAgents(undefined);
                }
                res.json({ agents });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/agents', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const name = String(body.name ?? '').trim();
                const workspaceId = String(body.workspaceId ?? '').trim();
                if (!name || !workspaceId) {
                    res.status(400).json({ error: 'name and workspaceId are required' });
                    return;
                }
                const agent = await memoryStore.createAgent({
                    name,
                    workspaceId,
                    ownerUserId: String(body.ownerUserId ?? req.authUser?.sub ?? getStableWebId()),
                    description: typeof body.description === 'string' ? body.description : undefined,
                    status: body.status === 'paused' ? 'paused' : 'active',
                    memoryScope: body.memoryScope === 'workspace' || body.memoryScope === 'user' ? body.memoryScope : 'agent',
                    provider: typeof body.provider === 'string' ? body.provider : undefined,
                    model: typeof body.model === 'string' ? body.model : undefined,
                    systemPrompt: typeof body.systemPrompt === 'string' ? body.systemPrompt : undefined,
                    metadata: typeof body.metadata === 'object' && body.metadata !== null ? body.metadata : undefined,
                });
                res.status(201).json({ agent });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/agents/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const agent = await memoryStore.updateAgent(String(req.params.id), {
                    ...(typeof body.name === 'string' ? { name: body.name } : {}),
                    ...(typeof body.description === 'string' ? { description: body.description } : {}),
                    ...(body.status === 'active' || body.status === 'paused' ? { status: body.status } : {}),
                    ...(body.memoryScope === 'user' || body.memoryScope === 'workspace' || body.memoryScope === 'agent'
                        ? { memoryScope: body.memoryScope }
                        : {}),
                    ...(body.provider === null || typeof body.provider === 'string' ? { provider: body.provider } : {}),
                    ...(body.model === null || typeof body.model === 'string' ? { model: body.model } : {}),
                    ...(typeof body.systemPrompt === 'string' ? { systemPrompt: body.systemPrompt } : {}),
                    ...(typeof body.metadata === 'object' && body.metadata !== null ? { metadata: body.metadata } : {}),
                });
                if (!agent) {
                    res.status(404).json({ error: 'Agent not found' });
                    return;
                }
                res.json({ agent });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/heartbeat/agents', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const agents = await memoryStore.listAgents(workspaceId);
                res.json({ agents: agents.map((agentDef) => summarizeHeartbeatAgent(agentDef)) });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/heartbeat/agents/:id/reset', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const agentDef = await memoryStore.getAgent(String(req.params.id));
                if (!agentDef) {
                    res.status(404).json({ error: 'Agent not found' });
                    return;
                }
                const metadata = {
                    ...(agentDef.metadata ?? {}),
                    heartbeatFailureCount: 0,
                    heartbeatPausedBySystem: false,
                    heartbeatCircuitOpenUntil: null,
                    lastHeartbeatStatus: 'recovered',
                    lastHeartbeatError: null,
                    lastHeartbeatSummary: 'Manual heartbeat reset',
                    lastHeartbeatAt: new Date().toISOString(),
                };
                const updated = await memoryStore.updateAgent(agentDef.id, {
                    status: 'active',
                    metadata,
                });
                res.json({ agent: updated ? summarizeHeartbeatAgent(updated) : null });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/agents/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const ok = await memoryStore.deleteAgent(String(req.params.id));
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/agent-bindings', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const bindings = await memoryStore.listAgentBindings({
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(typeof req.query.agentId === 'string' ? { agentId: req.query.agentId } : {}),
                    ...(typeof req.query.channel === 'string' ? { channel: req.query.channel } : {}),
                });
                res.json({ bindings });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/agent-bindings', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const agentId = String(body.agentId ?? '').trim();
                const workspaceId = String(body.workspaceId ?? '').trim();
                const channel = String(body.channel ?? 'web').trim();
                if (!agentId || !workspaceId || !channel) {
                    res.status(400).json({ error: 'agentId, workspaceId, and channel are required' });
                    return;
                }
                const binding = await memoryStore.createAgentBinding({
                    agentId,
                    workspaceId,
                    channel,
                    userId: typeof body.userId === 'string' ? body.userId : undefined,
                    chatId: typeof body.chatId === 'string' ? body.chatId : undefined,
                });
                res.status(201).json({ binding });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/agent-bindings/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const ok = await memoryStore.deleteAgentBinding(String(req.params.id));
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-tasks', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const tasks = await memoryStore.listTeamTasks({
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(parseTeamTaskStatus(req.query.status) ? { status: parseTeamTaskStatus(req.query.status) } : {}),
                    ...(typeof req.query.assignedAgentId === 'string' ? { assignedAgentId: req.query.assignedAgentId } : {}),
                });
                res.json({ tasks });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Natural Language Task Draft ───────────────────────────────────────────
        app.post('/api/team-tasks/draft', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const rawText = typeof body.text === 'string' ? body.text.trim() : '';
                const workspaceId = typeof body.workspaceId === 'string' ? body.workspaceId.trim() : 'personal';
                if (!rawText) {
                    res.status(400).json({ error: 'text is required' });
                    return;
                }
                // ── Classification: chat vs task (multi-signal, not just keyword hit) ──
                //
                // Signals that strongly indicate a TASK:
                //   1. Starts with a command/action prefix ("帮我", "请", "把", "翻译", ...)
                //   2. Contains an action verb anywhere ("分析", "生成", "写", ...)
                //
                // Only classify as CHAT when:
                //   - No task starter AND no action verb
                //   - AND at least one question signal present (ends with ？/吗 OR contains question word)
                //
                // Default fallback = task (better to create a task than silently drop intent)
                const taskStarterPrefixes = ['帮我', '帮', '请帮', '请你', '请', '把', '将'];
                const actionVerbs = ['翻译', '写', '写一', '搜索', '搜', '整理', '分析', '检查', '发送', '发', '生成', '创建', '修改', '优化', '部署', '监控', '提醒', '扫描', '总结', '爬取', '下载', '上传', '配置', '设置', '转换', '导出', '备份', '运行', '执行', '测试', '修复', '重构', '统计', '更新', '同步', '比较', '评估', '提取', '汇总', '制作', '安排'];
                const questionEnders = ['吗', '吧', '么', '呢', '?', '？'];
                const questionWords = ['是否', '怎么', '为什么', '哪', '谁', '多少', '几个', '哪里', '如何', '怎样', '有没有', '能不能', '可以吗', '告诉我', '解释'];
                const hasTaskStarter = taskStarterPrefixes.some((s) => rawText.startsWith(s));
                const hasActionVerb = actionVerbs.some((v) => rawText.includes(v));
                const endsWithQuestion = questionEnders.some((e) => rawText.endsWith(e));
                const hasQuestionWord = questionWords.some((q) => rawText.includes(q));
                const isChatLike = !hasTaskStarter && !hasActionVerb && (endsWithQuestion || hasQuestionWord);
                // Produce a human-readable reason for the classification
                const classifyReason = hasTaskStarter
                    ? `以指令词"${taskStarterPrefixes.find((s) => rawText.startsWith(s))}"开头，识别为任务`
                    : hasActionVerb
                        ? `包含操作动词，识别为任务`
                        : isChatLike
                            ? `未检测到任务动词，且包含问句标记，识别为问答`
                            : '默认识别为任务';
                // ── Title extraction ──────────────────────────────────────────────────
                // Strip common leading filler words so title reads naturally
                const fillerPrefixes = ['帮我', '请你', '请帮我', '请帮', '请', '麻烦', '能不能', '可以', '帮忙'];
                let cleaned = rawText;
                for (const fp of fillerPrefixes) {
                    if (cleaned.startsWith(fp)) {
                        cleaned = cleaned.slice(fp.length).trimStart();
                        break;
                    }
                }
                const firstSentence = cleaned.split(/[。！？.!?\n]/)[0].trim();
                const title = firstSentence.length >= 4 && firstSentence.length <= 60
                    ? firstSentence
                    : cleaned.slice(0, 40).trimEnd() + (cleaned.length > 40 ? '…' : '');
                // ── Priority heuristic ────────────────────────────────────────────────
                const lower = rawText.toLowerCase();
                const criticalKw = ['紧急', '立即', 'asap', '马上', '立刻', '今晚', '赶紧'];
                const highKw = ['今天', '尽快', '重要', '优先', 'urgent', '截止', '明天前'];
                const hitCritical = criticalKw.find((k) => lower.includes(k));
                const hitHigh = !hitCritical && highKw.find((k) => lower.includes(k));
                const priority = hitCritical ? 'critical' : hitHigh ? 'high' : 'medium';
                const priorityReason = hitCritical
                    ? `包含关键词「${hitCritical}」→ 紧急`
                    : hitHigh
                        ? `包含关键词「${hitHigh}」→ 高优先级`
                        : '未检测到优先级关键词，默认中等';
                // ── Word tokenisation (for matching) ─────────────────────────────────
                const words = lower.split(/[\s,，。、！？!?；;：:""''（）()]+/).filter((w) => w.length >= 2);
                // ── Template matching ─────────────────────────────────────────────────
                // Require score ≥ 2, OR score ≥ 1 when only 1 template exists
                const templates = await memoryStore.listTeamTemplates(workspaceId);
                let recommendedTemplateId = null;
                let recommendedTemplateName = null;
                let recommendedTemplateReason = null;
                {
                    let bestScore = 0;
                    let bestMatched = [];
                    let bestTpl = null;
                    for (const tpl of templates) {
                        const hay = `${tpl.name} ${tpl.description ?? ''}`.toLowerCase();
                        const matched = words.filter((w) => hay.includes(w));
                        if (matched.length > bestScore) {
                            bestScore = matched.length;
                            bestMatched = matched;
                            bestTpl = tpl;
                        }
                    }
                    const threshold = templates.length <= 1 ? 1 : 2;
                    if (bestScore >= threshold && bestTpl) {
                        recommendedTemplateId = bestTpl.id;
                        recommendedTemplateName = bestTpl.name;
                        recommendedTemplateReason = `与关键词「${bestMatched.slice(0, 2).join('、')}」匹配`;
                    }
                }
                // ── Agent matching ────────────────────────────────────────────────────
                // Require score ≥ 2, OR score ≥ 1 when only 1 agent exists
                let agentList = await memoryStore.listAgents(workspaceId);
                if (agentList.length === 0)
                    agentList = await memoryStore.listAgents(undefined);
                let recommendedAgentId = null;
                let recommendedAgentName = null;
                let recommendedAgentReason = null;
                {
                    let bestScore = 0;
                    let bestMatched = [];
                    let bestAg = null;
                    for (const ag of agentList) {
                        const hay = `${ag.name} ${ag.description ?? ''}`.toLowerCase();
                        const matched = words.filter((w) => hay.includes(w));
                        if (matched.length > bestScore) {
                            bestScore = matched.length;
                            bestMatched = matched;
                            bestAg = ag;
                        }
                    }
                    const threshold = agentList.length <= 1 ? 1 : 2;
                    if (bestScore >= threshold && bestAg) {
                        recommendedAgentId = bestAg.id;
                        recommendedAgentName = bestAg.name;
                        recommendedAgentReason = `与关键词「${bestMatched.slice(0, 2).join('、')}」匹配`;
                    }
                }
                res.json({
                    type: isChatLike ? 'chat' : 'task',
                    classifyReason,
                    draft: {
                        title,
                        description: rawText,
                        priority,
                        priorityReason,
                        recommendedAgentId,
                        recommendedAgentName,
                        recommendedAgentReason,
                        recommendedTemplateId,
                        recommendedTemplateName,
                        recommendedTemplateReason,
                    },
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-tasks', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const workspaceId = String(body.workspaceId ?? '').trim();
                const title = String(body.title ?? '').trim();
                const reviewerAgentId = body.reviewerAgentId === null
                    ? null
                    : typeof body.reviewerAgentId === 'string' && body.reviewerAgentId.trim()
                        ? body.reviewerAgentId.trim()
                        : undefined;
                const reviewRequired = body.reviewRequired === undefined ? undefined : Boolean(body.reviewRequired);
                if (!workspaceId || !title) {
                    res.status(400).json({ error: 'workspaceId and title are required' });
                    return;
                }
                if (reviewRequired && !reviewerAgentId) {
                    res.status(400).json({ error: 'reviewerAgentId is required when reviewRequired is true' });
                    return;
                }
                const task = await memoryStore.createTeamTask({
                    workspaceId,
                    title,
                    description: typeof body.description === 'string' ? body.description : undefined,
                    status: parseTeamTaskStatus(body.status),
                    priority: typeof body.priority === 'string' ? body.priority : undefined,
                    assignedAgentId: typeof body.assignedAgentId === 'string' ? body.assignedAgentId : undefined,
                    dependsOnTaskIds: parseStringArrayInput(body.dependsOnTaskIds),
                    reviewRequired,
                    reviewerAgentId,
                    reviewStatus: parseReviewStatus(body.reviewStatus),
                    attemptCount: typeof body.attemptCount === 'number' ? body.attemptCount : undefined,
                    maxAttempts: typeof body.maxAttempts === 'number' ? body.maxAttempts : undefined,
                    lastAttemptAt: typeof body.lastAttemptAt === 'string' && body.lastAttemptAt ? new Date(body.lastAttemptAt) : undefined,
                    escalationStatus: parseEscalationStatus(body.escalationStatus),
                    escalationReason: body.escalationReason === null || typeof body.escalationReason === 'string'
                        ? body.escalationReason
                        : undefined,
                    humanOwnerUserId: body.humanOwnerUserId === null || typeof body.humanOwnerUserId === 'string'
                        ? body.humanOwnerUserId
                        : undefined,
                    blockedReason: body.blockedReason === null || typeof body.blockedReason === 'string'
                        ? body.blockedReason
                        : undefined,
                    createdBy: String(body.createdBy ?? req.authUser?.sub ?? getStableWebId()),
                    resultSummary: typeof body.resultSummary === 'string' ? body.resultSummary : undefined,
                    dueAt: typeof body.dueAt === 'string' && body.dueAt ? new Date(body.dueAt) : undefined,
                    metadata: typeof body.metadata === 'object' && body.metadata !== null ? body.metadata : undefined,
                });
                res.status(201).json({ task });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-tasks/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const existing = await memoryStore.getTeamTask(String(req.params.id));
                if (!existing) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                const reviewerAgentId = body.reviewerAgentId === null
                    ? null
                    : typeof body.reviewerAgentId === 'string'
                        ? (body.reviewerAgentId.trim() || null)
                        : existing.reviewerAgentId ?? null;
                const reviewRequired = body.reviewRequired !== undefined ? Boolean(body.reviewRequired) : existing.reviewRequired;
                if (reviewRequired && !reviewerAgentId) {
                    res.status(400).json({ error: 'reviewerAgentId is required when reviewRequired is true' });
                    return;
                }
                const explicitReviewStatus = parseReviewStatus(body.reviewStatus);
                const explicitEscalationStatus = parseEscalationStatus(body.escalationStatus);
                const task = await memoryStore.updateTeamTask(String(req.params.id), {
                    ...(typeof body.title === 'string' ? { title: body.title } : {}),
                    ...(typeof body.description === 'string' ? { description: body.description } : {}),
                    ...(parseTeamTaskStatus(body.status) !== undefined ? { status: parseTeamTaskStatus(body.status) } : {}),
                    ...(typeof body.priority === 'string' ? { priority: body.priority } : {}),
                    ...(body.assignedAgentId === null || typeof body.assignedAgentId === 'string'
                        ? { assignedAgentId: body.assignedAgentId }
                        : {}),
                    ...(body.dependsOnTaskIds !== undefined ? { dependsOnTaskIds: parseStringArrayInput(body.dependsOnTaskIds) ?? [] } : {}),
                    ...(body.reviewerAgentId !== undefined ? { reviewerAgentId } : {}),
                    ...(body.reviewRequired !== undefined ? { reviewRequired } : {}),
                    ...(explicitReviewStatus !== undefined
                        ? { reviewStatus: explicitReviewStatus }
                        : body.reviewRequired !== undefined
                            ? { reviewStatus: reviewRequired ? (existing.reviewStatus === 'not_required' ? 'pending' : existing.reviewStatus) : 'not_required' }
                            : {}),
                    ...(typeof body.attemptCount === 'number' ? { attemptCount: body.attemptCount } : {}),
                    ...(typeof body.maxAttempts === 'number' ? { maxAttempts: body.maxAttempts } : {}),
                    ...(body.lastAttemptAt === null || typeof body.lastAttemptAt === 'string'
                        ? { lastAttemptAt: body.lastAttemptAt ? new Date(body.lastAttemptAt) : null }
                        : {}),
                    ...(explicitEscalationStatus !== undefined ? { escalationStatus: explicitEscalationStatus } : {}),
                    ...(body.escalationReason === null || typeof body.escalationReason === 'string'
                        ? { escalationReason: body.escalationReason }
                        : {}),
                    ...(body.humanOwnerUserId === null || typeof body.humanOwnerUserId === 'string'
                        ? { humanOwnerUserId: body.humanOwnerUserId }
                        : {}),
                    ...(body.blockedReason === null || typeof body.blockedReason === 'string'
                        ? { blockedReason: body.blockedReason }
                        : {}),
                    ...(body.resultSummary === null || typeof body.resultSummary === 'string'
                        ? { resultSummary: body.resultSummary }
                        : {}),
                    ...(body.dueAt === null || typeof body.dueAt === 'string'
                        ? { dueAt: body.dueAt ? new Date(body.dueAt) : null }
                        : {}),
                    ...(typeof body.metadata === 'object' && body.metadata !== null ? { metadata: body.metadata } : {}),
                });
                res.json({ task });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/team-tasks/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const ok = await memoryStore.deleteTeamTask(String(req.params.id));
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-tasks/:id/claim', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const agentId = String(body.agentId ?? '').trim();
                if (!agentId) {
                    res.status(400).json({ error: 'agentId is required' });
                    return;
                }
                const task = await claimTeamTaskById(String(req.params.id), agentId, req.authUser?.sub ?? getStableWebId());
                if (!task) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                res.json({ task });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-tasks/:id/challenge', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const challengerAgentId = String(body.challengerAgentId ?? '').trim();
                const summary = String(body.summary ?? '').trim();
                if (!challengerAgentId || !summary) {
                    res.status(400).json({ error: 'challengerAgentId and summary are required' });
                    return;
                }
                const task = await raiseTeamTaskChallengeById({
                    taskId: String(req.params.id),
                    challengerAgentId,
                    summary,
                    threadId: typeof body.threadId === 'string' ? body.threadId : undefined,
                });
                if (!task) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                res.json({ task });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-tasks/:id/consensus', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const requesterAgentId = String(body.requesterAgentId ?? '').trim();
                const summary = String(body.summary ?? '').trim();
                if (!requesterAgentId || !summary) {
                    res.status(400).json({ error: 'requesterAgentId and summary are required' });
                    return;
                }
                const task = await requestTeamTaskConsensusById({
                    taskId: String(req.params.id),
                    requesterAgentId,
                    summary,
                    participantAgentIds: parseStringArrayInput(body.participantAgentIds),
                    participantWeights: body.participantWeights && typeof body.participantWeights === 'object' && !Array.isArray(body.participantWeights)
                        ? Object.fromEntries(Object.entries(body.participantWeights)
                            .map(([agentId, weight]) => [agentId.trim(), Number(weight)])
                            .filter((entry) => entry[0].length > 0 && Number.isFinite(entry[1]) && entry[1] > 0))
                        : undefined,
                    threadId: typeof body.threadId === 'string' ? body.threadId : undefined,
                });
                if (!task) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                res.json({ task });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-tasks/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const task = await memoryStore.getTeamTask(String(req.params.id));
                if (!task) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                const runtime = summarizeTeamTaskRuntime(task);
                const verdict = deriveVerdict(task, runtime);
                res.json({ task, runtime, verdict });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-tasks/:id/dispatch', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const taskId = String(req.params.id);
                const task = await memoryStore.getTeamTask(taskId);
                if (!task) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                if (!task.assignedAgentId) {
                    res.status(400).json({ error: 'Task has no assigned agent — set assignedAgentId first' });
                    return;
                }
                // If already running, return current state without re-dispatching
                if (task.status === 'in_progress') {
                    const currentRunId = typeof (task.metadata ?? {})['currentRunId'] === 'string'
                        ? task.metadata['currentRunId']
                        : null;
                    res.json({ ok: false, alreadyRunning: true, currentRunId, task });
                    return;
                }
                const runId = `teamtask:${taskId}:${Date.now()}`;
                // Fire-and-forget: return immediately, let agent run in background
                void dispatchTeamTaskById(taskId, undefined, undefined, { runId }).catch((err) => {
                    console.error(`[dispatch] task ${taskId} runId ${runId} error:`, err);
                });
                res.json({ ok: true, runId, message: '任务已下发，Agent 开始执行' });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-tasks/:id/retry', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const taskId = String(req.params.id);
                const task = await memoryStore.getTeamTask(taskId);
                if (!task) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                if (!task.assignedAgentId) {
                    res.status(400).json({ error: 'No assigned agent — assign an agent before retrying' });
                    return;
                }
                // Reject retry if already in_progress
                if (task.status === 'in_progress') {
                    const currentRunId = typeof (task.metadata ?? {})['currentRunId'] === 'string'
                        ? task.metadata['currentRunId']
                        : null;
                    res.json({ ok: false, alreadyRunning: true, currentRunId, task });
                    return;
                }
                // Reset to todo so dispatch can proceed
                await memoryStore.updateTeamTask(taskId, {
                    status: 'todo',
                    blockedReason: null,
                    escalationReason: null,
                    escalationStatus: 'none',
                    resultSummary: null,
                });
                const runId = `teamtask:${taskId}:${Date.now()}`;
                void dispatchTeamTaskById(taskId, undefined, undefined, { runId }).catch((err) => {
                    console.error(`[retry] task ${taskId} runId ${runId} error:`, err);
                });
                res.json({ ok: true, runId, message: '任务已重置并重新派发给 Agent' });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/team-tasks/:id/human-decision
         * Records a human verdict override for a task.
         * Decision is written to task metadata (non-destructive, fully traceable).
         * If decision = 'retry_requested', also triggers a fresh dispatch.
         *
         * Body: { decision: 'approved' | 'rejected' | 'retry_requested', reason?: string }
         */
        app.post('/api/team-tasks/:id/human-decision', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const taskId = String(req.params.id);
                const task = await memoryStore.getTeamTask(taskId);
                if (!task) {
                    res.status(404).json({ error: 'Task not found' });
                    return;
                }
                const body = req.body;
                const decision = body.decision;
                const reason = typeof body.reason === 'string' ? body.reason.trim() : undefined;
                const userId = req.authUser?.sub ?? 'unknown';
                if (!['approved', 'rejected', 'retry_requested'].includes(decision ?? '')) {
                    res.status(400).json({ error: 'decision must be approved | rejected | retry_requested' });
                    return;
                }
                // Map decision to reviewStatus
                const reviewStatus = decision === 'approved' ? 'approved'
                    : decision === 'rejected' ? 'changes_requested'
                        : task.reviewStatus; // retry_requested — keep current reviewStatus
                // Write human decision into metadata (non-destructive)
                const updatedMetadata = {
                    ...(task.metadata ?? {}),
                    lastHumanDecision: decision,
                    lastHumanDecisionAt: new Date().toISOString(),
                    lastHumanDecisionBy: userId,
                    ...(reason ? { lastHumanDecisionReason: reason } : {}),
                };
                await memoryStore.updateTeamTask(taskId, {
                    reviewStatus: reviewStatus,
                    metadata: updatedMetadata,
                });
                // If retry requested, also reset and re-dispatch
                if (decision === 'retry_requested') {
                    await memoryStore.updateTeamTask(taskId, {
                        status: 'todo',
                        blockedReason: null,
                        escalationReason: null,
                        resultSummary: null,
                    });
                    const runId = `teamtask:${taskId}:${Date.now()}`;
                    void dispatchTeamTaskById(taskId, undefined, undefined, { runId }).catch((err) => {
                        console.error(`[human-decision retry] task ${taskId} error:`, err);
                    });
                    res.json({ ok: true, decision, runId, message: '已请求重跑并重新派发' });
                    return;
                }
                res.json({ ok: true, decision, message: `决定已记录：${decision}` });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Harness Engineering endpoints (P3) ──────────────────────────────────
        /**
         * GET /api/harness/samples
         * Returns the fixed regression sample set for repeatability testing.
         * Samples cover: task-like inputs, likely-blocked inputs, chat-like inputs.
         */
        app.get('/api/harness/samples', requireAuth, requireAdminAccess, (_req, res) => {
            res.json({
                samples: [
                    { id: 's1', label: '翻译任务（清晰可执行）', input: '帮我把 README 翻译成英文', expectedType: 'task' },
                    { id: 's2', label: '定时任务（需调度）', input: '每天早上9点发一份市场摘要', expectedType: 'task' },
                    { id: 's3', label: '代码检查（需上下文）', input: '检查代码里的安全漏洞', expectedType: 'task' },
                    { id: 's4', label: '问答输入（应转 Chat）', input: '今天天气怎么样', expectedType: 'chat' },
                    { id: 's5', label: '部署任务（可能阻塞）', input: '帮我把这个项目部署到服务器上', expectedType: 'task' },
                ],
            });
        });
        /**
         * POST /api/harness/validate
         * Runs a single NL input through the draft classification pipeline
         * and returns the full classification result for regression comparison.
         * Body: { input: string }
         */
        app.post('/api/harness/validate', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const rawText = typeof body.input === 'string' ? body.input.trim() : '';
                if (!rawText) {
                    res.status(400).json({ error: 'input is required' });
                    return;
                }
                // Reuse the same classification logic as /api/team-tasks/draft
                const taskStarterPrefixes = ['帮我', '帮', '请帮', '请你', '请', '把', '将'];
                const actionVerbs = ['翻译', '写', '写一', '搜索', '搜', '整理', '分析', '检查', '发送', '发', '生成', '创建', '修改', '优化', '部署', '监控', '提醒', '扫描', '总结', '爬取', '下载', '上传', '配置', '设置', '转换', '导出', '备份', '运行', '执行', '测试', '修复', '重构', '统计', '更新', '同步', '比较', '评估', '提取', '汇总', '制作', '安排'];
                const questionEnders = ['吗', '吧', '么', '呢', '?', '？'];
                const questionWords = ['是否', '怎么', '为什么', '哪', '谁', '多少', '几个', '哪里', '如何', '怎样', '有没有', '能不能', '可以吗', '告诉我', '解释'];
                const hasTaskStarter = taskStarterPrefixes.some((s) => rawText.startsWith(s));
                const hasActionVerb = actionVerbs.some((v) => rawText.includes(v));
                const endsWithQuestion = questionEnders.some((e) => rawText.endsWith(e));
                const hasQuestionWord = questionWords.some((q) => rawText.includes(q));
                const isChatLike = !hasTaskStarter && !hasActionVerb && (endsWithQuestion || hasQuestionWord);
                const classifyReason = hasTaskStarter
                    ? `以指令词"${taskStarterPrefixes.find((s) => rawText.startsWith(s))}"开头，识别为任务`
                    : hasActionVerb
                        ? '包含操作动词，识别为任务'
                        : isChatLike
                            ? '未检测到任务动词，且包含问句标记，识别为问答'
                            : '默认识别为任务';
                const draftType = isChatLike ? 'chat' : 'task';
                const signals = { hasTaskStarter, hasActionVerb, endsWithQuestion, hasQuestionWord };
                res.json({ input: rawText, draftType, classifyReason, signals });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/harness/stats
         * Returns minimal governance signals derived from existing task data.
         * Computes verdict for each task on-the-fly and aggregates stats.
         */
        app.get('/api/harness/stats', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const tasks = await memoryStore.listTeamTasks(workspaceId ? { workspaceId } : undefined);
                // Compute verdicts for all tasks
                const taskVerdicts = tasks.map((t) => {
                    const runtime = summarizeTeamTaskRuntime(t);
                    const v = deriveVerdict(t, runtime);
                    return { task: t, verdict: v.verdict };
                });
                // Verdict distribution
                const verdictCounts = {};
                for (const { verdict } of taskVerdicts) {
                    verdictCounts[verdict] = (verdictCounts[verdict] ?? 0) + 1;
                }
                // Per-agent stats
                const agentMap = {};
                for (const { task, verdict } of taskVerdicts) {
                    if (!task.assignedAgentId)
                        continue;
                    const key = task.assignedAgentId;
                    if (!agentMap[key])
                        agentMap[key] = { agentId: key, total: 0, success: 0, failed: 0, blocked: 0, needs_review: 0 };
                    agentMap[key].total++;
                    if (verdict === 'success')
                        agentMap[key].success++;
                    else if (verdict === 'failed')
                        agentMap[key].failed++;
                    else if (verdict === 'blocked')
                        agentMap[key].blocked++;
                    else if (verdict === 'needs_review')
                        agentMap[key].needs_review++;
                }
                // Enrich agent names from agent list
                const allAgents = await memoryStore.listAgents(workspaceId ?? undefined);
                for (const ag of allAgents) {
                    if (agentMap[ag.id])
                        agentMap[ag.id].name = ag.name;
                }
                // Human decision distribution
                const humanDecisions = { approved: 0, rejected: 0, retry_requested: 0, none: 0 };
                for (const { task } of taskVerdicts) {
                    const hd = task.metadata?.['lastHumanDecision'];
                    if (hd === 'approved')
                        humanDecisions.approved++;
                    else if (hd === 'rejected')
                        humanDecisions.rejected++;
                    else if (hd === 'retry_requested')
                        humanDecisions.retry_requested++;
                    else
                        humanDecisions.none++;
                }
                // Auto vs human breakdown for success verdicts
                const autoSuccessCount = taskVerdicts.filter(({ task, verdict }) => verdict === 'success' && !task.metadata?.['lastHumanDecision']).length;
                const humanApprovedCount = humanDecisions.approved;
                res.json({
                    totalTasks: tasks.length,
                    verdictDistribution: verdictCounts,
                    agentStats: Object.values(agentMap),
                    humanDecisions,
                    autoSuccessCount,
                    humanApprovedCount,
                    generatedAt: new Date().toISOString(),
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/harness/run
         *
         * Creates a team task, triggers the supervisor to dispatch it, polls for
         * completion (max 30s), derives verdict, and returns the full result.
         *
         * Body:
         *   title                    string  (required)
         *   description              string  (optional)
         *   workspaceId              string  (optional — defaults to 'harness')
         *   expectedAutoAccept       boolean (optional — false → sets requiresHumanApproval)
         *   expectedEvidenceVerifiable boolean (optional — true → sets requiresEvidence)
         *   difficulty               string  (optional — 'trivial'|'easy'|'medium'|'hard')
         *   timeoutMs                number  (optional — max 30000, default 30000)
         *
         * Returns:
         *   { taskId, status, verdict, verdictSource, reason, needsHuman,
         *     failureClass, stepResults, durationMs }
         */
        app.post('/api/harness/run', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const title = typeof body.title === 'string' ? body.title.trim() : '';
                if (!title) {
                    res.status(400).json({ error: 'title is required' });
                    return;
                }
                const workspaceId = typeof body.workspaceId === 'string' ? body.workspaceId : 'harness';
                const description = typeof body.description === 'string' ? body.description : undefined;
                const expectedAutoAccept = typeof body.expectedAutoAccept === 'boolean' ? body.expectedAutoAccept : true;
                const expectedEvidenceVerifiable = typeof body.expectedEvidenceVerifiable === 'boolean' ? body.expectedEvidenceVerifiable : false;
                const difficulty = typeof body.difficulty === 'string' ? body.difficulty : 'medium';
                const timeoutMs = Math.min(typeof body.timeoutMs === 'number' ? body.timeoutMs : 30000, 30000);
                const taskMeta = { difficulty };
                if (!expectedAutoAccept)
                    taskMeta['requiresHumanApproval'] = true;
                if (expectedEvidenceVerifiable)
                    taskMeta['requiresEvidence'] = true;
                // Create task
                const task = await memoryStore.createTeamTask({
                    workspaceId,
                    title,
                    description,
                    createdBy: 'harness',
                    status: 'todo',
                    metadata: taskMeta,
                });
                // Trigger supervisor to dispatch the task
                const { processReadyTeamTasks: processReady } = await import('../../skills/team.js');
                await processReady(workspaceId);
                // Poll for completion
                const start = Date.now();
                const POLL_INTERVAL = 500;
                const TERMINAL_STATUSES = new Set(['done', 'blocked', 'cancelled', 'escalated']);
                let finalTask = task;
                while (Date.now() - start < timeoutMs) {
                    await new Promise((r) => setTimeout(r, POLL_INTERVAL));
                    const current = await memoryStore.getTeamTask(task.id);
                    if (!current)
                        break;
                    finalTask = current;
                    if (TERMINAL_STATUSES.has(current.status))
                        break;
                }
                const durationMs = Date.now() - start;
                const runtime = summarizeTeamTaskRuntime(finalTask);
                const verdictResult = deriveVerdict(finalTask, runtime);
                // Compute failure class (simplified harness classification)
                const meta = finalTask.metadata ?? {};
                const status = finalTask.status;
                const verdictValue = verdictResult.verdict;
                let failureClass;
                if (verdictValue === 'success') {
                    const doneCriteria = Array.isArray(meta['contract']?.['doneCriteria'])
                        ? meta['contract']['doneCriteria']
                        : [];
                    const evSev = typeof meta['evidenceSeverity'] === 'string' ? meta['evidenceSeverity'] : null;
                    if (doneCriteria.length === 0 && difficulty !== 'trivial' && verdictResult.verdictSource === 'system') {
                        failureClass = 'weak_context';
                    }
                    else if (expectedEvidenceVerifiable && evSev === null && verdictResult.verdictSource !== 'human') {
                        failureClass = 'evidence_not_checked';
                    }
                    else if (!expectedAutoAccept && verdictResult.verdictSource === 'system') {
                        failureClass = 'auto_accepted_unexpected';
                    }
                    else {
                        failureClass = 'ok';
                    }
                }
                else if (TERMINAL_STATUSES.has(status) && !['done'].includes(status)) {
                    failureClass = 'action_failed';
                }
                else if (['todo', 'open', 'claimed', 'assigned', 'in_progress', 'proposed'].includes(status)) {
                    failureClass = 'environment_issue';
                }
                else if (verdictValue === 'needs_review' && verdictResult.needsHuman && !verdictResult.humanDecision) {
                    const evSev2 = typeof meta['evidenceSeverity'] === 'string' ? meta['evidenceSeverity'] : null;
                    failureClass = evSev2 === 'contradicted' ? 'evidence_failed' : 'needs_review_unresolved';
                }
                else {
                    failureClass = 'action_failed';
                }
                res.json({
                    taskId: finalTask.id,
                    status: finalTask.status,
                    verdict: verdictResult.verdict,
                    verdictSource: verdictResult.verdictSource,
                    reason: verdictResult.reason,
                    needsHuman: verdictResult.needsHuman,
                    humanDecision: verdictResult.humanDecision,
                    failureClass,
                    resultSummary: finalTask.resultSummary ?? null,
                    metadata: finalTask.metadata,
                    durationMs,
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/workflow-runs/:workflowId
         * Returns the most recent run records for a workflow (default last 20).
         */
        app.get('/api/workflow-runs/:workflowId', requireAuth, async (req, res) => {
            try {
                const workflowId = req.params['workflowId'];
                const limit = typeof req.query.limit === 'string' ? Math.min(parseInt(req.query.limit, 10) || 20, 100) : 20;
                const runs = getWorkflowRunsForWorkflow(workflowId, limit);
                res.json({ workflowId, runs, count: runs.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/workflow-runs
         * Returns recent runs across all workflows.
         */
        app.get('/api/workflow-runs', requireAuth, async (req, res) => {
            try {
                const limit = typeof req.query.limit === 'string' ? Math.min(parseInt(req.query.limit, 10) || 50, 200) : 50;
                const runs = getAllWorkflowRuns(limit);
                res.json({ runs, count: runs.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/job-runs/:jobId
         * Returns the most recent run records for a scheduled job.
         */
        app.get('/api/job-runs/:jobId', requireAuth, async (req, res) => {
            try {
                const jobId = req.params['jobId'];
                const limit = typeof req.query.limit === 'string' ? Math.min(parseInt(req.query.limit, 10) || 20, 100) : 20;
                const runs = getJobRunsForJob(jobId, limit);
                res.json({ jobId, runs, count: runs.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/job-runs
         * Returns recent runs across all scheduled jobs.
         */
        app.get('/api/job-runs', requireAuth, async (req, res) => {
            try {
                const limit = typeof req.query.limit === 'string' ? Math.min(parseInt(req.query.limit, 10) || 50, 200) : 50;
                const runs = getAllJobRuns(limit);
                res.json({ runs, count: runs.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Child Distribution API ────────────────────────────────────────────────
        // Auth (two-phase):
        //   Phase 1 — Enrollment: child sends enrollmentKey in POST body (no Bearer header)
        //   Phase 2 — Ongoing: child uses JWT (issued at enrollment) as Bearer token
        const childJwtSecret = config.gateway?.secret ?? 'greenfrog-dev-secret';
        const childAuth = makeChildAuthMiddleware({ jwtSecret: childJwtSecret });
        const enrollHandlerFn = handleEnroll({ jwtSecret: childJwtSecret });
        // POST /api/distribution/enroll — no auth (first boot)
        app.post('/api/distribution/enroll', enrollHandlerFn);
        // POST /api/distribution/backflow — Bearer JWT
        app.post('/api/distribution/backflow', childAuth, handleBackflow());
        // GET /api/distribution/inheritance/latest — Bearer JWT
        app.get('/api/distribution/inheritance/latest', childAuth, handleInheritanceLatest());
        // GET /api/distribution/inheritance/:releaseId — Bearer JWT
        app.get('/api/distribution/inheritance/:releaseId', childAuth, handleInheritanceById());
        // POST /api/distribution/enroll/revoke — Bearer JWT
        app.post('/api/distribution/enroll/revoke', childAuth, handleRevoke({}));
        // GET /api/distribution/status — public (no auth); child instance observability
        app.get('/api/distribution/status', (_req, res) => {
            try {
                const baseDir = process.env['GF_BASE_DIR'];
                const homeDir = process.env['HOME'] ?? process.env['USERPROFILE'] ?? '';
                const enrollmentRecord = getEnrollmentState(baseDir);
                const installRecord = readInstallRecord(baseDir);
                const inheritanceCfg = readInheritanceConfig(baseDir);
                const credential = loadCredential(baseDir);
                const depth = queueDepth(baseDir);
                const publicKeyPath = baseDir
                    ? `${baseDir}/public-key.pem`
                    : `${homeDir}/.greenfrog/public-key.pem`;
                let appVersion = '0.0.0';
                try {
                    const pkgPath = new URL('../../../package.json', import.meta.url);
                    const pkg = JSON.parse(readFileSync(pkgPath, 'utf-8'));
                    appVersion = pkg.version ?? appVersion;
                }
                catch { /* ignore */ }
                res.json({
                    ok: true,
                    runMode: process.env['GF_IS_CHILD_INSTANCE'] === 'true' ? 'child' : 'mother',
                    enrollmentState: enrollmentRecord.state,
                    enrolledAt: enrollmentRecord.enrolledAt ?? null,
                    instanceId: installRecord?.instanceId ?? null,
                    platform: (installRecord?.platform ?? process.platform),
                    appVersion,
                    nodeVersion: process.version,
                    inheritanceMode: inheritanceCfg.mode,
                    inheritanceVersion: inheritanceCfg.lastAppliedVersion ?? null,
                    inheritanceLastAppliedAt: inheritanceCfg.lastAppliedAt ?? null,
                    backflowQueueDepth: depth,
                    credentialPresent: !!credential?.jwt,
                    credentialExpiresAt: credential?.expiresAt ?? null,
                    publicKeyPresent: existsSync(publicKeyPath),
                    locale: process.env['GF_LOCALE'] ?? (process.env['LANG']?.split('.')[0]?.replace('_', '-') ?? 'en'),
                });
            }
            catch (err) {
                res.status(500).json({ ok: false, error: String(err) });
            }
        });
        // ── P4.6: Benchmark / Reliability endpoints ───────────────────────────────
        /**
         * GET /api/benchmark/samples
         * Returns the P4.6 true-task benchmark sample set.
         * Each entry includes metadata for expected outcomes.
         */
        app.get('/api/benchmark/samples', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                const benchmarkPath = new URL('../../scripts/benchmark-tasks.json', import.meta.url);
                // eslint-disable-next-line @typescript-eslint/no-require-imports
                const data = JSON.parse(require('fs').readFileSync(require('url').fileURLToPath(benchmarkPath), 'utf8'));
                res.json({ samples: data.samples, meta: data._meta });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/benchmark/reliability
         * Computes runtime reliability metrics from all existing benchmark tasks.
         *
         * Tasks are identified by metadata.benchmarkSampleId field.
         * Groups results by sample ID to derive category-level metrics.
         *
         * Query params:
         *   workspaceId — filter to a workspace (default: all)
         *   since       — ISO date string, only tasks created after this date
         */
        app.get('/api/benchmark/reliability', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const since = typeof req.query.since === 'string' ? new Date(req.query.since) : null;
                const allTasks = await memoryStore.listTeamTasks(workspaceId ? { workspaceId } : undefined);
                // Filter to benchmark-tagged tasks only
                const benchmarkTasks = allTasks.filter(t => {
                    const sampleId = t.metadata?.['benchmarkSampleId'];
                    if (!sampleId)
                        return false;
                    if (since && t.createdAt < since)
                        return false;
                    return true;
                });
                const total = benchmarkTasks.length;
                if (total === 0) {
                    res.json({
                        total: 0,
                        note: 'No benchmark tasks found. Run the benchmark first via: node scripts/run-benchmark.js',
                        generatedAt: new Date().toISOString(),
                    });
                    return;
                }
                const metrics = {
                    total,
                    successCount: 0,
                    evidenceVerifiedCount: 0,
                    softVerifiedCount: 0,
                    contradictedCount: 0,
                    needsReviewCount: 0,
                    recoverTriggeredCount: 0,
                    recoverSucceededCount: 0,
                    humanInterventionCount: 0,
                    artifactProducedCount: 0,
                    failureCounts: {},
                    categoryMetrics: {},
                    verdictSourceCounts: {},
                    avgConfidence: 0,
                };
                let totalConfidence = 0;
                let confidenceCount = 0;
                for (const task of benchmarkTasks) {
                    const meta = task.metadata ?? {};
                    const runtime = summarizeTeamTaskRuntime(task);
                    const verdict = deriveVerdict(task, runtime);
                    const vv = verdict.verdict;
                    const vs = verdict.verdictSource;
                    // Verdict source
                    metrics.verdictSourceCounts[vs] = (metrics.verdictSourceCounts[vs] ?? 0) + 1;
                    // Success
                    const isSuccess = vv === 'success';
                    if (isSuccess)
                        metrics.successCount++;
                    // Evidence severity
                    const evSev = typeof meta['evidenceSeverity'] === 'string' ? meta['evidenceSeverity'] : null;
                    if (evSev === 'hard_verified')
                        metrics.evidenceVerifiedCount++;
                    else if (evSev === 'soft_verified')
                        metrics.softVerifiedCount++;
                    else if (evSev === 'contradicted')
                        metrics.contradictedCount++;
                    // Needs review
                    if (vv === 'needs_review')
                        metrics.needsReviewCount++;
                    // Recovery
                    const execSteps = Array.isArray(meta['executionSteps']) ? meta['executionSteps'] : [];
                    const hadRecover = execSteps.some((s) => s?.['phase'] === 'recover');
                    if (hadRecover) {
                        metrics.recoverTriggeredCount++;
                        if (isSuccess)
                            metrics.recoverSucceededCount++;
                    }
                    // Human intervention
                    if (verdict.humanDecision)
                        metrics.humanInterventionCount++;
                    // Artifacts
                    const artifacts = Array.isArray(meta['artifacts']) ? meta['artifacts'] : [];
                    if (artifacts.length > 0)
                        metrics.artifactProducedCount++;
                    // Confidence
                    const conf = typeof meta['confidence'] === 'number' ? meta['confidence'] : null;
                    if (conf !== null) {
                        totalConfidence += conf;
                        confidenceCount++;
                    }
                    // Category metrics
                    const cat = typeof meta['benchmarkCategory'] === 'string' ? meta['benchmarkCategory'] : 'unknown';
                    if (!metrics.categoryMetrics[cat])
                        metrics.categoryMetrics[cat] = { total: 0, success: 0, rate: '0.0' };
                    metrics.categoryMetrics[cat].total++;
                    if (isSuccess)
                        metrics.categoryMetrics[cat].success++;
                    // Failure classification (inline minimal version)
                    let fc = 'ok';
                    if (!isSuccess) {
                        if (evSev === 'contradicted')
                            fc = 'evidence_failed';
                        else if (vv === 'needs_review' && !verdict.humanDecision)
                            fc = 'needs_review_unresolved';
                        else if (task.status === 'blocked' || task.status === 'escalated')
                            fc = 'action_failed';
                        else if (conf !== null && conf < 0.45)
                            fc = 'verdict_low_confidence';
                        else if (vv === 'failed')
                            fc = 'action_failed';
                        else
                            fc = 'environment_issue';
                    }
                    metrics.failureCounts[fc] = (metrics.failureCounts[fc] ?? 0) + 1;
                }
                // Category success rates
                for (const cat of Object.keys(metrics.categoryMetrics)) {
                    const c = metrics.categoryMetrics[cat];
                    c.rate = c.total > 0 ? ((c.success / c.total) * 100).toFixed(1) : '0.0';
                }
                metrics.avgConfidence = confidenceCount > 0
                    ? parseFloat((totalConfidence / confidenceCount).toFixed(3))
                    : 0;
                const successRate = ((metrics.successCount / total) * 100).toFixed(1);
                // Top failures (excluding 'ok')
                const topFailures = Object.entries(metrics.failureCounts)
                    .filter(([k]) => k !== 'ok')
                    .sort((a, b) => b[1] - a[1])
                    .map(([cls, count]) => ({ class: cls, count, pct: ((count / total) * 100).toFixed(1) }));
                res.json({
                    total,
                    successRate,
                    metrics,
                    topFailures,
                    generatedAt: new Date().toISOString(),
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-mailbox', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const messages = await memoryStore.listTeamMailboxMessages({
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(typeof req.query.threadId === 'string' ? { threadId: req.query.threadId } : {}),
                    ...(typeof req.query.senderAgentId === 'string' ? { senderAgentId: req.query.senderAgentId } : {}),
                    ...(typeof req.query.recipientAgentId === 'string' ? { recipientAgentId: req.query.recipientAgentId } : {}),
                    ...(typeof req.query.taskId === 'string' ? { taskId: req.query.taskId } : {}),
                    ...(parseTeamMailboxType(req.query.type) ? { type: parseTeamMailboxType(req.query.type) } : {}),
                    ...(parseTeamMailboxStatus(req.query.status) ? { status: parseTeamMailboxStatus(req.query.status) } : {}),
                });
                res.json({ messages });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-mailbox', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const workspaceId = String(body.workspaceId ?? '').trim();
                const message = String(body.message ?? '').trim();
                if (!workspaceId || !message) {
                    res.status(400).json({ error: 'workspaceId and message are required' });
                    return;
                }
                const created = await memoryStore.createTeamMailboxMessage({
                    workspaceId,
                    threadId: typeof body.threadId === 'string' ? body.threadId : undefined,
                    dedupeKey: body.dedupeKey === null || typeof body.dedupeKey === 'string' ? body.dedupeKey : undefined,
                    senderAgentId: typeof body.senderAgentId === 'string' ? body.senderAgentId : undefined,
                    senderUserId: String(body.senderUserId ?? req.authUser?.sub ?? getStableWebId()),
                    recipientAgentId: body.recipientAgentId === null || typeof body.recipientAgentId === 'string' ? body.recipientAgentId : undefined,
                    taskId: body.taskId === null || typeof body.taskId === 'string' ? body.taskId : undefined,
                    type: parseTeamMailboxType(body.type),
                    status: parseTeamMailboxStatus(body.status),
                    subject: body.subject === null || typeof body.subject === 'string' ? body.subject : undefined,
                    message,
                    metadata: (() => {
                        const metadata = typeof body.metadata === 'object' && body.metadata !== null && !Array.isArray(body.metadata)
                            ? { ...body.metadata }
                            : {};
                        const type = parseTeamMailboxType(body.type);
                        const decision = typeof body.decision === 'string'
                            ? (body.decision === 'approve' || body.decision === 'approved' || body.decision === 'agree'
                                ? 'approve'
                                : body.decision === 'changes_requested' || body.decision === 'reject' || body.decision === 'rejected' || body.decision === 'blocked'
                                    ? 'changes_requested'
                                    : null)
                            : null;
                        if (type === 'consensus_response' && decision) {
                            metadata['decision'] = decision;
                            metadata['rationale'] = typeof body.rationale === 'string' ? body.rationale.slice(0, 500) : message.slice(0, 500);
                            const voteWeight = Number(body.voteWeight);
                            if (Number.isFinite(voteWeight) && voteWeight > 0) {
                                metadata['voteWeight'] = voteWeight;
                            }
                        }
                        return Object.keys(metadata).length > 0 ? metadata : undefined;
                    })(),
                });
                res.status(201).json({ message: created });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-mailbox/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const message = await memoryStore.updateTeamMailboxMessage(String(req.params.id), {
                    ...(parseTeamMailboxStatus(body.status) ? { status: parseTeamMailboxStatus(body.status) } : {}),
                    ...(body.subject === null || typeof body.subject === 'string' ? { subject: body.subject } : {}),
                    ...(typeof body.message === 'string' ? { message: body.message } : {}),
                    ...(typeof body.metadata === 'object' && body.metadata !== null ? { metadata: body.metadata } : {}),
                    ...(body.acknowledgedAt === null || typeof body.acknowledgedAt === 'string'
                        ? { acknowledgedAt: body.acknowledgedAt ? new Date(body.acknowledgedAt) : null }
                        : {}),
                });
                if (!message) {
                    res.status(404).json({ error: 'Mailbox message not found' });
                    return;
                }
                res.json({ message });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-policies/:workspaceId', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId ?? '').trim();
                if (!workspaceId) {
                    res.status(400).json({ error: 'workspaceId is required' });
                    return;
                }
                const policy = await memoryStore.getTeamPolicy(workspaceId);
                res.json({ policy });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.put('/api/team-policies/:workspaceId', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId ?? '').trim();
                const body = req.body;
                if (!workspaceId) {
                    res.status(400).json({ error: 'workspaceId is required' });
                    return;
                }
                const policy = await memoryStore.upsertTeamPolicy({
                    workspaceId,
                    ...(body.autoDispatch !== undefined ? { autoDispatch: Boolean(body.autoDispatch) } : {}),
                    ...(body.autoReview !== undefined ? { autoReview: Boolean(body.autoReview) } : {}),
                    ...(body.maxAutoRetries !== undefined ? { maxAutoRetries: Math.max(0, Number(body.maxAutoRetries) || 0) } : {}),
                    ...(body.escalateOnBlocked !== undefined ? { escalateOnBlocked: Boolean(body.escalateOnBlocked) } : {}),
                    ...(body.escalateOnReviewChanges !== undefined ? { escalateOnReviewChanges: Boolean(body.escalateOnReviewChanges) } : {}),
                    ...(body.escalateOnSlaBreach !== undefined ? { escalateOnSlaBreach: Boolean(body.escalateOnSlaBreach) } : {}),
                    ...(body.autoShareTaskResults !== undefined ? { autoShareTaskResults: Boolean(body.autoShareTaskResults) } : {}),
                    ...(body.autoPropagateLearnings !== undefined ? { autoPropagateLearnings: Boolean(body.autoPropagateLearnings) } : {}),
                    ...(body.autoGovernLearnedRules !== undefined ? { autoGovernLearnedRules: Boolean(body.autoGovernLearnedRules) } : {}),
                    ...(typeof body.sharedMemoryPrefix === 'string' ? { sharedMemoryPrefix: body.sharedMemoryPrefix } : {}),
                    ...(body.defaultTaskSlaHours !== undefined ? { defaultTaskSlaHours: Math.max(1, Number(body.defaultTaskSlaHours) || 1) } : {}),
                    ...(body.defaultHumanOwnerUserId === null || typeof body.defaultHumanOwnerUserId === 'string'
                        ? { defaultHumanOwnerUserId: body.defaultHumanOwnerUserId }
                        : {}),
                    ...(body.approvalReminderAfterMinutes !== undefined ? { approvalReminderAfterMinutes: Math.max(1, Number(body.approvalReminderAfterMinutes) || 1) } : {}),
                    ...(body.approvalEscalationAfterMinutes !== undefined ? { approvalEscalationAfterMinutes: Math.max(1, Number(body.approvalEscalationAfterMinutes) || 1) } : {}),
                    ...(body.onCallAssignmentTimeoutMinutes !== undefined ? { onCallAssignmentTimeoutMinutes: Math.max(1, Number(body.onCallAssignmentTimeoutMinutes) || 1) } : {}),
                    ...(body.onCallMaxHandoffsPerTask !== undefined ? { onCallMaxHandoffsPerTask: Math.max(1, Number(body.onCallMaxHandoffsPerTask) || 1) } : {}),
                    ...(body.escalationOwnerUserId === null || typeof body.escalationOwnerUserId === 'string'
                        ? { escalationOwnerUserId: body.escalationOwnerUserId }
                        : {}),
                    updatedBy: req.authUser?.sub ?? getStableWebId(),
                    metadata: (() => {
                        if (typeof body.metadata !== 'object' || body.metadata === null)
                            return undefined;
                        const merged = { ...body.metadata };
                        if (body.autoGovernLearnedRules !== undefined) {
                            merged['autoGovernLearnedRules'] = Boolean(body.autoGovernLearnedRules);
                            merged['ruleLibraryAutoGovernanceEnabled'] = Boolean(body.autoGovernLearnedRules);
                        }
                        return merged;
                    })(),
                });
                res.json({ policy });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/workspaces/:workspaceId/shared-memory', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId ?? '').trim();
                const userId = String(req.query.userId ?? '').trim();
                const channel = String(req.query.channel ?? 'web').trim();
                if (!workspaceId || !userId) {
                    res.status(400).json({ error: 'workspaceId and userId are required' });
                    return;
                }
                const memory = Object.fromEntries(Object.entries(await memoryStore.getAllScopedMemory({ userId, channel, workspaceId }))
                    .filter(([key]) => !isTeamSharedMemoryMetaKey(key)));
                res.json({ memory });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/workspaces/:workspaceId/shared-memory/promote', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId ?? '').trim();
                const body = req.body;
                const userId = String(body.userId ?? '').trim();
                const channel = String(body.channel ?? 'web').trim();
                const sourceKey = String(body.sourceKey ?? '').trim();
                const sourceAgentId = typeof body.sourceAgentId === 'string' && body.sourceAgentId.trim() ? body.sourceAgentId.trim() : undefined;
                if (!workspaceId || !userId || !sourceKey) {
                    res.status(400).json({ error: 'workspaceId, userId, and sourceKey are required' });
                    return;
                }
                const sourceScope = { userId, channel, workspaceId, ...(sourceAgentId ? { agentId: sourceAgentId } : {}) };
                const value = typeof body.value === 'string' ? body.value : await memoryStore.getScopedMemory(sourceScope, sourceKey);
                if (value === null) {
                    res.status(404).json({ error: 'Source memory not found' });
                    return;
                }
                const targetKey = String(body.targetKey ?? sourceKey).trim();
                const result = await writeTeamSharedMemoryEntry({
                    workspaceId,
                    userId,
                    channel,
                    key: targetKey,
                    value,
                    actorUserId: req.authUser?.sub ?? getStableWebId(),
                    expectedVersion: body.expectedVersion !== undefined ? Number(body.expectedVersion) : null,
                    conflictRecipientUserId: req.authUser?.sub ?? undefined,
                    conflictTitle: `Shared memory conflict for ${targetKey}`,
                });
                if (result.unauthorized) {
                    res.status(403).json({
                        error: 'Shared memory write blocked by authority policy',
                        key: targetKey,
                        version: result.currentVersion,
                        authorityPrefix: result.authorityPrefix,
                        approvalRequired: result.approvalRequired,
                    });
                    return;
                }
                res.json({ ok: result.applied, key: targetKey, value, version: result.nextVersion, conflictDetected: result.conflictDetected, versionConflict: result.versionConflict });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/workspaces/:workspaceId/shared-memory/rollback', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId ?? '').trim();
                const body = req.body;
                const userId = String(body.userId ?? '').trim();
                const channel = String(body.channel ?? 'web').trim();
                const key = String(body.key ?? '').trim();
                if (!workspaceId || !userId || !key) {
                    res.status(400).json({ error: 'workspaceId, userId, and key are required' });
                    return;
                }
                const result = await rollbackTeamSharedMemoryEntry({
                    workspaceId,
                    userId,
                    channel,
                    key,
                    actorUserId: req.authUser?.sub ?? getStableWebId(),
                    actorAgentId: typeof body.actorAgentId === 'string' && body.actorAgentId.trim() ? body.actorAgentId.trim() : null,
                    historyId: typeof body.historyId === 'string' && body.historyId.trim() ? body.historyId.trim() : null,
                    reason: typeof body.reason === 'string' && body.reason.trim() ? body.reason.trim() : null,
                    conflictTaskId: typeof body.conflictTaskId === 'string' && body.conflictTaskId.trim() ? body.conflictTaskId.trim() : null,
                    conflictRecipientUserId: req.authUser?.sub ?? undefined,
                    conflictRecipientAgentId: typeof body.conflictRecipientAgentId === 'string' && body.conflictRecipientAgentId.trim()
                        ? body.conflictRecipientAgentId.trim()
                        : null,
                    conflictTitle: `Shared memory rollback for ${key}`,
                });
                if (result.unauthorized) {
                    res.status(403).json({
                        error: 'Shared memory rollback blocked by authority policy',
                        key,
                        version: result.currentVersion,
                        authorityPrefix: result.authorityPrefix,
                        approvalRequired: result.approvalRequired,
                    });
                    return;
                }
                if (!result.ok) {
                    res.status(404).json({ error: 'Shared memory history entry not found', key });
                    return;
                }
                res.json({
                    ok: true,
                    key,
                    value: result.value,
                    version: result.nextVersion,
                    historyId: result.historyId,
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/workspaces/:workspaceId/shared-memory/conflicts', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId ?? '').trim();
                const userId = String(req.query.userId ?? '').trim();
                const channel = String(req.query.channel ?? 'web').trim();
                if (!workspaceId || !userId) {
                    res.status(400).json({ error: 'workspaceId and userId are required' });
                    return;
                }
                const [tasks, memory] = await Promise.all([
                    memoryStore.listTeamTasks({ workspaceId }),
                    memoryStore.getAllScopedMemory({ userId, channel, workspaceId }),
                ]);
                const conflictTasks = tasks
                    .filter((task) => {
                    const consensus = task.metadata?.['consensus'];
                    return Boolean(consensus && typeof consensus === 'object' && consensus['protocolKind'] === 'memory_conflict');
                })
                    .map((task) => {
                    const consensus = task.metadata?.['consensus'];
                    const conflictKey = typeof consensus['conflictKey'] === 'string' ? consensus['conflictKey'] : '';
                    const versionRaw = memory[`${conflictKey}::__meta_version`];
                    return {
                        taskId: task.id,
                        title: task.title,
                        status: task.status,
                        conflictKey,
                        expectedVersion: Number.isFinite(Number(consensus['expectedVersion'])) ? Number(consensus['expectedVersion']) : null,
                        currentVersion: Number.isFinite(Number(versionRaw ?? consensus['currentVersion'])) ? Number(versionRaw ?? consensus['currentVersion']) : null,
                        currentValue: conflictKey ? (memory[conflictKey] ?? null) : null,
                        incomingValue: typeof consensus['incomingValue'] === 'string' ? consensus['incomingValue'] : null,
                        previousValue: typeof consensus['previousValue'] === 'string' ? consensus['previousValue'] : null,
                        participantAgentIds: Array.isArray(consensus['participantAgentIds'])
                            ? consensus['participantAgentIds'].filter((item) => typeof item === 'string')
                            : [],
                        responseCount: Number(consensus['responseCount'] ?? 0),
                        resolution: typeof consensus['resolution'] === 'string' ? consensus['resolution'] : null,
                        updatedAt: task.updatedAt.toISOString(),
                    };
                })
                    .sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
                res.json({ conflicts: conflictTasks });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/workspaces/:workspaceId/shared-memory/:key', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId ?? '').trim();
                const key = String(req.params.key ?? '').trim();
                const userId = String(req.query.userId ?? '').trim();
                const channel = String(req.query.channel ?? 'web').trim();
                if (!workspaceId || !userId || !key) {
                    res.status(400).json({ error: 'workspaceId, userId, and key are required' });
                    return;
                }
                const scope = { userId, channel, workspaceId };
                const oldValue = await memoryStore.getScopedMemory(scope, key);
                if (oldValue !== null) {
                    await memoryStore.recordScopedMemoryChange(scope, key, oldValue, '', 'manual');
                }
                const ok = await memoryStore.deleteScopedMemory(scope, key);
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-approvals', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const approvals = await memoryStore.listTeamTaskApprovals({
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(typeof req.query.taskId === 'string' ? { taskId: req.query.taskId } : {}),
                    ...(typeof req.query.status === 'string' ? { status: req.query.status } : {}),
                    ...(typeof req.query.requestedForUserId === 'string' ? { requestedForUserId: req.query.requestedForUserId } : {}),
                });
                res.json({ approvals });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-governance/:taskId/retry', requireAuth, async (req, res) => {
            try {
                const actorUserId = String(req.authUser?.sub ?? '').trim() || null;
                const admin = isAdminUser(req.authUser);
                const taskId = String(req.params.taskId ?? '').trim();
                if (!taskId) {
                    res.status(400).json({ error: 'taskId is required' });
                    return;
                }
                const task = await memoryStore.getTeamTask(taskId);
                if (!task) {
                    res.status(404).json({ error: 'Governance task not found' });
                    return;
                }
                if (!canViewGovernanceTask(task, actorUserId, admin)) {
                    res.status(403).json({ error: 'Forbidden' });
                    return;
                }
                const result = await retrySharedMemoryGovernanceTaskById(taskId, actorUserId);
                if (!result.task) {
                    res.status(404).json({ error: result.error ?? 'Governance task not found' });
                    return;
                }
                if (!result.ok) {
                    res.status(409).json({ error: result.error ?? 'Governance retry did not complete', task: result.task });
                    return;
                }
                res.json({ ok: true, task: result.task });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-governance/:taskId', requireAuth, async (req, res) => {
            try {
                const actorUserId = String(req.authUser?.sub ?? '').trim() || null;
                const admin = isAdminUser(req.authUser);
                const taskId = String(req.params.taskId ?? '').trim();
                if (!taskId) {
                    res.status(400).json({ error: 'taskId is required' });
                    return;
                }
                const task = await memoryStore.getTeamTask(taskId);
                if (!task) {
                    res.status(404).json({ error: 'Governance task not found' });
                    return;
                }
                if (!canViewGovernanceTask(task, actorUserId, admin)) {
                    res.status(403).json({ error: 'Forbidden' });
                    return;
                }
                const metadata = task.metadata ?? {};
                if (metadata['governanceKind'] !== 'shared_memory_authority') {
                    res.status(400).json({ error: 'Task is not a shared memory governance task' });
                    return;
                }
                const scopeUserId = typeof metadata['sharedMemoryScopeUserId'] === 'string' && metadata['sharedMemoryScopeUserId'].trim()
                    ? metadata['sharedMemoryScopeUserId'].trim()
                    : task.createdBy;
                const scopeChannel = parseChannelName(metadata['sharedMemoryScopeChannel'])
                    ?? parseChannelName(metadata['requestChannel'])
                    ?? 'web';
                const key = typeof metadata['sharedMemoryKey'] === 'string' ? metadata['sharedMemoryKey'].trim() : '';
                const scope = { userId: scopeUserId, channel: scopeChannel, workspaceId: task.workspaceId };
                const versionKey = key ? `${key}::__meta_version` : '';
                const [approvals, notifications, mailbox, currentValue, currentVersionRaw, history] = await Promise.all([
                    memoryStore.listTeamTaskApprovals({ taskId: task.id }),
                    memoryStore.listTeamNotifications({ taskId: task.id }),
                    memoryStore.listTeamMailboxMessages({ taskId: task.id }),
                    key ? memoryStore.getScopedMemory(scope, key) : Promise.resolve(null),
                    versionKey ? memoryStore.getScopedMemory(scope, versionKey) : Promise.resolve(null),
                    key ? memoryStore.getScopedMemoryHistory(scope, 50) : Promise.resolve([]),
                ]);
                const filteredHistory = key
                    ? history.filter((entry) => entry.key === key).slice(0, 20)
                    : [];
                res.json({
                    task,
                    governance: summarizeDashboardGovernanceTask(task),
                    approvals: approvals.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()),
                    notifications: notifications.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()).slice(0, 20),
                    mailbox: mailbox.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()).slice(0, 20),
                    memory: {
                        scopeUserId,
                        scopeChannel,
                        key: key || null,
                        currentValue,
                        currentVersion: Number.isFinite(Number(currentVersionRaw)) ? Number(currentVersionRaw) : null,
                        history: filteredHistory,
                    },
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/my/team-approvals', requireAuth, async (req, res) => {
            try {
                const actor = getTopologyControlActor(req);
                if (!actor.userId) {
                    res.status(403).json({ error: 'Authenticated user required' });
                    return;
                }
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const taskId = typeof req.query.taskId === 'string' ? req.query.taskId : undefined;
                const status = typeof req.query.status === 'string' ? req.query.status : undefined;
                const approvals = await memoryStore.listTeamTaskApprovals({
                    requestedForUserId: actor.userId,
                    ...(workspaceId ? { workspaceId } : {}),
                    ...(taskId ? { taskId } : {}),
                    ...(status ? { status } : {}),
                });
                const extraApprovals = status !== undefined && status !== 'pending'
                    ? []
                    : (await memoryStore.listTeamTaskApprovals({
                        ...(workspaceId ? { workspaceId } : {}),
                        ...(taskId ? { taskId } : {}),
                        status: 'pending',
                    }));
                const extraApprovalIds = new Set(approvals.map((approval) => approval.id));
                const extraEligibleApprovals = (await Promise.all(extraApprovals.map(async (approval) => {
                    if (extraApprovalIds.has(approval.id) || approval.requestedForUserId === actor.userId)
                        return null;
                    const task = await memoryStore.getTeamTask(approval.taskId);
                    if (!task || !canActorApproveTopologyGovernanceTask(task, actor))
                        return null;
                    return approval;
                }))).filter((approval) => Boolean(approval));
                approvals.push(...extraEligibleApprovals);
                res.json({
                    approvals: approvals.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()),
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/my/team-approvals/:id', requireAuth, async (req, res) => {
            try {
                const actor = getTopologyControlActor(req);
                if (!actor.userId) {
                    res.status(403).json({ error: 'Authenticated user required' });
                    return;
                }
                const body = req.body;
                if (body.status !== 'approved' && body.status !== 'rejected') {
                    res.status(400).json({ error: 'status must be approved or rejected' });
                    return;
                }
                const approvalId = String(req.params.id);
                const approvals = await memoryStore.listTeamTaskApprovals();
                const approval = approvals.find((item) => item.id === approvalId);
                if (!approval) {
                    res.status(404).json({ error: 'Approval not found' });
                    return;
                }
                const directAssignee = approval.requestedForUserId === actor.userId;
                const task = await memoryStore.getTeamTask(approval.taskId);
                const policyApprover = task ? canActorApproveTopologyGovernanceTask(task, actor) : false;
                if (!directAssignee && !policyApprover) {
                    res.status(403).json({ error: 'Forbidden: approval belongs to another user' });
                    return;
                }
                const result = await resolveTeamApprovalById(approvalId, body.status === 'approved' ? 'approve' : 'reject', typeof body.resolutionNotes === 'string' ? body.resolutionNotes : null, actor.userId, { bypassActorCheck: !directAssignee && policyApprover });
                if (!result.approvalUpdated) {
                    res.status(404).json({ error: 'Approval not found' });
                    return;
                }
                const updatedApprovals = await memoryStore.listTeamTaskApprovals({ taskId: result.task?.id });
                const updatedApproval = updatedApprovals.find((item) => item.id === approvalId) ?? null;
                res.json({ approval: updatedApproval, task: result.task });
            }
            catch (err) {
                if (respondKnownTeamError(res, err))
                    return;
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-approvals/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const approvalId = String(req.params.id);
                if ((body.status === 'approved' || body.status === 'rejected') && body.applyTaskDecision === true) {
                    const result = await resolveTeamApprovalById(approvalId, body.status === 'approved' ? 'approve' : 'reject', typeof body.resolutionNotes === 'string' ? body.resolutionNotes : null, req.authUser?.sub ?? null, { bypassActorCheck: true });
                    if (!result.approvalUpdated) {
                        res.status(404).json({ error: 'Approval not found' });
                        return;
                    }
                    const approvals = await memoryStore.listTeamTaskApprovals({ taskId: result.task?.id });
                    const approval = approvals.find((item) => item.id === approvalId) ?? null;
                    res.json({ approval, task: result.task });
                    return;
                }
                const approval = await memoryStore.updateTeamTaskApproval(approvalId, {
                    ...(body.status === 'pending' || body.status === 'approved' || body.status === 'rejected'
                        ? { status: body.status }
                        : {}),
                    ...(body.resolutionNotes === null || typeof body.resolutionNotes === 'string'
                        ? { resolutionNotes: body.resolutionNotes }
                        : {}),
                    ...(body.resolvedAt === null || typeof body.resolvedAt === 'string'
                        ? { resolvedAt: body.resolvedAt ? new Date(body.resolvedAt) : null }
                        : {}),
                });
                if (!approval) {
                    res.status(404).json({ error: 'Approval not found' });
                    return;
                }
                res.json({ approval });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-notifications', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const notifications = await memoryStore.listTeamNotifications({
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(typeof req.query.recipientUserId === 'string' ? { recipientUserId: req.query.recipientUserId } : {}),
                    ...(parseTeamNotificationStatus(req.query.status) ? { status: parseTeamNotificationStatus(req.query.status) } : {}),
                    ...(parseTeamNotificationDeliveryStatus(req.query.deliveryStatus) ? { deliveryStatus: parseTeamNotificationDeliveryStatus(req.query.deliveryStatus) } : {}),
                    ...(typeof req.query.type === 'string' ? { type: req.query.type } : {}),
                    ...(typeof req.query.taskId === 'string' ? { taskId: req.query.taskId } : {}),
                    ...(typeof req.query.approvalId === 'string' ? { approvalId: req.query.approvalId } : {}),
                });
                res.json({ notifications });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/my/team-notifications', requireAuth, async (req, res) => {
            try {
                const actorUserId = String(req.authUser?.sub ?? '').trim();
                if (!actorUserId) {
                    res.status(403).json({ error: 'Authenticated user required' });
                    return;
                }
                const notifications = await memoryStore.listTeamNotifications({
                    recipientUserId: actorUserId,
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(parseTeamNotificationStatus(req.query.status) ? { status: parseTeamNotificationStatus(req.query.status) } : {}),
                    ...(parseTeamNotificationDeliveryStatus(req.query.deliveryStatus) ? { deliveryStatus: parseTeamNotificationDeliveryStatus(req.query.deliveryStatus) } : {}),
                    ...(typeof req.query.type === 'string' ? { type: req.query.type } : {}),
                });
                res.json({ notifications });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/my/team-notifications/:id', requireAuth, async (req, res) => {
            try {
                const actorUserId = String(req.authUser?.sub ?? '').trim();
                if (!actorUserId) {
                    res.status(403).json({ error: 'Authenticated user required' });
                    return;
                }
                const existing = await memoryStore.listTeamNotifications({
                    recipientUserId: actorUserId,
                });
                const target = existing.find((item) => item.id === String(req.params.id));
                if (!target) {
                    res.status(404).json({ error: 'Notification not found' });
                    return;
                }
                const body = req.body;
                const status = parseTeamNotificationStatus(body.status);
                const notification = await memoryStore.updateTeamNotification(target.id, {
                    ...(status ? { status } : {}),
                    ...(body.readAt === null || typeof body.readAt === 'string'
                        ? { readAt: body.readAt ? new Date(body.readAt) : null }
                        : {}),
                });
                res.json({ notification });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-notifications/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const status = parseTeamNotificationStatus(body.status);
                const notification = await memoryStore.updateTeamNotification(String(req.params.id), {
                    ...(status ? { status } : {}),
                    ...(parseTeamNotificationDeliveryStatus(body.deliveryStatus) ? { deliveryStatus: parseTeamNotificationDeliveryStatus(body.deliveryStatus) } : {}),
                    ...(typeof body.title === 'string' ? { title: body.title } : {}),
                    ...(typeof body.message === 'string' ? { message: body.message } : {}),
                    ...(typeof body.metadata === 'object' && body.metadata !== null ? { metadata: body.metadata } : {}),
                    ...(body.readAt === null || typeof body.readAt === 'string'
                        ? { readAt: body.readAt ? new Date(body.readAt) : null }
                        : {}),
                    ...(typeof body.deliveryAttemptCount === 'number' ? { deliveryAttemptCount: body.deliveryAttemptCount } : {}),
                    ...(body.lastDeliveryError === null || typeof body.lastDeliveryError === 'string'
                        ? { lastDeliveryError: body.lastDeliveryError }
                        : {}),
                    ...(body.lastDeliveryAttemptAt === null || typeof body.lastDeliveryAttemptAt === 'string'
                        ? { lastDeliveryAttemptAt: body.lastDeliveryAttemptAt ? new Date(body.lastDeliveryAttemptAt) : null }
                        : {}),
                    ...(body.deliveredAt === null || typeof body.deliveredAt === 'string'
                        ? { deliveredAt: body.deliveredAt ? new Date(body.deliveredAt) : null }
                        : {}),
                });
                if (!notification) {
                    res.status(404).json({ error: 'Notification not found' });
                    return;
                }
                res.json({ notification });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-notifications/:id/retry', requireAuth, async (req, res) => {
            try {
                const actorUserId = String(req.authUser?.sub ?? '').trim() || null;
                const admin = isAdminUser(req.authUser);
                const notificationId = String(req.params.id ?? '').trim();
                if (!notificationId) {
                    res.status(400).json({ error: 'Notification id required' });
                    return;
                }
                const notifications = await memoryStore.listTeamNotifications();
                const notification = notifications.find((item) => item.id === notificationId) ?? null;
                if (!notification) {
                    res.status(404).json({ error: 'Notification not found' });
                    return;
                }
                let allowed = admin || Boolean(actorUserId && notification.recipientUserId === actorUserId);
                if (!allowed && notification.taskId) {
                    const task = await memoryStore.getTeamTask(notification.taskId);
                    allowed = canViewGovernanceTask(task, actorUserId, admin);
                }
                if (!allowed) {
                    res.status(403).json({ error: 'Forbidden' });
                    return;
                }
                const updated = await deliverTeamNotification(notification);
                res.json({ notification: updated });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-notification-routes', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const routes = await memoryStore.listTeamNotificationRoutes({
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(typeof req.query.recipientUserId === 'string' ? { recipientUserId: req.query.recipientUserId } : {}),
                    ...(parseChannelName(req.query.channel) ? { channel: parseChannelName(req.query.channel) } : {}),
                    ...(req.query.enabled === 'true' ? { enabled: true } : req.query.enabled === 'false' ? { enabled: false } : {}),
                });
                res.json({ routes });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-notification-routes', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const workspaceId = String(body.workspaceId ?? '').trim();
                const recipientUserId = String(body.recipientUserId ?? '').trim();
                const channel = parseChannelName(body.channel);
                const chatId = String(body.chatId ?? '').trim();
                if (!workspaceId || !recipientUserId || !channel || !chatId) {
                    res.status(400).json({ error: 'workspaceId, recipientUserId, channel, and chatId are required' });
                    return;
                }
                const route = await memoryStore.createTeamNotificationRoute({
                    workspaceId,
                    recipientUserId,
                    channel,
                    chatId,
                    enabled: body.enabled === undefined ? true : Boolean(body.enabled),
                    createdBy: req.authUser?.sub ?? getStableWebId(),
                    metadata: typeof body.metadata === 'object' && body.metadata !== null ? body.metadata : undefined,
                });
                res.status(201).json({ route });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-notification-routes/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const route = await memoryStore.updateTeamNotificationRoute(String(req.params.id), {
                    ...(typeof body.recipientUserId === 'string' ? { recipientUserId: body.recipientUserId } : {}),
                    ...(parseChannelName(body.channel) ? { channel: parseChannelName(body.channel) } : {}),
                    ...(typeof body.chatId === 'string' ? { chatId: body.chatId } : {}),
                    ...(body.enabled !== undefined ? { enabled: Boolean(body.enabled) } : {}),
                    ...(typeof body.metadata === 'object' && body.metadata !== null ? { metadata: body.metadata } : {}),
                });
                if (!route) {
                    res.status(404).json({ error: 'Notification route not found' });
                    return;
                }
                res.json({ route });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/team-notification-routes/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const ok = await memoryStore.deleteTeamNotificationRoute(String(req.params.id));
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-oncall-rotations', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const rotations = await memoryStore.listTeamOnCallRotations({
                    ...(typeof req.query.workspaceId === 'string' ? { workspaceId: req.query.workspaceId } : {}),
                    ...(req.query.enabled === 'true' ? { enabled: true } : req.query.enabled === 'false' ? { enabled: false } : {}),
                    ...(typeof req.query.department === 'string' ? { department: req.query.department } : {}),
                    ...(typeof req.query.role === 'string' ? { role: req.query.role } : {}),
                });
                res.json({ rotations });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-oncall-rotations', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const workspaceId = String(body.workspaceId ?? '').trim();
                const name = String(body.name ?? '').trim();
                if (!workspaceId || !name) {
                    res.status(400).json({ error: 'workspaceId and name are required' });
                    return;
                }
                const rotation = await memoryStore.createTeamOnCallRotation({
                    workspaceId,
                    name,
                    enabled: body.enabled === undefined ? true : Boolean(body.enabled),
                    scheduleType: parseOnCallScheduleType(body.scheduleType),
                    anchorDate: typeof body.anchorDate === 'string' && body.anchorDate ? new Date(body.anchorDate) : undefined,
                    department: typeof body.department === 'string' ? body.department : undefined,
                    role: typeof body.role === 'string' ? body.role : undefined,
                    primaryAgentIds: parseStringArrayInput(body.primaryAgentIds),
                    secondaryAgentIds: parseStringArrayInput(body.secondaryAgentIds),
                    createdBy: req.authUser?.sub ?? getStableWebId(),
                    metadata: typeof body.metadata === 'object' && body.metadata !== null ? body.metadata : undefined,
                });
                res.status(201).json({ rotation });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-oncall-rotations/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const rotation = await memoryStore.updateTeamOnCallRotation(String(req.params.id), {
                    ...(typeof body.name === 'string' ? { name: body.name } : {}),
                    ...(body.enabled !== undefined ? { enabled: Boolean(body.enabled) } : {}),
                    ...(parseOnCallScheduleType(body.scheduleType) ? { scheduleType: parseOnCallScheduleType(body.scheduleType) } : {}),
                    ...(typeof body.anchorDate === 'string' && body.anchorDate ? { anchorDate: new Date(body.anchorDate) } : {}),
                    ...(body.department === null || typeof body.department === 'string' ? { department: body.department } : {}),
                    ...(body.role === null || typeof body.role === 'string' ? { role: body.role } : {}),
                    ...(body.primaryAgentIds !== undefined ? { primaryAgentIds: parseStringArrayInput(body.primaryAgentIds) ?? [] } : {}),
                    ...(body.secondaryAgentIds !== undefined ? { secondaryAgentIds: parseStringArrayInput(body.secondaryAgentIds) ?? [] } : {}),
                    ...(typeof body.metadata === 'object' && body.metadata !== null ? { metadata: body.metadata } : {}),
                });
                if (!rotation) {
                    res.status(404).json({ error: 'On-call rotation not found' });
                    return;
                }
                res.json({ rotation });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/team-oncall-rotations/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const ok = await memoryStore.deleteTeamOnCallRotation(String(req.params.id));
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-templates', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const templates = await memoryStore.listTeamTemplates(typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined);
                res.json({ templates });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-templates', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const workspaceId = String(body.workspaceId ?? '').trim();
                const name = String(body.name ?? '').trim();
                if (!workspaceId || !name || !Array.isArray(body.taskBlueprints)) {
                    res.status(400).json({ error: 'workspaceId, name, and taskBlueprints are required' });
                    return;
                }
                const template = await memoryStore.createTeamTemplate({
                    workspaceId,
                    name,
                    description: typeof body.description === 'string' ? body.description : undefined,
                    department: typeof body.department === 'string' ? body.department : undefined,
                    role: typeof body.role === 'string' ? body.role : undefined,
                    goalTemplate: typeof body.goalTemplate === 'string' ? body.goalTemplate : undefined,
                    variables: parseTeamTemplateVariableDefinitions(body.variables),
                    taskBlueprints: body.taskBlueprints,
                    createdBy: req.authUser?.sub ?? getStableWebId(),
                    metadata: typeof body.metadata === 'object' && body.metadata !== null ? body.metadata : undefined,
                });
                res.status(201).json({ template });
            }
            catch (err) {
                if (respondKnownTeamError(res, err))
                    return;
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-templates/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const template = await memoryStore.updateTeamTemplate(String(req.params.id), {
                    ...(typeof body.name === 'string' ? { name: body.name } : {}),
                    ...(body.description === null || typeof body.description === 'string' ? { description: body.description } : {}),
                    ...(body.department === null || typeof body.department === 'string' ? { department: body.department } : {}),
                    ...(body.role === null || typeof body.role === 'string' ? { role: body.role } : {}),
                    ...(body.goalTemplate === null || typeof body.goalTemplate === 'string' ? { goalTemplate: body.goalTemplate } : {}),
                    ...(body.variables !== undefined ? { variables: parseTeamTemplateVariableDefinitions(body.variables) ?? [] } : {}),
                    ...(Array.isArray(body.taskBlueprints) ? { taskBlueprints: body.taskBlueprints } : {}),
                    ...(typeof body.metadata === 'object' && body.metadata !== null ? { metadata: body.metadata } : {}),
                });
                if (!template) {
                    res.status(404).json({ error: 'Template not found' });
                    return;
                }
                res.json({ template });
            }
            catch (err) {
                if (respondKnownTeamError(res, err))
                    return;
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/team-templates/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const ok = await memoryStore.deleteTeamTemplate(String(req.params.id));
                res.json({ ok });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-templates/:id/instantiate', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const template = await memoryStore.getTeamTemplate(String(req.params.id));
                if (!template) {
                    res.status(404).json({ error: 'Template not found' });
                    return;
                }
                const userId = String(body.userId ?? req.authUser?.sub ?? getStableWebId()).trim();
                const channel = String(body.channel ?? 'web').trim();
                const chatId = String(body.chatId ?? template.workspaceId).trim();
                const tasks = await instantiateTeamTemplateById(template.id, {
                    sessionId: `team-template:${template.id}`,
                    userId,
                    channel,
                    chatId,
                    workspaceId: template.workspaceId,
                    history: [],
                    role: req.authUser?.role === 'readonly' ? 'user' : req.authUser?.role,
                }, {
                    humanOwnerUserId: body.humanOwnerUserId === null || typeof body.humanOwnerUserId === 'string'
                        ? body.humanOwnerUserId
                        : undefined,
                    variables: parseTeamTemplateVariableValues(body.variables),
                    workerAgentIds: parseStringArrayInput(body.workerAgentIds),
                    supervisorAgentId: body.supervisorAgentId === null || typeof body.supervisorAgentId === 'string'
                        ? body.supervisorAgentId
                        : undefined,
                });
                res.status(201).json({ tasks });
            }
            catch (err) {
                if (respondKnownTeamError(res, err))
                    return;
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-topologies', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const [topologies, tasks] = await Promise.all([
                    memoryStore.listTeamTopologies(workspaceId),
                    memoryStore.listTeamTasks(workspaceId ? { workspaceId } : undefined),
                ]);
                res.json({
                    topologies: topologies.map((topology) => {
                        const topologyTasks = tasks.filter((task) => typeof (task.metadata ?? {})['topologyId'] === 'string'
                            && task.metadata['topologyId'] === topology.id);
                        return {
                            ...topology,
                            summary: {
                                workerCount: topology.workerAgentIds.length,
                                taskCount: topologyTasks.length,
                                openTaskCount: topologyTasks.filter((task) => task.status !== 'done' && task.status !== 'cancelled').length,
                                blockedTaskCount: topologyTasks.filter((task) => task.status === 'blocked').length,
                                doneTaskCount: topologyTasks.filter((task) => task.status === 'done').length,
                                strategyVersion: topology.strategyVersion ?? 1,
                                strategyUpdatedAt: topology.strategyUpdatedAt ?? null,
                                candidateStrategy: topology.candidateStrategy ?? null,
                                candidateRolloutPolicy: topology.candidateRolloutPolicy ?? null,
                                taskStrategyVersions: Object.entries(topologyTasks.reduce((acc, task) => {
                                    const version = Number((task.metadata ?? {})['topologyStrategyVersion'] ?? 1);
                                    const key = Number.isFinite(version) && version >= 1 ? String(Math.floor(version)) : '1';
                                    acc[key] = (acc[key] ?? 0) + 1;
                                    return acc;
                                }, {})).map(([version, count]) => ({ version: Number(version), count })),
                                taskStrategyTracks: Object.entries(topologyTasks.reduce((acc, task) => {
                                    const track = (task.metadata ?? {})['topologyStrategyTrack'] === 'candidate' ? 'candidate' : 'stable';
                                    acc[track] = (acc[track] ?? 0) + 1;
                                    return acc;
                                }, {})).map(([track, count]) => ({ track, count })),
                            },
                        };
                    }),
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/team-topologies/:id/runtime', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const topology = await memoryStore.getTeamTopology(String(req.params.id));
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const [tasks, agents, approvals, policy, notificationRoutes] = await Promise.all([
                    memoryStore.listTeamTasks({ workspaceId: topology.workspaceId }),
                    memoryStore.listAgents(),
                    memoryStore.listTeamTaskApprovals({ workspaceId: topology.workspaceId }),
                    memoryStore.getTeamPolicy(topology.workspaceId),
                    memoryStore.listTeamNotificationRoutes({ workspaceId: topology.workspaceId, enabled: true }),
                ]);
                const controlAudit = (await memoryStore.queryAuditLog({ channel: 'web', limit: 200 }))
                    .filter((entry) => {
                    const skillName = entry.skillName || '';
                    const params = entry.params ?? {};
                    return skillName.startsWith('admin.team_topology.')
                        && params['topologyId'] === topology.id;
                })
                    .slice(0, 40);
                const topologyTasks = tasks.filter((task) => typeof (task.metadata ?? {})['topologyId'] === 'string'
                    && task.metadata['topologyId'] === topology.id);
                const topologyApprovalTasks = topologyTasks.filter((task) => {
                    const metadata = task.metadata ?? {};
                    return metadata['governanceKind'] === 'topology_candidate_promotion'
                        || metadata['governanceKind'] === 'topology_control_action';
                });
                const topologyApprovalTaskIds = new Set(topologyApprovalTasks.map((task) => task.id));
                const topologyPendingApprovals = approvals
                    .filter((approval) => topologyApprovalTaskIds.has(approval.taskId))
                    .map((approval) => {
                    const task = topologyApprovalTasks.find((item) => item.id === approval.taskId) ?? null;
                    const metadata = task?.metadata ?? {};
                    const approvalPolicy = policy ?? buildDefaultTeamPolicy(topology.workspaceId);
                    const routing = task
                        ? resolveApprovalRoutingSummary({ task, approval, policy: approvalPolicy })
                        : null;
                    const levelStartedAtMs = routing?.levelStartedAt ? Date.parse(routing.levelStartedAt) : approval.createdAt.getTime();
                    const reminderAtMs = levelStartedAtMs + (routing?.reminderAfterMinutes ?? approvalPolicy.approvalReminderAfterMinutes) * 60_000;
                    const escalationAtMs = levelStartedAtMs + (routing?.escalationAfterMinutes ?? approvalPolicy.approvalEscalationAfterMinutes) * 60_000;
                    const nowMs = Date.now();
                    const status = approval.status === 'pending'
                        ? (nowMs >= escalationAtMs
                            ? 'escalation_due'
                            : nowMs >= reminderAtMs
                                ? 'reminder_due'
                                : 'within_sla')
                        : approval.status;
                    const escalationRecipient = routing?.escalationRecipient ?? (task ? resolveApprovalEscalationRecipient(task, approval, approvalPolicy) : null);
                    const approvalBroadcastRecipients = Array.from(new Set([
                        approval.requestedForUserId,
                        ...((Array.isArray(metadata['approvalBroadcastUserIds'])
                            ? metadata['approvalBroadcastUserIds'].filter((item) => typeof item === 'string' && item.trim().length > 0)
                            : [])),
                    ]));
                    const approvalResolvedRecipients = Array.from(new Set([
                        task?.createdBy ?? null,
                        approval.requestedForUserId,
                        ...approvalBroadcastRecipients,
                    ].filter((value) => typeof value === 'string' && value.trim().length > 0)));
                    const approvalChain = Array.isArray(metadata['approvalChain'])
                        ? metadata['approvalChain']
                            .filter((entry) => Boolean(entry) && typeof entry === 'object' && !Array.isArray(entry))
                            .map((entry) => ({
                            event: typeof entry['event'] === 'string' ? entry['event'] : 'unknown',
                            at: typeof entry['at'] === 'string' ? entry['at'] : null,
                            fromUserId: typeof entry['fromUserId'] === 'string' ? entry['fromUserId'] : null,
                            toUserId: typeof entry['toUserId'] === 'string' ? entry['toUserId'] : null,
                            approvalId: typeof entry['approvalId'] === 'string' ? entry['approvalId'] : null,
                            nextApprovalId: typeof entry['nextApprovalId'] === 'string' ? entry['nextApprovalId'] : null,
                            ageMinutes: Number.isFinite(Number(entry['ageMinutes'])) ? Number(entry['ageMinutes']) : null,
                            reason: typeof entry['reason'] === 'string' ? entry['reason'] : null,
                        }))
                        : [];
                    return {
                        approvalId: approval.id,
                        taskId: approval.taskId,
                        title: task?.title ?? approval.taskId,
                        governanceKind: typeof metadata['governanceKind'] === 'string' ? metadata['governanceKind'] : null,
                        action: typeof metadata['topologyControlAction'] === 'string'
                            ? metadata['topologyControlAction']
                            : (typeof metadata['governanceKind'] === 'string' ? metadata['governanceKind'] : null),
                        requestedByUserId: approval.requestedBy,
                        requestedForUserId: approval.requestedForUserId,
                        humanOwnerUserId: task?.humanOwnerUserId ?? null,
                        status: approval.status,
                        slaStatus: status,
                        createdAt: approval.createdAt.toISOString(),
                        updatedAt: approval.updatedAt.toISOString(),
                        resolvedAt: approval.resolvedAt ? approval.resolvedAt.toISOString() : null,
                        ageMinutes: Math.max(0, Math.floor((nowMs - levelStartedAtMs) / 60_000)),
                        reminderDueAt: new Date(reminderAtMs).toISOString(),
                        escalationDueAt: new Date(escalationAtMs).toISOString(),
                        reason: approval.reason,
                        notes: approval.resolutionNotes ?? null,
                        approvalChain,
                        approvalRouting: routing ? {
                            currentLevelIndex: routing.currentLevelIndex,
                            currentLevel: routing.currentLevel,
                            nextLevel: routing.nextLevel,
                            levelStartedAt: routing.levelStartedAt,
                            reminderAfterMinutes: routing.reminderAfterMinutes,
                            escalationAfterMinutes: routing.escalationAfterMinutes,
                        } : null,
                        riskLevel: typeof metadata['topologyControlRiskLevel'] === 'string'
                            ? metadata['topologyControlRiskLevel']
                            : (metadata['governanceKind'] === 'topology_candidate_promotion' ? 'high' : null),
                        notificationPreview: {
                            approvalRequested: previewMatchingNotificationRoutes({
                                routes: notificationRoutes,
                                workspaceId: topology.workspaceId,
                                recipientUserIds: approvalBroadcastRecipients,
                                type: 'approval_requested',
                                severity: (typeof metadata['topologyControlRiskLevel'] === 'string'
                                    ? metadata['topologyControlRiskLevel']
                                    : (metadata['governanceKind'] === 'topology_candidate_promotion' ? 'high' : 'warning')) === 'critical'
                                    ? 'critical'
                                    : ((typeof metadata['topologyControlRiskLevel'] === 'string'
                                        ? metadata['topologyControlRiskLevel']
                                        : (metadata['governanceKind'] === 'topology_candidate_promotion' ? 'high' : 'warning')) === 'high' ? 'critical' : 'warning'),
                                metadata: {
                                    governanceKind: metadata['governanceKind'],
                                    topologyControlAction: metadata['topologyControlAction'],
                                    topologyId: topology.id,
                                },
                            }),
                            approvalReminder: previewMatchingNotificationRoutes({
                                routes: notificationRoutes,
                                workspaceId: topology.workspaceId,
                                recipientUserIds: approvalBroadcastRecipients,
                                type: 'approval_reminder',
                                severity: 'warning',
                                metadata: {
                                    governanceKind: metadata['governanceKind'],
                                    topologyControlAction: metadata['topologyControlAction'],
                                    topologyId: topology.id,
                                },
                            }),
                            approvalEscalated: previewMatchingNotificationRoutes({
                                routes: notificationRoutes,
                                workspaceId: topology.workspaceId,
                                recipientUserIds: [
                                    escalationRecipient,
                                    approval.requestedForUserId,
                                    ...(routing?.escalationAudienceUserIds ?? []),
                                    ...approvalBroadcastRecipients,
                                ],
                                type: 'approval_escalated',
                                severity: 'critical',
                                metadata: {
                                    governanceKind: metadata['governanceKind'],
                                    topologyControlAction: metadata['topologyControlAction'],
                                    topologyId: topology.id,
                                },
                            }),
                            approvalResolved: previewMatchingNotificationRoutes({
                                routes: notificationRoutes,
                                workspaceId: topology.workspaceId,
                                recipientUserIds: approvalResolvedRecipients,
                                type: 'approval_resolved',
                                severity: approval.status === 'rejected' ? 'warning' : 'info',
                                metadata: {
                                    governanceKind: metadata['governanceKind'],
                                    topologyControlAction: metadata['topologyControlAction'],
                                    topologyId: topology.id,
                                },
                            }),
                        },
                    };
                })
                    .sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
                const topologyResolvedApprovals = topologyPendingApprovals
                    .filter((approval) => approval.status !== 'pending')
                    .sort((a, b) => Date.parse(b.resolvedAt || b.updatedAt) - Date.parse(a.resolvedAt || a.updatedAt))
                    .slice(0, 20);
                const topologyOpenApprovals = topologyPendingApprovals.filter((approval) => approval.status === 'pending');
                const topologyPromotionGovernanceTasks = topologyTasks.filter((task) => (task.metadata ?? {})['governanceKind'] === 'topology_candidate_promotion');
                const topologyAgents = agents.filter((agentDef) => agentDef.workspaceId === topology.workspaceId
                    && (agentDef.id === topology.supervisorAgentId || topology.workerAgentIds.includes(agentDef.id)));
                const routeKeys = [
                    'orchestrator',
                    'challenge_reflection',
                    'success_reflection',
                    'reviewer',
                    'heartbeat',
                    'default_worker',
                ];
                const effectiveRoutes = Object.fromEntries(routeKeys
                    .map((key) => [key, resolveTeamTopologyModelRoute(topology, key)])
                    .filter((entry) => Boolean(entry[1])));
                const metadata = topology.metadata ?? {};
                const adaptiveOrchestratorPolicy = parseAdaptiveOrchestratorPolicy(metadata['adaptiveOrchestratorPolicy']);
                const orchFrozenUntil = typeof metadata['lastOrchFrozenUntil'] === 'string' && metadata['lastOrchFrozenUntil'].trim()
                    ? metadata['lastOrchFrozenUntil']
                    : null;
                const orchFrozenUntilMs = orchFrozenUntil ? Date.parse(orchFrozenUntil) : Number.NaN;
                const storedMetrics = metadata['lastOrchMetrics'] && typeof metadata['lastOrchMetrics'] === 'object' && !Array.isArray(metadata['lastOrchMetrics'])
                    ? metadata['lastOrchMetrics']
                    : null;
                const liveMetrics = computeSwarmMetrics(topologyTasks, topology.id);
                const stableTrackMetrics = computeStrategyTrackSwarmMetrics(topologyTasks, topology.id, 'stable');
                const candidateTrackMetrics = computeStrategyTrackSwarmMetrics(topologyTasks, topology.id, 'candidate');
                const defaultControlPolicy = getTopologyControlAccessPolicy(topology);
                const defaultControlScope = resolveTopologyControlActionScope(defaultControlPolicy, 'default');
                const fallbackApproverUserId = topology.defaultHumanOwnerUserId ?? topology.createdBy ?? null;
                const defaultControlAccessScope = {
                    action: 'default',
                    requesterUserIds: defaultControlScope.requesterUserIds,
                    requesterRoleGroups: defaultControlScope.requesterRoleGroups,
                    approverUserIds: defaultControlScope.approverUserIds,
                    approverRoleGroups: defaultControlScope.approverRoleGroups,
                    escalationChain: resolveTopologyControlEscalationChain(defaultControlScope.escalationChain, fallbackApproverUserId),
                    fallbackApproverUserId,
                    effectiveRequesterUserIds: Array.from(new Set([
                        ...defaultControlScope.requesterUserIds,
                        ...getWebUserIdsForRoleGroups(defaultControlScope.requesterRoleGroups),
                    ])),
                    effectiveApproverUserIds: Array.from(new Set([
                        ...defaultControlScope.approverUserIds,
                        ...getWebUserIdsForRoleGroups(defaultControlScope.approverRoleGroups),
                        ...(fallbackApproverUserId ? [fallbackApproverUserId] : []),
                    ].filter((value) => typeof value === 'string' && value.trim().length > 0))),
                    primaryApproverUserId: null,
                };
                defaultControlAccessScope.primaryApproverUserId = defaultControlAccessScope.effectiveApproverUserIds[0] ?? defaultControlAccessScope.fallbackApproverUserId ?? null;
                const controlAccessByAction = {
                    promote_strategy: resolveTopologyGovernanceApprovalScope(topology, 'promote_strategy', 'topology_control_action'),
                    promote_candidate: resolveTopologyGovernanceApprovalScope(topology, 'promote_candidate', 'topology_candidate_promotion'),
                    candidate_rollout_disable: resolveTopologyGovernanceApprovalScope(topology, 'candidate_rollout_disable', 'topology_control_action'),
                    candidate_rollout_freeze: resolveTopologyGovernanceApprovalScope(topology, 'candidate_rollout_freeze', 'topology_control_action'),
                    orchestrator_control: resolveTopologyGovernanceApprovalScope(topology, 'orchestrator_control', 'topology_control_action'),
                    rollback_strategy: resolveTopologyGovernanceApprovalScope(topology, 'rollback_strategy', 'topology_control_action'),
                    delete_topology: resolveTopologyGovernanceApprovalScope(topology, 'delete_topology', 'topology_control_action'),
                };
                const controlNotificationPreview = {
                    promote_strategy: {
                        approvalRequested: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: controlAccessByAction.promote_strategy.effectiveApproverUserIds,
                            type: 'approval_requested',
                            severity: 'critical',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'promote_strategy', topologyId: topology.id },
                        }),
                        approvalResolved: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: [
                                ...controlAccessByAction.promote_strategy.effectiveRequesterUserIds,
                                ...controlAccessByAction.promote_strategy.effectiveApproverUserIds,
                            ],
                            type: 'approval_resolved',
                            severity: 'info',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'promote_strategy', topologyId: topology.id },
                        }),
                    },
                    promote_candidate: {
                        approvalRequested: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: controlAccessByAction.promote_candidate.effectiveApproverUserIds,
                            type: 'approval_requested',
                            severity: 'critical',
                            metadata: { governanceKind: 'topology_candidate_promotion', topologyId: topology.id },
                        }),
                        approvalResolved: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: [
                                ...controlAccessByAction.promote_candidate.effectiveRequesterUserIds,
                                ...controlAccessByAction.promote_candidate.effectiveApproverUserIds,
                            ],
                            type: 'approval_resolved',
                            severity: 'info',
                            metadata: { governanceKind: 'topology_candidate_promotion', topologyId: topology.id },
                        }),
                    },
                    candidate_rollout_disable: {
                        approvalRequested: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: controlAccessByAction.candidate_rollout_disable.effectiveApproverUserIds,
                            type: 'approval_requested',
                            severity: 'critical',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'candidate_rollout_disable', topologyId: topology.id },
                        }),
                        approvalResolved: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: [
                                ...controlAccessByAction.candidate_rollout_disable.effectiveRequesterUserIds,
                                ...controlAccessByAction.candidate_rollout_disable.effectiveApproverUserIds,
                            ],
                            type: 'approval_resolved',
                            severity: 'info',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'candidate_rollout_disable', topologyId: topology.id },
                        }),
                    },
                    candidate_rollout_freeze: {
                        approvalRequested: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: controlAccessByAction.candidate_rollout_freeze.effectiveApproverUserIds,
                            type: 'approval_requested',
                            severity: 'warning',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'candidate_rollout_freeze', topologyId: topology.id },
                        }),
                        approvalResolved: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: [
                                ...controlAccessByAction.candidate_rollout_freeze.effectiveRequesterUserIds,
                                ...controlAccessByAction.candidate_rollout_freeze.effectiveApproverUserIds,
                            ],
                            type: 'approval_resolved',
                            severity: 'info',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'candidate_rollout_freeze', topologyId: topology.id },
                        }),
                    },
                    orchestrator_control: {
                        approvalRequested: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: controlAccessByAction.orchestrator_control.effectiveApproverUserIds,
                            type: 'approval_requested',
                            severity: 'warning',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'orchestrator_control', topologyId: topology.id },
                        }),
                        approvalResolved: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: [
                                ...controlAccessByAction.orchestrator_control.effectiveRequesterUserIds,
                                ...controlAccessByAction.orchestrator_control.effectiveApproverUserIds,
                            ],
                            type: 'approval_resolved',
                            severity: 'info',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'orchestrator_control', topologyId: topology.id },
                        }),
                    },
                    rollback_strategy: {
                        approvalRequested: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: controlAccessByAction.rollback_strategy.effectiveApproverUserIds,
                            type: 'approval_requested',
                            severity: 'critical',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'rollback_strategy', topologyId: topology.id },
                        }),
                        approvalResolved: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: [
                                ...controlAccessByAction.rollback_strategy.effectiveRequesterUserIds,
                                ...controlAccessByAction.rollback_strategy.effectiveApproverUserIds,
                            ],
                            type: 'approval_resolved',
                            severity: 'info',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'rollback_strategy', topologyId: topology.id },
                        }),
                    },
                    delete_topology: {
                        approvalRequested: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: controlAccessByAction.delete_topology.effectiveApproverUserIds,
                            type: 'approval_requested',
                            severity: 'critical',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'delete_topology', topologyId: topology.id },
                        }),
                        approvalResolved: previewMatchingNotificationRoutes({
                            routes: notificationRoutes,
                            workspaceId: topology.workspaceId,
                            recipientUserIds: [
                                ...controlAccessByAction.delete_topology.effectiveRequesterUserIds,
                                ...controlAccessByAction.delete_topology.effectiveApproverUserIds,
                            ],
                            type: 'approval_resolved',
                            severity: 'info',
                            metadata: { governanceKind: 'topology_control_action', topologyControlAction: 'delete_topology', topologyId: topology.id },
                        }),
                    },
                };
                res.json({
                    runtime: {
                        topologyId: topology.id,
                        workspaceId: topology.workspaceId,
                        name: topology.name,
                        strategyVersion: topology.strategyVersion ?? 1,
                        strategyUpdatedAt: topology.strategyUpdatedAt ?? null,
                        strategyHistory: topology.strategyHistory ?? [],
                        candidateStrategy: topology.candidateStrategy ?? null,
                        candidateRolloutPolicy: topology.candidateRolloutPolicy ?? null,
                        candidateRolloutControl: topology.candidateRolloutControl ?? null,
                        supervisorAgentId: topology.supervisorAgentId ?? null,
                        workerAgentIds: topology.workerAgentIds,
                        currentRules: topology.orchestratorRules ?? parseOrchestratorRules(metadata['orchestratorRules']),
                        adaptiveModelPolicy: topology.adaptiveModelPolicy ?? parseAdaptiveModelPolicyInput(metadata['adaptiveModelPolicy']),
                        modelRoutes: topology.modelRoutes ?? parseTeamTopologyModelRoutes(metadata['modelRoutes']),
                        effectiveRoutes,
                        adaptiveModelState: typeof metadata['adaptiveModelState'] === 'string' ? metadata['adaptiveModelState'] : 'baseline',
                        lastAdaptiveModelAction: typeof metadata['lastAdaptiveModelAction'] === 'string' ? metadata['lastAdaptiveModelAction'] : null,
                        adaptiveOrchestrator: {
                            policy: adaptiveOrchestratorPolicy,
                            lastAction: typeof metadata['lastOrchAction'] === 'string' ? metadata['lastOrchAction'] : null,
                            lastAt: typeof metadata['lastOrchAdaptedAt'] === 'string' ? metadata['lastOrchAdaptedAt'] : null,
                            health: typeof metadata['lastOrchHealth'] === 'string' ? metadata['lastOrchHealth'] : null,
                            degradedStreak: Number.isFinite(Number(metadata['orchDegradedStreak']))
                                ? Number(metadata['orchDegradedStreak'])
                                : 0,
                            control: {
                                frozenUntil: orchFrozenUntil,
                                isFrozen: Number.isFinite(orchFrozenUntilMs) && orchFrozenUntilMs > Date.now(),
                                freezeReason: typeof metadata['lastOrchFreezeReason'] === 'string' ? metadata['lastOrchFreezeReason'] : null,
                                frozenBy: typeof metadata['lastOrchFrozenBy'] === 'string' ? metadata['lastOrchFrozenBy'] : null,
                                manualControl: metadata['lastOrchManualControl'] === true,
                            },
                            rollback: {
                                at: typeof metadata['lastOrchRollbackAt'] === 'string' ? metadata['lastOrchRollbackAt'] : null,
                                fromVersion: Number.isFinite(Number(metadata['lastOrchRollbackFromVersion']))
                                    ? Number(metadata['lastOrchRollbackFromVersion'])
                                    : null,
                                toVersion: Number.isFinite(Number(metadata['lastOrchRollbackToVersion']))
                                    ? Number(metadata['lastOrchRollbackToVersion'])
                                    : null,
                                reason: typeof metadata['lastOrchRollbackReason'] === 'string' ? metadata['lastOrchRollbackReason'] : null,
                            },
                        },
                        metrics: {
                            live: liveMetrics,
                            stored: storedMetrics,
                            lastAdaptiveModelMetrics: metadata['lastAdaptiveModelMetrics'] && typeof metadata['lastAdaptiveModelMetrics'] === 'object' && !Array.isArray(metadata['lastAdaptiveModelMetrics'])
                                ? metadata['lastAdaptiveModelMetrics']
                                : null,
                            lastCandidateRolloutMetrics: metadata['lastCandidateRolloutMetrics'] && typeof metadata['lastCandidateRolloutMetrics'] === 'object' && !Array.isArray(metadata['lastCandidateRolloutMetrics'])
                                ? metadata['lastCandidateRolloutMetrics']
                                : null,
                            byTrack: {
                                stable: stableTrackMetrics,
                                candidate: candidateTrackMetrics,
                            },
                        },
                        candidateRollout: {
                            control: topology.candidateRolloutControl ?? null,
                            lastAction: typeof metadata['lastCandidateRolloutAction'] === 'string' ? metadata['lastCandidateRolloutAction'] : null,
                            lastAt: typeof metadata['lastCandidateRolloutAt'] === 'string' ? metadata['lastCandidateRolloutAt'] : null,
                            lastRolloutPercent: Number.isFinite(Number(metadata['lastCandidateRolloutPercent']))
                                ? Number(metadata['lastCandidateRolloutPercent'])
                                : null,
                            lastPromotionVersion: Number.isFinite(Number(metadata['lastCandidatePromotionVersion']))
                                ? Number(metadata['lastCandidatePromotionVersion'])
                                : null,
                            gate: {
                                pendingApprovalTasks: topologyPromotionGovernanceTasks.filter((task) => task.status !== 'done'
                                    && task.status !== 'cancelled'
                                    && (task.metadata ?? {})['candidatePromotionApprovalStatus'] === 'pending').length,
                                lastPendingTaskId: typeof metadata['pendingCandidatePromotionTaskId'] === 'string'
                                    ? metadata['pendingCandidatePromotionTaskId']
                                    : null,
                                lastPendingApprovalId: typeof metadata['pendingCandidatePromotionApprovalId'] === 'string'
                                    ? metadata['pendingCandidatePromotionApprovalId']
                                    : null,
                            },
                            audit: topology.candidateRolloutAudit ?? [],
                            panel: {
                                stable: stableTrackMetrics,
                                candidate: candidateTrackMetrics,
                            },
                        },
                        tasks: {
                            total: topologyTasks.length,
                            open: topologyTasks.filter((task) => task.status !== 'done' && task.status !== 'cancelled').length,
                            blocked: topologyTasks.filter((task) => task.status === 'blocked').length,
                            done: topologyTasks.filter((task) => task.status === 'done').length,
                            versions: Object.entries(topologyTasks.reduce((acc, task) => {
                                const version = Number((task.metadata ?? {})['topologyStrategyVersion'] ?? 1);
                                const key = Number.isFinite(version) && version >= 1 ? String(Math.floor(version)) : '1';
                                acc[key] = (acc[key] ?? 0) + 1;
                                return acc;
                            }, {})).map(([version, count]) => ({ version: Number(version), count })),
                            tracks: Object.entries(topologyTasks.reduce((acc, task) => {
                                const track = (task.metadata ?? {})['topologyStrategyTrack'] === 'candidate' ? 'candidate' : 'stable';
                                acc[track] = (acc[track] ?? 0) + 1;
                                return acc;
                            }, {})).map(([track, count]) => ({ track, count })),
                            recent: topologyTasks
                                .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())
                                .slice(0, 10)
                                .map((task) => ({
                                id: task.id,
                                title: task.title,
                                status: task.status,
                                assignedAgentId: task.assignedAgentId ?? null,
                                strategyTrack: (task.metadata ?? {})['topologyStrategyTrack'] === 'candidate' ? 'candidate' : 'stable',
                                strategyVersion: Number((task.metadata ?? {})['topologyStrategyVersion'] ?? 1),
                                updatedAt: task.updatedAt.toISOString(),
                                blockedReason: task.blockedReason ?? null,
                            })),
                        },
                        agents: topologyAgents.map((agentDef) => ({
                            id: agentDef.id,
                            name: agentDef.name,
                            status: agentDef.status,
                            provider: agentDef.provider ?? null,
                            model: agentDef.model ?? null,
                            lastHeartbeatStatus: typeof agentDef.metadata?.['lastHeartbeatStatus'] === 'string'
                                ? agentDef.metadata['lastHeartbeatStatus']
                                : null,
                            lastHeartbeatAt: typeof agentDef.metadata?.['lastHeartbeatAt'] === 'string'
                                ? agentDef.metadata['lastHeartbeatAt']
                                : null,
                        })),
                        controlAudit,
                        pendingControlApprovals: topologyOpenApprovals,
                        resolvedControlApprovals: topologyResolvedApprovals,
                        approvalPolicy: {
                            reminderAfterMinutes: policy?.approvalReminderAfterMinutes ?? 30,
                            escalationAfterMinutes: policy?.approvalEscalationAfterMinutes ?? 120,
                        },
                        controlAccess: {
                            requesterUserIds: defaultControlAccessScope.requesterUserIds,
                            requesterRoleGroups: defaultControlAccessScope.requesterRoleGroups,
                            effectiveRequesterUserIds: defaultControlAccessScope.effectiveRequesterUserIds,
                            approverUserIds: defaultControlAccessScope.approverUserIds,
                            approverRoleGroups: defaultControlAccessScope.approverRoleGroups,
                            effectiveApproverUserIds: defaultControlAccessScope.effectiveApproverUserIds,
                            fallbackApprover: defaultControlAccessScope.fallbackApproverUserId,
                            primaryApprover: defaultControlAccessScope.primaryApproverUserId,
                            requestModel: defaultControlAccessScope.requesterUserIds.length > 0 || defaultControlAccessScope.requesterRoleGroups.length > 0
                                ? 'admin_or_topology_policy'
                                : 'admin_only',
                            approvalModel: defaultControlAccessScope.approverUserIds.length > 0 || defaultControlAccessScope.approverRoleGroups.length > 0
                                ? 'explicit_users_groups_then_owner_fallback'
                                : 'owner_fallback_only',
                            actions: controlAccessByAction,
                        },
                        controlNotificationPreview,
                        controlRequirements: buildTopologyControlRequirements(topology),
                    },
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-topologies/:id/promote-strategy', requireAuth, async (req, res) => {
            try {
                const topologyId = String(req.params.id);
                const topology = await memoryStore.getTeamTopology(topologyId);
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const actor = getTopologyControlActor(req);
                if (!canActorRequestTopologyControl(topology, 'promote_strategy', actor)) {
                    res.status(403).json({ error: 'Forbidden: topology control access denied' });
                    return;
                }
                const actorUserId = actor.userId ?? getStableWebId();
                const body = req.body;
                const orchestratorRules = body.orchestratorRules === null ? null : parseOrchestratorRules(body.orchestratorRules);
                const adaptiveModelPolicy = body.adaptiveModelPolicy === null ? null : parseAdaptiveModelPolicyInput(body.adaptiveModelPolicy);
                const adaptiveOrchestratorPolicy = body.adaptiveOrchestratorPolicy === null ? null : parseAdaptiveOrchestratorPolicy(body.adaptiveOrchestratorPolicy);
                const modelRoutes = body.modelRoutes === null ? null : parseTeamTopologyModelRoutes(body.modelRoutes);
                if (body.orchestratorRules !== undefined && body.orchestratorRules !== null && !orchestratorRules) {
                    res.status(400).json({ error: 'Invalid orchestratorRules' });
                    return;
                }
                if (body.adaptiveModelPolicy !== undefined && body.adaptiveModelPolicy !== null && !adaptiveModelPolicy) {
                    res.status(400).json({ error: 'Invalid adaptiveModelPolicy' });
                    return;
                }
                if (body.adaptiveOrchestratorPolicy !== undefined && body.adaptiveOrchestratorPolicy !== null && !adaptiveOrchestratorPolicy) {
                    res.status(400).json({ error: 'Invalid adaptiveOrchestratorPolicy' });
                    return;
                }
                if (body.modelRoutes !== undefined && body.modelRoutes !== null && !modelRoutes) {
                    res.status(400).json({ error: 'Invalid modelRoutes' });
                    return;
                }
                const confirmation = requireTopologyControlConfirmation({
                    req,
                    res,
                    body,
                    topology,
                    action: 'promote_strategy',
                    risk: 'high',
                    requiredReason: true,
                    confirmationPhrase: buildTopologyControlPhrase('promote-strategy', topology),
                });
                if (!confirmation.ok)
                    return;
                const approvalScope = resolveTopologyGovernanceApprovalScope(topology, 'promote_strategy', 'topology_control_action');
                const approverUserId = approvalScope.primaryApproverUserId;
                if (approverUserId) {
                    const approvalTask = await ensureTopologyControlApprovalTask({
                        topology,
                        action: 'promote_strategy',
                        title: `[Governance] Approve strategy promotion: ${topology.name}`,
                        summary: [
                            `Promote stable strategy configuration for topology ${topology.name}.`,
                            `Current stable version: v${topology.strategyVersion ?? 1}.`,
                            `Reason: ${confirmation.reason}`,
                        ].join('\n'),
                        requestedByUserId: actorUserId,
                        requestedForUserId: approverUserId,
                        approverUserIds: approvalScope.approverUserIds,
                        approverRoleGroups: approvalScope.approverRoleGroups,
                        effectiveApproverUserIds: approvalScope.effectiveApproverUserIds,
                        escalationChain: approvalScope.escalationChain,
                        metadata: {
                            topologyControlRiskLevel: 'high',
                            topologyControlReason: confirmation.reason,
                            topologyControlOrchestratorRules: body.orchestratorRules ?? null,
                            topologyControlAdaptiveModelPolicy: body.adaptiveModelPolicy ?? null,
                            topologyControlAdaptiveOrchestratorPolicy: body.adaptiveOrchestratorPolicy ?? null,
                            topologyControlModelRoutes: body.modelRoutes ?? null,
                        },
                    });
                    if (approvalTask) {
                        logAdminAudit(req, 'admin.team_topology.promote_strategy.request_approval', {
                            ...summarizeTopologyAuditParams(topology),
                            approvalTaskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                            reason: confirmation.reason,
                            riskLevel: 'high',
                        });
                        res.status(202).json({
                            approvalRequired: true,
                            taskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                        });
                        return;
                    }
                }
                const updated = await memoryStore.updateTeamTopology(topologyId, {
                    ...(body.orchestratorRules !== undefined ? { orchestratorRules } : {}),
                    ...(body.adaptiveModelPolicy !== undefined ? { adaptiveModelPolicy } : {}),
                    ...(body.modelRoutes !== undefined ? { modelRoutes } : {}),
                });
                if (!updated) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                logAdminAudit(req, 'admin.team_topology.promote_strategy', {
                    ...summarizeTopologyAuditParams(updated),
                    fromVersion: topology.strategyVersion ?? 1,
                    toVersion: updated.strategyVersion ?? 1,
                    updatedFields: [
                        ...(body.orchestratorRules !== undefined ? ['orchestratorRules'] : []),
                        ...(body.adaptiveModelPolicy !== undefined ? ['adaptiveModelPolicy'] : []),
                        ...(body.modelRoutes !== undefined ? ['modelRoutes'] : []),
                        ...(body.adaptiveOrchestratorPolicy !== undefined ? ['adaptiveOrchestratorPolicy'] : []),
                    ],
                    reason: confirmation.reason,
                    riskLevel: 'high',
                });
                res.json({
                    topology: updated,
                    promoted: {
                        fromVersion: topology.strategyVersion ?? 1,
                        toVersion: updated.strategyVersion ?? 1,
                    },
                });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.promote_strategy', {
                    topologyId: String(req.params.id),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-topologies/:id/promote-candidate', requireAuth, async (req, res) => {
            try {
                const topologyId = String(req.params.id);
                const topology = await memoryStore.getTeamTopology(topologyId);
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const actor = getTopologyControlActor(req);
                if (!canActorRequestTopologyControl(topology, 'promote_candidate', actor)) {
                    res.status(403).json({ error: 'Forbidden: topology control access denied' });
                    return;
                }
                const actorUserId = actor.userId ?? getStableWebId();
                const promotion = buildPromoteCandidateStrategyUpdates(topology);
                if (!promotion) {
                    res.status(409).json({ error: 'Topology has no candidate strategy to promote' });
                    return;
                }
                const confirmation = requireTopologyControlConfirmation({
                    req,
                    res,
                    body: req.body,
                    topology,
                    action: 'promote_candidate',
                    risk: 'high',
                    requiredReason: true,
                    confirmationPhrase: buildTopologyControlPhrase('promote-candidate', topology),
                });
                if (!confirmation.ok)
                    return;
                const approvalScope = resolveTopologyGovernanceApprovalScope(topology, 'promote_candidate', 'topology_candidate_promotion');
                const approverUserId = approvalScope.primaryApproverUserId;
                if (approverUserId) {
                    const approvalTask = await ensureManualCandidatePromotionApprovalTask({
                        topology,
                        requestedByUserId: actorUserId,
                        requestedForUserId: approverUserId,
                        reason: confirmation.reason ?? 'Manual candidate promotion requested',
                        approverUserIds: approvalScope.approverUserIds,
                        approverRoleGroups: approvalScope.approverRoleGroups,
                        effectiveApproverUserIds: approvalScope.effectiveApproverUserIds,
                        escalationChain: approvalScope.escalationChain,
                    });
                    if (approvalTask) {
                        logAdminAudit(req, 'admin.team_topology.promote_candidate.request_approval', {
                            ...summarizeTopologyAuditParams(topology),
                            approvalTaskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                            reason: confirmation.reason,
                            riskLevel: 'high',
                        });
                        res.status(202).json({
                            approvalRequired: true,
                            taskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                        });
                        return;
                    }
                }
                const nowIso = new Date().toISOString();
                const updated = await memoryStore.updateTeamTopology(topologyId, promotion.updates);
                if (!updated) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const audited = await memoryStore.updateTeamTopology(topologyId, {
                    metadata: appendCandidateRolloutAuditEvent(updated.metadata, {
                        action: 'manual_promote',
                        at: nowIso,
                        actor: 'user',
                        fromRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                        toRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                        candidateVersion: promotion.candidate.version,
                        stableVersion: updated.strategyVersion ?? 1,
                        reason: 'Manual candidate promotion',
                    }),
                });
                logAdminAudit(req, 'admin.team_topology.promote_candidate', {
                    ...summarizeTopologyAuditParams(audited ?? updated),
                    fromVersion: topology.strategyVersion ?? 1,
                    toVersion: updated.strategyVersion ?? 1,
                    candidateVersion: promotion.candidate.version,
                    rolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                    candidateCleared: !updated.candidateStrategy,
                    reason: confirmation.reason,
                    riskLevel: 'high',
                });
                res.json({
                    topology: audited ?? updated,
                    promoted: {
                        track: 'candidate',
                        candidateVersion: promotion.candidate.version,
                        fromVersion: topology.strategyVersion ?? 1,
                        toVersion: updated.strategyVersion ?? 1,
                        candidateCleared: !updated.candidateStrategy,
                    },
                });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.promote_candidate', {
                    topologyId: String(req.params.id),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-topologies/:id/candidate-rollout-control', requireAuth, async (req, res) => {
            try {
                const topologyId = String(req.params.id);
                const topology = await memoryStore.getTeamTopology(topologyId);
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const body = req.body;
                const frozen = body.frozen === true;
                const enabled = body.enabled !== undefined ? body.enabled === true : (topology.candidateRolloutControl?.enabled ?? true);
                const actor = getTopologyControlActor(req);
                if (!canActorRequestTopologyControl(topology, enabled === false ? 'candidate_rollout_disable' : 'candidate_rollout_freeze', actor)) {
                    res.status(403).json({ error: 'Forbidden: topology control access denied' });
                    return;
                }
                const actorUserId = actor.userId ?? getStableWebId();
                const confirmation = requireTopologyControlConfirmation({
                    req,
                    res,
                    body,
                    topology,
                    action: 'candidate_rollout_control',
                    risk: frozen || enabled === false ? (enabled === false ? 'high' : 'medium') : 'low',
                    requiredReason: frozen || enabled === false,
                    confirmationPhrase: enabled === false ? buildTopologyControlPhrase('disable-rollout', topology) : undefined,
                });
                if (!confirmation.ok)
                    return;
                const reason = confirmation.reason;
                if (enabled === false) {
                    const approvalScope = resolveTopologyGovernanceApprovalScope(topology, 'candidate_rollout_disable', 'topology_control_action');
                    const approverUserId = approvalScope.primaryApproverUserId;
                    if (approverUserId) {
                        const approvalTask = await ensureTopologyControlApprovalTask({
                            topology,
                            action: 'candidate_rollout_disable',
                            title: `[Governance] Approve rollout disable: ${topology.name}`,
                            summary: [
                                `Disable automatic candidate rollout for topology ${topology.name}.`,
                                `Candidate version: ${topology.candidateStrategy?.version ?? 'n/a'}.`,
                                `Reason: ${reason}`,
                            ].join('\n'),
                            requestedByUserId: actorUserId,
                            requestedForUserId: approverUserId,
                            approverUserIds: approvalScope.approverUserIds,
                            approverRoleGroups: approvalScope.approverRoleGroups,
                            effectiveApproverUserIds: approvalScope.effectiveApproverUserIds,
                            escalationChain: approvalScope.escalationChain,
                            metadata: {
                                topologyControlRiskLevel: 'high',
                                topologyControlReason: reason,
                                topologyControlEnabled: false,
                                topologyControlFrozen: false,
                            },
                        });
                        if (approvalTask) {
                            logAdminAudit(req, 'admin.team_topology.candidate_rollout_control.request_approval', {
                                ...summarizeTopologyAuditParams(topology),
                                approvalTaskId: approvalTask.taskId,
                                approvalId: approvalTask.approvalId,
                                reason,
                                riskLevel: 'high',
                                enabled: false,
                            });
                            res.status(202).json({
                                approvalRequired: true,
                                taskId: approvalTask.taskId,
                                approvalId: approvalTask.approvalId,
                            });
                            return;
                        }
                    }
                }
                const nowIso = new Date().toISOString();
                const control = {
                    enabled,
                    frozen,
                    freezeReason: frozen ? reason : null,
                    frozenAt: frozen ? nowIso : null,
                    frozenBy: frozen ? (req.authUser?.sub ?? 'system') : null,
                    updatedAt: nowIso,
                    updatedBy: actorUserId,
                };
                const updated = await memoryStore.updateTeamTopology(topologyId, {
                    candidateRolloutControl: control,
                    metadata: appendCandidateRolloutAuditEvent(topology.metadata, {
                        action: frozen ? 'freeze' : 'resume',
                        at: nowIso,
                        actor: 'user',
                        reason,
                        fromRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                        toRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                        candidateVersion: topology.candidateStrategy?.version ?? null,
                        stableVersion: topology.strategyVersion ?? 1,
                    }),
                });
                if (!updated) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                logAdminAudit(req, 'admin.team_topology.candidate_rollout_control', {
                    ...summarizeTopologyAuditParams(updated),
                    enabled,
                    frozen,
                    reason,
                    candidateVersion: topology.candidateStrategy?.version ?? null,
                    rolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                    riskLevel: frozen || enabled === false ? (enabled === false ? 'high' : 'medium') : 'low',
                });
                res.json({
                    topology: updated,
                    control,
                });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.candidate_rollout_control', {
                    topologyId: String(req.params.id),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-topologies/:id/orchestrator-control', requireAuth, async (req, res) => {
            try {
                const topologyId = String(req.params.id);
                const topology = await memoryStore.getTeamTopology(topologyId);
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const actor = getTopologyControlActor(req);
                if (!canActorRequestTopologyControl(topology, 'orchestrator_control', actor)) {
                    res.status(403).json({ error: 'Forbidden: topology control access denied' });
                    return;
                }
                const actorUserId = actor.userId ?? getStableWebId();
                const body = req.body;
                const frozen = body.frozen === true;
                const freezeMinutes = Number.isFinite(Number(body.freezeMinutes))
                    ? Math.max(1, Math.floor(Number(body.freezeMinutes)))
                    : 180;
                const confirmation = requireTopologyControlConfirmation({
                    req,
                    res,
                    body,
                    topology,
                    action: 'orchestrator_control',
                    risk: frozen ? 'medium' : 'low',
                    requiredReason: frozen,
                });
                if (!confirmation.ok)
                    return;
                const reason = confirmation.reason;
                const now = new Date();
                const nowIso = now.toISOString();
                const frozenUntil = frozen ? new Date(now.getTime() + freezeMinutes * 60_000).toISOString() : null;
                const metadata = {
                    ...(topology.metadata ?? {}),
                    lastOrchFrozenUntil: frozenUntil,
                    lastOrchFreezeReason: frozen ? reason : null,
                    lastOrchFrozenBy: actorUserId,
                    lastOrchManualControl: true,
                    ...(frozen ? {} : { orchDegradedStreak: 0 }),
                };
                const updated = await memoryStore.updateTeamTopology(topologyId, { metadata });
                if (!updated) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                logAdminAudit(req, 'admin.team_topology.orchestrator_control', {
                    ...summarizeTopologyAuditParams(updated),
                    frozen,
                    frozenUntil,
                    freezeMinutes: frozen ? freezeMinutes : null,
                    reason,
                    riskLevel: frozen ? 'medium' : 'low',
                });
                res.json({
                    topology: updated,
                    control: {
                        frozen,
                        frozenUntil,
                        freezeReason: frozen ? reason : null,
                        frozenBy: actorUserId,
                        manualControl: true,
                        resumedAt: frozen ? null : nowIso,
                    },
                });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.orchestrator_control', {
                    topologyId: String(req.params.id),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-topologies/:id/rollback-strategy', requireAuth, async (req, res) => {
            try {
                const topologyId = String(req.params.id);
                const topology = await memoryStore.getTeamTopology(topologyId);
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const actor = getTopologyControlActor(req);
                if (!canActorRequestTopologyControl(topology, 'rollback_strategy', actor)) {
                    res.status(403).json({ error: 'Forbidden: topology control access denied' });
                    return;
                }
                const actorUserId = actor.userId ?? getStableWebId();
                const targetVersion = Number(req.body['version']);
                if (!Number.isFinite(targetVersion) || targetVersion < 1) {
                    res.status(400).json({ error: 'version must be a positive integer' });
                    return;
                }
                const confirmation = requireTopologyControlConfirmation({
                    req,
                    res,
                    body: req.body,
                    topology,
                    action: 'rollback_strategy',
                    risk: 'critical',
                    requiredReason: true,
                    confirmationPhrase: `${buildTopologyControlPhrase('rollback', topology)} v${targetVersion}`,
                });
                if (!confirmation.ok)
                    return;
                const approvalScope = resolveTopologyGovernanceApprovalScope(topology, 'rollback_strategy', 'topology_control_action');
                const approverUserId = approvalScope.primaryApproverUserId;
                if (approverUserId) {
                    const approvalTask = await ensureTopologyControlApprovalTask({
                        topology,
                        action: 'rollback_strategy',
                        title: `[Governance] Approve strategy rollback: ${topology.name}`,
                        summary: [
                            `Rollback topology ${topology.name} from stable v${topology.strategyVersion ?? 1} to v${targetVersion}.`,
                            `Reason: ${confirmation.reason}`,
                        ].join('\n'),
                        requestedByUserId: actorUserId,
                        requestedForUserId: approverUserId,
                        approverUserIds: approvalScope.approverUserIds,
                        approverRoleGroups: approvalScope.approverRoleGroups,
                        effectiveApproverUserIds: approvalScope.effectiveApproverUserIds,
                        escalationChain: approvalScope.escalationChain,
                        metadata: {
                            topologyControlRiskLevel: 'critical',
                            topologyControlReason: confirmation.reason,
                            topologyControlRequestedVersion: targetVersion,
                        },
                    });
                    if (approvalTask) {
                        logAdminAudit(req, 'admin.team_topology.rollback_strategy.request_approval', {
                            ...summarizeTopologyAuditParams(topology),
                            approvalTaskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                            requestedVersion: targetVersion,
                            reason: confirmation.reason,
                            riskLevel: 'critical',
                        });
                        res.status(202).json({
                            approvalRequired: true,
                            taskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                        });
                        return;
                    }
                }
                const snapshot = findTeamTopologyStrategySnapshot(topology, targetVersion);
                if (!snapshot) {
                    res.status(404).json({ error: `Strategy version not found: ${targetVersion}` });
                    return;
                }
                const updated = await memoryStore.updateTeamTopology(topologyId, {
                    orchestratorRules: snapshot.orchestratorRules ?? null,
                    adaptiveModelPolicy: snapshot.adaptiveModelPolicy ?? null,
                    modelRoutes: snapshot.modelRoutes ?? null,
                });
                if (!updated) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                logAdminAudit(req, 'admin.team_topology.rollback_strategy', {
                    ...summarizeTopologyAuditParams(updated),
                    requestedVersion: snapshot.version,
                    fromVersion: topology.strategyVersion ?? 1,
                    toVersion: updated.strategyVersion ?? 1,
                    reason: confirmation.reason,
                    riskLevel: 'critical',
                });
                res.json({
                    topology: updated,
                    rollback: {
                        requestedVersion: snapshot.version,
                        fromVersion: topology.strategyVersion ?? 1,
                        toVersion: updated.strategyVersion ?? 1,
                    },
                });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.rollback_strategy', {
                    topologyId: String(req.params.id),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-topologies', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const workspaceId = String(body.workspaceId ?? '').trim();
                const name = String(body.name ?? '').trim();
                const orchestratorRules = body.orchestratorRules === null ? null : parseOrchestratorRules(body.orchestratorRules);
                const adaptiveModelPolicy = body.adaptiveModelPolicy === null ? null : parseAdaptiveModelPolicyInput(body.adaptiveModelPolicy);
                const adaptiveOrchestratorPolicy = body.adaptiveOrchestratorPolicy === null ? null : parseAdaptiveOrchestratorPolicy(body.adaptiveOrchestratorPolicy);
                const controlAccessPolicy = body.controlAccessPolicy === null ? null : parseTopologyControlAccessPolicy(body.controlAccessPolicy);
                const modelRoutes = body.modelRoutes === null ? null : parseTeamTopologyModelRoutes(body.modelRoutes);
                const candidateStrategy = body.candidateStrategy === null ? null : parseTeamTopologyCandidateStrategy(body.candidateStrategy);
                const candidateRolloutPolicy = body.candidateRolloutPolicy === null ? null : parseTeamTopologyCandidateRolloutPolicy(body.candidateRolloutPolicy);
                const candidateRolloutControl = body.candidateRolloutControl === null ? null : parseTeamTopologyCandidateRolloutControl(body.candidateRolloutControl);
                if (!workspaceId || !name) {
                    res.status(400).json({ error: 'workspaceId and name are required' });
                    return;
                }
                if (body.orchestratorRules !== undefined && body.orchestratorRules !== null && !orchestratorRules) {
                    res.status(400).json({ error: 'Invalid orchestratorRules' });
                    return;
                }
                if (body.adaptiveModelPolicy !== undefined && body.adaptiveModelPolicy !== null && !adaptiveModelPolicy) {
                    res.status(400).json({ error: 'Invalid adaptiveModelPolicy' });
                    return;
                }
                if (body.modelRoutes !== undefined && body.modelRoutes !== null && !modelRoutes) {
                    res.status(400).json({ error: 'Invalid modelRoutes' });
                    return;
                }
                if (body.candidateStrategy !== undefined && body.candidateStrategy !== null && !candidateStrategy) {
                    res.status(400).json({ error: 'Invalid candidateStrategy' });
                    return;
                }
                if (body.candidateRolloutPolicy !== undefined && body.candidateRolloutPolicy !== null && !candidateRolloutPolicy) {
                    res.status(400).json({ error: 'Invalid candidateRolloutPolicy' });
                    return;
                }
                if (body.candidateRolloutControl !== undefined && body.candidateRolloutControl !== null && !candidateRolloutControl) {
                    res.status(400).json({ error: 'Invalid candidateRolloutControl' });
                    return;
                }
                if (body.controlAccessPolicy !== undefined && body.controlAccessPolicy !== null && !controlAccessPolicy) {
                    res.status(400).json({ error: 'Invalid controlAccessPolicy' });
                    return;
                }
                const metadata = typeof body.metadata === 'object' && body.metadata !== null
                    ? { ...body.metadata }
                    : {};
                if (body.adaptiveOrchestratorPolicy !== undefined) {
                    if (adaptiveOrchestratorPolicy)
                        metadata['adaptiveOrchestratorPolicy'] = adaptiveOrchestratorPolicy;
                    else
                        delete metadata['adaptiveOrchestratorPolicy'];
                }
                if (body.controlAccessPolicy !== undefined) {
                    if (controlAccessPolicy)
                        metadata['controlAccessPolicy'] = controlAccessPolicy;
                    else
                        delete metadata['controlAccessPolicy'];
                }
                const topology = await memoryStore.createTeamTopology({
                    workspaceId,
                    name,
                    department: typeof body.department === 'string' ? body.department : undefined,
                    role: typeof body.role === 'string' ? body.role : undefined,
                    supervisorAgentId: body.supervisorAgentId === null || typeof body.supervisorAgentId === 'string'
                        ? body.supervisorAgentId
                        : undefined,
                    workerAgentIds: parseStringArrayInput(body.workerAgentIds),
                    defaultTemplateIds: parseStringArrayInput(body.defaultTemplateIds),
                    defaultHumanOwnerUserId: body.defaultHumanOwnerUserId === null || typeof body.defaultHumanOwnerUserId === 'string'
                        ? body.defaultHumanOwnerUserId
                        : undefined,
                    ...(body.orchestratorRules !== undefined ? { orchestratorRules } : {}),
                    ...(body.adaptiveModelPolicy !== undefined ? { adaptiveModelPolicy } : {}),
                    ...(body.modelRoutes !== undefined ? { modelRoutes } : {}),
                    ...(body.candidateStrategy !== undefined ? { candidateStrategy } : {}),
                    ...(body.candidateRolloutPolicy !== undefined ? { candidateRolloutPolicy } : {}),
                    ...(body.candidateRolloutControl !== undefined ? { candidateRolloutControl } : {}),
                    createdBy: req.authUser?.sub ?? getStableWebId(),
                    metadata: Object.keys(metadata).length > 0 ? metadata : undefined,
                });
                logAdminAudit(req, 'admin.team_topology.create', {
                    ...summarizeTopologyAuditParams(topology),
                    department: topology.department ?? null,
                    role: topology.role ?? null,
                    workerCount: topology.workerAgentIds.length,
                    templateCount: topology.defaultTemplateIds.length,
                });
                res.status(201).json({ topology });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.create', {
                    workspaceId: String(req.body?.['workspaceId'] ?? ''),
                    topologyName: String(req.body?.['name'] ?? ''),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.patch('/api/team-topologies/:id', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const orchestratorRules = body.orchestratorRules === null ? null : parseOrchestratorRules(body.orchestratorRules);
                const adaptiveModelPolicy = body.adaptiveModelPolicy === null ? null : parseAdaptiveModelPolicyInput(body.adaptiveModelPolicy);
                const adaptiveOrchestratorPolicy = body.adaptiveOrchestratorPolicy === null ? null : parseAdaptiveOrchestratorPolicy(body.adaptiveOrchestratorPolicy);
                const controlAccessPolicy = body.controlAccessPolicy === null ? null : parseTopologyControlAccessPolicy(body.controlAccessPolicy);
                const modelRoutes = body.modelRoutes === null ? null : parseTeamTopologyModelRoutes(body.modelRoutes);
                const candidateStrategy = body.candidateStrategy === null ? null : parseTeamTopologyCandidateStrategy(body.candidateStrategy);
                const candidateRolloutPolicy = body.candidateRolloutPolicy === null ? null : parseTeamTopologyCandidateRolloutPolicy(body.candidateRolloutPolicy);
                const candidateRolloutControl = body.candidateRolloutControl === null ? null : parseTeamTopologyCandidateRolloutControl(body.candidateRolloutControl);
                if (body.orchestratorRules !== undefined && body.orchestratorRules !== null && !orchestratorRules) {
                    res.status(400).json({ error: 'Invalid orchestratorRules' });
                    return;
                }
                if (body.adaptiveModelPolicy !== undefined && body.adaptiveModelPolicy !== null && !adaptiveModelPolicy) {
                    res.status(400).json({ error: 'Invalid adaptiveModelPolicy' });
                    return;
                }
                if (body.adaptiveOrchestratorPolicy !== undefined && body.adaptiveOrchestratorPolicy !== null && !adaptiveOrchestratorPolicy) {
                    res.status(400).json({ error: 'Invalid adaptiveOrchestratorPolicy' });
                    return;
                }
                if (body.modelRoutes !== undefined && body.modelRoutes !== null && !modelRoutes) {
                    res.status(400).json({ error: 'Invalid modelRoutes' });
                    return;
                }
                if (body.candidateStrategy !== undefined && body.candidateStrategy !== null && !candidateStrategy) {
                    res.status(400).json({ error: 'Invalid candidateStrategy' });
                    return;
                }
                if (body.candidateRolloutPolicy !== undefined && body.candidateRolloutPolicy !== null && !candidateRolloutPolicy) {
                    res.status(400).json({ error: 'Invalid candidateRolloutPolicy' });
                    return;
                }
                if (body.candidateRolloutControl !== undefined && body.candidateRolloutControl !== null && !candidateRolloutControl) {
                    res.status(400).json({ error: 'Invalid candidateRolloutControl' });
                    return;
                }
                if (body.controlAccessPolicy !== undefined && body.controlAccessPolicy !== null && !controlAccessPolicy) {
                    res.status(400).json({ error: 'Invalid controlAccessPolicy' });
                    return;
                }
                const existingTopology = await memoryStore.getTeamTopology(String(req.params.id));
                if (!existingTopology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const mergedMetadata = typeof body.metadata === 'object' && body.metadata !== null
                    ? { ...body.metadata }
                    : { ...(existingTopology.metadata ?? {}) };
                if (body.adaptiveOrchestratorPolicy !== undefined) {
                    if (adaptiveOrchestratorPolicy)
                        mergedMetadata['adaptiveOrchestratorPolicy'] = adaptiveOrchestratorPolicy;
                    else
                        delete mergedMetadata['adaptiveOrchestratorPolicy'];
                }
                if (body.controlAccessPolicy !== undefined) {
                    if (controlAccessPolicy)
                        mergedMetadata['controlAccessPolicy'] = controlAccessPolicy;
                    else
                        delete mergedMetadata['controlAccessPolicy'];
                }
                const topology = await memoryStore.updateTeamTopology(String(req.params.id), {
                    ...(typeof body.name === 'string' ? { name: body.name } : {}),
                    ...(body.department === null || typeof body.department === 'string' ? { department: body.department } : {}),
                    ...(body.role === null || typeof body.role === 'string' ? { role: body.role } : {}),
                    ...(body.supervisorAgentId === null || typeof body.supervisorAgentId === 'string'
                        ? { supervisorAgentId: body.supervisorAgentId }
                        : {}),
                    ...(body.workerAgentIds !== undefined ? { workerAgentIds: parseStringArrayInput(body.workerAgentIds) ?? [] } : {}),
                    ...(body.defaultTemplateIds !== undefined ? { defaultTemplateIds: parseStringArrayInput(body.defaultTemplateIds) ?? [] } : {}),
                    ...(body.defaultHumanOwnerUserId === null || typeof body.defaultHumanOwnerUserId === 'string'
                        ? { defaultHumanOwnerUserId: body.defaultHumanOwnerUserId }
                        : {}),
                    ...(body.orchestratorRules !== undefined ? { orchestratorRules } : {}),
                    ...(body.adaptiveModelPolicy !== undefined ? { adaptiveModelPolicy } : {}),
                    ...(body.modelRoutes !== undefined ? { modelRoutes } : {}),
                    ...(body.candidateStrategy !== undefined ? { candidateStrategy } : {}),
                    ...(body.candidateRolloutPolicy !== undefined ? { candidateRolloutPolicy } : {}),
                    ...(body.candidateRolloutControl !== undefined ? { candidateRolloutControl } : {}),
                    ...(body.metadata !== undefined || body.adaptiveOrchestratorPolicy !== undefined ? { metadata: mergedMetadata } : {}),
                });
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                logAdminAudit(req, 'admin.team_topology.update', {
                    ...summarizeTopologyAuditParams(topology),
                    updatedFields: Object.keys(body),
                });
                res.json({ topology });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.update', {
                    topologyId: String(req.params.id),
                    updatedFields: Object.keys(req.body ?? {}),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/team-topologies/:id', requireAuth, async (req, res) => {
            try {
                const existingTopology = await memoryStore.getTeamTopology(String(req.params.id));
                if (!existingTopology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const actor = getTopologyControlActor(req);
                if (!canActorRequestTopologyControl(existingTopology, 'delete_topology', actor)) {
                    res.status(403).json({ error: 'Forbidden: topology control access denied' });
                    return;
                }
                const actorUserId = actor.userId ?? getStableWebId();
                const confirmation = requireTopologyControlConfirmation({
                    req,
                    res,
                    body: req.body ?? {},
                    topology: existingTopology,
                    action: 'delete',
                    risk: 'critical',
                    requiredReason: true,
                    confirmationPhrase: buildTopologyControlPhrase('delete', existingTopology),
                });
                if (!confirmation.ok)
                    return;
                const approvalScope = resolveTopologyGovernanceApprovalScope(existingTopology, 'delete_topology', 'topology_control_action');
                const approverUserId = approvalScope.primaryApproverUserId;
                if (approverUserId) {
                    const approvalTask = await ensureTopologyControlApprovalTask({
                        topology: existingTopology,
                        action: 'delete_topology',
                        title: `[Governance] Approve topology delete: ${existingTopology.name}`,
                        summary: [
                            `Delete topology ${existingTopology.name} (${existingTopology.id}).`,
                            `Stable version: v${existingTopology.strategyVersion ?? 1}.`,
                            `Reason: ${confirmation.reason}`,
                        ].join('\n'),
                        requestedByUserId: actorUserId,
                        requestedForUserId: approverUserId,
                        approverUserIds: approvalScope.approverUserIds,
                        approverRoleGroups: approvalScope.approverRoleGroups,
                        effectiveApproverUserIds: approvalScope.effectiveApproverUserIds,
                        escalationChain: approvalScope.escalationChain,
                        metadata: {
                            topologyControlRiskLevel: 'critical',
                            topologyControlReason: confirmation.reason,
                        },
                    });
                    if (approvalTask) {
                        logAdminAudit(req, 'admin.team_topology.delete.request_approval', {
                            ...summarizeTopologyAuditParams(existingTopology),
                            approvalTaskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                            reason: confirmation.reason,
                            riskLevel: 'critical',
                        });
                        res.status(202).json({
                            approvalRequired: true,
                            taskId: approvalTask.taskId,
                            approvalId: approvalTask.approvalId,
                        });
                        return;
                    }
                }
                const ok = await memoryStore.deleteTeamTopology(String(req.params.id));
                if (ok) {
                    logAdminAudit(req, 'admin.team_topology.delete', {
                        ...summarizeTopologyAuditParams(existingTopology),
                        reason: confirmation.reason,
                        riskLevel: 'critical',
                    });
                }
                res.json({ ok });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.delete', {
                    topologyId: String(req.params.id),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/team-topologies/:id/instantiate', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = req.body;
                const topology = await memoryStore.getTeamTopology(String(req.params.id));
                if (!topology) {
                    res.status(404).json({ error: 'Topology not found' });
                    return;
                }
                const userId = String(body.userId ?? req.authUser?.sub ?? getStableWebId()).trim();
                const channel = String(body.channel ?? 'web').trim();
                const chatId = String(body.chatId ?? topology.workspaceId).trim();
                const tasks = await instantiateTeamTopologyById(topology.id, {
                    sessionId: `team-topology:${topology.id}`,
                    userId,
                    channel,
                    chatId,
                    workspaceId: topology.workspaceId,
                    history: [],
                    role: req.authUser?.role === 'readonly' ? 'user' : req.authUser?.role,
                }, {
                    humanOwnerUserId: body.humanOwnerUserId === null || typeof body.humanOwnerUserId === 'string'
                        ? body.humanOwnerUserId
                        : undefined,
                    variables: parseTeamTemplateVariableValues(body.variables),
                    templateIds: parseStringArrayInput(body.templateIds),
                    workerAgentIds: parseStringArrayInput(body.workerAgentIds),
                    supervisorAgentId: body.supervisorAgentId === null || typeof body.supervisorAgentId === 'string'
                        ? body.supervisorAgentId
                        : undefined,
                });
                logAdminAudit(req, 'admin.team_topology.instantiate', {
                    ...summarizeTopologyAuditParams(topology),
                    taskCount: tasks.length,
                    userId,
                    channel,
                    chatId,
                });
                res.status(201).json({ topology, tasks });
            }
            catch (err) {
                logAdminAudit(req, 'admin.team_topology.instantiate', {
                    topologyId: String(req.params.id),
                }, false, String(err));
                if (respondKnownTeamError(res, err))
                    return;
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/skills', requireAuth, (_req, res) => {
            try {
                const skills = skillRegistry.listAllMeta();
                res.json({ skills });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/skills/stats', requireAuth, requireAdminAccess, async (_req, res) => {
            try {
                const stats = await memoryStore.getSkillStats();
                res.json({ stats });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Providers API ─────────────────────────────────────────────────────────
        app.get('/api/providers', requireAuth, (_req, res) => {
            try {
                const providers = providerRegistry.listMeta();
                res.json({ providers, default: config.defaultProvider });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.post('/api/providers/default', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const name = String(req.body.name ?? '').trim();
                if (!name) {
                    res.status(400).json({ error: 'Missing name' });
                    return;
                }
                providerRegistry.setDefault(name);
                res.json({ ok: true, default: name });
            }
            catch (err) {
                res.status(400).json({ error: String(err) });
            }
        });
        // ── Conversation Search & Export ──────────────────────────────────────────
        app.get('/api/conversations/search', requireAuth, async (req, res) => {
            try {
                const q = String(req.query.q ?? '').trim();
                if (!q) {
                    res.status(400).json({ error: 'Missing query parameter q' });
                    return;
                }
                const userId = req.authUser?.sub ?? getStableWebId();
                const limit = Math.min(parseInt(req.query.limit) || 20, 100);
                const results = await memoryStore.searchConversations(userId, 'web', q, limit);
                res.json({ results, query: q });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        app.get('/api/conversations/:sessionId/export', requireAuth, async (req, res) => {
            try {
                const fmt = req.query.format === 'json' ? 'json' : 'markdown';
                const sessionId = String(req.params.sessionId);
                const scopedUserId = getScopedUserId(req);
                if (scopedUserId) {
                    const owner = await memoryStore.getSessionOwner(sessionId);
                    if (owner !== scopedUserId) {
                        return res.status(403).json({ error: 'Forbidden: conversation does not belong to you.' });
                    }
                }
                const content = await memoryStore.exportConversation(sessionId, fmt);
                if (fmt === 'json') {
                    res.setHeader('Content-Type', 'application/json');
                    res.setHeader('Content-Disposition', `attachment; filename="conversation-${sessionId}.json"`);
                }
                else {
                    res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
                    res.setHeader('Content-Disposition', `attachment; filename="conversation-${sessionId}.md"`);
                }
                res.send(content);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Config API (requires auth) ───────────────────────────────────────────────
        app.get('/api/config', requireAuth, requireAdminAccess, (_req, res) => {
            res.json(configManager.getPublicConfig());
        });
        app.put('/api/config', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const updates = stripMaskedFields(req.body);
                configManager.set(updates);
                providerRegistry.reload();
                logAdminAudit(req, 'admin.config.update', summarizeConfigUpdate(updates));
                res.json({ ok: true });
            }
            catch (err) {
                logAdminAudit(req, 'admin.config.update', { failed: true }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Admin: user management (admin role required) ─────────────────────────
        /** GET /api/admin/users — list all users with session/conversation counts */
        app.get('/api/admin/users', requireAuth, requireAdminAccess, async (_req, res) => {
            try {
                const users = (await memoryStore.listUsers()).map((user) => ({
                    ...user,
                    directRole: getDirectAssignedRole(user.userId),
                    effectiveRole: resolveRoleFromConfig(configManager.get().roles, user.userId, 'web'),
                    roleGroups: getMatchingRoleGroups(user.userId),
                }));
                res.json({ users });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** PUT /api/admin/users/:userId/role — promote/demote a user */
        app.put('/api/admin/users/:userId/role', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const userId = String(req.params.userId);
                const { role } = req.body;
                if (role !== 'admin' && role !== 'user' && role !== 'readonly' && role !== 'clear') {
                    res.status(400).json({ error: 'role must be "admin", "user", "readonly", or "clear"' });
                    return;
                }
                const cfg = configManager.get();
                const adminSet = new Set(cfg.roles?.admin ?? []);
                const userSet = new Set(cfg.roles?.user ?? []);
                const readonlySet = new Set(cfg.roles?.readonly ?? []);
                adminSet.delete(userId);
                userSet.delete(userId);
                readonlySet.delete(userId);
                if (role === 'admin')
                    adminSet.add(userId);
                if (role === 'user')
                    userSet.add(userId);
                if (role === 'readonly')
                    readonlySet.add(userId);
                configManager.set({
                    roles: {
                        ...cfg.roles,
                        admin: [...adminSet],
                        user: [...userSet],
                        readonly: [...readonlySet],
                    },
                });
                logAdminAudit(req, 'admin.user.role.update', {
                    targetUserId: userId,
                    role,
                    directRole: role === 'clear' ? null : role,
                });
                res.json({ ok: true, userId, role, directRole: role === 'clear' ? null : role });
            }
            catch (err) {
                logAdminAudit(req, 'admin.user.role.update', {
                    targetUserId: String(req.params.userId),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        /** DELETE /api/admin/users/:userId/data — GDPR erasure: wipe all user data */
        /** GET /api/admin/role-groups - list group-based role assignments */
        app.get('/api/admin/role-groups', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                const groups = Object.entries(configManager.get().roles?.groups ?? {})
                    .map(([id, group]) => ({
                    id,
                    role: group.role,
                    members: [...group.members],
                    externalGroups: [...(group.externalGroups ?? [])],
                    memberCount: group.members.length,
                    externalGroupCount: (group.externalGroups ?? []).length,
                }))
                    .sort((a, b) => a.id.localeCompare(b.id));
                res.json({ groups });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** PUT /api/admin/role-groups/:groupId - create or replace a role group */
        app.put('/api/admin/role-groups/:groupId', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const groupId = String(req.params.groupId ?? '').trim();
                const { role, members, externalGroups } = req.body;
                if (!isValidRoleGroupId(groupId)) {
                    res.status(400).json({ error: 'groupId must match /^[A-Za-z0-9._:-]{1,64}$/' });
                    return;
                }
                if (role !== 'admin' && role !== 'user' && role !== 'readonly') {
                    res.status(400).json({ error: 'role must be \"admin\", \"user\", or \"readonly\"' });
                    return;
                }
                const normalizedMembers = normalizeRoleGroupMembers(members);
                const normalizedExternalGroups = normalizeExternalGroups(externalGroups);
                const cfg = configManager.get();
                configManager.set({
                    roles: {
                        ...cfg.roles,
                        groups: {
                            ...(cfg.roles?.groups ?? {}),
                            [groupId]: {
                                role,
                                members: normalizedMembers,
                                externalGroups: normalizedExternalGroups,
                            },
                        },
                    },
                });
                logAdminAudit(req, 'admin.role_group.upsert', {
                    groupId,
                    role,
                    memberCount: normalizedMembers.length,
                    externalGroupCount: normalizedExternalGroups.length,
                });
                res.json({
                    ok: true,
                    group: {
                        id: groupId,
                        role,
                        members: normalizedMembers,
                        externalGroups: normalizedExternalGroups,
                        memberCount: normalizedMembers.length,
                        externalGroupCount: normalizedExternalGroups.length,
                    },
                });
            }
            catch (err) {
                logAdminAudit(req, 'admin.role_group.upsert', {
                    groupId: String(req.params.groupId ?? ''),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        /** DELETE /api/admin/role-groups/:groupId - remove a role group */
        app.delete('/api/admin/role-groups/:groupId', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const groupId = String(req.params.groupId ?? '').trim();
                if (!isValidRoleGroupId(groupId)) {
                    res.status(400).json({ error: 'groupId must match /^[A-Za-z0-9._:-]{1,64}$/' });
                    return;
                }
                const cfg = configManager.get();
                const groups = { ...(cfg.roles?.groups ?? {}) };
                if (!groups[groupId]) {
                    res.status(404).json({ error: 'role group not found' });
                    return;
                }
                delete groups[groupId];
                configManager.set({
                    roles: {
                        ...cfg.roles,
                        groups,
                    },
                });
                logAdminAudit(req, 'admin.role_group.delete', { groupId });
                res.json({ ok: true, groupId });
            }
            catch (err) {
                logAdminAudit(req, 'admin.role_group.delete', {
                    groupId: String(req.params.groupId ?? ''),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        app.delete('/api/admin/users/:userId/data', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const userId = String(req.params.userId);
                await memoryStore.deleteUserData(userId);
                logAdminAudit(req, 'admin.user.data.delete', { targetUserId: userId });
                res.json({ ok: true, userId });
            }
            catch (err) {
                logAdminAudit(req, 'admin.user.data.delete', {
                    targetUserId: String(req.params.userId),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Conditional TLS/HTTPS setup ───────────────────────────────────────────
        app.post('/api/admin/users/:userId/revoke-sessions', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const userId = String(req.params.userId);
                await memoryStore.revokeAuthSessions(userId, {
                    revokedAfter: Math.floor(Date.now() / 1000),
                    revokedBy: req.authUser?.sub ?? '[admin]',
                    reason: 'admin forced logout',
                });
                logAdminAudit(req, 'admin.user.sessions.revoke', { targetUserId: userId });
                res.json({ ok: true, userId });
            }
            catch (err) {
                logAdminAudit(req, 'admin.user.sessions.revoke', {
                    targetUserId: String(req.params.userId),
                }, false, String(err));
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Token Usage & Quota endpoints ─────────────────────────────────────────
        /** GET /api/usage — current user's token usage summary for the current month */
        app.get('/api/usage', requireAuth, async (req, res) => {
            try {
                const userId = req.authUser.sub;
                const period = typeof req.query.period === 'string' ? req.query.period : new Date().toISOString().slice(0, 7);
                const [summary] = await memoryStore.getTokenUsageSummary({ userId, period });
                const quota = await memoryStore.getUserQuota('user', userId);
                res.json({ summary: summary ?? null, quota: quota ?? null, period });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** GET /api/admin/usage — admin view: all usage (optionally filtered by userId or workspaceId) */
        app.get('/api/admin/usage', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const userId = typeof req.query.userId === 'string' ? req.query.userId : undefined;
                const workspaceId = typeof req.query.workspaceId === 'string' ? req.query.workspaceId : undefined;
                const period = typeof req.query.period === 'string' ? req.query.period : new Date().toISOString().slice(0, 7);
                const limit = Math.min(parseInt(String(req.query.limit ?? '50'), 10) || 50, 200);
                const offset = parseInt(String(req.query.offset ?? '0'), 10) || 0;
                const [summary, detail] = await Promise.all([
                    memoryStore.getTokenUsageSummary({ userId, workspaceId, period }),
                    memoryStore.getTokenUsageDetail({ userId, workspaceId, limit, offset }),
                ]);
                res.json({ summary, detail, period });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** GET /api/admin/quotas — list all configured quotas */
        app.get('/api/admin/quotas', requireAuth, requireAdminAccess, async (_req, res) => {
            try {
                const quotas = await memoryStore.listUserQuotas();
                res.json({ quotas });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** PUT /api/admin/quotas/:scopeType/:scopeId — set or update a quota */
        app.put('/api/admin/quotas/:scopeType/:scopeId', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const scopeType = String(req.params.scopeType);
                if (scopeType !== 'user' && scopeType !== 'workspace') {
                    return void res.status(400).json({ error: 'scopeType must be "user" or "workspace"' });
                }
                const scopeId = String(req.params.scopeId);
                const body = req.body;
                await memoryStore.setUserQuota({
                    scopeType,
                    scopeId,
                    monthlyTokenLimit: body['monthlyTokenLimit'] != null ? Number(body['monthlyTokenLimit']) : null,
                    monthlyCostLimitUsd: body['monthlyCostLimitUsd'] != null ? Number(body['monthlyCostLimitUsd']) : null,
                    limitBehavior: body['limitBehavior'] === 'hard' ? 'hard' : 'soft',
                });
                logAdminAudit(req, 'admin.quota.set', { scopeType, scopeId, quota: body });
                const updated = await memoryStore.getUserQuota(scopeType, scopeId);
                res.json({ ok: true, quota: updated });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** DELETE /api/admin/quotas/:scopeType/:scopeId — remove a quota (restore unlimited) */
        app.delete('/api/admin/quotas/:scopeType/:scopeId', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const scopeType = String(req.params.scopeType);
                const scopeId = String(req.params.scopeId);
                // Setting all limits to null effectively removes the quota constraint
                await memoryStore.setUserQuota({ scopeType, scopeId, monthlyTokenLimit: null, monthlyCostLimitUsd: null, limitBehavior: 'soft' });
                logAdminAudit(req, 'admin.quota.delete', { scopeType, scopeId });
                res.json({ ok: true });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Workspace Membership endpoints ────────────────────────────────────────
        /** GET /api/workspaces/:workspaceId/members — list workspace members */
        app.get('/api/workspaces/:workspaceId/members', requireAuth, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId);
                const adminCheck = isAdminUser(req.authUser);
                const userId = req.authUser.sub;
                const membership = adminCheck ? { role: 'owner' } : await memoryStore.getWorkspaceMembership(workspaceId, userId);
                if (!membership)
                    return void res.status(403).json({ error: 'Access denied' });
                const members = await memoryStore.listWorkspaceMembers(workspaceId);
                res.json({ members });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** POST /api/workspaces/:workspaceId/members — add a member (admin or workspace owner only) */
        app.post('/api/workspaces/:workspaceId/members', requireAuth, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId);
                const adminCheck = isAdminUser(req.authUser);
                const userId = req.authUser.sub;
                const membership = adminCheck ? { role: 'owner' } : await memoryStore.getWorkspaceMembership(workspaceId, userId);
                if (!membership || (membership.role !== 'owner' && !adminCheck)) {
                    return void res.status(403).json({ error: 'Only workspace owners or admins may add members' });
                }
                const body = req.body;
                const targetUserId = String(body['userId'] ?? '').trim();
                const role = body['role'] === 'owner' || body['role'] === 'viewer' ? body['role'] : 'member';
                if (!targetUserId)
                    return void res.status(400).json({ error: 'userId required' });
                await memoryStore.addWorkspaceMember(workspaceId, targetUserId, role);
                logAdminAudit(req, 'workspace.member.add', { workspaceId, targetUserId, role });
                res.json({ ok: true });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** DELETE /api/workspaces/:workspaceId/members/:userId — remove a member */
        app.delete('/api/workspaces/:workspaceId/members/:userId', requireAuth, async (req, res) => {
            try {
                const workspaceId = String(req.params.workspaceId);
                const targetUserId = String(req.params.userId);
                const adminCheck = isAdminUser(req.authUser);
                const requesterId = req.authUser.sub;
                const membership = adminCheck ? { role: 'owner' } : await memoryStore.getWorkspaceMembership(workspaceId, requesterId);
                if (!membership || (membership.role !== 'owner' && !adminCheck)) {
                    return void res.status(403).json({ error: 'Only workspace owners or admins may remove members' });
                }
                await memoryStore.removeWorkspaceMember(workspaceId, targetUserId);
                logAdminAudit(req, 'workspace.member.remove', { workspaceId, targetUserId });
                res.json({ ok: true });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** GET /api/setup/status — first-run detection for onboarding UX */
        app.get('/api/setup/status', async (_req, res) => {
            try {
                const providers = providerRegistry.list();
                const hasProvider = providers.some((p) => p !== 'ollama');
                const hasOllamaOrAny = providers.length > 0;
                res.json({
                    needsSetup: !hasOllamaOrAny,
                    configuredProviders: providers,
                    hasNonLocalProvider: hasProvider,
                    version: process.env.npm_package_version ?? 'unknown',
                });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /** GET /api/deployment/check — production deployment readiness check */
        app.get('/api/deployment/check', requireAuth, async (_req, res) => {
            try {
                const checks = {
                    environment: {
                        nodeVersion: process.version,
                        platform: process.platform,
                        arch: process.arch,
                        uptime: process.uptime(),
                        memory: process.memoryUsage(),
                    },
                    security: {
                        httpsEnabled: !!config.tls?.certFile && !!config.tls?.keyFile,
                        authEnabled: !!config.gateway?.secret,
                        secretStrength: config.gateway?.secret ? (config.gateway.secret.length >= 32 ? 'strong' : 'weak') : 'none',
                    },
                    providers: {
                        configured: providerRegistry.list(),
                        count: providerRegistry.list().length,
                        hasProduction: providerRegistry.list().some((p) => p !== 'ollama'),
                    },
                    runtime: {
                        maxAgents: getAgentRuntimeOverview().maxConcurrent,
                        queueEnabled: isQueueEnabled(),
                        sandboxType: config.sandbox?.enabled === false ? 'disabled' : 'docker',
                    },
                    database: {
                        type: config.database?.url ? 'postgres' : 'sqlite',
                        configured: !!config.database,
                    },
                    recommendations: [],
                };
                // Generate recommendations
                if (!checks.security.httpsEnabled) {
                    checks.recommendations.push({
                        priority: 'high',
                        category: 'security',
                        message: 'HTTPS is not enabled. Production deployments should use TLS/SSL.',
                        action: 'Configure tls.certFile and tls.keyFile in config',
                    });
                }
                if (checks.security.secretStrength !== 'strong') {
                    checks.recommendations.push({
                        priority: 'high',
                        category: 'security',
                        message: 'Gateway secret is weak or missing. Use a strong random secret (32+ characters).',
                        action: 'Set gateway.secret in config to a strong random value',
                    });
                }
                if (!checks.providers.hasProduction) {
                    checks.recommendations.push({
                        priority: 'medium',
                        category: 'providers',
                        message: 'Only local providers configured. Consider adding cloud providers for production.',
                        action: 'Configure Anthropic, OpenAI, or other cloud providers',
                    });
                }
                if (checks.runtime.maxAgents < 10) {
                    checks.recommendations.push({
                        priority: 'low',
                        category: 'runtime',
                        message: 'Low maxAgents setting may limit throughput in production.',
                        action: 'Consider increasing runtime.maxAgents for production workloads',
                    });
                }
                if (checks.database.type === 'sqlite') {
                    checks.recommendations.push({
                        priority: 'medium',
                        category: 'database',
                        message: 'SQLite is suitable for development but PostgreSQL is recommended for production.',
                        action: 'Configure PostgreSQL or MySQL for better scalability',
                    });
                }
                res.json(checks);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Mother-Body Governance API ─────────────────────────────────────────────
        /**
         * GET /api/mother-body/status
         * Returns a full snapshot of the mother-body activation state.
         */
        app.get('/api/mother-body/status', requireAuth, requireAdminAccess, async (_req, res) => {
            try {
                const status = await buildMotherBodyStatus();
                res.json(status);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/mother-body/kernel/candidates
         * List Owner Kernel candidates.  Optionally filter by status via ?status=pending|promoted|rejected|expired.
         */
        app.get('/api/mother-body/kernel/candidates', requireAuth, requireAdminAccess, (req, res) => {
            try {
                expireStaleKernelCandidates();
                const statusFilter = req.query['status'];
                const valid = ['pending', 'promoted', 'rejected', 'expired'];
                const filter = statusFilter && valid.includes(statusFilter)
                    ? statusFilter
                    : undefined;
                const candidates = listKernelCandidates(filter);
                res.json({ candidates, total: candidates.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-body/kernel/candidates/:id/approve
         * Promote a pending kernel candidate into the live kernel.
         * Body: { reviewNote?: string }
         */
        app.post('/api/mother-body/kernel/candidates/:id/approve', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const id = String(req.params['id'] ?? '');
                const reviewNote = typeof req.body?.reviewNote === 'string'
                    ? req.body.reviewNote
                    : undefined;
                const reviewedBy = String(req.authUser?.sub ?? 'admin');
                const result = promoteKernelCandidate({ candidateId: id, reviewedBy, reviewNote });
                if (!result.ok) {
                    res.status(400).json({ error: result.reason });
                    return;
                }
                res.json({ ok: true, kernel: result.kernel });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-body/kernel/candidates/:id/reject
         * Reject a pending kernel candidate.
         * Body: { reason?: string }
         */
        app.post('/api/mother-body/kernel/candidates/:id/reject', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const { id } = req.params;
                const reason = typeof req.body?.reason === 'string' && req.body.reason
                    ? req.body.reason
                    : 'Rejected by admin';
                const result = rejectKernelCandidate(String(id), reason);
                if (!result.ok) {
                    res.status(400).json({ error: result.reason });
                    return;
                }
                res.json({ ok: true });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Capability Unit API ────────────────────────────────────────────────────
        /**
         * GET /api/mother-body/capability-units
         * List capability units. Optional ?status=draft|promotable|... and ?evidence=hard|soft|placeholder
         */
        app.get('/api/mother-body/capability-units', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                const units = listCapabilityUnits();
                res.json({ units, total: units.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/mother-body/capability-units/:id
         */
        app.get('/api/mother-body/capability-units/:id', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const unit = getCapabilityUnit(String(req.params['id'] ?? ''));
                if (!unit) {
                    res.status(404).json({ error: 'Unit not found' });
                    return;
                }
                res.json(unit);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-body/capability-units/:id/hard-evidence
         * Record human-confirmed hard evidence for a capability unit.
         * Body: { description: string, sourceRef?: string }
         * Automatically attempts to advance the promotion status.
         *
         * This is the primary hard-evidence entry point for human governance.
         * Hard evidence enables a unit to reach 'promotable' status via TrustedSelector.
         */
        app.post('/api/mother-body/capability-units/:id/hard-evidence', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const unitId = String(req.params['id'] ?? '');
                const description = typeof req.body?.description === 'string' && req.body.description
                    ? req.body.description
                    : '';
                if (!description) {
                    res.status(400).json({ error: 'description is required' });
                    return;
                }
                const sourceRef = typeof req.body?.sourceRef === 'string' && req.body.sourceRef
                    ? req.body.sourceRef
                    : `human-admin:${String(req.authUser?.sub ?? 'admin')}`;
                const result = recordHardEvidence({ unitId, description, sourceRef, tryAdvance: true });
                if (!result.ok) {
                    res.status(400).json({ error: result.reason });
                    return;
                }
                res.json({ ok: true, unit: result.unit, advanced: result.advanced, newStatus: result.newStatus });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-body/capability-units/:id/advance
         * Attempt to advance a capability unit's promotion status.
         */
        app.post('/api/mother-body/capability-units/:id/advance', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const unitId = String(req.params['id'] ?? '');
                const promotedBy = String(req.authUser?.sub ?? 'admin');
                const result = advanceCapabilityUnit(unitId, promotedBy);
                if (!result.ok) {
                    res.status(400).json({ error: result.reason });
                    return;
                }
                res.json({ ok: true, unit: result.unit });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        // ── Federated Mother-Repo Operational API ──────────────────────────────────
        //
        // All endpoints require admin role.
        // motherRepoPath resolves from: body.motherRepoPath → GF_MOTHER_REPO_PATH env → config
        //
        function resolveMotherRepoPathFromReq(body) {
            return (typeof body['motherRepoPath'] === 'string' && body['motherRepoPath'])
                ? body['motherRepoPath']
                : resolveConfiguredMotherRepoPath();
        }
        /**
         * GET /api/mother-repo/status
         * Returns operational status of the configured mother-repo.
         * Query: ?motherRepoPath=<path> (optional override)
         */
        app.get('/api/mother-repo/status', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const motherRepoPath = typeof req.query['motherRepoPath'] === 'string'
                    ? req.query['motherRepoPath']
                    : resolveConfiguredMotherRepoPath();
                const status = getMotherRepoStatus(motherRepoPath);
                res.json(status);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-repo/uplink
         * Send this instance's upload bundle to the mother-repo inbox.
         * Body: { motherRepoPath?: string, sourceBundlePath?: string }
         */
        app.post('/api/mother-repo/uplink', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = (req.body ?? {});
                const motherRepoPath = resolveMotherRepoPathFromReq(body);
                if (!motherRepoPath) {
                    res.status(400).json({ error: 'motherRepoPath required — set GF_MOTHER_REPO_PATH or pass in body' });
                    return;
                }
                const result = await uplinkToMotherRepo({
                    motherRepoPath,
                    sourceBundlePath: typeof body['sourceBundlePath'] === 'string' ? body['sourceBundlePath'] : undefined,
                });
                res.status(result.ok ? 200 : 400).json(result);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-repo/aggregate
         * Run mother-body aggregation on all inbox bundles.
         * Body: { motherRepoPath?: string, thresholds?: Partial<FederatedThresholds>, motherBodyVersion?: string, archiveInbox?: boolean }
         */
        app.post('/api/mother-repo/aggregate', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = (req.body ?? {});
                const motherRepoPath = resolveMotherRepoPathFromReq(body);
                if (!motherRepoPath) {
                    res.status(400).json({ error: 'motherRepoPath required — set GF_MOTHER_REPO_PATH or pass in body' });
                    return;
                }
                const result = await runMotherAggregation({
                    motherRepoPath,
                    thresholds: typeof body['thresholds'] === 'object' && body['thresholds']
                        ? body['thresholds']
                        : undefined,
                    motherBodyVersion: typeof body['motherBodyVersion'] === 'string' ? body['motherBodyVersion'] : undefined,
                    archiveInbox: typeof body['archiveInbox'] === 'boolean' ? body['archiveInbox'] : true,
                });
                res.status(result.ok ? 200 : 400).json(result);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-repo/downlink
         * Fetch mother_promoted bundle from mother-repo into local instance.
         * Body: { motherRepoPath?: string, sourceBundlePath?: string, destinationPath?: string }
         */
        app.post('/api/mother-repo/downlink', requireAuth, requireAdminAccess, async (req, res) => {
            try {
                const body = (req.body ?? {});
                const motherRepoPath = resolveMotherRepoPathFromReq(body);
                if (!motherRepoPath) {
                    res.status(400).json({ error: 'motherRepoPath required — set GF_MOTHER_REPO_PATH or pass in body' });
                    return;
                }
                const result = await downlinkFromMotherRepo({
                    motherRepoPath,
                    sourceBundlePath: typeof body['sourceBundlePath'] === 'string' ? body['sourceBundlePath'] : undefined,
                    destinationPath: typeof body['destinationPath'] === 'string' ? body['destinationPath'] : undefined,
                });
                res.status(result.ok ? 200 : 400).json(result);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/mother-repo/contradictions
         * List contradiction-blocked records from the mother-repo.
         * Query: ?motherRepoPath=<path> (optional), ?status=blocked|rejected|allow_override|needs_review
         */
        app.get('/api/mother-repo/contradictions', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const motherRepoPath = typeof req.query['motherRepoPath'] === 'string'
                    ? req.query['motherRepoPath']
                    : resolveConfiguredMotherRepoPath();
                if (!motherRepoPath) {
                    res.status(400).json({ error: 'motherRepoPath required — set GF_MOTHER_REPO_PATH or pass as query param' });
                    return;
                }
                const statusFilter = typeof req.query['status'] === 'string'
                    ? req.query['status']
                    : undefined;
                const records = listContradictionRecords(motherRepoPath, statusFilter);
                res.json({ records, total: records.length });
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-repo/contradictions/review
         * Review a contradiction-blocked record.
         * Body: { motherRepoPath?: string, payload: string, action: 'rejected'|'allow_override'|'needs_review', note?: string }
         */
        app.post('/api/mother-repo/contradictions/review', requireAuth, requireAdminAccess, (req, res) => {
            try {
                const body = (req.body ?? {});
                const motherRepoPath = resolveMotherRepoPathFromReq(body);
                if (!motherRepoPath) {
                    res.status(400).json({ error: 'motherRepoPath required — set GF_MOTHER_REPO_PATH or pass in body' });
                    return;
                }
                const payload = typeof body['payload'] === 'string' ? body['payload'] : '';
                if (!payload) {
                    res.status(400).json({ error: 'payload required' });
                    return;
                }
                const action = body['action'];
                if (action !== 'rejected' && action !== 'allow_override' && action !== 'needs_review') {
                    res.status(400).json({ error: "action must be 'rejected', 'allow_override', or 'needs_review'" });
                    return;
                }
                const note = typeof body['note'] === 'string' ? body['note'] : undefined;
                const result = reviewContradictionRecord(motherRepoPath, payload, action, note);
                res.status(result.ok ? 200 : 404).json(result);
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * GET /api/mother-repo/scheduler/state
         * Returns current scheduler state (running, last run times, error counts).
         */
        app.get('/api/mother-repo/scheduler/state', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                res.json(getMotherRepoSchedulerState());
            }
            catch (err) {
                res.status(500).json({ error: String(err) });
            }
        });
        /**
         * POST /api/mother-repo/scheduler/start
         * Start the background scheduler (if GF_MOTHER_REPO_SCHEDULER_ENABLED=true).
         * Body: {} — env vars govern the actual config.
         */
        app.post('/api/mother-repo/scheduler/start', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                const started = startMotherRepoScheduler();
                res.json({ ok: true, started, state: getMotherRepoSchedulerState() });
            }
            catch (err) {
                res.status(500).json({ ok: false, error: String(err) });
            }
        });
        /**
         * POST /api/mother-repo/scheduler/stop
         * Stop the background scheduler.
         */
        app.post('/api/mother-repo/scheduler/stop', requireAuth, requireAdminAccess, (_req, res) => {
            try {
                stopMotherRepoScheduler();
                res.json({ ok: true, state: getMotherRepoSchedulerState() });
            }
            catch (err) {
                res.status(500).json({ ok: false, error: String(err) });
            }
        });
        // ── HTTP Transport endpoints (instance-facing) ─────────────────────────
        // These endpoints form the server side of the http_repo transport.
        // Auth: requireAuth only (no admin required — instances can call with bearer token).
        // Governance is STRICTLY enforced in both directions:
        //   POST /upload — only accepts bundleType 'instance_upload'
        //   GET  /promoted — only serves bundleType 'mother_promoted'
        /**
         * POST /api/mother-repo/http/upload
         * Receive an instance_upload bundle from a remote instance.
         * Validates bundleType === 'instance_upload' before writing to server inbox.
         * Does NOT accept mother_aggregate or mother_promoted — governance boundary.
         */
        app.post('/api/mother-repo/http/upload', requireAuth, async (req, res) => {
            try {
                const bundle = req.body;
                if (!bundle || typeof bundle !== 'object') {
                    res.status(400).json({ ok: false, error: 'Request body must be a JSON object' });
                    return;
                }
                // Governance boundary: only instance_upload bundles are accepted via HTTP upload
                if (bundle['bundleType'] !== 'instance_upload') {
                    const got = String(bundle['bundleType'] ?? 'missing');
                    res.status(400).json({
                        ok: false,
                        error: `GOVERNANCE VIOLATION: only instance_upload bundles may be uploaded. Got: ${got}. ` +
                            `Cross-instance learning must flow through mother-body aggregation.`,
                    });
                    return;
                }
                const motherRepoPath = resolveConfiguredMotherRepoPath();
                if (!motherRepoPath) {
                    res.status(503).json({ ok: false, error: 'Mother-repo not configured on this server (set GF_MOTHER_REPO_PATH)' });
                    return;
                }
                const dirs = resolveMotherRepoDirs(motherRepoPath);
                mkdirSync(dirs.inbox, { recursive: true });
                const instanceId = typeof bundle['instanceId'] === 'string' ? bundle['instanceId'] : 'unknown';
                const safeId = instanceId.replace(/[^a-zA-Z0-9-]/g, '_').slice(0, 64);
                const filename = `bundle_${safeId}_${Date.now()}.json`;
                const filePath = join(dirs.inbox, filename);
                writeFileSync(filePath, JSON.stringify(bundle), 'utf-8');
                const entryCount = Array.isArray(bundle['entries']) ? bundle['entries'].length : 0;
                this.log.info({ instanceId, entryCount, filename }, 'http-transport: received instance_upload bundle');
                res.json({ ok: true, instanceId, entryCount, filename });
            }
            catch (err) {
                res.status(500).json({ ok: false, error: String(err) });
            }
        });
        /**
         * GET /api/mother-repo/http/promoted
         * Serve the current mother_promoted bundle to requesting instances.
         * Validates bundleType === 'mother_promoted' before serving.
         * Returns 404 if no promoted bundle is available yet.
         * NEVER serves inbox or mother_aggregate content — governance boundary.
         */
        app.get('/api/mother-repo/http/promoted', requireAuth, (req, res) => {
            try {
                const motherRepoPath = resolveConfiguredMotherRepoPath();
                if (!motherRepoPath) {
                    res.status(503).json({ ok: false, error: 'Mother-repo not configured on this server (set GF_MOTHER_REPO_PATH)' });
                    return;
                }
                const dirs = resolveMotherRepoDirs(motherRepoPath);
                const promotedPath = join(dirs.promoted, 'mother_promoted_bundle.json');
                if (!existsSync(promotedPath)) {
                    res.status(404).json({ ok: false, reason: 'no_promoted_bundle' });
                    return;
                }
                let bundle;
                try {
                    bundle = JSON.parse(readFileSync(promotedPath, 'utf-8'));
                }
                catch (err) {
                    res.status(500).json({ ok: false, error: `Failed to read promoted bundle: ${String(err)}` });
                    return;
                }
                // Governance boundary: validate before serving — never serve non-promoted content
                const validation = tryValidateMotherApprovedBundle(bundle);
                if (!validation.ok) {
                    res.status(403).json({
                        ok: false,
                        error: `GOVERNANCE VIOLATION: promoted bundle failed validation — ${validation.reason}`,
                    });
                    return;
                }
                res.json(bundle);
            }
            catch (err) {
                res.status(500).json({ ok: false, error: String(err) });
            }
        });
        // SPA catch-all: serve index.html for any unmatched GET (client-side routing)
        app.get('/{*path}', (_req, res) => {
            const indexHtml = join(uiRoot, 'index.html');
            if (existsSync(indexHtml)) {
                res.setHeader('Cache-Control', 'no-store');
                res.sendFile(indexHtml);
            }
            else {
                res.status(404).send('UI not found. Run: cd ui && npm run build');
            }
        });
        const tlsCfg = config.tls;
        if (tlsCfg?.certFile && tlsCfg?.keyFile) {
            try {
                const cert = readFileSync(tlsCfg.certFile);
                const key = readFileSync(tlsCfg.keyFile);
                this.httpServer = createHttpsServer({ cert, key }, app);
                this.log.info({ certFile: tlsCfg.certFile }, 'Web channel using HTTPS/TLS');
            }
            catch (err) {
                this.log.error({ err }, 'Failed to load TLS cert/key — falling back to HTTP');
                this.httpServer = createHttpServer(app);
            }
        }
        else {
            this.httpServer = createHttpServer(app);
        }
        this.wss = new WebSocketServer({ server: this.httpServer });
        this.wss.on('connection', (ws) => {
            const clientId = nanoid();
            const client = { id: clientId, ws, authenticated: false, busy: false, activeRunId: null };
            this.clients.set(clientId, client);
            wsClients.set(this.clients.size);
            // Send challenge
            ws.send(JSON.stringify({ type: 'connected', clientId, requiresAuth: true }));
            // Auto-close unauthenticated connections after 10 s
            const authTimeout = setTimeout(() => {
                if (!client.authenticated) {
                    ws.send(JSON.stringify({ type: 'error', error: 'Authentication timeout' }));
                    ws.close();
                }
            }, 10_000);
            ws.on('message', async (raw) => {
                // Reject oversized messages (max 128 KB)
                if (raw.length > 131_072) {
                    ws.send(JSON.stringify({ type: 'error', error: 'Message too large' }));
                    return;
                }
                try {
                    const data = JSON.parse(raw.toString());
                    // ── Auth handshake ─────────────────────────────────────────────────
                    if (data.type === 'auth') {
                        // Per-client brute-force protection on WS auth
                        const wsIp = ws._socket?.remoteAddress ?? 'unknown';
                        if (!await memoryStore.checkRateLimit(`wsauth:${wsIp}`, AUTH_RATE_LIMIT, AUTH_RATE_WINDOW_MS)) {
                            ws.send(JSON.stringify({ type: 'auth_fail', error: 'Too many authentication attempts' }));
                            ws.close();
                            return;
                        }
                        if (data.secret === config.gateway.secret) {
                            client.authenticated = true;
                            clearTimeout(authTimeout);
                            const stableId = getStableWebId();
                            const sessionId = await memoryStore.getOrCreateSession(stableId, 'web', stableId);
                            ws.send(JSON.stringify({ type: 'auth_ok', clientId, sessionId }));
                        }
                        else {
                            ws.send(JSON.stringify({ type: 'auth_fail', error: 'Invalid secret' }));
                            ws.close();
                        }
                        return;
                    }
                    if (!client.authenticated) {
                        ws.send(JSON.stringify({ type: 'error', error: 'Not authenticated' }));
                        return;
                    }
                    if (data.type === 'heartbeat') {
                        client.lastHeartbeatAt = new Date();
                        ws.send(JSON.stringify({ type: 'heartbeat_ack', ts: client.lastHeartbeatAt.toISOString() }));
                        return;
                    }
                    if (data.type === 'cancel') {
                        if (!client.activeRunId) {
                            ws.send(JSON.stringify({ type: 'cancel_requested', runId: null, accepted: false }));
                            return;
                        }
                        const runId = client.activeRunId;
                        const accepted = cancelAgentRun(runId, 'Cancelled from web UI');
                        ws.send(JSON.stringify({ type: 'cancel_requested', runId, accepted }));
                        return;
                    }
                    // ── HMAC signature verification (post-auth messages) ───────────────
                    // Payload signed: text content for chat, or action type for control messages.
                    // Older clients without sig support are allowed through for backward compat.
                    if (data.sig) {
                        const sigPayload = data.text ?? data.type ?? '';
                        if (!verifyMessageSig(config.gateway.secret, sigPayload, data.sig)) {
                            ws.send(JSON.stringify({ type: 'error', error: 'Message signature invalid' }));
                            return;
                        }
                    }
                    // ── Clear history command ──────────────────────────────────────────
                    if (data.type === 'clear' || data.text === '/clear') {
                        const stableId = getStableWebId();
                        const sessionId = await memoryStore.getOrCreateSession(stableId, 'web', stableId);
                        await memoryStore.clearHistory(sessionId);
                        ws.send(JSON.stringify({ type: 'cleared' }));
                        return;
                    }
                    // ── Chat message ───────────────────────────────────────────────────
                    if (!data.text || typeof data.text !== 'string')
                        return;
                    // Prevent concurrent requests from the same client
                    if (client.busy) {
                        ws.send(JSON.stringify({ type: 'error', error: 'Previous request still in progress' }));
                        return;
                    }
                    client.busy = true;
                    // Use stable ID so scheduled jobs can always reach this "session"
                    const stableId = getStableWebId();
                    // Server-derived userId — never trust the client's self-reported userId.
                    // All authenticated sessions sharing the same gateway secret map to the
                    // same stable identity, so memory / history are consistent across reconnects.
                    const msg = {
                        id: nanoid(),
                        channel: 'web',
                        userId: stableId, // server-derived, not client-reported
                        chatId: stableId,
                        text: data.text.slice(0, 8192),
                        timestamp: new Date(),
                    };
                    const run = startAgentRun({
                        userId: msg.userId,
                        channel: msg.channel,
                        label: 'websocket_stream',
                    });
                    client.activeRunId = run.runId;
                    msg.metadata = {
                        ...(msg.metadata ?? {}),
                        agentRunId: run.runId,
                    };
                    ws.send(JSON.stringify({ type: 'run_started', runId: run.runId }));
                    ws.send(JSON.stringify({ type: 'typing' }));
                    try {
                        const lease = acquireAgentExecutionLease({
                            userId: msg.userId,
                            channel: msg.channel,
                            label: 'websocket_stream',
                        });
                        try {
                            // Use streaming agent — yields token/thinking/done/error events
                            for await (const event of agent.processMessageStream(msg)) {
                                if (ws.readyState !== WebSocket.OPEN)
                                    break;
                                if (event.type === 'token') {
                                    ws.send(JSON.stringify({ type: 'token', text: event.text }));
                                }
                                else if (event.type === 'thinking') {
                                    ws.send(JSON.stringify({ type: 'thinking', tool: event.tool }));
                                }
                                else if (event.type === 'done') {
                                    ws.send(JSON.stringify({ type: 'done', runId: run.runId }));
                                }
                                else if (event.type === 'error') {
                                    ws.send(JSON.stringify({ type: 'error', error: event.error, runId: run.runId }));
                                }
                            }
                        }
                        finally {
                            lease.release();
                            run.release();
                        }
                    }
                    catch (err) {
                        const errorText = err instanceof RuntimeLimitError ? err.message : String(err);
                        ws.send(JSON.stringify({ type: 'error', error: errorText, runId: client.activeRunId ?? undefined }));
                    }
                    finally {
                        client.busy = false;
                        client.activeRunId = null;
                        run.release();
                    }
                }
                catch (err) {
                    ws.send(JSON.stringify({ type: 'error', error: String(err) }));
                }
            });
            ws.on('close', () => {
                clearTimeout(authTimeout);
                if (client.activeRunId) {
                    cancelAgentRun(client.activeRunId, 'WebSocket client disconnected');
                }
                this.clients.delete(clientId);
                wsClients.set(this.clients.size);
            });
        });
        await new Promise((resolve) => {
            this.httpServer.listen(port, host, () => {
                this.log.info({ port, host }, 'Web channel started');
                this._running = true;
                resolve();
            });
        });
    }
    async stop() {
        this.wss?.close();
        await new Promise((resolve) => {
            this.httpServer?.close(() => resolve());
        });
        this._running = false;
    }
    /**
     * Broadcast a message to ALL authenticated web clients.
     * Using stable chatId means any open browser tab will receive
     * scheduled job results, even after reconnection.
     */
    async send(message) {
        const payload = JSON.stringify({ type: 'message', text: message.text });
        for (const client of this.clients.values()) {
            if (client.authenticated && client.ws.readyState === WebSocket.OPEN) {
                client.ws.send(payload);
            }
        }
    }
    isRunning() {
        return this._running;
    }
}
//# sourceMappingURL=index.js.map