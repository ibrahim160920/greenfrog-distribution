import cron from 'node-cron';
import { memoryStore } from '../memory/store.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('scheduler');
export class Scheduler {
    tasks = new Map();
    runner = null;
    setRunner(runner) {
        this.runner = runner;
    }
    /** Load all active jobs from the DB and schedule them. */
    async start() {
        const jobs = (await memoryStore.getJobs()).filter((j) => j.status === 'active');
        log.info({ count: jobs.length }, 'Loading scheduled jobs');
        for (const job of jobs) {
            this.scheduleJob(job);
        }
    }
    /** Schedule (or re-schedule) a single job. */
    scheduleJob(job) {
        // Stop and remove any existing task for this job
        this.cancelJob(job.id);
        if (!cron.validate(job.cron)) {
            log.warn({ jobId: job.id, cron: job.cron }, 'Invalid cron expression, skipping');
            return;
        }
        const task = cron.schedule(job.cron, async () => {
            log.info({ jobId: job.id, name: job.name }, 'Running scheduled job');
            try {
                if (this.runner) {
                    await this.runner(job);
                }
                await memoryStore.updateJobRun(job.id);
            }
            catch (err) {
                log.error({ jobId: job.id, err }, 'Scheduled job failed');
            }
        }, {
            scheduled: true,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        });
        this.tasks.set(job.id, task);
        log.info({ jobId: job.id, cron: job.cron, name: job.name }, 'Job scheduled');
    }
    /** Stop and remove the live cron task for a job (does not touch DB). */
    cancelJob(jobId) {
        const task = this.tasks.get(jobId);
        if (task) {
            task.stop();
            this.tasks.delete(jobId);
            log.info({ jobId }, 'Job cancelled');
        }
    }
    stopAll() {
        for (const [id, task] of this.tasks) {
            task.stop();
            log.debug({ jobId: id }, 'Job stopped');
        }
        this.tasks.clear();
    }
    getActiveJobIds() {
        return [...this.tasks.keys()];
    }
}
export const scheduler = new Scheduler();
//# sourceMappingURL=index.js.map