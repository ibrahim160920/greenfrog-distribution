/**
 * verifier.ts — Inheritance bundle signature verification.
 *
 * Verifies Ed25519 signatures on release manifests using the
 * mother-body's public key (distributed with child runtime).
 *
 * Verification is mandatory before any inheritance bundle is applied.
 * A bundle without a valid signature is rejected — no override.
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createLogger } from '../../utils/logger.js';
import { computeManifestDigest, computeBundleHash } from './manifest.js';
const log = createLogger('inheritance-verifier');
// The mother-body public key is distributed as a PEM file alongside the runtime.
const DEFAULT_PUBLIC_KEY_PATH = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', 'keys', 'mother-public.pem');
/**
 * Verify the Ed25519 signature on a release manifest.
 *
 * @param manifest  Parsed manifest (must include signature field)
 * @param publicKeyPath  Path to mother-body Ed25519 public key PEM (optional override)
 */
export function verifyManifestSignature(manifest, publicKeyPath) {
    const keyPath = publicKeyPath ?? DEFAULT_PUBLIC_KEY_PATH;
    if (!fs.existsSync(keyPath)) {
        log.warn({ keyPath }, 'inheritance-verifier: public key file not found');
        return { ok: false, reason: `public key not found: ${keyPath}` };
    }
    let publicKey;
    try {
        const pem = fs.readFileSync(keyPath, 'utf-8');
        publicKey = crypto.createPublicKey(pem);
    }
    catch (err) {
        return { ok: false, reason: `failed to load public key: ${String(err)}` };
    }
    try {
        const digest = computeManifestDigest(manifest);
        const signatureBytes = Buffer.from(manifest.signature, 'base64url');
        const valid = crypto.verify(null, // Ed25519 uses null algorithm parameter
        digest, publicKey, signatureBytes);
        if (!valid) {
            log.warn({ releaseId: manifest.releaseId }, 'inheritance-verifier: signature invalid');
            return { ok: false, reason: 'signature verification failed' };
        }
        log.debug({ releaseId: manifest.releaseId }, 'inheritance-verifier: signature valid');
        return { ok: true };
    }
    catch (err) {
        return { ok: false, reason: `signature check threw: ${String(err)}` };
    }
}
/**
 * Verify that downloaded bundle content matches the hash declared in the manifest.
 */
export function verifyBundleHash(content, manifest) {
    const actual = computeBundleHash(content);
    if (actual !== manifest.bundleHash) {
        log.warn({ expected: manifest.bundleHash, actual }, 'inheritance-verifier: bundle hash mismatch');
        return { ok: false, reason: `bundle hash mismatch: expected ${manifest.bundleHash}, got ${actual}` };
    }
    return { ok: true };
}
//# sourceMappingURL=verifier.js.map