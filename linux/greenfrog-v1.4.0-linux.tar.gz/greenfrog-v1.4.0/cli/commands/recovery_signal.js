import { randomUUID } from 'crypto';
import { isAbsolute, resolve } from 'path';
import chalk from 'chalk';
import { recordProjectEvolutionRecoverySignalWithPolicy } from '../../memory/project_evolution_recovery_signal_policy.js';
async function resolveConfiguredRepoPath() {
    try {
        const { config } = await import('../../config/index.js');
        return config.evolution?.upgrade?.repoPath
            || config.evolution?.release?.repoPath
            || config.evolution?.codeRepo?.repoPath
            || config.evolution?.sourceRepo?.repoPath
            || null;
    }
    catch {
        return null;
    }
}
async function resolveRepoPath(repo) {
    const configuredRepo = repo?.trim()
        || await resolveConfiguredRepoPath()
        || process.cwd();
    return isAbsolute(configuredRepo) ? configuredRepo : resolve(process.cwd(), configuredRepo);
}
function parseDetails(raw) {
    if (!raw?.trim())
        return {};
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error('details must be a JSON object');
    }
    return parsed;
}
export async function recordRecoverySignalCommand(opts) {
    const repoPath = await resolveRepoPath(opts.repo);
    const recorded = recordProjectEvolutionRecoverySignalWithPolicy(repoPath, {
        id: opts.id?.trim() || `recovery:${opts.kind}:${Date.now()}:${randomUUID()}`,
        kind: opts.kind,
        priority: opts.priority ?? 'high',
        createdAt: new Date().toISOString(),
        passed: opts.passed ?? true,
        title: opts.title,
        summary: opts.summary,
        source: opts.source,
        details: parseDetails(opts.details),
    });
    const latest = recorded.history.entries[0];
    console.log(chalk.green(`Recorded ${latest?.kind ?? opts.kind} recovery signal history`));
    console.log(chalk.cyan(`Repo: ${repoPath}`));
    console.log(`Title: ${latest?.title ?? opts.title}`);
    console.log(`Passed: ${String(latest?.passed ?? (opts.passed ?? true))}`);
    console.log(`Promoted: ${String(recorded.promotion.promoted)}`);
    console.log(`Reason: ${recorded.promotion.reason}`);
}
//# sourceMappingURL=recovery_signal.js.map