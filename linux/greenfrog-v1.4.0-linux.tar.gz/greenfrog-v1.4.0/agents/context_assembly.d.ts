/**
 * Context Assembly layer for GreenFrog P4.
 *
 * Assembles the three-tier context window for a task execution:
 *
 *   pinnedContext   — always present, high priority (workspace identity,
 *                     global constraints, agent persona)
 *   workingContext  — task-specific, medium priority (prior run results,
 *                     blocked reasons, dependency summaries)
 *   ephemeralContext — freshly fetched this run (current time, run ID)
 *
 * The assembled context is serialised into the worker prompt so the agent
 * has maximum relevant signal without reading unrelated memory chunks.
 */
import type { TeamTask } from '../utils/types.js';
import type { TaskContract } from './contract.js';
export interface AssembledContext {
    /** Always injected at the top of the prompt */
    pinnedContext: string;
    /** Task-specific context from prior runs and related tasks */
    workingContext: string;
    /** Per-execution ephemeral data (timestamps, run ID) */
    ephemeralContext: string;
    /** One-line summary for logging / metadata */
    summary: string;
}
export interface ContextAssemblyInput {
    task: TeamTask;
    contract: TaskContract;
    /** IDs of tasks this task depends on, with their result summaries */
    dependencyResults?: Array<{
        id: string;
        title: string;
        resultSummary?: string | null;
    }>;
    /** Agent name / persona, if known */
    agentName?: string;
    /** Workspace name, if known */
    workspaceName?: string;
    /** Run ID for this execution */
    runId: string;
    /**
     * P4.2: High-value signals for decision quality.
     * Passed in by the caller (team.ts) after reading task metadata and
     * workspace shared memory. Keeps context assembly pure.
     */
    /** Previous run result from workspace shared memory (if this task ran before) */
    previousResultHint?: string | null;
    /** Human override context: what a human decided and why (from task.metadata) */
    humanDecisionContext?: string | null;
    /** Effective max attempts for this dispatch (unified boundary from team.ts) */
    effectiveMaxAttempts?: number;
    /**
     * P4.3: Related workspace memory entries recalled by keyword for first-run context.
     * At most 3 entries. Passed in by team.ts after keyword-based lookup.
     */
    relatedMemoryHints?: Array<{
        key: string;
        value: string;
    }>;
}
/** Feedback fields written by the execution loop's observe/evaluate/recover phases */
export interface FeedbackSnapshot {
    pendingHint?: string | null;
    latestObservation?: {
        text: string;
        at: string;
    } | null;
    latestError?: {
        message: string;
        errorClass: string;
        at: string;
    } | null;
    nextSuggestedAction?: string | null;
    confidence?: number | null;
}
/** Extract feedback snapshot from task metadata (written by execution loop) */
export declare function extractFeedback(m: Record<string, unknown>): FeedbackSnapshot;
export declare function assembleTaskContext(input: ContextAssemblyInput): AssembledContext;
/**
 * Combine all context tiers into a single worker prompt string.
 * Order: pinned → working → ephemeral → (caller appends contract)
 */
export declare function renderContextPrompt(ctx: AssembledContext): string;
//# sourceMappingURL=context_assembly.d.ts.map