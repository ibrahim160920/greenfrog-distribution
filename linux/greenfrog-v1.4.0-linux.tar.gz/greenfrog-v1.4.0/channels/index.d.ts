import { BaseChannel } from './base.js';
import { TelegramChannel } from './telegram/index.js';
import { DiscordChannel } from './discord/index.js';
import { SlackChannel } from './slack/index.js';
import { WebChannel } from './web/index.js';
import { WhatsAppChannel } from './whatsapp/index.js';
import { WeComChannel } from './wecom/index.js';
import { FeishuChannel } from './feishu/index.js';
import { DingTalkChannel } from './dingtalk/index.js';
import { TeamsChannel } from './teams/index.js';
import { LineChannel } from './line/index.js';
import { MatrixChannel } from './matrix/index.js';
import type { OutgoingMessage, ChannelName } from '../utils/types.js';
export declare class ChannelManager {
    private channels;
    constructor();
    register(channel: BaseChannel): void;
    startAll(cfg?: Record<string, unknown>): Promise<void>;
    stopAll(): Promise<void>;
    /** Send a message through a specific channel (used by the scheduler). */
    send(channelName: ChannelName, message: OutgoingMessage): Promise<void>;
    getStatus(): Record<string, boolean>;
}
export declare const channelManager: ChannelManager;
export { BaseChannel, TelegramChannel, DiscordChannel, SlackChannel, WebChannel, WhatsAppChannel, WeComChannel, FeishuChannel, DingTalkChannel, TeamsChannel, LineChannel, MatrixChannel };
//# sourceMappingURL=index.d.ts.map