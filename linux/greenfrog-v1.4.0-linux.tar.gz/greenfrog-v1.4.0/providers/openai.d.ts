import type { ProviderRequest, ProviderResponse } from '../utils/types.js';
import { BaseProvider, type StreamingCall } from './base.js';
type OpenAIAuthMode = 'bearer' | 'apikey' | 'raw';
export declare function buildOpenAIAuthHeaders(apiKey: string, authMode?: string, authHeader?: string, authScheme?: string): Record<string, string>;
export declare class OpenAIProvider extends BaseProvider {
    name: string;
    defaultModel: string;
    private client;
    private model;
    private baseUrl;
    private authHeaders;
    private authMode;
    private authHeaderName;
    private authScheme?;
    private extraHeaders;
    private sendClientRequestId;
    protected useResponsesApi: boolean;
    protected reasoningEffort: string | undefined;
    protected disableResponseStorage: boolean;
    protected responsesMaxAttempts: number;
    protected responsesRetryBaseDelayMs: number;
    constructor(apiKey: string, model?: string, baseUrl?: string, useResponsesApi?: boolean, reasoningEffort?: string, authMode?: OpenAIAuthMode, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, sendClientRequestId?: boolean, disableResponseStorage?: boolean, responsesMaxAttempts?: number, responsesRetryBaseDelayMs?: number);
    getAuthDebugInfo(): {
        mode: OpenAIAuthMode;
        header: string;
        scheme?: string;
        extraHeaders?: string[];
        autoClientRequestId?: boolean;
    };
    private buildRequestHeaders;
    private throwResponsesApiError;
    private postResponsesFetch;
    private consumeResponsesStream;
    chat(request: ProviderRequest): Promise<ProviderResponse>;
    private chatViaResponsesApi;
    private postResponsesApi;
    /** Parse a single Responses API SSE event and call the provided callbacks */
    private applyResponsesEvent;
    private buildInputForResponsesApi;
    private buildToolsForResponsesApi;
    private chatNonStream;
    private chatStreamInternal;
    chatStream(request: ProviderRequest): StreamingCall;
    private chatStreamViaResponsesApi;
    /** Shared message builder for chat() and chatStream() */
    private buildMessages;
    /** Shared tool builder */
    private buildTools;
    isAvailable(): Promise<boolean>;
    listModels(): Promise<string[]>;
}
export {};
//# sourceMappingURL=openai.d.ts.map