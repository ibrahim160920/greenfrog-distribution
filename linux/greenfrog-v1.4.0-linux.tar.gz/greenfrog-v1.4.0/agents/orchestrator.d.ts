import type { AdaptiveModelPolicy, OrchestratorRules, TeamTask, TeamTopologyCandidateRolloutPolicy } from '../utils/types.js';
/**
 * Parses raw metadata into a typed OrchestratorRules object.
 * Returns null if the input is absent or not a valid object.
 */
export declare function parseOrchestratorRules(raw: unknown): OrchestratorRules | null;
/**
 * Supervisor agent makes an immediate, binding conflict resolution decision.
 * Much faster than full consensus — uses a single cheap LLM call.
 * Falls back to 'changes_requested' (conservative) on any error.
 */
export declare function evaluateSupervisorConflictSafe(params: {
    task: TeamTask;
    challengeSummary: string;
    rules: OrchestratorRules;
}): Promise<'approve' | 'changes_requested'>;
export type AdaptiveOrchestratorPolicy = {
    enabled: boolean;
    rollbackOnConsecutiveDegrades: number;
    freezeMinutes: number;
    severeConsensusTimeoutRate: number;
    severeBlockedRate: number;
    severeRetryRate: number;
};
export declare function parseAdaptiveOrchestratorPolicy(raw: unknown): AdaptiveOrchestratorPolicy;
export interface SwarmMetrics {
    topologyId: string;
    taskCount: number;
    challengedTaskCount: number;
    retryTaskCount: number;
    consensusTaskCount: number;
    consensusTimedOutCount: number;
    blockedTaskCount: number;
    /** Fraction of tasks that needed more than one attempt */
    retryRate: number;
    /** Fraction of tasks that received a peer challenge */
    challengeRate: number;
    /** Of challenged tasks: fraction where challenge was upheld (changes_requested) */
    challengeSuccessRate: number;
    /** Of tasks that went to consensus: fraction that timed out without resolution */
    consensusTimeoutRate: number;
    /** Fraction of tasks currently blocked or escalated */
    blockedRate: number;
    computedAt: string;
}
export declare function computeSwarmMetrics(tasks: TeamTask[], topologyId: string): SwarmMetrics | null;
export declare function computeStrategyTrackSwarmMetrics(tasks: TeamTask[], topologyId: string, track: 'stable' | 'candidate'): SwarmMetrics | null;
/**
 * Derive updated rules from swarm metrics using threshold heuristics.
 * Returns null when no rule changes are warranted.
 *
 * Thresholds (tunable via metadata in the future):
 *   consensusTimeoutRate > 0.30  → switch to supervisor_resolve (voting stalls)
 *   consensusTimeoutRate < 0.05  → revert to consensus (voting works fine)
 *   retryRate > 0.40             → enable reflect_and_retry (agents keep failing same way)
 *   retryRate < 0.15             → revert to block (agents self-correct without reflection)
 */
export declare function adaptRulesFromMetrics(current: OrchestratorRules, metrics: SwarmMetrics): OrchestratorRules | null;
export declare function parseAdaptiveModelPolicy(raw: unknown): AdaptiveModelPolicy | null;
export declare function decideAdaptiveModelAction(currentState: 'baseline' | 'promoted' | null | undefined, metrics: SwarmMetrics, policy: AdaptiveModelPolicy): 'promote' | 'revert' | null;
export declare function decideCandidateRolloutAction(currentRolloutPercent: number, metrics: SwarmMetrics, policy: TeamTopologyCandidateRolloutPolicy): {
    action: 'increase' | 'decrease' | 'promote';
    nextRolloutPercent: number;
} | null;
/**
 * Runs the adaptive rules cycle for one topology:
 * 1. Check cooldown (skip if adapted recently)
 * 2. Compute metrics from task list
 * 3. Derive rule updates from metrics
 * 4. Persist updated rules back to topology metadata
 */
export declare function adaptOrchestratorRulesSafe(params: {
    topologyId: string;
    workspaceId: string;
    tasks: TeamTask[];
    currentRules: OrchestratorRules;
}): Promise<OrchestratorRules | null>;
export declare function adaptTopologyModelsSafe(params: {
    topologyId: string;
    workspaceId: string;
    tasks: TeamTask[];
}): Promise<'promote' | 'revert' | null>;
export declare function adaptCandidateRolloutSafe(params: {
    topologyId: string;
    workspaceId: string;
    tasks: TeamTask[];
}): Promise<'increase' | 'decrease' | 'promote' | null>;
//# sourceMappingURL=orchestrator.d.ts.map