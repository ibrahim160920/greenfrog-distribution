import type { ScheduledJob } from '../utils/types.js';
type JobRunner = (job: ScheduledJob) => Promise<void>;
export declare class Scheduler {
    private tasks;
    private runner;
    setRunner(runner: JobRunner): void;
    /** Load all active jobs from the DB and schedule them. */
    start(): Promise<void>;
    /** Schedule (or re-schedule) a single job. */
    scheduleJob(job: ScheduledJob): void;
    /** Stop and remove the live cron task for a job (does not touch DB). */
    cancelJob(jobId: string): void;
    stopAll(): void;
    getActiveJobIds(): string[];
}
export declare const scheduler: Scheduler;
export {};
//# sourceMappingURL=index.d.ts.map