/**
 * first_boot.ts — Registration state machine.
 *
 * States:
 *   unregistered → generating → pending → submitted → enrolled
 *                                                   ↘ failed (retriable)
 *
 * Rules:
 *   - NO local-only mode: instances MUST register before normal operation
 *   - State is persisted to .greenfrog/identity/state.json after every transition
 *   - Failed state is recoverable via retryEnrollment()
 *   - Enrolled state is terminal (no re-enrollment without clearEnrollment())
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { createLogger } from '../../utils/logger.js';
import { loadOrCreateInstallRecord } from './enrollment.js';
import { saveCredential } from './credential.js';
import { getFirstBootMessages } from './first_boot_messages.js';
const log = createLogger('first-boot');
// ── Path helpers ──────────────────────────────────────────────────────────────
function getStatePath(baseDir) {
    const root = baseDir ?? path.join(os.homedir(), '.greenfrog');
    return path.join(root, 'identity', 'state.json');
}
// ── State persistence ─────────────────────────────────────────────────────────
function readState(baseDir) {
    const statePath = getStatePath(baseDir);
    if (!fs.existsSync(statePath)) {
        return { state: 'unregistered', updatedAt: new Date().toISOString(), attemptCount: 0 };
    }
    try {
        return JSON.parse(fs.readFileSync(statePath, 'utf-8'));
    }
    catch {
        return { state: 'unregistered', updatedAt: new Date().toISOString(), attemptCount: 0 };
    }
}
function writeState(record, baseDir) {
    const statePath = getStatePath(baseDir);
    fs.mkdirSync(path.dirname(statePath), { recursive: true });
    fs.writeFileSync(statePath, JSON.stringify(record, null, 2), 'utf-8');
}
function transition(state, extras = {}, baseDir) {
    const prev = readState(baseDir);
    const next = {
        ...prev,
        state,
        updatedAt: new Date().toISOString(),
        ...extras,
    };
    writeState(next, baseDir);
    log.debug({ from: prev.state, to: state }, 'enrollment state transition');
    return next;
}
/**
 * Run the first-boot enrollment flow end-to-end.
 *
 * 1. Load or create install record (generates enrollmentKey if first time)
 * 2. Transition: generating → pending
 * 3. POST to enrollmentUrl
 * 4. On success: save credential, transition → enrolled
 * 5. On failure: transition → failed
 *
 * If already enrolled, returns enrolled state immediately.
 * No-op if currently submitted (prevents double-submission).
 */
export async function runFirstBoot(opts) {
    const { enrollmentUrl, appVersion, baseDir } = opts;
    const fetchFn = opts.fetchFn ?? globalThis.fetch;
    const msgs = getFirstBootMessages(opts.locale);
    // Load current state
    const currentState = readState(baseDir);
    // Already enrolled — return immediately
    if (currentState.state === 'enrolled') {
        const install = loadOrCreateInstallRecord(baseDir);
        return {
            ok: true,
            state: 'enrolled',
            instanceId: install.instanceId,
            enrollmentKey: install.enrollmentKey,
        };
    }
    // Currently submitting — don't double-submit
    if (currentState.state === 'submitted') {
        const install = loadOrCreateInstallRecord(baseDir);
        return {
            ok: false,
            state: 'submitted',
            instanceId: install.instanceId,
            enrollmentKey: install.enrollmentKey,
            error: 'registration already in progress',
        };
    }
    // Step 1: Generate identifiers (idempotent)
    transition('generating', {}, baseDir);
    log.info(msgs.generating);
    const install = loadOrCreateInstallRecord(baseDir);
    transition('pending', {}, baseDir);
    log.info({ instanceId: install.instanceId }, msgs.submitting);
    // Step 2: Submit registration
    const request = {
        instanceId: install.instanceId,
        enrollmentKey: install.enrollmentKey,
        platform: process.platform,
        arch: process.arch,
        nodeVersion: process.version,
        appVersion,
    };
    const prev = readState(baseDir);
    transition('submitted', {
        attemptCount: (prev.attemptCount ?? 0) + 1,
        lastAttemptAt: new Date().toISOString(),
    }, baseDir);
    try {
        const response = await fetchFn(enrollmentUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(request),
        });
        const body = await response.json();
        if (!response.ok || !body.ok || !body.jwt) {
            const reason = body.error ?? `HTTP ${response.status}`;
            log.warn({ reason }, msgs.errorServer);
            transition('failed', { failureReason: reason }, baseDir);
            return {
                ok: false,
                state: 'failed',
                instanceId: install.instanceId,
                enrollmentKey: install.enrollmentKey,
                error: reason,
            };
        }
        // Step 3: Persist credential
        saveCredential({
            instanceId: install.instanceId,
            jwt: body.jwt,
            issuedAt: new Date().toISOString(),
            expiresAt: body.expiresAt ?? null,
        }, baseDir);
        transition('enrolled', { failureReason: undefined, enrolledAt: new Date().toISOString() }, baseDir);
        log.info({ instanceId: install.instanceId }, msgs.success);
        return {
            ok: true,
            state: 'enrolled',
            instanceId: install.instanceId,
            enrollmentKey: install.enrollmentKey,
        };
    }
    catch (err) {
        const reason = String(err);
        log.warn({ err: reason }, msgs.errorNetwork);
        transition('failed', { failureReason: reason }, baseDir);
        return {
            ok: false,
            state: 'failed',
            instanceId: install.instanceId,
            enrollmentKey: install.enrollmentKey,
            error: reason,
        };
    }
}
/**
 * Retry enrollment after a previous failure.
 * Resets state to 'pending' and re-runs the submission step.
 */
export async function retryEnrollment(opts) {
    const { baseDir } = opts;
    const currentState = readState(baseDir);
    if (currentState.state !== 'failed') {
        const install = loadOrCreateInstallRecord(baseDir);
        return {
            ok: false,
            state: currentState.state,
            instanceId: install.instanceId,
            enrollmentKey: install.enrollmentKey,
            error: 'can only retry from failed state',
        };
    }
    // Reset to pending so runFirstBoot can proceed
    writeState({ ...currentState, state: 'pending', updatedAt: new Date().toISOString() }, baseDir);
    return runFirstBoot(opts);
}
/** Return the current enrollment state record without modifying it. */
export function getEnrollmentState(baseDir) {
    return readState(baseDir);
}
/**
 * Return true if this instance is fully enrolled and has a credential.
 * This is the gate for entering normal operation.
 */
export function isEnrolled(baseDir) {
    return readState(baseDir).state === 'enrolled';
}
/**
 * Clear all enrollment state and credentials.
 * Used only when re-enrollment is explicitly requested (e.g., support workflow).
 */
export function clearEnrollment(baseDir) {
    const root = baseDir ?? path.join(os.homedir(), '.greenfrog');
    const identityDir = path.join(root, 'identity');
    if (fs.existsSync(identityDir)) {
        fs.rmSync(identityDir, { recursive: true });
    }
    log.warn('enrollment cleared — instance must re-register on next boot');
}
//# sourceMappingURL=first_boot.js.map