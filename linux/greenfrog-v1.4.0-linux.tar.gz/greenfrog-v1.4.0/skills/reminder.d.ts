import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class ReminderSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    private keyPrefix;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=reminder.d.ts.map