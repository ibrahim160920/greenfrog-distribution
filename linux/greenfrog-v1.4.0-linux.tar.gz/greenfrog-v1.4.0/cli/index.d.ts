import { Command } from 'commander';
export declare function createCLI(): Command;
//# sourceMappingURL=index.d.ts.map