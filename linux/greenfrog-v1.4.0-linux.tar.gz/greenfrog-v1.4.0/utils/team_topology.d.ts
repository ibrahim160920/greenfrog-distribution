import type { AdaptiveModelPolicy, TeamTask, TeamTopologyCandidateRolloutAuditEvent, TeamTopologyCandidateRolloutControl, TeamTopologyCandidateStrategy, TeamTopologyCandidateRolloutPolicy, TeamTopology, TeamTopologyModelRoute, TeamTopologyModelRouteKey, TeamTopologyModelRoutes, TeamTopologyStrategySnapshot } from './types.js';
export declare function parseTeamTopologyModelRoute(raw: unknown): TeamTopologyModelRoute | null;
export declare function parseTeamTopologyModelRoutes(raw: unknown): TeamTopologyModelRoutes | null;
export declare function parseAdaptiveModelPolicyInput(raw: unknown): AdaptiveModelPolicy | null;
export declare function parseTeamTopologyCandidateStrategy(raw: unknown): TeamTopologyCandidateStrategy | null;
export declare function parseTeamTopologyCandidateRolloutPolicy(raw: unknown): TeamTopologyCandidateRolloutPolicy | null;
export declare function parseTeamTopologyCandidateRolloutControl(raw: unknown): TeamTopologyCandidateRolloutControl | null;
export declare function parseTeamTopologyCandidateRolloutAudit(raw: unknown): TeamTopologyCandidateRolloutAuditEvent[] | null;
export declare function hydrateTeamTopology(topology: TeamTopology): TeamTopology;
export declare function mergeTeamTopologyMetadata(metadata: Record<string, unknown> | undefined, updates: Partial<Pick<TeamTopology, 'orchestratorRules' | 'adaptiveModelPolicy' | 'modelRoutes' | 'candidateStrategy' | 'candidateRolloutPolicy' | 'candidateRolloutControl'>>, options?: {
    existingTopology?: TeamTopology | null;
    nowIso?: string;
}): Record<string, unknown> | undefined;
export declare function buildTeamTopologyStrategySnapshot(topology: TeamTopology): TeamTopologyStrategySnapshot;
export declare function findTeamTopologyStrategySnapshot(topology: TeamTopology | null | undefined, version: number): TeamTopologyStrategySnapshot | null;
export declare function selectTeamTopologyStrategyTrack(topology: TeamTopology | null | undefined, seed: string): {
    track: 'stable' | 'candidate';
    snapshot: TeamTopologyStrategySnapshot | TeamTopologyCandidateStrategy;
} | null;
export declare function buildPromoteCandidateStrategyUpdates(topology: TeamTopology | null | undefined): {
    candidate: TeamTopologyCandidateStrategy;
    updates: Pick<TeamTopology, 'orchestratorRules' | 'adaptiveModelPolicy' | 'modelRoutes' | 'candidateStrategy'>;
} | null;
export declare function appendCandidateRolloutAuditEvent(metadata: Record<string, unknown> | undefined, event: TeamTopologyCandidateRolloutAuditEvent): Record<string, unknown>;
export declare function resolveTeamTopologyModelRoute(topology: TeamTopology | null | undefined, routeKey: TeamTopologyModelRouteKey, fallback?: TeamTopologyModelRoute | null): TeamTopologyModelRoute | null;
export declare function materializeTaskTopology(task: TeamTask, liveTopology?: TeamTopology | null): TeamTopology | null;
//# sourceMappingURL=team_topology.d.ts.map