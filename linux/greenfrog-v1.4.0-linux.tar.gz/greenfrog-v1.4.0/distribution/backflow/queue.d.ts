/**
 * queue.ts — Local backflow queue.
 *
 * Ring buffer (max 1000 entries) persisted at .greenfrog/backflow/queue.json.
 * Entries are appended locally and flushed to the mother-body in batches.
 * On flush failure, entries are retained for retry (up to 5 attempts, 1h window).
 */
import type { SanitizedBackflowEntry } from './sanitizer.js';
export interface QueueEntry {
    id: string;
    data: SanitizedBackflowEntry;
    enqueuedAt: string;
    attempts: number;
    lastAttemptAt?: string;
}
/** Append a sanitized entry to the local queue. Trims oldest if over cap. */
export declare function enqueue(data: SanitizedBackflowEntry, baseDir?: string): void;
/** Peek at the oldest N entries without removing them. */
export declare function peekBatch(n: number, baseDir?: string): QueueEntry[];
/** Mark entries as successfully sent — remove them from the queue. */
export declare function ackBatch(ids: string[], baseDir?: string): void;
/** Increment attempt count on entries (called when a flush attempt fails). */
export declare function nackBatch(ids: string[], baseDir?: string): void;
/** Return current queue depth. */
export declare function queueDepth(baseDir?: string): number;
/** Clear entire queue (used in tests). */
export declare function clearQueue(baseDir?: string): void;
//# sourceMappingURL=queue.d.ts.map