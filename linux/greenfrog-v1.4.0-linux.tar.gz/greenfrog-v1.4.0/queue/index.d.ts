/**
 * BullMQ task queue — async decoupling for AI message processing.
 *
 * When config.queue.redisUrl is set:
 *   - All POST /api/message requests are enqueued instead of blocking HTTP.
 *   - Worker processes jobs concurrently (config.queue.concurrency, default 4).
 *   - Results are stored in Redis for 60 s so callers can poll GET /api/jobs/:id.
 *   - WebSocket clients receive results via push notification.
 *   - Graceful shutdown drains the worker before process exit.
 *
 * When redisUrl is absent, the module no-ops gracefully (direct processing).
 */
import { Queue } from 'bullmq';
export interface ProcessMessageJob {
    type: 'process_message';
    requestId: string;
    userId: string;
    channel: string;
    chatId: string;
    sessionId: string;
    text: string;
    agentId?: string;
    workspaceId?: string;
}
export type QueueJobData = ProcessMessageJob;
export interface JobResult {
    requestId: string;
    text: string;
    error?: string;
}
export declare function isQueueEnabled(): boolean;
export declare function getQueue(): Queue | null;
/** Register a callback that fires when a job finishes (used by web channel for WS push). */
export declare function onJobResult(cb: (result: JobResult) => void): void;
/**
 * Enqueue a message processing job.
 * Returns the BullMQ job ID (or undefined when queue is disabled).
 */
export declare function enqueueMessage(data: ProcessMessageJob): Promise<string | undefined>;
/**
 * Poll for a job result (used when caller prefers pull over push).
 * Returns null if not yet ready.
 */
export declare function getJobResult(requestId: string): JobResult | null;
export declare function initQueue(processMessage: (data: ProcessMessageJob) => Promise<string>): Promise<void>;
export declare function closeQueue(): Promise<void>;
//# sourceMappingURL=index.d.ts.map