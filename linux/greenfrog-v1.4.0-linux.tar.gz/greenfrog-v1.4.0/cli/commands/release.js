import chalk from 'chalk';
import { config } from '../../config/index.js';
import { getProjectEvolutionCapabilities, resolveProjectEvolutionMode } from '../../memory/evolution_mode.js';
import { generateProjectRelease } from '../../release/project_release.js';
function resolveReleaseConfig(overrides) {
    const mode = resolveProjectEvolutionMode(config.evolution);
    const caps = getProjectEvolutionCapabilities(mode);
    const release = config.evolution?.release;
    return {
        enabled: caps.allowReleaseAutomation && Boolean(release?.enabled),
        repoPath: release?.repoPath ?? process.cwd(),
        manifestPath: release?.manifestPath ?? '.greenfrog/releases/latest.json',
        notesPath: release?.notesPath ?? '.greenfrog/releases/RELEASE_NOTES.md',
        bump: overrides?.bump ?? release?.bump ?? 'patch',
        approvalWindowStartHourUtc: release?.approvalWindowStartHourUtc,
        approvalWindowEndHourUtc: release?.approvalWindowEndHourUtc,
        approvedWeekdaysUtc: release?.approvedWeekdaysUtc,
        healthCheckCommands: release?.healthCheckCommands ?? [],
        minHealthChecksPassing: release?.minHealthChecksPassing ?? 0,
        autoCommit: release?.autoCommit ?? false,
        autoPush: release?.autoPush ?? false,
        autoTag: release?.autoTag ?? false,
        createGithubRelease: release?.createGithubRelease ?? false,
        remote: release?.remote ?? 'origin',
        repo: release?.repo,
        baseBranch: release?.baseBranch ?? 'main',
        githubToken: config.skills.github?.token,
        releaseTitle: release?.releaseTitle ?? 'GreenFrog automated release',
        branchPrefix: release?.branchPrefix ?? 'greenfrog-evolution',
        commitMessage: release?.commitMessage ?? 'chore(release): publish automated release metadata',
        tagPrefix: release?.tagPrefix ?? 'v',
    };
}
export async function manageRelease(opts) {
    const releaseConfig = resolveReleaseConfig({ bump: opts.bump });
    const result = await generateProjectRelease(releaseConfig);
    if (!releaseConfig.enabled) {
        console.log(chalk.yellow('Project release automation is disabled.'));
        return;
    }
    console.log(chalk.bold('\nProject Release Status'));
    console.log(`  ${chalk.cyan('Current version:')} ${result.currentVersion}`);
    console.log(`  ${chalk.cyan('Next version:')} ${result.nextVersion}`);
    console.log(`  ${chalk.cyan('Manifest:')} ${result.manifestPath}`);
    console.log(`  ${chalk.cyan('Release notes:')} ${result.notesPath}`);
    console.log(`  ${chalk.cyan('Changed:')} ${result.changed ? 'yes' : 'no'}`);
    console.log(`  ${chalk.cyan('Committed:')} ${result.committed ? 'yes' : 'no'}`);
    console.log(`  ${chalk.cyan('Pushed:')} ${result.pushed ? 'yes' : 'no'}`);
    console.log(`  ${chalk.cyan('Tagged:')} ${result.tagged ? 'yes' : 'no'}`);
    console.log(`  ${chalk.cyan('Branch:')} ${result.branch ?? 'none'}`);
    if (result.releaseUrl) {
        console.log(`  ${chalk.cyan('GitHub release:')} ${result.releaseUrl}`);
    }
    if (result.skippedReason) {
        console.log(`  ${chalk.yellow('Reason:')} ${result.skippedReason}`);
    }
}
//# sourceMappingURL=release.js.map