/**
 * Patrol — 主动巡检技能
 *
 * 支持 HTTP 和 TCP 两种巡检类型：
 *   HTTP：检查状态码、响应时间、响应体关键词
 *   TCP ：检查端口是否可达
 *
 * 核心逻辑：
 *   - 每次 patrol runner 触发时，检查距上次巡检是否已超过 interval_min
 *   - 连续失败次数 >= alert_threshold 才推送告警（防止偶发抖动误报）
 *   - 服务恢复时自动推送恢复通知
 *   - 历史记录保留最近 100 条，供用户查询
 */
import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class PatrolSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    private addCheck;
    private removeCheck;
    private listChecks;
    private checkNow;
    private setStatus;
    private showHistory;
}
export interface CheckResult {
    ok: boolean;
    statusCode?: number;
    latencyMs: number;
    error?: string;
}
export declare function runCheck(check: import('../utils/types.js').PatrolCheck): Promise<CheckResult>;
//# sourceMappingURL=patrol.d.ts.map