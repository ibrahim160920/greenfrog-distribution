import { WebSocketServer, WebSocket } from 'ws';
import { createServer } from 'http';
import { createHmac, timingSafeEqual } from 'crypto';
import { createLogger } from '../utils/logger.js';
import { config } from '../config/index.js';
import { nanoid } from 'nanoid';
const log = createLogger('gateway');
/**
 * Verify a per-message HMAC-SHA256 signature.
 * Clients sign messages with: HMAC-SHA256(secret, JSON.stringify(payloadWithoutSig))
 */
function verifyMessageSig(secret, payload, sig) {
    const expected = createHmac('sha256', secret).update(payload).digest('hex');
    try {
        return timingSafeEqual(Buffer.from(sig, 'hex'), Buffer.from(expected, 'hex'));
    }
    catch {
        return false;
    }
}
export class Gateway {
    wss = null;
    httpServer = null;
    clients = new Map();
    handlers = new Map();
    running = false;
    registerHandler(type, handler) {
        this.handlers.set(type, handler);
    }
    async start() {
        if (this.running)
            return;
        const { port, host, secret } = config.gateway;
        this.httpServer = createServer((req, res) => {
            if (req.url === '/health') {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ status: 'ok', clients: this.clients.size }));
                return;
            }
            res.writeHead(404);
            res.end();
        });
        this.wss = new WebSocketServer({ server: this.httpServer });
        this.wss.on('connection', (ws) => {
            const clientId = nanoid();
            const client = {
                id: clientId,
                ws,
                authenticated: false,
                connectedAt: new Date(),
            };
            this.clients.set(clientId, client);
            log.info({ clientId }, 'Gateway client connected');
            const reply = (type, data) => {
                if (ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({ type, data, clientId }));
                }
            };
            // Auto-close unauthenticated connections after 15 s
            const authTimeout = setTimeout(() => {
                if (!client.authenticated) {
                    reply('error', { error: 'Authentication timeout' });
                    ws.close();
                }
            }, 15_000);
            ws.on('message', async (raw) => {
                // Reject oversized messages (max 128 KB)
                if (raw.length > 131_072) {
                    reply('error', { error: 'Message too large' });
                    return;
                }
                try {
                    const msg = JSON.parse(raw.toString());
                    // Auth handshake
                    if (msg.type === 'auth') {
                        if (msg.secret === secret) {
                            client.authenticated = true;
                            clearTimeout(authTimeout);
                            reply('auth_ok', { clientId });
                            log.info({ clientId }, 'Client authenticated');
                        }
                        else {
                            reply('auth_fail', { error: 'Invalid secret' });
                            ws.close();
                        }
                        return;
                    }
                    if (!client.authenticated) {
                        reply('error', { error: 'Not authenticated' });
                        return;
                    }
                    // Verify per-message HMAC signature if provided by the client
                    const rawMsg = raw.toString();
                    if ('sig' in msg) {
                        const { sig, ...rest } = msg;
                        const payload = JSON.stringify(rest);
                        if (!verifyMessageSig(secret, payload, sig)) {
                            reply('error', { error: 'Invalid message signature' });
                            log.warn({ clientId }, 'Gateway message rejected: invalid HMAC signature');
                            return;
                        }
                    }
                    const handler = this.handlers.get(msg.type);
                    if (handler) {
                        await handler(msg.type, msg.data, client, reply);
                    }
                    else {
                        reply('error', { error: `Unknown message type: ${msg.type}` });
                    }
                }
                catch (err) {
                    log.error({ err }, 'Gateway message error');
                }
            });
            ws.on('close', () => {
                clearTimeout(authTimeout);
                this.clients.delete(clientId);
                log.info({ clientId }, 'Gateway client disconnected');
            });
            ws.on('error', (err) => {
                log.error({ clientId, err }, 'WebSocket error');
                this.clients.delete(clientId);
            });
            // Send welcome
            reply('connected', {
                clientId,
                version: '1.0.0',
                requiresAuth: true,
            });
        });
        await new Promise((resolve) => {
            this.httpServer.listen(port, host, () => {
                log.info({ port, host }, 'Gateway started');
                this.running = true;
                resolve();
            });
        });
    }
    broadcast(type, data) {
        const msg = JSON.stringify({ type, data });
        for (const client of this.clients.values()) {
            if (client.authenticated && client.ws.readyState === WebSocket.OPEN) {
                client.ws.send(msg);
            }
        }
    }
    async stop() {
        this.wss?.close();
        await new Promise((resolve) => {
            this.httpServer?.close(() => resolve());
        });
        this.running = false;
        log.info('Gateway stopped');
    }
    getStatus() {
        return {
            running: this.running,
            clients: this.clients.size,
            host: config.gateway.host,
            port: config.gateway.port,
        };
    }
}
export const gateway = new Gateway();
//# sourceMappingURL=index.js.map