/**
 * sanitizer.ts — Backflow data sanitizer.
 *
 * Strips all user-identifiable fields from backflow payloads before transmission.
 * This sanitizer is non-bypassable: all backflow data passes through it.
 *
 * What is ALLOWED (anonymized structural data):
 *   - version, platform, arch
 *   - uptime (seconds)
 *   - capability usage counts (no content)
 *   - anonymized error codes (no stack traces, no messages)
 *   - performance metrics (latency buckets, no content)
 *
 * What is NEVER transmitted:
 *   - raw conversation content
 *   - private files or documents
 *   - personal or identifying information
 *   - proprietary work products
 *   - stack traces or error messages
 *   - file paths
 */
/** Allowed top-level string fields in backflow entries. */
const ALLOWED_STRING_FIELDS = new Set([
    'type', 'version', 'platform', 'arch', 'nodeVersion',
    'errorCode', 'category', 'instanceId', 'recordedAt',
]);
/** Allowed numeric fields. */
const ALLOWED_NUMERIC_FIELDS = new Set([
    'uptime', 'count', 'successCount', 'failureCount', 'latencyMs',
    'p50Ms', 'p95Ms', 'p99Ms', 'totalApplications', 'successRate',
]);
/** Allowed boolean fields. */
const ALLOWED_BOOLEAN_FIELDS = new Set(['autoVerified']);
/**
 * Sanitize a single backflow entry.
 * Returns null if the entry cannot be safely sanitized (skip silently).
 */
export function sanitizeEntry(raw) {
    if (!raw.type || typeof raw.type !== 'string')
        return null;
    const sanitized = { type: raw.type };
    for (const [key, value] of Object.entries(raw)) {
        if (key === 'type')
            continue;
        if (ALLOWED_STRING_FIELDS.has(key) && typeof value === 'string') {
            sanitized[key] = value;
        }
        else if (ALLOWED_NUMERIC_FIELDS.has(key) && typeof value === 'number' && isFinite(value)) {
            sanitized[key] = value;
        }
        else if (ALLOWED_BOOLEAN_FIELDS.has(key) && typeof value === 'boolean') {
            sanitized[key] = value;
        }
        // Any other field is silently dropped
    }
    return sanitized;
}
/**
 * Sanitize an array of backflow entries.
 * Drops any entries that fail sanitization.
 */
export function sanitizeBatch(entries) {
    const result = [];
    for (const entry of entries) {
        const sanitized = sanitizeEntry(entry);
        if (sanitized !== null)
            result.push(sanitized);
    }
    return result;
}
//# sourceMappingURL=sanitizer.js.map