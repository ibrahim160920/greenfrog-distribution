import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class WeComChannel extends BaseChannel {
    readonly name: "wecom";
    private corpId;
    private corpSecret;
    private agentId;
    private token;
    private encodingAESKey;
    private webhookUrl;
    private callbackPort;
    private _encToken;
    private _encTokenIv;
    private _tokenExpiresAt;
    private readonly _sessionKey;
    private httpServer;
    private _running;
    start(): Promise<void>;
    stop(): Promise<void>;
    isRunning(): boolean;
    private startCallbackServer;
    send(message: OutgoingMessage): Promise<void>;
    private storeToken;
    private loadToken;
    private getAccessToken;
    private sendViaApp;
    private sendViaWebhook;
    private splitMessage;
}
//# sourceMappingURL=index.d.ts.map