import type { ChannelName, ConversationContext, MemoryEntry, MemoryScope } from '../utils/types.js';
export declare function resolveMemoryScope(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>): MemoryScope | null;
export declare function setScopedMemoryForContext(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>, key: string, value: string, ttlDays?: number): Promise<void>;
export declare function getScopedMemoryForContext(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>, key: string): Promise<string | null>;
export declare function getAllScopedMemoryForContext(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>): Promise<Record<string, string>>;
export declare function deleteScopedMemoryForContext(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>, key: string): Promise<boolean>;
export declare function searchScopedMemoryForContext(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>, query: string, limit?: number): Promise<MemoryEntry[]>;
export declare function searchScopedSemanticForContext(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>, query: string, limit?: number): Promise<MemoryEntry[]>;
export declare function buildLegacyScope(userId: string, channel: ChannelName): Pick<ConversationContext, 'userId' | 'channel'>;
//# sourceMappingURL=scoped.d.ts.map