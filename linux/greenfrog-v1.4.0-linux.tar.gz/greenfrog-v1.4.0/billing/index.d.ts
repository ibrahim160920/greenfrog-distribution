/**
 * Multi-tenant Billing System - MVP implementation
 * Provides subscription tiers, usage tracking, and billing reports
 */
export interface SubscriptionTier {
    id: string;
    name: string;
    description: string;
    priceUsd: number;
    billingPeriod: 'monthly' | 'yearly';
    features: {
        monthlyTokenLimit: number;
        monthlyCostLimitUsd: number;
        maxWorkspaces: number;
        maxAgents: number;
        maxCustomSkills: number;
        prioritySupport: boolean;
        advancedAnalytics: boolean;
        apiAccess: boolean;
    };
}
export interface BillingRecord {
    id: string;
    userId: string;
    workspaceId: string | null;
    tierId: string;
    amount: number;
    currency: string;
    status: 'pending' | 'paid' | 'failed' | 'refunded';
    billingPeriodStart: Date;
    billingPeriodEnd: Date;
    createdAt: Date;
    paidAt: Date | null;
}
export interface UsageSummary {
    userId: string;
    workspaceId: string | null;
    period: string;
    totalTokens: number;
    totalCostUsd: number;
    apiCalls: number;
    storageBytes: number;
    breakdown: {
        provider: string;
        model: string;
        tokens: number;
        costUsd: number;
    }[];
}
/**
 * Subscription tiers (MVP: hardcoded)
 */
export declare const SUBSCRIPTION_TIERS: SubscriptionTier[];
/**
 * Get all subscription tiers
 */
export declare function getSubscriptionTiers(): SubscriptionTier[];
/**
 * Get a specific tier by ID
 */
export declare function getSubscriptionTier(id: string): SubscriptionTier | null;
/**
 * Calculate usage cost based on token usage
 * This is a simplified pricing model for MVP
 */
export declare function calculateUsageCost(provider: string, model: string, inputTokens: number, outputTokens: number): number;
/**
 * Check if user is within tier limits
 */
export declare function checkTierLimits(tier: SubscriptionTier, usage: {
    monthlyTokens: number;
    monthlyCostUsd: number;
    workspaceCount: number;
    agentCount: number;
    customSkillCount: number;
}): {
    withinLimits: boolean;
    violations: string[];
};
//# sourceMappingURL=index.d.ts.map