import { BaseSkill } from './base.js';
import { getScopedMemoryForContext, setScopedMemoryForContext, } from '../memory/index.js';
import { nanoid } from 'nanoid';
const TODOS_KEY = 'todos';
export class TodoSkill extends BaseSkill {
    definition = {
        name: 'todo',
        description: 'Manage a personal TODO list. Add, complete, list, and delete tasks.',
        category: 'productivity',
        parameters: [
            { name: 'action', type: 'string', required: true, description: 'Action', enum: ['add', 'list', 'done', 'delete', 'clear_done'] },
            { name: 'text', type: 'string', description: 'Task text (for add action)' },
            { name: 'id', type: 'string', description: 'Task ID (for done/delete actions)' },
            { name: 'priority', type: 'string', description: 'Priority level', enum: ['low', 'medium', 'high'], default: 'medium' },
        ],
    };
    async getTodos(ctx) {
        const raw = await getScopedMemoryForContext(ctx, TODOS_KEY);
        return raw ? JSON.parse(raw) : [];
    }
    async saveTodos(ctx, todos) {
        await setScopedMemoryForContext(ctx, TODOS_KEY, JSON.stringify(todos), 365);
    }
    async execute(params, ctx) {
        const todos = await this.getTodos(ctx);
        switch (params.action) {
            case 'add': {
                if (!params.text)
                    return this.err('text is required');
                const item = {
                    id: nanoid(6),
                    text: params.text,
                    done: false,
                    priority: params.priority ?? 'medium',
                    createdAt: new Date().toISOString(),
                };
                todos.push(item);
                await this.saveTodos(ctx, todos);
                return this.text(`✅ Added: \`${item.id}\` **${item.text}** [${item.priority}]`);
            }
            case 'list': {
                const pending = todos.filter((t) => !t.done);
                const done = todos.filter((t) => t.done);
                if (todos.length === 0)
                    return this.text('Your TODO list is empty! Add tasks with the todo skill.');
                const priorityEmoji = { high: '🔴', medium: '🟡', low: '🟢' };
                const pendingLines = pending.map((t) => `${priorityEmoji[t.priority]} \`${t.id}\` ${t.text}`);
                const doneLines = done.slice(0, 5).map((t) => `✅ ~~${t.text}~~`);
                const parts = [`📋 **TODO List** (${pending.length} pending, ${done.length} done)`];
                if (pendingLines.length)
                    parts.push('\n**Pending:**\n' + pendingLines.join('\n'));
                if (doneLines.length)
                    parts.push('\n**Recently done:**\n' + doneLines.join('\n'));
                return this.text(parts.join('\n'));
            }
            case 'done': {
                if (!params.id)
                    return this.err('id is required');
                const idx = todos.findIndex((t) => t.id === params.id);
                if (idx === -1)
                    return this.err(`Task ${params.id} not found`);
                todos[idx].done = true;
                todos[idx].doneAt = new Date().toISOString();
                await this.saveTodos(ctx, todos);
                return this.text(`✅ Completed: **${todos[idx].text}**`);
            }
            case 'delete': {
                if (!params.id)
                    return this.err('id is required');
                const idx = todos.findIndex((t) => t.id === params.id);
                if (idx === -1)
                    return this.err(`Task ${params.id} not found`);
                const [removed] = todos.splice(idx, 1);
                await this.saveTodos(ctx, todos);
                return this.text(`🗑 Deleted: ${removed.text}`);
            }
            case 'clear_done': {
                const before = todos.length;
                const active = todos.filter((t) => !t.done);
                await this.saveTodos(ctx, active);
                return this.text(`🧹 Cleared ${before - active.length} completed tasks`);
            }
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
}
//# sourceMappingURL=todo.js.map