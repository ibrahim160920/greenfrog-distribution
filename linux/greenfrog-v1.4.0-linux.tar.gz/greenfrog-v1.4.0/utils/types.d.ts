export type ChannelName = 'telegram' | 'discord' | 'slack' | 'whatsapp' | 'web' | 'wecom' | 'feishu' | 'dingtalk' | 'teams' | 'line' | 'matrix';
export type MessageRole = 'user' | 'assistant' | 'system' | 'tool';
export type MediaType = 'image' | 'video' | 'audio' | 'file' | 'sticker';
export interface MediaAttachment {
    type: MediaType;
    url?: string;
    data?: Buffer;
    mimeType: string;
    filename?: string;
    size?: number;
}
export interface IncomingMessage {
    id: string;
    channel: ChannelName;
    /** Unique user identifier within the channel */
    userId: string;
    /** Human-readable username */
    username?: string;
    /** Chat/room/group where this message was sent */
    chatId: string;
    chatName?: string;
    text: string;
    attachments?: MediaAttachment[];
    replyToId?: string;
    timestamp: Date;
    raw?: unknown;
    /** Optional channel-level metadata (e.g. progress callbacks for UI) */
    metadata?: Record<string, unknown>;
}
export interface OutgoingMessage {
    text: string;
    channel?: ChannelName;
    chatId?: string;
    attachments?: MediaAttachment[];
    replyToId?: string;
    markdown?: boolean;
}
export interface ConversationMessage {
    role: MessageRole;
    content: string;
    toolCallId?: string;
    toolName?: string;
}
export interface ConversationContext {
    sessionId: string;
    userId: string;
    channel: ChannelName;
    /** The channel-level chat/room/group ID (e.g. Telegram chat_id, Discord channelId) */
    chatId: string;
    /** Persistent workspace/team namespace for enterprise agent operations. */
    workspaceId?: string;
    /** Resolved active agent identity for this conversation turn. */
    agentId?: string;
    history: ConversationMessage[];
    /** Resolved auth role for this user (set by OAuth2/OIDC or config.roles). */
    role?: 'admin' | 'user';
    metadata?: Record<string, unknown>;
}
export interface SkillParameter {
    name: string;
    type: 'string' | 'number' | 'boolean' | 'array' | 'object';
    description: string;
    required?: boolean;
    default?: unknown;
    enum?: unknown[];
}
export interface SkillDefinition {
    name: string;
    description: string;
    parameters: SkillParameter[];
    category: string;
    examples?: string[];
    /** Minimum role required to invoke this skill (default: 'user'). */
    requiredRole?: 'admin' | 'user';
}
export interface SkillCallResult {
    success: boolean;
    data?: unknown;
    text?: string;
    error?: string;
    attachments?: MediaAttachment[];
}
export type SkillHandler = (params: Record<string, unknown>, ctx: ConversationContext) => Promise<SkillCallResult>;
/** A neutral tool-result item, produced by the agent after executing a tool call. */
export interface ToolResultItem {
    /** Matches the ToolCall.id that requested this result */
    id: string;
    /** Tool name — useful for debugging and for providers that need it */
    name: string;
    /** Text output of the tool execution */
    content: string;
}
export interface ProviderMessage {
    role: 'user' | 'assistant' | 'system';
    content: string;
    /**
     * Image attachments for multimodal messages (vision).
     * Each item: { base64: string (data without data-URL prefix), mimeType: 'image/jpeg' | 'image/png' | 'image/gif' | 'image/webp' }
     */
    imageAttachments?: Array<{
        base64: string;
        mimeType: string;
    }>;
    /**
     * Tool results for the turn immediately following an assistant tool-call turn.
     * The agent populates this; each provider translates it into its native format:
     *   - Anthropic: `[{ type: 'tool_result', tool_use_id, content }]`
     *   - OpenAI:    separate `{ role: 'tool', tool_call_id, content }` messages
     *   - Ollama:    best-effort plain text (fallback)
     */
    toolResults?: ToolResultItem[];
    /**
     * Provider-native representation of this message (set on assistant messages
     * that contain tool calls).  The same provider reads it back on the next
     * turn so the API sees a structurally correct conversation history.
     *
     *   - Anthropic: `Anthropic.ContentBlock[]`  (includes `tool_use` blocks)
     *   - OpenAI:    `{ content: string | null; tool_calls?: ChatCompletionMessageToolCall[] }`
     */
    rawContent?: unknown;
}
export interface ProviderTool {
    name: string;
    description: string;
    parameters: {
        type: 'object';
        properties: Record<string, unknown>;
        required?: string[];
    };
}
export interface ProviderRequest {
    messages: ProviderMessage[];
    tools?: ProviderTool[];
    temperature?: number;
    maxTokens?: number;
    systemPrompt?: string;
    model?: string;
    /**
     * Optional AbortSignal.  When aborted, the provider MUST abort the
     * underlying network call (fetch / SDK request) immediately.
     * Set by the agent loop to enforce both the time budget and manual
     * cancellation for mid-call hung provider requests.
     */
    signal?: AbortSignal;
    /**
     * Optional attribution context used by the provider registry to record
     * token usage and enforce budget quotas after each successful call.
     * Not forwarded to the underlying LLM provider.
     */
    usageContext?: {
        userId: string;
        workspaceId?: string | null;
        agentId?: string | null;
        channel?: string | null;
        sessionKey?: string | null;
    };
}
export interface ToolCall {
    id: string;
    name: string;
    arguments: Record<string, unknown>;
}
export interface ProviderResponse {
    content: string;
    toolCalls?: ToolCall[];
    /**
     * Provider-native representation of this response.
     * Must be stored in ProviderMessage.rawContent when building the next
     * request so the conversation history is structurally valid.
     */
    rawContent?: unknown;
    usage?: {
        inputTokens: number;
        outputTokens: number;
    };
    model?: string;
}
export interface TokenUsageRecord {
    id: string;
    userId: string;
    workspaceId: string | null;
    agentId: string | null;
    provider: string;
    model: string;
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    /** Estimated USD cost, null if pricing not known for this provider/model. */
    costUsd: number | null;
    channel: string | null;
    /** Logical session (e.g. heartbeat:{agentId}, chat:{sessionId}). */
    sessionKey: string | null;
    recordedAt: Date;
}
export interface UserQuota {
    /** 'user' | 'workspace' */
    scopeType: 'user' | 'workspace';
    scopeId: string;
    /** Maximum tokens allowed in current calendar month. null = unlimited. */
    monthlyTokenLimit: number | null;
    /** Maximum USD allowed in current calendar month. null = unlimited. */
    monthlyCostLimitUsd: number | null;
    /**
     * 'soft' = log a warning but allow the call through.
     * 'hard' = reject the call with a budget error once limit is exceeded.
     */
    limitBehavior: 'soft' | 'hard';
    updatedAt: Date;
}
export interface TokenUsageSummary {
    scopeType: 'user' | 'workspace' | 'global';
    scopeId: string;
    period: string;
    totalInputTokens: number;
    totalOutputTokens: number;
    totalTokens: number;
    totalCostUsd: number | null;
    callCount: number;
}
/**
 * Events emitted by the agent's streaming API.
 *  - token    : incremental text token from the model
 *  - thinking : a tool call is about to execute (tool name provided)
 *  - done     : streaming complete, full response attached
 *  - error    : error occurred
 */
export type AgentStreamEvent = {
    type: 'token';
    text: string;
} | {
    type: 'thinking';
    tool: string;
} | {
    type: 'done';
    response: OutgoingMessage;
} | {
    type: 'error';
    error: string;
};
export interface MemoryHistoryEntry {
    id: string;
    user_id: string;
    channel: string;
    workspace_id?: string | null;
    agent_id?: string | null;
    key: string;
    old_value: string | null;
    new_value: string;
    source: 'extraction' | 'correction' | 'manual';
    created_at: string;
}
export interface BehavioralRuleHistoryEntry {
    id: string;
    userId: string;
    channel: ChannelName;
    workspaceId?: string | null;
    agentId?: string | null;
    rule: string;
    action: 'insert' | 'update' | 'delete' | 'rollback';
    relatedHistoryId?: string | null;
    oldCategory?: string | null;
    oldConfidence?: number | null;
    oldSource?: string | null;
    oldEvidenceCount?: number | null;
    newCategory?: string | null;
    newConfidence?: number | null;
    newSource?: string | null;
    newEvidenceCount?: number | null;
    createdAt: Date;
}
export interface MemoryEntry {
    id: string;
    userId: string;
    channel: ChannelName;
    workspaceId?: string | null;
    agentId?: string | null;
    key: string;
    value: string;
    embedding?: number[];
    createdAt: Date;
    updatedAt: Date;
    expiresAt?: Date;
}
export interface MemoryScope {
    userId: string;
    channel: ChannelName;
    workspaceId?: string | null;
    agentId?: string | null;
}
export type AgentStatus = 'active' | 'paused';
export type AgentMemoryScopeMode = 'user' | 'workspace' | 'agent';
export interface AgentDefinition {
    id: string;
    name: string;
    description?: string;
    workspaceId: string;
    ownerUserId: string;
    status: AgentStatus;
    memoryScope: AgentMemoryScopeMode;
    provider?: string | null;
    model?: string | null;
    systemPrompt?: string;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
export interface AgentBinding {
    id: string;
    agentId: string;
    workspaceId: string;
    channel: ChannelName;
    userId?: string | null;
    chatId?: string | null;
    createdAt: Date;
    updatedAt: Date;
}
export interface ResolvedAgentBinding {
    agent: AgentDefinition;
    binding: AgentBinding;
}
export type TeamTaskStatus = 'todo' | 'open' | 'proposed' | 'claimed' | 'assigned' | 'in_progress' | 'review_pending' | 'challenge_open' | 'consensus_pending' | 'blocked' | 'escalated' | 'done' | 'cancelled';
export type TeamTaskPriority = 'low' | 'medium' | 'high' | 'critical';
export type TeamTaskReviewStatus = 'not_required' | 'pending' | 'approved' | 'changes_requested';
export type TeamTaskEscalationStatus = 'none' | 'pending' | 'acknowledged';
export type TeamTaskApprovalStatus = 'pending' | 'approved' | 'rejected';
export type TeamNotificationSeverity = 'info' | 'warning' | 'critical';
export type TeamNotificationStatus = 'unread' | 'read' | 'archived';
export type TeamNotificationDeliveryStatus = 'pending' | 'sent' | 'partial' | 'failed';
export interface TeamTask {
    id: string;
    workspaceId: string;
    title: string;
    description?: string;
    status: TeamTaskStatus;
    priority: TeamTaskPriority;
    assignedAgentId?: string | null;
    dependsOnTaskIds?: string[];
    reviewRequired: boolean;
    reviewerAgentId?: string | null;
    reviewStatus: TeamTaskReviewStatus;
    attemptCount: number;
    maxAttempts: number;
    lastAttemptAt?: Date | null;
    escalationStatus: TeamTaskEscalationStatus;
    escalationReason?: string | null;
    humanOwnerUserId?: string | null;
    blockedReason?: string | null;
    createdBy: string;
    resultSummary?: string | null;
    dueAt?: Date | null;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
/**
 * Rules that govern how the Orchestrator mediates agent interactions within a topology.
 * Stored in TeamTopology.metadata['orchestratorRules'] and parsed at runtime.
 */
export interface OrchestratorRules {
    /** How to handle a raised challenge.
     *  'consensus'         = broadcast consensus_request to participants and wait for votes (default)
     *  'supervisor_resolve' = supervisor agent makes an immediate binding decision (faster, cheaper) */
    onConflict: 'consensus' | 'supervisor_resolve';
    /** What happens when a challenge/consensus results in 'changes_requested'.
     *  'block'             = block the task (default)
     *  'reflect_and_retry' = write behavioral rule to challenged agent and retry immediately */
    onConsensusRejected: 'block' | 'reflect_and_retry';
    /** What happens when a task reaches 'done'.
     *  'silent'            = nothing extra (default)
     *  'broadcast_result'  = send result to all topology workers via mailbox */
    onTaskDone: 'silent' | 'broadcast_result';
    /** Model for the Orchestrator's own decisions (supervisor_resolve). Null = workspace default */
    model?: string | null;
    provider?: string | null;
}
export type TeamTopologyModelRouteKey = 'orchestrator' | 'challenge_reflection' | 'success_reflection' | 'reviewer' | 'heartbeat' | 'default_worker';
export interface TeamTopologyModelRoute {
    provider?: string | null;
    model?: string | null;
}
export type TeamTopologyModelRoutes = Partial<Record<TeamTopologyModelRouteKey, TeamTopologyModelRoute>>;
export interface AdaptiveModelPolicy {
    promotedProvider?: string | null;
    promotedModel?: string | null;
    revertProvider?: string | null;
    revertModel?: string | null;
    promoteOnChallengeSuccessRate: number;
    revertOnChallengeSuccessRate: number;
    minChallengedTasks: number;
    cooldownMinutes: number;
}
export interface TeamTopologyStrategySnapshot {
    version: number;
    updatedAt: string;
    orchestratorRules?: OrchestratorRules | null;
    adaptiveModelPolicy?: AdaptiveModelPolicy | null;
    modelRoutes?: TeamTopologyModelRoutes | null;
}
export interface TeamTopologyCandidateRolloutPolicy {
    minTaskCount: number;
    minChallengedTasks: number;
    cooldownMinutes: number;
    stepUpPercent: number;
    stepDownPercent: number;
    maxRolloutPercent: number;
    promoteToStablePercent: number;
    promoteOnChallengeSuccessRate: number;
    rollbackOnChallengeSuccessRate: number;
    rollbackOnConsensusTimeoutRate: number;
    rollbackOnBlockedRate: number;
    healthyConsensusTimeoutRate: number;
    healthyBlockedRate: number;
}
export interface TeamTopologyCandidateRolloutControl {
    enabled: boolean;
    frozen: boolean;
    requirePromotionApproval?: boolean;
    approvalUserIds?: string[] | null;
    freezeReason?: string | null;
    frozenAt?: string | null;
    frozenBy?: string | null;
    updatedAt?: string | null;
    updatedBy?: string | null;
}
export interface TeamTopologyCandidateRolloutAuditEvent {
    action: 'observe' | 'increase' | 'decrease' | 'promote' | 'freeze' | 'resume' | 'manual_promote' | 'approval_requested' | 'approval_approved' | 'approval_rejected';
    at: string;
    actor: 'system' | 'user';
    reason?: string | null;
    fromRolloutPercent?: number | null;
    toRolloutPercent?: number | null;
    candidateVersion?: number | null;
    stableVersion?: number | null;
    metrics?: Record<string, unknown> | null;
}
export interface TeamTopologyCandidateStrategy extends TeamTopologyStrategySnapshot {
    rolloutPercent: number;
}
export interface TeamPolicy {
    workspaceId: string;
    autoDispatch: boolean;
    autoReview: boolean;
    maxAutoRetries: number;
    escalateOnBlocked: boolean;
    escalateOnReviewChanges: boolean;
    escalateOnSlaBreach: boolean;
    autoShareTaskResults: boolean;
    /** Whether challenge-reflection rules are propagated to the whole workspace/team. Default: true. */
    autoPropagateLearnings: boolean;
    /** Whether team-learned rules are promoted/demoted through the rule-library governance pipeline. Default: false. */
    autoGovernLearnedRules: boolean;
    sharedMemoryPrefix: string;
    defaultTaskSlaHours: number;
    defaultHumanOwnerUserId?: string | null;
    approvalReminderAfterMinutes: number;
    approvalEscalationAfterMinutes: number;
    onCallAssignmentTimeoutMinutes: number;
    onCallMaxHandoffsPerTask: number;
    escalationOwnerUserId?: string | null;
    updatedBy: string;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
export interface TeamTaskApproval {
    id: string;
    workspaceId: string;
    taskId: string;
    status: TeamTaskApprovalStatus;
    requestedBy: string;
    requestedForUserId: string;
    reason: string;
    resolutionNotes?: string | null;
    createdAt: Date;
    updatedAt: Date;
    resolvedAt?: Date | null;
}
export interface TeamTemplateTaskBlueprint {
    title: string;
    description?: string;
    priority?: TeamTaskPriority;
    assignedAgentId?: string | null;
    reviewRequired?: boolean;
    reviewerAgentId?: string | null;
    dependsOnTitles?: string[];
    maxAttempts?: number;
}
export interface TeamTemplateVariable {
    name: string;
    description?: string;
    defaultValue?: string | null;
    required?: boolean;
}
export interface TeamTemplate {
    id: string;
    workspaceId: string;
    name: string;
    description?: string;
    department?: string | null;
    role?: string | null;
    goalTemplate?: string | null;
    variables: TeamTemplateVariable[];
    taskBlueprints: TeamTemplateTaskBlueprint[];
    createdBy: string;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
export interface TeamTopology {
    id: string;
    workspaceId: string;
    name: string;
    department?: string | null;
    role?: string | null;
    supervisorAgentId?: string | null;
    workerAgentIds: string[];
    defaultTemplateIds: string[];
    defaultHumanOwnerUserId?: string | null;
    orchestratorRules?: OrchestratorRules | null;
    adaptiveModelPolicy?: AdaptiveModelPolicy | null;
    modelRoutes?: TeamTopologyModelRoutes | null;
    strategyVersion?: number;
    strategyUpdatedAt?: string | null;
    strategyHistory?: TeamTopologyStrategySnapshot[] | null;
    candidateStrategy?: TeamTopologyCandidateStrategy | null;
    candidateRolloutPolicy?: TeamTopologyCandidateRolloutPolicy | null;
    candidateRolloutControl?: TeamTopologyCandidateRolloutControl | null;
    candidateRolloutAudit?: TeamTopologyCandidateRolloutAuditEvent[] | null;
    metadata?: Record<string, unknown>;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface TeamOnCallRotation {
    id: string;
    workspaceId: string;
    name: string;
    enabled: boolean;
    scheduleType: 'daily' | 'weekly';
    anchorDate: Date;
    department?: string | null;
    role?: string | null;
    primaryAgentIds: string[];
    secondaryAgentIds: string[];
    createdBy: string;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
export interface TeamNotification {
    id: string;
    workspaceId: string;
    recipientUserId: string;
    type: 'approval_requested' | 'approval_reminder' | 'approval_escalated' | 'approval_resolved' | 'task_escalated' | 'template_instantiated' | 'topology_instantiated' | 'heartbeat_circuit_opened' | 'heartbeat_recovered' | 'project_evolution_gate_alert' | 'project_evolution_admin_action';
    severity: TeamNotificationSeverity;
    status: TeamNotificationStatus;
    deliveryStatus: TeamNotificationDeliveryStatus;
    deliveryAttemptCount: number;
    title: string;
    message: string;
    taskId?: string | null;
    approvalId?: string | null;
    lastDeliveryError?: string | null;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
    readAt?: Date | null;
    lastDeliveryAttemptAt?: Date | null;
    deliveredAt?: Date | null;
}
export interface TeamNotificationRoute {
    id: string;
    workspaceId: string;
    recipientUserId: string;
    channel: ChannelName;
    chatId: string;
    enabled: boolean;
    createdBy: string;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}
export type TeamMailboxMessageType = 'direct' | 'broadcast' | 'task_event' | 'challenge' | 'consensus_request' | 'consensus_response';
export type TeamMailboxMessageStatus = 'pending' | 'acknowledged' | 'archived' | 'dead_letter';
export interface TeamMailboxMessage {
    id: string;
    workspaceId: string;
    threadId: string;
    dedupeKey?: string | null;
    senderAgentId?: string | null;
    senderUserId?: string | null;
    recipientAgentId?: string | null;
    taskId?: string | null;
    type: TeamMailboxMessageType;
    status: TeamMailboxMessageStatus;
    subject?: string | null;
    message: string;
    metadata?: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
    acknowledgedAt?: Date | null;
}
export interface PluginManifest {
    name: string;
    version: string;
    description: string;
    author?: string;
    skills?: string[];
    channels?: ChannelName[];
    hooks?: string[];
    dependencies?: Record<string, string>;
    minGreenFrogVersion?: string;
    permissions?: ('network' | 'filesystem' | 'shell' | 'memory')[];
}
export type JobStatus = 'active' | 'paused' | 'completed' | 'failed';
export interface ScheduledJob {
    id: string;
    name: string;
    cron: string;
    prompt: string;
    channel: ChannelName;
    chatId: string;
    userId: string;
    status: JobStatus;
    lastRun?: Date;
    nextRun?: Date;
    runCount: number;
    createdAt: Date;
    /**
     * Conditional notification:
     *   'always'        — always push result (default)
     *   'on_alert'      — only push when response contains alert keywords
     *   'if_changed'    — only push when result differs from last run
     *   'never'         — run silently (data collection)
     *   'keyword:XXX'   — only push when response contains XXX
     */
    notifyIf?: string;
    /** Last run result text, used for if_changed comparison */
    lastResult?: string;
}
export type EntityType = 'person' | 'project' | 'task' | 'event' | 'organization' | 'concept';
export interface EntityRelation {
    /** Relation type, e.g. "member_of", "reports_to", "depends_on", "assigned_to" */
    type: string;
    /** Target entity name */
    target: string;
}
export interface Entity {
    id: string;
    userId: string;
    channel: ChannelName;
    type: EntityType;
    /** Canonical name (used as unique key) */
    name: string;
    /** Alternative names / aliases */
    aliases?: string[];
    /** Flexible attributes: role, status, deadline, email, etc. */
    attributes: Record<string, string>;
    /** Relationships to other named entities */
    relations?: EntityRelation[];
    mentionCount: number;
    lastMentioned: Date;
    createdAt: Date;
}
export type PatrolStatus = 'active' | 'paused';
export type PatrolResultStatus = 'ok' | 'error' | 'timeout';
export interface PatrolCheck {
    id: string;
    name: string;
    type: 'http' | 'tcp';
    target: string;
    intervalMin: number;
    method?: string;
    expectedStatus?: number;
    keyword?: string;
    timeoutMs: number;
    alertThreshold: number;
    channel: ChannelName;
    chatId: string;
    userId: string;
    status: PatrolStatus;
    lastCheck?: Date;
    lastStatus?: PatrolResultStatus;
    consecutiveFailures: number;
    createdAt: Date;
}
export interface PatrolResult {
    id: string;
    checkId: string;
    ok: boolean;
    statusCode?: number;
    latencyMs: number;
    error?: string;
    checkedAt: Date;
}
export interface WorkflowStep {
    id: string;
    /** Prompt template — use {{step_id}} to reference previous step outputs */
    prompt: string;
    /** Save this step's result under this key in the run context */
    saveAs?: string;
    /**
     * When to notify user about this step:
     *   'always' | 'on_alert' | 'if_changed' | 'never' | 'keyword:XXX'
     */
    notifyIf?: string;
    /**
     * Stop the workflow if this condition is met:
     *   'on_alert' | 'empty' | 'keyword:XXX'
     */
    stopIf?: string;
}
export interface WorkflowDef {
    id: string;
    name: string;
    description?: string;
    /** Cron expression or 'manual' */
    trigger: string;
    steps: WorkflowStep[];
    channel: ChannelName;
    chatId: string;
    userId: string;
    status: 'active' | 'paused';
    lastRun?: Date;
    runCount: number;
    createdAt: Date;
}
//# sourceMappingURL=types.d.ts.map