import { BaseProvider, type StreamingCall } from './base.js';
import { AnthropicProvider } from './anthropic.js';
import { OpenAIProvider } from './openai.js';
import { OllamaProvider } from './ollama.js';
import { GeminiProvider } from './gemini.js';
import { MistralProvider, GroqProvider, DeepSeekProvider, QwenProvider, KimiProvider, GLMProvider, GeminiRelayProvider } from './compat.js';
import type { ProviderRequest, ProviderResponse } from '../utils/types.js';
export type UsageContext = {
    userId: string;
    workspaceId?: string | null;
    agentId?: string | null;
    channel?: string | null;
    sessionKey?: string | null;
};
export declare function getQuotaReservationOverview(): {
    activeReservations: number;
    reservedScopes: number;
    reservedTokens: number;
    reservedCostUsd: number;
};
export declare class ProviderRegistry {
    private providers;
    private defaultProviderName;
    /** Total number of times a request fell back to a non-preferred provider (chat). */
    private _fallbackCount;
    /** Total number of times a streaming request fell back to a non-preferred provider. */
    private _streamFallbackCount;
    /**
     * Optional callback invoked whenever a request falls back to a non-preferred
     * provider.  Register this in index.ts to send admin notifications.
     * Signature: (primary, used, requestLabel) => void
     */
    onFallback?: (primary: string, used: string, requestLabel?: string) => void;
    /** Total provider fallback count (chat + stream). */
    getFallbackCount(): number;
    constructor(autoInit?: boolean);
    /** Returns an empty registry with no pre-registered providers (useful for unit tests). */
    static createEmpty(): ProviderRegistry;
    private initialize;
    /**
     * Rebuild the registry from the current live config.
     * Called after PUT /api/config so provider changes take effect immediately
     * without a process restart.
     */
    reload(): void;
    register(provider: BaseProvider): void;
    /** Returns registered providers with their default model names. */
    listMeta(): Array<{
        name: string;
        defaultModel: string;
    }>;
    get(name?: string): BaseProvider;
    /**
     * 带自动 fallback + 全局超时的 chat 调用。
     * 主 provider 失败时，按顺序尝试备用 provider。
     * 整个链路若超过 PROVIDER_CHAIN_TIMEOUT_MS 仍无响应，抛出超时错误。
     */
    chatWithFallback(request: ProviderRequest, preferredProvider?: string): Promise<ProviderResponse>;
    private _chatFallbackChain;
    /**
     * Like chatWithFallback but returns a StreamingCall.
     * Falls back to a non-streaming wrapper if the preferred provider
     * doesn't implement chatStream.
     */
    chatStreamWithFallback(request: ProviderRequest, preferredProvider?: string): Promise<StreamingCall>;
    list(): string[];
    setDefault(name: string): void;
}
export declare const providerRegistry: ProviderRegistry;
export { BaseProvider, AnthropicProvider, OpenAIProvider, OllamaProvider, GeminiProvider, MistralProvider, GroqProvider, DeepSeekProvider, QwenProvider, KimiProvider, GLMProvider, GeminiRelayProvider };
//# sourceMappingURL=index.d.ts.map