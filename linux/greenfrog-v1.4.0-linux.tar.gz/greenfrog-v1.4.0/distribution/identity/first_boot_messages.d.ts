/**
 * first_boot_messages.ts — i18n message set for the first-boot enrollment flow.
 *
 * Provides typed access to all messages shown during enrollment states.
 * Locale defaults to system locale detection; falls back to 'en'.
 */
export interface FirstBootMessages {
    /** Shown while generating installId + enrollmentKey */
    generating: string;
    /** Title for the first-boot screen */
    title: string;
    /** Subtitle for the first-boot screen */
    subtitle: string;
    /** Label for the enrollment key display field */
    enrollmentKeyLabel: string;
    /** Hint text below enrollment key field */
    enrollmentKeyHint: string;
    /** Shown after the key has been copied to clipboard */
    enrollmentKeyCopied: string;
    /** Button label for the submit/register action */
    submitLabel: string;
    /** Shown while the POST request is in-flight */
    submitting: string;
    /** Shown on successful enrollment */
    success: string;
    /** Shown if already enrolled */
    alreadyEnrolled: string;
    /** Credential saved confirmation */
    credentialSaved: string;
    /** Error: network failure */
    errorNetwork: string;
    /** Error: server failure */
    errorServer: string;
    /** Error: generic */
    errorGeneric: string;
}
/**
 * Return the typed first-boot message set for the given locale.
 * If no locale is provided, the system locale is detected automatically.
 *
 * @param locale  BCP-47 locale tag, e.g. 'en', 'zh-CN', 'ja'. Optional.
 */
export declare function getFirstBootMessages(locale?: string): FirstBootMessages;
/**
 * Return a credential location message with the path interpolated.
 * Separate from the main set because it requires a variable.
 */
export declare function getCredentialLocationMessage(storagePath: string, locale?: string): string;
//# sourceMappingURL=first_boot_messages.d.ts.map