import { memoryStore } from '../memory/store.js';
function applyAgentScope(agent) {
    switch (agent.memoryScope) {
        case 'workspace':
            return { workspaceId: agent.workspaceId, agentId: undefined };
        case 'agent':
            return { workspaceId: agent.workspaceId, agentId: agent.id };
        case 'user':
        default:
            return { workspaceId: undefined, agentId: undefined };
    }
}
export async function resolveConversationAgentIdentity(msg) {
    const metadata = msg.metadata ?? {};
    const requestedAgentId = typeof metadata['agentId'] === 'string' ? metadata['agentId'].trim() : '';
    const requestedWorkspaceId = typeof metadata['workspaceId'] === 'string' ? metadata['workspaceId'].trim() : '';
    if (requestedAgentId) {
        const agent = await memoryStore.getAgent(requestedAgentId);
        if (agent)
            return { ...applyAgentScope(agent), agent };
        return {
            agentId: requestedAgentId || undefined,
            workspaceId: requestedWorkspaceId || undefined,
        };
    }
    if (requestedWorkspaceId) {
        return { workspaceId: requestedWorkspaceId };
    }
    const resolved = await memoryStore.resolveAgentBinding({
        channel: msg.channel,
        userId: msg.userId,
        chatId: msg.chatId,
    });
    if (!resolved)
        return {};
    return {
        ...applyAgentScope(resolved.agent),
        agent: resolved.agent,
    };
}
export function deriveSpecialistContext(ctx, specialistName) {
    const baseWorkspaceId = ctx.workspaceId ?? ctx.agentId ?? `session:${ctx.sessionId}`;
    const derivedAgentId = ctx.agentId
        ? `${ctx.agentId}:${specialistName}`
        : `specialist:${baseWorkspaceId}:${specialistName}`;
    return {
        ...ctx,
        workspaceId: baseWorkspaceId,
        agentId: derivedAgentId,
        metadata: {
            ...ctx.metadata,
            specialist: specialistName,
            parentAgentId: ctx.agentId,
        },
    };
}
//# sourceMappingURL=identity.js.map