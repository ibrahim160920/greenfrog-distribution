export interface ProjectUpgradeConfig {
    enabled: boolean;
    repoPath: string;
    manifestPath: string;
    remote: string;
    baseBranch: string;
    autoApply: boolean;
    requireCleanWorkingTree: boolean;
    installCommand?: string;
    buildCommand?: string;
    restartOnApply: boolean;
    approvalWindowStartHourUtc?: number;
    approvalWindowEndHourUtc?: number;
    approvedWeekdaysUtc?: number[];
    rolloutPercentage?: number;
    rolloutSeed?: string;
    healthCheckCommands?: string[];
    minHealthChecksPassing?: number;
    verificationCommands?: string[];
    minVerificationChecksPassing?: number;
    autoRollbackOnVerificationFailure?: boolean;
    respectAutomationPolicies?: boolean;
}
export interface ProjectUpgradeCheckResult {
    enabled: boolean;
    available: boolean;
    currentVersion: string;
    targetVersion: string | null;
    currentGitSha: string | null;
    targetGitSha: string | null;
    source: 'git_remote' | 'local_file' | 'none';
    skippedReason: string | null;
}
export interface ProjectUpgradeApplyResult extends ProjectUpgradeCheckResult {
    applied: boolean;
    commandsRun: string[];
    rolledBack: boolean;
    rollbackReason: string | null;
    rollbackCommandsRun: string[];
}
export declare function checkForProjectUpgrade(partial?: Partial<ProjectUpgradeConfig>): Promise<ProjectUpgradeCheckResult>;
export declare function applyProjectUpgrade(partial?: Partial<ProjectUpgradeConfig>): Promise<ProjectUpgradeApplyResult>;
//# sourceMappingURL=project_upgrade.d.ts.map