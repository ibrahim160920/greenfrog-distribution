/**
 * manifest.ts — Release manifest types and schema validation.
 *
 * The release manifest is a signed JSON document that describes an inheritance
 * bundle available for download. The child fetches the manifest, verifies its
 * signature, and only then downloads and applies the bundle.
 */
import crypto from 'node:crypto';
/** Schema version — increment when breaking changes are made. */
export const MANIFEST_VERSION = 1;
// ── Validation ─────────────────────────────────────────────────────────────────
/** Validate that a parsed object conforms to ReleaseManifest shape. */
export function validateManifest(obj) {
    if (!obj || typeof obj !== 'object')
        return false;
    const m = obj;
    return (m['manifestVersion'] === MANIFEST_VERSION &&
        typeof m['releaseId'] === 'string' &&
        typeof m['version'] === 'string' &&
        typeof m['releasedAt'] === 'string' &&
        typeof m['compatibilityConstraint'] === 'string' &&
        m['bundleType'] === 'mother_promoted' &&
        typeof m['bundleHash'] === 'string' && m['bundleHash'].length === 64 &&
        typeof m['bundleSize'] === 'number' &&
        typeof m['downloadUrl'] === 'string' &&
        typeof m['signature'] === 'string');
}
/**
 * Compute the canonical manifest digest for signing/verification.
 * Digest = SHA-256(JSON of manifest without the signature field).
 */
export function computeManifestDigest(manifest) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { signature: _sig, ...withoutSig } = manifest;
    const canonical = JSON.stringify(withoutSig, Object.keys(withoutSig).sort());
    return crypto.createHash('sha256').update(canonical).digest();
}
/**
 * Compute SHA-256 hash of bundle content.
 * Used to verify download integrity.
 */
export function computeBundleHash(content) {
    return crypto.createHash('sha256').update(content).digest('hex');
}
//# sourceMappingURL=manifest.js.map