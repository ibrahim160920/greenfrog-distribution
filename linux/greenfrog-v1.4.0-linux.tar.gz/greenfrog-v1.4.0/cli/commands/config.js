import chalk from 'chalk';
import { config } from '../../config/index.js';
export async function manageConfig(opts) {
    if (opts.set) {
        const [key, ...valueParts] = opts.set.split('=');
        const value = valueParts.join('=');
        if (!key || !value) {
            console.error(chalk.red('Invalid format. Use: --set key=value'));
            process.exit(1);
        }
        // Simple nested key support (e.g., providers.anthropic.apiKey)
        console.log(chalk.yellow(`Config update via CLI is limited. Edit ~/.greenfrog/config.yaml or .env directly.`));
        return;
    }
    // Show config (redact secrets)
    const safeConfig = JSON.parse(JSON.stringify(config));
    if (safeConfig.providers.anthropic?.apiKey) {
        safeConfig.providers.anthropic.apiKey = safeConfig.providers.anthropic.apiKey.slice(0, 10) + '...';
    }
    if (safeConfig.providers.openai?.apiKey) {
        safeConfig.providers.openai.apiKey = safeConfig.providers.openai.apiKey.slice(0, 10) + '...';
    }
    if (safeConfig.channels.telegram?.token) {
        safeConfig.channels.telegram.token = safeConfig.channels.telegram.token.slice(0, 10) + '...';
    }
    if (safeConfig.channels.discord?.token) {
        safeConfig.channels.discord.token = safeConfig.channels.discord.token.slice(0, 10) + '...';
    }
    console.log(chalk.bold('\n🐸 GreenFrog Configuration:\n'));
    console.log(`  ${chalk.cyan('Data directory:')} ${safeConfig.dataDir}`);
    console.log(`  ${chalk.cyan('Default provider:')} ${safeConfig.defaultProvider}`);
    console.log(`  ${chalk.cyan('Default model:')} ${safeConfig.defaultModel}`);
    console.log(`  ${chalk.cyan('Gateway:')} ws://${safeConfig.gateway.host}:${safeConfig.gateway.port}`);
    console.log(`  ${chalk.cyan('Web UI:')} http://${safeConfig.webui.host}:${safeConfig.webui.port}`);
    console.log(chalk.bold('\n  Providers:'));
    if (safeConfig.providers.anthropic)
        console.log(`    ${chalk.green('✓')} Anthropic (${safeConfig.providers.anthropic.apiKey})`);
    if (safeConfig.providers.openai)
        console.log(`    ${chalk.green('✓')} OpenAI (${safeConfig.providers.openai.apiKey})`);
    if (safeConfig.providers.ollama)
        console.log(`    ${chalk.green('✓')} Ollama (${safeConfig.providers.ollama.baseUrl})`);
    console.log(chalk.bold('\n  Channels:'));
    for (const [name, channelCfg] of Object.entries(safeConfig.channels)) {
        if (channelCfg && channelCfg.enabled) {
            console.log(`    ${chalk.green('✓')} ${name}`);
        }
    }
    console.log(chalk.bold('\n  Skills APIs:'));
    if (safeConfig.skills.weather)
        console.log(`    ${chalk.green('✓')} Weather`);
    if (safeConfig.skills.github)
        console.log(`    ${chalk.green('✓')} GitHub`);
    if (safeConfig.skills.news)
        console.log(`    ${chalk.green('✓')} News`);
    if (safeConfig.skills.search)
        console.log(`    ${chalk.green('✓')} Web Search`);
    console.log();
}
//# sourceMappingURL=config.js.map