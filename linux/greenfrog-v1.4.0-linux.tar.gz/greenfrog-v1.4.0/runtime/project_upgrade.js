import { existsSync, readFileSync } from 'fs';
import { isAbsolute, resolve } from 'path';
import { spawnSync } from 'child_process';
import { createLogger } from '../utils/logger.js';
import { writeEvolutionOperationStatus } from '../memory/evolution_operation_status.js';
import { recordProjectEvolutionIncident } from '../memory/project_evolution_incidents.js';
import { evaluateApprovalWindow, evaluateHealthChecks, evaluateRollout } from './automation_policy.js';
import { evaluateProjectEvolutionUpgradeAutomationGate } from '../memory/project_evolution_automation_gate.js';
const log = createLogger('project-upgrade');
function runGit(repoPath, args) {
    const result = spawnSync('git', args, {
        cwd: repoPath,
        encoding: 'utf8',
        timeout: 60_000,
        stdio: ['ignore', 'pipe', 'pipe'],
    });
    if (result.error)
        throw result.error;
    if (result.status !== 0) {
        throw new Error((result.stderr ?? result.stdout ?? '').trim() || `git exited with code ${result.status}`);
    }
    return (result.stdout ?? '').trim();
}
function tryRunGit(repoPath, args) {
    try {
        return runGit(repoPath, args);
    }
    catch {
        return null;
    }
}
function parseSimpleSemver(version) {
    const match = version.trim().match(/^(\d+)\.(\d+)\.(\d+)$/);
    if (!match)
        return null;
    return [Number(match[1]), Number(match[2]), Number(match[3])];
}
function compareSemver(left, right) {
    const l = parseSimpleSemver(left);
    const r = parseSimpleSemver(right);
    if (!l || !r)
        return left.localeCompare(right);
    for (let index = 0; index < 3; index += 1) {
        if (l[index] > r[index])
            return 1;
        if (l[index] < r[index])
            return -1;
    }
    return 0;
}
function getCurrentVersion(repoPath) {
    const packageFile = resolve(repoPath, 'package.json');
    if (!existsSync(packageFile))
        return '0.0.0';
    const raw = JSON.parse(readFileSync(packageFile, 'utf8'));
    return typeof raw.version === 'string' ? raw.version : '0.0.0';
}
function loadRemoteManifest(repoPath, remote, baseBranch, manifestPath) {
    const manifest = tryRunGit(repoPath, ['show', `${remote}/${baseBranch}:${manifestPath.replace(/\\/g, '/')}`]);
    if (!manifest)
        return null;
    return JSON.parse(manifest);
}
function loadLocalManifest(repoPath, manifestPath) {
    const filePath = resolve(repoPath, manifestPath);
    if (!existsSync(filePath))
        return null;
    return JSON.parse(readFileSync(filePath, 'utf8'));
}
function getCurrentBranch(repoPath) {
    return tryRunGit(repoPath, ['symbolic-ref', '--quiet', '--short', 'HEAD']);
}
function workingTreeClean(repoPath) {
    const status = tryRunGit(repoPath, ['status', '--porcelain']) ?? '';
    return status.trim().length === 0;
}
function runShellCommand(command, repoPath) {
    const result = spawnSync(command, {
        cwd: repoPath,
        encoding: 'utf8',
        timeout: 10 * 60_000,
        stdio: 'inherit',
        shell: true,
    });
    if (result.error)
        throw result.error;
    if (result.status !== 0) {
        throw new Error(`Command failed (${result.status}): ${command}`);
    }
}
function buildDefaultConfig(partial) {
    return {
        enabled: false,
        repoPath: '',
        manifestPath: '.greenfrog/releases/latest.json',
        remote: 'origin',
        baseBranch: 'main',
        autoApply: false,
        requireCleanWorkingTree: true,
        restartOnApply: true,
        rolloutPercentage: 100,
        healthCheckCommands: [],
        minHealthChecksPassing: 0,
        verificationCommands: [],
        minVerificationChecksPassing: 0,
        autoRollbackOnVerificationFailure: false,
        respectAutomationPolicies: false,
        ...partial,
    };
}
function getCurrentHead(repoPath) {
    return tryRunGit(repoPath, ['rev-parse', 'HEAD']);
}
function rollbackProjectUpgrade(repoPath, previousHead, config) {
    const rollbackCommandsRun = [];
    runGit(repoPath, ['reset', '--hard', previousHead]);
    rollbackCommandsRun.push(`git reset --hard ${previousHead}`);
    if (config.installCommand) {
        runShellCommand(config.installCommand, repoPath);
        rollbackCommandsRun.push(config.installCommand);
    }
    if (config.buildCommand) {
        runShellCommand(config.buildCommand, repoPath);
        rollbackCommandsRun.push(config.buildCommand);
    }
    return rollbackCommandsRun;
}
export async function checkForProjectUpgrade(partial) {
    const config = buildDefaultConfig(partial);
    const repoRoot = config.repoPath
        ? (isAbsolute(config.repoPath) ? config.repoPath : resolve(process.cwd(), config.repoPath))
        : null;
    if (!config.enabled) {
        const result = {
            enabled: false,
            available: false,
            currentVersion: '0.0.0',
            targetVersion: null,
            currentGitSha: null,
            targetGitSha: null,
            source: 'none',
            skippedReason: 'project upgrade disabled',
        };
        if (repoRoot) {
            writeEvolutionOperationStatus(repoRoot, 'project_upgrade_check', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    available: result.available,
                    currentVersion: result.currentVersion,
                    targetVersion: result.targetVersion,
                    source: result.source,
                },
            });
        }
        return result;
    }
    if (!config.repoPath) {
        return {
            enabled: true,
            available: false,
            currentVersion: '0.0.0',
            targetVersion: null,
            currentGitSha: null,
            targetGitSha: null,
            source: 'none',
            skippedReason: 'repoPath is required for project upgrade',
        };
    }
    const resolvedRepoRoot = repoRoot;
    if (!resolvedRepoRoot) {
        return {
            enabled: true,
            available: false,
            currentVersion: '0.0.0',
            targetVersion: null,
            currentGitSha: null,
            targetGitSha: null,
            source: 'none',
            skippedReason: 'repoPath is required for project upgrade',
        };
    }
    try {
        const currentVersion = getCurrentVersion(resolvedRepoRoot);
        const currentGitSha = tryRunGit(resolvedRepoRoot, ['rev-parse', 'HEAD']);
        tryRunGit(resolvedRepoRoot, ['fetch', config.remote, config.baseBranch]);
        const remoteManifest = loadRemoteManifest(resolvedRepoRoot, config.remote, config.baseBranch, config.manifestPath);
        const localManifest = remoteManifest ? null : loadLocalManifest(resolvedRepoRoot, config.manifestPath);
        const manifest = remoteManifest ?? localManifest;
        const source = remoteManifest ? 'git_remote' : localManifest ? 'local_file' : 'none';
        if (!manifest) {
            const result = {
                enabled: true,
                available: false,
                currentVersion,
                targetVersion: null,
                currentGitSha,
                targetGitSha: null,
                source,
                skippedReason: 'release manifest not found',
            };
            writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_check', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    available: result.available,
                    currentVersion: result.currentVersion,
                    targetVersion: result.targetVersion,
                    source: result.source,
                },
            });
            return result;
        }
        const targetVersion = typeof manifest.version === 'string' ? manifest.version : null;
        const targetGitSha = typeof manifest.gitSha === 'string' ? manifest.gitSha : null;
        const available = ((targetVersion ? compareSemver(targetVersion, currentVersion) > 0 : false)
            || (targetGitSha ? targetGitSha !== currentGitSha : false));
        const result = {
            enabled: true,
            available,
            currentVersion,
            targetVersion,
            currentGitSha,
            targetGitSha,
            source,
            skippedReason: available ? null : 'already up to date',
        };
        writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_check', {
            status: 'success',
            skippedReason: result.skippedReason,
            summary: {
                available: result.available,
                currentVersion: result.currentVersion,
                targetVersion: result.targetVersion,
                currentGitSha: result.currentGitSha,
                targetGitSha: result.targetGitSha,
                source: result.source,
            },
        });
        return result;
    }
    catch (err) {
        writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_check', {
            status: 'error',
            skippedReason: err instanceof Error ? err.message : String(err),
        });
        throw err;
    }
}
export async function applyProjectUpgrade(partial) {
    const config = buildDefaultConfig(partial);
    const repoRoot = config.repoPath
        ? (isAbsolute(config.repoPath) ? config.repoPath : resolve(process.cwd(), config.repoPath))
        : null;
    const resolvedRepoRoot = repoRoot;
    try {
        const check = await checkForProjectUpgrade(config);
        if (!check.enabled || !check.available) {
            const result = {
                ...check,
                applied: false,
                commandsRun: [],
                rolledBack: false,
                rollbackReason: null,
                rollbackCommandsRun: [],
            };
            if (resolvedRepoRoot) {
                writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                    status: 'skipped',
                    skippedReason: result.skippedReason,
                    summary: {
                        applied: result.applied,
                        available: result.available,
                        currentVersion: result.currentVersion,
                        targetVersion: result.targetVersion,
                        commandsRun: result.commandsRun,
                        rolledBack: result.rolledBack,
                    },
                });
            }
            return result;
        }
        if (!resolvedRepoRoot) {
            return {
                ...check,
                applied: false,
                commandsRun: [],
                rolledBack: false,
                rollbackReason: null,
                rollbackCommandsRun: [],
                skippedReason: 'repoPath is required for project upgrade',
            };
        }
        if (config.requireCleanWorkingTree && !workingTreeClean(resolvedRepoRoot)) {
            const result = {
                ...check,
                applied: false,
                commandsRun: [],
                rolledBack: false,
                rollbackReason: null,
                rollbackCommandsRun: [],
                skippedReason: 'working tree is not clean; refusing auto-upgrade',
            };
            writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    applied: result.applied,
                    available: result.available,
                    currentVersion: result.currentVersion,
                    targetVersion: result.targetVersion,
                    commandsRun: result.commandsRun,
                    rolledBack: result.rolledBack,
                },
            });
            return result;
        }
        if (config.respectAutomationPolicies) {
            const approvalWindow = evaluateApprovalWindow({
                startHourUtc: config.approvalWindowStartHourUtc,
                endHourUtc: config.approvalWindowEndHourUtc,
                approvedWeekdaysUtc: config.approvedWeekdaysUtc,
            });
            if (!approvalWindow.allowed) {
                const result = {
                    ...check,
                    applied: false,
                    commandsRun: [],
                    rolledBack: false,
                    rollbackReason: null,
                    rollbackCommandsRun: [],
                    skippedReason: approvalWindow.reason,
                };
                writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                    status: 'skipped',
                    skippedReason: result.skippedReason,
                    summary: {
                        applied: result.applied,
                        approvalWindow,
                    },
                });
                return result;
            }
            if (config.autoApply) {
                const rollout = evaluateRollout({
                    percentage: config.rolloutPercentage,
                    seed: config.rolloutSeed,
                }, resolvedRepoRoot);
                if (!rollout.allowed) {
                    const result = {
                        ...check,
                        applied: false,
                        commandsRun: [],
                        rolledBack: false,
                        rollbackReason: null,
                        rollbackCommandsRun: [],
                        skippedReason: rollout.reason,
                    };
                    writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                        status: 'skipped',
                        skippedReason: result.skippedReason,
                        summary: {
                            applied: result.applied,
                            rollout,
                        },
                    });
                    return result;
                }
            }
            const healthChecks = await evaluateHealthChecks({
                commands: config.healthCheckCommands,
                minPassing: config.minHealthChecksPassing,
            }, (command) => runShellCommand(command, resolvedRepoRoot));
            if (!healthChecks.allowed) {
                const result = {
                    ...check,
                    applied: false,
                    commandsRun: [],
                    rolledBack: false,
                    rollbackReason: null,
                    rollbackCommandsRun: [],
                    skippedReason: healthChecks.reason,
                };
                writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                    status: 'skipped',
                    skippedReason: result.skippedReason,
                    summary: {
                        applied: result.applied,
                        healthChecks: {
                            total: healthChecks.total,
                            passed: healthChecks.passed,
                            required: healthChecks.required,
                        },
                    },
                });
                return result;
            }
            const manifest = loadRemoteManifest(resolvedRepoRoot, config.remote, config.baseBranch, config.manifestPath)
                ?? loadLocalManifest(resolvedRepoRoot, config.manifestPath);
            const automationGate = evaluateProjectEvolutionUpgradeAutomationGate({
                repoPath: resolvedRepoRoot,
                currentBranch: getCurrentBranch(resolvedRepoRoot),
                manifest: manifest,
            });
            if (!automationGate.allowed) {
                const result = {
                    ...check,
                    applied: false,
                    commandsRun: [],
                    rolledBack: false,
                    rollbackReason: null,
                    rollbackCommandsRun: [],
                    skippedReason: automationGate.reason,
                };
                writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                    status: 'skipped',
                    skippedReason: result.skippedReason,
                    summary: {
                        applied: result.applied,
                        automationGate,
                    },
                });
                return result;
            }
        }
        const commandsRun = [];
        const previousHead = getCurrentHead(resolvedRepoRoot);
        runGit(resolvedRepoRoot, ['pull', '--ff-only', config.remote, config.baseBranch]);
        if (config.installCommand) {
            runShellCommand(config.installCommand, resolvedRepoRoot);
            commandsRun.push(config.installCommand);
        }
        if (config.buildCommand) {
            runShellCommand(config.buildCommand, resolvedRepoRoot);
            commandsRun.push(config.buildCommand);
        }
        const verification = await evaluateHealthChecks({
            commands: config.verificationCommands,
            minPassing: config.minVerificationChecksPassing,
        }, (command) => runShellCommand(command, resolvedRepoRoot));
        if (!verification.allowed) {
            const rollbackReason = verification.reason;
            const rollbackCommandsRun = (config.autoRollbackOnVerificationFailure && previousHead
                ? rollbackProjectUpgrade(resolvedRepoRoot, previousHead, config)
                : []);
            if (rollbackCommandsRun.length > 0) {
                recordProjectEvolutionIncident(resolvedRepoRoot, {
                    id: `upgrade-rollback:${new Date().toISOString()}:${check.targetVersion ?? 'unknown'}`,
                    kind: 'upgrade_rollback',
                    priority: 'critical',
                    createdAt: new Date().toISOString(),
                    title: `Automatic rollback after failed upgrade verification (${check.targetVersion ?? 'unknown'})`,
                    summary: rollbackReason ?? 'post-upgrade verification failed',
                    source: 'project_upgrade',
                    details: {
                        currentVersion: check.currentVersion,
                        targetVersion: check.targetVersion,
                        currentGitSha: check.currentGitSha,
                        targetGitSha: check.targetGitSha,
                        commandsRun,
                        rollbackCommandsRun,
                        verification: {
                            total: verification.total,
                            passed: verification.passed,
                            required: verification.required,
                        },
                    },
                });
            }
            const revertedState = previousHead ? await checkForProjectUpgrade(config) : check;
            const result = {
                ...revertedState,
                applied: false,
                commandsRun,
                rolledBack: rollbackCommandsRun.length > 0,
                rollbackReason,
                rollbackCommandsRun,
                skippedReason: rollbackReason,
            };
            writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                status: result.rolledBack ? 'success' : 'error',
                skippedReason: result.skippedReason,
                summary: {
                    applied: result.applied,
                    available: result.available,
                    currentVersion: result.currentVersion,
                    targetVersion: result.targetVersion,
                    commandsRun: result.commandsRun,
                    rolledBack: result.rolledBack,
                    rollbackReason: result.rollbackReason,
                    rollbackCommandsRun: result.rollbackCommandsRun,
                    verification: {
                        total: verification.total,
                        passed: verification.passed,
                        required: verification.required,
                    },
                },
            });
            return result;
        }
        const appliedResult = await checkForProjectUpgrade(config);
        log.info({
            currentVersion: check.currentVersion,
            targetVersion: check.targetVersion,
            commandsRun,
            restartOnApply: config.restartOnApply,
        }, 'Project upgrade applied');
        const result = {
            ...appliedResult,
            applied: true,
            commandsRun,
            rolledBack: false,
            rollbackReason: null,
            rollbackCommandsRun: [],
            skippedReason: null,
        };
        writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
            status: 'success',
            skippedReason: result.skippedReason,
            summary: {
                applied: result.applied,
                available: result.available,
                currentVersion: result.currentVersion,
                targetVersion: result.targetVersion,
                commandsRun: result.commandsRun,
                rolledBack: result.rolledBack,
                rollbackReason: result.rollbackReason,
                rollbackCommandsRun: result.rollbackCommandsRun,
                verification: {
                    total: verification.total,
                    passed: verification.passed,
                    required: verification.required,
                },
                rollout: config.respectAutomationPolicies && config.autoApply ? evaluateRollout({
                    percentage: config.rolloutPercentage,
                    seed: config.rolloutSeed,
                }, resolvedRepoRoot) : null,
            },
        });
        return result;
    }
    catch (err) {
        if (resolvedRepoRoot) {
            writeEvolutionOperationStatus(resolvedRepoRoot, 'project_upgrade_apply', {
                status: 'error',
                skippedReason: err instanceof Error ? err.message : String(err),
            });
        }
        throw err;
    }
}
//# sourceMappingURL=project_upgrade.js.map