import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class GitOpsSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    /**
     * Run git with an explicit arg list — avoids shell injection entirely.
     * spawnSync does NOT invoke a shell; each element is passed verbatim to the OS.
     */
    private git;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=git_ops.d.ts.map