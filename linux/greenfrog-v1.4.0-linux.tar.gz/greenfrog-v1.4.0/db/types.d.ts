/**
 * Async database adapter interface.
 * Both SQLiteMemoryStore and PostgresMemoryStore implement this.
 */
import type { AdaptiveModelPolicy, MemoryEntry, MemoryHistoryEntry, BehavioralRuleHistoryEntry, ChannelName, ConversationMessage, PatrolCheck, PatrolResult, WorkflowDef, Entity, EntityType, ScheduledJob, JobStatus, AgentDefinition, AgentBinding, MemoryScope, OrchestratorRules, ResolvedAgentBinding, TeamNotification, TeamNotificationDeliveryStatus, TeamNotificationRoute, TeamNotificationSeverity, TeamNotificationStatus, TeamOnCallRotation, TeamPolicy, TeamTask, TeamTaskApproval, TeamTaskApprovalStatus, TeamTaskPriority, TeamTaskStatus, TeamTemplate, TeamTopology, TeamTopologyModelRoutes, TokenUsageRecord, TokenUsageSummary, UserQuota } from '../utils/types.js';
export interface IMemoryStore {
    init(): Promise<void>;
    close(): Promise<void>;
    setMemory(userId: string, channel: ChannelName, key: string, value: string, ttlDays?: number): Promise<void>;
    getMemory(userId: string, channel: ChannelName, key: string): Promise<string | null>;
    getAllMemory(userId: string, channel: ChannelName): Promise<Record<string, string>>;
    deleteMemory(userId: string, channel: ChannelName, key: string): Promise<boolean>;
    setScopedMemory(scope: MemoryScope, key: string, value: string, ttlDays?: number): Promise<void>;
    getScopedMemory(scope: MemoryScope, key: string): Promise<string | null>;
    getAllScopedMemory(scope: MemoryScope): Promise<Record<string, string>>;
    deleteScopedMemory(scope: MemoryScope, key: string): Promise<boolean>;
    searchScopedMemory(scope: MemoryScope, query: string, limit?: number): Promise<MemoryEntry[]>;
    searchScopedSemantic(scope: MemoryScope, query: string, limit?: number): Promise<MemoryEntry[]>;
    searchSemantic(userId: string, channel: ChannelName, query: string, limit?: number): Promise<MemoryEntry[]>;
    warmQueryEmbedding(query: string): Promise<void>;
    searchMemory(userId: string, channel: ChannelName, query: string, limit?: number): Promise<MemoryEntry[]>;
    getCorrectionCount(userId: string, channel: string, windowMs: number): Promise<number>;
    createAgent(agent: {
        name: string;
        description?: string;
        workspaceId: string;
        ownerUserId: string;
        status?: 'active' | 'paused';
        memoryScope?: 'user' | 'workspace' | 'agent';
        provider?: string | null;
        model?: string | null;
        systemPrompt?: string;
        metadata?: Record<string, unknown>;
    }): Promise<AgentDefinition>;
    getAgent(id: string): Promise<AgentDefinition | null>;
    listAgents(workspaceId?: string): Promise<AgentDefinition[]>;
    updateAgent(id: string, updates: Partial<{
        name: string;
        description: string;
        status: 'active' | 'paused';
        memoryScope: 'user' | 'workspace' | 'agent';
        provider: string | null;
        model: string | null;
        systemPrompt: string;
        metadata: Record<string, unknown>;
    }>): Promise<AgentDefinition | null>;
    deleteAgent(id: string): Promise<boolean>;
    createAgentBinding(binding: {
        agentId: string;
        workspaceId: string;
        channel: ChannelName;
        userId?: string | null;
        chatId?: string | null;
    }): Promise<AgentBinding>;
    listAgentBindings(filter?: {
        workspaceId?: string;
        agentId?: string;
        channel?: ChannelName;
    }): Promise<AgentBinding[]>;
    deleteAgentBinding(id: string): Promise<boolean>;
    resolveAgentBinding(params: {
        channel: ChannelName;
        userId: string;
        chatId: string;
    }): Promise<ResolvedAgentBinding | null>;
    createTeamTask(task: {
        workspaceId: string;
        title: string;
        description?: string;
        status?: TeamTaskStatus;
        priority?: TeamTaskPriority;
        assignedAgentId?: string | null;
        dependsOnTaskIds?: string[];
        reviewRequired?: boolean;
        reviewerAgentId?: string | null;
        reviewStatus?: TeamTask['reviewStatus'];
        attemptCount?: number;
        maxAttempts?: number;
        lastAttemptAt?: Date | null;
        escalationStatus?: TeamTask['escalationStatus'];
        escalationReason?: string | null;
        humanOwnerUserId?: string | null;
        blockedReason?: string | null;
        createdBy: string;
        resultSummary?: string;
        dueAt?: Date | null;
        metadata?: Record<string, unknown>;
    }): Promise<TeamTask>;
    getTeamTask(id: string): Promise<TeamTask | null>;
    listTeamTasks(filter?: {
        workspaceId?: string;
        status?: TeamTaskStatus;
        assignedAgentId?: string;
    }): Promise<TeamTask[]>;
    updateTeamTask(id: string, updates: Partial<{
        title: string;
        description: string;
        status: TeamTaskStatus;
        priority: TeamTaskPriority;
        assignedAgentId: string | null;
        dependsOnTaskIds: string[];
        reviewRequired: boolean;
        reviewerAgentId: string | null;
        reviewStatus: TeamTask['reviewStatus'];
        attemptCount: number;
        maxAttempts: number;
        lastAttemptAt: Date | null;
        escalationStatus: TeamTask['escalationStatus'];
        escalationReason: string | null;
        humanOwnerUserId: string | null;
        blockedReason: string | null;
        resultSummary: string | null;
        dueAt: Date | null;
        metadata: Record<string, unknown>;
    }>): Promise<TeamTask | null>;
    deleteTeamTask(id: string): Promise<boolean>;
    getTeamPolicy(workspaceId: string): Promise<TeamPolicy | null>;
    upsertTeamPolicy(policy: {
        workspaceId: string;
        autoDispatch?: boolean;
        autoReview?: boolean;
        maxAutoRetries?: number;
        escalateOnBlocked?: boolean;
        escalateOnReviewChanges?: boolean;
        escalateOnSlaBreach?: boolean;
        autoShareTaskResults?: boolean;
        autoPropagateLearnings?: boolean;
        autoGovernLearnedRules?: boolean;
        sharedMemoryPrefix?: string;
        defaultTaskSlaHours?: number;
        defaultHumanOwnerUserId?: string | null;
        approvalReminderAfterMinutes?: number;
        approvalEscalationAfterMinutes?: number;
        onCallAssignmentTimeoutMinutes?: number;
        onCallMaxHandoffsPerTask?: number;
        escalationOwnerUserId?: string | null;
        updatedBy: string;
        metadata?: Record<string, unknown>;
    }): Promise<TeamPolicy>;
    createTeamTaskApproval(approval: {
        workspaceId: string;
        taskId: string;
        requestedBy: string;
        requestedForUserId: string;
        reason: string;
        status?: TeamTaskApprovalStatus;
        resolutionNotes?: string | null;
        resolvedAt?: Date | null;
    }): Promise<TeamTaskApproval>;
    listTeamTaskApprovals(filter?: {
        workspaceId?: string;
        taskId?: string;
        status?: TeamTaskApprovalStatus;
        requestedForUserId?: string;
    }): Promise<TeamTaskApproval[]>;
    updateTeamTaskApproval(id: string, updates: Partial<{
        status: TeamTaskApprovalStatus;
        resolutionNotes: string | null;
        resolvedAt: Date | null;
    }>): Promise<TeamTaskApproval | null>;
    createTeamNotification(notification: {
        workspaceId: string;
        recipientUserId: string;
        type: TeamNotification['type'];
        severity?: TeamNotificationSeverity;
        status?: TeamNotificationStatus;
        deliveryStatus?: TeamNotificationDeliveryStatus;
        deliveryAttemptCount?: number;
        title: string;
        message: string;
        taskId?: string | null;
        approvalId?: string | null;
        lastDeliveryError?: string | null;
        metadata?: Record<string, unknown>;
        readAt?: Date | null;
        lastDeliveryAttemptAt?: Date | null;
        deliveredAt?: Date | null;
    }): Promise<TeamNotification>;
    listTeamNotifications(filter?: {
        workspaceId?: string;
        recipientUserId?: string;
        status?: TeamNotificationStatus;
        deliveryStatus?: TeamNotificationDeliveryStatus;
        type?: TeamNotification['type'];
        taskId?: string;
        approvalId?: string;
    }): Promise<TeamNotification[]>;
    updateTeamNotification(id: string, updates: Partial<{
        status: TeamNotificationStatus;
        deliveryStatus: TeamNotificationDeliveryStatus;
        deliveryAttemptCount: number;
        title: string;
        message: string;
        lastDeliveryError: string | null;
        metadata: Record<string, unknown>;
        readAt: Date | null;
        lastDeliveryAttemptAt: Date | null;
        deliveredAt: Date | null;
    }>): Promise<TeamNotification | null>;
    createTeamNotificationRoute(route: {
        workspaceId: string;
        recipientUserId: string;
        channel: ChannelName;
        chatId: string;
        enabled?: boolean;
        createdBy: string;
        metadata?: Record<string, unknown>;
    }): Promise<TeamNotificationRoute>;
    listTeamNotificationRoutes(filter?: {
        workspaceId?: string;
        recipientUserId?: string;
        channel?: ChannelName;
        enabled?: boolean;
    }): Promise<TeamNotificationRoute[]>;
    getTeamNotificationRoute(id: string): Promise<TeamNotificationRoute | null>;
    updateTeamNotificationRoute(id: string, updates: Partial<{
        recipientUserId: string;
        channel: ChannelName;
        chatId: string;
        enabled: boolean;
        metadata: Record<string, unknown>;
    }>): Promise<TeamNotificationRoute | null>;
    deleteTeamNotificationRoute(id: string): Promise<boolean>;
    createTeamMailboxMessage(message: {
        workspaceId: string;
        threadId?: string;
        dedupeKey?: string | null;
        senderAgentId?: string | null;
        senderUserId?: string | null;
        recipientAgentId?: string | null;
        taskId?: string | null;
        type?: 'direct' | 'broadcast' | 'task_event' | 'challenge' | 'consensus_request' | 'consensus_response';
        status?: 'pending' | 'acknowledged' | 'archived' | 'dead_letter';
        subject?: string | null;
        message: string;
        metadata?: Record<string, unknown>;
        acknowledgedAt?: Date | null;
    }): Promise<import('../utils/types.js').TeamMailboxMessage>;
    listTeamMailboxMessages(filter?: {
        workspaceId?: string;
        threadId?: string;
        dedupeKey?: string;
        senderAgentId?: string;
        recipientAgentId?: string;
        taskId?: string;
        type?: import('../utils/types.js').TeamMailboxMessage['type'];
        status?: import('../utils/types.js').TeamMailboxMessage['status'];
    }): Promise<import('../utils/types.js').TeamMailboxMessage[]>;
    updateTeamMailboxMessage(id: string, updates: Partial<{
        status: import('../utils/types.js').TeamMailboxMessage['status'];
        subject: string | null;
        message: string;
        metadata: Record<string, unknown>;
        acknowledgedAt: Date | null;
    }>): Promise<import('../utils/types.js').TeamMailboxMessage | null>;
    createTeamOnCallRotation(rotation: {
        workspaceId: string;
        name: string;
        enabled?: boolean;
        scheduleType?: TeamOnCallRotation['scheduleType'];
        anchorDate?: Date;
        department?: string | null;
        role?: string | null;
        primaryAgentIds?: string[];
        secondaryAgentIds?: string[];
        createdBy: string;
        metadata?: Record<string, unknown>;
    }): Promise<TeamOnCallRotation>;
    listTeamOnCallRotations(filter?: {
        workspaceId?: string;
        enabled?: boolean;
        department?: string;
        role?: string;
    }): Promise<TeamOnCallRotation[]>;
    getTeamOnCallRotation(id: string): Promise<TeamOnCallRotation | null>;
    updateTeamOnCallRotation(id: string, updates: Partial<{
        name: string;
        enabled: boolean;
        scheduleType: TeamOnCallRotation['scheduleType'];
        anchorDate: Date;
        department: string | null;
        role: string | null;
        primaryAgentIds: string[];
        secondaryAgentIds: string[];
        metadata: Record<string, unknown>;
    }>): Promise<TeamOnCallRotation | null>;
    deleteTeamOnCallRotation(id: string): Promise<boolean>;
    createTeamTemplate(template: {
        workspaceId: string;
        name: string;
        description?: string;
        department?: string | null;
        role?: string | null;
        goalTemplate?: string | null;
        variables?: TeamTemplate['variables'];
        taskBlueprints: TeamTemplate['taskBlueprints'];
        createdBy: string;
        metadata?: Record<string, unknown>;
    }): Promise<TeamTemplate>;
    listTeamTemplates(workspaceId?: string): Promise<TeamTemplate[]>;
    getTeamTemplate(id: string): Promise<TeamTemplate | null>;
    updateTeamTemplate(id: string, updates: Partial<{
        name: string;
        description: string | null;
        department: string | null;
        role: string | null;
        goalTemplate: string | null;
        variables: TeamTemplate['variables'];
        taskBlueprints: TeamTemplate['taskBlueprints'];
        metadata: Record<string, unknown>;
    }>): Promise<TeamTemplate | null>;
    deleteTeamTemplate(id: string): Promise<boolean>;
    createTeamTopology(topology: {
        workspaceId: string;
        name: string;
        department?: string | null;
        role?: string | null;
        supervisorAgentId?: string | null;
        workerAgentIds?: string[];
        defaultTemplateIds?: string[];
        defaultHumanOwnerUserId?: string | null;
        orchestratorRules?: OrchestratorRules | null;
        adaptiveModelPolicy?: AdaptiveModelPolicy | null;
        modelRoutes?: TeamTopologyModelRoutes | null;
        candidateStrategy?: TeamTopology['candidateStrategy'];
        candidateRolloutPolicy?: TeamTopology['candidateRolloutPolicy'];
        candidateRolloutControl?: TeamTopology['candidateRolloutControl'];
        createdBy: string;
        metadata?: Record<string, unknown>;
    }): Promise<TeamTopology>;
    listTeamTopologies(workspaceId?: string): Promise<TeamTopology[]>;
    getTeamTopology(id: string): Promise<TeamTopology | null>;
    updateTeamTopology(id: string, updates: Partial<{
        name: string;
        department: string | null;
        role: string | null;
        supervisorAgentId: string | null;
        workerAgentIds: string[];
        defaultTemplateIds: string[];
        defaultHumanOwnerUserId: string | null;
        orchestratorRules: OrchestratorRules | null;
        adaptiveModelPolicy: AdaptiveModelPolicy | null;
        modelRoutes: TeamTopologyModelRoutes | null;
        candidateStrategy: TeamTopology['candidateStrategy'];
        candidateRolloutPolicy: TeamTopology['candidateRolloutPolicy'];
        candidateRolloutControl: TeamTopology['candidateRolloutControl'];
        metadata: Record<string, unknown>;
    }>): Promise<TeamTopology | null>;
    deleteTeamTopology(id: string): Promise<boolean>;
    addMessage(sessionId: string, userId: string, channel: ChannelName, message: ConversationMessage): Promise<void>;
    getHistory(sessionId: string, limit?: number): Promise<ConversationMessage[]>;
    clearHistory(sessionId: string): Promise<void>;
    getHistoryForUser(sessionId: string, userId: string, limit?: number): Promise<ConversationMessage[] | null>;
    clearHistoryForUser(sessionId: string, userId: string): Promise<boolean>;
    getOrCreateSession(userId: string, channel: ChannelName, chatId: string): Promise<string>;
    getSessionOwner(sessionId: string): Promise<string | null>;
    saveJob(job: Omit<ScheduledJob, 'runCount' | 'createdAt'>): Promise<string>;
    getJobs(userId?: string): Promise<ScheduledJob[]>;
    updateJobRun(id: string, nextRun?: Date): Promise<void>;
    updateJobStatus(id: string, status: JobStatus): Promise<void>;
    deleteJob(id: string): Promise<boolean>;
    updateJobNotifyIf(id: string, notifyIf: string): Promise<void>;
    updateJobLastResult(id: string, lastResult: string): Promise<void>;
    saveInteractionFeedback(opts: {
        userId: string;
        channel: ChannelName;
        sessionId: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: 'positive' | 'negative' | 'neutral' | 'correction' | 'rephrase';
        signal?: string;
        score: number;
    }): Promise<void>;
    saveScopedInteractionFeedback(scope: MemoryScope, opts: {
        sessionId: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: 'positive' | 'negative' | 'neutral' | 'correction' | 'rephrase';
        signal?: string;
        score: number;
    }): Promise<void>;
    getRecentFeedback(userId: string, channel: ChannelName, limit?: number): Promise<Array<{
        id: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: string;
        signal: string | null;
        score: number;
        createdAt: Date;
    }>>;
    getRecentScopedFeedback(scope: MemoryScope, limit?: number): Promise<Array<{
        id: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: string;
        signal: string | null;
        score: number;
        createdAt: Date;
    }>>;
    getFeedbackStats(userId: string, channel: ChannelName): Promise<{
        total: number;
        positive: number;
        negative: number;
        avgScore: number;
    }>;
    getScopedFeedbackStats(scope: MemoryScope): Promise<{
        total: number;
        positive: number;
        negative: number;
        avgScore: number;
    }>;
    upsertBehavioralRule(opts: {
        userId: string;
        channel: ChannelName;
        rule: string;
        category: string;
        confidence: number;
        source: string;
    }): Promise<void>;
    upsertScopedBehavioralRule(scope: MemoryScope, opts: {
        rule: string;
        category: string;
        confidence: number;
        source: string;
    }): Promise<void>;
    getBehavioralRules(userId: string, channel: ChannelName, minConfidence?: number): Promise<Array<{
        rule: string;
        category: string;
        confidence: number;
        source: string;
        evidenceCount: number;
    }>>;
    getScopedBehavioralRules(scope: MemoryScope, minConfidence?: number): Promise<Array<{
        rule: string;
        category: string;
        confidence: number;
        source: string;
        evidenceCount: number;
    }>>;
    getBehavioralRuleHistory(userId: string, channel: ChannelName, limit?: number): Promise<BehavioralRuleHistoryEntry[]>;
    getScopedBehavioralRuleHistory(scope: MemoryScope, limit?: number): Promise<BehavioralRuleHistoryEntry[]>;
    rollbackBehavioralRuleHistory(userId: string, channel: ChannelName, historyId: string, source?: string): Promise<boolean>;
    rollbackScopedBehavioralRuleHistory(scope: MemoryScope, historyId: string, source?: string): Promise<boolean>;
    deleteBehavioralRule(userId: string, channel: ChannelName, rule: string): Promise<boolean>;
    deleteScopedBehavioralRule(scope: MemoryScope, rule: string): Promise<boolean>;
    bulkReplaceScopedBehavioralRules(scope: MemoryScope, rules: Array<{
        rule: string;
        category: string;
        confidence: number;
        source: string;
    }>): Promise<void>;
    listBehavioralRuleScopes(limit?: number): Promise<Array<{
        userId: string;
        channel: ChannelName;
        workspaceId?: string;
        agentId?: string;
        ruleCount: number;
        latestUpdatedAt: Date | null;
    }>>;
    decayScopedBehavioralRules(scope: MemoryScope, opts?: {
        staleAfterDays?: number;
        deleteAfterDays?: number;
        lowEvidenceThreshold?: number;
        decayStep?: number;
        floorConfidence?: number;
    }): Promise<{
        updated: number;
        deleted: number;
    }>;
    summarizeBehavioralRules(): Promise<{
        totalRules: number;
        compressedRules: number;
        avgConfidence: number;
        lowConfidenceRules: number;
        staleRules: number;
        distinctScopes: number;
    }>;
    upsertRuleTrackingStat(workspaceId: string, channel: ChannelName, ruleId: string, success: boolean): Promise<void>;
    getPersistedRuleStats(workspaceId: string, channel: ChannelName, ruleId: string): Promise<{
        ruleId: string;
        workspaceId: string;
        channel: string;
        totalApplications: number;
        successfulApplications: number;
        failedApplications: number;
        lastUsedAt: Date | null;
        createdAt: Date;
    } | null>;
    getAllPersistedRuleStats(workspaceId: string, channel: ChannelName): Promise<Map<string, {
        ruleId: string;
        workspaceId: string;
        channel: string;
        totalApplications: number;
        successfulApplications: number;
        failedApplications: number;
        lastUsedAt: Date | null;
        createdAt: Date;
    }>>;
    upsertEntity(userId: string, channel: ChannelName, entity: Omit<Entity, 'id' | 'userId' | 'channel' | 'mentionCount' | 'lastMentioned' | 'createdAt'>): Promise<string>;
    upsertScopedEntity(scope: MemoryScope, entity: Omit<Entity, 'id' | 'userId' | 'channel' | 'mentionCount' | 'lastMentioned' | 'createdAt'>): Promise<string>;
    getEntities(userId: string, channel: ChannelName, type?: EntityType): Promise<Entity[]>;
    getScopedEntities(scope: MemoryScope, type?: EntityType): Promise<Entity[]>;
    getEntity(userId: string, channel: ChannelName, name: string): Promise<Entity | null>;
    getScopedEntity(scope: MemoryScope, name: string): Promise<Entity | null>;
    searchEntities(userId: string, channel: ChannelName, query: string, limit?: number): Promise<Entity[]>;
    searchScopedEntities(scope: MemoryScope, query: string, limit?: number): Promise<Entity[]>;
    getRecentEntities(userId: string, channel: ChannelName, limit?: number): Promise<Entity[]>;
    getRecentScopedEntities(scope: MemoryScope, limit?: number): Promise<Entity[]>;
    getPendingTasks(userId: string, channel: ChannelName): Promise<Entity[]>;
    getPendingScopedTasks(scope: MemoryScope): Promise<Entity[]>;
    deleteEntity(userId: string, channel: ChannelName, name: string): Promise<boolean>;
    savePatrolCheck(check: Omit<PatrolCheck, 'id' | 'createdAt' | 'consecutiveFailures' | 'lastCheck' | 'lastStatus'>): Promise<string>;
    getPatrolChecks(userId?: string): Promise<PatrolCheck[]>;
    updatePatrolResult(id: string, ok: boolean, status: 'ok' | 'error' | 'timeout', consecutiveFailures: number): Promise<void>;
    updatePatrolStatus(id: string, status: 'active' | 'paused'): Promise<void>;
    deletePatrolCheck(id: string): Promise<boolean>;
    savePatrolResult(result: Omit<PatrolResult, 'id' | 'checkedAt'>): Promise<void>;
    getPatrolHistory(checkId: string, limit?: number): Promise<PatrolResult[]>;
    saveWorkflow(wf: Omit<WorkflowDef, 'id' | 'createdAt' | 'runCount' | 'lastRun'>): Promise<string>;
    getWorkflows(userId?: string): Promise<WorkflowDef[]>;
    updateWorkflowRun(id: string): Promise<void>;
    updateWorkflowStatus(id: string, status: 'active' | 'paused'): Promise<void>;
    deleteWorkflow(id: string): Promise<boolean>;
    getLastJobRunTime(): Promise<number | null>;
    getLastWorkflowRunTime(): Promise<number | null>;
    getDueReminders(): Promise<Array<{
        userId: string;
        channel: string;
        key: string;
        value: string;
    }>>;
    markReminderDone(userId: string, channel: string, key: string): Promise<void>;
    checkRateLimit(key: string, limit: number, windowMs: number): Promise<boolean>;
    cleanupRateLimits(): Promise<void>;
    trackError(opts: {
        level?: 'error' | 'warn';
        message: string;
        context?: Record<string, unknown>;
        stack?: string;
        userId?: string;
        channel?: string;
    }): Promise<void>;
    getRecentErrors(limit?: number): Promise<Array<{
        id: string;
        level: string;
        message: string;
        context: Record<string, unknown> | null;
        userId: string | null;
        channel: string | null;
        createdAt: Date;
    }>>;
    logAudit(entry: {
        userId: string;
        channel: string;
        chatId?: string;
        skillName: string;
        params?: Record<string, unknown>;
        success: boolean;
        durationMs: number;
        error?: string;
        role?: string;
    }): Promise<void>;
    queryAuditLog(opts: {
        userId?: string;
        skillName?: string;
        channel?: string;
        success?: boolean;
        sinceMs?: number;
        limit?: number;
    }): Promise<Array<{
        id: string;
        timestamp: Date;
        userId: string;
        channel: string;
        chatId: string | null;
        skillName: string;
        params: Record<string, unknown> | null;
        success: boolean;
        durationMs: number;
        error: string | null;
        role: string | null;
    }>>;
    getSkillStats(): Promise<Array<{
        skillName: string;
        callCount: number;
        successCount: number;
        successRate: number;
        avgDurationMs: number;
        lastCalledAt: Date | null;
    }>>;
    recordMemoryChange(userId: string, channel: string, key: string, oldValue: string | null, newValue: string, source: 'extraction' | 'correction' | 'manual'): Promise<void>;
    recordScopedMemoryChange(scope: MemoryScope, key: string, oldValue: string | null, newValue: string, source: 'extraction' | 'correction' | 'manual'): Promise<void>;
    getMemoryHistory(userId: string, channel: string, limit?: number): Promise<MemoryHistoryEntry[]>;
    getScopedMemoryHistory(scope: MemoryScope, limit?: number): Promise<MemoryHistoryEntry[]>;
    rollbackMemory(userId: string, channel: ChannelName, historyId: string): Promise<boolean>;
    rollbackScopedMemory(scope: MemoryScope, historyId: string): Promise<boolean>;
    searchConversations(userId: string, channel: ChannelName, query: string, limit?: number): Promise<Array<{
        sessionId: string;
        role: string;
        content: string;
        createdAt: Date;
    }>>;
    exportConversation(sessionId: string, format: 'json' | 'markdown'): Promise<string>;
    listUsers(): Promise<Array<{
        userId: string;
        sessionCount: number;
        conversationCount: number;
        lastActive: Date | null;
    }>>;
    deleteUserData(userId: string): Promise<void>;
    getAuthRevokedAfter(userId: string): Promise<number | null>;
    revokeAuthSessions(userId: string, opts?: {
        revokedAfter?: number;
        revokedBy?: string;
        reason?: string;
    }): Promise<void>;
    cleanup(): Promise<void>;
    recordTokenUsage(record: {
        userId: string;
        workspaceId?: string | null;
        agentId?: string | null;
        provider: string;
        model: string;
        inputTokens: number;
        outputTokens: number;
        costUsd?: number | null;
        channel?: string | null;
        sessionKey?: string | null;
    }): Promise<void>;
    getTokenUsageSummary(filter: {
        userId?: string;
        workspaceId?: string;
        period?: string;
    }): Promise<TokenUsageSummary[]>;
    getTokenUsageDetail(filter: {
        userId?: string;
        workspaceId?: string;
        limit?: number;
        offset?: number;
    }): Promise<TokenUsageRecord[]>;
    setUserQuota(quota: {
        scopeType: 'user' | 'workspace';
        scopeId: string;
        monthlyTokenLimit?: number | null;
        monthlyCostLimitUsd?: number | null;
        limitBehavior?: 'soft' | 'hard';
    }): Promise<void>;
    getUserQuota(scopeType: 'user' | 'workspace', scopeId: string): Promise<UserQuota | null>;
    listUserQuotas(): Promise<UserQuota[]>;
    addWorkspaceMember(workspaceId: string, userId: string, role: 'owner' | 'member' | 'viewer'): Promise<void>;
    removeWorkspaceMember(workspaceId: string, userId: string): Promise<void>;
    getWorkspaceMembership(workspaceId: string, userId: string): Promise<{
        role: 'owner' | 'member' | 'viewer';
    } | null>;
    listWorkspaceMembers(workspaceId: string): Promise<Array<{
        userId: string;
        role: string;
        joinedAt: Date;
    }>>;
    listUserWorkspaces(userId: string): Promise<Array<{
        workspaceId: string;
        role: string;
        joinedAt: Date;
    }>>;
}
//# sourceMappingURL=types.d.ts.map