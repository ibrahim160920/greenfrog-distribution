import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare function validatePluginManifest(manifest: unknown): {
    valid: boolean;
    errors?: string[];
};
export declare function checkDependencies(deps: Record<string, string>): {
    missing: string[];
};
/** Record a skill file in the manifest after creation. */
export declare function registerSkillHash(dir: string, filename: string, filePath: string): void;
/**
 * Verify a skill file against the stored manifest.
 * Returns 'ok' | 'new' (not in manifest) | 'tampered' (hash mismatch).
 */
export declare function verifySkillHash(dir: string, filename: string, filePath: string): 'ok' | 'new' | 'tampered';
/**
 * Wraps a saved custom skill so its execute() call runs in an isolated sandbox.
 *
 * Isolation priority:
 *   1. Docker container (strongest — separate namespace, cgroups, no network)
 *   2. Worker thread (fallback when Docker unavailable)
 *
 * The skill's definition is loaded from the actual file (for LLM schema),
 * but execution is fully sandboxed either way.
 *
 * Exported so registry.ts can use it when loading custom skills on startup.
 */
export declare class SandboxedCustomSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    private filePath;
    constructor(definition: SkillDefinition, filePath: string);
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
}
/**
 * skill_creator - The self-evolution skill!
 * Allows the AI to write new skills and register them at runtime.
 * Skills are saved as JavaScript files and hot-loaded immediately — no restart required.
 */
export declare class SkillCreatorSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    /**
     * Wrap a simple code snippet into a full BaseSkill subclass.
     * Generates JavaScript (ESM) — no TypeScript type annotations.
     */
    private wrapSimpleCode;
}
//# sourceMappingURL=skill_creator.d.ts.map