/**
 * Rule Quality Scoring System
 *
 * Implements automatic quality scoring for behavioral rules based on:
 * - Success rate (40%)
 * - Usage frequency (30%)
 * - Confidence (20%)
 * - Recency/time decay (10%)
 */
import type { ChannelName } from '../utils/types.js';
export interface RuleUsageStats {
    ruleId: string;
    totalApplications: number;
    successfulApplications: number;
    failedApplications: number;
    lastUsedAt: Date;
    createdAt: Date;
}
export interface RuleQualityScore {
    ruleId: string;
    overallScore: number;
    successRate: number;
    usageFrequency: number;
    confidence: number;
    recency: number;
    qualityLevel: 'excellent' | 'good' | 'acceptable' | 'poor';
    shouldKeep: boolean;
    shouldPromote: boolean;
    shouldDemote: boolean;
}
/**
 * Calculate overall quality score for a rule
 */
export declare function calculateRuleQualityScore(stats: RuleUsageStats, confidence: number, maxApplications: number): RuleQualityScore;
/**
 * Batch score all rules in a workspace
 */
export declare function scoreAllRules(workspaceId: string, channel: ChannelName): Promise<RuleQualityScore[]>;
/**
 * Clean up low-quality rules
 */
export declare function cleanupLowQualityRules(workspaceId: string, channel: ChannelName, dryRun?: boolean): Promise<{
    deleted: number;
    demoted: number;
}>;
/**
 * Get high-quality rules for promotion to global library
 */
export declare function getHighQualityRules(workspaceId: string, channel: ChannelName, minScore?: number): Promise<RuleQualityScore[]>;
/**
 * Get rule quality statistics
 */
export declare function getRuleQualityStats(workspaceId: string, channel: ChannelName): Promise<{
    totalRules: number;
    averageScore: number;
    qualityDistribution: Record<string, number>;
    topRules: RuleQualityScore[];
    bottomRules: RuleQualityScore[];
}>;
//# sourceMappingURL=rule_scoring.d.ts.map