/**
 * Reflect — 自我反思技能
 *
 * 让 AI 主动回顾自己的表现，从错误中学习，更新行为规则。
 * 使用越久，积累的交互越多，反思质量越高。
 *
 * 功能：
 *   reflect run        — 触发一次完整反思
 *   reflect status     — 查看学习统计（好评率、规则数、反馈量）
 *   reflect rules      — 列出已学会的行为规则
 *   reflect delete     — 删除某条错误的规则
 *   reflect reset      — 清除所有规则（重新学习）
 */
import { BaseSkill } from './base.js';
import { memoryStore } from '../memory/store.js';
import { runReflection } from '../memory/reflector.js';
export class ReflectSkill extends BaseSkill {
    definition = {
        name: 'reflect',
        description: '自我反思与持续学习：分析历史交互，从错误中提炼行为规则，让AI越用越智能。' +
            '查看学习状态、已掌握的规则，或手动触发一次深度反思。',
        category: 'system',
        parameters: [
            {
                name: 'action', type: 'string', required: true,
                description: '操作',
                enum: ['run', 'status', 'rules', 'delete', 'reset'],
            },
            { name: 'rule', type: 'string', description: '要删除的规则内容（delete 时使用）' },
        ],
        examples: [
            '分析一下你最近的表现，从错误中学习',
            '你学到了哪些关于我的行为规则？',
            '查看你的学习统计',
        ],
    };
    async execute(params, ctx) {
        const { userId, channel } = ctx;
        const action = params.action;
        switch (action) {
            case 'run': return this.runReflect(userId, channel);
            case 'status': return await this.showStatus(userId, channel);
            case 'rules': return await this.showRules(userId, channel);
            case 'delete': return await this.deleteRule(params, userId, channel);
            case 'reset': return await this.resetRules(userId, channel);
            default: return this.err(`未知操作: ${action}`);
        }
    }
    async runReflect(userId, channel) {
        const result = await runReflection(userId, channel);
        if (result.rulesAdded === 0 && result.rulesReinforced === 0) {
            return this.text(`🔍 **自我反思完成**\n\n${result.summary}`);
        }
        const ruleLines = result.rules.map((r) => `- [${r.category}] ${r.rule} (置信度: ${r.confidence}%)`).join('\n');
        return this.text(`🧠 **自我反思完成**\n\n${result.summary}\n\n` +
            (result.rules.length > 0 ? `**新增/更新规则：**\n${ruleLines}` : ''));
    }
    async showStatus(userId, channel) {
        const stats = await memoryStore.getFeedbackStats(userId, channel);
        const rules = await memoryStore.getBehavioralRules(userId, channel, 0);
        const allMem = await memoryStore.getAllMemory(userId, channel);
        const corrections = Object.keys(allMem).filter((k) => k.startsWith('correction:')).length;
        const satisfaction = stats.total > 0
            ? Math.round(stats.positive / stats.total * 100)
            : 0;
        const bar = (n, total, len = 20) => {
            const filled = total > 0 ? Math.round(n / total * len) : 0;
            return '█'.repeat(filled) + '░'.repeat(len - filled);
        };
        return this.text(`📊 **学习状态报告**\n\n` +
            `**交互统计**\n` +
            `总交互: ${stats.total} 次\n` +
            `正向反馈: ${stats.positive} 次 ${bar(stats.positive, stats.total)}\n` +
            `负向反馈: ${stats.negative} 次 ${bar(stats.negative, stats.total)}\n` +
            `满意度: ${satisfaction}%\n\n` +
            `**学习成果**\n` +
            `已学行为规则: ${rules.length} 条\n` +
            `已修正知识点: ${corrections} 条\n\n` +
            `**成熟度评估**: ${this.maturityLevel(stats.total, rules.length)}\n\n` +
            `提示：用 \`reflect run\` 触发一次深度反思，从错误中提炼新规则。`);
    }
    maturityLevel(totalInteractions, ruleCount) {
        const score = totalInteractions * 0.5 + ruleCount * 10;
        if (score < 20)
            return '🌱 初学阶段 — 继续使用，积累更多经验';
        if (score < 100)
            return '🌿 成长阶段 — 已掌握一些个人偏好';
        if (score < 300)
            return '🌳 成熟阶段 — 对你的习惯有较好理解';
        return '🎯 精通阶段 — 深度了解你的工作方式';
    }
    async showRules(userId, channel) {
        const rules = await memoryStore.getBehavioralRules(userId, channel, 0);
        if (rules.length === 0) {
            return this.text('暂无已学行为规则。使用一段时间后，用 `reflect run` 触发反思。');
        }
        const CATEGORY_ICON = {
            style: '✍️', format: '📋', content: '📝', tone: '💬', workflow: '⚙️',
        };
        const byCategory = new Map();
        for (const r of rules) {
            if (!byCategory.has(r.category))
                byCategory.set(r.category, []);
            byCategory.get(r.category).push(r);
        }
        const sections = [];
        for (const [cat, catRules] of byCategory) {
            const icon = CATEGORY_ICON[cat] ?? '•';
            const lines = catRules.map((r) => `  - ${r.rule}\n    置信度: ${r.confidence}% · 来源: ${r.source} · 证据: ${r.evidenceCount}次`);
            sections.push(`${icon} **${cat}**\n${lines.join('\n')}`);
        }
        return this.text(`🧠 **已学行为规则 (${rules.length} 条)**\n\n${sections.join('\n\n')}\n\n` +
            `这些规则已自动注入到每次对话中，AI 会严格遵守。\n` +
            `用 \`reflect delete rule="规则内容"\` 删除不准确的规则。`);
    }
    async deleteRule(params, userId, channel) {
        const rule = (params.rule ?? '').trim();
        if (!rule)
            return this.err('rule 不能为空');
        const rules = await memoryStore.getBehavioralRules(userId, channel, 0);
        const match = rules.find((r) => r.rule.toLowerCase().includes(rule.toLowerCase()) ||
            rule.toLowerCase().includes(r.rule.toLowerCase()));
        if (!match)
            return this.err(`未找到匹配的规则: "${rule}"`);
        const deleted = await memoryStore.deleteBehavioralRule(userId, channel, match.rule);
        if (!deleted)
            return this.err('删除失败');
        return this.text(`已删除规则: "${match.rule}"`);
    }
    async resetRules(userId, channel) {
        const rules = await memoryStore.getBehavioralRules(userId, channel, 0);
        let deleted = 0;
        for (const r of rules) {
            if (await memoryStore.deleteBehavioralRule(userId, channel, r.rule))
                deleted++;
        }
        return this.text(`已清除 ${deleted} 条行为规则。AI 将从零开始重新学习你的偏好。`);
    }
}
//# sourceMappingURL=reflect.js.map