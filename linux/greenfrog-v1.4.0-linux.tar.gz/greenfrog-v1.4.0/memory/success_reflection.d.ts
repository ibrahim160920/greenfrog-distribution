import type { ChannelName } from '../utils/types.js';
export interface SuccessReflectionParams {
    workspaceId: string;
    completedAgentId: string;
    userId: string;
    channel: ChannelName;
    taskTitle: string;
    taskDescription?: string | null;
    taskResult: string;
    propagateToTeam?: boolean;
    /** Use a specific model/provider for the reflection call (e.g. Haiku for low cost) */
    model?: string | null;
    provider?: string | null;
}
export interface SuccessReflectionRule {
    rule: string;
    category: string;
    confidence: number;
}
export declare function runSuccessReflectionSafe(params: SuccessReflectionParams): Promise<SuccessReflectionRule | null>;
//# sourceMappingURL=success_reflection.d.ts.map