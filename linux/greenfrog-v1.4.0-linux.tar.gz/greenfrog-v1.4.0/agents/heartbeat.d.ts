import type { AgentDefinition, TeamMailboxMessage, TeamOnCallRotation, TeamTask } from '../utils/types.js';
export declare const HEARTBEAT_OK = "HEARTBEAT_OK";
type HeartbeatTaskUpdate = {
    taskId: string;
    status?: TeamTask['status'] | 'done';
    progressSummary?: string;
    nextAction?: string;
    blockedReason?: string;
};
type HeartbeatTeammateState = {
    id: string;
    name: string;
    status: AgentDefinition['status'];
    model?: string | null;
    lastHeartbeatStatus?: string | null;
    lastHeartbeatSummary?: string | null;
    openTaskCount: number;
};
type HeartbeatSwarmStatus = {
    topologyName: string;
    onConflict: string;
    challengeSuccessRate?: number | null;
    consensusTimeoutRate?: number | null;
};
export declare function parseHeartbeatTaskUpdates(text: string): HeartbeatTaskUpdate[];
export declare function buildAgentHeartbeatPrompt(params: {
    agent: AgentDefinition;
    checklist: string;
    tasks: TeamTask[];
    mailboxMessages: TeamMailboxMessage[];
    claimableTasks: TeamTask[];
    onCallRotations: TeamOnCallRotation[];
    teamRules?: Array<{
        rule: string;
        category: string;
        source: string;
    }>;
    teammates?: HeartbeatTeammateState[];
    swarmStatus?: HeartbeatSwarmStatus[];
    at?: Date;
}): string;
export declare function runAgentHeartbeatCycle(options?: {
    cwd?: string;
    at?: Date;
    workspaceId?: string;
    agentId?: string;
}): Promise<{
    processed: number;
    idle: number;
    actionable: number;
    errors: number;
}>;
/**
 * Lightweight mailbox-only cycle for a single agent.
 * Called when a mailbox_created event fires for that agent.
 * Does NOT run the full heartbeat; loads only the agent and their pending messages.
 */
export declare function runAgentMailboxCycle(params: {
    workspaceId: string;
    agentId: string;
}): Promise<{
    acked: number;
    sent: number;
}>;
export {};
//# sourceMappingURL=heartbeat.d.ts.map