/**
 * Execution Planner for GreenFrog P4.3.
 *
 * Inserts a `plan` phase between PREPARE and ACT in the dispatch loop.
 * The plan is NOT a submodel call — it is derived deterministically from
 * the contract, feedback state, and execution context. This keeps it
 * zero-latency and predictable.
 *
 * The plan outputs:
 *   strategy         — overall approach for this iteration
 *   keyAssumption    — what the plan assumes to be true
 *   primaryAction    — the main step the agent should take
 *   expectedEvidence — what a passing resultSummary should contain
 *   fallbackAction   — what to try if the primary action fails
 *   promptSuffix     — text injected into the worker prompt to shape behaviour
 *   planSummary      — one-line string for logging and metadata
 *
 * The promptSuffix is appended after the worker prompt but before the
 * contract prompt — it frames the agent's strategy for this attempt.
 *
 * This is a pure module — no I/O, no DB access.
 */
// ── Helpers ───────────────────────────────────────────────────────────────────
/**
 * Build a human-readable "expected evidence" string from doneCriteria.
 * If no criteria exist, derive from the objective.
 */
function buildExpectedEvidence(contract) {
    if (contract.doneCriteria.length === 0) {
        return `resultSummary 应简洁说明「${contract.objective.slice(0, 60)}」已完成`;
    }
    const items = contract.doneCriteria.slice(0, 3).map(c => `• ${c.slice(0, 60)}`).join('\n');
    return `resultSummary 应覆盖以下完成标准：\n${items}`;
}
/**
 * Extract the most actionable phrase from the objective.
 */
function primaryActionFromObjective(objective) {
    // Trim to a manageable action phrase
    return objective.length > 80 ? `${objective.slice(0, 80)}…` : objective;
}
// ── Core function ─────────────────────────────────────────────────────────────
/**
 * Derive an execution plan for the current iteration.
 *
 * @param contract          — task contract for this dispatch
 * @param feedback          — feedback snapshot from prior iterations
 * @param attemptsRemaining — how many more runs are permitted AFTER this one
 * @param options           — optional signals from caller
 */
export function buildExecutionPlan(contract, feedback, attemptsRemaining, options) {
    const { recoveryMode = 'restartable', lastHumanDecision = null, missingCriteria = [], } = options ?? {};
    const objective = contract.objective;
    const expectedEvidence = buildExpectedEvidence(contract);
    const primaryAction = primaryActionFromObjective(objective);
    // ── Strategy selection ────────────────────────────────────────────────────
    let strategy;
    if (attemptsRemaining === 0) {
        // Last chance — must produce best possible output
        strategy = 'conservative_last_attempt';
    }
    else if (lastHumanDecision === 'rejected' || lastHumanDecision === 'retry_requested') {
        // Human explicitly asked for a redo
        strategy = 'repair_prior_output';
    }
    else if (feedback.latestError?.errorClass === 'unclear_goal') {
        strategy = 'clarify_and_act';
    }
    else if (recoveryMode === 'resumable' && feedback.latestObservation?.text) {
        strategy = 'resume_from_observation';
    }
    else if (feedback.pendingHint || feedback.latestError || missingCriteria.length > 0) {
        strategy = 'repair_prior_output';
    }
    else {
        strategy = 'direct_execution';
    }
    // ── Per-strategy output ───────────────────────────────────────────────────
    switch (strategy) {
        case 'direct_execution': {
            return {
                strategy,
                keyAssumption: '任务目标明确，所需上下文充足，可直接执行',
                primaryAction,
                expectedEvidence,
                fallbackAction: '若遇到阻碍，在 resultSummary 中说明情况并给出部分结果',
                promptSuffix: '',
                planSummary: `direct_execution: ${objective.slice(0, 50)}`,
            };
        }
        case 'repair_prior_output': {
            const missingNote = missingCriteria.length > 0
                ? `\n上次未满足的标准：${missingCriteria.slice(0, 3).map(c => `「${c.slice(0, 50)}」`).join('；')}`
                : '';
            const humanNote = lastHumanDecision === 'rejected'
                ? `\n人工审核不合格${options?.lastRunStatus ? `（上次状态：${options.lastRunStatus}）` : ''}。`
                : '';
            const promptSuffix = [
                `## 本次执行策略`,
                `上次执行结果需要改进。请针对性地修正：${humanNote}${missingNote}`,
                `- 不要从零开始重复无关步骤`,
                `- 直接解决上次未完成的部分`,
                `- 在 resultSummary 中明确说明你改进了什么`,
            ].join('\n');
            return {
                strategy,
                keyAssumption: '上次执行已产出部分结果，本次需针对性改进',
                primaryAction: `改进并补全：${primaryAction}`,
                expectedEvidence,
                fallbackAction: '若无法确定上次问题所在，从最简可行方案开始重新执行',
                promptSuffix,
                planSummary: `repair: ${missingCriteria.slice(0, 2).join(',') || '(human rejection)'}`,
            };
        }
        case 'conservative_last_attempt': {
            const criteriaNote = contract.doneCriteria.length > 0
                ? `\n必须满足的完成标准：\n${contract.doneCriteria.slice(0, 5).map(c => `- ${c.slice(0, 60)}`).join('\n')}`
                : '';
            const promptSuffix = [
                `## 本次执行策略`,
                `**这是最后一次自动执行机会。** 请务必产出完整、正确的结果。${criteriaNote}`,
                `- 不要请求澄清，直接输出最佳结果`,
                `- 即使不完美，也要给出实质性的结果`,
                `- resultSummary 中必须覆盖所有完成标准`,
            ].join('\n');
            return {
                strategy,
                keyAssumption: '本次是最后一次自动重试，必须给出最佳输出',
                primaryAction: `最终执行：${primaryAction}`,
                expectedEvidence,
                fallbackAction: '输出尽力而为的结果，不留空白',
                promptSuffix,
                planSummary: `conservative_last: ${objective.slice(0, 40)}`,
            };
        }
        case 'resume_from_observation': {
            const obs = feedback.latestObservation?.text?.slice(0, 200) ?? '';
            const promptSuffix = [
                `## 本次执行策略（继续模式）`,
                `上次已完成部分工作，请在此基础上继续，不要重复已完成的步骤。`,
                obs ? `上次观察：${obs}` : '',
                `- 跳过已完成的步骤`,
                `- 从上次中断处继续执行`,
            ].filter(Boolean).join('\n');
            return {
                strategy,
                keyAssumption: '上次执行已有可用的中间结果，可以继续而非从头开始',
                primaryAction: `继续执行：${primaryAction}`,
                expectedEvidence,
                fallbackAction: '若无法确认上次进度，从头安全重新执行',
                promptSuffix,
                planSummary: `resume: ${obs.slice(0, 40)}`,
            };
        }
        case 'clarify_and_act': {
            const promptSuffix = [
                `## 本次执行策略`,
                `任务目标可能不够明确。请选择最合理的解释，直接完成任务，不要反复要求澄清。`,
                `- 选择最简单直接的解释`,
                `- 在 resultSummary 中说明你采用的解释`,
                `- 给出实质性结果，即使基于假设`,
            ].join('\n');
            return {
                strategy,
                keyAssumption: '目标有歧义，选择最合理的解释推进',
                primaryAction: `按最佳解释执行：${primaryAction}`,
                expectedEvidence,
                fallbackAction: '以最宽松的解释完成最小可行任务',
                promptSuffix,
                planSummary: `clarify_and_act: ${objective.slice(0, 40)}`,
            };
        }
    }
}
//# sourceMappingURL=planner.js.map