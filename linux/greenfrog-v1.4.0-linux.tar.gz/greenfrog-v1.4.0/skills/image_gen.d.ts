import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class ImageGenSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private generateDalle;
    private generatePollinations;
    private generateStableDiffusion;
    private generateFlux;
}
//# sourceMappingURL=image_gen.d.ts.map