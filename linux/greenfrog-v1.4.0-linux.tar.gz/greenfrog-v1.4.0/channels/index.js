import { BaseChannel } from './base.js';
import { TelegramChannel } from './telegram/index.js';
import { DiscordChannel } from './discord/index.js';
import { SlackChannel } from './slack/index.js';
import { WebChannel } from './web/index.js';
import { WhatsAppChannel } from './whatsapp/index.js';
import { WeComChannel } from './wecom/index.js';
import { FeishuChannel } from './feishu/index.js';
import { DingTalkChannel } from './dingtalk/index.js';
import { TeamsChannel } from './teams/index.js';
import { LineChannel } from './line/index.js';
import { MatrixChannel } from './matrix/index.js';
import { agent } from '../agents/agent.js';
import { createLogger } from '../utils/logger.js';
import { withAgentExecutionLease } from '../runtime/agent_runtime_guard.js';
import { RuntimeLimitError } from '../utils/errors.js';
const log = createLogger('channels');
/** Channels that were removed from ChannelName — warn if still present in config. */
const REMOVED_CHANNELS = ['imessage', 'signal', 'wechat'];
export class ChannelManager {
    channels = new Map();
    constructor() {
        this.register(new TelegramChannel());
        this.register(new DiscordChannel());
        this.register(new SlackChannel());
        this.register(new WebChannel());
        this.register(new WhatsAppChannel());
        this.register(new WeComChannel());
        this.register(new FeishuChannel());
        this.register(new DingTalkChannel());
        this.register(new TeamsChannel());
        this.register(new LineChannel());
        this.register(new MatrixChannel());
    }
    register(channel) {
        this.channels.set(channel.name, channel);
    }
    async startAll(cfg) {
        // Warn about removed channels that may still be in user config
        if (cfg) {
            for (const ch of REMOVED_CHANNELS) {
                if (cfg?.[ch]) {
                    log.warn({ channel: ch }, `Channel "${ch}" is not implemented and will be ignored. Remove it from your config.`);
                }
            }
        }
        const messageHandler = async (msg) => {
            log.info({ channel: msg.channel, userId: msg.userId, text: msg.text.slice(0, 50) }, 'Incoming message');
            try {
                return await withAgentExecutionLease({ userId: msg.userId, channel: msg.channel, label: 'channel_message' }, () => agent.processMessage(msg));
            }
            catch (err) {
                if (err instanceof RuntimeLimitError) {
                    return {
                        text: err.message,
                        channel: msg.channel,
                        chatId: msg.chatId,
                        replyToId: msg.id,
                    };
                }
                throw err;
            }
        };
        const results = await Promise.allSettled([...this.channels.values()].map(async (channel) => {
            channel.onMessage(messageHandler);
            await channel.start();
        }));
        let started = 0;
        for (const result of results) {
            if (result.status === 'fulfilled')
                started++;
            else
                log.error({ err: result.reason }, 'Channel start failed');
        }
        log.info({ started, total: this.channels.size }, 'Channels started');
    }
    async stopAll() {
        await Promise.allSettled([...this.channels.values()].map((ch) => ch.stop()));
        log.info('All channels stopped');
    }
    /** Send a message through a specific channel (used by the scheduler). */
    async send(channelName, message) {
        const channel = this.channels.get(channelName);
        if (!channel) {
            log.warn({ channel: channelName }, 'Cannot send: channel not registered');
            return;
        }
        if (!channel.isRunning()) {
            log.warn({ channel: channelName }, 'Cannot send: channel not running');
            return;
        }
        await channel.send(message);
    }
    getStatus() {
        return Object.fromEntries([...this.channels.entries()].map(([name, ch]) => [name, ch.isRunning()]));
    }
}
export const channelManager = new ChannelManager();
export { BaseChannel, TelegramChannel, DiscordChannel, SlackChannel, WebChannel, WhatsAppChannel, WeComChannel, FeishuChannel, DingTalkChannel, TeamsChannel, LineChannel, MatrixChannel };
//# sourceMappingURL=index.js.map