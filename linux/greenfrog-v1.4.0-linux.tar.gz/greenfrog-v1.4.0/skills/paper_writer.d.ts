import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class PaperWriterSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private writePaper;
    private revisePaper;
    private polishPaper;
    private reviewPaper;
}
//# sourceMappingURL=paper_writer.d.ts.map