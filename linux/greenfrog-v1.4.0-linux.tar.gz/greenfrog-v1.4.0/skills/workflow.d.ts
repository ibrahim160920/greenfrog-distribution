/**
 * Workflow — 自主工作流技能
 *
 * 真正的 Proactive Agent 核心：定义多步骤任务链，每步可以：
 *   1. 用任意 prompt（可引用前步结果）调用完整 agentic loop（含工具）
 *   2. 根据条件决定是否通知用户
 *   3. 根据条件决定是否继续后续步骤
 *
 * 使用场景举例：
 *   竞品监控：抓取页面 → AI 对比变化 → 有变化才推送
 *   每日简报：查天气 → 查新闻 → 查日历 → 合并成一条推送
 *   服务巡检报告：收集各服务状态 → AI 汇总 → 异常时告警
 *   内容助手：收集热点 → AI 草拟内容 → 发给你审核
 *
 * prompt 模板语法：
 *   {{step_id}}   — 引用某步骤的输出
 *   {{context.key}} — 引用运行时上下文变量
 *
 * notify_if / stop_if 条件：
 *   'always'      — 每次都通知/停止
 *   'never'       — 从不通知/停止
 *   'on_alert'    — 响应包含告警关键词时（error/失败/异常/down/❌）
 *   'if_changed'  — 与上次运行结果不同时
 *   'empty'       — 响应为空时（stop_if 专用）
 *   'keyword:XXX' — 响应包含 XXX 时
 */
import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare function matchesCondition(text: string, condition: string, lastResult?: string): boolean;
export declare function renderTemplate(template: string, context: Record<string, string>): string;
export declare class WorkflowSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    private create;
    private list;
    private show;
    private delete;
    private runNow;
    private setStatus;
}
//# sourceMappingURL=workflow.d.ts.map