export declare function sendMessage(message: string, opts: {
    channel?: string;
    json?: boolean;
}): Promise<void>;
//# sourceMappingURL=send.d.ts.map