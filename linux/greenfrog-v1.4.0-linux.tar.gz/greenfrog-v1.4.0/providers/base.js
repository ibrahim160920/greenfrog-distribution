export class BaseProvider {
}
//# sourceMappingURL=base.js.map