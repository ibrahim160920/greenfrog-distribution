import { BaseSkill } from './base.js';
import { createRequire } from 'module';
import { memoryStore } from '../memory/store.js';
import { GLOBAL_RULE_LIBRARY_WORKSPACE_ID } from '../memory/index.js';
import { providerRegistry } from '../providers/index.js';
import { createLogger } from '../utils/logger.js';
import { runChallengeReflectionSafe } from '../memory/challenge_reflection.js';
import { runSuccessReflectionSafe } from '../memory/success_reflection.js';
import { buildTaskContract, renderContractPrompt } from '../agents/contract.js';
import { assembleTaskContext, renderContextPrompt } from '../agents/context_assembly.js';
import { classifyError, planRecovery } from '../agents/recovery.js';
import { buildExecutionPlan } from '../agents/planner.js';
import { finalizeTaskDone } from '../agents/task_finalization.js';
import { recordAutoHardEvidenceForTask } from '../memory/auto_hard_evidence.js';
import { evaluateSupervisorConflictSafe, parseAdaptiveOrchestratorPolicy, parseOrchestratorRules, adaptCandidateRolloutSafe, adaptOrchestratorRulesSafe, adaptTopologyModelsSafe } from '../agents/orchestrator.js';
import { appendCandidateRolloutAuditEvent, buildPromoteCandidateStrategyUpdates, findTeamTopologyStrategySnapshot, materializeTaskTopology, parseAdaptiveModelPolicyInput, parseTeamTopologyCandidateRolloutControl, parseTeamTopologyCandidateStrategy, parseTeamTopologyCandidateRolloutPolicy, parseTeamTopologyModelRoutes, resolveTeamTopologyModelRoute, selectTeamTopologyStrategyTrack, } from '../utils/team_topology.js';
const log = createLogger('team');
const DEFAULT_PROTOCOL_ANNOUNCEMENT_TIMEOUT_MINUTES = 30;
const DEFAULT_PROTOCOL_CONSENSUS_TIMEOUT_MINUTES = 60;
const TEAM_SHARED_MEMORY_VERSION_SUFFIX = '::__meta_version';
const require = createRequire(import.meta.url);
export function buildDefaultTeamPolicy(workspaceId, updatedBy = 'system') {
    return {
        workspaceId,
        autoDispatch: true,
        autoReview: true,
        maxAutoRetries: 1,
        escalateOnBlocked: true,
        escalateOnReviewChanges: true,
        escalateOnSlaBreach: true,
        autoShareTaskResults: false,
        autoPropagateLearnings: true,
        autoGovernLearnedRules: false,
        sharedMemoryPrefix: 'team:',
        defaultTaskSlaHours: 24,
        defaultHumanOwnerUserId: null,
        approvalReminderAfterMinutes: 30,
        approvalEscalationAfterMinutes: 120,
        onCallAssignmentTimeoutMinutes: 10,
        onCallMaxHandoffsPerTask: 4,
        escalationOwnerUserId: null,
        updatedBy,
        createdAt: new Date(0),
        updatedAt: new Date(0),
    };
}
async function getEffectiveTeamPolicy(workspaceId, updatedBy = 'system') {
    return await memoryStore.getTeamPolicy?.(workspaceId) ?? buildDefaultTeamPolicy(workspaceId, updatedBy);
}
function parseRuleLibraryAutoGovernancePolicy(policy) {
    const metadata = policy.metadata ?? {};
    const bool = (key, fallback) => typeof metadata[key] === 'boolean' ? metadata[key] : fallback;
    const num = (key, fallback) => {
        const value = Number(metadata[key]);
        return Number.isFinite(value) ? value : fallback;
    };
    return {
        enabled: (typeof metadata['autoGovernLearnedRules'] === 'boolean'
            ? metadata['autoGovernLearnedRules']
            : (typeof metadata['ruleLibraryAutoGovernanceEnabled'] === 'boolean'
                ? metadata['ruleLibraryAutoGovernanceEnabled']
                : policy.autoGovernLearnedRules)),
        autoPromoteMinConfidence: Math.max(0, Math.min(100, num('ruleLibraryAutoPromoteMinConfidence', 85))),
        autoPromoteMinEvidenceCount: Math.max(1, Math.floor(num('ruleLibraryAutoPromoteMinEvidenceCount', 3))),
        autoPromoteMaxPerCycle: Math.max(1, Math.floor(num('ruleLibraryAutoPromoteMaxPerCycle', 2))),
        autoPromoteMinDoneTasks: Math.max(1, Math.floor(num('ruleLibraryAutoPromoteMinDoneTasks', 5))),
        healthyBlockedRate: Math.max(0, Math.min(1, num('ruleLibraryHealthyBlockedRate', 0.15))),
        healthyConsensusTimeoutRate: Math.max(0, Math.min(1, num('ruleLibraryHealthyConsensusTimeoutRate', 0.10))),
        autoDemoteMaxPerCycle: Math.max(1, Math.floor(num('ruleLibraryAutoDemoteMaxPerCycle', 1))),
        autoDemoteRollbackThreshold: Math.max(1, Math.floor(num('ruleLibraryAutoDemoteRollbackThreshold', 2))),
        autoDemoteDeleteThreshold: Math.max(1, Math.floor(num('ruleLibraryAutoDemoteDeleteThreshold', 2))),
        unhealthyBlockedRate: Math.max(0, Math.min(1, num('ruleLibraryUnhealthyBlockedRate', 0.35))),
        unhealthyConsensusTimeoutRate: Math.max(0, Math.min(1, num('ruleLibraryUnhealthyConsensusTimeoutRate', 0.25))),
    };
}
function mergeTeamPolicyMetadata(current, updates) {
    const merged = { ...(current ?? {}) };
    for (const [key, value] of Object.entries(updates)) {
        if (value === undefined)
            continue;
        merged[key] = value;
    }
    return Object.keys(merged).length > 0 ? merged : undefined;
}
function resolveWorkspaceId(ctx, params) {
    const explicit = typeof params.workspace_id === 'string' ? params.workspace_id.trim() : '';
    return explicit || ctx.workspaceId || null;
}
function parseStringArray(value) {
    if (Array.isArray(value)) {
        return value.filter((item) => typeof item === 'string' && item.trim().length > 0).map((item) => item.trim());
    }
    if (typeof value === 'string' && value.trim()) {
        return value.split(',').map((item) => item.trim()).filter(Boolean);
    }
    return undefined;
}
function parseChannelName(value) {
    return value === 'telegram'
        || value === 'discord'
        || value === 'slack'
        || value === 'whatsapp'
        || value === 'web'
        || value === 'wecom'
        || value === 'feishu'
        || value === 'dingtalk'
        || value === 'teams'
        || value === 'line'
        || value === 'matrix'
        ? value
        : undefined;
}
function parseScheduleType(value) {
    return value === 'daily' || value === 'weekly' ? value : undefined;
}
function parseTaskBlueprints(value) {
    if (Array.isArray(value))
        return value;
    if (typeof value === 'string' && value.trim()) {
        return JSON.parse(value);
    }
    return undefined;
}
export function parseTeamTemplateVariableDefinitions(value) {
    let raw = value;
    if (typeof raw === 'string' && raw.trim()) {
        raw = JSON.parse(raw);
    }
    if (!Array.isArray(raw))
        return undefined;
    return raw
        .filter((item) => Boolean(item) && typeof item === 'object' && !Array.isArray(item))
        .map((item) => ({
        name: typeof item.name === 'string' ? item.name.trim() : '',
        ...(typeof item.description === 'string' ? { description: item.description.trim() } : {}),
        ...(item.defaultValue === null || typeof item.defaultValue === 'string'
            ? { defaultValue: item.defaultValue === null ? null : item.defaultValue.trim() }
            : {}),
        ...(item.required !== undefined ? { required: Boolean(item.required) } : {}),
    }))
        .filter((item) => item.name.length > 0);
}
export function parseTeamTemplateVariableValues(value) {
    let raw = value;
    if (typeof raw === 'string' && raw.trim()) {
        raw = JSON.parse(raw);
    }
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return undefined;
    return Object.fromEntries(Object.entries(raw)
        .filter(([key, item]) => key.trim().length > 0 && item !== undefined && item !== null)
        .map(([key, item]) => [key.trim(), String(item).trim()])
        .filter(([, item]) => item.length > 0));
}
function dedupeStringList(values) {
    const seen = new Set();
    const result = [];
    for (const value of values ?? []) {
        const normalized = value.trim();
        if (!normalized || seen.has(normalized))
            continue;
        seen.add(normalized);
        result.push(normalized);
    }
    return result;
}
function normalizeKeyPart(value) {
    return (value ?? '').trim().toLowerCase();
}
export function interpolateTeamTemplateString(value, variables) {
    if (value === undefined || value === null)
        return value;
    return value.replace(/\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}/g, (_match, name) => variables[name] ?? '');
}
export function resolveTeamTemplateVariables(template, provided) {
    const supplied = parseTeamTemplateVariableValues(provided ?? undefined) ?? {};
    const resolved = { ...supplied };
    const missing = [];
    for (const variable of template.variables ?? []) {
        const existing = resolved[variable.name];
        if (existing && existing.trim())
            continue;
        if (typeof variable.defaultValue === 'string' && variable.defaultValue.trim()) {
            resolved[variable.name] = variable.defaultValue.trim();
            continue;
        }
        if (variable.defaultValue === null) {
            resolved[variable.name] = '';
            continue;
        }
        if (variable.required) {
            missing.push(variable.name);
            continue;
        }
        resolved[variable.name] = '';
    }
    if (missing.length > 0) {
        throw new Error(`Missing required template variables: ${missing.join(', ')}`);
    }
    return resolved;
}
export function canUserResolveTeamApproval(approval, actorUserId) {
    return Boolean(actorUserId && approval.requestedForUserId === actorUserId);
}
function renderTask(task) {
    return [
        `- [${task.status}] ${task.title}`,
        `  id: ${task.id}`,
        `  priority: ${task.priority}`,
        `  assigned: ${task.assignedAgentId ?? 'unassigned'}`,
        `  review: ${task.reviewStatus}${task.reviewerAgentId ? ` by ${task.reviewerAgentId}` : ''}`,
        `  attempts: ${task.attemptCount}/${task.maxAttempts}`,
        `  escalation: ${task.escalationStatus}${task.humanOwnerUserId ? ` -> ${task.humanOwnerUserId}` : ''}`,
        task.dependsOnTaskIds && task.dependsOnTaskIds.length > 0 ? `  depends_on: ${task.dependsOnTaskIds.join(', ')}` : null,
        task.description ? `  desc: ${task.description}` : null,
        task.escalationReason ? `  escalation_reason: ${task.escalationReason}` : null,
        task.blockedReason ? `  blocked: ${task.blockedReason}` : null,
        task.resultSummary ? `  result: ${task.resultSummary}` : null,
    ].filter(Boolean).join('\n');
}
function isLoopbackHost(host) {
    const normalized = host.trim().toLowerCase();
    return normalized === '127.0.0.1'
        || normalized === 'localhost'
        || normalized === '0.0.0.0'
        || normalized === '::1';
}
function getTeamWebUiConfig() {
    try {
        return require('../config/index.js').configManager.get();
    }
    catch {
        return null;
    }
}
function resolveTeamWebUiBaseUrl() {
    const cfg = getTeamWebUiConfig();
    if (!cfg)
        return null;
    const explicit = cfg.webui.publicBaseUrl?.trim();
    if (explicit)
        return explicit.replace(/\/+$/, '');
    const redirectUri = cfg.auth?.redirectUri?.trim();
    if (redirectUri) {
        try {
            return new URL(redirectUri).origin;
        }
        catch {
            // Ignore invalid redirect URI here; config validation handles authoritative checks.
        }
    }
    if (isLoopbackHost(cfg.webui.host))
        return null;
    const protocol = cfg.tls?.certFile && cfg.tls?.keyFile ? 'https' : 'http';
    return `${protocol}://${cfg.webui.host}:${cfg.webui.port}`;
}
function buildTeamUiDeepLink(params) {
    const baseUrl = resolveTeamWebUiBaseUrl();
    if (!baseUrl)
        return null;
    const target = new URL('/', `${baseUrl}/`);
    target.searchParams.set('panel', 'teams');
    target.searchParams.set('workspaceId', params.workspaceId);
    if (params.taskId)
        target.searchParams.set('governanceTaskId', params.taskId);
    if (params.approvalId)
        target.searchParams.set('approvalId', params.approvalId);
    const cfg = getTeamWebUiConfig();
    if (!cfg)
        return target.toString();
    if (cfg.auth?.enabled) {
        const loginUrl = new URL('/auth/login', `${baseUrl}/`);
        loginUrl.searchParams.set('redirect', target.toString());
        return loginUrl.toString();
    }
    return target.toString();
}
function buildTeamNotificationActionMetadata(params) {
    const actionUrl = buildTeamUiDeepLink(params);
    return actionUrl
        ? { actionUrl, actionLabel: params.approvalId ? 'Open approval in GreenFrog' : 'Open task in GreenFrog' }
        : {};
}
function isClosedTeamTask(task) {
    return task.status === 'done' || task.status === 'cancelled';
}
function isRunnableTeamTaskStatus(status) {
    return status === 'todo' || status === 'open' || status === 'claimed' || status === 'assigned';
}
function getDefaultCreatedTaskStatus(task) {
    return task.assignedAgentId ? 'claimed' : 'open';
}
function getTaskDispatchContext(task) {
    const metadata = task.metadata ?? {};
    return {
        userId: typeof metadata['requestUserId'] === 'string' ? metadata['requestUserId'] : task.createdBy,
        channel: typeof metadata['requestChannel'] === 'string' ? metadata['requestChannel'] : 'web',
        chatId: typeof metadata['requestChatId'] === 'string' ? metadata['requestChatId'] : task.workspaceId,
    };
}
async function getDependencyStates(task) {
    const dependencies = task.dependsOnTaskIds ?? [];
    const states = await Promise.all(dependencies.map(async (id) => {
        const dep = await memoryStore.getTeamTask(id);
        return dep ? { id, status: dep.status } : { id, status: 'blocked' };
    }));
    return states;
}
export async function isTeamTaskReady(task) {
    if (!task.assignedAgentId)
        return false;
    if (!isRunnableTeamTaskStatus(task.status))
        return false;
    const dependencyStates = await getDependencyStates(task);
    return dependencyStates.every((dep) => dep.status === 'done');
}
async function resolveTaskExecutionRoute(task, mode) {
    const topologyId = typeof (task.metadata ?? {})['topologyId'] === 'string'
        ? task.metadata['topologyId']
        : null;
    const liveTopology = topologyId ? await memoryStore.getTeamTopology(topologyId) : null;
    const taskTopology = materializeTaskTopology(task, liveTopology);
    if (!taskTopology)
        return null;
    const route = mode === 'review'
        ? resolveTeamTopologyModelRoute(taskTopology, 'reviewer', resolveTeamTopologyModelRoute(taskTopology, 'orchestrator'))
        : resolveTeamTopologyModelRoute(taskTopology, 'default_worker');
    if (!route?.provider && !route?.model)
        return null;
    return {
        provider: route.provider ?? null,
        model: route.model ?? null,
        topologyId: taskTopology.id,
        topologyName: taskTopology.name,
    };
}
async function runTaskExecution(task, prompt, agentId, dispatchCtx, mode = 'execution', runId) {
    const { agent } = await import('../agents/agent.js');
    const { withAgentExecutionLease } = await import('../runtime/agent_runtime_guard.js');
    const { startAgentRun } = await import('../runtime/agent_run_control.js');
    const executionRoute = await resolveTaskExecutionRoute(task, mode);
    const incomingMessage = {
        id: `teamtask:${task.id}`,
        userId: dispatchCtx.userId,
        channel: dispatchCtx.channel,
        chatId: dispatchCtx.chatId,
        text: prompt,
        timestamp: new Date(),
        metadata: {
            workspaceId: task.workspaceId,
            agentId,
            sessionKey: `teamtask:${task.id}:${mode}`,
            teamTaskExecutionMode: mode,
            ...(runId ? { agentRunId: runId } : {}),
            ...(executionRoute?.provider ? { agentProviderOverride: executionRoute.provider } : {}),
            ...(executionRoute?.model ? { agentModelOverride: executionRoute.model } : {}),
            ...(executionRoute?.topologyId ? { topologyId: executionRoute.topologyId } : {}),
            ...(executionRoute?.topologyName ? { topologyName: executionRoute.topologyName } : {}),
        },
    };
    const run = startAgentRun({
        runId,
        userId: incomingMessage.userId,
        channel: incomingMessage.channel,
        label: `team_task_${mode}:${task.id}`,
        taskId: task.id,
        workspaceId: task.workspaceId,
        agentId,
    });
    const response = await withAgentExecutionLease({ userId: incomingMessage.userId, channel: incomingMessage.channel, label: `team_task_${mode}` }, async () => {
        try {
            return await agent.processMessage(incomingMessage);
        }
        finally {
            run.release();
        }
    });
    return (response.text ?? '').slice(0, 1000);
}
function resolveHumanOwner(task, policy) {
    return task.humanOwnerUserId ?? policy.defaultHumanOwnerUserId ?? task.createdBy;
}
async function createTeamNotificationSafe(params) {
    try {
        const metadata = {
            ...buildTeamNotificationActionMetadata({
                workspaceId: params.workspaceId,
                taskId: params.taskId,
                approvalId: params.approvalId,
            }),
            ...(params.metadata ?? {}),
        };
        const notification = await memoryStore.createTeamNotification({
            workspaceId: params.workspaceId,
            recipientUserId: params.recipientUserId,
            type: params.type,
            severity: params.severity,
            title: params.title,
            message: params.message,
            taskId: params.taskId,
            approvalId: params.approvalId,
            metadata,
        });
        await deliverTeamNotification(notification);
    }
    catch (err) {
        log.warn({ err, params }, 'Failed to persist team notification');
    }
}
async function createTeamMailboxMessageSafe(params) {
    try {
        return await memoryStore.createTeamMailboxMessage({
            workspaceId: params.workspaceId,
            senderAgentId: params.senderAgentId,
            senderUserId: params.senderUserId,
            recipientAgentId: params.recipientAgentId,
            taskId: params.taskId,
            threadId: params.threadId,
            dedupeKey: params.dedupeKey,
            type: params.type ?? 'direct',
            subject: params.subject,
            message: params.message,
            metadata: params.metadata,
        });
    }
    catch (err) {
        log.warn({ err, params }, 'Failed to persist team mailbox message');
        return null;
    }
}
function buildMailboxDedupeKey(...parts) {
    return parts
        .map((part) => (part ?? '').trim().toLowerCase())
        .filter(Boolean)
        .join(':')
        .slice(0, 240);
}
export function buildTeamSharedMemoryVersionKey(key) {
    return `${key}${TEAM_SHARED_MEMORY_VERSION_SUFFIX}`;
}
export function isTeamSharedMemoryMetaKey(key) {
    return key.endsWith(TEAM_SHARED_MEMORY_VERSION_SUFFIX);
}
function parseSharedMemoryAuthorityRules(policy) {
    const raw = (policy.metadata ?? {})['sharedMemoryAuthorityRules'];
    if (!Array.isArray(raw))
        return [];
    return raw
        .filter((item) => Boolean(item) && typeof item === 'object' && !Array.isArray(item))
        .map((item) => ({
        prefix: typeof item['prefix'] === 'string' ? item['prefix'].trim() : '',
        allowedUserIds: dedupeStringList(parseStringArray(item['allowedUserIds']) ?? []),
        allowedAgentIds: dedupeStringList(parseStringArray(item['allowedAgentIds']) ?? []),
        rollbackAllowedUserIds: dedupeStringList(parseStringArray(item['rollbackAllowedUserIds']) ?? []),
        rollbackAllowedAgentIds: dedupeStringList(parseStringArray(item['rollbackAllowedAgentIds']) ?? []),
        approvalUserIds: dedupeStringList(parseStringArray(item['approvalUserIds']) ?? []),
        approvalRequired: Boolean(item['approvalRequired']),
    }))
        .filter((rule) => rule.prefix.length > 0)
        .sort((a, b) => b.prefix.length - a.prefix.length);
}
function resolveSharedMemoryAuthorityRule(policy, key) {
    return parseSharedMemoryAuthorityRules(policy).find((rule) => key.startsWith(rule.prefix)) ?? null;
}
function canActorWriteSharedMemory(rule, actorUserId, actorAgentId) {
    if (!rule)
        return true;
    const hasUserRules = rule.allowedUserIds.length > 0;
    const hasAgentRules = rule.allowedAgentIds.length > 0;
    if (!hasUserRules && !hasAgentRules)
        return !rule.approvalRequired;
    if (hasUserRules && rule.allowedUserIds.includes(actorUserId))
        return true;
    if (hasAgentRules && actorAgentId && rule.allowedAgentIds.includes(actorAgentId))
        return true;
    return false;
}
function canActorRollbackSharedMemory(rule, actorUserId, actorAgentId) {
    if (!rule)
        return true;
    if (rule.rollbackAllowedUserIds.length > 0 && rule.rollbackAllowedUserIds.includes(actorUserId))
        return true;
    if (rule.rollbackAllowedAgentIds.length > 0 && actorAgentId && rule.rollbackAllowedAgentIds.includes(actorAgentId))
        return true;
    if (rule.rollbackAllowedUserIds.length === 0 && rule.rollbackAllowedAgentIds.length === 0) {
        return canActorWriteSharedMemory(rule, actorUserId, actorAgentId);
    }
    return false;
}
function resolveSharedMemoryApprovalOwner(params) {
    const candidates = [
        ...(params.rule?.approvalUserIds ?? []),
        ...(params.rule?.allowedUserIds ?? []),
        params.fallbackUserId ?? null,
        params.policy.defaultHumanOwnerUserId ?? null,
        params.policy.escalationOwnerUserId ?? null,
        params.actorUserId,
    ];
    return candidates.find((value) => typeof value === 'string' && value.trim().length > 0) ?? null;
}
async function ensureSharedMemoryApprovalTask(params) {
    if (!params.authorityRule?.approvalRequired)
        return null;
    const requestedForUserId = resolveSharedMemoryApprovalOwner({
        rule: params.authorityRule,
        policy: params.policy,
        fallbackUserId: params.fallbackRecipientUserId ?? null,
        actorUserId: params.actorUserId,
    });
    if (!requestedForUserId)
        return null;
    const existingTasks = await memoryStore.listTeamTasks({ workspaceId: params.workspaceId });
    const existing = existingTasks.find((task) => {
        if (isClosedTeamTask(task))
            return false;
        const metadata = task.metadata ?? {};
        return metadata['governanceKind'] === 'shared_memory_authority'
            && metadata['sharedMemoryAction'] === params.action
            && metadata['sharedMemoryKey'] === params.key
            && metadata['sharedMemoryApprovalStatus'] === 'pending';
    });
    const governanceMetadata = {
        requestUserId: params.actorUserId,
        requestChannel: params.channel,
        requestChatId: params.workspaceId,
        governanceKind: 'shared_memory_authority',
        sharedMemoryAction: params.action,
        sharedMemoryKey: params.key,
        sharedMemoryScopeUserId: params.userId,
        sharedMemoryScopeChannel: params.channel,
        sharedMemoryAuthorityPrefix: params.authorityRule.prefix,
        sharedMemoryApprovalRequired: true,
        sharedMemoryApprovalStatus: 'pending',
        sharedMemoryCurrentValue: params.currentValue ?? null,
        sharedMemoryIncomingValue: params.incomingValue ?? null,
        sharedMemoryExpectedVersion: params.expectedVersion ?? null,
        sharedMemoryCurrentVersion: params.currentVersion,
        sharedMemoryHistoryId: params.historyId ?? null,
        sharedMemoryReason: params.reason ?? null,
        sharedMemoryRequesterUserId: params.actorUserId,
        sharedMemoryRequesterAgentId: params.actorAgentId ?? null,
        sharedMemoryRequestedForUserId: requestedForUserId,
    };
    const title = `[Governance] Approve shared memory ${params.action}: ${params.key}`.slice(0, 120);
    const description = [
        `${params.action === 'write' ? 'Approve a protected shared memory write' : 'Approve a protected shared memory rollback'} for key ${params.key}.`,
        params.summary,
    ].join('\n\n').slice(0, 2000);
    const task = existing
        ? await memoryStore.updateTeamTask(existing.id, {
            status: 'blocked',
            priority: existing.priority,
            blockedReason: params.summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: params.summary.slice(0, 500),
            humanOwnerUserId: requestedForUserId,
            description,
            metadata: {
                ...(existing.metadata ?? {}),
                ...governanceMetadata,
            },
        })
        : await memoryStore.createTeamTask({
            workspaceId: params.workspaceId,
            title,
            description,
            status: 'blocked',
            priority: 'high',
            assignedAgentId: null,
            reviewRequired: false,
            reviewStatus: 'not_required',
            maxAttempts: 1,
            humanOwnerUserId: requestedForUserId,
            blockedReason: params.summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: params.summary.slice(0, 500),
            dueAt: new Date(Date.now() + params.policy.defaultTaskSlaHours * 3600 * 1000),
            createdBy: params.actorUserId,
            metadata: governanceMetadata,
        });
    if (!task)
        return null;
    await ensurePendingApprovalForTask(task, params.policy, params.summary);
    return task;
}
async function emitSharedMemoryGovernanceSignal(params) {
    const baseMetadata = {
        ...(params.metadata ?? {}),
        actorUserId: params.actorUserId,
        actorAgentId: params.actorAgentId ?? null,
    };
    if (params.conflictRecipientAgentId) {
        await createTeamMailboxMessageSafe({
            workspaceId: params.workspaceId,
            senderAgentId: params.actorAgentId ?? null,
            senderUserId: params.actorUserId,
            recipientAgentId: params.conflictRecipientAgentId,
            taskId: params.conflictTaskId ?? null,
            threadId: getTaskProtocolThreadId(params.conflictTaskId ?? params.key, 'task'),
            dedupeKey: buildMailboxDedupeKey(params.protocolKind, params.workspaceId, params.key, params.conflictTaskId ?? null, params.conflictRecipientAgentId),
            type: 'task_event',
            subject: params.title,
            message: params.summary,
            metadata: baseMetadata,
        });
    }
    if (params.conflictRecipientUserId) {
        await createTeamNotificationSafe({
            workspaceId: params.workspaceId,
            recipientUserId: params.conflictRecipientUserId,
            type: 'task_escalated',
            severity: params.severity ?? 'warning',
            title: params.title,
            message: params.summary,
            taskId: params.conflictTaskId ?? null,
            metadata: baseMetadata,
        });
    }
    if (!params.conflictTaskId || params.requestConsensus === false)
        return;
    const task = await memoryStore.getTeamTask(params.conflictTaskId);
    if (!task || isClosedTeamTask(task) || task.status === 'consensus_pending')
        return;
    const participants = getConsensusParticipants(task);
    if (participants.length === 0)
        return;
    await requestTeamTaskConsensusById({
        taskId: task.id,
        requesterAgentId: params.actorAgentId ?? (typeof (task.metadata ?? {})['topologySupervisorAgentId'] === 'string'
            ? (task.metadata ?? {})['topologySupervisorAgentId']
            : 'memory-governor'),
        summary: params.summary,
        participantAgentIds: participants,
        protocolMetadata: {
            protocolKind: params.protocolKind,
            conflictKey: params.key,
            ...baseMetadata,
        },
        threadId: getTaskProtocolThreadId(task.id, 'consensus'),
    });
}
function getTaskProtocolThreadId(taskId, lane = 'task') {
    return `${lane}:${taskId}`;
}
function getGlobalRuleLibraryScope(params) {
    return {
        userId: params.userId,
        channel: params.channel,
        workspaceId: GLOBAL_RULE_LIBRARY_WORKSPACE_ID,
    };
}
function findBehavioralRuleMatch(rules, query) {
    const normalized = query.trim().toLowerCase();
    if (!normalized)
        return null;
    return rules.find((entry) => entry.rule.toLowerCase() === normalized
        || entry.rule.toLowerCase().includes(normalized)
        || normalized.includes(entry.rule.toLowerCase())) ?? null;
}
function buildRuleLibraryGovernanceTaskKey(params) {
    return [
        params.userId,
        params.channel,
        params.action,
        normalizeKeyPart(params.rule),
        normalizeKeyPart(params.historyId ?? ''),
    ].join('::');
}
function computeWorkspaceRuleHealthMetrics(tasks) {
    const doneCount = tasks.filter((task) => task.status === 'done').length;
    const blockedCount = tasks.filter((task) => task.status === 'blocked' || task.status === 'escalated').length;
    const consensusTasks = tasks.filter((task) => {
        const consensus = task.metadata?.['consensus'];
        return Boolean(consensus && typeof consensus === 'object');
    });
    const timedOutConsensus = consensusTasks.filter((task) => {
        const consensus = task.metadata?.['consensus'];
        return consensus['resolution'] === 'timeout_escalated';
    });
    return {
        doneCount,
        blockedRate: tasks.length > 0 ? blockedCount / tasks.length : 0,
        consensusTimeoutRate: consensusTasks.length > 0 ? timedOutConsensus.length / consensusTasks.length : 0,
    };
}
function getConsensusParticipants(task) {
    const metadata = task.metadata ?? {};
    const workerPool = Array.isArray(metadata['topologyWorkerAgentIds'])
        ? metadata['topologyWorkerAgentIds']
            .filter((item) => typeof item === 'string' && item.trim().length > 0)
        : [];
    return dedupeStringList([
        task.assignedAgentId ?? null,
        task.reviewerAgentId ?? null,
        typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null,
        typeof metadata['lastChallengeAgentId'] === 'string' ? metadata['lastChallengeAgentId'] : null,
        ...workerPool,
    ].filter((item) => typeof item === 'string'));
}
async function computeAdaptiveConsensusParticipantWeights(params) {
    const topologyId = typeof (params.task.metadata ?? {})['topologyId'] === 'string'
        ? params.task.metadata['topologyId']
        : null;
    const workspaceTasks = await memoryStore.listTeamTasks({ workspaceId: params.task.workspaceId });
    const relevantTasks = workspaceTasks.filter((candidate) => {
        if (candidate.id === params.task.id)
            return false;
        if (!topologyId)
            return true;
        return typeof (candidate.metadata ?? {})['topologyId'] === 'string'
            && candidate.metadata['topologyId'] === topologyId;
    });
    const weights = {};
    for (const agentId of params.participantAgentIds) {
        const assignedWins = relevantTasks.filter((candidate) => {
            if (candidate.assignedAgentId !== agentId || candidate.status !== 'done')
                return false;
            const resolution = (candidate.metadata ?? {})['supervisorResolution']?.['decision']
                ?? (candidate.metadata ?? {})['consensus']?.['resolution'];
            return resolution !== 'changes_requested';
        }).length;
        const assignedLosses = relevantTasks.filter((candidate) => {
            if (candidate.assignedAgentId !== agentId)
                return false;
            const resolution = (candidate.metadata ?? {})['supervisorResolution']?.['decision']
                ?? (candidate.metadata ?? {})['consensus']?.['resolution'];
            return resolution === 'changes_requested';
        }).length;
        const challengeWins = relevantTasks.filter((candidate) => {
            const challenger = typeof (candidate.metadata ?? {})['lastChallengeAgentId'] === 'string'
                ? candidate.metadata['lastChallengeAgentId']
                : null;
            if (challenger !== agentId)
                return false;
            const resolution = (candidate.metadata ?? {})['supervisorResolution']?.['decision']
                ?? (candidate.metadata ?? {})['consensus']?.['resolution'];
            return resolution === 'changes_requested';
        }).length;
        const challengeLosses = relevantTasks.filter((candidate) => {
            const challenger = typeof (candidate.metadata ?? {})['lastChallengeAgentId'] === 'string'
                ? candidate.metadata['lastChallengeAgentId']
                : null;
            if (challenger !== agentId)
                return false;
            const resolution = (candidate.metadata ?? {})['supervisorResolution']?.['decision']
                ?? (candidate.metadata ?? {})['consensus']?.['resolution'];
            return resolution === 'approve' || resolution === 'approved';
        }).length;
        const rawWeight = 1
            + assignedWins * 0.05
            + challengeWins * 0.2
            - assignedLosses * 0.1
            - challengeLosses * 0.05;
        weights[agentId] = Math.round(Math.min(2.5, Math.max(0.75, rawWeight)) * 100) / 100;
    }
    return weights;
}
function getProtocolDeliberationMaxRounds(policy, topology) {
    const topologyRaw = Number((topology?.metadata ?? {})['consensusDeliberationMaxRounds']);
    const policyRaw = Number((policy.metadata ?? {})['consensusDeliberationMaxRounds']);
    const configured = Number.isFinite(topologyRaw)
        ? topologyRaw
        : (Number.isFinite(policyRaw) ? policyRaw : 1);
    const consensusTimeoutRate = Number((topology?.metadata ?? {})['lastOrchMetrics'] && typeof (topology?.metadata ?? {})['lastOrchMetrics'] === 'object'
        ? (topology?.metadata ?? {})['lastOrchMetrics']['consensusTimeoutRate']
        : NaN);
    if (Number.isFinite(consensusTimeoutRate) && consensusTimeoutRate >= 0.3) {
        return 0;
    }
    return Math.max(0, Math.min(3, Math.floor(configured)));
}
function buildConsensusDeliberationSummary(params) {
    const approvals = params.responses
        .filter((response) => response.decision === 'approve')
        .map((response) => `${response.agentId}[w=${response.weight}]: ${response.rationale}`);
    const objections = params.responses
        .filter((response) => response.decision === 'changes_requested')
        .map((response) => `${response.agentId}[w=${response.weight}]: ${response.rationale}`);
    return [
        `Deliberation round ${params.round} for task ${params.task.title}.`,
        'There is disagreement in the team. Reconsider the strongest arguments from both sides, then send an updated consensus_response.',
        approvals.length > 0 ? `Approve side:\n${approvals.join('\n')}` : null,
        objections.length > 0 ? `Changes requested side:\n${objections.join('\n')}` : null,
    ].filter(Boolean).join('\n\n').slice(0, 2000);
}
function buildConsensusDebatePrompt(params) {
    return [
        `Debate round ${params.round} for task ${params.task.title}.`,
        'You must address at least one opposing argument directly before restating your final position.',
        'Reply with a consensus_response that includes your decision and a concise rationale.',
        buildConsensusDeliberationSummary(params),
    ].join('\n\n').slice(0, 2200);
}
function buildConsensusRevotePrompt(params) {
    const debateLines = params.debateResponses.map((response) => `${response.agentId}[w=${response.weight} | ${response.decision}]: ${response.rationale}`);
    return [
        `Revote round ${params.round} for task ${params.task.title}.`,
        'The team has exchanged arguments. Cast your updated vote now.',
        debateLines.length > 0 ? `Debate transcript:\n${debateLines.join('\n')}` : null,
        'Send one consensus_response with your final decision and concise rationale.',
    ].filter(Boolean).join('\n\n').slice(0, 2200);
}
function getLatestChallengeSummary(task) {
    const metadata = task.metadata ?? {};
    const challenges = Array.isArray(metadata['challenges']) ? metadata['challenges'] : [];
    const latest = challenges[challenges.length - 1];
    return typeof latest?.['summary'] === 'string' && latest.summary.trim()
        ? latest.summary.trim().slice(0, 500)
        : `Consensus needed for task ${task.title}`;
}
function normalizeConsensusDecision(value) {
    if (typeof value !== 'string')
        return null;
    const normalized = value.trim().toLowerCase();
    if (normalized === 'approve' || normalized === 'approved' || normalized === 'agree') {
        return 'approve';
    }
    if (normalized === 'changes_requested'
        || normalized === 'changes-requested'
        || normalized === 'reject'
        || normalized === 'rejected'
        || normalized === 'blocked'
        || normalized === 'object'
        || normalized === 'disagree') {
        return 'changes_requested';
    }
    return null;
}
function parseConsensusDecision(message) {
    const metadata = message.metadata ?? {};
    const metadataDecision = normalizeConsensusDecision(metadata['decision']);
    if (metadataDecision)
        return metadataDecision;
    const body = message.message.toLowerCase();
    if (/\b(changes requested|changes_requested|reject|blocked|object|disagree)\b/.test(body)) {
        return 'changes_requested';
    }
    return 'approve';
}
function parseConsensusRationale(message) {
    const metadata = message.metadata ?? {};
    const metadataRationale = typeof metadata['rationale'] === 'string' ? metadata['rationale'].trim() : '';
    if (metadataRationale)
        return metadataRationale.slice(0, 180);
    return message.message.slice(0, 180);
}
function parseConsensusVoteWeight(message, participantWeights) {
    const metadata = message.metadata ?? {};
    const explicit = Number(metadata['voteWeight']);
    if (Number.isFinite(explicit) && explicit > 0)
        return explicit;
    if (message.senderAgentId && participantWeights && Number.isFinite(Number(participantWeights[message.senderAgentId]))) {
        const weighted = Number(participantWeights[message.senderAgentId]);
        if (weighted > 0)
            return weighted;
    }
    return 1;
}
function parseApprovalRoutingLevels(task, approval) {
    const metadata = task.metadata ?? {};
    const rawLevels = Array.isArray(metadata['approvalRoutingLevels']) ? metadata['approvalRoutingLevels'] : [];
    const parsed = rawLevels
        .filter((entry) => Boolean(entry) && typeof entry === 'object' && !Array.isArray(entry))
        .map((entry, index) => ({
        level: Number.isFinite(Number(entry['level'])) ? Math.max(0, Math.floor(Number(entry['level']))) : index,
        approverUserIds: Array.isArray(entry['approverUserIds'])
            ? entry['approverUserIds'].filter((item) => typeof item === 'string' && item.trim().length > 0).map((item) => item.trim())
            : [],
        approverRoleGroups: Array.isArray(entry['approverRoleGroups'])
            ? entry['approverRoleGroups'].filter((item) => typeof item === 'string' && item.trim().length > 0).map((item) => item.trim())
            : [],
        effectiveApproverUserIds: Array.isArray(entry['effectiveApproverUserIds'])
            ? entry['effectiveApproverUserIds'].filter((item) => typeof item === 'string' && item.trim().length > 0).map((item) => item.trim())
            : [],
        primaryApproverUserId: typeof entry['primaryApproverUserId'] === 'string' && entry['primaryApproverUserId'].trim()
            ? entry['primaryApproverUserId'].trim()
            : null,
        reminderAfterMinutes: Number.isFinite(Number(entry['reminderAfterMinutes'])) ? Math.max(1, Math.floor(Number(entry['reminderAfterMinutes']))) : null,
        escalationAfterMinutes: Number.isFinite(Number(entry['escalationAfterMinutes'])) ? Math.max(1, Math.floor(Number(entry['escalationAfterMinutes']))) : null,
        label: typeof entry['label'] === 'string' && entry['label'].trim() ? entry['label'].trim() : null,
    }))
        .sort((a, b) => a.level - b.level);
    if (parsed.length > 0)
        return parsed;
    return [{
            level: 0,
            approverUserIds: [approval.requestedForUserId],
            approverRoleGroups: [],
            effectiveApproverUserIds: [approval.requestedForUserId],
            primaryApproverUserId: approval.requestedForUserId,
            reminderAfterMinutes: null,
            escalationAfterMinutes: null,
            label: 'initial',
        }];
}
function resolveApprovalRoutingState(task, approval, policy) {
    const metadata = task.metadata ?? {};
    const levels = parseApprovalRoutingLevels(task, approval);
    let currentLevelIndex = Number.isFinite(Number(metadata['approvalCurrentLevelIndex']))
        ? Math.max(0, Math.min(levels.length - 1, Math.floor(Number(metadata['approvalCurrentLevelIndex']))))
        : levels.findIndex((level) => level.primaryApproverUserId === approval.requestedForUserId);
    if (currentLevelIndex < 0
        || ((levels[currentLevelIndex]?.primaryApproverUserId !== approval.requestedForUserId)
            && !(levels[currentLevelIndex]?.effectiveApproverUserIds.includes(approval.requestedForUserId)))) {
        currentLevelIndex = levels.findIndex((level) => level.primaryApproverUserId === approval.requestedForUserId);
    }
    if (currentLevelIndex < 0) {
        currentLevelIndex = levels.findIndex((level) => level.effectiveApproverUserIds.includes(approval.requestedForUserId));
    }
    if (currentLevelIndex < 0)
        currentLevelIndex = 0;
    const currentLevel = levels[currentLevelIndex] ?? levels[0];
    const nextLevel = levels.slice(currentLevelIndex + 1)
        .find((level) => level.primaryApproverUserId && level.primaryApproverUserId !== approval.requestedForUserId) ?? null;
    const levelStartedAtMs = typeof metadata['approvalCurrentLevelStartedAt'] === 'string'
        ? Date.parse(metadata['approvalCurrentLevelStartedAt'])
        : Number.NaN;
    return {
        levels,
        currentLevelIndex,
        currentLevel,
        nextLevel,
        levelStartedAtMs: Number.isFinite(levelStartedAtMs) ? levelStartedAtMs : approval.createdAt.getTime(),
        reminderAfterMinutes: currentLevel.reminderAfterMinutes ?? policy.approvalReminderAfterMinutes,
        escalationAfterMinutes: currentLevel.escalationAfterMinutes ?? policy.approvalEscalationAfterMinutes,
    };
}
function resolveApprovalEscalationTarget(task, approval, policy) {
    const routing = resolveApprovalRoutingState(task, approval, policy);
    if (routing.nextLevel?.primaryApproverUserId) {
        return {
            recipientUserId: routing.nextLevel.primaryApproverUserId,
            approverUserIds: routing.nextLevel.approverUserIds,
            approverRoleGroups: routing.nextLevel.approverRoleGroups,
            effectiveApproverUserIds: routing.nextLevel.effectiveApproverUserIds.length > 0
                ? routing.nextLevel.effectiveApproverUserIds
                : [routing.nextLevel.primaryApproverUserId],
            levelIndex: routing.currentLevelIndex + 1,
            label: routing.nextLevel.label,
            reminderAfterMinutes: routing.nextLevel.reminderAfterMinutes ?? policy.approvalReminderAfterMinutes,
            escalationAfterMinutes: routing.nextLevel.escalationAfterMinutes ?? policy.approvalEscalationAfterMinutes,
        };
    }
    const fallbackRecipient = policy.escalationOwnerUserId ?? task.createdBy ?? null;
    if (!fallbackRecipient || fallbackRecipient === approval.requestedForUserId)
        return null;
    return {
        recipientUserId: fallbackRecipient,
        approverUserIds: [fallbackRecipient],
        approverRoleGroups: [],
        effectiveApproverUserIds: [fallbackRecipient],
        levelIndex: null,
        label: 'fallback',
        reminderAfterMinutes: policy.approvalReminderAfterMinutes,
        escalationAfterMinutes: policy.approvalEscalationAfterMinutes,
    };
}
export function resolveApprovalEscalationRecipient(task, approval, policy) {
    return resolveApprovalEscalationTarget(task, approval, policy)?.recipientUserId ?? null;
}
export function resolveOnCallAgentId(rotation, level, at = Date.now()) {
    const pool = level === 'primary' ? rotation.primaryAgentIds : rotation.secondaryAgentIds;
    if (!pool || pool.length === 0)
        return null;
    const anchor = rotation.anchorDate.getTime();
    const diffMs = Math.max(0, at - anchor);
    const periodMs = rotation.scheduleType === 'weekly' ? 7 * 24 * 3600 * 1000 : 24 * 3600 * 1000;
    const slot = Math.floor(diffMs / periodMs);
    return pool[slot % pool.length] ?? null;
}
export function resolveNextOnCallAgentId(rotation, level, activeAgentIds, currentAgentId, at = Date.now()) {
    const pool = level === 'primary' ? rotation.primaryAgentIds : rotation.secondaryAgentIds;
    if (!pool || pool.length === 0)
        return null;
    const activeSet = new Set(activeAgentIds);
    if (activeSet.size === 0)
        return null;
    const anchor = rotation.anchorDate.getTime();
    const diffMs = Math.max(0, at - anchor);
    const periodMs = rotation.scheduleType === 'weekly' ? 7 * 24 * 3600 * 1000 : 24 * 3600 * 1000;
    const startIndex = Math.floor(diffMs / periodMs) % pool.length;
    const orderedPool = pool.slice(startIndex).concat(pool.slice(0, startIndex));
    const activePool = orderedPool.filter((agentId) => activeSet.has(agentId));
    if (activePool.length === 0)
        return null;
    if (!currentAgentId)
        return activePool[0] ?? null;
    const currentIndex = activePool.indexOf(currentAgentId);
    if (currentIndex < 0)
        return activePool[0] ?? null;
    if (activePool.length === 1)
        return activePool[0] ?? null;
    return activePool[(currentIndex + 1) % activePool.length] ?? null;
}
async function resolveApplicableOnCallRotation(task) {
    const all = await memoryStore.listTeamOnCallRotations({ workspaceId: task.workspaceId, enabled: true });
    if (all.length === 0)
        return null;
    const metadata = task.metadata ?? {};
    const department = normalizeKeyPart(typeof metadata['templateDepartment'] === 'string' ? metadata['templateDepartment'] : null);
    const role = normalizeKeyPart(typeof metadata['templateRole'] === 'string' ? metadata['templateRole'] : null);
    const scored = all.map((rotation) => {
        const rotationDepartment = normalizeKeyPart(rotation.department);
        const rotationRole = normalizeKeyPart(rotation.role);
        const departmentMatch = rotationDepartment && department && rotationDepartment === department;
        const roleMatch = rotationRole && role && rotationRole === role;
        const wildcardDepartment = !rotationDepartment;
        const wildcardRole = !rotationRole;
        const eligible = (departmentMatch || wildcardDepartment)
            && (roleMatch || wildcardRole);
        const score = (departmentMatch ? 2 : 0) + (roleMatch ? 2 : 0) + (wildcardDepartment ? 0 : -1) + (wildcardRole ? 0 : -1);
        return { rotation, eligible, score };
    }).filter((item) => item.eligible);
    if (scored.length === 0)
        return all[0] ?? null;
    scored.sort((a, b) => b.score - a.score || b.rotation.updatedAt.getTime() - a.rotation.updatedAt.getTime());
    return scored[0]?.rotation ?? null;
}
async function hasNotificationForApproval(approval, type) {
    const notifications = await memoryStore.listTeamNotifications({
        workspaceId: approval.workspaceId,
        approvalId: approval.id,
        type,
    });
    return notifications.length > 0;
}
async function hasPendingApprovalForUser(taskId, requestedForUserId) {
    const approvals = await memoryStore.listTeamTaskApprovals({
        taskId,
        status: 'pending',
        requestedForUserId,
    });
    return approvals.length > 0;
}
function getTaskApprovalBroadcastRecipients(task, primaryRecipientUserId) {
    const metadata = task.metadata ?? {};
    const sources = [
        metadata['approvalBroadcastUserIds'],
        metadata['topologyControlEffectiveApproverUserIds'],
        metadata['candidatePromotionEffectiveApproverUserIds'],
    ];
    const recipients = sources.flatMap((value) => Array.isArray(value)
        ? value.filter((item) => typeof item === 'string' && item.trim().length > 0).map((item) => item.trim())
        : []);
    return Array.from(new Set(recipients.filter((userId) => userId !== primaryRecipientUserId)));
}
function getApprovalResolvedRecipients(task, approval) {
    return Array.from(new Set([
        approval.requestedForUserId,
        ...getTaskApprovalBroadcastRecipients(task, task.createdBy),
    ].filter((userId) => userId && userId !== task.createdBy)));
}
function applyEscalatedApprovalAudienceMetadata(task, target, baseMetadata) {
    const governanceKind = (task.metadata ?? {})['governanceKind'];
    if (governanceKind === 'topology_control_action') {
        return {
            ...baseMetadata,
            topologyControlApproverUserIds: target.approverUserIds,
            topologyControlApproverRoleGroups: target.approverRoleGroups,
            topologyControlEffectiveApproverUserIds: target.effectiveApproverUserIds,
            topologyControlRequestedForUserId: target.recipientUserId,
        };
    }
    if (governanceKind === 'topology_candidate_promotion') {
        return {
            ...baseMetadata,
            candidatePromotionApproverUserIds: target.approverUserIds,
            candidatePromotionApproverRoleGroups: target.approverRoleGroups,
            candidatePromotionEffectiveApproverUserIds: target.effectiveApproverUserIds,
            candidatePromotionRequestedForUserId: target.recipientUserId,
        };
    }
    return baseMetadata;
}
async function ensureOnCallFollowupTask(params) {
    const existingTasks = await memoryStore.listTeamTasks({ workspaceId: params.sourceTask.workspaceId });
    const existing = existingTasks.find((task) => {
        if (isClosedTeamTask(task))
            return false;
        const metadata = task.metadata ?? {};
        return metadata['onCallApprovalId'] === params.approval.id
            && metadata['onCallLevel'] === params.level;
    });
    const description = [
        `Follow up on pending approval ${params.approval.id}.`,
        `Original task: ${params.sourceTask.title} (${params.sourceTask.id})`,
        `Pending approver: ${params.approval.requestedForUserId}`,
        `Reason: ${params.reason}`,
        'Review context, investigate blockers, and produce an actionable recommendation or remediation summary.',
    ].join('\n');
    if (existing) {
        return memoryStore.updateTeamTask(existing.id, {
            assignedAgentId: params.agentId,
            status: 'claimed',
            blockedReason: null,
            description,
            metadata: {
                ...(existing.metadata ?? {}),
                onCallAgentId: params.agentId,
                onCallReason: params.reason,
                onCallAssignedAt: new Date().toISOString(),
            },
        });
    }
    return memoryStore.createTeamTask({
        workspaceId: params.sourceTask.workspaceId,
        title: `[OnCall:${params.level}] Approval ${params.approval.id} follow-up`,
        description,
        status: 'claimed',
        priority: params.level === 'secondary' ? 'critical' : 'high',
        assignedAgentId: params.agentId,
        reviewRequired: false,
        reviewStatus: 'not_required',
        maxAttempts: Math.max(1, params.policy.maxAutoRetries + 1),
        humanOwnerUserId: params.sourceTask.humanOwnerUserId ?? params.policy.defaultHumanOwnerUserId ?? params.sourceTask.createdBy,
        dueAt: new Date(Date.now() + params.policy.defaultTaskSlaHours * 3600 * 1000),
        createdBy: params.sourceTask.createdBy,
        metadata: {
            requestUserId: params.sourceTask.createdBy,
            requestChannel: 'web',
            requestChatId: params.sourceTask.workspaceId,
            onCallApprovalId: params.approval.id,
            onCallSourceTaskId: params.sourceTask.id,
            onCallLevel: params.level,
            onCallAgentId: params.agentId,
            onCallReason: params.reason,
            onCallAssignedAt: new Date().toISOString(),
            onCallHandoffCount: 0,
            templateDepartment: (params.sourceTask.metadata ?? {})['templateDepartment'] ?? null,
            templateRole: (params.sourceTask.metadata ?? {})['templateRole'] ?? null,
        },
    });
}
function parseOnCallLevel(value) {
    return value === 'primary' || value === 'secondary' ? value : null;
}
function parseOnCallTimestamp(value, fallback) {
    if (value instanceof Date && !Number.isNaN(value.getTime()))
        return value.getTime();
    if (typeof value === 'number' && Number.isFinite(value))
        return value;
    if (typeof value === 'string' && value.trim()) {
        const parsed = Date.parse(value);
        if (!Number.isNaN(parsed))
            return parsed;
    }
    return fallback.getTime();
}
function parseOnCallHandoffCount(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 0;
}
function getProtocolAnnouncementTimeoutMinutes(policy) {
    const raw = Number((policy.metadata ?? {})['protocolAnnouncementTimeoutMinutes']);
    return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : DEFAULT_PROTOCOL_ANNOUNCEMENT_TIMEOUT_MINUTES;
}
function getProtocolConsensusTimeoutMinutes(policy) {
    const raw = Number((policy.metadata ?? {})['protocolConsensusTimeoutMinutes']);
    return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : DEFAULT_PROTOCOL_CONSENSUS_TIMEOUT_MINUTES;
}
function renderTeamNotificationMessage(notification) {
    const metadata = notification.metadata ?? {};
    const actionUrl = typeof metadata['actionUrl'] === 'string' ? metadata['actionUrl'].trim() : '';
    const actionLabel = typeof metadata['actionLabel'] === 'string' ? metadata['actionLabel'].trim() : 'Open in GreenFrog';
    return [
        `[${notification.severity.toUpperCase()}] ${notification.title}`,
        notification.message,
        notification.taskId ? `Task: ${notification.taskId}` : null,
        notification.approvalId ? `Approval: ${notification.approvalId}` : null,
        `Workspace: ${notification.workspaceId}`,
        `Recipient: ${notification.recipientUserId}`,
        actionUrl ? `${actionLabel}: ${actionUrl}` : null,
    ].filter(Boolean).join('\n');
}
function getTeamNotificationRetryDelayMs(attemptCount) {
    return Math.min(5 * 60_000, Math.max(15_000, 15_000 * Math.pow(2, Math.max(0, attemptCount - 1))));
}
export function isTeamNotificationRetryDue(notification, now = Date.now()) {
    if (notification.deliveryStatus === 'sent')
        return false;
    if (notification.status === 'archived')
        return false;
    if (notification.deliveryAttemptCount >= 5)
        return false;
    if (!notification.lastDeliveryAttemptAt)
        return true;
    return notification.lastDeliveryAttemptAt.getTime() + getTeamNotificationRetryDelayMs(notification.deliveryAttemptCount) <= now;
}
function normalizeNotificationRouteFilterList(value) {
    if (typeof value === 'string' && value.trim())
        return [value.trim()];
    if (!Array.isArray(value))
        return [];
    return value
        .filter((item) => typeof item === 'string' && item.trim().length > 0)
        .map((item) => item.trim());
}
function matchesNotificationRouteFilter(actual, allowed) {
    if (allowed.length === 0)
        return true;
    if (!actual)
        return false;
    return allowed.includes(actual);
}
export function doesNotificationRouteMatch(route, notification) {
    const routeMetadata = route.metadata ?? {};
    const notificationMetadata = notification.metadata ?? {};
    const notificationTypes = normalizeNotificationRouteFilterList(routeMetadata['notificationTypes'] ?? routeMetadata['notificationType'] ?? routeMetadata['types'] ?? routeMetadata['type']);
    const governanceKinds = normalizeNotificationRouteFilterList(routeMetadata['governanceKinds'] ?? routeMetadata['governanceKind']);
    const topologyControlActions = normalizeNotificationRouteFilterList(routeMetadata['topologyControlActions'] ?? routeMetadata['topologyControlAction']);
    const topologyIds = normalizeNotificationRouteFilterList(routeMetadata['topologyIds'] ?? routeMetadata['topologyId']);
    const severities = normalizeNotificationRouteFilterList(routeMetadata['severities'] ?? routeMetadata['severity']);
    return matchesNotificationRouteFilter(notification.type, notificationTypes)
        && matchesNotificationRouteFilter(typeof notificationMetadata['governanceKind'] === 'string' ? notificationMetadata['governanceKind'] : null, governanceKinds)
        && matchesNotificationRouteFilter(typeof notificationMetadata['topologyControlAction'] === 'string' ? notificationMetadata['topologyControlAction'] : null, topologyControlActions)
        && matchesNotificationRouteFilter(typeof notificationMetadata['topologyId'] === 'string' ? notificationMetadata['topologyId'] : null, topologyIds)
        && matchesNotificationRouteFilter(notification.severity, severities);
}
function normalizeAdditionalNotificationRecipients(value) {
    if (typeof value === 'string' && value.trim())
        return [value.trim()];
    if (!Array.isArray(value))
        return [];
    return value
        .filter((item) => typeof item === 'string' && item.trim().length > 0)
        .map((item) => item.trim());
}
export async function deliverTeamNotification(notification) {
    const metadata = notification.metadata ?? {};
    const routeRecipients = Array.from(new Set([
        notification.recipientUserId,
        ...normalizeAdditionalNotificationRecipients(metadata['additionalRecipientUserIds']),
    ].filter((value) => typeof value === 'string' && value.trim().length > 0)));
    const candidateRoutes = (await Promise.all(routeRecipients.map((recipientUserId) => memoryStore.listTeamNotificationRoutes({
        workspaceId: notification.workspaceId,
        recipientUserId,
        enabled: true,
    })))).flat();
    const routes = candidateRoutes.filter((route) => doesNotificationRouteMatch(route, notification));
    const fallbackChannel = typeof metadata['deliveryChannel'] === 'string' ? metadata['deliveryChannel'] : '';
    const fallbackChatId = typeof metadata['deliveryChatId'] === 'string' ? metadata['deliveryChatId'] : '';
    const targets = [
        ...routes.map((route) => ({
            id: route.id,
            channel: route.channel,
            chatId: route.chatId,
            source: 'route',
        })),
        ...(fallbackChannel && fallbackChatId ? [{
                id: `fallback:${fallbackChannel}:${fallbackChatId}`,
                channel: fallbackChannel,
                chatId: fallbackChatId,
                source: 'fallback',
            }] : []),
    ].filter((target, index, items) => items.findIndex((candidate) => candidate.channel === target.channel && candidate.chatId === target.chatId) === index);
    const attemptCount = notification.deliveryAttemptCount + 1;
    const attemptAt = new Date();
    if (targets.length === 0) {
        return (await memoryStore.updateTeamNotification(notification.id, {
            deliveryStatus: 'failed',
            deliveryAttemptCount: attemptCount,
            lastDeliveryError: 'no_enabled_routes',
            lastDeliveryAttemptAt: attemptAt,
            deliveredAt: null,
        })) ?? notification;
    }
    const { channelManager } = await import('../channels/index.js');
    const status = channelManager.getStatus();
    const message = renderTeamNotificationMessage(notification);
    const deliveryResults = [];
    for (const target of targets) {
        if (!status[target.channel]) {
            deliveryResults.push({
                routeId: target.id,
                channel: target.channel,
                chatId: target.chatId,
                source: target.source,
                ok: false,
                error: 'channel_not_running',
            });
            continue;
        }
        try {
            await channelManager.send(target.channel, {
                text: message,
                chatId: target.chatId,
            });
            deliveryResults.push({
                routeId: target.id,
                channel: target.channel,
                chatId: target.chatId,
                source: target.source,
                ok: true,
            });
        }
        catch (err) {
            deliveryResults.push({
                routeId: target.id,
                channel: target.channel,
                chatId: target.chatId,
                source: target.source,
                ok: false,
                error: String(err),
            });
        }
    }
    const okCount = deliveryResults.filter((item) => item['ok'] === true).length;
    const errorList = deliveryResults
        .filter((item) => item['ok'] !== true)
        .map((item) => String(item['error'] ?? 'delivery_failed'));
    const deliveryStatus = okCount === deliveryResults.length
        ? 'sent'
        : okCount > 0
            ? 'partial'
            : 'failed';
    return (await memoryStore.updateTeamNotification(notification.id, {
        deliveryStatus,
        deliveryAttemptCount: attemptCount,
        lastDeliveryError: errorList.length > 0 ? errorList.join('; ').slice(0, 500) : null,
        metadata: {
            ...metadata,
            deliveryResults,
            deliveryUpdatedAt: new Date().toISOString(),
        },
        lastDeliveryAttemptAt: attemptAt,
        deliveredAt: deliveryStatus === 'sent' ? attemptAt : null,
    })) ?? notification;
}
export async function retryPendingTeamNotifications(limit = 50) {
    const notifications = await memoryStore.listTeamNotifications();
    let processed = 0;
    for (const notification of notifications) {
        if (processed >= limit)
            break;
        if (!isTeamNotificationRetryDue(notification))
            continue;
        await deliverTeamNotification(notification);
        processed++;
    }
    return processed;
}
export async function writeTeamSharedMemoryEntry(params) {
    const scope = { userId: params.userId, channel: params.channel, workspaceId: params.workspaceId };
    const oldValue = await memoryStore.getScopedMemory(scope, params.key);
    const versionKey = buildTeamSharedMemoryVersionKey(params.key);
    const versionRaw = await memoryStore.getScopedMemory(scope, versionKey);
    const currentVersion = Math.max(0, Number(versionRaw ?? 0) || 0);
    const policy = await getEffectiveTeamPolicy(params.workspaceId, params.actorUserId);
    const authorityRule = resolveSharedMemoryAuthorityRule(policy, params.key);
    const unauthorized = !params.authorityOverride && !canActorWriteSharedMemory(authorityRule, params.actorUserId, params.actorAgentId ?? null);
    if (unauthorized) {
        const unauthorizedSummary = [
            `Shared memory write blocked for ${params.key}.`,
            authorityRule?.prefix ? `Protected prefix: ${authorityRule.prefix}` : null,
            authorityRule?.approvalRequired ? 'Direct write requires authority approval.' : null,
            oldValue ? `Current value: ${oldValue.slice(0, 240)}` : null,
            `Incoming value: ${params.value.slice(0, 240)}`,
            params.actorAgentId ? `Actor agent: ${params.actorAgentId}` : null,
            `Actor user: ${params.actorUserId}`,
        ].filter(Boolean).join('\n');
        await emitSharedMemoryGovernanceSignal({
            workspaceId: params.workspaceId,
            key: params.key,
            title: params.conflictTitle ?? `Shared memory authority violation: ${params.key}`,
            summary: unauthorizedSummary,
            actorUserId: params.actorUserId,
            actorAgentId: params.actorAgentId ?? null,
            conflictTaskId: params.conflictTaskId ?? null,
            conflictRecipientUserId: params.conflictRecipientUserId ?? null,
            conflictRecipientAgentId: params.conflictRecipientAgentId ?? null,
            severity: authorityRule?.approvalRequired ? 'critical' : 'warning',
            protocolKind: 'memory_authority_violation',
            metadata: {
                authorityPrefix: authorityRule?.prefix ?? null,
                approvalRequired: Boolean(authorityRule?.approvalRequired),
                expectedVersion: params.expectedVersion ?? null,
                currentVersion,
                previousValue: oldValue?.slice(0, 500) ?? null,
                incomingValue: params.value.slice(0, 500),
            },
        });
        await ensureSharedMemoryApprovalTask({
            workspaceId: params.workspaceId,
            userId: params.userId,
            channel: params.channel,
            key: params.key,
            action: 'write',
            actorUserId: params.actorUserId,
            actorAgentId: params.actorAgentId ?? null,
            policy,
            authorityRule,
            summary: unauthorizedSummary,
            currentValue: oldValue,
            incomingValue: params.value,
            expectedVersion: params.expectedVersion ?? null,
            currentVersion,
            fallbackRecipientUserId: params.conflictRecipientUserId ?? null,
        });
        return {
            conflictDetected: true,
            versionConflict: false,
            applied: false,
            currentVersion,
            nextVersion: currentVersion,
            unauthorized: true,
            authorityPrefix: authorityRule?.prefix ?? null,
            approvalRequired: Boolean(authorityRule?.approvalRequired),
        };
    }
    const versionConflict = params.expectedVersion !== undefined && params.expectedVersion !== null && params.expectedVersion !== currentVersion;
    const valueConflict = Boolean(oldValue && oldValue !== params.value);
    const conflictDetected = versionConflict || valueConflict;
    if (conflictDetected) {
        const history = (await memoryStore.getScopedMemoryHistory(scope, 20)).find((entry) => entry.key === params.key);
        const conflictSummary = [
            `Shared memory conflict detected for ${params.key}.`,
            versionConflict ? `Expected version ${params.expectedVersion}, current version ${currentVersion}.` : null,
            oldValue ? `Previous value: ${oldValue.slice(0, 240)}` : null,
            `Incoming value: ${params.value.slice(0, 240)}`,
            history?.created_at ? `Previous update at: ${history.created_at}` : null,
            params.actorAgentId ? `Actor agent: ${params.actorAgentId}` : null,
            `Actor user: ${params.actorUserId}`,
        ].filter(Boolean).join('\n');
        await emitSharedMemoryGovernanceSignal({
            workspaceId: params.workspaceId,
            key: params.key,
            title: params.conflictTitle ?? `Shared memory conflict: ${params.key}`,
            summary: conflictSummary,
            actorUserId: params.actorUserId,
            actorAgentId: params.actorAgentId ?? null,
            conflictTaskId: params.conflictTaskId ?? null,
            conflictRecipientUserId: params.conflictRecipientUserId ?? null,
            conflictRecipientAgentId: params.conflictRecipientAgentId ?? null,
            severity: 'warning',
            protocolKind: 'memory_conflict',
            metadata: {
                expectedVersion: params.expectedVersion ?? null,
                currentVersion,
                previousValue: oldValue?.slice(0, 500) ?? null,
                incomingValue: params.value.slice(0, 500),
            },
        });
    }
    if (versionConflict) {
        return {
            conflictDetected: true,
            versionConflict: true,
            applied: false,
            currentVersion,
            nextVersion: currentVersion,
            unauthorized: false,
            authorityPrefix: authorityRule?.prefix ?? null,
            approvalRequired: Boolean(authorityRule?.approvalRequired),
        };
    }
    await memoryStore.recordScopedMemoryChange(scope, params.key, oldValue, params.value, 'manual');
    await memoryStore.setScopedMemory(scope, params.key, params.value);
    const nextVersion = currentVersion + 1;
    await memoryStore.setScopedMemory(scope, versionKey, String(nextVersion));
    return {
        conflictDetected,
        versionConflict: false,
        applied: true,
        currentVersion,
        nextVersion,
        unauthorized: false,
        authorityPrefix: authorityRule?.prefix ?? null,
        approvalRequired: Boolean(authorityRule?.approvalRequired),
    };
}
export async function rollbackTeamSharedMemoryEntry(params) {
    const scope = { userId: params.userId, channel: params.channel, workspaceId: params.workspaceId };
    const versionKey = buildTeamSharedMemoryVersionKey(params.key);
    const versionRaw = await memoryStore.getScopedMemory(scope, versionKey);
    const currentVersion = Math.max(0, Number(versionRaw ?? 0) || 0);
    const currentValue = await memoryStore.getScopedMemory(scope, params.key);
    const policy = await getEffectiveTeamPolicy(params.workspaceId, params.actorUserId);
    const authorityRule = resolveSharedMemoryAuthorityRule(policy, params.key);
    if (isTeamSharedMemoryMetaKey(params.key)) {
        return {
            ok: false,
            applied: false,
            unauthorized: false,
            currentVersion,
            nextVersion: currentVersion,
            historyId: null,
            key: params.key,
            value: currentValue,
            authorityPrefix: authorityRule?.prefix ?? null,
            approvalRequired: Boolean(authorityRule?.approvalRequired),
        };
    }
    const unauthorized = !params.authorityOverride && !canActorRollbackSharedMemory(authorityRule, params.actorUserId, params.actorAgentId ?? null);
    if (unauthorized) {
        const summary = [
            `Shared memory rollback blocked for ${params.key}.`,
            authorityRule?.prefix ? `Protected prefix: ${authorityRule.prefix}` : null,
            authorityRule?.approvalRequired ? 'Rollback requires authority approval.' : null,
            currentValue ? `Current value: ${currentValue.slice(0, 240)}` : null,
            params.reason ? `Reason: ${params.reason.slice(0, 240)}` : null,
            params.actorAgentId ? `Actor agent: ${params.actorAgentId}` : null,
            `Actor user: ${params.actorUserId}`,
        ].filter(Boolean).join('\n');
        await emitSharedMemoryGovernanceSignal({
            workspaceId: params.workspaceId,
            key: params.key,
            title: params.conflictTitle ?? `Shared memory rollback blocked: ${params.key}`,
            summary,
            actorUserId: params.actorUserId,
            actorAgentId: params.actorAgentId ?? null,
            conflictTaskId: params.conflictTaskId ?? null,
            conflictRecipientUserId: params.conflictRecipientUserId ?? null,
            conflictRecipientAgentId: params.conflictRecipientAgentId ?? null,
            severity: authorityRule?.approvalRequired ? 'critical' : 'warning',
            protocolKind: 'memory_rollback_denied',
            metadata: {
                authorityPrefix: authorityRule?.prefix ?? null,
                approvalRequired: Boolean(authorityRule?.approvalRequired),
                reason: params.reason ?? null,
                currentVersion,
                currentValue: currentValue?.slice(0, 500) ?? null,
            },
        });
        await ensureSharedMemoryApprovalTask({
            workspaceId: params.workspaceId,
            userId: params.userId,
            channel: params.channel,
            key: params.key,
            action: 'rollback',
            actorUserId: params.actorUserId,
            actorAgentId: params.actorAgentId ?? null,
            policy,
            authorityRule,
            summary,
            currentValue,
            currentVersion,
            historyId: params.historyId ?? null,
            reason: params.reason ?? null,
            fallbackRecipientUserId: params.conflictRecipientUserId ?? null,
        });
        return {
            ok: false,
            applied: false,
            unauthorized: true,
            currentVersion,
            nextVersion: currentVersion,
            historyId: null,
            key: params.key,
            value: currentValue,
            authorityPrefix: authorityRule?.prefix ?? null,
            approvalRequired: Boolean(authorityRule?.approvalRequired),
        };
    }
    const history = await memoryStore.getScopedMemoryHistory(scope, 200);
    const targetEntry = history.find((entry) => entry.key === params.key && (!params.historyId || entry.id === params.historyId));
    if (!targetEntry) {
        return {
            ok: false,
            applied: false,
            unauthorized: false,
            currentVersion,
            nextVersion: currentVersion,
            historyId: null,
            key: params.key,
            value: currentValue,
            authorityPrefix: authorityRule?.prefix ?? null,
            approvalRequired: Boolean(authorityRule?.approvalRequired),
        };
    }
    const ok = await memoryStore.rollbackScopedMemory(scope, targetEntry.id);
    if (!ok) {
        return {
            ok: false,
            applied: false,
            unauthorized: false,
            currentVersion,
            nextVersion: currentVersion,
            historyId: targetEntry.id,
            key: params.key,
            value: currentValue,
            authorityPrefix: authorityRule?.prefix ?? null,
            approvalRequired: Boolean(authorityRule?.approvalRequired),
        };
    }
    const nextVersion = currentVersion + 1;
    await memoryStore.setScopedMemory(scope, versionKey, String(nextVersion));
    const value = await memoryStore.getScopedMemory(scope, params.key);
    if (params.conflictRecipientUserId || params.conflictRecipientAgentId) {
        const summary = [
            `Shared memory rollback applied for ${params.key}.`,
            params.reason ? `Reason: ${params.reason.slice(0, 240)}` : null,
            `Restored history entry: ${targetEntry.id}`,
            targetEntry.old_value !== null ? `Restored value: ${targetEntry.old_value.slice(0, 240)}` : 'Restored value: <deleted>',
            params.actorAgentId ? `Actor agent: ${params.actorAgentId}` : null,
            `Actor user: ${params.actorUserId}`,
        ].filter(Boolean).join('\n');
        await emitSharedMemoryGovernanceSignal({
            workspaceId: params.workspaceId,
            key: params.key,
            title: params.conflictTitle ?? `Shared memory rollback applied: ${params.key}`,
            summary,
            actorUserId: params.actorUserId,
            actorAgentId: params.actorAgentId ?? null,
            conflictTaskId: params.conflictTaskId ?? null,
            conflictRecipientUserId: params.conflictRecipientUserId ?? null,
            conflictRecipientAgentId: params.conflictRecipientAgentId ?? null,
            severity: 'info',
            protocolKind: 'memory_rollback_executed',
            requestConsensus: false,
            metadata: {
                authorityPrefix: authorityRule?.prefix ?? null,
                approvalRequired: Boolean(authorityRule?.approvalRequired),
                reason: params.reason ?? null,
                restoredHistoryId: targetEntry.id,
                restoredValue: value?.slice(0, 500) ?? null,
                currentVersion,
                nextVersion,
            },
        });
    }
    return {
        ok: true,
        applied: true,
        unauthorized: false,
        currentVersion,
        nextVersion,
        historyId: targetEntry.id,
        key: params.key,
        value,
        authorityPrefix: authorityRule?.prefix ?? null,
        approvalRequired: Boolean(authorityRule?.approvalRequired),
    };
}
async function shareTaskResultToWorkspaceMemory(task, policy, summary) {
    if (!policy.autoShareTaskResults || !summary)
        return;
    const dispatchCtx = getTaskDispatchContext(task);
    const key = `${policy.sharedMemoryPrefix || 'team:'}task:${task.id}`;
    await writeTeamSharedMemoryEntry({
        workspaceId: task.workspaceId,
        userId: dispatchCtx.userId,
        channel: dispatchCtx.channel,
        key,
        value: summary,
        actorUserId: task.createdBy,
        actorAgentId: task.assignedAgentId ?? task.reviewerAgentId ?? null,
        conflictTaskId: task.id,
        conflictRecipientUserId: resolveHumanOwner(task, policy),
        conflictRecipientAgentId: typeof (task.metadata ?? {})['topologySupervisorAgentId'] === 'string'
            ? (task.metadata ?? {})['topologySupervisorAgentId']
            : null,
        conflictTitle: `Shared memory conflict for task ${task.title}`,
    });
}
async function broadcastTaskDoneToWorkersSafe(task) {
    const metadata = task.metadata ?? {};
    const workers = Array.isArray(metadata['topologyWorkerAgentIds'])
        ? metadata['topologyWorkerAgentIds'].filter((id) => typeof id === 'string' && id.trim().length > 0)
        : [];
    if (workers.length === 0)
        return;
    const summary = task.resultSummary ? task.resultSummary.slice(0, 400) : '(no summary)';
    for (const workerId of workers) {
        try {
            await createTeamMailboxMessageSafe({
                workspaceId: task.workspaceId,
                senderAgentId: typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null,
                recipientAgentId: workerId,
                taskId: task.id,
                dedupeKey: buildMailboxDedupeKey('task_done_broadcast', task.id, workerId),
                type: 'task_event',
                subject: `Task completed: ${task.title}`,
                message: `Task "${task.title}" completed by agent ${task.assignedAgentId ?? 'unknown'}.\n\nResult:\n${summary}`,
                metadata: { protocolRule: 'onTaskDone_broadcast', taskStatus: 'done' },
            });
        }
        catch (err) {
            log.warn({ err: String(err), taskId: task.id, workerId }, 'Failed to broadcast task done to worker');
        }
    }
}
async function broadcastSuccessPracticeToTeamSafe(task, practice) {
    const metadata = task.metadata ?? {};
    const recipients = dedupeStringList([
        ...(Array.isArray(metadata['topologyWorkerAgentIds'])
            ? metadata['topologyWorkerAgentIds'].filter((id) => typeof id === 'string' && id.trim().length > 0)
            : []),
        typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : '',
    ]).filter((agentId) => agentId !== task.assignedAgentId);
    if (recipients.length === 0)
        return;
    for (const recipientAgentId of recipients) {
        try {
            await createTeamMailboxMessageSafe({
                workspaceId: task.workspaceId,
                senderAgentId: task.assignedAgentId ?? (typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null),
                recipientAgentId,
                taskId: task.id,
                dedupeKey: buildMailboxDedupeKey('success_practice', task.id, recipientAgentId, practice.rule),
                type: 'broadcast',
                subject: `Best practice learned: ${task.title}`,
                message: `Successful task "${task.title}" yielded a reusable best practice.\n\n[${practice.category}] ${practice.rule}\nConfidence: ${practice.confidence}%`,
                metadata: {
                    protocolRule: 'success_practice_broadcast',
                    bestPracticeRule: practice.rule,
                    bestPracticeCategory: practice.category,
                    bestPracticeConfidence: practice.confidence,
                    taskStatus: 'done',
                },
            });
        }
        catch (err) {
            log.warn({ err: String(err), taskId: task.id, recipientAgentId }, 'Failed to broadcast success practice to teammate');
        }
    }
}
async function ensurePendingApprovalForTask(task, policy, reason) {
    const requestedForUserId = resolveHumanOwner(task, policy);
    const dispatchCtx = getTaskDispatchContext(task);
    const existing = await memoryStore.listTeamTaskApprovals({
        workspaceId: task.workspaceId,
        taskId: task.id,
        status: 'pending',
        requestedForUserId,
    });
    if (existing.length > 0)
        return;
    const approval = await memoryStore.createTeamTaskApproval({
        workspaceId: task.workspaceId,
        taskId: task.id,
        requestedBy: 'system',
        requestedForUserId,
        reason,
    });
    await createTeamNotificationSafe({
        workspaceId: task.workspaceId,
        recipientUserId: requestedForUserId,
        type: 'approval_requested',
        severity: task.escalationStatus === 'pending' ? 'critical' : 'warning',
        title: `Approval required for task: ${task.title}`,
        message: reason,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            taskStatus: task.status,
            escalationStatus: task.escalationStatus,
            createdBy: task.createdBy,
            ...(requestedForUserId === dispatchCtx.userId
                ? {
                    deliveryChannel: dispatchCtx.channel,
                    deliveryChatId: dispatchCtx.chatId,
                }
                : {}),
        },
    });
    await createTeamNotificationSafe({
        workspaceId: task.workspaceId,
        recipientUserId: requestedForUserId,
        type: 'task_escalated',
        severity: 'critical',
        title: `Task escalated: ${task.title}`,
        message: reason,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            taskStatus: task.status,
            escalationStatus: task.escalationStatus,
            createdBy: task.createdBy,
            ...(requestedForUserId === dispatchCtx.userId
                ? {
                    deliveryChannel: dispatchCtx.channel,
                    deliveryChatId: dispatchCtx.chatId,
                }
                : {}),
        },
    });
}
async function ensureRuleLibraryPromotionApprovalTask(params) {
    const existingTasks = await memoryStore.listTeamTasks({ workspaceId: params.workspaceId });
    const existing = existingTasks.find((task) => {
        if (isClosedTeamTask(task))
            return false;
        const metadata = task.metadata ?? {};
        return metadata['governanceKind'] === 'rule_library_promotion'
            && metadata['ruleLibraryAction'] === params.action
            && (params.action !== 'rollback' || normalizeKeyPart(typeof metadata['ruleLibraryHistoryId'] === 'string' ? metadata['ruleLibraryHistoryId'] : null) === normalizeKeyPart(params.historyId))
            && normalizeKeyPart(typeof metadata['ruleLibraryRule'] === 'string' ? metadata['ruleLibraryRule'] : null) === normalizeKeyPart(params.rule)
            && metadata['ruleLibraryApprovalStatus'] === 'pending';
    });
    const governanceMetadata = {
        requestUserId: params.userId,
        requestChannel: params.channel,
        requestChatId: params.chatId,
        governanceKind: 'rule_library_promotion',
        ruleLibraryAction: params.action,
        ruleLibraryRule: params.rule,
        ruleLibraryCategory: params.category,
        ruleLibraryConfidence: params.confidence,
        ruleLibraryEvidenceCount: params.evidenceCount,
        ruleLibrarySource: params.source,
        ruleLibrarySourceWorkspaceId: params.sourceWorkspaceId,
        ruleLibrarySourceAgentId: params.sourceAgentId ?? null,
        ruleLibraryHistoryId: params.historyId ?? null,
        ruleLibraryApprovalRequired: true,
        ruleLibraryApprovalStatus: 'pending',
        ruleLibraryExecutionStatus: 'pending',
        ruleLibraryRequestedForUserId: params.requestedForUserId,
        ruleLibraryRequestedByUserId: params.actorUserId,
    };
    const summary = [
        `${params.action === 'promote'
            ? 'Promote'
            : params.action === 'remove'
                ? 'Remove'
                : 'Rollback'} rule ${params.action === 'promote'
            ? 'into'
            : params.action === 'remove'
                ? 'from'
                : 'in'} the cross-workspace rule library: ${params.rule}`,
        `Category: ${params.category}`,
        `Confidence: ${params.confidence}%`,
        `Evidence count: ${params.evidenceCount}`,
        `Source workspace: ${params.sourceWorkspaceId}`,
        params.historyId ? `History entry: ${params.historyId}` : null,
        params.sourceAgentId ? `Source agent: ${params.sourceAgentId}` : null,
    ].filter(Boolean).join('\n');
    const title = `[Governance] ${params.action === 'promote'
        ? 'Promote'
        : params.action === 'remove'
            ? 'Remove'
            : 'Rollback'} rule ${params.action === 'promote'
        ? 'to'
        : params.action === 'remove'
            ? 'from'
            : 'in'} library: ${params.rule}`.slice(0, 120);
    const description = [
        params.action === 'promote'
            ? 'Approve publishing this learned behavioral rule into the owner-scoped global rule library.'
            : params.action === 'remove'
                ? 'Approve removing this behavioral rule from the owner-scoped global rule library.'
                : 'Approve rolling back the selected rule-library history entry in the owner-scoped global rule library.',
        summary,
    ].join('\n\n').slice(0, 2000);
    const task = existing
        ? await memoryStore.updateTeamTask(existing.id, {
            status: 'blocked',
            priority: 'high',
            blockedReason: summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: summary.slice(0, 500),
            humanOwnerUserId: params.requestedForUserId,
            description,
            metadata: {
                ...(existing.metadata ?? {}),
                ...governanceMetadata,
            },
        })
        : await memoryStore.createTeamTask({
            workspaceId: params.workspaceId,
            title,
            description,
            status: 'blocked',
            priority: 'high',
            assignedAgentId: null,
            reviewRequired: false,
            reviewStatus: 'not_required',
            maxAttempts: 1,
            humanOwnerUserId: params.requestedForUserId,
            blockedReason: summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: summary.slice(0, 500),
            dueAt: new Date(Date.now() + params.policy.defaultTaskSlaHours * 3600 * 1000),
            createdBy: params.actorUserId,
            metadata: governanceMetadata,
        });
    if (!task)
        return null;
    await ensurePendingApprovalForTask(task, params.policy, summary);
    return task;
}
async function recycleOrEscalateTask(task, reason, policy, mode) {
    const shouldImmediateEscalate = mode === 'review' ? policy.escalateOnReviewChanges : false;
    const retriesRemaining = task.attemptCount < task.maxAttempts;
    if (!shouldImmediateEscalate && retriesRemaining) {
        return memoryStore.updateTeamTask(task.id, {
            status: getDefaultCreatedTaskStatus(task),
            blockedReason: reason,
            reviewStatus: mode === 'review' ? 'changes_requested' : task.reviewStatus,
            escalationStatus: 'none',
            escalationReason: null,
            humanOwnerUserId: resolveHumanOwner(task, policy),
        });
    }
    const shouldEscalate = shouldImmediateEscalate || policy.escalateOnBlocked || (mode === 'review' && policy.escalateOnReviewChanges);
    const updated = await memoryStore.updateTeamTask(task.id, {
        status: 'blocked',
        blockedReason: reason,
        reviewStatus: mode === 'review' ? 'changes_requested' : task.reviewStatus,
        escalationStatus: shouldEscalate ? 'pending' : 'none',
        escalationReason: shouldEscalate ? reason : null,
        humanOwnerUserId: resolveHumanOwner(task, policy),
    });
    if (updated && shouldEscalate) {
        await ensurePendingApprovalForTask(updated, policy, reason);
    }
    return updated;
}
async function escalateOverdueTask(task, policy) {
    if (!task.dueAt || task.status === 'done' || task.status === 'cancelled')
        return task;
    if (task.dueAt.getTime() > Date.now())
        return task;
    const reason = `SLA breached at ${task.dueAt.toISOString()}`;
    if (task.escalationStatus === 'pending' && task.escalationReason === reason)
        return task;
    const updated = await memoryStore.updateTeamTask(task.id, {
        status: 'blocked',
        blockedReason: reason,
        escalationStatus: policy.escalateOnSlaBreach ? 'pending' : task.escalationStatus,
        escalationReason: policy.escalateOnSlaBreach ? reason : task.escalationReason,
        humanOwnerUserId: resolveHumanOwner(task, policy),
    });
    if (updated && policy.escalateOnSlaBreach) {
        await ensurePendingApprovalForTask(updated, policy, reason);
    }
    return updated;
}
async function createTasksFromTemplate(template, ctx, overrides) {
    const policy = await getEffectiveTeamPolicy(template.workspaceId, ctx.userId);
    const resolvedVariables = resolveTeamTemplateVariables(template, overrides?.variables);
    const templateGoal = interpolateTeamTemplateString(template.goalTemplate, resolvedVariables);
    const fallbackWorkers = dedupeStringList(overrides?.workerAgentIds);
    const createdByTitle = new Map();
    const createdTasks = [];
    let nextWorkerIndex = 0;
    for (const [index, item] of template.taskBlueprints.entries()) {
        const expandedTitle = interpolateTeamTemplateString(item.title, resolvedVariables)?.trim() ?? '';
        if (!expandedTitle)
            continue;
        const selectedTopologyTrack = overrides?.topologySource
            ? selectTeamTopologyStrategyTrack(overrides.topologySource, `${template.id}:${index}:${expandedTitle}`)
            : null;
        const topologyStrategyTrack = overrides?.topologyStrategyTrack ?? selectedTopologyTrack?.track ?? 'stable';
        const topologyStrategySnapshot = selectedTopologyTrack?.snapshot ?? null;
        const topologyOrchestratorRules = topologyStrategySnapshot?.orchestratorRules
            ?? overrides?.topologyOrchestratorRules
            ?? null;
        const topologyAdaptiveModelPolicy = topologyStrategySnapshot?.adaptiveModelPolicy
            ?? overrides?.topologyAdaptiveModelPolicy
            ?? null;
        const topologyModelRoutes = topologyStrategySnapshot?.modelRoutes
            ?? overrides?.topologyModelRoutes
            ?? null;
        const topologyStrategyVersion = topologyStrategySnapshot?.version
            ?? overrides?.topologyStrategyVersion
            ?? null;
        const topologyStrategyUpdatedAt = topologyStrategySnapshot?.updatedAt
            ?? overrides?.topologyStrategyUpdatedAt
            ?? null;
        const topologyStrategyHistory = topologyStrategyTrack === 'candidate'
            ? null
            : (overrides?.topologyStrategyHistory ?? null);
        const dependsOnTaskIds = (item.dependsOnTitles ?? [])
            .map((title) => interpolateTeamTemplateString(title, resolvedVariables)?.trim() ?? '')
            .map((title) => createdByTitle.get(title)?.id)
            .filter((id) => Boolean(id));
        const assignedAgentId = item.assignedAgentId ?? (fallbackWorkers.length > 0
            ? fallbackWorkers[nextWorkerIndex++ % fallbackWorkers.length]
            : null);
        const reviewerAgentId = item.reviewerAgentId ?? (item.reviewRequired ? (overrides?.supervisorAgentId ?? null) : null);
        const task = await memoryStore.createTeamTask({
            workspaceId: template.workspaceId,
            title: expandedTitle.slice(0, 120),
            description: interpolateTeamTemplateString(item.description, resolvedVariables)?.slice(0, 500),
            priority: item.priority ?? 'medium',
            assignedAgentId,
            dependsOnTaskIds,
            reviewRequired: Boolean(item.reviewRequired && reviewerAgentId),
            reviewerAgentId,
            maxAttempts: Math.max(1, item.maxAttempts ?? (policy.maxAutoRetries + 1)),
            humanOwnerUserId: overrides?.humanOwnerUserId ?? policy.defaultHumanOwnerUserId ?? ctx.userId,
            dueAt: new Date(Date.now() + policy.defaultTaskSlaHours * 3600 * 1000),
            createdBy: ctx.userId,
            metadata: {
                requestUserId: ctx.userId,
                requestChannel: ctx.channel,
                requestChatId: ctx.chatId,
                templateId: template.id,
                templateName: template.name,
                templateDepartment: template.department ?? null,
                templateRole: template.role ?? null,
                ...(templateGoal ? { templateGoal } : {}),
                ...(Object.keys(resolvedVariables).length > 0 ? { templateVariables: resolvedVariables } : {}),
                ...(overrides?.topologyId ? { topologyId: overrides.topologyId } : {}),
                ...(overrides?.topologyName ? { topologyName: overrides.topologyName } : {}),
                ...(fallbackWorkers.length > 0 ? { topologyWorkerAgentIds: fallbackWorkers } : {}),
                ...(overrides?.supervisorAgentId ? { topologySupervisorAgentId: overrides.supervisorAgentId } : {}),
                ...(topologyOrchestratorRules ? { topologyOrchestratorRules } : {}),
                ...(topologyAdaptiveModelPolicy ? { topologyAdaptiveModelPolicy } : {}),
                ...(topologyModelRoutes ? { topologyModelRoutes } : {}),
                ...(typeof topologyStrategyVersion === 'number' ? { topologyStrategyVersion } : {}),
                ...(topologyStrategyUpdatedAt ? { topologyStrategyUpdatedAt } : {}),
                ...(topologyStrategyHistory ? { topologyStrategyHistory } : {}),
                ...(topologyStrategyTrack ? { topologyStrategyTrack } : {}),
            },
        });
        createdByTitle.set(expandedTitle, task);
        createdTasks.push(task);
    }
    if (createdTasks.length > 0) {
        const notificationRecipient = overrides?.humanOwnerUserId ?? policy.defaultHumanOwnerUserId ?? ctx.userId;
        await createTeamNotificationSafe({
            workspaceId: template.workspaceId,
            recipientUserId: notificationRecipient,
            type: 'template_instantiated',
            severity: 'info',
            title: `Template instantiated: ${template.name}`,
            message: `Created ${createdTasks.length} tasks from template ${template.name}.`,
            metadata: {
                templateId: template.id,
                templateName: template.name,
                taskIds: createdTasks.map((task) => task.id),
                topologyId: overrides?.topologyId ?? null,
                topologyName: overrides?.topologyName ?? null,
                topologyOrchestratorRules: overrides?.topologyOrchestratorRules ?? null,
                topologyAdaptiveModelPolicy: overrides?.topologyAdaptiveModelPolicy ?? null,
                topologyModelRoutes: overrides?.topologyModelRoutes ?? null,
                topologyStrategyVersion: overrides?.topologyStrategyVersion ?? null,
                topologyStrategyUpdatedAt: overrides?.topologyStrategyUpdatedAt ?? null,
                topologyStrategyTrack: overrides?.topologyStrategyTrack ?? null,
                ...(notificationRecipient === ctx.userId
                    ? {
                        deliveryChannel: ctx.channel,
                        deliveryChatId: ctx.chatId,
                    }
                    : {}),
            },
        });
    }
    return createdTasks;
}
function parseGovernanceMetadataString(metadata, key) {
    const value = metadata[key];
    return typeof value === 'string' && value.trim().length > 0 ? value.trim() : null;
}
function parseGovernanceMetadataNumber(metadata, key) {
    const raw = Number(metadata[key]);
    return Number.isFinite(raw) ? raw : null;
}
async function executeApprovedSharedMemoryGovernanceTask(params) {
    const metadata = params.task.metadata ?? {};
    const action = parseGovernanceMetadataString(metadata, 'sharedMemoryAction');
    const key = parseGovernanceMetadataString(metadata, 'sharedMemoryKey');
    const userId = parseGovernanceMetadataString(metadata, 'sharedMemoryScopeUserId') ?? params.task.createdBy;
    const channel = parseChannelName(metadata['sharedMemoryScopeChannel']) ?? parseChannelName(metadata['requestChannel']) ?? 'web';
    const requesterAgentId = parseGovernanceMetadataString(metadata, 'sharedMemoryRequesterAgentId');
    if (!action || !key || (action !== 'write' && action !== 'rollback')) {
        const summary = 'Shared memory governance task is missing execution metadata.';
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    sharedMemoryExecutionStatus: 'failed',
                    sharedMemoryExecutionError: summary,
                },
            },
        };
    }
    if (action === 'write') {
        const value = parseGovernanceMetadataString(metadata, 'sharedMemoryIncomingValue');
        if (value === null) {
            const summary = `Shared memory write approval for ${key} is missing the pending value.`;
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        sharedMemoryExecutionStatus: 'failed',
                        sharedMemoryExecutionError: summary,
                    },
                },
            };
        }
        const writeResult = await writeTeamSharedMemoryEntry({
            workspaceId: params.task.workspaceId,
            userId,
            channel,
            key,
            value,
            actorUserId: params.actorUserId,
            actorAgentId: requesterAgentId,
            expectedVersion: parseGovernanceMetadataNumber(metadata, 'sharedMemoryExpectedVersion'),
            conflictTaskId: params.task.id,
            conflictRecipientUserId: params.task.humanOwnerUserId ?? resolveHumanOwner(params.task, params.policy),
            conflictTitle: `Approved shared memory write for ${key}`,
            authorityOverride: {
                approvalId: params.approval.id,
                approvedByUserId: params.actorUserId,
            },
        });
        if (writeResult.applied) {
            const summary = `Shared memory write applied for ${key} at version ${writeResult.nextVersion}.`;
            return {
                summary,
                updates: {
                    status: 'done',
                    blockedReason: null,
                    escalationStatus: 'acknowledged',
                    escalationReason: null,
                    resultSummary: summary,
                    metadata: {
                        ...metadata,
                        sharedMemoryExecutionStatus: 'applied',
                        sharedMemoryExecutedAt: new Date().toISOString(),
                        sharedMemoryExecutedByUserId: params.actorUserId,
                        sharedMemoryAppliedVersion: writeResult.nextVersion,
                        sharedMemoryExecutionSummary: summary,
                    },
                },
            };
        }
        const summary = writeResult.versionConflict
            ? `Approved shared memory write for ${key} could not be applied because the version moved to ${writeResult.currentVersion}.`
            : `Approved shared memory write for ${key} could not be applied.`;
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    sharedMemoryExecutionStatus: 'failed',
                    sharedMemoryExecutedAt: new Date().toISOString(),
                    sharedMemoryExecutedByUserId: params.actorUserId,
                    sharedMemoryExecutionError: summary,
                    sharedMemoryCurrentVersion: writeResult.currentVersion,
                },
            },
        };
    }
    const rollbackResult = await rollbackTeamSharedMemoryEntry({
        workspaceId: params.task.workspaceId,
        userId,
        channel,
        key,
        actorUserId: params.actorUserId,
        actorAgentId: requesterAgentId,
        historyId: parseGovernanceMetadataString(metadata, 'sharedMemoryHistoryId'),
        reason: parseGovernanceMetadataString(metadata, 'sharedMemoryReason') ?? params.notes ?? null,
        conflictTaskId: params.task.id,
        conflictRecipientUserId: params.task.humanOwnerUserId ?? resolveHumanOwner(params.task, params.policy),
        conflictTitle: `Approved shared memory rollback for ${key}`,
        authorityOverride: {
            approvalId: params.approval.id,
            approvedByUserId: params.actorUserId,
        },
    });
    if (rollbackResult.ok) {
        const summary = `Shared memory rollback applied for ${key} at version ${rollbackResult.nextVersion}.`;
        return {
            summary,
            updates: {
                status: 'done',
                blockedReason: null,
                escalationStatus: 'acknowledged',
                escalationReason: null,
                resultSummary: summary,
                metadata: {
                    ...metadata,
                    sharedMemoryExecutionStatus: 'applied',
                    sharedMemoryExecutedAt: new Date().toISOString(),
                    sharedMemoryExecutedByUserId: params.actorUserId,
                    sharedMemoryAppliedVersion: rollbackResult.nextVersion,
                    sharedMemoryExecutionSummary: summary,
                    sharedMemoryRestoredHistoryId: rollbackResult.historyId,
                },
            },
        };
    }
    const summary = `Approved shared memory rollback for ${key} could not be applied.`;
    return {
        summary,
        updates: {
            status: 'blocked',
            blockedReason: summary,
            escalationStatus: 'pending',
            escalationReason: summary,
            resultSummary: null,
            metadata: {
                ...metadata,
                sharedMemoryExecutionStatus: 'failed',
                sharedMemoryExecutedAt: new Date().toISOString(),
                sharedMemoryExecutedByUserId: params.actorUserId,
                sharedMemoryExecutionError: summary,
                sharedMemoryCurrentVersion: rollbackResult.currentVersion,
            },
        },
    };
}
async function executeApprovedTopologyPromotionGovernanceTask(params) {
    const metadata = params.task.metadata ?? {};
    const topologyId = parseGovernanceMetadataString(metadata, 'topologyId');
    const candidateVersion = parseGovernanceMetadataNumber(metadata, 'candidatePromotionCandidateVersion');
    if (!topologyId || !candidateVersion) {
        const summary = 'Topology promotion governance task is missing promotion metadata.';
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    candidatePromotionExecutionStatus: 'failed',
                    candidatePromotionExecutionError: summary,
                },
            },
        };
    }
    const topology = await memoryStore.getTeamTopology(topologyId);
    if (!topology || topology.workspaceId !== params.task.workspaceId) {
        const summary = `Topology not found for approved promotion: ${topologyId}.`;
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    candidatePromotionExecutionStatus: 'failed',
                    candidatePromotionExecutionError: summary,
                },
            },
        };
    }
    const promotion = buildPromoteCandidateStrategyUpdates(topology);
    if (!promotion || promotion.candidate.version !== candidateVersion) {
        const liveVersion = topology.candidateStrategy?.version ?? null;
        const summary = liveVersion === null
            ? `Candidate strategy v${candidateVersion} is no longer available for promotion.`
            : `Candidate strategy moved from v${candidateVersion} to v${liveVersion}; request a new approval.`;
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    candidatePromotionExecutionStatus: 'failed',
                    candidatePromotionExecutionError: summary,
                    candidatePromotionLiveVersion: liveVersion,
                },
            },
        };
    }
    const nowIso = new Date().toISOString();
    const updatedTopology = await memoryStore.updateTeamTopology(topologyId, {
        ...promotion.updates,
        metadata: appendCandidateRolloutAuditEvent(topology.metadata, {
            action: 'approval_approved',
            at: nowIso,
            actor: 'user',
            reason: params.notes ?? null,
            fromRolloutPercent: promotion.candidate.rolloutPercent,
            toRolloutPercent: promotion.candidate.rolloutPercent,
            candidateVersion: promotion.candidate.version,
            stableVersion: (topology.strategyVersion ?? 1) + 1,
        }),
    });
    if (!updatedTopology) {
        const summary = `Approved topology promotion for ${topologyId} could not be applied.`;
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    candidatePromotionExecutionStatus: 'failed',
                    candidatePromotionExecutionError: summary,
                },
            },
        };
    }
    const summary = `Promoted candidate strategy v${promotion.candidate.version} for topology ${updatedTopology.name} into stable v${updatedTopology.strategyVersion ?? 1}.`;
    return {
        summary,
        updates: {
            status: 'done',
            blockedReason: null,
            escalationStatus: 'acknowledged',
            escalationReason: null,
            resultSummary: summary,
            metadata: {
                ...metadata,
                candidatePromotionExecutionStatus: 'applied',
                candidatePromotionExecutedAt: nowIso,
                candidatePromotionExecutedByUserId: params.actorUserId,
                candidatePromotionApprovedAt: nowIso,
                candidatePromotionApprovedByUserId: params.actorUserId,
                candidatePromotionStableVersion: updatedTopology.strategyVersion ?? 1,
                candidatePromotionExecutionSummary: summary,
            },
        },
    };
}
async function executeApprovedTopologyControlGovernanceTask(params) {
    const metadata = params.task.metadata ?? {};
    const topologyId = parseGovernanceMetadataString(metadata, 'topologyId');
    const action = parseGovernanceMetadataString(metadata, 'topologyControlAction');
    if (!topologyId || !action) {
        const summary = 'Topology control governance task is missing control metadata.';
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    topologyControlExecutionStatus: 'failed',
                    topologyControlExecutionError: summary,
                },
            },
        };
    }
    const topology = await memoryStore.getTeamTopology(topologyId);
    if (!topology || topology.workspaceId !== params.task.workspaceId) {
        const summary = `Topology not found for approved control action: ${topologyId}.`;
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    topologyControlExecutionStatus: 'failed',
                    topologyControlExecutionError: summary,
                },
            },
        };
    }
    const nowIso = new Date().toISOString();
    if (action === 'promote_strategy') {
        const nextMetadata = {
            ...(topology.metadata ?? {}),
            ...(Object.prototype.hasOwnProperty.call(metadata, 'topologyControlAdaptiveOrchestratorPolicy')
                ? {
                    adaptiveOrchestratorPolicy: metadata['topologyControlAdaptiveOrchestratorPolicy'],
                }
                : {}),
        };
        const updatedTopology = await memoryStore.updateTeamTopology(topologyId, {
            ...(Object.prototype.hasOwnProperty.call(metadata, 'topologyControlOrchestratorRules')
                ? { orchestratorRules: parseOrchestratorRules(metadata['topologyControlOrchestratorRules']) }
                : {}),
            ...(Object.prototype.hasOwnProperty.call(metadata, 'topologyControlAdaptiveModelPolicy')
                ? { adaptiveModelPolicy: parseAdaptiveModelPolicyInput(metadata['topologyControlAdaptiveModelPolicy']) }
                : {}),
            ...(Object.prototype.hasOwnProperty.call(metadata, 'topologyControlModelRoutes')
                ? { modelRoutes: parseTeamTopologyModelRoutes(metadata['topologyControlModelRoutes']) }
                : {}),
            metadata: nextMetadata,
        });
        if (!updatedTopology) {
            const summary = `Approved strategy promotion for ${topologyId} could not be applied.`;
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        topologyControlExecutionStatus: 'failed',
                        topologyControlExecutionError: summary,
                    },
                },
            };
        }
        const summary = `Applied approved strategy promotion for topology ${updatedTopology.name}; stable version is now v${updatedTopology.strategyVersion ?? 1}.`;
        return {
            summary,
            updates: {
                status: 'done',
                blockedReason: null,
                escalationStatus: 'acknowledged',
                escalationReason: null,
                resultSummary: summary,
                metadata: {
                    ...metadata,
                    topologyControlExecutionStatus: 'applied',
                    topologyControlExecutedAt: nowIso,
                    topologyControlExecutedByUserId: params.actorUserId,
                    topologyControlExecutionSummary: summary,
                    topologyControlStableVersion: updatedTopology.strategyVersion ?? 1,
                },
            },
        };
    }
    if (action === 'rollback_strategy') {
        const requestedVersion = parseGovernanceMetadataNumber(metadata, 'topologyControlRequestedVersion');
        const snapshot = requestedVersion ? findTeamTopologyStrategySnapshot(topology, requestedVersion) : null;
        if (!requestedVersion || !snapshot) {
            const summary = `Rollback target version is missing or no longer available for topology ${topology.name}.`;
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        topologyControlExecutionStatus: 'failed',
                        topologyControlExecutionError: summary,
                    },
                },
            };
        }
        const updatedTopology = await memoryStore.updateTeamTopology(topologyId, {
            orchestratorRules: snapshot.orchestratorRules ?? null,
            adaptiveModelPolicy: snapshot.adaptiveModelPolicy ?? null,
            modelRoutes: snapshot.modelRoutes ?? null,
        });
        if (!updatedTopology) {
            const summary = `Approved rollback for ${topologyId} could not be applied.`;
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        topologyControlExecutionStatus: 'failed',
                        topologyControlExecutionError: summary,
                    },
                },
            };
        }
        const summary = `Rolled topology ${updatedTopology.name} back to stable v${updatedTopology.strategyVersion ?? 1}.`;
        return {
            summary,
            updates: {
                status: 'done',
                blockedReason: null,
                escalationStatus: 'acknowledged',
                escalationReason: null,
                resultSummary: summary,
                metadata: {
                    ...metadata,
                    topologyControlExecutionStatus: 'applied',
                    topologyControlExecutedAt: nowIso,
                    topologyControlExecutedByUserId: params.actorUserId,
                    topologyControlExecutionSummary: summary,
                    topologyControlStableVersion: updatedTopology.strategyVersion ?? 1,
                },
            },
        };
    }
    if (action === 'candidate_rollout_disable') {
        const updatedTopology = await memoryStore.updateTeamTopology(topologyId, {
            candidateRolloutControl: {
                ...(topology.candidateRolloutControl ?? parseTeamTopologyCandidateRolloutControl(topology.metadata?.['candidateRolloutControl']) ?? { enabled: true, frozen: false }),
                enabled: false,
                frozen: false,
                freezeReason: null,
                updatedAt: nowIso,
                updatedBy: params.actorUserId,
            },
            metadata: appendCandidateRolloutAuditEvent(topology.metadata, {
                action: 'freeze',
                at: nowIso,
                actor: 'user',
                reason: parseGovernanceMetadataString(metadata, 'topologyControlReason') ?? params.notes ?? null,
                fromRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                toRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                candidateVersion: topology.candidateStrategy?.version ?? null,
                stableVersion: topology.strategyVersion ?? 1,
            }),
        });
        if (!updatedTopology) {
            const summary = `Approved candidate rollout disable for ${topologyId} could not be applied.`;
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        topologyControlExecutionStatus: 'failed',
                        topologyControlExecutionError: summary,
                    },
                },
            };
        }
        const summary = `Disabled automatic candidate rollout for topology ${updatedTopology.name}.`;
        return {
            summary,
            updates: {
                status: 'done',
                blockedReason: null,
                escalationStatus: 'acknowledged',
                escalationReason: null,
                resultSummary: summary,
                metadata: {
                    ...metadata,
                    topologyControlExecutionStatus: 'applied',
                    topologyControlExecutedAt: nowIso,
                    topologyControlExecutedByUserId: params.actorUserId,
                    topologyControlExecutionSummary: summary,
                },
            },
        };
    }
    if (action === 'delete_topology') {
        const deleted = await memoryStore.deleteTeamTopology(topologyId);
        const summary = deleted
            ? `Deleted topology ${topology.name} (${topology.id}).`
            : `Approved deletion for ${topology.name} could not be applied.`;
        return {
            summary,
            updates: {
                status: deleted ? 'done' : 'blocked',
                blockedReason: deleted ? null : summary,
                escalationStatus: deleted ? 'acknowledged' : 'pending',
                escalationReason: deleted ? null : summary,
                resultSummary: deleted ? summary : null,
                metadata: {
                    ...metadata,
                    topologyControlExecutionStatus: deleted ? 'applied' : 'failed',
                    topologyControlExecutedAt: nowIso,
                    topologyControlExecutedByUserId: params.actorUserId,
                    ...(deleted ? { topologyControlExecutionSummary: summary } : { topologyControlExecutionError: summary }),
                },
            },
        };
    }
    const summary = `Unsupported topology control action: ${action}.`;
    return {
        summary,
        updates: {
            status: 'blocked',
            blockedReason: summary,
            escalationStatus: 'pending',
            escalationReason: summary,
            resultSummary: null,
            metadata: {
                ...metadata,
                topologyControlExecutionStatus: 'failed',
                topologyControlExecutionError: summary,
            },
        },
    };
}
async function executeApprovedRuleLibraryPromotionGovernanceTask(params) {
    const metadata = params.task.metadata ?? {};
    const rule = parseGovernanceMetadataString(metadata, 'ruleLibraryRule');
    const category = parseGovernanceMetadataString(metadata, 'ruleLibraryCategory');
    const requestedUserId = parseGovernanceMetadataString(metadata, 'requestUserId') ?? params.task.createdBy;
    const requestedChannel = parseChannelName(metadata['requestChannel']) ?? 'web';
    const sourceWorkspaceId = parseGovernanceMetadataString(metadata, 'ruleLibrarySourceWorkspaceId') ?? params.task.workspaceId;
    const confidence = parseGovernanceMetadataNumber(metadata, 'ruleLibraryConfidence') ?? 60;
    const source = parseGovernanceMetadataString(metadata, 'ruleLibrarySource') ?? 'library_candidate';
    const rawAction = parseGovernanceMetadataString(metadata, 'ruleLibraryAction');
    const action = rawAction === 'remove'
        ? 'remove'
        : rawAction === 'rollback'
            ? 'rollback'
            : 'promote';
    const historyId = parseGovernanceMetadataString(metadata, 'ruleLibraryHistoryId');
    if (!rule || !category) {
        const summary = 'Rule library promotion governance task is missing rule metadata.';
        return {
            summary,
            updates: {
                status: 'blocked',
                blockedReason: summary,
                escalationStatus: 'pending',
                escalationReason: summary,
                resultSummary: null,
                metadata: {
                    ...metadata,
                    ruleLibraryExecutionStatus: 'failed',
                    ruleLibraryExecutionError: summary,
                },
            },
        };
    }
    const libraryScope = getGlobalRuleLibraryScope({
        userId: requestedUserId,
        channel: requestedChannel,
    });
    const libraryRules = await memoryStore.getScopedBehavioralRules(libraryScope, 0);
    const existing = findBehavioralRuleMatch(libraryRules, rule);
    let summary;
    let appliedConfidence = confidence;
    if (action === 'rollback') {
        if (!historyId) {
            summary = 'Rule library rollback governance task is missing history metadata.';
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        ruleLibraryExecutionStatus: 'failed',
                        ruleLibraryExecutionError: summary,
                    },
                },
            };
        }
        const rolledBack = await memoryStore.rollbackScopedBehavioralRuleHistory(libraryScope, historyId, 'library_governance');
        if (!rolledBack) {
            summary = `Rule library history entry ${historyId} could not be rolled back.`;
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        ruleLibraryExecutionStatus: 'failed',
                        ruleLibraryExecutionError: summary,
                    },
                },
            };
        }
        summary = `Rolled back rule library history entry ${historyId} for rule "${rule}".`;
    }
    else if (action === 'remove') {
        const removed = await memoryStore.deleteScopedBehavioralRule(libraryScope, existing?.rule ?? rule);
        if (!removed) {
            summary = `Rule "${rule}" was not present in the cross-workspace rule library.`;
            return {
                summary,
                updates: {
                    status: 'blocked',
                    blockedReason: summary,
                    escalationStatus: 'pending',
                    escalationReason: summary,
                    resultSummary: null,
                    metadata: {
                        ...metadata,
                        ruleLibraryExecutionStatus: 'failed',
                        ruleLibraryExecutionError: summary,
                    },
                },
            };
        }
        summary = `Removed rule "${existing?.rule ?? rule}" from the cross-workspace rule library.`;
    }
    else {
        appliedConfidence = Math.max(confidence, existing?.confidence ?? 0);
        await memoryStore.upsertScopedBehavioralRule(libraryScope, {
            rule,
            category,
            confidence: appliedConfidence,
            source: 'library',
        });
        summary = existing
            ? `Updated rule library entry for "${rule}" to ${appliedConfidence}% confidence from workspace ${sourceWorkspaceId}.`
            : `Promoted rule "${rule}" into the cross-workspace rule library at ${appliedConfidence}% confidence.`;
    }
    return {
        summary,
        updates: {
            status: 'done',
            blockedReason: null,
            escalationStatus: 'acknowledged',
            escalationReason: null,
            resultSummary: summary,
            metadata: {
                ...metadata,
                ruleLibraryExecutionStatus: 'applied',
                ruleLibraryExecutedAt: new Date().toISOString(),
                ruleLibraryExecutedByUserId: params.actorUserId,
                ruleLibraryApprovedAt: new Date().toISOString(),
                ruleLibraryApprovedByUserId: params.actorUserId,
                ruleLibraryAction: action,
                ruleLibraryAppliedConfidence: action === 'promote' ? appliedConfidence : null,
                ruleLibraryExecutionSummary: summary,
                ruleLibraryAppliedScopeWorkspaceId: GLOBAL_RULE_LIBRARY_WORKSPACE_ID,
                ruleLibraryAppliedFromSource: source,
                ruleLibraryAppliedHistoryId: historyId ?? null,
                ruleLibraryApprovalNotes: params.notes ?? null,
            },
        },
    };
}
async function processRuleLibraryAutoGovernance(params) {
    const governancePolicy = parseRuleLibraryAutoGovernancePolicy(params.policy);
    if (!governancePolicy.enabled || params.tasks.length === 0)
        return 0;
    const pendingTasks = await memoryStore.listTeamTasks({ workspaceId: params.workspaceId });
    const pendingRuleGovernanceKeys = new Set(pendingTasks
        .filter((task) => !isClosedTeamTask(task) && (task.metadata ?? {})['governanceKind'] === 'rule_library_promotion')
        .map((task) => {
        const metadata = task.metadata ?? {};
        return buildRuleLibraryGovernanceTaskKey({
            userId: typeof metadata['requestUserId'] === 'string' ? metadata['requestUserId'] : '',
            channel: parseChannelName(metadata['requestChannel']) ?? 'web',
            action: parseGovernanceMetadataString(metadata, 'ruleLibraryAction') === 'remove'
                ? 'remove'
                : parseGovernanceMetadataString(metadata, 'ruleLibraryAction') === 'rollback'
                    ? 'rollback'
                    : 'promote',
            rule: parseGovernanceMetadataString(metadata, 'ruleLibraryRule') ?? '',
            historyId: parseGovernanceMetadataString(metadata, 'ruleLibraryHistoryId'),
        });
    }));
    let processed = 0;
    const ownerGroups = new Map();
    for (const task of params.tasks) {
        const metadata = task.metadata ?? {};
        const userId = typeof metadata['requestUserId'] === 'string' && metadata['requestUserId'].trim()
            ? metadata['requestUserId'].trim()
            : task.createdBy;
        const channel = parseChannelName(metadata['requestChannel']) ?? 'web';
        const key = `${userId}::${channel}`;
        if (!ownerGroups.has(key)) {
            ownerGroups.set(key, { userId, channel, tasks: [] });
        }
        ownerGroups.get(key).tasks.push(task);
    }
    for (const ownerGroup of ownerGroups.values()) {
        const approverUserId = params.policy.defaultHumanOwnerUserId
            ?? ownerGroup.tasks.find((task) => task.humanOwnerUserId)?.humanOwnerUserId
            ?? ownerGroup.userId;
        if (!approverUserId)
            continue;
        const health = computeWorkspaceRuleHealthMetrics(ownerGroup.tasks);
        const workspaceScope = {
            userId: ownerGroup.userId,
            channel: ownerGroup.channel,
            workspaceId: params.workspaceId,
        };
        const libraryScope = getGlobalRuleLibraryScope({
            userId: ownerGroup.userId,
            channel: ownerGroup.channel,
        });
        const [workspaceRules, libraryRules, libraryHistory] = await Promise.all([
            memoryStore.getScopedBehavioralRules(workspaceScope, 0),
            memoryStore.getScopedBehavioralRules(libraryScope, 0),
            memoryStore.getScopedBehavioralRuleHistory(libraryScope, 200),
        ]);
        const healthyForPromotion = health.doneCount >= governancePolicy.autoPromoteMinDoneTasks
            && health.blockedRate <= governancePolicy.healthyBlockedRate
            && health.consensusTimeoutRate <= governancePolicy.healthyConsensusTimeoutRate;
        if (healthyForPromotion) {
            const libraryRuleSet = new Set(libraryRules.map((rule) => normalizeKeyPart(rule.rule)));
            const promotionCandidates = workspaceRules
                .filter((rule) => !libraryRuleSet.has(normalizeKeyPart(rule.rule)))
                .filter((rule) => rule.confidence >= governancePolicy.autoPromoteMinConfidence
                && rule.evidenceCount >= governancePolicy.autoPromoteMinEvidenceCount)
                .sort((a, b) => b.confidence - a.confidence || b.evidenceCount - a.evidenceCount)
                .slice(0, governancePolicy.autoPromoteMaxPerCycle);
            for (const candidate of promotionCandidates) {
                const key = buildRuleLibraryGovernanceTaskKey({
                    userId: ownerGroup.userId,
                    channel: ownerGroup.channel,
                    action: 'promote',
                    rule: candidate.rule,
                });
                if (pendingRuleGovernanceKeys.has(key))
                    continue;
                const task = await ensureRuleLibraryPromotionApprovalTask({
                    action: 'promote',
                    workspaceId: params.workspaceId,
                    sourceWorkspaceId: params.workspaceId,
                    userId: ownerGroup.userId,
                    channel: ownerGroup.channel,
                    chatId: params.workspaceId,
                    actorUserId: 'system',
                    requestedForUserId: approverUserId,
                    rule: candidate.rule,
                    category: candidate.category,
                    confidence: candidate.confidence,
                    evidenceCount: candidate.evidenceCount,
                    source: candidate.source,
                    policy: params.policy,
                });
                if (task) {
                    pendingRuleGovernanceKeys.add(key);
                    processed++;
                }
            }
        }
        const unhealthyForDemotion = health.blockedRate >= governancePolicy.unhealthyBlockedRate
            || health.consensusTimeoutRate >= governancePolicy.unhealthyConsensusTimeoutRate;
        if (!unhealthyForDemotion)
            continue;
        const currentLibraryRuleSet = new Set(libraryRules.map((rule) => normalizeKeyPart(rule.rule)));
        const demotionCandidates = new Map();
        for (const entry of libraryHistory) {
            const key = normalizeKeyPart(entry.rule);
            if (!currentLibraryRuleSet.has(key))
                continue;
            if (!demotionCandidates.has(key)) {
                demotionCandidates.set(key, { rollbackCount: 0, deleteCount: 0, latestRollbackId: null });
            }
            const stats = demotionCandidates.get(key);
            if (entry.action === 'rollback') {
                stats.rollbackCount += 1;
                if (!stats.latestRollbackId)
                    stats.latestRollbackId = entry.id;
            }
            else if (entry.action === 'delete') {
                stats.deleteCount += 1;
            }
        }
        const removals = libraryRules
            .map((rule) => ({
            rule,
            stats: demotionCandidates.get(normalizeKeyPart(rule.rule)) ?? { rollbackCount: 0, deleteCount: 0, latestRollbackId: null },
        }))
            .filter(({ stats }) => stats.rollbackCount >= governancePolicy.autoDemoteRollbackThreshold
            || stats.deleteCount >= governancePolicy.autoDemoteDeleteThreshold)
            .sort((a, b) => (b.stats.rollbackCount + b.stats.deleteCount) - (a.stats.rollbackCount + a.stats.deleteCount)
            || b.rule.confidence - a.rule.confidence)
            .slice(0, governancePolicy.autoDemoteMaxPerCycle);
        for (const candidate of removals) {
            const key = buildRuleLibraryGovernanceTaskKey({
                userId: ownerGroup.userId,
                channel: ownerGroup.channel,
                action: 'remove',
                rule: candidate.rule.rule,
            });
            if (pendingRuleGovernanceKeys.has(key))
                continue;
            const task = await ensureRuleLibraryPromotionApprovalTask({
                action: 'remove',
                workspaceId: params.workspaceId,
                sourceWorkspaceId: params.workspaceId,
                userId: ownerGroup.userId,
                channel: ownerGroup.channel,
                chatId: params.workspaceId,
                actorUserId: 'system',
                requestedForUserId: approverUserId,
                rule: candidate.rule.rule,
                category: candidate.rule.category,
                confidence: candidate.rule.confidence,
                evidenceCount: candidate.rule.evidenceCount,
                source: candidate.rule.source,
                policy: params.policy,
            });
            if (task) {
                pendingRuleGovernanceKeys.add(key);
                processed++;
            }
        }
    }
    return processed;
}
export async function retrySharedMemoryGovernanceTaskById(taskId, actorUserId) {
    const task = await memoryStore.getTeamTask(taskId);
    if (!task)
        return { ok: false, task: null, error: 'Task not found' };
    const metadata = task.metadata ?? {};
    if (metadata['governanceKind'] !== 'shared_memory_authority') {
        return { ok: false, task, error: 'Task is not a shared memory governance task' };
    }
    if (task.status === 'done' || task.status === 'cancelled') {
        return { ok: false, task, error: `Task is already ${task.status}` };
    }
    if (metadata['sharedMemoryApprovalStatus'] !== 'approved') {
        return { ok: false, task, error: 'Task approval is not approved' };
    }
    const approvals = await memoryStore.listTeamTaskApprovals({
        taskId,
        status: 'approved',
    });
    const approval = approvals.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())[0];
    if (!approval) {
        return { ok: false, task, error: 'Approved governance approval not found' };
    }
    const policy = await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
    const execution = await executeApprovedSharedMemoryGovernanceTask({
        task,
        approval,
        actorUserId: actorUserId ?? approval.requestedForUserId,
        notes: approval.resolutionNotes ?? null,
        policy,
    });
    const updatedTask = await memoryStore.updateTeamTask(task.id, {
        status: execution.updates.status ?? task.status,
        blockedReason: execution.updates.blockedReason ?? task.blockedReason,
        escalationStatus: execution.updates.escalationStatus ?? task.escalationStatus,
        escalationReason: execution.updates.escalationReason ?? task.escalationReason,
        resultSummary: execution.updates.resultSummary ?? task.resultSummary,
        dueAt: execution.updates.status === 'done'
            ? task.dueAt
            : new Date(Date.now() + policy.defaultTaskSlaHours * 3600 * 1000),
        metadata: {
            ...metadata,
            ...(execution.updates.metadata ?? {}),
            sharedMemoryRetryAt: new Date().toISOString(),
            sharedMemoryRetriedByUserId: actorUserId ?? approval.requestedForUserId,
        },
    });
    return {
        ok: updatedTask?.status === 'done',
        task: updatedTask,
        error: updatedTask?.status === 'done' ? null : execution.summary,
    };
}
export async function resolveTeamApprovalById(approvalId, decision, notes, actorUserId, opts) {
    const approvals = await memoryStore.listTeamTaskApprovals();
    const approval = approvals.find((item) => item.id === approvalId);
    if (!approval)
        return { approvalUpdated: false, task: null };
    if (actorUserId && !opts?.bypassActorCheck && !canUserResolveTeamApproval(approval, actorUserId)) {
        throw new Error('Forbidden: approval belongs to another user');
    }
    const task = await memoryStore.getTeamTask(approval.taskId);
    if (!task)
        return { approvalUpdated: false, task: null };
    const policy = await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
    const dispatchCtx = getTaskDispatchContext(task);
    const taskMetadata = task.metadata ?? {};
    const isSharedMemoryGovernanceTask = taskMetadata['governanceKind'] === 'shared_memory_authority';
    const isTopologyPromotionGovernanceTask = taskMetadata['governanceKind'] === 'topology_candidate_promotion';
    const isTopologyControlGovernanceTask = taskMetadata['governanceKind'] === 'topology_control_action';
    const isRuleLibraryPromotionGovernanceTask = taskMetadata['governanceKind'] === 'rule_library_promotion';
    await memoryStore.updateTeamTaskApproval(approval.id, {
        status: decision === 'approve' ? 'approved' : 'rejected',
        resolutionNotes: notes ?? null,
        resolvedAt: new Date(),
    });
    const approvalActorUserId = actorUserId ?? approval.requestedForUserId;
    const governanceApprovalMetadata = isSharedMemoryGovernanceTask
        ? {
            sharedMemoryApprovalStatus: decision === 'approve' ? 'approved' : 'rejected',
            ...(decision === 'approve'
                ? {
                    sharedMemoryApprovedAt: new Date().toISOString(),
                    sharedMemoryApprovedByUserId: approvalActorUserId,
                }
                : {
                    sharedMemoryRejectedAt: new Date().toISOString(),
                    sharedMemoryRejectedByUserId: approvalActorUserId,
                }),
            sharedMemoryApprovalNotes: notes ?? null,
        }
        : (isTopologyPromotionGovernanceTask
            ? {
                candidatePromotionApprovalStatus: decision === 'approve' ? 'approved' : 'rejected',
                ...(decision === 'approve'
                    ? {
                        candidatePromotionApprovedAt: new Date().toISOString(),
                        candidatePromotionApprovedByUserId: approvalActorUserId,
                    }
                    : {
                        candidatePromotionRejectedAt: new Date().toISOString(),
                        candidatePromotionRejectedByUserId: approvalActorUserId,
                    }),
                candidatePromotionApprovalNotes: notes ?? null,
            }
            : (isTopologyControlGovernanceTask
                ? {
                    topologyControlApprovalStatus: decision === 'approve' ? 'approved' : 'rejected',
                    ...(decision === 'approve'
                        ? {
                            topologyControlApprovedAt: new Date().toISOString(),
                            topologyControlApprovedByUserId: approvalActorUserId,
                        }
                        : {
                            topologyControlRejectedAt: new Date().toISOString(),
                            topologyControlRejectedByUserId: approvalActorUserId,
                        }),
                    topologyControlApprovalNotes: notes ?? null,
                }
                : (isRuleLibraryPromotionGovernanceTask
                    ? {
                        ruleLibraryApprovalStatus: decision === 'approve' ? 'approved' : 'rejected',
                        ...(decision === 'approve'
                            ? {
                                ruleLibraryApprovedAt: new Date().toISOString(),
                                ruleLibraryApprovedByUserId: approvalActorUserId,
                            }
                            : {
                                ruleLibraryRejectedAt: new Date().toISOString(),
                                ruleLibraryRejectedByUserId: approvalActorUserId,
                            }),
                        ruleLibraryApprovalNotes: notes ?? null,
                    }
                    : {})));
    const approvedExecution = decision === 'approve'
        ? (isSharedMemoryGovernanceTask
            ? await executeApprovedSharedMemoryGovernanceTask({
                task,
                approval,
                actorUserId: approvalActorUserId,
                notes,
                policy,
            })
            : (isTopologyPromotionGovernanceTask
                ? await executeApprovedTopologyPromotionGovernanceTask({
                    task,
                    approval,
                    actorUserId: approvalActorUserId,
                    notes,
                })
                : (isTopologyControlGovernanceTask
                    ? await executeApprovedTopologyControlGovernanceTask({
                        task,
                        approval,
                        actorUserId: approvalActorUserId,
                        notes,
                    })
                    : (isRuleLibraryPromotionGovernanceTask
                        ? await executeApprovedRuleLibraryPromotionGovernanceTask({
                            task,
                            approval,
                            actorUserId: approvalActorUserId,
                            notes,
                        })
                        : null))))
        : null;
    if (decision === 'reject' && isTopologyPromotionGovernanceTask) {
        const topologyId = parseGovernanceMetadataString(taskMetadata, 'topologyId');
        const topology = topologyId ? await memoryStore.getTeamTopology(topologyId) : null;
        if (topology) {
            await memoryStore.updateTeamTopology(topology.id, {
                metadata: appendCandidateRolloutAuditEvent(topology.metadata, {
                    action: 'approval_rejected',
                    at: new Date().toISOString(),
                    actor: 'user',
                    reason: notes ?? null,
                    fromRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                    toRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                    candidateVersion: topology.candidateStrategy?.version ?? null,
                    stableVersion: topology.strategyVersion ?? 1,
                }),
            });
        }
    }
    const updatedTask = await memoryStore.updateTeamTask(task.id, decision === 'approve'
        ? {
            status: approvedExecution?.updates.status ?? ((isSharedMemoryGovernanceTask || isTopologyPromotionGovernanceTask || isTopologyControlGovernanceTask || isRuleLibraryPromotionGovernanceTask) ? 'open' : getDefaultCreatedTaskStatus(task)),
            blockedReason: approvedExecution?.updates.blockedReason ?? null,
            escalationStatus: approvedExecution?.updates.escalationStatus ?? 'acknowledged',
            escalationReason: approvedExecution?.updates.escalationReason ?? null,
            resultSummary: approvedExecution?.updates.resultSummary ?? task.resultSummary,
            dueAt: approvedExecution?.updates.status === 'done'
                ? task.dueAt
                : new Date(Date.now() + policy.defaultTaskSlaHours * 3600 * 1000),
            metadata: {
                ...taskMetadata,
                ...(approvedExecution?.updates.metadata ?? {}),
                ...governanceApprovalMetadata,
            },
        }
        : {
            status: 'cancelled',
            escalationStatus: 'acknowledged',
            escalationReason: notes ?? task.escalationReason,
            blockedReason: notes ?? task.blockedReason,
            metadata: {
                ...taskMetadata,
                ...governanceApprovalMetadata,
            },
        });
    const resolvedRecipients = getApprovalResolvedRecipients(task, approval);
    await createTeamNotificationSafe({
        workspaceId: task.workspaceId,
        recipientUserId: task.createdBy,
        type: 'approval_resolved',
        severity: decision === 'approve' ? 'info' : 'warning',
        title: `Approval ${decision === 'approve' ? 'approved' : 'rejected'}: ${task.title}`,
        message: notes ?? approvedExecution?.summary ?? approval.reason,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            decision,
            actorUserId: approvalActorUserId,
            requestedForUserId: approval.requestedForUserId,
            governanceKind: typeof taskMetadata['governanceKind'] === 'string' ? taskMetadata['governanceKind'] : null,
            topologyControlAction: typeof taskMetadata['topologyControlAction'] === 'string' ? taskMetadata['topologyControlAction'] : null,
            topologyId: typeof taskMetadata['topologyId'] === 'string' ? taskMetadata['topologyId'] : null,
            additionalRecipientUserIds: resolvedRecipients,
            approvalChain: Array.isArray(taskMetadata['approvalChain']) ? taskMetadata['approvalChain'] : [],
            ...(approvedExecution ? { executionSummary: approvedExecution.summary } : {}),
            deliveryChannel: dispatchCtx.channel,
            deliveryChatId: dispatchCtx.chatId,
        },
    });
    return { approvalUpdated: true, task: updatedTask };
}
export async function instantiateTeamTemplateById(templateId, ctx, overrides) {
    const template = await memoryStore.getTeamTemplate(templateId);
    if (!template)
        return [];
    return createTasksFromTemplate(template, ctx, overrides);
}
export async function instantiateTeamTopologyById(topologyId, ctx, overrides) {
    const topology = await memoryStore.getTeamTopology(topologyId);
    if (!topology)
        return [];
    const templateIds = dedupeStringList(overrides?.templateIds && overrides.templateIds.length > 0
        ? overrides.templateIds
        : topology.defaultTemplateIds);
    const workerAgentIds = dedupeStringList(overrides?.workerAgentIds && overrides.workerAgentIds.length > 0
        ? overrides.workerAgentIds
        : topology.workerAgentIds);
    const supervisorAgentId = overrides?.supervisorAgentId !== undefined ? overrides.supervisorAgentId : (topology.supervisorAgentId ?? null);
    const humanOwnerUserId = overrides?.humanOwnerUserId !== undefined
        ? overrides.humanOwnerUserId
        : (topology.defaultHumanOwnerUserId ?? null);
    const tasks = [];
    for (const templateId of templateIds) {
        const template = await memoryStore.getTeamTemplate(templateId);
        if (!template || template.workspaceId !== topology.workspaceId) {
            throw new Error(`Template not found in topology workspace: ${templateId}`);
        }
        tasks.push(...await createTasksFromTemplate(template, ctx, {
            humanOwnerUserId,
            variables: overrides?.variables,
            topologyId: topology.id,
            topologyName: topology.name,
            workerAgentIds,
            supervisorAgentId,
            topologyOrchestratorRules: topology.orchestratorRules ?? null,
            topologyAdaptiveModelPolicy: topology.adaptiveModelPolicy ?? null,
            topologyModelRoutes: topology.modelRoutes ?? null,
            topologyStrategyVersion: topology.strategyVersion ?? 1,
            topologyStrategyUpdatedAt: topology.strategyUpdatedAt ?? null,
            topologyStrategyHistory: topology.strategyHistory ?? null,
            topologySource: topology,
        }));
    }
    if (tasks.length > 0) {
        const notificationRecipient = humanOwnerUserId ?? ctx.userId;
        await createTeamNotificationSafe({
            workspaceId: topology.workspaceId,
            recipientUserId: notificationRecipient,
            type: 'topology_instantiated',
            severity: 'info',
            title: `Topology instantiated: ${topology.name}`,
            message: `Created ${tasks.length} tasks from topology ${topology.name}.`,
            metadata: {
                topologyId: topology.id,
                topologyName: topology.name,
                taskIds: tasks.map((task) => task.id),
                templateIds,
                workerAgentIds,
                supervisorAgentId,
                topologyOrchestratorRules: topology.orchestratorRules ?? null,
                topologyAdaptiveModelPolicy: topology.adaptiveModelPolicy ?? null,
                topologyModelRoutes: topology.modelRoutes ?? null,
                topologyStrategyVersion: topology.strategyVersion ?? 1,
                topologyStrategyUpdatedAt: topology.strategyUpdatedAt ?? null,
                topologyStrategyTracks: tasks.reduce((acc, task) => {
                    const track = (task.metadata ?? {})['topologyStrategyTrack'] === 'candidate' ? 'candidate' : 'stable';
                    acc[track] = (acc[track] ?? 0) + 1;
                    return acc;
                }, {}),
                ...(notificationRecipient === ctx.userId
                    ? {
                        deliveryChannel: ctx.channel,
                        deliveryChatId: ctx.chatId,
                    }
                    : {}),
            },
        });
    }
    return tasks;
}
// ── P4.1 helpers ─────────────────────────────────────────────────────────────
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
/** Run topology broadcast + success reflection after a task completes. */
async function runPostDoneEffects(updated, policy) {
    await shareTaskResultToWorkspaceMemory(updated, policy, updated.resultSummary);
    const topologyId = typeof (updated.metadata ?? {})['topologyId'] === 'string'
        ? updated.metadata['topologyId']
        : null;
    if (!topologyId)
        return;
    const topology = await memoryStore.getTeamTopology(topologyId);
    const taskTopology = materializeTaskTopology(updated, topology);
    const orchRules = taskTopology?.orchestratorRules ?? null;
    const successRoute = resolveTeamTopologyModelRoute(taskTopology, 'success_reflection');
    if (orchRules?.onTaskDone === 'broadcast_result') {
        void broadcastTaskDoneToWorkersSafe(updated);
    }
    if (updated.resultSummary && updated.assignedAgentId) {
        const dCtx = getTaskDispatchContext(updated);
        const propagateLearnings = policy.autoPropagateLearnings ?? true;
        void runSuccessReflectionSafe({
            workspaceId: updated.workspaceId,
            completedAgentId: updated.assignedAgentId,
            userId: dCtx.userId,
            channel: dCtx.channel,
            taskTitle: updated.title,
            taskDescription: updated.description,
            taskResult: updated.resultSummary,
            propagateToTeam: propagateLearnings,
            model: successRoute?.model ?? orchRules?.model ?? null,
            provider: successRoute?.provider ?? orchRules?.provider ?? null,
        }).then((practice) => {
            if (practice && propagateLearnings)
                return broadcastSuccessPracticeToTeamSafe(updated, practice);
            return undefined;
        });
    }
}
function appendStep(existing, step, maxSteps = 5) {
    return [...existing.slice(-(maxSteps - 1)), step];
}
/**
 * P4.2 Hardened Execution State Machine
 *
 * P4.2 improvements over P4.1:
 *   1. Unified retry boundary: effectiveMaxAttempts = min(task.maxAttempts, contractMax+1, 5)
 *      planRecovery receives attemptsRemaining computed from this unified value.
 *   2. High-value context signals injected: human decision context, previous result,
 *      attempt budget awareness.
 *   3. Structured ExecutionStep record replaces free-form runtimeLoop.
 *   4. Stale run detection: if task is already in_progress on entry, check for
 *      interrupted state before proceeding.
 *
 * Retry boundary rules (single source of truth):
 *   effectiveMaxAttempts = min(task.maxAttempts, contract.retryPolicy.maxAttempts + 1, 5)
 *   attemptsRemaining = effectiveMaxAttempts - attemptingTask.attemptCount
 *   recycleOrEscalateTask is ONLY called for final escalation/permanent-fail,
 *   never for in-loop retries.
 */
async function runDispatchLoop(taskId, policy, promptOverride, baseRunId) {
    const ABSOLUTE_LOOP_CAP = 5; // hard safety ceiling
    for (let loopIteration = 0; loopIteration < ABSOLUTE_LOOP_CAP; loopIteration++) {
        // Re-read fresh task state — picks up feedback written in previous iteration
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || !task.assignedAgentId)
            return task ?? null;
        const runId = loopIteration === 0 ? baseRunId : `${baseRunId}:r${loopIteration}`;
        const dispatchCtx = getTaskDispatchContext(task);
        // ── PREPARE ──────────────────────────────────────────────────────────────
        let workerPrompt;
        let contract = null;
        let inputStrategy = 'fresh';
        if (promptOverride) {
            workerPrompt = promptOverride;
        }
        else {
            contract = buildTaskContract(task);
            // ── P4.2: Unified effective max ─────────────────────────────────────────
            // Single source of truth for how many attempts are allowed.
            // task.maxAttempts = system-level limit (set at task creation)
            // contract.retryPolicy.maxAttempts = contract-level retry count (attempts = retries + 1)
            // ABSOLUTE_LOOP_CAP = absolute safety ceiling
            const effectiveMaxAttempts = Math.min(task.maxAttempts, contract.retryPolicy.maxAttempts + 1, ABSOLUTE_LOOP_CAP);
            // Fetch dependency results
            const depResults = [];
            if (task.dependsOnTaskIds && task.dependsOnTaskIds.length > 0) {
                for (const depId of task.dependsOnTaskIds) {
                    const dep = await memoryStore.getTeamTask(depId);
                    if (dep)
                        depResults.push({ id: dep.id, title: dep.title, resultSummary: dep.resultSummary });
                }
            }
            // ── P4.2: High-value context signals ────────────────────────────────────
            // 1. Human decision context (from task metadata — written by P3-A human-decision endpoint)
            const m = task.metadata ?? {};
            let humanDecisionContext = null;
            const lastHumanDecision = typeof m['lastHumanDecision'] === 'string' ? m['lastHumanDecision'] : null;
            const lastHumanDecisionReason = typeof m['lastHumanDecisionReason'] === 'string' ? m['lastHumanDecisionReason'] : null;
            if (lastHumanDecision) {
                humanDecisionContext = `人工${lastHumanDecision === 'rejected' ? '标记不合格' : lastHumanDecision === 'retry_requested' ? '请求重跑' : '确认通过'}`;
                if (lastHumanDecisionReason)
                    humanDecisionContext += `，原因：${lastHumanDecisionReason}`;
            }
            // 2. Previous result from workspace shared memory (for retry-after-rejection)
            let previousResultHint = null;
            if (loopIteration > 0 || lastHumanDecision === 'rejected') {
                try {
                    const sharedKey = `${policy.sharedMemoryPrefix || 'team:'}task:${taskId}`;
                    const sharedVal = await memoryStore.getScopedMemory({ userId: dispatchCtx.userId, channel: dispatchCtx.channel, workspaceId: task.workspaceId }, sharedKey);
                    if (sharedVal && typeof sharedVal === 'string')
                        previousResultHint = sharedVal.slice(0, 400);
                }
                catch { /* non-critical — proceed without */ }
            }
            // Set input strategy label for step record
            inputStrategy = loopIteration > 0
                ? (lastHumanDecision ? `retry_after_human_${lastHumanDecision}` : `retry_${loopIteration}`)
                : 'initial';
            // ── P4.3: First-run keyword recall from shared memory ─────────────────
            // For iteration 0, pull up to 3 related workspace memory entries by
            // keyword-matching the task title. Best-effort — failures are silently skipped.
            let relatedMemoryHints;
            if (loopIteration === 0) {
                try {
                    const memPrefix = policy.sharedMemoryPrefix || 'team:';
                    // Extract meaningful keywords (≥4 chars) from task title
                    const titleKeywords = task.title
                        .toLowerCase()
                        .replace(/[^\w\u4e00-\u9fff\s]/g, ' ')
                        .split(/\s+/)
                        .filter(w => w.length >= 4)
                        .slice(0, 5);
                    const candidateKeys = [
                        `${memPrefix}workspace:context`,
                        `${memPrefix}workspace:guidelines`,
                        ...titleKeywords.map(kw => `${memPrefix}topic:${kw}`),
                    ];
                    const hints = [];
                    const scope = { userId: dispatchCtx.userId, channel: dispatchCtx.channel, workspaceId: task.workspaceId };
                    for (const key of candidateKeys) {
                        if (hints.length >= 3)
                            break;
                        try {
                            const val = await memoryStore.getScopedMemory(scope, key);
                            if (val && typeof val === 'string' && val.trim().length > 10) {
                                hints.push({ key, value: val });
                            }
                        }
                        catch { /* skip this key */ }
                    }
                    if (hints.length > 0)
                        relatedMemoryHints = hints;
                }
                catch { /* non-critical */ }
            }
            const agentRecord = await memoryStore.getAgent(task.assignedAgentId);
            const ctx = assembleTaskContext({
                task, contract, dependencyResults: depResults,
                agentName: agentRecord?.name, workspaceName: task.workspaceId, runId,
                humanDecisionContext,
                previousResultHint,
                effectiveMaxAttempts,
                relatedMemoryHints,
            });
            // ── P4.3: PLAN phase ──────────────────────────────────────────────────
            // Derive an execution plan before constructing the final worker prompt.
            // The plan is pure (no I/O) and its promptSuffix shapes agent behaviour.
            const feedbackForPlan = {
                pendingHint: typeof m['pendingHint'] === 'string' ? m['pendingHint'] : null,
                latestObservation: (() => {
                    const lo = m['latestObservation'];
                    if (lo && typeof lo === 'object' && !Array.isArray(lo)) {
                        const l = lo;
                        if (typeof l['text'] === 'string')
                            return { text: l['text'], at: typeof l['at'] === 'string' ? l['at'] : '' };
                    }
                    return null;
                })(),
                latestError: (() => {
                    const le = m['latestError'];
                    if (le && typeof le === 'object' && !Array.isArray(le)) {
                        const l = le;
                        if (typeof l['message'] === 'string')
                            return { message: l['message'], errorClass: typeof l['errorClass'] === 'string' ? l['errorClass'] : 'unknown', at: '' };
                    }
                    return null;
                })(),
                nextSuggestedAction: typeof m['nextSuggestedAction'] === 'string' ? m['nextSuggestedAction'] : null,
                confidence: typeof m['confidence'] === 'number' ? m['confidence'] : null,
            };
            // attemptsRemaining for plan: use effectiveMaxAttempts - current attemptCount
            const planAttemptsRemaining = Math.max(0, effectiveMaxAttempts - task.attemptCount - 1);
            const lastRunStatus = typeof m['lastRunStatus'] === 'string' ? m['lastRunStatus'] : null;
            const missingCriteriaForPlan = Array.isArray(m['missingCriteria'])
                ? m['missingCriteria'].filter((x) => typeof x === 'string')
                : [];
            const execPlan = buildExecutionPlan(contract, feedbackForPlan, planAttemptsRemaining, {
                recoveryMode: contract.recoveryMode,
                lastHumanDecision: lastHumanDecision ?? undefined,
                lastRunStatus: lastRunStatus ?? undefined,
                missingCriteria: missingCriteriaForPlan,
            });
            // Build final worker prompt: context + optional plan suffix + contract
            const promptParts = [renderContextPrompt(ctx)];
            if (execPlan.promptSuffix.trim())
                promptParts.push(execPlan.promptSuffix);
            promptParts.push('', renderContractPrompt(contract));
            workerPrompt = promptParts.join('\n');
            await memoryStore.updateTeamTask(taskId, {
                metadata: {
                    ...m,
                    contract: { objective: contract.objective, doneCriteria: contract.doneCriteria, source: contract.source, retryPolicy: contract.retryPolicy },
                    contextSummary: ctx.summary,
                    effectiveMaxAttempts,
                    executionPhase: 'plan',
                    pendingHint: null, // consumed
                    currentPlan: {
                        strategy: execPlan.strategy,
                        keyAssumption: execPlan.keyAssumption,
                        primaryAction: execPlan.primaryAction,
                        expectedEvidence: execPlan.expectedEvidence,
                        fallbackAction: execPlan.fallbackAction,
                        planSummary: execPlan.planSummary,
                        builtAt: new Date().toISOString(),
                    },
                },
            }).catch(() => { });
        }
        // ── ACT ──────────────────────────────────────────────────────────────────
        const attemptingTask = await memoryStore.updateTeamTask(taskId, {
            status: 'in_progress',
            blockedReason: null,
            assignedAgentId: task.assignedAgentId,
            attemptCount: task.attemptCount + 1,
            lastAttemptAt: new Date(),
            escalationStatus: 'none',
            escalationReason: null,
            metadata: {
                ...(task.metadata ?? {}),
                currentRunId: runId,
                lastRunAt: new Date().toISOString(),
                lastRunStatus: 'running',
                executionPhase: 'act',
                pendingHint: null,
            },
        });
        if (!attemptingTask)
            return null;
        // ── P4.2: Unified attemptsRemaining ─────────────────────────────────────
        // Computed after ACT update so attemptCount is already incremented.
        const retryPolicy = contract?.retryPolicy ?? {
            maxAttempts: 2, retryDelayMs: 0,
            retryOn: ['provider_error', 'tool_error', 'environment_issue'],
        };
        const effectiveMax = contract
            ? Math.min(task.maxAttempts, contract.retryPolicy.maxAttempts + 1, ABSOLUTE_LOOP_CAP)
            : Math.min(task.maxAttempts, ABSOLUTE_LOOP_CAP);
        const attemptsRemaining = Math.max(0, effectiveMax - attemptingTask.attemptCount);
        // ── P4.2: Existing executionSteps (structured record) ────────────────────
        const prevSteps = Array.isArray((attemptingTask.metadata ?? {})['executionSteps'])
            ? attemptingTask.metadata['executionSteps']
            : [];
        // Read plan fields from metadata (written during PLAN phase)
        const planMeta = (attemptingTask.metadata ?? {})['currentPlan'];
        const planFields = planMeta && typeof planMeta === 'object' && !Array.isArray(planMeta)
            ? planMeta
            : null;
        const actStep = {
            iteration: loopIteration,
            phase: 'act',
            runId,
            at: new Date().toISOString(),
            inputStrategy,
            contextSummary: typeof (attemptingTask.metadata ?? {})['contextSummary'] === 'string'
                ? attemptingTask.metadata['contextSummary']
                : undefined,
            // P4.3: plan decision record fields
            strategy: typeof planFields?.['strategy'] === 'string' ? planFields['strategy'] : undefined,
            keyAssumption: typeof planFields?.['keyAssumption'] === 'string' ? planFields['keyAssumption'] : undefined,
            expectedEvidence: typeof planFields?.['expectedEvidence'] === 'string' ? planFields['expectedEvidence'] : undefined,
            planSummary: typeof planFields?.['planSummary'] === 'string' ? planFields['planSummary'] : undefined,
            recoveryMode: contract?.recoveryMode,
        };
        let resultSummary = null;
        let actError = null;
        try {
            resultSummary = await runTaskExecution(task, workerPrompt, task.assignedAgentId, dispatchCtx, 'execution', runId);
        }
        catch (err) {
            actError = err;
        }
        const observedAt = new Date().toISOString();
        // ── OBSERVE + RECOVER (error path) ───────────────────────────────────────
        if (actError) {
            const errMsg = String(actError).slice(0, 400);
            const errorClass = classifyError(actError);
            // P4.2: pass explicit attemptsRemaining — no more metadata.retryCount reading
            const recoveryPlan = planRecovery(errorClass, attemptsRemaining, retryPolicy);
            const errorStep = {
                ...actStep,
                phase: 'recover',
                at: observedAt,
                observation: errMsg.slice(0, 150),
                errorClass,
                recoveryAction: recoveryPlan.action,
                nextSuggestedAction: recoveryPlan.reason,
            };
            const updatedSteps = appendStep(prevSteps, errorStep);
            const baseMeta = {
                ...(attemptingTask.metadata ?? {}),
                lastRunId: runId, currentRunId: null,
                lastRunCompletedAt: observedAt, lastRunStatus: 'failed',
                lastRunError: errMsg, lastErrorClass: errorClass,
                lastRecoveryAction: recoveryPlan.action,
                executionPhase: 'recover',
                latestError: { message: errMsg, errorClass, at: observedAt },
                latestObservation: null,
                nextSuggestedAction: recoveryPlan.reason,
                executionSteps: updatedSteps,
            };
            if (recoveryPlan.action === 'fail_permanent') {
                await memoryStore.updateTeamTask(taskId, { metadata: baseMeta }).catch(() => { });
                return recycleOrEscalateTask(attemptingTask, errMsg, policy, 'execution');
            }
            if (recoveryPlan.action === 'escalate') {
                await memoryStore.updateTeamTask(taskId, { metadata: baseMeta }).catch(() => { });
                return recycleOrEscalateTask(attemptingTask, errMsg, policy, 'execution');
            }
            // Retryable: write hint + continue loop
            await memoryStore.updateTeamTask(taskId, {
                metadata: { ...baseMeta, pendingHint: recoveryPlan.hint ?? null },
            }).catch(() => { });
            if (recoveryPlan.delayMs > 0)
                await sleep(Math.min(recoveryPlan.delayMs, 8000));
            continue;
        }
        // ── OBSERVE + EVALUATE (success path) ────────────────────────────────────
        // P4.6.2: Shared finalization helper (also used by heartbeat done path)
        const { evalResult, artifacts: mergedArtifacts, effectiveChecksCount } = await finalizeTaskDone(attemptingTask, resultSummary ?? null, runId);
        const existingArtifacts = mergedArtifacts; // alias kept for recover-path metadata write below
        const doneCriteria = contract?.doneCriteria ?? [];
        // P4.3: actualEvidence = first 150 chars of resultSummary (what we found)
        const actualEvidence = (resultSummary ?? '').slice(0, 150) || undefined;
        const evalStep = {
            ...actStep,
            phase: 'evaluate',
            at: observedAt,
            observation: actualEvidence,
            actualEvidence,
            confidence: evalResult.confidence,
            secondPassApplied: evalResult.secondPassApplied,
            acceptanceMode: evalResult.acceptanceMode,
            nextSuggestedAction: evalResult.pass ? 'complete' : evalResult.reason.slice(0, 100),
        };
        // If doneCriteria not met and we have iterations left → quality_insufficient recovery
        if (!evalResult.pass && (doneCriteria.length > 0 || effectiveChecksCount > 0) && attemptsRemaining > 0) {
            const recoveryPlan = planRecovery('quality_insufficient', attemptsRemaining, retryPolicy);
            const recoverStep = {
                ...evalStep,
                phase: 'recover',
                errorClass: 'quality_insufficient',
                recoveryAction: recoveryPlan.action,
                nextSuggestedAction: recoveryPlan.hint ?? recoveryPlan.reason,
            };
            if (recoveryPlan.action === 'retry_with_hint' || recoveryPlan.action === 'retry_immediately') {
                await memoryStore.updateTeamTask(taskId, {
                    metadata: {
                        ...(attemptingTask.metadata ?? {}),
                        executionPhase: 'recover',
                        confidence: evalResult.confidence,
                        nextSuggestedAction: recoveryPlan.hint ?? recoveryPlan.reason,
                        pendingHint: recoveryPlan.hint ?? null,
                        latestObservation: { text: (resultSummary ?? '').slice(0, 300), at: observedAt },
                        latestError: null,
                        missingCriteria: evalResult.missingCriteria,
                        // P4.4/P4.5: persist evidence records, verification mode, artifacts, severity
                        acceptanceEvidence: evalResult.evidenceRecords ?? null,
                        verificationMode: evalResult.verificationMode ?? null,
                        evidenceSeverity: evalResult.evidenceSeverity ?? null,
                        hasAutoGeneratedChecks: evalResult.hasAutoGeneratedChecks ?? false,
                        artifacts: mergedArtifacts.length > 0 ? mergedArtifacts : (existingArtifacts.length > 0 ? existingArtifacts : null),
                        executionSteps: appendStep(prevSteps, recoverStep),
                    },
                }).catch(() => { });
                if (recoveryPlan.delayMs > 0)
                    await sleep(Math.min(recoveryPlan.delayMs, 5000));
                continue;
            }
            // Escalation path: fall through to done (we've done our best, verdict will flag it)
        }
        // ── DONE ─────────────────────────────────────────────────────────────────
        const completedAt = new Date().toISOString();
        const doneStep = {
            ...evalStep,
            phase: 'done',
            at: completedAt,
        };
        const updated = await memoryStore.updateTeamTask(taskId, {
            resultSummary,
            status: task.reviewRequired ? 'review_pending' : 'done',
            reviewStatus: task.reviewRequired ? 'pending' : 'not_required',
            blockedReason: null,
            escalationStatus: 'none',
            escalationReason: null,
            humanOwnerUserId: resolveHumanOwner(attemptingTask, policy),
            metadata: {
                ...(attemptingTask.metadata ?? {}),
                lastRunId: runId, currentRunId: null,
                lastRunCompletedAt: completedAt,
                lastRunStatus: task.reviewRequired ? 'review_pending' : 'done',
                executionPhase: 'done',
                confidence: evalResult.confidence,
                nextSuggestedAction: null,
                pendingHint: null,
                latestObservation: { text: (resultSummary ?? '').slice(0, 300), at: completedAt },
                latestError: null,
                // P4.4/P4.5: write evidence records, verification mode, artifacts, severity
                acceptanceEvidence: evalResult.evidenceRecords ?? null,
                verificationMode: evalResult.verificationMode ?? null,
                acceptanceChecksPassed: evalResult.acceptanceChecksPassed ?? null,
                acceptanceChecksTotal: evalResult.acceptanceChecksTotal ?? null,
                evidenceSeverity: evalResult.evidenceSeverity ?? null,
                hasAutoGeneratedChecks: evalResult.hasAutoGeneratedChecks ?? false,
                artifacts: mergedArtifacts.length > 0 ? mergedArtifacts : (existingArtifacts.length > 0 ? existingArtifacts : null),
                executionSteps: appendStep(prevSteps, doneStep),
            },
        });
        if (updated?.status === 'done')
            await runPostDoneEffects(updated, policy);
        // M5: automated hard evidence — wires evidence_verified task completions into capability unit promotion
        if (updated?.status === 'done') {
            recordAutoHardEvidenceForTask(updated, evalResult, runId).catch(() => { });
        }
        return updated;
    }
    // Loop cap exceeded — escalate
    const finalTask = await memoryStore.getTeamTask(taskId);
    if (!finalTask)
        return null;
    await memoryStore.updateTeamTask(taskId, {
        metadata: { ...(finalTask.metadata ?? {}), executionPhase: 'escalated', nextSuggestedAction: `超过执行循环上限（${ABSOLUTE_LOOP_CAP} 轮）` },
    }).catch(() => { });
    return recycleOrEscalateTask(finalTask, `执行循环超过上限（${ABSOLUTE_LOOP_CAP} 轮），自动升级`, policy, 'execution');
}
export async function dispatchTeamTaskById(taskId, promptOverride, policyOverride, options) {
    const task = await memoryStore.getTeamTask(taskId);
    if (!task)
        return null;
    if (!task.assignedAgentId)
        return null;
    const policy = policyOverride ?? await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
    const runId = options?.runId ?? `teamtask:${taskId}:${Date.now()}`;
    const dependencyStates = await getDependencyStates(task);
    const unmet = dependencyStates.filter((dep) => dep.status !== 'done');
    if (unmet.length > 0) {
        return memoryStore.updateTeamTask(taskId, {
            status: 'blocked',
            blockedReason: `Waiting on dependencies: ${unmet.map((dep) => dep.id).join(', ')}`,
            escalationStatus: 'none',
            escalationReason: null,
        });
    }
    return runDispatchLoop(taskId, policy, promptOverride, runId);
}
export async function claimTeamTaskById(taskId, agentId, actorUserId = 'system') {
    const task = await memoryStore.getTeamTask(taskId);
    if (!task || isClosedTeamTask(task))
        return task;
    const dependencyStates = await getDependencyStates(task);
    const unmet = dependencyStates.filter((dep) => dep.status !== 'done');
    return memoryStore.updateTeamTask(taskId, {
        assignedAgentId: agentId,
        status: unmet.length === 0 ? 'claimed' : 'blocked',
        blockedReason: unmet.length === 0 ? null : `Waiting on dependencies: ${unmet.map((dep) => dep.id).join(', ')}`,
        metadata: {
            ...(task.metadata ?? {}),
            claimRequestedBy: actorUserId,
            claimRequestedAt: new Date().toISOString(),
        },
    });
}
export async function raiseTeamTaskChallengeById(params) {
    const task = await memoryStore.getTeamTask(params.taskId);
    if (!task || isClosedTeamTask(task))
        return task;
    const metadata = task.metadata ?? {};
    const challenges = Array.isArray(metadata['challenges'])
        ? [...metadata['challenges']]
        : [];
    challenges.push({
        challengerAgentId: params.challengerAgentId,
        summary: params.summary.slice(0, 500),
        createdAt: new Date().toISOString(),
    });
    await createTeamMailboxMessageSafe({
        workspaceId: task.workspaceId,
        senderAgentId: params.challengerAgentId,
        recipientAgentId: task.assignedAgentId ?? task.reviewerAgentId ?? null,
        taskId: task.id,
        threadId: params.threadId,
        dedupeKey: buildMailboxDedupeKey('challenge', task.id, params.challengerAgentId, task.assignedAgentId ?? task.reviewerAgentId ?? ''),
        type: 'challenge',
        subject: `Challenge for task ${task.title}`,
        message: params.summary,
        metadata: { taskStatus: task.status },
    });
    return memoryStore.updateTeamTask(task.id, {
        status: 'challenge_open',
        metadata: {
            ...metadata,
            challenges,
            lastChallengeAt: new Date().toISOString(),
            lastChallengeAgentId: params.challengerAgentId,
        },
    });
}
export async function requestTeamTaskConsensusById(params) {
    const task = await memoryStore.getTeamTask(params.taskId);
    if (!task || isClosedTeamTask(task))
        return task;
    const metadata = task.metadata ?? {};
    const participants = [...new Set((params.participantAgentIds ?? []).filter(Boolean))];
    const participantWeights = params.participantWeights ?? await computeAdaptiveConsensusParticipantWeights({
        task,
        participantAgentIds: participants,
    });
    for (const participantAgentId of participants) {
        await createTeamMailboxMessageSafe({
            workspaceId: task.workspaceId,
            senderAgentId: params.requesterAgentId,
            recipientAgentId: participantAgentId,
            taskId: task.id,
            threadId: params.threadId,
            dedupeKey: buildMailboxDedupeKey('consensus_request', params.requestKey ?? 'initial', task.id, params.requesterAgentId, participantAgentId),
            type: 'consensus_request',
            subject: `Consensus requested for ${task.title}`,
            message: params.summary,
            metadata: {
                taskStatus: task.status,
                participantWeight: participantWeights[participantAgentId] ?? 1,
            },
        });
    }
    return memoryStore.updateTeamTask(task.id, {
        status: 'consensus_pending',
        metadata: {
            ...metadata,
            consensus: {
                requestedBy: params.requesterAgentId,
                requestedAt: new Date().toISOString(),
                participantAgentIds: participants,
                participantWeights,
                participantWeightSource: params.participantWeights ? 'manual' : 'adaptive_history',
                summary: params.summary.slice(0, 500),
                ...(params.protocolMetadata ?? {}),
            },
        },
    });
}
export async function reviewTeamTaskById(taskId, policyOverride) {
    const task = await memoryStore.getTeamTask(taskId);
    if (!task || task.status !== 'review_pending' || task.reviewStatus !== 'pending' || !task.reviewerAgentId)
        return task;
    const policy = policyOverride ?? await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
    const dispatchCtx = getTaskDispatchContext(task);
    const reviewPrompt = [
        'You are reviewing a completed workspace team task.',
        `Task ID: ${task.id}`,
        `Title: ${task.title}`,
        task.description ? `Task Description: ${task.description}` : null,
        task.resultSummary ? `Worker Result:\n${task.resultSummary}` : 'Worker Result: (empty)',
        'Return ONLY JSON: {"decision":"approve|changes_requested","summary":"short review summary"}',
    ].filter(Boolean).join('\n\n');
    try {
        const raw = await runTaskExecution(task, reviewPrompt, task.reviewerAgentId, dispatchCtx, 'review');
        const match = raw.match(/\{[\s\S]*\}/);
        let decision = 'changes_requested';
        let summary = raw.slice(0, 500);
        if (match) {
            const parsed = JSON.parse(match[0]);
            if (parsed.decision === 'approve')
                decision = 'approve';
            summary = typeof parsed.summary === 'string' ? parsed.summary.slice(0, 500) : summary;
        }
        if (decision !== 'approve') {
            if (task.assignedAgentId) {
                const topologyIdForReview = typeof (task.metadata ?? {})['topologyId'] === 'string'
                    ? task.metadata['topologyId']
                    : null;
                const reviewTopology = topologyIdForReview ? await memoryStore.getTeamTopology(topologyIdForReview) : null;
                const taskTopology = materializeTaskTopology(task, reviewTopology);
                const reviewOrchRules = taskTopology?.orchestratorRules ?? null;
                const challengeRoute = resolveTeamTopologyModelRoute(taskTopology, 'challenge_reflection');
                void runChallengeReflectionSafe({
                    workspaceId: task.workspaceId,
                    challengedAgentId: task.assignedAgentId,
                    userId: dispatchCtx.userId,
                    channel: dispatchCtx.channel,
                    taskTitle: task.title,
                    taskDescription: task.description,
                    taskResult: task.resultSummary,
                    objections: [summary],
                    propagateToTeam: policy.autoPropagateLearnings ?? true,
                    model: challengeRoute?.model ?? reviewOrchRules?.model ?? null,
                    provider: challengeRoute?.provider ?? reviewOrchRules?.provider ?? null,
                });
            }
            return recycleOrEscalateTask(task, summary, policy, 'review');
        }
        const updated = await memoryStore.updateTeamTask(taskId, {
            status: decision === 'approve' ? 'done' : 'blocked',
            reviewStatus: decision === 'approve' ? 'approved' : 'changes_requested',
            blockedReason: decision === 'approve' ? null : summary,
            escalationStatus: 'none',
            escalationReason: null,
            humanOwnerUserId: resolveHumanOwner(task, policy),
            resultSummary: task.resultSummary
                ? `${task.resultSummary}\n\n[Review] ${summary}`
                : `[Review] ${summary}`,
        });
        if (updated?.status === 'done') {
            await shareTaskResultToWorkspaceMemory(updated, policy, updated.resultSummary);
        }
        return updated;
    }
    catch (err) {
        log.warn({ err: String(err), taskId }, 'Team task review failed');
        return recycleOrEscalateTask(task, String(err).slice(0, 500), policy, 'review');
    }
}
export async function processTeamSwarmProtocol(workspaceId) {
    const tasks = await memoryStore.listTeamTasks(workspaceId ? { workspaceId } : undefined);
    let processed = 0;
    const now = Date.now();
    const nowIso = new Date(now).toISOString();
    const policyCache = new Map();
    const topologyCache = new Map();
    const topologyRulesCache = new Map();
    const getTopology = async (topologyId) => {
        if (!topologyId)
            return null;
        if (topologyCache.has(topologyId))
            return topologyCache.get(topologyId) ?? null;
        const topology = await memoryStore.getTeamTopology(topologyId);
        topologyCache.set(topologyId, topology);
        return topology;
    };
    const getOrchRules = async (topologyId) => {
        if (!topologyId)
            return null;
        if (topologyRulesCache.has(topologyId))
            return topologyRulesCache.get(topologyId) ?? null;
        const topology = await getTopology(topologyId);
        const rules = parseOrchestratorRules(topology?.metadata?.['orchestratorRules']);
        topologyRulesCache.set(topologyId, rules);
        return rules;
    };
    const getTaskTopology = async (task) => {
        const topologyId = typeof (task.metadata ?? {})['topologyId'] === 'string'
            ? task.metadata['topologyId']
            : null;
        return materializeTaskTopology(task, await getTopology(topologyId));
    };
    for (const task of tasks) {
        if (isClosedTeamTask(task))
            continue;
        const metadata = task.metadata ?? {};
        const policy = policyCache.get(task.workspaceId) ?? await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
        policyCache.set(task.workspaceId, policy);
        if ((task.status === 'open' || task.status === 'proposed') && !task.assignedAgentId) {
            const workerAgentIds = Array.isArray(metadata['topologyWorkerAgentIds'])
                ? metadata['topologyWorkerAgentIds']
                    .filter((item) => typeof item === 'string' && item.trim().length > 0)
                : [];
            const protocolAnnouncedAt = typeof metadata['protocolAnnouncedAt'] === 'string'
                ? Date.parse(metadata['protocolAnnouncedAt'])
                : Number.NaN;
            const announcementTimedOut = Number.isFinite(protocolAnnouncedAt)
                && protocolAnnouncedAt + getProtocolAnnouncementTimeoutMinutes(policy) * 60_000 <= now;
            if (announcementTimedOut) {
                const updated = await memoryStore.updateTeamTask(task.id, {
                    status: 'escalated',
                    escalationStatus: 'pending',
                    escalationReason: `No agent claimed the shared task within ${getProtocolAnnouncementTimeoutMinutes(policy)} minutes.`,
                    blockedReason: 'Shared task announcement timed out without a claim.',
                    humanOwnerUserId: resolveHumanOwner(task, policy),
                    metadata: {
                        ...metadata,
                        protocolTimedOutAt: nowIso,
                        protocolTimeoutStage: 'announcement',
                    },
                });
                await createTeamNotificationSafe({
                    workspaceId: task.workspaceId,
                    recipientUserId: resolveHumanOwner(task, policy),
                    type: 'task_escalated',
                    severity: 'warning',
                    title: `Task claim timed out: ${task.title}`,
                    message: `No agent claimed task ${task.title} within the protocol announcement window.`,
                    taskId: task.id,
                    metadata: {
                        protocolTimeoutStage: 'announcement',
                        protocolAnnouncedAt: metadata['protocolAnnouncedAt'] ?? null,
                    },
                });
                if (updated)
                    processed++;
                continue;
            }
            if (workerAgentIds.length > 0 && !metadata['protocolAnnouncedAt']) {
                const threadId = getTaskProtocolThreadId(task.id, 'task');
                for (const workerAgentId of workerAgentIds) {
                    await createTeamMailboxMessageSafe({
                        workspaceId: task.workspaceId,
                        senderAgentId: typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null,
                        recipientAgentId: workerAgentId,
                        taskId: task.id,
                        threadId,
                        dedupeKey: buildMailboxDedupeKey('task_announce', task.id, workerAgentId),
                        type: 'task_event',
                        subject: `Task available to claim: ${task.title}`,
                        message: `Shared task ${task.title} is available to claim. Review the task context and claim it if you are the best fit.`,
                        metadata: { protocolRule: 'task_announce', taskStatus: task.status },
                    });
                }
                const updated = await memoryStore.updateTeamTask(task.id, {
                    metadata: {
                        ...metadata,
                        protocolAnnouncedAt: nowIso,
                        protocolAnnouncedAgentIds: workerAgentIds,
                    },
                });
                if (updated)
                    processed++;
            }
        }
        if (task.status === 'challenge_open') {
            const participants = getConsensusParticipants(task);
            if (participants.length === 0)
                continue;
            const summary = getLatestChallengeSummary(task);
            const topology = await getTaskTopology(task);
            const orchRules = topology?.orchestratorRules ?? null;
            const supervisorAgentId = typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null;
            // --- RULE: onConflict = 'supervisor_resolve' ---
            // Supervisor AI makes an immediate, binding decision instead of waiting for a full consensus vote.
            if (orchRules?.onConflict === 'supervisor_resolve') {
                const orchestratorRoute = resolveTeamTopologyModelRoute(topology, 'orchestrator');
                const decision = await evaluateSupervisorConflictSafe({
                    task,
                    challengeSummary: summary,
                    rules: {
                        ...orchRules,
                        model: orchestratorRoute?.model ?? orchRules.model ?? null,
                        provider: orchestratorRoute?.provider ?? orchRules.provider ?? null,
                    },
                });
                const dispatchCtx = getTaskDispatchContext(task);
                if (decision === 'approve') {
                    // Challenge dismissed — restore working status and notify participants
                    const restoreStatus = task.assignedAgentId ? 'in_progress' : 'open';
                    const updated = await memoryStore.updateTeamTask(task.id, {
                        status: restoreStatus,
                        blockedReason: null,
                        metadata: {
                            ...metadata,
                            supervisorResolution: { decision: 'approve', resolvedAt: nowIso, resolvedBy: 'supervisor_resolve' },
                        },
                    });
                    for (const participantAgentId of participants) {
                        await createTeamMailboxMessageSafe({
                            workspaceId: task.workspaceId,
                            senderAgentId: supervisorAgentId,
                            recipientAgentId: participantAgentId,
                            taskId: task.id,
                            dedupeKey: buildMailboxDedupeKey('supervisor_resolve_approve', task.id, participantAgentId),
                            type: 'task_event',
                            subject: `Challenge dismissed: ${task.title}`,
                            message: `Supervisor reviewed the challenge for "${task.title}" and approved the original work. Task continues.`,
                            metadata: { protocolRule: 'supervisor_resolve', resolution: 'approve' },
                        });
                    }
                    if (updated)
                        processed++;
                }
                else {
                    // Challenge upheld — run reflection and apply onConsensusRejected rule
                    if (task.assignedAgentId) {
                        const challengeRoute = resolveTeamTopologyModelRoute(topology, 'challenge_reflection');
                        void runChallengeReflectionSafe({
                            workspaceId: task.workspaceId,
                            challengedAgentId: task.assignedAgentId,
                            userId: dispatchCtx.userId,
                            channel: dispatchCtx.channel,
                            taskTitle: task.title,
                            taskDescription: task.description,
                            taskResult: task.resultSummary,
                            objections: [summary],
                            propagateToTeam: policy.autoPropagateLearnings ?? true,
                            model: challengeRoute?.model ?? orchRules.model ?? null,
                            provider: challengeRoute?.provider ?? orchRules.provider ?? null,
                        });
                    }
                    const resolvedStatus = orchRules.onConsensusRejected === 'reflect_and_retry'
                        ? getDefaultCreatedTaskStatus(task)
                        : 'blocked';
                    const updated = await memoryStore.updateTeamTask(task.id, {
                        status: resolvedStatus,
                        blockedReason: resolvedStatus === 'blocked' ? `Supervisor upheld challenge: ${summary.slice(0, 300)}` : null,
                        metadata: {
                            ...metadata,
                            supervisorResolution: { decision: 'changes_requested', resolvedAt: nowIso, resolvedBy: 'supervisor_resolve' },
                        },
                    });
                    for (const participantAgentId of participants) {
                        await createTeamMailboxMessageSafe({
                            workspaceId: task.workspaceId,
                            senderAgentId: supervisorAgentId,
                            recipientAgentId: participantAgentId,
                            taskId: task.id,
                            dedupeKey: buildMailboxDedupeKey('supervisor_resolve_reject', task.id, participantAgentId),
                            type: 'task_event',
                            subject: `Challenge upheld: ${task.title}`,
                            message: `Supervisor reviewed the challenge for "${task.title}" and upheld it. Task must be revised.`,
                            metadata: { protocolRule: 'supervisor_resolve', resolution: 'changes_requested' },
                        });
                    }
                    if (updated)
                        processed++;
                }
                continue;
            }
            // --- RULE: onConflict = 'consensus' (default) ---
            // Broadcast consensus_request to all participants and wait for votes.
            const threadId = getTaskProtocolThreadId(task.id, 'consensus');
            for (const participantAgentId of participants) {
                await createTeamMailboxMessageSafe({
                    workspaceId: task.workspaceId,
                    senderAgentId: supervisorAgentId,
                    recipientAgentId: participantAgentId,
                    taskId: task.id,
                    threadId,
                    dedupeKey: buildMailboxDedupeKey('protocol_consensus_request', task.id, participantAgentId),
                    type: 'consensus_request',
                    subject: `Consensus required: ${task.title}`,
                    message: summary,
                    metadata: { protocolRule: 'challenge_to_consensus', taskStatus: task.status },
                });
            }
            const updated = await memoryStore.updateTeamTask(task.id, {
                status: 'consensus_pending',
                metadata: {
                    ...metadata,
                    consensus: {
                        ...(metadata['consensus'] && typeof metadata['consensus'] === 'object' ? metadata['consensus'] : {}),
                        requestedBy: 'orchestrator',
                        requestedAt: nowIso,
                        participantAgentIds: participants,
                        summary,
                        threadId,
                        protocolRule: 'challenge_to_consensus',
                    },
                },
            });
            if (updated)
                processed++;
            continue;
        }
        if (task.status === 'consensus_pending') {
            const topology = await getTaskTopology(task);
            const orchRules = topology?.orchestratorRules ?? null;
            const consensus = metadata['consensus'] && typeof metadata['consensus'] === 'object'
                ? metadata['consensus']
                : {};
            const participants = dedupeStringList(Array.isArray(consensus['participantAgentIds'])
                ? consensus['participantAgentIds']
                    .filter((item) => typeof item === 'string' && item.trim().length > 0)
                : getConsensusParticipants(task));
            if (participants.length === 0)
                continue;
            const threadId = typeof consensus['threadId'] === 'string' && consensus['threadId'].trim()
                ? consensus['threadId'].trim()
                : getTaskProtocolThreadId(task.id, 'consensus');
            const deliberationStage = consensus['deliberationStage'] === 'debate'
                ? 'debate'
                : consensus['deliberationStage'] === 'revote'
                    ? 'revote'
                    : 'none';
            const participantWeights = consensus['participantWeights'] && typeof consensus['participantWeights'] === 'object' && !Array.isArray(consensus['participantWeights'])
                ? consensus['participantWeights']
                : {};
            const consensusRequestedAt = deliberationStage === 'debate'
                ? (typeof consensus['debateRequestedAt'] === 'string'
                    ? Date.parse(consensus['debateRequestedAt'])
                    : (typeof consensus['requestedAt'] === 'string' ? Date.parse(consensus['requestedAt']) : Number.NaN))
                : (typeof consensus['requestedAt'] === 'string'
                    ? Date.parse(consensus['requestedAt'])
                    : Number.NaN);
            const responses = await memoryStore.listTeamMailboxMessages({
                workspaceId: task.workspaceId,
                taskId: task.id,
                threadId,
                type: 'consensus_response',
            });
            const latestByAgent = new Map();
            for (const response of responses) {
                if (!response.senderAgentId || !participants.includes(response.senderAgentId))
                    continue;
                if (Number.isFinite(consensusRequestedAt) && response.createdAt.getTime() < consensusRequestedAt)
                    continue;
                if (!latestByAgent.has(response.senderAgentId)) {
                    latestByAgent.set(response.senderAgentId, response);
                }
            }
            const totalWeight = participants.reduce((sum, participantAgentId) => {
                const configured = Number(participantWeights[participantAgentId]);
                return sum + ((Number.isFinite(configured) && configured > 0) ? configured : 1);
            }, 0);
            let approveWeight = 0;
            let changesRequestedWeight = 0;
            const responseSummaries = [...latestByAgent.values()].map((response) => {
                const decision = parseConsensusDecision(response);
                const weight = parseConsensusVoteWeight(response, participantWeights);
                if (decision === 'approve')
                    approveWeight += weight;
                else
                    changesRequestedWeight += weight;
                return {
                    agentId: response.senderAgentId ?? 'unknown',
                    decision,
                    weight,
                    rationale: parseConsensusRationale(response),
                };
            });
            const quorum = Math.max(1, totalWeight / 2);
            const allResponsesReceived = latestByAgent.size >= participants.length;
            const consensusTimeoutMs = getProtocolConsensusTimeoutMinutes(policy) * 60_000;
            const consensusTimedOut = Number.isFinite(consensusRequestedAt)
                && consensusRequestedAt + consensusTimeoutMs <= now;
            // ── Consensus reminder: re-ping silent agents at the halfway mark ──────
            // If we've passed 50% of the timeout window AND some participants still
            // haven't voted AND we haven't sent a reminder yet, send them a nudge.
            // Uses a distinct dedupeKey so it's delivered as a new message.
            const reminderSentAt = typeof consensus['reminderSentAt'] === 'string'
                ? Date.parse(consensus['reminderSentAt'])
                : null;
            const halfwayMs = Number.isFinite(consensusRequestedAt)
                ? consensusRequestedAt + consensusTimeoutMs / 2
                : null;
            const shouldSendReminder = !allResponsesReceived
                && !consensusTimedOut
                && halfwayMs !== null
                && now >= halfwayMs
                && reminderSentAt === null;
            if (shouldSendReminder) {
                const silentParticipants = participants.filter((id) => !latestByAgent.has(id));
                for (const participantAgentId of silentParticipants) {
                    await createTeamMailboxMessageSafe({
                        workspaceId: task.workspaceId,
                        senderAgentId: typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null,
                        recipientAgentId: participantAgentId,
                        taskId: task.id,
                        threadId,
                        dedupeKey: buildMailboxDedupeKey('consensus_reminder', task.id, participantAgentId),
                        type: 'consensus_request',
                        subject: `Reminder: consensus vote needed for "${task.title}"`,
                        message: `${typeof consensus['summary'] === 'string' ? consensus['summary'] : ''}\n\nThis is a reminder — your vote is still required. Please respond with APPROVE or CHANGES_REQUESTED.`,
                        metadata: { protocolRule: 'consensus_reminder', taskStatus: task.status },
                    });
                }
                await memoryStore.updateTeamTask(task.id, {
                    metadata: {
                        ...metadata,
                        consensus: { ...consensus, reminderSentAt: nowIso, reminderParticipants: silentParticipants },
                    },
                });
                log.info({ taskId: task.id, silentCount: silentParticipants.length }, 'Consensus reminder sent to non-responding participants');
            }
            // ── end consensus reminder ────────────────────────────────────────────
            const deliberationRound = Number.isFinite(Number(consensus['deliberationRound']))
                ? Math.max(0, Math.floor(Number(consensus['deliberationRound'])))
                : 0;
            const maxDeliberationRounds = getProtocolDeliberationMaxRounds(policy, topology);
            const shouldDeliberate = deliberationStage !== 'debate'
                && (allResponsesReceived || consensusTimedOut)
                && approveWeight > 0
                && changesRequestedWeight > 0
                && approveWeight <= quorum
                && changesRequestedWeight <= quorum
                && deliberationRound < maxDeliberationRounds;
            if (deliberationStage === 'debate' && (allResponsesReceived || consensusTimedOut)) {
                const revotePrompt = buildConsensusRevotePrompt({
                    task,
                    round: deliberationRound,
                    debateResponses: responseSummaries,
                });
                for (const participantAgentId of participants) {
                    await createTeamMailboxMessageSafe({
                        workspaceId: task.workspaceId,
                        senderAgentId: typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null,
                        recipientAgentId: participantAgentId,
                        taskId: task.id,
                        threadId,
                        dedupeKey: buildMailboxDedupeKey('consensus_revote', task.id, participantAgentId, String(deliberationRound)),
                        type: 'consensus_request',
                        subject: `Consensus revote round ${deliberationRound}: ${task.title}`,
                        message: revotePrompt,
                        metadata: {
                            protocolRule: 'consensus_revote',
                            deliberationStage: 'revote',
                            deliberationRound,
                            taskStatus: task.status,
                        },
                    });
                }
                const updated = await memoryStore.updateTeamTask(task.id, {
                    metadata: {
                        ...metadata,
                        consensus: {
                            ...consensus,
                            participantAgentIds: participants,
                            participantWeights,
                            threadId,
                            requestedAt: nowIso,
                            deliberationStage: 'revote',
                            deliberationRound,
                            maxDeliberationRounds,
                            debateResponses: responseSummaries,
                            debateCompletedAt: nowIso,
                            totalWeight,
                            quorumWeight: quorum,
                            approveWeight,
                            changesRequestedWeight,
                            responseAgentIds: [],
                            responseCount: 0,
                            awaitingAgentIds: participants,
                            latestResponses: responseSummaries,
                        },
                    },
                });
                if (updated)
                    processed++;
                continue;
            }
            if (shouldDeliberate) {
                const nextRound = deliberationRound + 1;
                const deliberationSummary = buildConsensusDebatePrompt({
                    task,
                    round: nextRound,
                    responses: responseSummaries,
                });
                for (const participantAgentId of participants) {
                    await createTeamMailboxMessageSafe({
                        workspaceId: task.workspaceId,
                        senderAgentId: typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null,
                        recipientAgentId: participantAgentId,
                        taskId: task.id,
                        threadId,
                        dedupeKey: buildMailboxDedupeKey('consensus_deliberation', task.id, participantAgentId, String(nextRound)),
                        type: 'consensus_request',
                        subject: `Consensus debate round ${nextRound}: ${task.title}`,
                        message: deliberationSummary,
                        metadata: {
                            protocolRule: 'consensus_debate',
                            deliberationStage: 'debate',
                            deliberationRound: nextRound,
                            taskStatus: task.status,
                        },
                    });
                }
                const updated = await memoryStore.updateTeamTask(task.id, {
                    metadata: {
                        ...metadata,
                        consensus: {
                            ...consensus,
                            participantAgentIds: participants,
                            participantWeights,
                            threadId,
                            debateRequestedAt: nowIso,
                            deliberationStage: 'debate',
                            deliberationRound: nextRound,
                            maxDeliberationRounds,
                            deliberationRequestedAt: nowIso,
                            deliberationSummary,
                            totalWeight,
                            quorumWeight: quorum,
                            approveWeight,
                            changesRequestedWeight,
                            responseAgentIds: [],
                            responseCount: 0,
                            awaitingAgentIds: participants,
                            priorResponses: responseSummaries,
                            latestResponses: responseSummaries,
                        },
                    },
                });
                if (updated)
                    processed++;
                continue;
            }
            const resolution = changesRequestedWeight > quorum
                ? 'changes_requested'
                : approveWeight > quorum
                    ? 'approved'
                    : allResponsesReceived
                        ? (changesRequestedWeight >= approveWeight ? 'changes_requested' : 'approved')
                        : consensusTimedOut && latestByAgent.size > 0
                            ? (changesRequestedWeight >= approveWeight ? 'changes_requested' : 'approved')
                            : null;
            if (consensusTimedOut && latestByAgent.size === 0) {
                const updated = await memoryStore.updateTeamTask(task.id, {
                    status: 'escalated',
                    escalationStatus: 'pending',
                    escalationReason: `Consensus timed out after ${getProtocolConsensusTimeoutMinutes(policy)} minutes without responses.`,
                    blockedReason: 'Consensus timed out without participant responses.',
                    humanOwnerUserId: resolveHumanOwner(task, policy),
                    metadata: {
                        ...metadata,
                        consensus: {
                            ...consensus,
                            participantAgentIds: participants,
                            participantWeights,
                            threadId,
                            timedOutAt: nowIso,
                            resolution: 'timeout_escalated',
                            awaitingAgentIds: participants,
                            responseCount: 0,
                        },
                    },
                });
                await createTeamNotificationSafe({
                    workspaceId: task.workspaceId,
                    recipientUserId: resolveHumanOwner(task, policy),
                    type: 'task_escalated',
                    severity: 'warning',
                    title: `Consensus timed out: ${task.title}`,
                    message: `Consensus for task ${task.title} timed out without participant responses.`,
                    taskId: task.id,
                    metadata: {
                        protocolTimeoutStage: 'consensus',
                        participantAgentIds: participants,
                    },
                });
                if (updated)
                    processed++;
                continue;
            }
            if (!resolution) {
                const updated = await memoryStore.updateTeamTask(task.id, {
                    metadata: {
                        ...metadata,
                        consensus: {
                            ...consensus,
                            participantAgentIds: participants,
                            participantWeights,
                            threadId,
                            totalWeight,
                            quorumWeight: quorum,
                            approveWeight,
                            changesRequestedWeight,
                            responseAgentIds: [...latestByAgent.keys()],
                            responseCount: latestByAgent.size,
                            awaitingAgentIds: participants.filter((participantAgentId) => !latestByAgent.has(participantAgentId)),
                            latestResponses: responseSummaries,
                            timedOutAt: consensusTimedOut ? nowIso : null,
                        },
                    },
                });
                if (updated)
                    processed++;
                continue;
            }
            const objectionMessages = responseSummaries
                .filter((response) => response.decision === 'changes_requested')
                .map((response) => `${response.agentId}[w=${response.weight}]: ${response.rationale}`);
            // --- RULE: onConsensusRejected ---
            // 'reflect_and_retry': agent already has a new behavioral rule (from runChallengeReflectionSafe above),
            //   so reset to working status rather than blocking.
            // 'block' (default): park task as blocked for human/escalation review.
            const resolvedStatus = resolution === 'approved'
                ? (task.assignedAgentId ? 'claimed' : 'open')
                : orchRules?.onConsensusRejected === 'reflect_and_retry'
                    ? getDefaultCreatedTaskStatus(task)
                    : 'blocked';
            const updated = await memoryStore.updateTeamTask(task.id, {
                status: resolvedStatus,
                blockedReason: resolution === 'approved' || resolvedStatus !== 'blocked'
                    ? null
                    : `Consensus objections: ${objectionMessages.join(' | ').slice(0, 500)}`,
                metadata: {
                    ...metadata,
                    consensus: {
                        ...consensus,
                        participantAgentIds: participants,
                        participantWeights,
                        threadId,
                        resolvedAt: nowIso,
                        resolution,
                        resolvedBy: 'orchestrator',
                        responseAgentIds: [...latestByAgent.keys()],
                        responseCount: latestByAgent.size,
                        totalWeight,
                        quorumWeight: quorum,
                        approveWeight,
                        changesRequestedWeight,
                        latestResponses: responseSummaries,
                    },
                },
            });
            for (const participantAgentId of participants) {
                await createTeamMailboxMessageSafe({
                    workspaceId: task.workspaceId,
                    senderAgentId: typeof metadata['topologySupervisorAgentId'] === 'string' ? metadata['topologySupervisorAgentId'] : null,
                    recipientAgentId: participantAgentId,
                    taskId: task.id,
                    threadId,
                    dedupeKey: buildMailboxDedupeKey('protocol_consensus_resolution', task.id, participantAgentId, resolution),
                    type: 'task_event',
                    subject: `Consensus resolved: ${task.title}`,
                    message: resolution === 'approved'
                        ? `Consensus resolved for ${task.title}. Work can continue.`
                        : `Consensus resolved for ${task.title} with objections. Review blockers before continuing.`,
                    metadata: { protocolRule: 'consensus_resolution', resolution },
                });
            }
            if (updated && resolution === 'changes_requested' && task.assignedAgentId) {
                const dispatchCtx = getTaskDispatchContext(task);
                const challengeRoute = resolveTeamTopologyModelRoute(topology, 'challenge_reflection');
                void runChallengeReflectionSafe({
                    workspaceId: task.workspaceId,
                    challengedAgentId: task.assignedAgentId,
                    userId: dispatchCtx.userId,
                    channel: dispatchCtx.channel,
                    taskTitle: task.title,
                    taskDescription: task.description,
                    taskResult: task.resultSummary,
                    objections: objectionMessages,
                    propagateToTeam: policy.autoPropagateLearnings ?? true,
                    model: challengeRoute?.model ?? orchRules?.model ?? null,
                    provider: challengeRoute?.provider ?? orchRules?.provider ?? null,
                });
            }
            if (updated)
                processed++;
        }
    }
    // Adaptive rules: after processing all tasks, check each topology's metrics and adapt rules if warranted.
    // Uses the already-loaded tasks list — no extra DB query.
    const topologyTaskMap = new Map();
    const workspaceTaskMap = new Map();
    for (const task of tasks) {
        if (!workspaceTaskMap.has(task.workspaceId))
            workspaceTaskMap.set(task.workspaceId, []);
        workspaceTaskMap.get(task.workspaceId).push(task);
        const tid = typeof (task.metadata ?? {})['topologyId'] === 'string'
            ? task.metadata['topologyId']
            : null;
        if (tid) {
            if (!topologyTaskMap.has(tid))
                topologyTaskMap.set(tid, []);
            topologyTaskMap.get(tid).push(task);
        }
    }
    for (const [topologyId, topTasks] of topologyTaskMap) {
        const currentRules = topologyRulesCache.get(topologyId);
        const topWorkspaceId = topTasks[0]?.workspaceId;
        if (!topWorkspaceId)
            continue;
        if (currentRules) {
            void adaptOrchestratorRulesSafe({
                topologyId,
                workspaceId: topWorkspaceId,
                tasks: topTasks,
                currentRules,
            });
        }
        void adaptTopologyModelsSafe({
            topologyId,
            workspaceId: topWorkspaceId,
            tasks: topTasks,
        });
        void adaptCandidateRolloutSafe({
            topologyId,
            workspaceId: topWorkspaceId,
            tasks: topTasks,
        });
    }
    for (const [workspaceIdKey, workspaceTasks] of workspaceTaskMap) {
        const workspacePolicy = policyCache.get(workspaceIdKey) ?? await getEffectiveTeamPolicy(workspaceIdKey, workspaceTasks[0]?.createdBy ?? 'system');
        policyCache.set(workspaceIdKey, workspacePolicy);
        processed += await processRuleLibraryAutoGovernance({
            workspaceId: workspaceIdKey,
            tasks: workspaceTasks,
            policy: workspacePolicy,
        });
    }
    return processed;
}
export async function processOnCallTaskHandoffs(workspaceId) {
    const tasks = await memoryStore.listTeamTasks(workspaceId ? { workspaceId } : undefined);
    const now = Date.now();
    let processed = 0;
    const policyCache = new Map();
    const activeAgentsByWorkspace = new Map();
    for (const task of tasks) {
        if (!(task.status === 'assigned' || task.status === 'claimed' || task.status === 'open' || task.status === 'todo'))
            continue;
        const metadata = task.metadata ?? {};
        const level = parseOnCallLevel(metadata['onCallLevel']);
        if (!metadata['onCallApprovalId'] || !level)
            continue;
        const policy = policyCache.get(task.workspaceId) ?? await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
        policyCache.set(task.workspaceId, policy);
        const activeAgentIds = activeAgentsByWorkspace.get(task.workspaceId) ?? new Set((await memoryStore.listAgents(task.workspaceId))
            .filter((agent) => agent.status === 'active')
            .map((agent) => agent.id));
        activeAgentsByWorkspace.set(task.workspaceId, activeAgentIds);
        const assignedAtMs = parseOnCallTimestamp(metadata['onCallAssignedAt'], task.updatedAt);
        const handoffCount = parseOnCallHandoffCount(metadata['onCallHandoffCount']);
        const assignmentTimedOut = (task.status === 'assigned' || task.status === 'claimed')
            && assignedAtMs + policy.onCallAssignmentTimeoutMinutes * 60_000 <= now;
        const agentUnavailable = !task.assignedAgentId || !activeAgentIds.has(task.assignedAgentId);
        if (!assignmentTimedOut && !agentUnavailable)
            continue;
        const rotation = await resolveApplicableOnCallRotation(task);
        if (!rotation)
            continue;
        const nextAgentId = resolveNextOnCallAgentId(rotation, level, activeAgentIds, task.assignedAgentId, now);
        if (!nextAgentId)
            continue;
        if (nextAgentId === task.assignedAgentId && !agentUnavailable)
            continue;
        if (task.assignedAgentId && handoffCount >= policy.onCallMaxHandoffsPerTask)
            continue;
        const previousAgentIds = Array.isArray(metadata['onCallPreviousAgentIds'])
            ? metadata['onCallPreviousAgentIds'].filter((item) => typeof item === 'string' && item.trim().length > 0)
            : [];
        const updated = await memoryStore.updateTeamTask(task.id, {
            assignedAgentId: nextAgentId,
            status: 'claimed',
            blockedReason: null,
            metadata: {
                ...metadata,
                onCallAgentId: nextAgentId,
                onCallAssignedAt: new Date(now).toISOString(),
                onCallHandoffCount: task.assignedAgentId ? handoffCount + 1 : handoffCount,
                onCallLastHandoffReason: agentUnavailable ? 'agent_unavailable' : 'assignment_timeout',
                onCallPreviousAgentIds: task.assignedAgentId && task.assignedAgentId !== nextAgentId
                    ? dedupeStringList([...previousAgentIds, task.assignedAgentId])
                    : previousAgentIds,
            },
        });
        if (updated) {
            processed++;
        }
    }
    return processed;
}
export async function processReadyTeamTasks(workspaceId, 
/** When set, only tasks with one of these priorities are processed (fast-path for critical/high). */
priorityFilter) {
    const allTasks = await memoryStore.listTeamTasks(workspaceId ? { workspaceId } : undefined);
    const tasks = priorityFilter
        ? allTasks.filter((t) => priorityFilter.includes(t.priority))
        : allTasks;
    let processed = 0;
    const policyCache = new Map();
    for (const task of tasks) {
        const policy = policyCache.get(task.workspaceId) ?? await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
        policyCache.set(task.workspaceId, policy);
        if (task.dueAt && task.status !== 'done' && task.status !== 'cancelled') {
            const overdue = await escalateOverdueTask(task, policy);
            if (overdue?.escalationStatus === 'pending') {
                processed++;
                continue;
            }
        }
        if (task.status === 'review_pending' && task.reviewStatus === 'pending' && task.reviewerAgentId) {
            if (!policy.autoReview)
                continue;
            await reviewTeamTaskById(task.id, policy);
            processed++;
            continue;
        }
        if (await isTeamTaskReady(task)) {
            if (!policy.autoDispatch)
                continue;
            await dispatchTeamTaskById(task.id, undefined, policy);
            processed++;
        }
    }
    return processed;
}
export async function processPendingTeamApprovals(workspaceId) {
    const approvals = await memoryStore.listTeamTaskApprovals({
        ...(workspaceId ? { workspaceId } : {}),
        status: 'pending',
    });
    const now = Date.now();
    let processed = 0;
    for (const approval of approvals) {
        const task = await memoryStore.getTeamTask(approval.taskId);
        if (!task)
            continue;
        const policy = await getEffectiveTeamPolicy(task.workspaceId, task.createdBy);
        const routing = resolveApprovalRoutingState(task, approval, policy);
        const approvalAgeMinutes = Math.floor((now - routing.levelStartedAtMs) / 60_000);
        const dispatchCtx = getTaskDispatchContext(task);
        const rotation = await resolveApplicableOnCallRotation(task);
        const additionalRecipients = getTaskApprovalBroadcastRecipients(task, approval.requestedForUserId);
        if (approvalAgeMinutes >= routing.reminderAfterMinutes
            && !(await hasNotificationForApproval(approval, 'approval_reminder'))) {
            const primaryAgentId = rotation ? resolveOnCallAgentId(rotation, 'primary', now) : null;
            if (primaryAgentId) {
                await ensureOnCallFollowupTask({
                    sourceTask: task,
                    approval,
                    level: 'primary',
                    agentId: primaryAgentId,
                    reason: `Approval pending for ${approvalAgeMinutes} minutes`,
                    policy,
                });
            }
            else {
                await createTeamNotificationSafe({
                    workspaceId: approval.workspaceId,
                    recipientUserId: approval.requestedForUserId,
                    type: 'approval_reminder',
                    severity: 'warning',
                    title: `Approval reminder: ${task.title}`,
                    message: `Approval has been pending for ${approvalAgeMinutes} minutes.`,
                    taskId: task.id,
                    approvalId: approval.id,
                    metadata: {
                        reminderThresholdMinutes: routing.reminderAfterMinutes,
                        approvalAgeMinutes,
                        approvalLevelIndex: routing.currentLevelIndex,
                        approvalLevelLabel: routing.currentLevel.label ?? null,
                        ...(additionalRecipients.length > 0 ? { additionalRecipientUserIds: additionalRecipients } : {}),
                        ...(approval.requestedForUserId === dispatchCtx.userId
                            ? {
                                deliveryChannel: dispatchCtx.channel,
                                deliveryChatId: dispatchCtx.chatId,
                            }
                            : {}),
                    },
                });
            }
            processed++;
        }
        const escalationTarget = resolveApprovalEscalationTarget(task, approval, policy);
        const escalationRecipient = escalationTarget?.recipientUserId ?? null;
        if (approvalAgeMinutes >= routing.escalationAfterMinutes
            && !(await hasNotificationForApproval(approval, 'approval_escalated'))) {
            const secondaryAgentId = rotation
                ? (resolveOnCallAgentId(rotation, 'secondary', now) ?? resolveOnCallAgentId(rotation, 'primary', now))
                : null;
            if (secondaryAgentId) {
                await ensureOnCallFollowupTask({
                    sourceTask: task,
                    approval,
                    level: 'secondary',
                    agentId: secondaryAgentId,
                    reason: `Approval exceeded escalation threshold at ${approvalAgeMinutes} minutes`,
                    policy,
                });
            }
            else if (escalationRecipient && escalationTarget) {
                const supersedeNotes = `Superseded by escalation to ${escalationRecipient} after ${approvalAgeMinutes} minutes.`;
                const escalatedApproval = !(await hasPendingApprovalForUser(task.id, escalationRecipient))
                    ? await memoryStore.createTeamTaskApproval({
                        workspaceId: approval.workspaceId,
                        taskId: task.id,
                        requestedBy: 'system',
                        requestedForUserId: escalationRecipient,
                        reason: `Escalated approval for ${task.title} after ${approvalAgeMinutes} minutes${escalationTarget.label ? ` to ${escalationTarget.label}` : ''}.`,
                    })
                    : null;
                const nextBroadcastRecipients = Array.from(new Set([
                    approval.requestedForUserId,
                    escalationRecipient,
                    ...additionalRecipients,
                    ...escalationTarget.effectiveApproverUserIds,
                ]));
                const nextRoutingLevels = escalationTarget.levelIndex === null
                    ? [
                        ...(Array.isArray((task.metadata ?? {})['approvalRoutingLevels'])
                            ? (task.metadata ?? {})['approvalRoutingLevels']
                            : []),
                        {
                            level: routing.levels.length,
                            label: escalationTarget.label,
                            approverUserIds: escalationTarget.approverUserIds,
                            approverRoleGroups: escalationTarget.approverRoleGroups,
                            effectiveApproverUserIds: escalationTarget.effectiveApproverUserIds,
                            primaryApproverUserId: escalationRecipient,
                            reminderAfterMinutes: escalationTarget.reminderAfterMinutes,
                            escalationAfterMinutes: escalationTarget.escalationAfterMinutes,
                        },
                    ]
                    : (Array.isArray((task.metadata ?? {})['approvalRoutingLevels'])
                        ? (task.metadata ?? {})['approvalRoutingLevels']
                        : []);
                const nextMetadata = applyEscalatedApprovalAudienceMetadata(task, escalationTarget, {
                    ...(task.metadata ?? {}),
                    approvalEscalatedAt: new Date(now).toISOString(),
                    approvalEscalatedToUserId: escalationRecipient,
                    approvalEscalatedFromUserId: approval.requestedForUserId,
                    approvalEscalationAgeMinutes: approvalAgeMinutes,
                    approvalBroadcastUserIds: nextBroadcastRecipients,
                    approvalRoutingLevels: nextRoutingLevels,
                    approvalCurrentLevelIndex: escalationTarget.levelIndex ?? routing.levels.length,
                    approvalCurrentLevelStartedAt: new Date(now).toISOString(),
                    approvalChain: [
                        ...((Array.isArray((task.metadata ?? {})['approvalChain'])
                            ? (task.metadata ?? {})['approvalChain']
                            : []).filter((entry) => Boolean(entry) && typeof entry === 'object' && !Array.isArray(entry))),
                        {
                            event: 'escalated',
                            at: new Date(now).toISOString(),
                            fromUserId: approval.requestedForUserId,
                            toUserId: escalationRecipient,
                            approvalId: approval.id,
                            nextApprovalId: escalatedApproval?.id ?? null,
                            ageMinutes: approvalAgeMinutes,
                            fromLevelIndex: routing.currentLevelIndex,
                            toLevelIndex: escalationTarget.levelIndex,
                            label: escalationTarget.label,
                            reason: supersedeNotes,
                        },
                    ],
                });
                await memoryStore.updateTeamTaskApproval(approval.id, {
                    status: 'rejected',
                    resolutionNotes: supersedeNotes,
                    resolvedAt: new Date(now),
                });
                await memoryStore.updateTeamTask(task.id, {
                    humanOwnerUserId: escalationRecipient,
                    escalationStatus: 'pending',
                    escalationReason: `Approval escalated to ${escalationRecipient} after ${approvalAgeMinutes} minutes`,
                    metadata: nextMetadata,
                });
                await createTeamNotificationSafe({
                    workspaceId: approval.workspaceId,
                    recipientUserId: escalationRecipient,
                    type: 'approval_escalated',
                    severity: 'critical',
                    title: `Approval escalated: ${task.title}`,
                    message: `Approval has been pending for ${approvalAgeMinutes} minutes and was escalated.`,
                    taskId: task.id,
                    approvalId: escalatedApproval?.id ?? approval.id,
                    metadata: {
                        escalationThresholdMinutes: routing.escalationAfterMinutes,
                        approvalAgeMinutes,
                        approvalLevelIndex: routing.currentLevelIndex,
                        nextApprovalLevelIndex: escalationTarget.levelIndex,
                        nextApprovalLevelLabel: escalationTarget.label,
                        originalApproverUserId: approval.requestedForUserId,
                        additionalRecipientUserIds: nextBroadcastRecipients.filter((userId) => userId !== escalationRecipient),
                    },
                });
            }
            processed++;
        }
    }
    return processed;
}
export class TeamSkill extends BaseSkill {
    definition = {
        name: 'team',
        description: 'Operate a workspace-level agent team task board: plan goals, create tasks, assign agents, review work, and dispatch execution.',
        category: 'system',
        parameters: [
            {
                name: 'action',
                type: 'string',
                required: true,
                description: 'Action',
                enum: ['plan_goal', 'create_task', 'list_tasks', 'assign_task', 'claim_task', 'raise_challenge', 'request_consensus', 'update_task', 'dispatch_task', 'review_task', 'run_supervisor', 'get_policy', 'set_policy', 'list_shared_memory', 'list_rule_library', 'list_rule_library_history', 'list_rule_library_candidates', 'promote_rule_to_library', 'remove_rule_from_library', 'rollback_rule_library', 'promote_memory', 'rollback_memory', 'list_mailbox', 'send_mail', 'ack_mail', 'list_approvals', 'resolve_approval', 'list_notification_routes', 'save_notification_route', 'list_oncall_rotations', 'save_oncall_rotation', 'list_templates', 'save_template', 'instantiate_template', 'list_topologies', 'save_topology', 'promote_topology_strategy', 'promote_topology_candidate', 'freeze_topology_candidate_rollout', 'resume_topology_candidate_rollout', 'freeze_topology_orchestrator', 'resume_topology_orchestrator', 'rollback_topology_strategy', 'instantiate_topology'],
            },
            { name: 'workspace_id', type: 'string', description: 'Workspace ID. Defaults to current conversation workspace.' },
            { name: 'goal', type: 'string', description: 'Goal to decompose into team tasks' },
            { name: 'title', type: 'string', description: 'Task title' },
            { name: 'description', type: 'string', description: 'Task description' },
            { name: 'task_id', type: 'string', description: 'Task ID' },
            { name: 'message_id', type: 'string', description: 'Mailbox message ID' },
            { name: 'agent_id', type: 'string', description: 'Assigned worker agent ID' },
            { name: 'challenger_agent_id', type: 'string', description: 'Agent raising a challenge' },
            { name: 'participant_agent_ids', type: 'array', description: 'Consensus participant agent IDs' },
            { name: 'reviewer_agent_id', type: 'string', description: 'Reviewer agent ID for review gate' },
            { name: 'status', type: 'string', description: 'Task status' },
            { name: 'priority', type: 'string', description: 'Task priority' },
            { name: 'depends_on', type: 'array', description: 'Task IDs this task depends on' },
            { name: 'review_required', type: 'boolean', description: 'Whether task requires review before done' },
            { name: 'prompt', type: 'string', description: 'Explicit prompt when dispatching a task' },
            { name: 'result_summary', type: 'string', description: 'Result or progress summary for update_task' },
            { name: 'blocked_reason', type: 'string', description: 'Blocked reason for update_task' },
            { name: 'max_attempts', type: 'number', description: 'Max worker attempts before escalation' },
            { name: 'human_owner_user_id', type: 'string', description: 'Human owner for escalations' },
            { name: 'source_agent_id', type: 'string', description: 'Agent scope source when promoting shared memory' },
            { name: 'thread_id', type: 'string', description: 'Mailbox thread ID' },
            { name: 'recipient_agent_id', type: 'string', description: 'Mailbox recipient agent ID' },
            { name: 'sender_agent_id', type: 'string', description: 'Mailbox sender agent ID' },
            { name: 'subject', type: 'string', description: 'Mailbox subject' },
            { name: 'source_key', type: 'string', description: 'Source memory key for promotion' },
            { name: 'history_id', type: 'string', description: 'Shared memory history entry ID for rollback' },
            { name: 'message', type: 'string', description: 'Mailbox or challenge message body' },
            { name: 'rule', type: 'string', description: 'Behavioral rule text for rule library lookup or promotion' },
            { name: 'rule_category', type: 'string', description: 'Behavioral rule category for rule library promotion' },
            { name: 'min_confidence', type: 'number', description: 'Minimum rule confidence for rule library candidate listing' },
            { name: 'min_evidence_count', type: 'number', description: 'Minimum evidence count for rule library candidate listing' },
            { name: 'limit', type: 'number', description: 'Maximum number of rule library entries to return' },
            { name: 'target_key', type: 'string', description: 'Target workspace memory key for promotion' },
            { name: 'key', type: 'string', description: 'Workspace shared memory key' },
            { name: 'value', type: 'string', description: 'Workspace shared memory value' },
            { name: 'reason', type: 'string', description: 'Reason for shared memory rollback' },
            { name: 'mail_type', type: 'string', description: 'Mailbox type' },
            { name: 'auto_dispatch', type: 'boolean', description: 'Whether supervisor auto-dispatches ready tasks' },
            { name: 'auto_review', type: 'boolean', description: 'Whether supervisor auto-runs reviewers' },
            { name: 'max_auto_retries', type: 'number', description: 'Default retry budget for workspace tasks' },
            { name: 'escalate_on_blocked', type: 'boolean', description: 'Escalate blocked tasks to a human owner' },
            { name: 'escalate_on_review_changes', type: 'boolean', description: 'Escalate immediately when review requests changes' },
            { name: 'auto_share_task_results', type: 'boolean', description: 'Promote completed task results into workspace shared memory' },
            { name: 'auto_govern_learned_rules', type: 'boolean', description: 'Run learned rules through rule-library governance separately from team propagation' },
            { name: 'shared_memory_prefix', type: 'string', description: 'Prefix for auto-shared workspace memory keys' },
            { name: 'default_human_owner_user_id', type: 'string', description: 'Default human owner when escalating' },
            { name: 'rule_library_auto_governance_enabled', type: 'boolean', description: 'Enable automatic rule library promote/demote governance task creation' },
            { name: 'rule_library_auto_promote_min_confidence', type: 'number', description: 'Minimum confidence for automatic rule library promotion candidates' },
            { name: 'rule_library_auto_promote_min_evidence_count', type: 'number', description: 'Minimum evidence count for automatic rule library promotion candidates' },
            { name: 'rule_library_auto_promote_max_per_cycle', type: 'number', description: 'Maximum automatic rule promotion governance tasks per supervisor cycle' },
            { name: 'rule_library_auto_promote_min_done_tasks', type: 'number', description: 'Minimum completed tasks before automatic rule promotion is allowed' },
            { name: 'rule_library_healthy_blocked_rate', type: 'number', description: 'Maximum blocked rate considered healthy for automatic rule promotion' },
            { name: 'rule_library_healthy_consensus_timeout_rate', type: 'number', description: 'Maximum consensus timeout rate considered healthy for automatic rule promotion' },
            { name: 'rule_library_auto_demote_max_per_cycle', type: 'number', description: 'Maximum automatic rule demotion governance tasks per supervisor cycle' },
            { name: 'rule_library_auto_demote_rollback_threshold', type: 'number', description: 'Minimum rollback count before automatic rule demotion is proposed' },
            { name: 'rule_library_auto_demote_delete_threshold', type: 'number', description: 'Minimum delete count before automatic rule demotion is proposed' },
            { name: 'rule_library_unhealthy_blocked_rate', type: 'number', description: 'Blocked rate that marks a workspace unhealthy for automatic rule demotion' },
            { name: 'rule_library_unhealthy_consensus_timeout_rate', type: 'number', description: 'Consensus timeout rate that marks a workspace unhealthy for automatic rule demotion' },
            { name: 'approval_reminder_after_minutes', type: 'number', description: 'Minutes before pending approvals trigger a reminder' },
            { name: 'approval_escalation_after_minutes', type: 'number', description: 'Minutes before pending approvals escalate to a secondary owner' },
            { name: 'escalation_owner_user_id', type: 'string', description: 'Secondary owner for overdue approval escalations' },
            { name: 'escalate_on_sla_breach', type: 'boolean', description: 'Escalate tasks that miss SLA deadlines' },
            { name: 'default_task_sla_hours', type: 'number', description: 'Default SLA target in hours for new tasks' },
            { name: 'oncall_assignment_timeout_minutes', type: 'number', description: 'Minutes before an assigned on-call task rotates to the next agent' },
            { name: 'oncall_max_handoffs_per_task', type: 'number', description: 'Maximum automatic on-call handoffs allowed for a task' },
            { name: 'approval_id', type: 'string', description: 'Approval request ID' },
            { name: 'decision', type: 'string', description: 'Approval decision: approve or reject' },
            { name: 'notes', type: 'string', description: 'Resolution notes' },
            { name: 'route_id', type: 'string', description: 'Notification route ID' },
            { name: 'recipient_user_id', type: 'string', description: 'Notification recipient user ID' },
            { name: 'channel_name', type: 'string', description: 'Notification delivery channel name' },
            { name: 'route_chat_id', type: 'string', description: 'Channel-specific chat/room ID for notification delivery' },
            { name: 'enabled', type: 'boolean', description: 'Whether a notification route is enabled' },
            { name: 'rotation_id', type: 'string', description: 'On-call rotation ID' },
            { name: 'rotation_name', type: 'string', description: 'On-call rotation name' },
            { name: 'schedule_type', type: 'string', description: 'On-call schedule type: daily or weekly' },
            { name: 'anchor_date', type: 'string', description: 'Rotation anchor date as ISO timestamp' },
            { name: 'primary_agent_ids', type: 'array', description: 'Primary on-call agent IDs' },
            { name: 'secondary_agent_ids', type: 'array', description: 'Secondary on-call agent IDs' },
            { name: 'template_id', type: 'string', description: 'Template ID' },
            { name: 'template_name', type: 'string', description: 'Template name' },
            { name: 'template_description', type: 'string', description: 'Template description' },
            { name: 'department', type: 'string', description: 'Department tag for a template' },
            { name: 'role_name', type: 'string', description: 'Role tag for a template' },
            { name: 'goal_template', type: 'string', description: 'Template goal text' },
            { name: 'template_variables', type: 'array', description: 'Template variable definitions array' },
            { name: 'variables', type: 'object', description: 'Variable values for template or topology instantiation' },
            { name: 'task_blueprints', type: 'array', description: 'Template task blueprints array' },
            { name: 'topology_id', type: 'string', description: 'Topology ID' },
            { name: 'topology_name', type: 'string', description: 'Topology name' },
            { name: 'strategy_version', type: 'number', description: 'Topology strategy version number' },
            { name: 'supervisor_agent_id', type: 'string', description: 'Supervisor agent ID for a topology' },
            { name: 'worker_agent_ids', type: 'array', description: 'Worker agent IDs for a topology' },
            { name: 'template_ids', type: 'array', description: 'Template IDs attached to a topology' },
            { name: 'orchestrator_rules', type: 'object', description: 'Topology orchestrator rules object' },
            { name: 'adaptive_model_policy', type: 'object', description: 'Adaptive model promotion/revert policy object' },
            { name: 'adaptive_orchestrator_policy', type: 'object', description: 'Adaptive orchestrator rollback/freeze policy object' },
            { name: 'model_routes', type: 'object', description: 'Per-topology model routes for orchestrator/reflection/heartbeat' },
            { name: 'candidate_strategy', type: 'object', description: 'Candidate topology strategy for canary rollout and staged promotion' },
            { name: 'candidate_rollout_policy', type: 'object', description: 'Automatic canary rollout controller policy for candidate strategy' },
            { name: 'candidate_rollout_control', type: 'object', description: 'Manual control state for candidate rollout, including freeze/resume' },
            { name: 'freeze_reason', type: 'string', description: 'Reason for freezing candidate rollout automation' },
            { name: 'freeze_minutes', type: 'number', description: 'How long to freeze adaptive orchestrator automation before auto-expiry' },
            { name: 'max_tasks', type: 'number', description: 'Maximum planned tasks for plan_goal', default: 5 },
        ],
    };
    async execute(params, ctx) {
        const workspaceId = resolveWorkspaceId(ctx, params);
        if (!workspaceId)
            return this.err('workspace_id is required outside a workspace-scoped conversation');
        switch (params.action) {
            case 'plan_goal':
                return this.planGoal(workspaceId, params, ctx);
            case 'create_task':
                return this.createTask(workspaceId, params, ctx);
            case 'list_tasks':
                return this.listTasks(workspaceId, params);
            case 'assign_task':
                return this.assignTask(workspaceId, params);
            case 'claim_task':
                return this.claimTask(workspaceId, params, ctx);
            case 'raise_challenge':
                return this.raiseChallenge(workspaceId, params);
            case 'request_consensus':
                return this.requestConsensus(workspaceId, params);
            case 'update_task':
                return this.updateTask(workspaceId, params);
            case 'dispatch_task':
                return this.dispatchTask(workspaceId, params);
            case 'review_task':
                return this.reviewTask(workspaceId, params);
            case 'run_supervisor':
                return this.runSupervisor(workspaceId);
            case 'get_policy':
                return this.getPolicy(workspaceId, ctx);
            case 'set_policy':
                return this.setPolicy(workspaceId, params, ctx);
            case 'list_shared_memory':
                return this.listSharedMemory(workspaceId, ctx);
            case 'list_rule_library':
                return this.listRuleLibrary(workspaceId, params, ctx);
            case 'list_rule_library_history':
                return this.listRuleLibraryHistory(workspaceId, params, ctx);
            case 'list_rule_library_candidates':
                return this.listRuleLibraryCandidates(workspaceId, params, ctx);
            case 'promote_rule_to_library':
                return this.promoteRuleToLibrary(workspaceId, params, ctx);
            case 'remove_rule_from_library':
                return this.removeRuleFromLibrary(workspaceId, params, ctx);
            case 'rollback_rule_library':
                return this.rollbackRuleLibrary(workspaceId, params, ctx);
            case 'promote_memory':
                return this.promoteMemory(workspaceId, params, ctx);
            case 'rollback_memory':
                return this.rollbackMemory(workspaceId, params, ctx);
            case 'list_mailbox':
                return this.listMailbox(workspaceId, params);
            case 'send_mail':
                return this.sendMail(workspaceId, params, ctx);
            case 'ack_mail':
                return this.ackMail(workspaceId, params);
            case 'list_approvals':
                return this.listApprovals(workspaceId, params);
            case 'resolve_approval':
                return this.resolveApproval(workspaceId, params);
            case 'list_notification_routes':
                return this.listNotificationRoutes(workspaceId, params);
            case 'save_notification_route':
                return this.saveNotificationRoute(workspaceId, params, ctx);
            case 'list_oncall_rotations':
                return this.listOnCallRotations(workspaceId, params);
            case 'save_oncall_rotation':
                return this.saveOnCallRotation(workspaceId, params, ctx);
            case 'list_templates':
                return this.listTemplates(workspaceId);
            case 'save_template':
                return this.saveTemplate(workspaceId, params, ctx);
            case 'instantiate_template':
                return this.instantiateTemplate(workspaceId, params, ctx);
            case 'list_topologies':
                return this.listTopologies(workspaceId);
            case 'save_topology':
                return this.saveTopology(workspaceId, params, ctx);
            case 'promote_topology_strategy':
                return this.promoteTopologyStrategy(workspaceId, params);
            case 'promote_topology_candidate':
                return this.promoteTopologyCandidate(workspaceId, params);
            case 'freeze_topology_candidate_rollout':
                return this.setTopologyCandidateRolloutFrozen(workspaceId, params, ctx, true);
            case 'resume_topology_candidate_rollout':
                return this.setTopologyCandidateRolloutFrozen(workspaceId, params, ctx, false);
            case 'freeze_topology_orchestrator':
                return this.setTopologyOrchestratorFrozen(workspaceId, params, ctx, true);
            case 'resume_topology_orchestrator':
                return this.setTopologyOrchestratorFrozen(workspaceId, params, ctx, false);
            case 'rollback_topology_strategy':
                return this.rollbackTopologyStrategy(workspaceId, params);
            case 'instantiate_topology':
                return this.instantiateTopology(workspaceId, params, ctx);
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
    async planGoal(workspaceId, params, ctx) {
        const goal = (params.goal ?? '').trim();
        if (!goal)
            return this.err('goal is required');
        const maxTasks = Math.min(Math.max(Number(params.max_tasks ?? 5) || 5, 1), 8);
        const policy = await getEffectiveTeamPolicy(workspaceId, ctx.userId);
        const agents = await memoryStore.listAgents(workspaceId);
        const agentList = agents.map((agent) => `- ${agent.id}: ${agent.name} (${agent.description ?? 'no description'})`).join('\n');
        const response = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: `Goal: ${goal}` }],
            systemPrompt: `You are a supervisor planning work for a persistent AI agent team.\n` +
                `Available agents:\n${agentList || '(none)'}\n\n` +
                `Return ONLY a JSON array with up to ${maxTasks} items.\n` +
                `Each item must be {"title":"...","description":"...","priority":"low|medium|high|critical","agentId":"optional agent id","dependsOnTitles":["optional previous task titles"],"reviewRequired":true|false,"reviewerAgentId":"optional reviewer id"}.`,
            maxTokens: 1200,
            temperature: 0.2,
        });
        const match = (response.content ?? '').match(/\[[\s\S]*\]/);
        if (!match)
            return this.err('Failed to produce a valid team plan');
        const plan = JSON.parse(match[0]);
        const created = new Map();
        for (const item of plan.slice(0, maxTasks)) {
            if (!item.title)
                continue;
            const assignedAgentId = item.agentId && agents.some((agent) => agent.id === item.agentId) ? item.agentId : null;
            const reviewerAgentId = item.reviewerAgentId && agents.some((agent) => agent.id === item.reviewerAgentId) ? item.reviewerAgentId : null;
            const dependsOnTaskIds = (item.dependsOnTitles ?? [])
                .map((title) => created.get(title)?.id)
                .filter((id) => Boolean(id));
            const task = await memoryStore.createTeamTask({
                workspaceId,
                title: item.title.trim().slice(0, 120),
                description: item.description?.trim().slice(0, 500),
                priority: item.priority === 'critical' || item.priority === 'high' || item.priority === 'low' ? item.priority : 'medium',
                assignedAgentId,
                dependsOnTaskIds,
                reviewRequired: Boolean(item.reviewRequired && reviewerAgentId),
                reviewerAgentId,
                maxAttempts: Math.max(1, policy.maxAutoRetries + 1),
                humanOwnerUserId: policy.defaultHumanOwnerUserId ?? ctx.userId,
                dueAt: new Date(Date.now() + policy.defaultTaskSlaHours * 3600 * 1000),
                createdBy: ctx.userId,
                metadata: {
                    requestUserId: ctx.userId,
                    requestChannel: ctx.channel,
                    requestChatId: ctx.chatId,
                    plannedFromGoal: goal,
                },
            });
            created.set(item.title, task);
        }
        const tasks = [...created.values()];
        if (tasks.length === 0)
            return this.err('Supervisor did not generate any usable tasks');
        return this.text(`Created ${tasks.length} team tasks for workspace ${workspaceId}.\n\n${tasks.map(renderTask).join('\n\n')}`);
    }
    async createTask(workspaceId, params, ctx) {
        const title = (params.title ?? '').trim();
        if (!title)
            return this.err('title is required');
        const policy = await getEffectiveTeamPolicy(workspaceId, ctx.userId);
        const assignedAgentId = typeof params.agent_id === 'string' && params.agent_id.trim() ? params.agent_id.trim() : null;
        const reviewerAgentId = typeof params.reviewer_agent_id === 'string' && params.reviewer_agent_id.trim() ? params.reviewer_agent_id.trim() : null;
        const reviewRequired = Boolean(params.review_required && reviewerAgentId);
        const task = await memoryStore.createTeamTask({
            workspaceId,
            title,
            description: typeof params.description === 'string' ? params.description : undefined,
            priority: params.priority === 'critical' || params.priority === 'high' || params.priority === 'low' ? params.priority : 'medium',
            assignedAgentId,
            dependsOnTaskIds: parseStringArray(params.depends_on) ?? [],
            reviewRequired,
            reviewerAgentId,
            maxAttempts: Math.max(1, Number(params.max_attempts ?? (policy.maxAutoRetries + 1)) || (policy.maxAutoRetries + 1)),
            humanOwnerUserId: typeof params.human_owner_user_id === 'string' && params.human_owner_user_id.trim()
                ? params.human_owner_user_id.trim()
                : (policy.defaultHumanOwnerUserId ?? ctx.userId),
            dueAt: new Date(Date.now() + policy.defaultTaskSlaHours * 3600 * 1000),
            createdBy: ctx.userId,
            resultSummary: typeof params.result_summary === 'string' ? params.result_summary : undefined,
            blockedReason: typeof params.blocked_reason === 'string' ? params.blocked_reason : undefined,
            metadata: {
                requestUserId: ctx.userId,
                requestChannel: ctx.channel,
                requestChatId: ctx.chatId,
            },
        });
        return this.text(`Created team task.\n\n${renderTask(task)}`);
    }
    async listTasks(workspaceId, params) {
        const tasks = await memoryStore.listTeamTasks({
            workspaceId,
            ...(typeof params.status === 'string' ? { status: params.status } : {}),
            ...(typeof params.agent_id === 'string' && params.agent_id.trim() ? { assignedAgentId: params.agent_id.trim() } : {}),
        });
        if (tasks.length === 0)
            return this.text(`No team tasks in workspace ${workspaceId}.`);
        return this.text(`Team tasks in workspace ${workspaceId} (${tasks.length})\n\n${tasks.map(renderTask).join('\n\n')}`);
    }
    async assignTask(workspaceId, params) {
        const taskId = (params.task_id ?? '').trim();
        const agentId = (params.agent_id ?? '').trim();
        if (!taskId || !agentId)
            return this.err('task_id and agent_id are required');
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.workspaceId !== workspaceId)
            return this.err(`Task not found: ${taskId}`);
        const agent = await memoryStore.getAgent(agentId);
        if (!agent || agent.workspaceId !== workspaceId)
            return this.err(`Agent not found in workspace: ${agentId}`);
        const dependencyStates = await getDependencyStates(task);
        const unmet = dependencyStates.filter((dep) => dep.status !== 'done');
        const updated = await memoryStore.updateTeamTask(taskId, {
            assignedAgentId: agentId,
            status: unmet.length === 0 ? 'claimed' : 'blocked',
            blockedReason: unmet.length === 0 ? null : `Waiting on dependencies: ${unmet.map((dep) => dep.id).join(', ')}`,
        });
        return this.text(updated ? `Assigned task ${taskId} to ${agent.name}.` : 'Assignment failed');
    }
    async claimTask(workspaceId, params, ctx) {
        const taskId = (params.task_id ?? '').trim();
        const agentId = (params.agent_id ?? '').trim();
        if (!taskId || !agentId)
            return this.err('task_id and agent_id are required');
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.workspaceId !== workspaceId)
            return this.err(`Task not found: ${taskId}`);
        const claimed = await claimTeamTaskById(taskId, agentId, ctx.userId);
        return this.text(claimed ? `Claimed task ${taskId} for ${agentId}.\n\n${renderTask(claimed)}` : 'Task claim failed');
    }
    async raiseChallenge(workspaceId, params) {
        const taskId = (params.task_id ?? '').trim();
        const challengerAgentId = (params.challenger_agent_id ?? params.agent_id ?? '').trim();
        const summary = (params.message ?? params.blocked_reason ?? '').trim();
        if (!taskId || !challengerAgentId || !summary)
            return this.err('task_id, challenger_agent_id, and message are required');
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.workspaceId !== workspaceId)
            return this.err(`Task not found: ${taskId}`);
        const updated = await raiseTeamTaskChallengeById({
            taskId,
            challengerAgentId,
            summary,
            threadId: typeof params.thread_id === 'string' ? params.thread_id : undefined,
        });
        return this.text(updated ? `Opened challenge on task ${taskId}.\n\n${renderTask(updated)}` : 'Challenge failed');
    }
    async requestConsensus(workspaceId, params) {
        const taskId = (params.task_id ?? '').trim();
        const requesterAgentId = (params.agent_id ?? '').trim();
        const summary = (params.message ?? params.result_summary ?? '').trim();
        if (!taskId || !requesterAgentId || !summary)
            return this.err('task_id, agent_id, and message are required');
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.workspaceId !== workspaceId)
            return this.err(`Task not found: ${taskId}`);
        const participantWeights = params.participant_weights && typeof params.participant_weights === 'object' && !Array.isArray(params.participant_weights)
            ? Object.fromEntries(Object.entries(params.participant_weights)
                .map(([agentId, weight]) => [agentId.trim(), Number(weight)])
                .filter((entry) => entry[0].length > 0 && Number.isFinite(entry[1]) && entry[1] > 0))
            : undefined;
        const updated = await requestTeamTaskConsensusById({
            taskId,
            requesterAgentId,
            summary,
            participantAgentIds: parseStringArray(params.participant_agent_ids) ?? [],
            participantWeights,
            threadId: typeof params.thread_id === 'string' ? params.thread_id : undefined,
        });
        return this.text(updated ? `Requested consensus for task ${taskId}.\n\n${renderTask(updated)}` : 'Consensus request failed');
    }
    async updateTask(workspaceId, params) {
        const taskId = (params.task_id ?? '').trim();
        if (!taskId)
            return this.err('task_id is required');
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.workspaceId !== workspaceId)
            return this.err(`Task not found: ${taskId}`);
        const updated = await memoryStore.updateTeamTask(taskId, {
            ...(typeof params.title === 'string' ? { title: params.title } : {}),
            ...(typeof params.description === 'string' ? { description: params.description } : {}),
            ...(typeof params.status === 'string' ? { status: params.status } : {}),
            ...(typeof params.priority === 'string' ? { priority: params.priority } : {}),
            ...(typeof params.agent_id === 'string' ? { assignedAgentId: params.agent_id || null } : {}),
            ...(typeof params.reviewer_agent_id === 'string' ? { reviewerAgentId: params.reviewer_agent_id || null } : {}),
            ...(params.review_required !== undefined ? { reviewRequired: Boolean(params.review_required) } : {}),
            ...(params.max_attempts !== undefined ? { maxAttempts: Math.max(1, Number(params.max_attempts) || 1) } : {}),
            ...(typeof params.human_owner_user_id === 'string' ? { humanOwnerUserId: params.human_owner_user_id || null } : {}),
            ...(typeof params.blocked_reason === 'string' ? { blockedReason: params.blocked_reason } : {}),
            ...(typeof params.result_summary === 'string' ? { resultSummary: params.result_summary } : {}),
            ...(parseStringArray(params.depends_on) ? { dependsOnTaskIds: parseStringArray(params.depends_on) } : {}),
        });
        return this.text(updated ? `Updated task.\n\n${renderTask(updated)}` : 'Update failed');
    }
    async dispatchTask(workspaceId, params) {
        const taskId = (params.task_id ?? '').trim();
        if (!taskId)
            return this.err('task_id is required');
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.workspaceId !== workspaceId)
            return this.err(`Task not found: ${taskId}`);
        const updated = await dispatchTeamTaskById(taskId, typeof params.prompt === 'string' ? params.prompt : undefined);
        return this.text(updated ? `Task dispatch finished.\n\n${renderTask(updated)}` : 'Task dispatch failed');
    }
    async reviewTask(workspaceId, params) {
        const taskId = (params.task_id ?? '').trim();
        if (!taskId)
            return this.err('task_id is required');
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.workspaceId !== workspaceId)
            return this.err(`Task not found: ${taskId}`);
        const updated = await reviewTeamTaskById(taskId);
        return this.text(updated ? `Task review finished.\n\n${renderTask(updated)}` : 'Task review failed');
    }
    async runSupervisor(workspaceId) {
        const protocol = await processTeamSwarmProtocol(workspaceId);
        const handoffs = await processOnCallTaskHandoffs(workspaceId);
        const processed = await processReadyTeamTasks(workspaceId);
        return this.text(`Supervisor applied ${protocol} swarm protocol rules, rotated ${handoffs} on-call tasks, and processed ${processed} team tasks in workspace ${workspaceId}.`);
    }
    async getPolicy(workspaceId, ctx) {
        const policy = await getEffectiveTeamPolicy(workspaceId, ctx.userId);
        return this.text(`Team policy for workspace ${workspaceId}\n\n${JSON.stringify(policy, null, 2)}`);
    }
    async setPolicy(workspaceId, params, ctx) {
        const currentPolicy = await getEffectiveTeamPolicy(workspaceId, ctx.userId);
        const metadata = mergeTeamPolicyMetadata(currentPolicy.metadata, {
            ...((params.auto_govern_learned_rules !== undefined || params.rule_library_auto_governance_enabled !== undefined)
                ? { autoGovernLearnedRules: Boolean(params.auto_govern_learned_rules ?? params.rule_library_auto_governance_enabled) }
                : {}),
            ...(params.rule_library_auto_governance_enabled !== undefined
                ? { ruleLibraryAutoGovernanceEnabled: Boolean(params.rule_library_auto_governance_enabled) }
                : {}),
            ...(params.rule_library_auto_promote_min_confidence !== undefined
                ? { ruleLibraryAutoPromoteMinConfidence: Math.max(0, Math.min(100, Number(params.rule_library_auto_promote_min_confidence) || 0)) }
                : {}),
            ...(params.rule_library_auto_promote_min_evidence_count !== undefined
                ? { ruleLibraryAutoPromoteMinEvidenceCount: Math.max(1, Math.floor(Number(params.rule_library_auto_promote_min_evidence_count) || 1)) }
                : {}),
            ...(params.rule_library_auto_promote_max_per_cycle !== undefined
                ? { ruleLibraryAutoPromoteMaxPerCycle: Math.max(1, Math.floor(Number(params.rule_library_auto_promote_max_per_cycle) || 1)) }
                : {}),
            ...(params.rule_library_auto_promote_min_done_tasks !== undefined
                ? { ruleLibraryAutoPromoteMinDoneTasks: Math.max(1, Math.floor(Number(params.rule_library_auto_promote_min_done_tasks) || 1)) }
                : {}),
            ...(params.rule_library_healthy_blocked_rate !== undefined
                ? { ruleLibraryHealthyBlockedRate: Math.max(0, Math.min(1, Number(params.rule_library_healthy_blocked_rate) || 0)) }
                : {}),
            ...(params.rule_library_healthy_consensus_timeout_rate !== undefined
                ? { ruleLibraryHealthyConsensusTimeoutRate: Math.max(0, Math.min(1, Number(params.rule_library_healthy_consensus_timeout_rate) || 0)) }
                : {}),
            ...(params.rule_library_auto_demote_max_per_cycle !== undefined
                ? { ruleLibraryAutoDemoteMaxPerCycle: Math.max(1, Math.floor(Number(params.rule_library_auto_demote_max_per_cycle) || 1)) }
                : {}),
            ...(params.rule_library_auto_demote_rollback_threshold !== undefined
                ? { ruleLibraryAutoDemoteRollbackThreshold: Math.max(1, Math.floor(Number(params.rule_library_auto_demote_rollback_threshold) || 1)) }
                : {}),
            ...(params.rule_library_auto_demote_delete_threshold !== undefined
                ? { ruleLibraryAutoDemoteDeleteThreshold: Math.max(1, Math.floor(Number(params.rule_library_auto_demote_delete_threshold) || 1)) }
                : {}),
            ...(params.rule_library_unhealthy_blocked_rate !== undefined
                ? { ruleLibraryUnhealthyBlockedRate: Math.max(0, Math.min(1, Number(params.rule_library_unhealthy_blocked_rate) || 0)) }
                : {}),
            ...(params.rule_library_unhealthy_consensus_timeout_rate !== undefined
                ? { ruleLibraryUnhealthyConsensusTimeoutRate: Math.max(0, Math.min(1, Number(params.rule_library_unhealthy_consensus_timeout_rate) || 0)) }
                : {}),
        });
        const policy = await memoryStore.upsertTeamPolicy({
            workspaceId,
            ...(params.auto_dispatch !== undefined ? { autoDispatch: Boolean(params.auto_dispatch) } : {}),
            ...(params.auto_review !== undefined ? { autoReview: Boolean(params.auto_review) } : {}),
            ...(params.max_auto_retries !== undefined ? { maxAutoRetries: Math.max(0, Number(params.max_auto_retries) || 0) } : {}),
            ...(params.escalate_on_blocked !== undefined ? { escalateOnBlocked: Boolean(params.escalate_on_blocked) } : {}),
            ...(params.escalate_on_review_changes !== undefined ? { escalateOnReviewChanges: Boolean(params.escalate_on_review_changes) } : {}),
            ...(params.escalate_on_sla_breach !== undefined ? { escalateOnSlaBreach: Boolean(params.escalate_on_sla_breach) } : {}),
            ...(params.auto_share_task_results !== undefined ? { autoShareTaskResults: Boolean(params.auto_share_task_results) } : {}),
            ...(params.auto_propagate_learnings !== undefined ? { autoPropagateLearnings: Boolean(params.auto_propagate_learnings) } : {}),
            ...((params.auto_govern_learned_rules !== undefined || params.rule_library_auto_governance_enabled !== undefined)
                ? { autoGovernLearnedRules: Boolean(params.auto_govern_learned_rules ?? params.rule_library_auto_governance_enabled) }
                : {}),
            ...(typeof params.shared_memory_prefix === 'string' ? { sharedMemoryPrefix: params.shared_memory_prefix } : {}),
            ...(params.default_task_sla_hours !== undefined ? { defaultTaskSlaHours: Math.max(1, Number(params.default_task_sla_hours) || 1) } : {}),
            ...(typeof params.default_human_owner_user_id === 'string' ? { defaultHumanOwnerUserId: params.default_human_owner_user_id || null } : {}),
            ...(params.approval_reminder_after_minutes !== undefined ? { approvalReminderAfterMinutes: Math.max(1, Number(params.approval_reminder_after_minutes) || 1) } : {}),
            ...(params.approval_escalation_after_minutes !== undefined ? { approvalEscalationAfterMinutes: Math.max(1, Number(params.approval_escalation_after_minutes) || 1) } : {}),
            ...(params.oncall_assignment_timeout_minutes !== undefined ? { onCallAssignmentTimeoutMinutes: Math.max(1, Number(params.oncall_assignment_timeout_minutes) || 1) } : {}),
            ...(params.oncall_max_handoffs_per_task !== undefined ? { onCallMaxHandoffsPerTask: Math.max(1, Number(params.oncall_max_handoffs_per_task) || 1) } : {}),
            ...(typeof params.escalation_owner_user_id === 'string' ? { escalationOwnerUserId: params.escalation_owner_user_id || null } : {}),
            ...(metadata ? { metadata } : {}),
            updatedBy: ctx.userId,
        });
        return this.text(`Updated team policy for workspace ${workspaceId}\n\n${JSON.stringify(policy, null, 2)}`);
    }
    async listSharedMemory(workspaceId, ctx) {
        const memory = Object.fromEntries(Object.entries(await memoryStore.getAllScopedMemory({ userId: ctx.userId, channel: ctx.channel, workspaceId }))
            .filter(([key]) => !isTeamSharedMemoryMetaKey(key)));
        return this.text(`Workspace shared memory for ${workspaceId}\n\n${JSON.stringify(memory, null, 2)}`);
    }
    async listRuleLibrary(_workspaceId, params, ctx) {
        const minConfidence = Math.max(0, Number(params.min_confidence ?? 0) || 0);
        const minEvidenceCount = Math.max(0, Number(params.min_evidence_count ?? 0) || 0);
        const limit = Math.min(Math.max(Number(params.limit ?? 50) || 50, 1), 200);
        const rules = await memoryStore.getScopedBehavioralRules(getGlobalRuleLibraryScope({
            userId: ctx.userId,
            channel: ctx.channel,
        }), 0);
        const filtered = rules
            .filter((rule) => rule.confidence >= minConfidence && rule.evidenceCount >= minEvidenceCount)
            .slice(0, limit);
        if (filtered.length === 0) {
            return this.text('Rule library is empty.');
        }
        const lines = filtered.map((rule) => `- [${rule.category}] ${rule.rule} (${rule.confidence}% | ${rule.source} | evidence ${rule.evidenceCount})`);
        return this.text(`Cross-workspace rule library\n\n${lines.join('\n')}`);
    }
    async listRuleLibraryHistory(_workspaceId, params, ctx) {
        const limit = Math.min(Math.max(Number(params.limit ?? 50) || 50, 1), 200);
        const history = await memoryStore.getScopedBehavioralRuleHistory(getGlobalRuleLibraryScope({
            userId: ctx.userId,
            channel: ctx.channel,
        }), limit);
        if (history.length === 0) {
            return this.text('Rule library history is empty.');
        }
        const lines = history.map((entry) => {
            const fromState = entry.oldConfidence === null || entry.oldConfidence === undefined
                ? 'none'
                : `${entry.oldCategory}/${entry.oldConfidence}%/${entry.oldSource}/e${entry.oldEvidenceCount ?? 0}`;
            const toState = entry.newConfidence === null || entry.newConfidence === undefined
                ? 'none'
                : `${entry.newCategory}/${entry.newConfidence}%/${entry.newSource}/e${entry.newEvidenceCount ?? 0}`;
            return `- ${entry.id} [${entry.action}] ${entry.rule} | ${fromState} -> ${toState}${entry.relatedHistoryId ? ` | related ${entry.relatedHistoryId}` : ''}`;
        });
        return this.text(`Rule library history\n\n${lines.join('\n')}`);
    }
    async listRuleLibraryCandidates(workspaceId, params, ctx) {
        if (workspaceId === GLOBAL_RULE_LIBRARY_WORKSPACE_ID) {
            return this.err('list_rule_library_candidates must be run from a normal workspace');
        }
        const sourceAgentId = typeof params.source_agent_id === 'string' && params.source_agent_id.trim()
            ? params.source_agent_id.trim()
            : null;
        const scope = {
            userId: ctx.userId,
            channel: ctx.channel,
            workspaceId,
            ...(sourceAgentId ? { agentId: sourceAgentId } : {}),
        };
        const [workspaceRules, libraryRules] = await Promise.all([
            memoryStore.getScopedBehavioralRules(scope, 0),
            memoryStore.getScopedBehavioralRules(getGlobalRuleLibraryScope({
                userId: ctx.userId,
                channel: ctx.channel,
            }), 0),
        ]);
        const libraryRuleSet = new Set(libraryRules.map((rule) => normalizeKeyPart(rule.rule)));
        const minConfidence = Math.max(0, Number(params.min_confidence ?? 70) || 70);
        const minEvidenceCount = Math.max(0, Number(params.min_evidence_count ?? 2) || 2);
        const limit = Math.min(Math.max(Number(params.limit ?? 50) || 50, 1), 200);
        const candidates = workspaceRules
            .filter((rule) => !libraryRuleSet.has(normalizeKeyPart(rule.rule)))
            .filter((rule) => rule.confidence >= minConfidence && rule.evidenceCount >= minEvidenceCount)
            .sort((a, b) => b.confidence - a.confidence || b.evidenceCount - a.evidenceCount)
            .slice(0, limit);
        if (candidates.length === 0) {
            return this.text(`No pending rule library candidates in workspace ${workspaceId}.`);
        }
        const lines = candidates
            .map((rule) => `- [${rule.category}] ${rule.rule} (${rule.confidence}% | ${rule.source} | evidence ${rule.evidenceCount})`);
        return this.text(`Rule library candidates for workspace ${workspaceId}\n\n${lines.join('\n')}`);
    }
    async promoteRuleToLibrary(workspaceId, params, ctx) {
        if (workspaceId === GLOBAL_RULE_LIBRARY_WORKSPACE_ID) {
            return this.err('Cannot promote from the global rule library workspace');
        }
        const ruleQuery = (params.rule ?? '').trim();
        if (!ruleQuery)
            return this.err('rule is required');
        const sourceAgentId = typeof params.source_agent_id === 'string' && params.source_agent_id.trim()
            ? params.source_agent_id.trim()
            : null;
        const scope = {
            userId: ctx.userId,
            channel: ctx.channel,
            workspaceId,
            ...(sourceAgentId ? { agentId: sourceAgentId } : {}),
        };
        const [workspaceRules, libraryRules] = await Promise.all([
            memoryStore.getScopedBehavioralRules(scope, 0),
            memoryStore.getScopedBehavioralRules(getGlobalRuleLibraryScope({
                userId: ctx.userId,
                channel: ctx.channel,
            }), 0),
        ]);
        const match = findBehavioralRuleMatch(workspaceRules, ruleQuery);
        if (!match) {
            return this.err(`No matching workspace rule found for "${ruleQuery}"`);
        }
        if (findBehavioralRuleMatch(libraryRules, match.rule)) {
            return this.text(`Rule already exists in the cross-workspace rule library: "${match.rule}"`);
        }
        const requestedCategory = typeof params.rule_category === 'string' && params.rule_category.trim()
            ? params.rule_category.trim()
            : null;
        const policy = await getEffectiveTeamPolicy(workspaceId, ctx.userId);
        const task = await ensureRuleLibraryPromotionApprovalTask({
            action: 'promote',
            workspaceId,
            sourceWorkspaceId: workspaceId,
            sourceAgentId,
            userId: ctx.userId,
            channel: ctx.channel,
            chatId: ctx.chatId,
            actorUserId: ctx.userId,
            requestedForUserId: ctx.userId,
            rule: match.rule,
            category: requestedCategory ?? match.category,
            confidence: match.confidence,
            evidenceCount: match.evidenceCount,
            source: match.source,
            policy,
        });
        if (!task) {
            return this.err('Failed to create rule library promotion approval task');
        }
        return this.text(`Created rule library promotion approval task ${task.id} for "${match.rule}".`);
    }
    async removeRuleFromLibrary(workspaceId, params, ctx) {
        if (workspaceId === GLOBAL_RULE_LIBRARY_WORKSPACE_ID) {
            return this.err('Cannot create governance tasks from the global rule library workspace');
        }
        const ruleQuery = (params.rule ?? '').trim();
        if (!ruleQuery)
            return this.err('rule is required');
        const libraryRules = await memoryStore.getScopedBehavioralRules(getGlobalRuleLibraryScope({
            userId: ctx.userId,
            channel: ctx.channel,
        }), 0);
        const match = findBehavioralRuleMatch(libraryRules, ruleQuery);
        if (!match) {
            return this.err(`No matching rule found in the cross-workspace rule library for "${ruleQuery}"`);
        }
        const policy = await getEffectiveTeamPolicy(workspaceId, ctx.userId);
        const task = await ensureRuleLibraryPromotionApprovalTask({
            action: 'remove',
            workspaceId,
            sourceWorkspaceId: workspaceId,
            userId: ctx.userId,
            channel: ctx.channel,
            chatId: ctx.chatId,
            actorUserId: ctx.userId,
            requestedForUserId: ctx.userId,
            rule: match.rule,
            category: match.category,
            confidence: match.confidence,
            evidenceCount: match.evidenceCount,
            source: match.source,
            policy,
        });
        if (!task) {
            return this.err('Failed to create rule library removal approval task');
        }
        return this.text(`Created rule library removal approval task ${task.id} for "${match.rule}".`);
    }
    async rollbackRuleLibrary(workspaceId, params, ctx) {
        if (workspaceId === GLOBAL_RULE_LIBRARY_WORKSPACE_ID) {
            return this.err('Cannot create governance tasks from the global rule library workspace');
        }
        const historyId = (params.history_id ?? '').trim();
        if (!historyId)
            return this.err('history_id is required');
        const history = await memoryStore.getScopedBehavioralRuleHistory(getGlobalRuleLibraryScope({
            userId: ctx.userId,
            channel: ctx.channel,
        }), Math.min(Math.max(Number(params.limit ?? 200) || 200, 1), 500));
        const match = history.find((entry) => entry.id === historyId);
        if (!match) {
            return this.err(`Rule library history entry not found: ${historyId}`);
        }
        const policy = await getEffectiveTeamPolicy(workspaceId, ctx.userId);
        const task = await ensureRuleLibraryPromotionApprovalTask({
            action: 'rollback',
            workspaceId,
            sourceWorkspaceId: workspaceId,
            userId: ctx.userId,
            channel: ctx.channel,
            chatId: ctx.chatId,
            actorUserId: ctx.userId,
            requestedForUserId: ctx.userId,
            rule: match.rule,
            category: match.oldCategory ?? match.newCategory ?? 'workflow',
            confidence: match.oldConfidence ?? match.newConfidence ?? 0,
            evidenceCount: match.oldEvidenceCount ?? match.newEvidenceCount ?? 0,
            source: match.newSource ?? match.oldSource ?? 'library_history',
            historyId: match.id,
            policy,
        });
        if (!task) {
            return this.err('Failed to create rule library rollback approval task');
        }
        return this.text(`Created rule library rollback approval task ${task.id} for history entry ${match.id}.`);
    }
    async promoteMemory(workspaceId, params, ctx) {
        const sourceKey = (params.source_key ?? '').trim();
        if (!sourceKey)
            return this.err('source_key is required');
        const sourceAgentId = typeof params.source_agent_id === 'string' && params.source_agent_id.trim() ? params.source_agent_id.trim() : undefined;
        const sourceScope = { userId: ctx.userId, channel: ctx.channel, workspaceId, ...(sourceAgentId ? { agentId: sourceAgentId } : {}) };
        const value = typeof params.value === 'string'
            ? params.value
            : await memoryStore.getScopedMemory(sourceScope, sourceKey);
        if (!value)
            return this.err(`Memory key not found: ${sourceKey}`);
        const targetKey = (typeof params.target_key === 'string' && params.target_key.trim())
            ? params.target_key.trim()
            : sourceKey;
        const result = await writeTeamSharedMemoryEntry({
            workspaceId,
            userId: ctx.userId,
            channel: ctx.channel,
            key: targetKey,
            value,
            actorUserId: ctx.userId,
            actorAgentId: ctx.agentId ?? null,
            expectedVersion: params.expected_version !== undefined ? Number(params.expected_version) : null,
            conflictRecipientUserId: ctx.userId,
            conflictTitle: `Shared memory conflict for ${targetKey}`,
        });
        if (result.unauthorized) {
            return this.err(`Shared memory write blocked by authority policy for ${targetKey}.`);
        }
        if (result.versionConflict) {
            return this.err(`Shared memory version conflict for ${targetKey}. Current version: ${result.currentVersion}.`);
        }
        return this.text(`Promoted shared memory key ${targetKey} in workspace ${workspaceId} at version ${result.nextVersion}.`);
    }
    async rollbackMemory(workspaceId, params, ctx) {
        const key = (typeof params.key === 'string' ? params.key : '').trim();
        if (!key)
            return this.err('key is required');
        const result = await rollbackTeamSharedMemoryEntry({
            workspaceId,
            userId: ctx.userId,
            channel: ctx.channel,
            key,
            actorUserId: ctx.userId,
            actorAgentId: ctx.agentId ?? null,
            historyId: typeof params.history_id === 'string' && params.history_id.trim() ? params.history_id.trim() : null,
            reason: typeof params.reason === 'string' && params.reason.trim() ? params.reason.trim() : null,
            conflictRecipientUserId: ctx.userId,
            conflictTitle: `Shared memory rollback for ${key}`,
        });
        if (result.unauthorized) {
            return this.err(`Shared memory rollback blocked by authority policy for ${key}.`);
        }
        if (!result.ok) {
            return this.err(`Shared memory rollback failed for ${key}.`);
        }
        return this.text(`Rolled back shared memory key ${key} in workspace ${workspaceId} to version ${result.nextVersion}.`);
    }
    async listMailbox(workspaceId, params) {
        const messages = await memoryStore.listTeamMailboxMessages({
            workspaceId,
            ...(typeof params.thread_id === 'string' && params.thread_id.trim() ? { threadId: params.thread_id.trim() } : {}),
            ...(typeof params.sender_agent_id === 'string' && params.sender_agent_id.trim() ? { senderAgentId: params.sender_agent_id.trim() } : {}),
            ...(typeof params.recipient_agent_id === 'string' && params.recipient_agent_id.trim() ? { recipientAgentId: params.recipient_agent_id.trim() } : {}),
            ...(typeof params.task_id === 'string' && params.task_id.trim() ? { taskId: params.task_id.trim() } : {}),
            ...(typeof params.mail_type === 'string' ? { type: params.mail_type } : {}),
            ...(typeof params.status === 'string' ? { status: params.status } : {}),
        });
        return this.text(`Team mailbox in workspace ${workspaceId}\n\n${JSON.stringify(messages, null, 2)}`);
    }
    async sendMail(workspaceId, params, ctx) {
        const body = (params.message ?? '').trim();
        if (!body)
            return this.err('message is required');
        const mailType = typeof params.mail_type === 'string' ? params.mail_type : 'direct';
        const metadata = typeof params.metadata === 'object' && params.metadata !== null && !Array.isArray(params.metadata)
            ? { ...params.metadata }
            : {};
        const consensusDecision = normalizeConsensusDecision(params.decision);
        if (mailType === 'consensus_response' && consensusDecision) {
            metadata['decision'] = consensusDecision;
            metadata['rationale'] = typeof params.rationale === 'string' ? params.rationale.trim().slice(0, 500) : body.slice(0, 500);
            const voteWeight = Number(params.vote_weight);
            if (Number.isFinite(voteWeight) && voteWeight > 0) {
                metadata['voteWeight'] = voteWeight;
            }
        }
        const message = await createTeamMailboxMessageSafe({
            workspaceId,
            senderAgentId: typeof params.sender_agent_id === 'string' ? params.sender_agent_id.trim() || null : (typeof params.agent_id === 'string' ? params.agent_id.trim() || null : null),
            senderUserId: ctx.userId,
            recipientAgentId: typeof params.recipient_agent_id === 'string' ? params.recipient_agent_id.trim() || null : null,
            taskId: typeof params.task_id === 'string' ? params.task_id.trim() || null : null,
            threadId: typeof params.thread_id === 'string' ? params.thread_id.trim() || undefined : undefined,
            type: mailType,
            subject: typeof params.subject === 'string' ? params.subject : null,
            message: body,
            metadata,
        });
        return this.text(message ? `Sent mailbox message ${message.id}.` : 'Mailbox send failed');
    }
    async ackMail(workspaceId, params) {
        const messageId = (params.message_id ?? '').trim();
        if (!messageId)
            return this.err('message_id is required');
        const updated = await memoryStore.updateTeamMailboxMessage(messageId, {
            status: 'acknowledged',
            acknowledgedAt: new Date(),
        });
        if (!updated || updated.workspaceId !== workspaceId)
            return this.err(`Mailbox message not found: ${messageId}`);
        return this.text(`Acknowledged mailbox message ${messageId}.`);
    }
    async listApprovals(workspaceId, params) {
        const approvals = await memoryStore.listTeamTaskApprovals({
            workspaceId,
            ...(typeof params.task_id === 'string' ? { taskId: params.task_id } : {}),
            ...(typeof params.status === 'string' ? { status: params.status } : {}),
        });
        return this.text(`Team approvals in workspace ${workspaceId}\n\n${JSON.stringify(approvals, null, 2)}`);
    }
    async resolveApproval(workspaceId, params) {
        const approvalId = (params.approval_id ?? '').trim();
        const decision = (params.decision ?? '').trim();
        if (!approvalId || (decision !== 'approve' && decision !== 'reject')) {
            return this.err('approval_id and decision=approve|reject are required');
        }
        const result = await resolveTeamApprovalById(approvalId, decision, typeof params.notes === 'string' ? params.notes : null);
        return this.text(result.task ? `Resolved approval ${approvalId}.\n\n${renderTask(result.task)}` : 'Approval resolution failed');
    }
    async listNotificationRoutes(workspaceId, params) {
        const routes = await memoryStore.listTeamNotificationRoutes({
            workspaceId,
            ...(typeof params.recipient_user_id === 'string' ? { recipientUserId: params.recipient_user_id } : {}),
            ...(parseChannelName(params.channel_name) ? { channel: parseChannelName(params.channel_name) } : {}),
            ...(typeof params.enabled === 'boolean' ? { enabled: params.enabled } : {}),
        });
        return this.text(`Team notification routes in workspace ${workspaceId}\n\n${JSON.stringify(routes, null, 2)}`);
    }
    async saveNotificationRoute(workspaceId, params, ctx) {
        const recipientUserId = (params.recipient_user_id ?? '').trim();
        const channel = parseChannelName(params.channel_name);
        const chatId = (params.route_chat_id ?? '').trim();
        if (!recipientUserId || !channel || !chatId) {
            return this.err('recipient_user_id, channel_name, and route_chat_id are required');
        }
        const routeId = (params.route_id ?? '').trim();
        const route = routeId
            ? await memoryStore.updateTeamNotificationRoute(routeId, {
                recipientUserId,
                channel,
                chatId,
                ...(typeof params.enabled === 'boolean' ? { enabled: params.enabled } : {}),
            })
            : await memoryStore.createTeamNotificationRoute({
                workspaceId,
                recipientUserId,
                channel,
                chatId,
                enabled: typeof params.enabled === 'boolean' ? params.enabled : true,
                createdBy: ctx.userId,
            });
        return this.text(route ? `Saved notification route ${route.id}.` : 'Notification route save failed');
    }
    async listOnCallRotations(workspaceId, params) {
        const rotations = await memoryStore.listTeamOnCallRotations({
            workspaceId,
            ...(typeof params.enabled === 'boolean' ? { enabled: params.enabled } : {}),
            ...(typeof params.department === 'string' ? { department: params.department } : {}),
            ...(typeof params.role_name === 'string' ? { role: params.role_name } : {}),
        });
        return this.text(`Team on-call rotations in workspace ${workspaceId}\n\n${JSON.stringify(rotations, null, 2)}`);
    }
    async saveOnCallRotation(workspaceId, params, ctx) {
        const name = (params.rotation_name ?? '').trim();
        if (!name)
            return this.err('rotation_name is required');
        const rotationId = (params.rotation_id ?? '').trim();
        const scheduleType = parseScheduleType(params.schedule_type) ?? 'daily';
        const anchorDate = typeof params.anchor_date === 'string' && params.anchor_date.trim()
            ? new Date(params.anchor_date)
            : new Date();
        const primaryAgentIds = dedupeStringList(parseStringArray(params.primary_agent_ids));
        const secondaryAgentIds = dedupeStringList(parseStringArray(params.secondary_agent_ids));
        if (primaryAgentIds.length === 0)
            return this.err('primary_agent_ids is required');
        const rotation = rotationId
            ? await memoryStore.updateTeamOnCallRotation(rotationId, {
                name,
                ...(typeof params.enabled === 'boolean' ? { enabled: params.enabled } : {}),
                scheduleType,
                anchorDate,
                ...(typeof params.department === 'string' ? { department: params.department || null } : {}),
                ...(typeof params.role_name === 'string' ? { role: params.role_name || null } : {}),
                primaryAgentIds,
                secondaryAgentIds,
            })
            : await memoryStore.createTeamOnCallRotation({
                workspaceId,
                name,
                enabled: typeof params.enabled === 'boolean' ? params.enabled : true,
                scheduleType,
                anchorDate,
                department: typeof params.department === 'string' ? params.department : undefined,
                role: typeof params.role_name === 'string' ? params.role_name : undefined,
                primaryAgentIds,
                secondaryAgentIds,
                createdBy: ctx.userId,
            });
        return this.text(rotation ? `Saved on-call rotation ${rotation.id}.` : 'On-call rotation save failed');
    }
    async listTemplates(workspaceId) {
        const templates = await memoryStore.listTeamTemplates(workspaceId);
        return this.text(`Team templates in workspace ${workspaceId}\n\n${JSON.stringify(templates, null, 2)}`);
    }
    async saveTemplate(workspaceId, params, ctx) {
        const name = (params.template_name ?? '').trim();
        if (!name)
            return this.err('template_name is required');
        const taskBlueprints = parseTaskBlueprints(params.task_blueprints);
        if (!taskBlueprints || taskBlueprints.length === 0)
            return this.err('task_blueprints is required');
        const variables = parseTeamTemplateVariableDefinitions(params.template_variables);
        const templateId = (params.template_id ?? '').trim();
        const template = templateId
            ? await memoryStore.updateTeamTemplate(templateId, {
                name,
                ...(typeof params.template_description === 'string' ? { description: params.template_description || null } : {}),
                ...(typeof params.department === 'string' ? { department: params.department || null } : {}),
                ...(typeof params.role_name === 'string' ? { role: params.role_name || null } : {}),
                ...(typeof params.goal_template === 'string' ? { goalTemplate: params.goal_template || null } : {}),
                ...(variables ? { variables } : {}),
                taskBlueprints,
            })
            : await memoryStore.createTeamTemplate({
                workspaceId,
                name,
                description: typeof params.template_description === 'string' ? params.template_description : undefined,
                department: typeof params.department === 'string' ? params.department : undefined,
                role: typeof params.role_name === 'string' ? params.role_name : undefined,
                goalTemplate: typeof params.goal_template === 'string' ? params.goal_template : undefined,
                variables,
                taskBlueprints,
                createdBy: ctx.userId,
            });
        return this.text(template ? `Saved team template ${template.name}.` : 'Template save failed');
    }
    async instantiateTemplate(workspaceId, params, ctx) {
        const templateId = (params.template_id ?? '').trim();
        if (!templateId)
            return this.err('template_id is required');
        const template = await memoryStore.getTeamTemplate(templateId);
        if (!template || template.workspaceId !== workspaceId)
            return this.err(`Template not found: ${templateId}`);
        const tasks = await instantiateTeamTemplateById(templateId, ctx, {
            humanOwnerUserId: typeof params.human_owner_user_id === 'string' ? params.human_owner_user_id : undefined,
            variables: parseTeamTemplateVariableValues(params.variables),
            workerAgentIds: parseStringArray(params.worker_agent_ids),
            supervisorAgentId: typeof params.supervisor_agent_id === 'string' ? params.supervisor_agent_id : undefined,
        });
        return this.text(`Instantiated template ${template.name} into ${tasks.length} tasks.\n\n${tasks.map(renderTask).join('\n\n')}`);
    }
    async listTopologies(workspaceId) {
        const topologies = await memoryStore.listTeamTopologies(workspaceId);
        const now = Date.now();
        const summarized = topologies.map((topology) => {
            const metadata = topology.metadata ?? {};
            const orchFrozenUntil = typeof metadata['lastOrchFrozenUntil'] === 'string' ? metadata['lastOrchFrozenUntil'] : null;
            const orchFrozenUntilMs = orchFrozenUntil ? Date.parse(orchFrozenUntil) : Number.NaN;
            return {
                ...topology,
                adaptiveOrchestrator: {
                    policy: parseAdaptiveOrchestratorPolicy(metadata['adaptiveOrchestratorPolicy']),
                    lastAction: typeof metadata['lastOrchAction'] === 'string' ? metadata['lastOrchAction'] : null,
                    lastAt: typeof metadata['lastOrchAdaptedAt'] === 'string' ? metadata['lastOrchAdaptedAt'] : null,
                    health: typeof metadata['lastOrchHealth'] === 'string' ? metadata['lastOrchHealth'] : null,
                    degradedStreak: Number.isFinite(Number(metadata['orchDegradedStreak']))
                        ? Number(metadata['orchDegradedStreak'])
                        : 0,
                    control: {
                        frozenUntil: orchFrozenUntil,
                        isFrozen: Number.isFinite(orchFrozenUntilMs) && orchFrozenUntilMs > now,
                        freezeReason: typeof metadata['lastOrchFreezeReason'] === 'string' ? metadata['lastOrchFreezeReason'] : null,
                        frozenBy: typeof metadata['lastOrchFrozenBy'] === 'string' ? metadata['lastOrchFrozenBy'] : null,
                        manualControl: metadata['lastOrchManualControl'] === true,
                    },
                    rollback: {
                        at: typeof metadata['lastOrchRollbackAt'] === 'string' ? metadata['lastOrchRollbackAt'] : null,
                        fromVersion: Number.isFinite(Number(metadata['lastOrchRollbackFromVersion']))
                            ? Number(metadata['lastOrchRollbackFromVersion'])
                            : null,
                        toVersion: Number.isFinite(Number(metadata['lastOrchRollbackToVersion']))
                            ? Number(metadata['lastOrchRollbackToVersion'])
                            : null,
                        reason: typeof metadata['lastOrchRollbackReason'] === 'string' ? metadata['lastOrchRollbackReason'] : null,
                    },
                },
            };
        });
        return this.text(`Team topologies in workspace ${workspaceId}\n\n${JSON.stringify(summarized, null, 2)}`);
    }
    async saveTopology(workspaceId, params, ctx) {
        const name = (params.topology_name ?? '').trim();
        if (!name)
            return this.err('topology_name is required');
        const topologyId = (params.topology_id ?? '').trim();
        const orchestratorRules = params.orchestrator_rules === null ? null : parseOrchestratorRules(params.orchestrator_rules);
        const adaptiveModelPolicy = params.adaptive_model_policy === null ? null : parseAdaptiveModelPolicyInput(params.adaptive_model_policy);
        const adaptiveOrchestratorPolicy = params.adaptive_orchestrator_policy === null ? null : parseAdaptiveOrchestratorPolicy(params.adaptive_orchestrator_policy);
        const modelRoutes = params.model_routes === null ? null : parseTeamTopologyModelRoutes(params.model_routes);
        const candidateStrategy = params.candidate_strategy === null ? null : parseTeamTopologyCandidateStrategy(params.candidate_strategy);
        const candidateRolloutPolicy = params.candidate_rollout_policy === null ? null : parseTeamTopologyCandidateRolloutPolicy(params.candidate_rollout_policy);
        const candidateRolloutControl = params.candidate_rollout_control === null ? null : parseTeamTopologyCandidateRolloutControl(params.candidate_rollout_control);
        if (params.orchestrator_rules !== undefined && params.orchestrator_rules !== null && !orchestratorRules) {
            return this.err('orchestrator_rules is invalid');
        }
        if (params.adaptive_model_policy !== undefined && params.adaptive_model_policy !== null && !adaptiveModelPolicy) {
            return this.err('adaptive_model_policy is invalid');
        }
        if (params.adaptive_orchestrator_policy !== undefined && params.adaptive_orchestrator_policy !== null && !adaptiveOrchestratorPolicy) {
            return this.err('adaptive_orchestrator_policy is invalid');
        }
        if (params.model_routes !== undefined && params.model_routes !== null && !modelRoutes) {
            return this.err('model_routes is invalid');
        }
        if (params.candidate_strategy !== undefined && params.candidate_strategy !== null && !candidateStrategy) {
            return this.err('candidate_strategy is invalid');
        }
        if (params.candidate_rollout_policy !== undefined && params.candidate_rollout_policy !== null && !candidateRolloutPolicy) {
            return this.err('candidate_rollout_policy is invalid');
        }
        if (params.candidate_rollout_control !== undefined && params.candidate_rollout_control !== null && !candidateRolloutControl) {
            return this.err('candidate_rollout_control is invalid');
        }
        const existingTopology = topologyId ? await memoryStore.getTeamTopology(topologyId) : null;
        if (topologyId && !existingTopology)
            return this.err(`Topology not found: ${topologyId}`);
        const mergedMetadata = {
            ...(existingTopology?.metadata ?? {}),
        };
        if (params.adaptive_orchestrator_policy !== undefined) {
            if (adaptiveOrchestratorPolicy)
                mergedMetadata['adaptiveOrchestratorPolicy'] = adaptiveOrchestratorPolicy;
            else
                delete mergedMetadata['adaptiveOrchestratorPolicy'];
        }
        const topology = topologyId
            ? await memoryStore.updateTeamTopology(topologyId, {
                name,
                ...(typeof params.department === 'string' ? { department: params.department || null } : {}),
                ...(typeof params.role_name === 'string' ? { role: params.role_name || null } : {}),
                ...(typeof params.supervisor_agent_id === 'string' ? { supervisorAgentId: params.supervisor_agent_id || null } : {}),
                ...(parseStringArray(params.worker_agent_ids) ? { workerAgentIds: parseStringArray(params.worker_agent_ids) } : {}),
                ...(parseStringArray(params.template_ids) ? { defaultTemplateIds: parseStringArray(params.template_ids) } : {}),
                ...(typeof params.human_owner_user_id === 'string' ? { defaultHumanOwnerUserId: params.human_owner_user_id || null } : {}),
                ...(params.orchestrator_rules !== undefined ? { orchestratorRules } : {}),
                ...(params.adaptive_model_policy !== undefined ? { adaptiveModelPolicy } : {}),
                ...(params.model_routes !== undefined ? { modelRoutes } : {}),
                ...(params.candidate_strategy !== undefined ? { candidateStrategy } : {}),
                ...(params.candidate_rollout_policy !== undefined ? { candidateRolloutPolicy } : {}),
                ...(params.candidate_rollout_control !== undefined ? { candidateRolloutControl } : {}),
                ...(params.adaptive_orchestrator_policy !== undefined ? { metadata: mergedMetadata } : {}),
            })
            : await memoryStore.createTeamTopology({
                workspaceId,
                name,
                department: typeof params.department === 'string' ? params.department : undefined,
                role: typeof params.role_name === 'string' ? params.role_name : undefined,
                supervisorAgentId: typeof params.supervisor_agent_id === 'string' ? params.supervisor_agent_id : undefined,
                workerAgentIds: parseStringArray(params.worker_agent_ids),
                defaultTemplateIds: parseStringArray(params.template_ids),
                defaultHumanOwnerUserId: typeof params.human_owner_user_id === 'string' ? params.human_owner_user_id : undefined,
                ...(params.orchestrator_rules !== undefined ? { orchestratorRules } : {}),
                ...(params.adaptive_model_policy !== undefined ? { adaptiveModelPolicy } : {}),
                ...(params.model_routes !== undefined ? { modelRoutes } : {}),
                ...(params.candidate_strategy !== undefined ? { candidateStrategy } : {}),
                ...(params.candidate_rollout_policy !== undefined ? { candidateRolloutPolicy } : {}),
                ...(params.candidate_rollout_control !== undefined ? { candidateRolloutControl } : {}),
                ...(params.adaptive_orchestrator_policy !== undefined ? { metadata: mergedMetadata } : {}),
                createdBy: ctx.userId,
            });
        return this.text(topology ? `Saved team topology ${topology.name}.` : 'Topology save failed');
    }
    async promoteTopologyStrategy(workspaceId, params) {
        const topologyId = (params.topology_id ?? '').trim();
        if (!topologyId)
            return this.err('topology_id is required');
        const topology = await memoryStore.getTeamTopology(topologyId);
        if (!topology || topology.workspaceId !== workspaceId)
            return this.err(`Topology not found: ${topologyId}`);
        const orchestratorRules = params.orchestrator_rules === null ? null : parseOrchestratorRules(params.orchestrator_rules);
        const adaptiveModelPolicy = params.adaptive_model_policy === null ? null : parseAdaptiveModelPolicyInput(params.adaptive_model_policy);
        const modelRoutes = params.model_routes === null ? null : parseTeamTopologyModelRoutes(params.model_routes);
        if (params.orchestrator_rules !== undefined && params.orchestrator_rules !== null && !orchestratorRules) {
            return this.err('orchestrator_rules is invalid');
        }
        if (params.adaptive_model_policy !== undefined && params.adaptive_model_policy !== null && !adaptiveModelPolicy) {
            return this.err('adaptive_model_policy is invalid');
        }
        if (params.model_routes !== undefined && params.model_routes !== null && !modelRoutes) {
            return this.err('model_routes is invalid');
        }
        const updated = await memoryStore.updateTeamTopology(topologyId, {
            ...(params.orchestrator_rules !== undefined ? { orchestratorRules } : {}),
            ...(params.adaptive_model_policy !== undefined ? { adaptiveModelPolicy } : {}),
            ...(params.model_routes !== undefined ? { modelRoutes } : {}),
        });
        if (!updated)
            return this.err(`Topology update failed: ${topologyId}`);
        return this.text(`Promoted topology strategy for ${updated.name} from v${topology.strategyVersion ?? 1} to v${updated.strategyVersion ?? 1}.`);
    }
    async promoteTopologyCandidate(workspaceId, params) {
        const topologyId = (params.topology_id ?? '').trim();
        if (!topologyId)
            return this.err('topology_id is required');
        const topology = await memoryStore.getTeamTopology(topologyId);
        if (!topology || topology.workspaceId !== workspaceId)
            return this.err(`Topology not found: ${topologyId}`);
        const promotion = buildPromoteCandidateStrategyUpdates(topology);
        if (!promotion)
            return this.err(`Topology has no candidate strategy to promote: ${topologyId}`);
        const nowIso = new Date().toISOString();
        const updated = await memoryStore.updateTeamTopology(topologyId, promotion.updates);
        if (!updated)
            return this.err(`Topology candidate promotion failed: ${topologyId}`);
        await memoryStore.updateTeamTopology(topologyId, {
            metadata: appendCandidateRolloutAuditEvent(updated.metadata, {
                action: 'manual_promote',
                at: nowIso,
                actor: 'user',
                reason: 'Manual candidate promotion',
                fromRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                toRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                candidateVersion: promotion.candidate.version,
                stableVersion: updated.strategyVersion ?? 1,
            }),
        });
        return this.text(`Promoted candidate strategy v${promotion.candidate.version} for ${updated.name} into stable v${updated.strategyVersion ?? 1}.`);
    }
    async setTopologyCandidateRolloutFrozen(workspaceId, params, ctx, frozen) {
        const topologyId = (params.topology_id ?? '').trim();
        if (!topologyId)
            return this.err('topology_id is required');
        const topology = await memoryStore.getTeamTopology(topologyId);
        if (!topology || topology.workspaceId !== workspaceId)
            return this.err(`Topology not found: ${topologyId}`);
        const reason = typeof params.freeze_reason === 'string' && params.freeze_reason.trim() ? params.freeze_reason.trim() : null;
        const nowIso = new Date().toISOString();
        const control = {
            enabled: topology.candidateRolloutControl?.enabled ?? true,
            frozen,
            freezeReason: frozen ? reason : null,
            frozenAt: frozen ? nowIso : null,
            frozenBy: frozen ? ctx.userId : null,
            updatedAt: nowIso,
            updatedBy: ctx.userId,
        };
        const updated = await memoryStore.updateTeamTopology(topologyId, {
            candidateRolloutControl: control,
            metadata: appendCandidateRolloutAuditEvent(topology.metadata, {
                action: frozen ? 'freeze' : 'resume',
                at: nowIso,
                actor: 'user',
                reason,
                fromRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                toRolloutPercent: topology.candidateStrategy?.rolloutPercent ?? null,
                candidateVersion: topology.candidateStrategy?.version ?? null,
                stableVersion: topology.strategyVersion ?? 1,
            }),
        });
        if (!updated)
            return this.err(`Topology candidate rollout update failed: ${topologyId}`);
        return this.text(frozen
            ? `Froze candidate rollout automation for ${updated.name}.${reason ? ` Reason: ${reason}` : ''}`
            : `Resumed candidate rollout automation for ${updated.name}.`);
    }
    async setTopologyOrchestratorFrozen(workspaceId, params, ctx, frozen) {
        const topologyId = (params.topology_id ?? '').trim();
        if (!topologyId)
            return this.err('topology_id is required');
        const topology = await memoryStore.getTeamTopology(topologyId);
        if (!topology || topology.workspaceId !== workspaceId)
            return this.err(`Topology not found: ${topologyId}`);
        const freezeMinutes = Number.isFinite(Number(params.freeze_minutes))
            ? Math.max(1, Math.floor(Number(params.freeze_minutes)))
            : 180;
        const reason = typeof params.freeze_reason === 'string' && params.freeze_reason.trim() ? params.freeze_reason.trim() : null;
        const now = new Date();
        const nowIso = now.toISOString();
        const frozenUntil = frozen ? new Date(now.getTime() + freezeMinutes * 60_000).toISOString() : null;
        const updated = await memoryStore.updateTeamTopology(topologyId, {
            metadata: {
                ...(topology.metadata ?? {}),
                lastOrchFrozenUntil: frozenUntil,
                lastOrchFreezeReason: frozen ? reason : null,
                lastOrchFrozenBy: ctx.userId,
                lastOrchManualControl: true,
                ...(frozen ? {} : { orchDegradedStreak: 0 }),
            },
        });
        if (!updated)
            return this.err(`Topology orchestrator control update failed: ${topologyId}`);
        return this.text(frozen
            ? `Froze adaptive orchestrator automation for ${updated.name} until ${frozenUntil}.${reason ? ` Reason: ${reason}` : ''}`
            : `Resumed adaptive orchestrator automation for ${updated.name}.`);
    }
    async rollbackTopologyStrategy(workspaceId, params) {
        const topologyId = (params.topology_id ?? '').trim();
        if (!topologyId)
            return this.err('topology_id is required');
        const requestedVersion = Number(params.strategy_version);
        if (!Number.isFinite(requestedVersion) || requestedVersion < 1)
            return this.err('strategy_version must be a positive integer');
        const topology = await memoryStore.getTeamTopology(topologyId);
        if (!topology || topology.workspaceId !== workspaceId)
            return this.err(`Topology not found: ${topologyId}`);
        const snapshot = findTeamTopologyStrategySnapshot(topology, requestedVersion);
        if (!snapshot)
            return this.err(`Strategy version not found: ${requestedVersion}`);
        const updated = await memoryStore.updateTeamTopology(topologyId, {
            orchestratorRules: snapshot.orchestratorRules ?? null,
            adaptiveModelPolicy: snapshot.adaptiveModelPolicy ?? null,
            modelRoutes: snapshot.modelRoutes ?? null,
        });
        if (!updated)
            return this.err(`Topology rollback failed: ${topologyId}`);
        return this.text(`Rolled back topology ${updated.name} using strategy v${snapshot.version}. Current version is now v${updated.strategyVersion ?? 1}.`);
    }
    async instantiateTopology(workspaceId, params, ctx) {
        const topologyId = (params.topology_id ?? '').trim();
        if (!topologyId)
            return this.err('topology_id is required');
        const topology = await memoryStore.getTeamTopology(topologyId);
        if (!topology || topology.workspaceId !== workspaceId)
            return this.err(`Topology not found: ${topologyId}`);
        const tasks = await instantiateTeamTopologyById(topologyId, ctx, {
            humanOwnerUserId: typeof params.human_owner_user_id === 'string' ? params.human_owner_user_id : undefined,
            variables: parseTeamTemplateVariableValues(params.variables),
            templateIds: parseStringArray(params.template_ids),
            workerAgentIds: parseStringArray(params.worker_agent_ids),
            supervisorAgentId: typeof params.supervisor_agent_id === 'string' ? params.supervisor_agent_id : undefined,
        });
        return this.text(`Instantiated topology ${topology.name} into ${tasks.length} tasks.\n\n${tasks.map(renderTask).join('\n\n')}`);
    }
}
//# sourceMappingURL=team.js.map