import { nanoid } from 'nanoid';
import { createLogger } from '../utils/logger.js';
import { BM25Index } from './bm25.js';
import { cosineSimilarity, generateEmbedding } from './embedding.js';
const log = createLogger('memory');
function normalizeScope(scope) {
    return {
        userId: scope.userId,
        channel: scope.channel,
        workspaceId: scope.workspaceId ?? '',
        agentId: scope.agentId ?? '',
    };
}
function mapMemoryRow(row) {
    return {
        id: row.id,
        userId: row.user_id,
        channel: row.channel,
        workspaceId: row.workspace_id || null,
        agentId: row.agent_id || null,
        key: row.key,
        value: row.value,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
        expiresAt: row.expires_at ? new Date(row.expires_at) : undefined,
    };
}
export function createMemoryDomainStore(db) {
    const queryEmbCache = new Map();
    const getCachedQueryEmbedding = (query) => queryEmbCache.get(query) ?? null;
    const api = {
        setMemory(userId, channel, key, value, ttlDays) {
            const now = Date.now();
            const expiresAt = ttlDays != null ? now + ttlDays * 24 * 3600 * 1000 : null;
            db.prepare(`INSERT INTO memory (id, user_id, channel, key, value, created_at, updated_at, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(user_id, channel, key)
         DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at, expires_at = excluded.expires_at`).run(nanoid(), userId, channel, key, value, now, now, expiresAt);
            const entryText = `${key} ${value}`;
            setImmediate(async () => {
                try {
                    const embedding = await generateEmbedding(entryText);
                    if (embedding) {
                        db.prepare(`UPDATE memory SET embedding = ? WHERE user_id = ? AND channel = ? AND key = ?`).run(JSON.stringify(embedding), userId, channel, key);
                    }
                }
                catch {
                    // Non-fatal background enrichment.
                }
            });
        },
        getMemory(userId, channel, key) {
            const row = db.prepare(`SELECT value FROM memory WHERE user_id = ? AND channel = ? AND key = ?
         AND (expires_at IS NULL OR expires_at > ?)`).get(userId, channel, key, Date.now());
            return row?.value ?? null;
        },
        getAllMemory(userId, channel) {
            const rows = db.prepare(`SELECT key, value FROM memory WHERE user_id = ? AND channel = ?
         AND (expires_at IS NULL OR expires_at > ?)`).all(userId, channel, Date.now());
            return Object.fromEntries(rows.map((row) => [row.key, row.value]));
        },
        deleteMemory(userId, channel, key) {
            const result = db.prepare(`DELETE FROM memory WHERE user_id = ? AND channel = ? AND key = ?`).run(userId, channel, key);
            return result.changes > 0;
        },
        searchSemantic(userId, channel, query, limit = 5) {
            const all = db.prepare(`SELECT * FROM memory WHERE user_id = ? AND channel = ?
         AND (expires_at IS NULL OR expires_at > ?)`).all(userId, channel, Date.now());
            if (all.length === 0)
                return [];
            const index = new BM25Index();
            index.build(all.map((row) => ({ id: row.id, text: `${row.key} ${row.value}` })));
            const hits = index.query(query, limit * 2);
            const byId = new Map(all.map((row) => [row.id, row]));
            let results = hits
                .map(({ id, score }) => ({ row: byId.get(id), bm25Score: score }))
                .filter((item) => item.row != null);
            const withEmbeddings = all.filter((row) => row.embedding);
            const queryEmbedding = getCachedQueryEmbedding(query);
            if (queryEmbedding && withEmbeddings.length > 0) {
                results = results.map(({ row, bm25Score }) => {
                    let cosScore = 0;
                    if (row.embedding) {
                        try {
                            const embedding = JSON.parse(row.embedding);
                            cosScore = cosineSimilarity(queryEmbedding, embedding);
                        }
                        catch (error) {
                            log.debug({ key: row.key, err: String(error) }, 'Corrupted embedding JSON, skipping cosine re-rank');
                        }
                    }
                    return { row, bm25Score: bm25Score * 0.6 + cosScore * 0.4 };
                });
                results.sort((a, b) => b.bm25Score - a.bm25Score);
            }
            return results.slice(0, limit).map(({ row }) => ({
                id: row.id,
                userId: row.user_id,
                channel: row.channel,
                key: row.key,
                value: row.value,
                createdAt: new Date(row.created_at),
                updatedAt: new Date(row.updated_at),
                expiresAt: row.expires_at ? new Date(row.expires_at) : undefined,
            }));
        },
        async warmQueryEmbedding(query) {
            if (queryEmbCache.has(query))
                return;
            const embedding = await generateEmbedding(query);
            if (embedding)
                queryEmbCache.set(query, embedding);
            if (queryEmbCache.size > 100) {
                const firstKey = queryEmbCache.keys().next().value;
                if (firstKey)
                    queryEmbCache.delete(firstKey);
            }
        },
        searchMemory(userId, channel, query, limit = 10) {
            const rows = db.prepare(`SELECT * FROM memory WHERE user_id = ? AND channel = ?
         AND (expires_at IS NULL OR expires_at > ?)
         AND (key LIKE ? OR value LIKE ?) LIMIT ?`).all(userId, channel, Date.now(), `%${query}%`, `%${query}%`, limit);
            return rows.map((row) => ({
                id: row.id,
                userId: row.user_id,
                channel: row.channel,
                key: row.key,
                value: row.value,
                createdAt: new Date(row.created_at),
                updatedAt: new Date(row.updated_at),
                expiresAt: row.expires_at ? new Date(row.expires_at) : undefined,
            }));
        },
        getCorrectionCount(userId, channel, windowMs) {
            const cutoff = Date.now() - windowMs;
            const stmt = db.prepare(`SELECT COUNT(*) as cnt FROM memory WHERE key LIKE 'correction:%' AND user_id = ? AND channel = ? AND created_at > ?`);
            return stmt.get(userId, channel, cutoff).cnt;
        },
        setScopedMemory(scope, key, value, ttlDays) {
            const normalized = normalizeScope(scope);
            const now = Date.now();
            const expiresAt = ttlDays != null ? now + ttlDays * 24 * 3600 * 1000 : null;
            db.prepare(`INSERT INTO scoped_memory (id, user_id, channel, workspace_id, agent_id, key, value, created_at, updated_at, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(user_id, channel, workspace_id, agent_id, key)
         DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at, expires_at = excluded.expires_at`).run(nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, key, value, now, now, expiresAt);
            const entryText = `${key} ${value}`;
            setImmediate(async () => {
                try {
                    const embedding = await generateEmbedding(entryText);
                    if (embedding) {
                        db.prepare(`UPDATE scoped_memory
               SET embedding = ?
               WHERE user_id = ? AND channel = ?
                 AND ((workspace_id IS NULL AND ? IS NULL) OR workspace_id = ?)
                 AND ((agent_id IS NULL AND ? IS NULL) OR agent_id = ?)
                 AND key = ?`).run(JSON.stringify(embedding), normalized.userId, normalized.channel, normalized.workspaceId, normalized.workspaceId, normalized.agentId, normalized.agentId, key);
                    }
                }
                catch {
                    // Non-fatal background enrichment.
                }
            });
        },
        getScopedMemory(scope, key) {
            const normalized = normalizeScope(scope);
            const row = db.prepare(`SELECT value FROM scoped_memory
         WHERE user_id = ? AND channel = ?
           AND ((workspace_id IS NULL AND ? IS NULL) OR workspace_id = ?)
           AND ((agent_id IS NULL AND ? IS NULL) OR agent_id = ?)
           AND key = ?
           AND (expires_at IS NULL OR expires_at > ?)`).get(normalized.userId, normalized.channel, normalized.workspaceId, normalized.workspaceId, normalized.agentId, normalized.agentId, key, Date.now());
            return row?.value ?? null;
        },
        getAllScopedMemory(scope) {
            const normalized = normalizeScope(scope);
            const rows = db.prepare(`SELECT key, value FROM scoped_memory
         WHERE user_id = ? AND channel = ?
           AND ((workspace_id IS NULL AND ? IS NULL) OR workspace_id = ?)
           AND ((agent_id IS NULL AND ? IS NULL) OR agent_id = ?)
           AND (expires_at IS NULL OR expires_at > ?)`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.workspaceId, normalized.agentId, normalized.agentId, Date.now());
            return Object.fromEntries(rows.map((row) => [row.key, row.value]));
        },
        deleteScopedMemory(scope, key) {
            const normalized = normalizeScope(scope);
            const result = db.prepare(`DELETE FROM scoped_memory
         WHERE user_id = ? AND channel = ?
           AND ((workspace_id IS NULL AND ? IS NULL) OR workspace_id = ?)
           AND ((agent_id IS NULL AND ? IS NULL) OR agent_id = ?)
           AND key = ?`).run(normalized.userId, normalized.channel, normalized.workspaceId, normalized.workspaceId, normalized.agentId, normalized.agentId, key);
            return result.changes > 0;
        },
        searchScopedSemantic(scope, query, limit = 5) {
            const normalized = normalizeScope(scope);
            const all = db.prepare(`SELECT * FROM scoped_memory
         WHERE user_id = ? AND channel = ?
           AND ((workspace_id IS NULL AND ? IS NULL) OR workspace_id = ?)
           AND ((agent_id IS NULL AND ? IS NULL) OR agent_id = ?)
           AND (expires_at IS NULL OR expires_at > ?)`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.workspaceId, normalized.agentId, normalized.agentId, Date.now());
            if (all.length === 0)
                return [];
            const index = new BM25Index();
            index.build(all.map((row) => ({ id: row.id, text: `${row.key} ${row.value}` })));
            const hits = index.query(query, limit * 2);
            const byId = new Map(all.map((row) => [row.id, row]));
            let results = hits
                .map(({ id, score }) => ({ row: byId.get(id), bm25Score: score }))
                .filter((item) => item.row != null);
            const queryEmbedding = getCachedQueryEmbedding(query);
            if (queryEmbedding) {
                results = results.map(({ row, bm25Score }) => {
                    let cosScore = 0;
                    if (row.embedding) {
                        try {
                            cosScore = cosineSimilarity(queryEmbedding, JSON.parse(row.embedding));
                        }
                        catch {
                            // Skip invalid embedding payloads.
                        }
                    }
                    return { row, bm25Score: bm25Score * 0.6 + cosScore * 0.4 };
                });
                results.sort((a, b) => b.bm25Score - a.bm25Score);
            }
            return results.slice(0, limit).map(({ row }) => mapMemoryRow(row));
        },
        searchScopedMemory(scope, query, limit = 10) {
            const normalized = normalizeScope(scope);
            const rows = db.prepare(`SELECT * FROM scoped_memory
         WHERE user_id = ? AND channel = ?
           AND ((workspace_id IS NULL AND ? IS NULL) OR workspace_id = ?)
           AND ((agent_id IS NULL AND ? IS NULL) OR agent_id = ?)
           AND (expires_at IS NULL OR expires_at > ?)
           AND (key LIKE ? OR value LIKE ?)
         LIMIT ?`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.workspaceId, normalized.agentId, normalized.agentId, Date.now(), `%${query}%`, `%${query}%`, limit);
            return rows.map((row) => mapMemoryRow(row));
        },
        getDueReminders() {
            const now = Date.now();
            const rows = db.prepare(`SELECT user_id, channel, key, value FROM memory
         WHERE key LIKE 'reminder:%'
         AND (expires_at IS NULL OR expires_at > ?)`).all(now);
            return rows.filter((row) => {
                try {
                    const reminder = JSON.parse(row.value);
                    if (reminder.done || !reminder.dueAt)
                        return false;
                    const dueAt = new Date(reminder.dueAt).getTime();
                    return !Number.isNaN(dueAt) && dueAt <= now;
                }
                catch {
                    return false;
                }
            }).map((row) => ({ userId: row.user_id, channel: row.channel, key: row.key, value: row.value }));
        },
        markReminderDone(userId, channel, key) {
            const raw = db.prepare(`SELECT value FROM memory WHERE user_id = ? AND channel = ? AND key = ?`).get(userId, channel, key);
            if (!raw)
                return;
            try {
                const reminder = JSON.parse(raw.value);
                reminder.done = true;
                db.prepare(`UPDATE memory SET value = ?, updated_at = ? WHERE user_id = ? AND channel = ? AND key = ?`).run(JSON.stringify(reminder), Date.now(), userId, channel, key);
            }
            catch {
                // Ignore invalid reminder payloads.
            }
        },
        recordMemoryChange(userId, channel, key, oldValue, newValue, source) {
            api.recordScopedMemoryChange({ userId, channel: channel }, key, oldValue, newValue, source);
        },
        recordScopedMemoryChange(scope, key, oldValue, newValue, source) {
            const normalized = normalizeScope(scope);
            db.prepare(`INSERT INTO memory_history (id, user_id, channel, workspace_id, agent_id, key, old_value, new_value, source, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, key, oldValue ?? null, newValue, source, new Date().toISOString());
        },
        getMemoryHistory(userId, channel, limit = 50) {
            return api.getScopedMemoryHistory({ userId, channel: channel }, limit);
        },
        getScopedMemoryHistory(scope, limit = 50) {
            const normalized = normalizeScope(scope);
            return db.prepare(`SELECT * FROM memory_history WHERE user_id = ? AND channel = ?
           AND IFNULL(workspace_id, '') = ?
           AND IFNULL(agent_id, '') = ?
         ORDER BY created_at DESC, rowid DESC LIMIT ?`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit);
        },
        rollbackMemory(userId, channel, historyId) {
            return api.rollbackScopedMemory({ userId, channel }, historyId);
        },
        rollbackScopedMemory(scope, historyId) {
            const normalized = normalizeScope(scope);
            const entry = db.prepare(`SELECT * FROM memory_history WHERE id = ? AND user_id = ? AND channel = ?
           AND IFNULL(workspace_id, '') = ?
           AND IFNULL(agent_id, '') = ?`).get(historyId, normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId);
            if (!entry)
                return false;
            const hasScopedNamespace = Boolean(scope.workspaceId || scope.agentId);
            if (entry.old_value === null || entry.old_value === undefined) {
                if (hasScopedNamespace)
                    api.deleteScopedMemory(scope, entry.key);
                else
                    api.deleteMemory(scope.userId, scope.channel, entry.key);
            }
            else {
                if (hasScopedNamespace)
                    api.setScopedMemory(scope, entry.key, entry.old_value);
                else
                    api.setMemory(scope.userId, scope.channel, entry.key, entry.old_value);
            }
            api.recordScopedMemoryChange(scope, entry.key, entry.new_value, entry.old_value ?? '', 'manual');
            return true;
        },
    };
    return api;
}
//# sourceMappingURL=store_memory.js.map