import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
const TEST_SYSTEM = `你是一位资深的测试工程师，拥有丰富的硬件测试、软件测试和系统集成测试经验。
你熟悉各类测试方法论（黑盒/白盒/灰盒测试）、测试标准（IEC/ISO/GB）、自动化测试框架，
以及硬件测试仪器（示波器、逻辑分析仪、频谱仪、万用表等）的使用。
你能够制定全面的测试计划、设计详细的测试用例、分析测试结果并提供调试建议。`;
export class HardwareTestSkill extends BaseSkill {
    definition = {
        name: 'hardware_test',
        description: '硬件与代码测试辅助。支持制定测试计划、设计测试用例、生成测试报告、提供调试指导。覆盖硬件功能测试、软件单元测试、系统集成测试等场景。',
        category: 'engineering',
        parameters: [
            { name: 'type', type: 'string', required: true, description: '测试类型：hardware=硬件测试，code=代码测试，integration=集成测试', enum: ['hardware', 'code', 'integration'] },
            { name: 'target', type: 'string', required: true, description: '被测对象描述（硬件模块名称/代码功能/系统名称）' },
            { name: 'action', type: 'string', required: true, description: '操作类型：plan=测试计划，cases=测试用例，report=测试报告，debug=调试指导', enum: ['plan', 'cases', 'report', 'debug'] },
            { name: 'description', type: 'string', required: false, description: '详细描述（功能规格/接口定义/测试环境等）' },
            { name: 'results', type: 'string', required: false, description: '测试结果数据（report/debug时提供）' },
            { name: 'code', type: 'string', required: false, description: '待测代码（code类型时提供）' },
            { name: 'standard', type: 'string', required: false, description: '适用的测试标准或规范，如：IEC 61508、GB/T 25000等' },
        ],
        examples: [
            'hardware_test type=hardware target="温湿度传感器模块" action=cases description="DHT22传感器，I2C接口，量程-40~80°C"',
            'hardware_test type=code target="串口通信驱动" action=plan code="[代码内容]"',
            'hardware_test type=hardware target="电源管理模块" action=report results="[测试数据]"',
        ],
    };
    async execute(params, _ctx) {
        const type = String(params.type ?? '').trim();
        const target = String(params.target ?? '').trim();
        const action = String(params.action ?? '').trim();
        const description = String(params.description ?? '').trim();
        const results = String(params.results ?? '').trim();
        const code = String(params.code ?? '').trim();
        const standard = String(params.standard ?? '').trim();
        if (!type)
            return this.err('请指定测试类型：hardware/code/integration');
        if (!target)
            return this.err('请提供被测对象描述');
        if (!action)
            return this.err('请指定操作类型：plan/cases/report/debug');
        const typeLabel = { hardware: '硬件', code: '代码', integration: '集成' }[type] ?? type;
        const ctx = [description, standard ? `适用标准：${standard}` : ''].filter(Boolean).join('\n');
        switch (action) {
            case 'plan': return this.testPlan(target, typeLabel, ctx, code);
            case 'cases': return this.testCases(target, typeLabel, ctx, code);
            case 'report':
                if (!results)
                    return this.err('生成测试报告需要提供测试结果数据（results参数）');
                return this.testReport(target, typeLabel, ctx, results);
            case 'debug': return this.debugGuide(target, typeLabel, ctx, results, code);
            default: return this.err(`不支持的操作类型：${action}`);
        }
    }
    async llm(prompt, maxTokens = 2500) {
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: prompt }],
            systemPrompt: TEST_SYSTEM,
            maxTokens,
            temperature: 0.2,
        });
        return res.content?.trim() ?? '';
    }
    async testPlan(target, typeLabel, ctx, code) {
        const codeSection = code ? `\n\n相关代码/接口定义：\n\`\`\`\n${code.slice(0, 1500)}\n\`\`\`` : '';
        const prompt = `请为以下被测对象制定${typeLabel}测试计划：

被测对象：${target}
${ctx}${codeSection}

请输出完整测试计划：

## 一、测试概述
- 测试目标
- 测试范围
- 测试策略

## 二、测试环境
- 硬件环境（测试设备、仪器仪表）
- 软件环境（工具、框架、版本）
- 测试数据准备

## 三、测试内容
| 测试项目 | 测试方法 | 优先级 | 预计工时 |
|---------|---------|-------|---------|

## 四、测试进度计划
（各阶段时间安排）

## 五、通过/失败标准
（明确的量化指标）

## 六、风险与应对措施
（测试风险识别和缓解策略）

## 七、交付物清单
（测试用例文档、测试报告、缺陷报告等）`;
        try {
            const out = await this.llm(prompt, 2500);
            if (!out)
                return this.err('测试计划生成失败');
            return this.text(`# ${typeLabel}测试计划 — ${target}\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async testCases(target, typeLabel, ctx, code) {
        const codeSection = code ? `\n\n相关代码：\n\`\`\`\n${code.slice(0, 1500)}\n\`\`\`` : '';
        const prompt = `请为以下被测对象设计详细的${typeLabel}测试用例：

被测对象：${target}
${ctx}${codeSection}

请输出完整测试用例集：

## 功能测试用例

| 用例编号 | 用例名称 | 前置条件 | 测试步骤 | 输入数据 | 预期结果 | 优先级 |
|---------|---------|---------|---------|---------|---------|-------|

## 边界值测试用例

| 用例编号 | 测试场景 | 边界值 | 预期结果 |
|---------|---------|-------|---------|

## 异常/容错测试用例

| 用例编号 | 异常场景 | 触发条件 | 预期处理结果 |
|---------|---------|---------|------------|

## 性能测试用例（如适用）

| 用例编号 | 性能指标 | 测试方法 | 通过标准 |
|---------|---------|---------|---------|

## 测试用例统计
- 总用例数：
- 高优先级：
- 中优先级：
- 低优先级：`;
        try {
            const out = await this.llm(prompt, 3000);
            if (!out)
                return this.err('测试用例生成失败');
            return this.text(`# ${typeLabel}测试用例 — ${target}\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async testReport(target, typeLabel, ctx, results) {
        const resultsSnippet = results.slice(0, 3000);
        const prompt = `请根据以下测试数据生成${typeLabel}测试报告：

被测对象：${target}
${ctx}

【测试结果数据】
${resultsSnippet}${results.length > 3000 ? '\n[数据较多，已截取前3000字]' : ''}

请输出正式测试报告：

## 一、执行摘要
（测试结论、主要发现、建议）

## 二、测试概况
- 测试时间：
- 测试环境：
- 测试范围：
- 执行情况：

## 三、测试结果统计
| 测试项目 | 用例总数 | 通过 | 失败 | 阻塞 | 通过率 |
|---------|---------|------|------|------|-------|

## 四、缺陷列表
| 缺陷编号 | 缺陷描述 | 严重程度 | 优先级 | 状态 | 备注 |
|---------|---------|---------|-------|------|------|

## 五、详细测试结果
（各测试项目的详细结果分析）

## 六、风险评估
（未测试项目、已知风险、遗留问题）

## 七、测试结论
（是否达到发布标准，建议）`;
        try {
            const out = await this.llm(prompt, 2500);
            if (!out)
                return this.err('测试报告生成失败');
            return this.text(`# ${typeLabel}测试报告 — ${target}\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async debugGuide(target, typeLabel, ctx, results, code) {
        const resultsSection = results ? `\n\n测试结果/错误现象：\n${results.slice(0, 2000)}` : '';
        const codeSection = code ? `\n\n相关代码：\n\`\`\`\n${code.slice(0, 1500)}\n\`\`\`` : '';
        const prompt = `请为以下${typeLabel}测试问题提供调试指导：

被测对象：${target}
${ctx}${resultsSection}${codeSection}

请输出系统性调试方案：

## 一、问题分析
（根据现象分析可能的根本原因，按概率排序）

## 二、调试步骤
### 第一步：快速定位
（最快速确认问题范围的方法）

### 第二步：逐步排查
（系统性排查流程）

### 第三步：验证修复
（确认问题已解决的验证方法）

## 三、常见原因对照表
| 现象 | 可能原因 | 排查方法 | 解决方案 |
|------|---------|---------|---------|

## 四、调试工具使用建议
（推荐使用的工具和测量方法）

## 五、修复建议
（针对发现问题的具体修复方案）

## 六、预防措施
（避免类似问题的改进建议）`;
        try {
            const out = await this.llm(prompt, 2500);
            if (!out)
                return this.err('调试指导生成失败');
            return this.text(`# ${typeLabel}调试指导 — ${target}\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
}
//# sourceMappingURL=hardware_test.js.map