#!/usr/bin/env node
/**
 * GreenFrog CLI entry point
 */
import { createCLI } from './cli/index.js';
const program = createCLI();
program.parseAsync(process.argv).catch((err) => {
    console.error('Fatal error:', err);
    process.exit(1);
});
//# sourceMappingURL=entry.js.map