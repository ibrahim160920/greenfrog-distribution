/**
 * greenfrog backup  — pack DB + config into a timestamped .tar.gz
 * greenfrog restore — unpack and restore from a backup archive
 *
 * Archive layout:
 *   greenfrog-backup/
 *     greenfrog.db        ← SQLite database
 *     config.yaml         ← encrypted config (secrets stay encrypted)
 *     custom_skills/      ← user-created skills (if any)
 *     MANIFEST.json       ← backup metadata (version, timestamp, platform)
 */
export declare function backupData(outputPath?: string): Promise<void>;
/**
 * Run a scheduled backup, saving to `config.backup.dir` (default: dataDir).
 * Automatically prunes backups older than `config.backup.keepDays` (default: 7).
 * Safe to call from a cron scheduler — logs to pino, never throws.
 */
export declare function autoBackup(): Promise<void>;
export declare function restoreData(archivePath: string, opts?: {
    force?: boolean;
}): Promise<void>;
//# sourceMappingURL=backup.d.ts.map