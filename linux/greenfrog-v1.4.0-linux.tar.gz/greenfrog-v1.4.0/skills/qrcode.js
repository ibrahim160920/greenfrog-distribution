import QRCode from 'qrcode';
import { BaseSkill } from './base.js';
export class QRCodeSkill extends BaseSkill {
    definition = {
        name: 'generate_qrcode',
        description: 'Generate a QR code for any text, URL, or data. Returns as terminal ASCII art or base64 PNG.',
        category: 'utilities',
        parameters: [
            { name: 'data', type: 'string', description: 'Data to encode in the QR code', required: true },
            { name: 'format', type: 'string', description: 'Output format', enum: ['terminal', 'png_base64'], default: 'terminal' },
        ],
    };
    async execute(params, _ctx) {
        const data = params.data;
        const format = params.format ?? 'terminal';
        try {
            if (format === 'terminal') {
                const ascii = await QRCode.toString(data, { type: 'terminal', small: true });
                return this.text(`📱 **QR Code for:** ${data}\n\`\`\`\n${ascii}\n\`\`\``);
            }
            else {
                const base64 = await QRCode.toDataURL(data);
                return this.text(`📱 **QR Code generated!**\nData URL (PNG):\n${base64.slice(0, 100)}...`);
            }
        }
        catch (err) {
            return this.err(`QR Code error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=qrcode.js.map