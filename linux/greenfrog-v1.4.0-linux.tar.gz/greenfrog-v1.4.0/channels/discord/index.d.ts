import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class DiscordChannel extends BaseChannel {
    readonly name: "discord";
    private client;
    private _running;
    start(): Promise<void>;
    private registerCommands;
    stop(): Promise<void>;
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
}
//# sourceMappingURL=index.d.ts.map