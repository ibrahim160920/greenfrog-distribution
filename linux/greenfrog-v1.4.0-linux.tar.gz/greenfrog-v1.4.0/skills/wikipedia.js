import { BaseSkill } from './base.js';
export class WikipediaSkill extends BaseSkill {
    definition = {
        name: 'wikipedia',
        description: 'Search Wikipedia and get article summaries. Supports English and Chinese. Completely free, no API key needed.',
        category: 'information',
        parameters: [
            { name: 'query', type: 'string', required: true, description: 'Topic or article title to look up' },
            { name: 'lang', type: 'string', description: 'Language code: en (English), zh (Chinese), ja (Japanese), etc.', default: 'en' },
            { name: 'action', type: 'string', description: 'search: find articles | summary: get article content', enum: ['search', 'summary'], default: 'summary' },
        ],
        examples: ['Tell me about quantum computing', 'Wikipedia: 人工智能', 'Search Wikipedia for black holes'],
    };
    async execute(params, _ctx) {
        const query = params.query?.trim();
        if (!query)
            return this.err('Query is required');
        const lang = params.lang?.trim() || 'en';
        const action = params.action || 'summary';
        if (action === 'search')
            return this.searchWikipedia(query, lang);
        return this.getSummary(query, lang);
    }
    async getSummary(query, lang) {
        // First try direct summary by title
        try {
            const encoded = encodeURIComponent(query.replace(/\s+/g, '_'));
            const url = `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encoded}`;
            const res = await fetch(url, {
                headers: { 'User-Agent': 'GreenFrog/1.0 (educational bot)' },
                signal: AbortSignal.timeout(8_000),
            });
            if (res.ok) {
                const data = await res.json();
                if (data.extract) {
                    const url = data.content_urls?.desktop?.page ?? `https://${lang}.wikipedia.org/wiki/${encoded}`;
                    const desc = data.description ? ` *(${data.description})*` : '';
                    return this.text(`📖 **${data.title}**${desc}\n\n${data.extract}\n\n🔗 ${url}`);
                }
            }
        }
        catch { /* fall through to search */ }
        // If direct lookup failed, search first then get top result
        const searchResult = await this.searchWikipedia(query, lang);
        return searchResult;
    }
    async searchWikipedia(query, lang) {
        try {
            const url = `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=5&format=json&origin=*`;
            const res = await fetch(url, {
                headers: { 'User-Agent': 'GreenFrog/1.0 (educational bot)' },
                signal: AbortSignal.timeout(8_000),
            });
            if (!res.ok)
                return this.err(`Wikipedia search failed: ${res.status}`);
            const data = await res.json();
            const results = data.query?.search ?? [];
            if (!results.length)
                return this.text(`No Wikipedia articles found for "${query}".`);
            const lines = results.map((r, i) => {
                const clean = r.snippet.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').slice(0, 200);
                const articleUrl = `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(r.title.replace(/\s+/g, '_'))}`;
                return `${i + 1}. **${r.title}**\n   ${clean}\n   🔗 ${articleUrl}`;
            });
            return this.text(`📖 **Wikipedia: "${query}"**\n\n${lines.join('\n\n')}`);
        }
        catch (err) {
            return this.err(`Wikipedia error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=wikipedia.js.map