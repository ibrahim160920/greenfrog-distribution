/**
 * Execution run records for workflows and scheduled jobs.
 *
 * Design:
 *   - In-memory ring buffer (max 500 records each) — same pattern as execution_trace.ts
 *   - Typed records, not strings — queryable by workflowId / jobId
 *   - Survives within a process lifetime; not persisted across restarts
 *   - Exposed via API for UI/harness consumption
 *
 * Why not SQLite? Adding a new table requires a migration step. For an
 * observability-tier store (recent runs only) the in-memory approach is
 * the right trade-off. Evidence that matters long-term lives in task metadata.
 */
export interface WorkflowStepResult {
    stepId: string;
    prompt: string;
    result: string;
    notified: boolean;
    stopped: boolean;
    durationMs: number;
}
export interface WorkflowRunRecord {
    runId: string;
    workflowId: string;
    workflowName: string;
    trigger: 'manual' | 'cron';
    startedAt: string;
    endedAt: string | null;
    status: 'running' | 'success' | 'failed';
    error?: string;
    stepResults: WorkflowStepResult[];
    durationMs: number | null;
}
export declare function createWorkflowRun(workflowId: string, workflowName: string, trigger?: 'manual' | 'cron'): WorkflowRunRecord;
export declare function addWorkflowStepResult(runId: string, step: WorkflowStepResult): void;
export declare function completeWorkflowRun(runId: string, durationMs: number): void;
export declare function failWorkflowRun(runId: string, error: string, durationMs?: number): void;
export declare function getWorkflowRun(runId: string): WorkflowRunRecord | null;
export declare function getWorkflowRunsForWorkflow(workflowId: string, limit?: number): WorkflowRunRecord[];
export declare function getAllWorkflowRuns(limit?: number): WorkflowRunRecord[];
export interface JobRunRecord {
    runId: string;
    jobId: string;
    jobName: string;
    startedAt: string;
    endedAt: string | null;
    status: 'running' | 'success' | 'failed';
    error?: string;
    resultSummary: string;
    notified: boolean;
    durationMs: number | null;
}
export declare function createJobRun(jobId: string, jobName: string): JobRunRecord;
export declare function completeJobRun(runId: string, resultSummary: string, notified: boolean, durationMs: number): void;
export declare function failJobRun(runId: string, error: string, durationMs: number): void;
export declare function getJobRun(runId: string): JobRunRecord | null;
export declare function getJobRunsForJob(jobId: string, limit?: number): JobRunRecord[];
export declare function getAllJobRuns(limit?: number): JobRunRecord[];
//# sourceMappingURL=run_records.d.ts.map