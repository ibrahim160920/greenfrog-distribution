import type { ProviderRequest, ProviderResponse } from '../utils/types.js';
export declare abstract class BaseProvider {
    abstract name: string;
    abstract defaultModel: string;
    abstract chat(request: ProviderRequest): Promise<ProviderResponse>;
    /**
     * Streaming version of chat().  Yields text tokens as they arrive.
     * After the async generator is exhausted, call `.complete()` to get
     * the full ProviderResponse (including any tool calls).
     *
     * Providers that support streaming should override this.
     */
    chatStream?(request: ProviderRequest): StreamingCall;
    /** Check if provider is configured and reachable */
    abstract isAvailable(): Promise<boolean>;
    /** List available models */
    listModels?(): Promise<string[]>;
}
/**
 * A streaming call in progress.
 * `textStream` yields individual text deltas from the model.
 * `complete()` awaits the full ProviderResponse (available after stream ends).
 */
export interface StreamingCall {
    textStream: AsyncIterable<string>;
    complete(): Promise<ProviderResponse>;
}
//# sourceMappingURL=base.d.ts.map