import { nanoid } from 'nanoid';
function mapAgentRow(row) {
    return {
        id: row['id'],
        name: row['name'],
        description: row['description'],
        workspaceId: row['workspace_id'],
        ownerUserId: row['owner_user_id'],
        status: row['status'],
        memoryScope: row['memory_scope'],
        provider: row['provider'] || null,
        model: row['model'] || null,
        systemPrompt: row['system_prompt'],
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    };
}
function mapAgentBindingRow(row) {
    return {
        id: row['id'],
        agentId: row['agent_id'],
        workspaceId: row['workspace_id'],
        channel: row['channel'],
        userId: row['user_id'],
        chatId: row['chat_id'],
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    };
}
export function createAgentStore(db) {
    const api = {
        createAgent(agent) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO agent_registry (
           id, name, description, workspace_id, owner_user_id, status, memory_scope, provider, model, system_prompt, metadata, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, agent.name, agent.description ?? null, agent.workspaceId, agent.ownerUserId, agent.status ?? 'active', agent.memoryScope ?? 'workspace', agent.provider ?? null, agent.model ?? null, agent.systemPrompt ?? null, agent.metadata ? JSON.stringify(agent.metadata) : null, now, now);
            return api.getAgent(id);
        },
        getAgent(id) {
            const row = db.prepare(`SELECT * FROM agent_registry WHERE id = ?`).get(id);
            return row ? mapAgentRow(row) : null;
        },
        listAgents(workspaceId) {
            const rows = (workspaceId
                ? db.prepare(`SELECT * FROM agent_registry WHERE workspace_id = ? ORDER BY updated_at DESC`).all(workspaceId)
                : db.prepare(`SELECT * FROM agent_registry ORDER BY updated_at DESC`).all());
            return rows.map((row) => mapAgentRow(row));
        },
        updateAgent(id, updates) {
            const current = api.getAgent(id);
            if (!current)
                return null;
            db.prepare(`UPDATE agent_registry
         SET name = ?, description = ?, status = ?, memory_scope = ?, provider = ?, model = ?, system_prompt = ?, metadata = ?, updated_at = ?
         WHERE id = ?`).run(updates.name ?? current.name, updates.description ?? current.description ?? null, updates.status ?? current.status, updates.memoryScope ?? current.memoryScope, updates.provider ?? current.provider ?? null, updates.model ?? current.model ?? null, updates.systemPrompt ?? current.systemPrompt ?? null, JSON.stringify(updates.metadata ?? current.metadata ?? {}), Date.now(), id);
            return api.getAgent(id);
        },
        deleteAgent(id) {
            const result = db.prepare(`DELETE FROM agent_registry WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        createAgentBinding(binding) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO agent_bindings (id, agent_id, workspace_id, channel, user_id, chat_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(id, binding.agentId, binding.workspaceId, binding.channel, binding.userId ?? null, binding.chatId ?? null, now, now);
            return mapAgentBindingRow(db.prepare(`SELECT * FROM agent_bindings WHERE id = ?`).get(id));
        },
        listAgentBindings(filter) {
            const conditions = [];
            const args = [];
            if (filter?.workspaceId) {
                conditions.push('workspace_id = ?');
                args.push(filter.workspaceId);
            }
            if (filter?.agentId) {
                conditions.push('agent_id = ?');
                args.push(filter.agentId);
            }
            if (filter?.channel) {
                conditions.push('channel = ?');
                args.push(filter.channel);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const rows = db.prepare(`SELECT * FROM agent_bindings ${where} ORDER BY created_at ASC`).all(...args);
            return rows.map((row) => mapAgentBindingRow(row));
        },
        deleteAgentBinding(id) {
            const result = db.prepare(`DELETE FROM agent_bindings WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        resolveAgentBinding(params) {
            const row = db.prepare(`SELECT b.*,
                a.id AS resolved_agent_id,
                a.name,
                a.description,
                a.workspace_id AS resolved_workspace_id,
                a.owner_user_id,
                a.status,
                a.memory_scope,
                a.provider,
                a.model,
                a.system_prompt,
                a.metadata,
                a.created_at AS agent_created_at,
                a.updated_at AS agent_updated_at
         FROM agent_bindings b
         JOIN agent_registry a ON a.id = b.agent_id
         WHERE b.channel = ?
           AND a.status = 'active'
           AND (b.user_id IS NULL OR b.user_id = ?)
           AND (b.chat_id IS NULL OR b.chat_id = ?)
         ORDER BY
           CASE WHEN b.user_id = ? THEN 1 ELSE 0 END +
           CASE WHEN b.chat_id = ? THEN 2 ELSE 0 END DESC,
           b.updated_at DESC
         LIMIT 1`).get(params.channel, params.userId, params.chatId, params.userId, params.chatId);
            if (!row)
                return null;
            return {
                binding: mapAgentBindingRow(row),
                agent: mapAgentRow({
                    id: row['resolved_agent_id'],
                    name: row['name'],
                    description: row['description'],
                    workspace_id: row['resolved_workspace_id'],
                    owner_user_id: row['owner_user_id'],
                    status: row['status'],
                    memory_scope: row['memory_scope'],
                    provider: row['provider'],
                    model: row['model'],
                    system_prompt: row['system_prompt'],
                    metadata: row['metadata'],
                    created_at: row['agent_created_at'],
                    updated_at: row['agent_updated_at'],
                }),
            };
        },
    };
    return api;
}
//# sourceMappingURL=store_agent.js.map