import { providerRegistry } from '../providers/index.js';
import { memoryStore } from '../memory/store.js';
import { createLogger } from '../utils/logger.js';
import { appendCandidateRolloutAuditEvent, buildPromoteCandidateStrategyUpdates, findTeamTopologyStrategySnapshot, parseTeamTopologyCandidateRolloutControl, parseTeamTopologyCandidateRolloutPolicy, } from '../utils/team_topology.js';
const log = createLogger('agent:orchestrator');
const SUPERVISOR_RESOLVE_SYSTEM = `You are an orchestrator mediating a peer challenge in an AI agent team.
An agent completed a task. A peer raised a challenge against the result.
Decide: is the challenge valid?

Return ONLY JSON: {"decision":"approve|changes_requested","rationale":"one-line reason (max 100 chars)"}
- "approve"            the original work is acceptable; the challenge is minor or invalid
- "changes_requested"  the challenge reveals a real problem; the work must be revised`;
/**
 * Parses raw metadata into a typed OrchestratorRules object.
 * Returns null if the input is absent or not a valid object.
 */
export function parseOrchestratorRules(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const r = raw;
    return {
        onConflict: r['onConflict'] === 'supervisor_resolve' ? 'supervisor_resolve' : 'consensus',
        onConsensusRejected: r['onConsensusRejected'] === 'reflect_and_retry' ? 'reflect_and_retry' : 'block',
        onTaskDone: r['onTaskDone'] === 'broadcast_result' ? 'broadcast_result' : 'silent',
        model: typeof r['model'] === 'string' && r['model'].trim() ? r['model'].trim() : null,
        provider: typeof r['provider'] === 'string' && r['provider'].trim() ? r['provider'].trim() : null,
    };
}
/**
 * Supervisor agent makes an immediate, binding conflict resolution decision.
 * Much faster than full consensus — uses a single cheap LLM call.
 * Falls back to 'changes_requested' (conservative) on any error.
 */
export async function evaluateSupervisorConflictSafe(params) {
    try {
        return await evaluateSupervisorConflict(params);
    }
    catch (err) {
        log.warn({ err: String(err), taskId: params.task.id }, 'Supervisor conflict resolution failed — defaulting to changes_requested');
        return 'changes_requested';
    }
}
async function evaluateSupervisorConflict(params) {
    const { task, challengeSummary, rules } = params;
    const prompt = [
        `Task: ${task.title}`,
        task.description ? `Description: ${task.description.slice(0, 300)}` : null,
        task.resultSummary ? `Agent output:\n${task.resultSummary.slice(0, 600)}` : null,
        `Challenge: ${challengeSummary}`,
        '\nIs this challenge valid?',
    ].filter(Boolean).join('\n\n');
    const res = await providerRegistry.chatWithFallback({
        messages: [{ role: 'user', content: prompt }],
        systemPrompt: SUPERVISOR_RESOLVE_SYSTEM,
        maxTokens: 150,
        temperature: 0.1,
        ...(rules.model ? { model: rules.model } : {}),
    }, rules.provider ?? undefined);
    const match = (res.content ?? '').match(/\{[\s\S]*\}/);
    if (!match)
        return 'changes_requested';
    const parsed = JSON.parse(match[0]);
    const decision = parsed.decision === 'approve' ? 'approve' : 'changes_requested';
    log.info({ taskId: task.id, decision, rationale: (parsed.rationale ?? '').slice(0, 100) }, 'Orchestrator resolved conflict via supervisor');
    return decision;
}
// ─────────────────────────────────────────────────────────────────────────────
// Adaptive Rules Engine
// Computes swarm health metrics from recent tasks and self-adjusts OrchestratorRules
// when signal thresholds are crossed — no LLM call needed, pure heuristics.
// ─────────────────────────────────────────────────────────────────────────────
const MIN_TASKS_FOR_ADAPTATION = 5;
const ADAPTATION_COOLDOWN_MINUTES = 60;
export function parseAdaptiveOrchestratorPolicy(raw) {
    const record = raw && typeof raw === 'object' && !Array.isArray(raw)
        ? raw
        : {};
    return {
        enabled: record['enabled'] !== false,
        rollbackOnConsecutiveDegrades: Number.isFinite(Number(record['rollbackOnConsecutiveDegrades']))
            ? Math.max(1, Math.floor(Number(record['rollbackOnConsecutiveDegrades'])))
            : 2,
        freezeMinutes: Number.isFinite(Number(record['freezeMinutes']))
            ? Math.max(1, Math.floor(Number(record['freezeMinutes'])))
            : 180,
        severeConsensusTimeoutRate: Number.isFinite(Number(record['severeConsensusTimeoutRate']))
            ? Math.min(1, Math.max(0, Number(record['severeConsensusTimeoutRate'])))
            : 0.5,
        severeBlockedRate: Number.isFinite(Number(record['severeBlockedRate']))
            ? Math.min(1, Math.max(0, Number(record['severeBlockedRate'])))
            : 0.35,
        severeRetryRate: Number.isFinite(Number(record['severeRetryRate']))
            ? Math.min(1, Math.max(0, Number(record['severeRetryRate'])))
            : 0.5,
    };
}
function isSevereOrchestratorRegression(metrics, policy) {
    return metrics.consensusTimeoutRate >= policy.severeConsensusTimeoutRate
        || metrics.blockedRate >= policy.severeBlockedRate
        || metrics.retryRate >= policy.severeRetryRate;
}
function findPreviousStrategySnapshot(topology) {
    if (!topology)
        return null;
    const currentVersion = topology.strategyVersion ?? 1;
    for (let version = currentVersion - 1; version >= 1; version--) {
        const snapshot = findTeamTopologyStrategySnapshot(topology, version);
        if (snapshot)
            return snapshot;
    }
    return null;
}
function resolveCandidatePromotionApproverUserId(params) {
    const candidates = [
        ...((params.control?.approvalUserIds ?? []).filter((value) => typeof value === 'string' && value.trim().length > 0)),
        params.topology?.defaultHumanOwnerUserId ?? null,
        params.topology?.createdBy ?? null,
    ];
    return candidates.find((value) => typeof value === 'string' && value.trim().length > 0) ?? null;
}
/** Pure function — compute swarm health metrics from a task list for one topology. */
function computeSwarmMetricsForRelevantTasks(relevant, topologyId) {
    if (relevant.length < MIN_TASKS_FOR_ADAPTATION)
        return null;
    const challenged = relevant.filter((t) => {
        const challenges = (t.metadata ?? {})['challenges'];
        return Array.isArray(challenges) && challenges.length > 0;
    });
    const challengeUpheld = challenged.filter((t) => {
        const res = (t.metadata ?? {})['supervisorResolution']?.['decision']
            ?? (t.metadata ?? {})['consensus']?.['resolution'];
        return res === 'changes_requested';
    });
    const consensusTasks = relevant.filter((t) => {
        const c = (t.metadata ?? {})['consensus'];
        return c && typeof c === 'object';
    });
    const consensusTimedOut = consensusTasks.filter((t) => {
        const c = (t.metadata ?? {})['consensus'];
        return typeof c['timedOutAt'] === 'string' && c['timedOutAt'].trim().length > 0;
    });
    const retried = relevant.filter((t) => t.attemptCount > 1);
    const blocked = relevant.filter((t) => t.status === 'blocked' || t.status === 'escalated');
    return {
        topologyId,
        taskCount: relevant.length,
        challengedTaskCount: challenged.length,
        retryTaskCount: retried.length,
        consensusTaskCount: consensusTasks.length,
        consensusTimedOutCount: consensusTimedOut.length,
        blockedTaskCount: blocked.length,
        retryRate: relevant.length > 0 ? retried.length / relevant.length : 0,
        challengeRate: relevant.length > 0 ? challenged.length / relevant.length : 0,
        challengeSuccessRate: challenged.length > 0 ? challengeUpheld.length / challenged.length : 0,
        consensusTimeoutRate: consensusTasks.length > 0 ? consensusTimedOut.length / consensusTasks.length : 0,
        blockedRate: relevant.length > 0 ? blocked.length / relevant.length : 0,
        computedAt: new Date().toISOString(),
    };
}
export function computeSwarmMetrics(tasks, topologyId) {
    return computeSwarmMetricsForRelevantTasks(tasks.filter((t) => typeof (t.metadata ?? {})['topologyId'] === 'string'
        && t.metadata['topologyId'] === topologyId), topologyId);
}
export function computeStrategyTrackSwarmMetrics(tasks, topologyId, track) {
    return computeSwarmMetricsForRelevantTasks(tasks.filter((t) => typeof (t.metadata ?? {})['topologyId'] === 'string'
        && t.metadata['topologyId'] === topologyId
        && (((t.metadata ?? {})['topologyStrategyTrack'] === 'candidate' ? 'candidate' : 'stable') === track)), topologyId);
}
/**
 * Derive updated rules from swarm metrics using threshold heuristics.
 * Returns null when no rule changes are warranted.
 *
 * Thresholds (tunable via metadata in the future):
 *   consensusTimeoutRate > 0.30  → switch to supervisor_resolve (voting stalls)
 *   consensusTimeoutRate < 0.05  → revert to consensus (voting works fine)
 *   retryRate > 0.40             → enable reflect_and_retry (agents keep failing same way)
 *   retryRate < 0.15             → revert to block (agents self-correct without reflection)
 */
export function adaptRulesFromMetrics(current, metrics) {
    const updated = { ...current };
    let changed = false;
    if (metrics.consensusTimeoutRate > 0.30 && current.onConflict === 'consensus') {
        updated.onConflict = 'supervisor_resolve';
        changed = true;
        log.info({ topologyId: metrics.topologyId, consensusTimeoutRate: metrics.consensusTimeoutRate }, 'Adaptive rules: consensus timeout rate high — switching to supervisor_resolve');
    }
    else if (metrics.consensusTimeoutRate < 0.05 && current.onConflict === 'supervisor_resolve') {
        updated.onConflict = 'consensus';
        changed = true;
        log.info({ topologyId: metrics.topologyId, consensusTimeoutRate: metrics.consensusTimeoutRate }, 'Adaptive rules: consensus timeout rate low — reverting to consensus');
    }
    if (metrics.retryRate > 0.40 && current.onConsensusRejected === 'block') {
        updated.onConsensusRejected = 'reflect_and_retry';
        changed = true;
        log.info({ topologyId: metrics.topologyId, retryRate: metrics.retryRate }, 'Adaptive rules: high retry rate — enabling reflect_and_retry');
    }
    else if (metrics.retryRate < 0.15 && current.onConsensusRejected === 'reflect_and_retry') {
        updated.onConsensusRejected = 'block';
        changed = true;
        log.info({ topologyId: metrics.topologyId, retryRate: metrics.retryRate }, 'Adaptive rules: retry rate healthy — reverting to block');
    }
    return changed ? updated : null;
}
export function parseAdaptiveModelPolicy(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const record = raw;
    const promotedProvider = typeof record['promotedProvider'] === 'string' && record['promotedProvider'].trim()
        ? record['promotedProvider'].trim()
        : null;
    const promotedModel = typeof record['promotedModel'] === 'string' && record['promotedModel'].trim()
        ? record['promotedModel'].trim()
        : null;
    const revertProvider = typeof record['revertProvider'] === 'string' && record['revertProvider'].trim()
        ? record['revertProvider'].trim()
        : null;
    const revertModel = typeof record['revertModel'] === 'string' && record['revertModel'].trim()
        ? record['revertModel'].trim()
        : null;
    if (!promotedProvider && !promotedModel && !revertProvider && !revertModel)
        return null;
    return {
        promotedProvider,
        promotedModel,
        revertProvider,
        revertModel,
        promoteOnChallengeSuccessRate: Number.isFinite(Number(record['promoteOnChallengeSuccessRate']))
            ? Math.min(1, Math.max(0, Number(record['promoteOnChallengeSuccessRate'])))
            : 0.8,
        revertOnChallengeSuccessRate: Number.isFinite(Number(record['revertOnChallengeSuccessRate']))
            ? Math.min(1, Math.max(0, Number(record['revertOnChallengeSuccessRate'])))
            : 0.5,
        minChallengedTasks: Number.isFinite(Number(record['minChallengedTasks']))
            ? Math.max(1, Math.floor(Number(record['minChallengedTasks'])))
            : 3,
        cooldownMinutes: Number.isFinite(Number(record['cooldownMinutes']))
            ? Math.max(1, Math.floor(Number(record['cooldownMinutes'])))
            : ADAPTATION_COOLDOWN_MINUTES,
    };
}
export function decideAdaptiveModelAction(currentState, metrics, policy) {
    if (metrics.challengedTaskCount < policy.minChallengedTasks)
        return null;
    if (metrics.challengeSuccessRate >= policy.promoteOnChallengeSuccessRate && currentState !== 'promoted') {
        return 'promote';
    }
    if (metrics.challengeSuccessRate <= policy.revertOnChallengeSuccessRate && currentState === 'promoted') {
        return 'revert';
    }
    return null;
}
export function decideCandidateRolloutAction(currentRolloutPercent, metrics, policy) {
    if (metrics.taskCount < policy.minTaskCount)
        return null;
    const current = Math.min(100, Math.max(0, Math.round(currentRolloutPercent)));
    const unhealthyByChallenge = metrics.challengedTaskCount >= policy.minChallengedTasks
        && metrics.challengeSuccessRate <= policy.rollbackOnChallengeSuccessRate;
    const unhealthy = unhealthyByChallenge
        || metrics.consensusTimeoutRate >= policy.rollbackOnConsensusTimeoutRate
        || metrics.blockedRate >= policy.rollbackOnBlockedRate;
    if (unhealthy) {
        return {
            action: 'decrease',
            nextRolloutPercent: Math.max(0, current - policy.stepDownPercent),
        };
    }
    const healthy = metrics.challengedTaskCount >= policy.minChallengedTasks
        && metrics.challengeSuccessRate >= policy.promoteOnChallengeSuccessRate
        && metrics.consensusTimeoutRate <= policy.healthyConsensusTimeoutRate
        && metrics.blockedRate <= policy.healthyBlockedRate;
    if (!healthy)
        return null;
    const nextRolloutPercent = Math.min(policy.maxRolloutPercent, current + policy.stepUpPercent);
    if (nextRolloutPercent >= policy.promoteToStablePercent) {
        return { action: 'promote', nextRolloutPercent };
    }
    if (nextRolloutPercent > current) {
        return { action: 'increase', nextRolloutPercent };
    }
    return null;
}
/**
 * Runs the adaptive rules cycle for one topology:
 * 1. Check cooldown (skip if adapted recently)
 * 2. Compute metrics from task list
 * 3. Derive rule updates from metrics
 * 4. Persist updated rules back to topology metadata
 */
export async function adaptOrchestratorRulesSafe(params) {
    try {
        return await adaptOrchestratorRulesWithRollback(params);
    }
    catch (err) {
        log.warn({ err: String(err), topologyId: params.topologyId }, 'Orchestrator adaptation failed');
        return null;
    }
}
export async function adaptTopologyModelsSafe(params) {
    try {
        return await adaptTopologyModels(params);
    }
    catch (err) {
        log.warn({ err: String(err), topologyId: params.topologyId }, 'Adaptive topology model update failed');
        return null;
    }
}
export async function adaptCandidateRolloutSafe(params) {
    try {
        return await adaptCandidateRollout(params);
    }
    catch (err) {
        log.warn({ err: String(err), topologyId: params.topologyId }, 'Adaptive candidate rollout update failed');
        return null;
    }
}
async function ensureCandidatePromotionApprovalTask(params) {
    const candidate = params.topology.candidateStrategy;
    if (!candidate)
        return null;
    const requestedForUserId = resolveCandidatePromotionApproverUserId({
        topology: params.topology,
        control: params.control,
    });
    if (!requestedForUserId)
        return null;
    const existingTasks = await memoryStore.listTeamTasks({ workspaceId: params.topology.workspaceId });
    const existing = existingTasks.find((task) => {
        if (task.status === 'done' || task.status === 'cancelled')
            return false;
        const metadata = task.metadata ?? {};
        return metadata['governanceKind'] === 'topology_candidate_promotion'
            && metadata['topologyId'] === params.topology.id
            && Number(metadata['candidatePromotionCandidateVersion']) === candidate.version
            && metadata['candidatePromotionApprovalStatus'] === 'pending';
    });
    const summary = [
        `Candidate strategy v${candidate.version} for topology ${params.topology.name} is ready to promote to stable.`,
        `Current rollout: ${candidate.rolloutPercent}%`,
        `Proposed rollout checkpoint: ${params.proposedRolloutPercent}%`,
        `Challenge success rate: ${(params.metrics.challengeSuccessRate * 100).toFixed(1)}%`,
        `Consensus timeout rate: ${(params.metrics.consensusTimeoutRate * 100).toFixed(1)}%`,
        `Blocked rate: ${(params.metrics.blockedRate * 100).toFixed(1)}%`,
    ].join('\n');
    const metadata = {
        requestUserId: 'system',
        requestChannel: 'web',
        requestChatId: params.topology.workspaceId,
        topologyId: params.topology.id,
        topologyName: params.topology.name,
        governanceKind: 'topology_candidate_promotion',
        candidatePromotionApprovalRequired: true,
        candidatePromotionApprovalStatus: 'pending',
        candidatePromotionExecutionStatus: 'pending',
        candidatePromotionCandidateVersion: candidate.version,
        candidatePromotionStableVersion: params.topology.strategyVersion ?? 1,
        candidatePromotionRequestedForUserId: requestedForUserId,
        candidatePromotionRequestedAt: params.metrics.computedAt,
        candidatePromotionRolloutPercent: candidate.rolloutPercent,
        candidatePromotionProposedRolloutPercent: params.proposedRolloutPercent,
        candidatePromotionMetrics: params.metrics,
        candidatePromotionStrategySnapshot: candidate,
    };
    const task = existing
        ? await memoryStore.updateTeamTask(existing.id, {
            status: 'blocked',
            priority: 'high',
            blockedReason: summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: summary.slice(0, 500),
            humanOwnerUserId: requestedForUserId,
            description: summary.slice(0, 2000),
            metadata: {
                ...(existing.metadata ?? {}),
                ...metadata,
            },
        })
        : await memoryStore.createTeamTask({
            workspaceId: params.topology.workspaceId,
            title: `[Governance] Approve topology promotion: ${params.topology.name}`.slice(0, 120),
            description: summary.slice(0, 2000),
            status: 'blocked',
            priority: 'high',
            assignedAgentId: null,
            reviewRequired: false,
            reviewStatus: 'not_required',
            maxAttempts: 1,
            humanOwnerUserId: requestedForUserId,
            blockedReason: summary.slice(0, 500),
            escalationStatus: 'pending',
            escalationReason: summary.slice(0, 500),
            dueAt: new Date(Date.now() + 24 * 3600 * 1000),
            createdBy: 'system',
            metadata,
        });
    if (!task)
        return null;
    const existingApprovals = await memoryStore.listTeamTaskApprovals({
        workspaceId: params.topology.workspaceId,
        taskId: task.id,
        status: 'pending',
        requestedForUserId,
    });
    if (existingApprovals.length > 0) {
        return {
            taskId: task.id,
            approvalId: existingApprovals[0]?.id ?? null,
            approvalCreated: false,
        };
    }
    const approval = await memoryStore.createTeamTaskApproval({
        workspaceId: params.topology.workspaceId,
        taskId: task.id,
        requestedBy: 'system',
        requestedForUserId,
        reason: summary,
    });
    await memoryStore.createTeamNotification({
        workspaceId: params.topology.workspaceId,
        recipientUserId: requestedForUserId,
        type: 'approval_requested',
        severity: 'critical',
        title: `Approval required for topology promotion: ${params.topology.name}`,
        message: summary,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            governanceKind: 'topology_candidate_promotion',
            topologyId: params.topology.id,
            candidateVersion: candidate.version,
        },
    });
    await memoryStore.createTeamNotification({
        workspaceId: params.topology.workspaceId,
        recipientUserId: requestedForUserId,
        type: 'task_escalated',
        severity: 'critical',
        title: `Topology promotion pending approval: ${params.topology.name}`,
        message: summary,
        taskId: task.id,
        approvalId: approval.id,
        metadata: {
            governanceKind: 'topology_candidate_promotion',
            topologyId: params.topology.id,
            candidateVersion: candidate.version,
        },
    });
    return {
        taskId: task.id,
        approvalId: approval.id,
        approvalCreated: true,
    };
}
async function adaptOrchestratorRules(params) {
    const topology = await memoryStore.getTeamTopology(params.topologyId);
    if (!topology)
        return null;
    // Cooldown: don't adapt more than once per hour
    const lastAdaptedAt = typeof topology.metadata?.['lastOrchAdaptedAt'] === 'string'
        ? Date.parse(topology.metadata['lastOrchAdaptedAt'])
        : Number.NaN;
    if (Number.isFinite(lastAdaptedAt)
        && Date.now() - lastAdaptedAt < ADAPTATION_COOLDOWN_MINUTES * 60_000) {
        return null;
    }
    const metrics = computeSwarmMetrics(params.tasks, params.topologyId);
    if (!metrics)
        return null;
    const updated = adaptRulesFromMetrics(params.currentRules, metrics);
    if (!updated) {
        // No rule change — just update the timestamp to reset cooldown window
        await memoryStore.updateTeamTopology(params.topologyId, {
            metadata: { ...topology.metadata, lastOrchAdaptedAt: metrics.computedAt, lastOrchMetrics: metrics },
        });
        return null;
    }
    await memoryStore.updateTeamTopology(params.topologyId, {
        metadata: {
            ...topology.metadata,
            orchestratorRules: updated,
            lastOrchAdaptedAt: metrics.computedAt,
            lastOrchMetrics: metrics,
        },
    });
    log.info({ topologyId: params.topologyId, workspaceId: params.workspaceId, metrics }, 'Orchestrator rules adapted based on swarm metrics');
    return updated;
}
async function adaptOrchestratorRulesWithRollback(params) {
    const topology = await memoryStore.getTeamTopology(params.topologyId);
    if (!topology)
        return null;
    const adaptivePolicy = parseAdaptiveOrchestratorPolicy(topology.metadata?.['adaptiveOrchestratorPolicy']);
    if (!adaptivePolicy.enabled)
        return null;
    const metrics = computeSwarmMetrics(params.tasks, params.topologyId);
    if (!metrics)
        return null;
    const baseMetadata = { ...(topology.metadata ?? {}) };
    const frozenUntil = typeof baseMetadata['lastOrchFrozenUntil'] === 'string'
        ? Date.parse(baseMetadata['lastOrchFrozenUntil'])
        : Number.NaN;
    const severeRegression = isSevereOrchestratorRegression(metrics, adaptivePolicy);
    const priorDegradedStreak = Number.isFinite(Number(baseMetadata['orchDegradedStreak']))
        ? Math.max(0, Math.floor(Number(baseMetadata['orchDegradedStreak'])))
        : 0;
    const degradedStreak = severeRegression ? priorDegradedStreak + 1 : 0;
    if (severeRegression && degradedStreak >= adaptivePolicy.rollbackOnConsecutiveDegrades) {
        const rollbackSnapshot = findPreviousStrategySnapshot(topology);
        if (rollbackSnapshot?.orchestratorRules) {
            const freezeUntilIso = new Date(Date.now() + adaptivePolicy.freezeMinutes * 60_000).toISOString();
            await memoryStore.updateTeamTopology(params.topologyId, {
                orchestratorRules: rollbackSnapshot.orchestratorRules ?? null,
                adaptiveModelPolicy: rollbackSnapshot.adaptiveModelPolicy ?? null,
                modelRoutes: rollbackSnapshot.modelRoutes ?? null,
                metadata: {
                    ...baseMetadata,
                    lastOrchAdaptedAt: metrics.computedAt,
                    lastOrchMetrics: metrics,
                    lastOrchAction: 'rollback',
                    lastOrchHealth: 'degraded',
                    orchDegradedStreak: 0,
                    lastOrchRollbackAt: metrics.computedAt,
                    lastOrchRollbackFromVersion: topology.strategyVersion ?? 1,
                    lastOrchRollbackToVersion: rollbackSnapshot.version,
                    lastOrchRollbackReason: 'Adaptive orchestrator rollback triggered by sustained unhealthy swarm metrics',
                    lastOrchFrozenUntil: freezeUntilIso,
                    lastOrchFreezeReason: 'Automatic rollback freeze after sustained unhealthy swarm metrics',
                },
            });
            log.warn({
                topologyId: params.topologyId,
                workspaceId: params.workspaceId,
                fromVersion: topology.strategyVersion ?? 1,
                toVersion: rollbackSnapshot.version,
                metrics,
            }, 'Adaptive orchestrator rollback applied after sustained unhealthy metrics');
            return rollbackSnapshot.orchestratorRules;
        }
    }
    if (Number.isFinite(frozenUntil) && Date.now() < frozenUntil) {
        await memoryStore.updateTeamTopology(params.topologyId, {
            metadata: {
                ...baseMetadata,
                lastOrchMetrics: metrics,
                lastOrchHealth: severeRegression ? 'degraded' : 'healthy',
                orchDegradedStreak: degradedStreak,
            },
        });
        return null;
    }
    const lastAdaptedAt = typeof baseMetadata['lastOrchAdaptedAt'] === 'string'
        ? Date.parse(baseMetadata['lastOrchAdaptedAt'])
        : Number.NaN;
    if (Number.isFinite(lastAdaptedAt)
        && Date.now() - lastAdaptedAt < ADAPTATION_COOLDOWN_MINUTES * 60_000) {
        await memoryStore.updateTeamTopology(params.topologyId, {
            metadata: {
                ...baseMetadata,
                lastOrchMetrics: metrics,
                lastOrchHealth: severeRegression ? 'degraded' : 'healthy',
                orchDegradedStreak: degradedStreak,
            },
        });
        return null;
    }
    const updated = adaptRulesFromMetrics(params.currentRules, metrics);
    if (!updated) {
        await memoryStore.updateTeamTopology(params.topologyId, {
            metadata: {
                ...baseMetadata,
                lastOrchAdaptedAt: metrics.computedAt,
                lastOrchMetrics: metrics,
                lastOrchAction: 'observe',
                lastOrchHealth: severeRegression ? 'degraded' : 'healthy',
                orchDegradedStreak: degradedStreak,
            },
        });
        return null;
    }
    await memoryStore.updateTeamTopology(params.topologyId, {
        orchestratorRules: updated,
        metadata: {
            ...baseMetadata,
            lastOrchAdaptedAt: metrics.computedAt,
            lastOrchMetrics: metrics,
            lastOrchAction: 'adapt',
            lastOrchHealth: severeRegression ? 'degraded' : 'healthy',
            orchDegradedStreak: degradedStreak,
        },
    });
    log.info({ topologyId: params.topologyId, workspaceId: params.workspaceId, metrics }, 'Orchestrator rules adapted based on swarm metrics with versioned persistence');
    return updated;
}
async function adaptTopologyModels(params) {
    const topology = await memoryStore.getTeamTopology(params.topologyId);
    if (!topology)
        return null;
    const policy = parseAdaptiveModelPolicy(topology.metadata?.['adaptiveModelPolicy']);
    if (!policy)
        return null;
    const metrics = computeSwarmMetrics(params.tasks, params.topologyId);
    if (!metrics)
        return null;
    const lastAdaptedAt = typeof topology.metadata?.['lastAdaptiveModelAt'] === 'string'
        ? Date.parse(topology.metadata['lastAdaptiveModelAt'])
        : Number.NaN;
    if (Number.isFinite(lastAdaptedAt)
        && Date.now() - lastAdaptedAt < policy.cooldownMinutes * 60_000) {
        return null;
    }
    const currentState = topology.metadata?.['adaptiveModelState'] === 'promoted' ? 'promoted' : 'baseline';
    const action = decideAdaptiveModelAction(currentState, metrics, policy);
    if (!action) {
        await memoryStore.updateTeamTopology(params.topologyId, {
            metadata: {
                ...topology.metadata,
                lastAdaptiveModelAt: metrics.computedAt,
                lastAdaptiveModelMetrics: metrics,
            },
        });
        return null;
    }
    const agentIds = [...new Set([
            ...(topology.workerAgentIds ?? []),
            topology.supervisorAgentId ?? '',
        ].filter(Boolean))];
    if (agentIds.length === 0)
        return null;
    const originals = topology.metadata?.['adaptiveModelOriginals'] && typeof topology.metadata['adaptiveModelOriginals'] === 'object' && !Array.isArray(topology.metadata['adaptiveModelOriginals'])
        ? { ...topology.metadata['adaptiveModelOriginals'] }
        : {};
    for (const agentId of agentIds) {
        const agent = await memoryStore.getAgent(agentId);
        if (!agent)
            continue;
        if (!originals[agentId]) {
            originals[agentId] = {
                provider: agent.provider ?? null,
                model: agent.model ?? null,
            };
        }
        const target = action === 'promote'
            ? {
                provider: policy.promotedProvider ?? agent.provider ?? null,
                model: policy.promotedModel ?? agent.model ?? null,
            }
            : {
                provider: policy.revertProvider ?? originals[agentId]?.provider ?? agent.provider ?? null,
                model: policy.revertModel ?? originals[agentId]?.model ?? agent.model ?? null,
            };
        if (agent.provider === target.provider && agent.model === target.model)
            continue;
        await memoryStore.updateAgent(agentId, {
            provider: target.provider,
            model: target.model,
            metadata: {
                ...(agent.metadata ?? {}),
                adaptiveModelTopologyId: params.topologyId,
                adaptiveModelState: action === 'promote' ? 'promoted' : 'baseline',
                adaptiveModelUpdatedAt: metrics.computedAt,
            },
        });
    }
    await memoryStore.updateTeamTopology(params.topologyId, {
        metadata: {
            ...topology.metadata,
            adaptiveModelState: action === 'promote' ? 'promoted' : 'baseline',
            adaptiveModelOriginals: originals,
            lastAdaptiveModelAt: metrics.computedAt,
            lastAdaptiveModelMetrics: metrics,
            lastAdaptiveModelAction: action,
        },
    });
    log.info({
        topologyId: params.topologyId,
        workspaceId: params.workspaceId,
        action,
        challengeSuccessRate: metrics.challengeSuccessRate,
        challengedTaskCount: metrics.challengedTaskCount,
    }, 'Adaptive topology model update applied');
    return action;
}
async function adaptCandidateRollout(params) {
    const topology = await memoryStore.getTeamTopology(params.topologyId);
    if (!topology?.candidateStrategy)
        return null;
    const policy = parseTeamTopologyCandidateRolloutPolicy(topology.metadata?.['candidateRolloutPolicy']);
    if (!policy)
        return null;
    const control = topology.candidateRolloutControl ?? parseTeamTopologyCandidateRolloutControl(topology.metadata?.['candidateRolloutControl']);
    if (control && (!control.enabled || control.frozen))
        return null;
    const metrics = computeStrategyTrackSwarmMetrics(params.tasks, params.topologyId, 'candidate');
    if (!metrics)
        return null;
    const lastAdaptedAt = typeof topology.metadata?.['lastCandidateRolloutAt'] === 'string'
        ? Date.parse(topology.metadata['lastCandidateRolloutAt'])
        : Number.NaN;
    if (Number.isFinite(lastAdaptedAt)
        && Date.now() - lastAdaptedAt < policy.cooldownMinutes * 60_000) {
        return null;
    }
    const action = decideCandidateRolloutAction(topology.candidateStrategy.rolloutPercent, metrics, policy);
    const baseMetadata = {
        ...(topology.metadata ?? {}),
        lastCandidateRolloutAt: metrics.computedAt,
        lastCandidateRolloutMetrics: metrics,
    };
    if (!action) {
        await memoryStore.updateTeamTopology(params.topologyId, {
            metadata: appendCandidateRolloutAuditEvent({
                ...baseMetadata,
                lastCandidateRolloutAction: 'observe',
                lastCandidateRolloutPercent: topology.candidateStrategy.rolloutPercent,
            }, {
                action: 'observe',
                at: metrics.computedAt,
                actor: 'system',
                fromRolloutPercent: topology.candidateStrategy.rolloutPercent,
                toRolloutPercent: topology.candidateStrategy.rolloutPercent,
                candidateVersion: topology.candidateStrategy.version,
                stableVersion: topology.strategyVersion ?? 1,
                metrics: metrics,
            }),
        });
        return null;
    }
    if (action.action === 'promote') {
        if (control?.requirePromotionApproval) {
            const approvalTask = await ensureCandidatePromotionApprovalTask({
                topology,
                control,
                metrics,
                proposedRolloutPercent: action.nextRolloutPercent,
            });
            await memoryStore.updateTeamTopology(params.topologyId, {
                metadata: approvalTask?.approvalCreated
                    ? appendCandidateRolloutAuditEvent({
                        ...baseMetadata,
                        lastCandidateRolloutAction: 'await_approval',
                        lastCandidateRolloutPercent: topology.candidateStrategy.rolloutPercent,
                        pendingCandidatePromotionTaskId: approvalTask.taskId,
                        pendingCandidatePromotionApprovalId: approvalTask.approvalId,
                    }, {
                        action: 'approval_requested',
                        at: metrics.computedAt,
                        actor: 'system',
                        reason: 'Automatic candidate promotion is awaiting approval',
                        fromRolloutPercent: topology.candidateStrategy.rolloutPercent,
                        toRolloutPercent: action.nextRolloutPercent,
                        candidateVersion: topology.candidateStrategy.version,
                        stableVersion: topology.strategyVersion ?? 1,
                        metrics: metrics,
                    })
                    : {
                        ...baseMetadata,
                        lastCandidateRolloutAction: 'await_approval',
                        lastCandidateRolloutPercent: topology.candidateStrategy.rolloutPercent,
                        pendingCandidatePromotionTaskId: approvalTask?.taskId ?? null,
                        pendingCandidatePromotionApprovalId: approvalTask?.approvalId ?? null,
                    },
            });
            return null;
        }
        const promotion = buildPromoteCandidateStrategyUpdates(topology);
        if (!promotion)
            return null;
        await memoryStore.updateTeamTopology(params.topologyId, {
            ...promotion.updates,
            metadata: appendCandidateRolloutAuditEvent({
                ...baseMetadata,
                lastCandidateRolloutAction: 'promote',
                lastCandidateRolloutPercent: action.nextRolloutPercent,
                lastCandidatePromotionVersion: promotion.candidate.version,
            }, {
                action: 'promote',
                at: metrics.computedAt,
                actor: 'system',
                fromRolloutPercent: topology.candidateStrategy.rolloutPercent,
                toRolloutPercent: action.nextRolloutPercent,
                candidateVersion: promotion.candidate.version,
                stableVersion: (topology.strategyVersion ?? 1) + 1,
                metrics: metrics,
            }),
        });
        log.info({ topologyId: params.topologyId, workspaceId: params.workspaceId, metrics }, 'Adaptive candidate rollout promoted candidate to stable');
        return 'promote';
    }
    await memoryStore.updateTeamTopology(params.topologyId, {
        candidateStrategy: {
            ...topology.candidateStrategy,
            rolloutPercent: action.nextRolloutPercent,
        },
        metadata: appendCandidateRolloutAuditEvent({
            ...baseMetadata,
            lastCandidateRolloutAction: action.action,
            lastCandidateRolloutPercent: action.nextRolloutPercent,
        }, {
            action: action.action,
            at: metrics.computedAt,
            actor: 'system',
            fromRolloutPercent: topology.candidateStrategy.rolloutPercent,
            toRolloutPercent: action.nextRolloutPercent,
            candidateVersion: topology.candidateStrategy.version,
            stableVersion: topology.strategyVersion ?? 1,
            metrics: metrics,
        }),
    });
    log.info({
        topologyId: params.topologyId,
        workspaceId: params.workspaceId,
        action: action.action,
        nextRolloutPercent: action.nextRolloutPercent,
        metrics,
    }, 'Adaptive candidate rollout updated canary percentage');
    return action.action;
}
//# sourceMappingURL=orchestrator.js.map