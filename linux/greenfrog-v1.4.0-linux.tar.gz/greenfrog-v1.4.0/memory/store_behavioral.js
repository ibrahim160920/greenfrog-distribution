import { nanoid } from 'nanoid';
function normalizeScope(scope) {
    return {
        userId: scope.userId,
        channel: scope.channel,
        workspaceId: scope.workspaceId ?? '',
        agentId: scope.agentId ?? '',
    };
}
function mapBehavioralRuleHistoryRow(row) {
    return {
        id: row['id'],
        userId: row['user_id'],
        channel: row['channel'],
        workspaceId: row['workspace_id'] || null,
        agentId: (row['agent_id'] || null),
        rule: row['rule'],
        action: row['action'],
        relatedHistoryId: row['related_history_id'] || null,
        oldCategory: row['old_category'] || null,
        oldConfidence: row['old_confidence'] === null || row['old_confidence'] === undefined ? null : Number(row['old_confidence']),
        oldSource: row['old_source'] || null,
        oldEvidenceCount: row['old_evidence_count'] === null || row['old_evidence_count'] === undefined ? null : Number(row['old_evidence_count']),
        newCategory: row['new_category'] || null,
        newConfidence: row['new_confidence'] === null || row['new_confidence'] === undefined ? null : Number(row['new_confidence']),
        newSource: row['new_source'] || null,
        newEvidenceCount: row['new_evidence_count'] === null || row['new_evidence_count'] === undefined ? null : Number(row['new_evidence_count']),
        createdAt: new Date(row['created_at']),
    };
}
export function createBehavioralStore(db) {
    const api = {
        saveInteractionFeedback(opts) {
            return api.saveScopedInteractionFeedback({ userId: opts.userId, channel: opts.channel }, {
                sessionId: opts.sessionId,
                userMessage: opts.userMessage,
                aiResponse: opts.aiResponse,
                feedbackType: opts.feedbackType,
                signal: opts.signal,
                score: opts.score,
            });
        },
        saveScopedInteractionFeedback(scope, opts) {
            const normalized = normalizeScope(scope);
            db.prepare(`INSERT INTO interaction_feedback
         (id, user_id, channel, workspace_id, agent_id, session_id, user_message, ai_response, feedback_type, signal, score, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, opts.sessionId, opts.userMessage.slice(0, 500), opts.aiResponse.slice(0, 800), opts.feedbackType, opts.signal ?? null, opts.score, Date.now());
        },
        getRecentFeedback(userId, channel, limit = 50) {
            return api.getRecentScopedFeedback({ userId, channel }, limit);
        },
        getRecentScopedFeedback(scope, limit = 50) {
            const normalized = normalizeScope(scope);
            const rows = db.prepare(`SELECT id, user_message, ai_response, feedback_type, signal, score, created_at
         FROM interaction_feedback WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?
         ORDER BY created_at DESC LIMIT ?`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit);
            return rows.map((r) => ({
                id: r['id'],
                userMessage: r['user_message'],
                aiResponse: r['ai_response'],
                feedbackType: r['feedback_type'],
                signal: r['signal'],
                score: r['score'],
                createdAt: new Date(r['created_at']),
            }));
        },
        getFeedbackStats(userId, channel) {
            return api.getScopedFeedbackStats({ userId, channel });
        },
        getScopedFeedbackStats(scope) {
            const normalized = normalizeScope(scope);
            const row = db.prepare(`SELECT COUNT(*) as total,
                SUM(CASE WHEN score > 0 THEN 1 ELSE 0 END) as positive,
                SUM(CASE WHEN score < 0 THEN 1 ELSE 0 END) as negative,
                AVG(score) as avg_score
         FROM interaction_feedback WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?`).get(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId);
            return {
                total: row?.total ?? 0,
                positive: row?.positive ?? 0,
                negative: row?.negative ?? 0,
                avgScore: row?.avg_score ?? 0,
            };
        },
        upsertBehavioralRule(opts) {
            return api.upsertScopedBehavioralRule({ userId: opts.userId, channel: opts.channel }, {
                rule: opts.rule,
                category: opts.category,
                confidence: opts.confidence,
                source: opts.source,
            });
        },
        recordScopedBehavioralRuleHistory(scope, entry) {
            const normalized = normalizeScope(scope);
            db.prepare(`INSERT INTO behavioral_rule_history (
          id, user_id, channel, workspace_id, agent_id, rule, action, related_history_id,
          old_category, old_confidence, old_source, old_evidence_count,
          new_category, new_confidence, new_source, new_evidence_count, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, entry.rule, entry.action, entry.relatedHistoryId ?? null, entry.oldCategory ?? null, entry.oldConfidence ?? null, entry.oldSource ?? null, entry.oldEvidenceCount ?? null, entry.newCategory ?? null, entry.newConfidence ?? null, entry.newSource ?? null, entry.newEvidenceCount ?? null, Date.now());
        },
        getScopedBehavioralRuleRecord(scope, rule) {
            const normalized = normalizeScope(scope);
            return db.prepare(`SELECT id, category, confidence, source, evidence_count FROM behavioral_rules
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND rule = ?`).get(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, rule);
        },
        putScopedBehavioralRuleExact(scope, params) {
            const normalized = normalizeScope(scope);
            const existing = api.getScopedBehavioralRuleRecord(scope, params.rule);
            const now = Date.now();
            if (existing) {
                db.prepare(`UPDATE behavioral_rules
           SET category = ?, confidence = ?, source = ?, evidence_count = ?, updated_at = ?
           WHERE id = ?`).run(params.category, params.confidence, params.source, params.evidenceCount, now, existing.id);
            }
            else {
                db.prepare(`INSERT INTO behavioral_rules (id, user_id, channel, workspace_id, agent_id, rule, category, confidence, source, evidence_count, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, params.rule, params.category, params.confidence, params.source, params.evidenceCount, now, now);
            }
        },
        upsertScopedBehavioralRule(scope, opts) {
            const normalized = normalizeScope(scope);
            const now = Date.now();
            const existing = api.getScopedBehavioralRuleRecord(scope, opts.rule);
            if (existing) {
                const newConf = Math.min(100, Math.round((existing.confidence + opts.confidence) / 2 + 5));
                const newEvidenceCount = existing.evidence_count + 1;
                db.prepare(`UPDATE behavioral_rules
           SET category = ?, confidence = ?, source = ?, evidence_count = ?, updated_at = ?
           WHERE id = ?`).run(opts.category, newConf, opts.source, newEvidenceCount, now, existing.id);
                api.recordScopedBehavioralRuleHistory(scope, {
                    rule: opts.rule,
                    action: 'update',
                    oldCategory: existing.category,
                    oldConfidence: existing.confidence,
                    oldSource: existing.source,
                    oldEvidenceCount: existing.evidence_count,
                    newCategory: opts.category,
                    newConfidence: newConf,
                    newSource: opts.source,
                    newEvidenceCount,
                });
            }
            else {
                db.prepare(`INSERT INTO behavioral_rules (id, user_id, channel, workspace_id, agent_id, rule, category, confidence, source, evidence_count, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`).run(nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, opts.rule, opts.category, opts.confidence, opts.source, now, now);
                api.recordScopedBehavioralRuleHistory(scope, {
                    rule: opts.rule,
                    action: 'insert',
                    newCategory: opts.category,
                    newConfidence: opts.confidence,
                    newSource: opts.source,
                    newEvidenceCount: 1,
                });
            }
        },
        getBehavioralRules(userId, channel, minConfidence = 40) {
            return api.getScopedBehavioralRules({ userId, channel }, minConfidence);
        },
        getScopedBehavioralRules(scope, minConfidence = 40) {
            const normalized = normalizeScope(scope);
            const rows = db.prepare(`SELECT rule, category, confidence, source, evidence_count FROM behavioral_rules
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND confidence >= ?
         ORDER BY confidence DESC, evidence_count DESC`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, minConfidence);
            return rows.map((r) => ({
                rule: r['rule'],
                category: r['category'],
                confidence: r['confidence'],
                source: r['source'],
                evidenceCount: r['evidence_count'],
            }));
        },
        getBehavioralRuleHistory(userId, channel, limit = 50) {
            return api.getScopedBehavioralRuleHistory({ userId, channel }, limit);
        },
        getScopedBehavioralRuleHistory(scope, limit = 50) {
            const normalized = normalizeScope(scope);
            const rows = db.prepare(`SELECT * FROM behavioral_rule_history
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?
         ORDER BY created_at DESC
         LIMIT ?`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit);
            return rows.map(mapBehavioralRuleHistoryRow);
        },
        rollbackBehavioralRuleHistory(userId, channel, historyId, source = 'manual') {
            return api.rollbackScopedBehavioralRuleHistory({ userId, channel }, historyId, source);
        },
        rollbackScopedBehavioralRuleHistory(scope, historyId, source = 'manual') {
            void source;
            const normalized = normalizeScope(scope);
            const row = db.prepare(`SELECT * FROM behavioral_rule_history
         WHERE id = ? AND user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?`).get(historyId, normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId);
            if (!row)
                return false;
            const entry = mapBehavioralRuleHistoryRow(row);
            const current = api.getScopedBehavioralRuleRecord(scope, entry.rule);
            if (entry.action === 'insert') {
                if (!current)
                    return false;
                db.prepare(`DELETE FROM behavioral_rules
           WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND rule = ?`).run(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, entry.rule);
                api.recordScopedBehavioralRuleHistory(scope, {
                    rule: entry.rule,
                    action: 'rollback',
                    relatedHistoryId: historyId,
                    oldCategory: current.category,
                    oldConfidence: current.confidence,
                    oldSource: current.source,
                    oldEvidenceCount: current.evidence_count,
                    newCategory: null,
                    newConfidence: null,
                    newSource: null,
                    newEvidenceCount: null,
                });
                return true;
            }
            if (!entry.oldCategory || entry.oldConfidence === null || entry.oldConfidence === undefined || !entry.oldSource || entry.oldEvidenceCount === null || entry.oldEvidenceCount === undefined) {
                return false;
            }
            api.putScopedBehavioralRuleExact(scope, {
                rule: entry.rule,
                category: entry.oldCategory,
                confidence: entry.oldConfidence,
                source: entry.oldSource,
                evidenceCount: entry.oldEvidenceCount,
            });
            api.recordScopedBehavioralRuleHistory(scope, {
                rule: entry.rule,
                action: 'rollback',
                relatedHistoryId: historyId,
                oldCategory: current?.category ?? null,
                oldConfidence: current?.confidence ?? null,
                oldSource: current?.source ?? null,
                oldEvidenceCount: current?.evidence_count ?? null,
                newCategory: entry.oldCategory,
                newConfidence: entry.oldConfidence,
                newSource: entry.oldSource,
                newEvidenceCount: entry.oldEvidenceCount,
            });
            return true;
        },
        deleteBehavioralRule(userId, channel, rule) {
            return api.deleteScopedBehavioralRule({ userId, channel }, rule);
        },
        deleteScopedBehavioralRule(scope, rule) {
            const normalized = normalizeScope(scope);
            const existing = api.getScopedBehavioralRuleRecord(scope, rule);
            if (!existing)
                return false;
            const result = db.prepare(`DELETE FROM behavioral_rules
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND rule = ?`).run(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, rule);
            if (result.changes > 0) {
                api.recordScopedBehavioralRuleHistory(scope, {
                    rule,
                    action: 'delete',
                    oldCategory: existing.category,
                    oldConfidence: existing.confidence,
                    oldSource: existing.source,
                    oldEvidenceCount: existing.evidence_count,
                });
                return true;
            }
            return false;
        },
        bulkReplaceScopedBehavioralRules(scope, rules) {
            const normalized = normalizeScope(scope);
            const now = Date.now();
            db.transaction(() => {
                db.prepare(`DELETE FROM behavioral_rules
           WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?`).run(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId);
                for (const r of rules) {
                    db.prepare(`INSERT INTO behavioral_rules (id, user_id, channel, workspace_id, agent_id, rule, category, confidence, source, evidence_count, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`).run(nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, r.rule, r.category, r.confidence, r.source, now, now);
                }
            })();
        },
        listBehavioralRuleScopes(limit = 200) {
            const rows = db.prepare(`SELECT user_id, channel, workspace_id, agent_id, COUNT(*) AS rule_count, MAX(updated_at) AS latest_updated_at
         FROM behavioral_rules
         GROUP BY user_id, channel, workspace_id, agent_id
         ORDER BY rule_count DESC, latest_updated_at DESC
         LIMIT ?`).all(limit);
            return rows.map((row) => ({
                userId: String(row['user_id']),
                channel: row['channel'],
                ...(String(row['workspace_id'] ?? '') ? { workspaceId: String(row['workspace_id']) } : {}),
                ...(String(row['agent_id'] ?? '') ? { agentId: String(row['agent_id']) } : {}),
                ruleCount: Number(row['rule_count'] ?? 0),
                latestUpdatedAt: row['latest_updated_at'] ? new Date(Number(row['latest_updated_at'])) : null,
            }));
        },
        decayScopedBehavioralRules(scope, opts) {
            const normalized = normalizeScope(scope);
            const staleAfterDays = Math.max(1, Math.floor(opts?.staleAfterDays ?? 30));
            const deleteAfterDays = Math.max(staleAfterDays, Math.floor(opts?.deleteAfterDays ?? 90));
            const lowEvidenceThreshold = Math.max(1, Math.floor(opts?.lowEvidenceThreshold ?? 1));
            const decayStep = Math.max(1, Math.floor(opts?.decayStep ?? 5));
            const floorConfidence = Math.max(0, Math.min(100, Math.floor(opts?.floorConfidence ?? 35)));
            const staleCutoff = Date.now() - staleAfterDays * 24 * 3600 * 1000;
            const deleteCutoff = Date.now() - deleteAfterDays * 24 * 3600 * 1000;
            const rows = db.prepare(`SELECT rule, category, confidence, source, evidence_count, updated_at
         FROM behavioral_rules
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?
           AND updated_at <= ? AND evidence_count <= ? AND source != ?`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, staleCutoff, lowEvidenceThreshold, 'library');
            let updated = 0;
            let deleted = 0;
            for (const row of rows) {
                const rule = String(row['rule']);
                const category = String(row['category']);
                const confidence = Number(row['confidence'] ?? 0);
                const source = String(row['source'] ?? 'decayed');
                const evidenceCount = Number(row['evidence_count'] ?? 1);
                const updatedAt = Number(row['updated_at'] ?? Date.now());
                if (updatedAt <= deleteCutoff && confidence <= floorConfidence) {
                    if (api.deleteScopedBehavioralRule(scope, rule))
                        deleted += 1;
                    continue;
                }
                const nextConfidence = Math.max(floorConfidence, confidence - decayStep);
                if (nextConfidence === confidence)
                    continue;
                api.putScopedBehavioralRuleExact(scope, {
                    rule,
                    category,
                    confidence: nextConfidence,
                    source: source === 'compressed' ? 'compressed' : 'decayed',
                    evidenceCount,
                });
                api.recordScopedBehavioralRuleHistory(scope, {
                    rule,
                    action: 'update',
                    oldCategory: category,
                    oldConfidence: confidence,
                    oldSource: source,
                    oldEvidenceCount: evidenceCount,
                    newCategory: category,
                    newConfidence: nextConfidence,
                    newSource: source === 'compressed' ? 'compressed' : 'decayed',
                    newEvidenceCount: evidenceCount,
                });
                updated += 1;
            }
            return { updated, deleted };
        },
        summarizeBehavioralRules() {
            const staleCutoff = Date.now() - 30 * 24 * 3600 * 1000;
            const row = db.prepare(`SELECT
           COUNT(*) AS total_rules,
           SUM(CASE WHEN source = 'compressed' THEN 1 ELSE 0 END) AS compressed_rules,
           AVG(confidence) AS avg_confidence,
           SUM(CASE WHEN confidence < 50 THEN 1 ELSE 0 END) AS low_confidence_rules,
           SUM(CASE WHEN updated_at <= ? THEN 1 ELSE 0 END) AS stale_rules,
           COUNT(DISTINCT user_id || '::' || channel || '::' || workspace_id || '::' || agent_id) AS distinct_scopes
         FROM behavioral_rules`).get(staleCutoff);
            return {
                totalRules: Number(row?.['total_rules'] ?? 0),
                compressedRules: Number(row?.['compressed_rules'] ?? 0),
                avgConfidence: Number(Number(row?.['avg_confidence'] ?? 0).toFixed(1)),
                lowConfidenceRules: Number(row?.['low_confidence_rules'] ?? 0),
                staleRules: Number(row?.['stale_rules'] ?? 0),
                distinctScopes: Number(row?.['distinct_scopes'] ?? 0),
            };
        },
    };
    return api;
}
//# sourceMappingURL=store_behavioral.js.map