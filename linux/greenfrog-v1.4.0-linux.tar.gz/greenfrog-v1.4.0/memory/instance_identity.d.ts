/**
 * instance_identity.ts — Stable Persistent Instance Identity
 *
 * Replaces the hardware-fingerprint-based generateInstanceId() with a stable
 * identity that:
 *   1. Is generated once (random, not hardware-derived)
 *   2. Persisted to {dataDir}/instance_id.json
 *   3. Reused on every restart, upgrade, or process restart
 *   4. Does not expose sensitive machine information (no hostname, no MAC)
 *
 * Governance meaning of identity change:
 *   - If the instance_id.json file is deleted, a new identity is generated.
 *   - The mother-body will treat this as a NEW instance (evidence provenance
 *     will not be aggregated with the old identity's contributions).
 *   - This is intentional: identity reset = fresh start in the federation.
 *
 * Override:
 *   - GF_INSTANCE_ID_FILE — override path to instance_id.json
 */
export interface InstanceIdRecord {
    /** Stable instance identifier — 'gf-' prefix + 32 hex chars */
    instanceId: string;
    /** ISO timestamp of first generation */
    createdAt: string;
    /** Schema version */
    version: 1;
}
/**
 * Resolve the path to the instance ID file.
 * GF_INSTANCE_ID_FILE overrides the default location.
 */
export declare function resolveInstanceIdFilePath(dataDir: string): string;
/**
 * Read an existing instance ID record from disk.
 * Returns null if the file does not exist or is invalid.
 */
export declare function readInstanceIdRecord(dataDir: string): InstanceIdRecord | null;
/**
 * Generate a new random instance ID and persist it to disk.
 * Idempotent if the file already exists and is valid — returns the existing ID.
 */
export declare function generateNewInstanceId(dataDir: string): string;
/**
 * Get or create the stable instance ID for this GreenFrog instance.
 *
 * - First call: generates a random ID and persists it to {dataDir}/instance_id.json
 * - Subsequent calls (same process OR after restart): reads from disk
 *
 * This is the canonical entry point for obtaining instance identity.
 * All federated evidence should use this ID.
 */
export declare function getOrCreateInstanceId(dataDir: string): string;
/**
 * Cached variant — resolves once per process lifetime.
 * Safe to call from hot paths (e.g. per-task evidence recording).
 */
export declare function getCachedInstanceId(dataDir: string): string;
/**
 * Reset the in-process cache.
 * Used in tests to simulate process restarts with a fresh dataDir.
 */
export declare function resetInstanceIdCache(): void;
//# sourceMappingURL=instance_identity.d.ts.map