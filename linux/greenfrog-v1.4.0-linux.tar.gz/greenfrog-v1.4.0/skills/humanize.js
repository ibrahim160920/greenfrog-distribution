/**
 * Humanize Skill — 去AI味，让文字更像真人写的
 *
 * AI写作的典型病症（逐条处理）：
 *   1. 套话连接词      — "首先/其次/再次/最后"、"值得注意的是"、"综上所述"
 *   2. 空洞排比堆砌    — "不仅...而且...更..."、三段式列举
 *   3. 过度强调感叹    — "！！"、"非常非常"、"极其重要"
 *   4. 结尾升华        — "让我们共同努力"、"这正是X的意义所在"
 *   5. 被动句/长难句   — "通过X，我们可以Y，从而实现Z"
 *   6. 假装客观的模糊  — "可能"、"或许"、"在某种程度上"堆叠
 *   7. 段落首句公式化  — 每段都是"在XX领域/背景下，..."
 */
import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
// 最大输入字符数（防止 token 爆炸）
const MAX_INPUT = 3000;
// 分块大小（超长文章分块处理）
const CHUNK_SIZE = 1500;
// ─── 场景对应的改写风格指令 ────────────────────────────────────────────────────
const STYLE_PROMPTS = {
    moments: '改写成朋友圈风格：短句、口语、有点随意但不失真实感。可以有情绪，不用讲道理。去掉所有说教感。',
    article: '改写成个人文章风格：有观点有温度，像一个真实的人在说话，不是在做汇报。保留逻辑但去掉官腔。',
    casual: '改写成日常对话风格：随意、自然，像发微信消息给朋友一样，不用字斟句酌。',
    formal: '改写成正式但不生硬的风格：专业感保留，但去掉空话套话，每句话都要有实际内容。',
    xiaohongshu: '改写成小红书风格：真实体验感，有点个人情绪，可以用一些生活化的词，但别加无意义的emoji堆砌。',
};
// ─── 核心提示词 ────────────────────────────────────────────────────────────────
function buildPrompt(text, style, extra) {
    const styleGuide = STYLE_PROMPTS[style] ?? STYLE_PROMPTS.casual;
    return `你是一个专门去除AI腔调的编辑。任务：把下面这段文字改写得更像真人写的。

**${styleGuide}**

必须做到的改动：
- 删掉所有"首先/其次/再次/最后"式的连接词套路（如果有逻辑顺序可以保留，但换个说法）
- 删掉"值得注意的是"、"值得一提的是"、"综上所述"、"总的来说"、"不言而喻"等罐头句式
- 删掉"让我们一起"、"共同努力"、"这正是X的意义所在"式的结尾升华
- 删掉空洞的排比堆砌（三个"不仅...而且...更..."连用那种）
- 把长难句拆短，别用一句话塞五个逗号
- 去掉假装客观的模糊词堆叠（"可能在某种程度上或许..."）
- 语气要有立场，不要四平八稳什么都"需要辩证看待"

不要做的：
- 不要改变核心意思和事实
- 不要加emoji（除非原文有）
- 不要把文章变短很多（内容要保留，只是换说法）
- 不要加你自己的评价或解释

${extra ? `用户额外要求：${extra}\n` : ''}原文：
---
${text}
---

直接输出改写后的文字，不要加任何说明或前缀。`;
}
// ─── 技能主类 ──────────────────────────────────────────────────────────────────
export class HumanizeSkill extends BaseSkill {
    definition = {
        name: 'humanize',
        description: '去AI味：把AI生成的文字改写得更像真人说话，消除套话、空洞排比、结尾升华、首先其次最后等AI腔调。' +
            '适合发朋友圈、写公众号文章、小红书、日常对话前过一遍。',
        category: 'writing',
        parameters: [
            {
                name: 'text',
                type: 'string',
                required: true,
                description: '要去AI味的文字内容',
            },
            {
                name: 'style',
                type: 'string',
                description: '目标风格',
                enum: ['casual', 'moments', 'article', 'formal', 'xiaohongshu'],
                default: 'casual',
            },
            {
                name: 'instruction',
                type: 'string',
                description: '额外要求，例如"保留专业术语"、"语气要更犀利"、"控制在200字以内"',
            },
        ],
        examples: [
            '帮我把这段AI写的内容去掉AI味：[粘贴文字]',
            '这段朋友圈文案太AI了，帮我改一下 style=moments',
            '把这篇文章改得更像真人写的，不要那么多套话',
        ],
    };
    async execute(params, _ctx) {
        const text = (params.text ?? '').trim();
        const style = (params.style ?? 'casual').trim();
        const instruction = (params.instruction ?? '').trim();
        if (!text)
            return this.err('text 不能为空');
        if (text.length > MAX_INPUT) {
            return this.err(`文字太长（${text.length} 字），请控制在 ${MAX_INPUT} 字以内，或分段处理`);
        }
        try {
            let result;
            if (text.length <= CHUNK_SIZE) {
                result = await this.rewrite(text, style, instruction);
            }
            else {
                // 超长时分块改写再合并
                result = await this.rewriteInChunks(text, style, instruction);
            }
            const reduction = text.length - result.length;
            const note = reduction > 50
                ? `\n\n---\n*已压缩 ${reduction} 字（原 ${text.length} 字 → 改后 ${result.length} 字）*`
                : '';
            return this.text(result + note);
        }
        catch (err) {
            return this.err(`改写失败: ${String(err)}`);
        }
    }
    async rewrite(text, style, instruction) {
        const prompt = buildPrompt(text, style, instruction);
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: prompt }],
            maxTokens: 2000,
            temperature: 0.7, // 稍高一点，让改写更有变化感
        });
        return (res.content ?? '').trim();
    }
    async rewriteInChunks(text, style, instruction) {
        // 按段落切分，尽量保持段落完整
        const paragraphs = text.split(/\n{2,}/);
        const chunks = [];
        let current = '';
        for (const para of paragraphs) {
            if ((current + '\n\n' + para).length > CHUNK_SIZE && current) {
                chunks.push(current.trim());
                current = para;
            }
            else {
                current = current ? current + '\n\n' + para : para;
            }
        }
        if (current.trim())
            chunks.push(current.trim());
        const results = await Promise.all(chunks.map((chunk) => this.rewrite(chunk, style, instruction)));
        return results.join('\n\n');
    }
}
//# sourceMappingURL=humanize.js.map