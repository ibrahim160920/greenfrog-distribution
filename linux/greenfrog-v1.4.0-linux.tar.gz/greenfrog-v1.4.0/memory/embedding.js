/**
 * Embedding generation for semantic memory search.
 * Tries Ollama's embedding API first (local, private), then OpenAI text-embedding-3-small.
 * Falls back to a local hashing-trick embedding if neither external service is available.
 */
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('embedding');
const EMBEDDING_WARNING_COOLDOWN_MS = 5 * 60_000;
function createInitialEmbeddingRuntimeState() {
    return {
        mode: 'uninitialized',
        degraded: false,
        ollamaSuccesses: 0,
        openaiSuccesses: 0,
        localHashFallbacks: 0,
        lastSuccessAt: null,
        lastDegradedAt: null,
        lastFallbackReason: null,
        lastWarning: null,
        lastWarnedAtMs: 0,
    };
}
const embeddingRuntimeState = createInitialEmbeddingRuntimeState();
function markEmbeddingHealthy(mode) {
    embeddingRuntimeState.mode = mode;
    embeddingRuntimeState.degraded = false;
    embeddingRuntimeState.lastSuccessAt = new Date().toISOString();
    embeddingRuntimeState.lastWarning = null;
    if (mode === 'ollama')
        embeddingRuntimeState.ollamaSuccesses += 1;
    if (mode === 'openai')
        embeddingRuntimeState.openaiSuccesses += 1;
}
function markEmbeddingDegraded(reason) {
    embeddingRuntimeState.mode = 'local_hash';
    embeddingRuntimeState.degraded = true;
    embeddingRuntimeState.localHashFallbacks += 1;
    embeddingRuntimeState.lastDegradedAt = new Date().toISOString();
    embeddingRuntimeState.lastFallbackReason = reason;
    embeddingRuntimeState.lastWarning =
        `Semantic memory degraded to local hashing-trick embeddings: ${reason}. Semantic search quality is reduced until Ollama or OpenAI embeddings recover.`;
    const now = Date.now();
    if (now - embeddingRuntimeState.lastWarnedAtMs >= EMBEDDING_WARNING_COOLDOWN_MS) {
        embeddingRuntimeState.lastWarnedAtMs = now;
        log.warn({
            reason,
            ollamaBaseUrl: config.providers.ollama?.baseUrl ?? 'http://localhost:11434',
            openaiConfigured: Boolean(config.providers.openai?.apiKey),
        }, 'Semantic memory degraded to local hashing-trick embeddings');
    }
}
export function getEmbeddingRuntimeOverview() {
    return {
        mode: embeddingRuntimeState.mode,
        degraded: embeddingRuntimeState.degraded,
        ollamaSuccesses: embeddingRuntimeState.ollamaSuccesses,
        openaiSuccesses: embeddingRuntimeState.openaiSuccesses,
        localHashFallbacks: embeddingRuntimeState.localHashFallbacks,
        lastSuccessAt: embeddingRuntimeState.lastSuccessAt,
        lastDegradedAt: embeddingRuntimeState.lastDegradedAt,
        lastFallbackReason: embeddingRuntimeState.lastFallbackReason,
        lastWarning: embeddingRuntimeState.lastWarning,
        openaiConfigured: Boolean(config.providers.openai?.apiKey),
        ollamaBaseUrl: config.providers.ollama?.baseUrl ?? 'http://localhost:11434',
        embeddingModel: config.memory?.embeddingModel ?? 'nomic-embed-text',
    };
}
export function resetEmbeddingRuntimeOverview() {
    Object.assign(embeddingRuntimeState, createInitialEmbeddingRuntimeState());
}
export async function generateEmbedding(text) {
    const cleanText = text.slice(0, 8192).trim();
    if (!cleanText)
        return null;
    // Try Ollama first (local, free)
    const ollamaUrl = config.providers.ollama?.baseUrl ?? 'http://localhost:11434';
    const embeddingModel = config.memory?.embeddingModel ?? 'nomic-embed-text';
    try {
        const resp = await fetch(`${ollamaUrl}/api/embeddings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model: embeddingModel, prompt: cleanText }),
            signal: AbortSignal.timeout(15_000),
        });
        if (resp.ok) {
            const data = await resp.json();
            if (Array.isArray(data.embedding) && data.embedding.length > 0) {
                markEmbeddingHealthy('ollama');
                return data.embedding;
            }
        }
    }
    catch {
        // Ollama not available or model not loaded — try OpenAI
    }
    // Try OpenAI text-embedding-3-small
    const openaiKey = config.providers.openai?.apiKey;
    if (!openaiKey) {
        // No OpenAI key — skip to local fallback
        markEmbeddingDegraded('Ollama embeddings unavailable and no OpenAI embedding key is configured');
        return generateLocalEmbedding(cleanText);
    }
    try {
        const baseUrl = config.providers.openai?.baseUrl ?? 'https://api.openai.com/v1';
        const resp = await fetch(`${baseUrl}/embeddings`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${openaiKey}`,
            },
            body: JSON.stringify({
                model: 'text-embedding-3-small',
                input: cleanText,
            }),
            signal: AbortSignal.timeout(15_000),
        });
        if (resp.ok) {
            const data = await resp.json();
            if (data.data?.[0]?.embedding) {
                markEmbeddingHealthy('openai');
                return data.data[0].embedding;
            }
        }
    }
    catch {
        log.debug('OpenAI embedding failed');
    }
    // 3. Fallback: local hashing-trick embedding (always available)
    markEmbeddingDegraded('Ollama embeddings failed and OpenAI embeddings were unavailable');
    return generateLocalEmbedding(cleanText);
}
/**
 * Local hashing-trick embedding — no external service needed.
 * Produces a 256-dimension vector via word hashing + L2 normalization.
 * Quality is lower than neural embeddings but enables offline semantic search.
 */
export function generateLocalEmbedding(text) {
    const DIMS = 256;
    const vec = new Float64Array(DIMS);
    const words = text.toLowerCase().split(/\W+/).filter(w => w.length > 1);
    for (const word of words) {
        let hash = 0;
        for (let i = 0; i < word.length; i++) {
            hash = ((hash << 5) - hash + word.charCodeAt(i)) | 0;
        }
        const idx = Math.abs(hash) % DIMS;
        // Use sign from hash to create positive/negative features
        vec[idx] += (hash > 0 ? 1 : -1);
    }
    // L2 normalize
    let norm = 0;
    for (let i = 0; i < DIMS; i++)
        norm += vec[i] * vec[i];
    norm = Math.sqrt(norm);
    if (norm > 0)
        for (let i = 0; i < DIMS; i++)
            vec[i] /= norm;
    return Array.from(vec);
}
/** Cosine similarity between two vectors. Returns value in [-1, 1]. */
export function cosineSimilarity(a, b) {
    if (a.length !== b.length || a.length === 0)
        return 0;
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < a.length; i++) {
        dot += a[i] * b[i];
        normA += a[i] * a[i];
        normB += b[i] * b[i];
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom === 0 ? 0 : dot / denom;
}
//# sourceMappingURL=embedding.js.map