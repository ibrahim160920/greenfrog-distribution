import Database from 'better-sqlite3';
import type { ChannelName, ConversationMessage } from '../utils/types.js';
export declare function createConversationStore(db: Database.Database): {
    addMessage(sessionId: string, userId: string, channel: ChannelName, message: ConversationMessage): void;
    getHistory(sessionId: string, limit?: number): ConversationMessage[];
    clearHistory(sessionId: string): void;
    getHistoryForUser(sessionId: string, userId: string, limit?: number): ConversationMessage[] | null;
    clearHistoryForUser(sessionId: string, userId: string): boolean;
    getOrCreateSession(userId: string, channel: ChannelName, chatId: string): string;
    getSessionOwner(sessionId: string): string | null;
    searchConversations(userId: string, channel: ChannelName, query: string, limit?: number): Array<{
        sessionId: string;
        role: string;
        content: string;
        createdAt: Date;
    }>;
    exportConversation(sessionId: string, format: "json" | "markdown"): string;
};
//# sourceMappingURL=store_conversation.d.ts.map