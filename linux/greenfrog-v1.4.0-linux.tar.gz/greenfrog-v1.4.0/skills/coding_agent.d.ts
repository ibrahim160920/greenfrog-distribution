import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class CodingAgentSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    /**
     * Use `git diff --name-only` + `git ls-files --others` to discover all files
     * changed since the last commit — including those modified by shell commands.
     * Returns absolute paths.
     */
    private getGitChangedFiles;
    /**
     * Get the original (pre-modification) content of a file via `git show HEAD:<path>`.
     * Returns null if the file is new (not in HEAD) or if git is unavailable.
     */
    private getGitOriginalContent;
    private gatherProjectInfo;
}
//# sourceMappingURL=coding_agent.d.ts.map