/**
 * BullMQ task queue — async decoupling for AI message processing.
 *
 * When config.queue.redisUrl is set:
 *   - All POST /api/message requests are enqueued instead of blocking HTTP.
 *   - Worker processes jobs concurrently (config.queue.concurrency, default 4).
 *   - Results are stored in Redis for 60 s so callers can poll GET /api/jobs/:id.
 *   - WebSocket clients receive results via push notification.
 *   - Graceful shutdown drains the worker before process exit.
 *
 * When redisUrl is absent, the module no-ops gracefully (direct processing).
 */
import { Queue, Worker } from 'bullmq';
import { createLogger } from '../utils/logger.js';
import { queueJobsTotal, queueDepth } from '../metrics/index.js';
import { RuntimeLimitError } from '../utils/errors.js';
const log = createLogger('queue');
// ── Module-level singletons ───────────────────────────────────────────────────
let _queue = null;
let _worker = null;
/**
 * In-memory result store: requestId → result (kept max 60 s).
 * Used by the polling endpoint GET /api/jobs/:requestId.
 * In multi-process deployments replace with a Redis hash.
 */
const _results = new Map();
/** Registered callback for delivering results to WebSocket clients. */
let _onResult = null;
// ── Public API ────────────────────────────────────────────────────────────────
export function isQueueEnabled() {
    return _queue !== null;
}
export function getQueue() {
    return _queue;
}
/** Register a callback that fires when a job finishes (used by web channel for WS push). */
export function onJobResult(cb) {
    _onResult = cb;
}
/**
 * Enqueue a message processing job.
 * Returns the BullMQ job ID (or undefined when queue is disabled).
 */
export async function enqueueMessage(data) {
    if (!_queue)
        return undefined;
    const { config } = await import('../config/index.js');
    const maxPendingJobs = config.queue?.maxPendingJobs;
    if (maxPendingJobs) {
        const counts = await _queue.getJobCounts('waiting', 'active', 'delayed', 'prioritized');
        const pendingJobs = (counts.waiting ?? 0) + (counts.active ?? 0) + (counts.delayed ?? 0) + (counts.prioritized ?? 0);
        if (pendingJobs >= maxPendingJobs) {
            throw new RuntimeLimitError(`Queue backlog limit reached (${pendingJobs}/${maxPendingJobs}).`, {
                queue: 'messages',
                pendingJobs,
                maxPendingJobs,
            });
        }
    }
    const job = await _queue.add('process_message', data, {
        jobId: data.requestId,
        attempts: 2,
        backoff: { type: 'exponential', delay: 1_000 },
        removeOnComplete: { count: 1_000, age: 3_600 },
        removeOnFail: { count: 500 },
    });
    queueJobsTotal.inc({ queue: 'messages', event: 'added' });
    // Update depth gauge (fire-and-forget)
    _queue.getWaitingCount().then((n) => queueDepth.set({ queue: 'messages' }, n)).catch(() => { });
    return job.id;
}
/**
 * Poll for a job result (used when caller prefers pull over push).
 * Returns null if not yet ready.
 */
export function getJobResult(requestId) {
    const entry = _results.get(requestId);
    if (!entry)
        return null;
    _results.delete(requestId);
    return entry;
}
// ── Initialisation ────────────────────────────────────────────────────────────
/** Parse a Redis URL into BullMQ-compatible connection options. */
function parseRedisUrl(url) {
    const parsed = new URL(url);
    const opts = {
        host: parsed.hostname || 'localhost',
        port: parseInt(parsed.port || '6379', 10),
    };
    if (parsed.password)
        opts.password = decodeURIComponent(parsed.password);
    if (parsed.username)
        opts.username = decodeURIComponent(parsed.username);
    const db = parseInt(parsed.pathname?.slice(1) ?? '', 10);
    if (!isNaN(db) && db > 0)
        opts.db = db;
    return opts;
}
export async function initQueue(processMessage) {
    const { config } = await import('../config/index.js');
    const redisUrl = config.queue?.redisUrl;
    if (!redisUrl) {
        log.debug('Queue disabled (queue.redisUrl not configured)');
        return;
    }
    // Pass parsed options directly — BullMQ manages its own ioredis connections.
    // Sharing an external ioredis instance causes TS type conflicts because BullMQ
    // bundles a private copy of ioredis with incompatible module-instance types.
    const connection = parseRedisUrl(redisUrl);
    _queue = new Queue('messages', { connection });
    _worker = new Worker('messages', async (job) => {
        if (job.data.type !== 'process_message')
            throw new Error(`Unknown job type: ${job.data.type}`);
        return processMessage(job.data);
    }, {
        connection: { ...connection }, // Worker needs its own connection object
        concurrency: config.queue?.concurrency ?? 4,
    });
    log.info({ redisUrl }, 'Redis (BullMQ) connected');
    _worker.on('completed', (job, result) => {
        const data = job.data;
        const jobResult = { requestId: data.requestId, text: result };
        _results.set(data.requestId, { ...jobResult, ts: Date.now() });
        _onResult?.(jobResult);
        queueJobsTotal.inc({ queue: 'messages', event: 'completed' });
        // Update depth gauge
        _queue?.getWaitingCount().then((n) => queueDepth.set({ queue: 'messages' }, n)).catch(() => { });
    });
    _worker.on('failed', (job, err) => {
        if (!job)
            return;
        const data = job.data;
        const jobResult = { requestId: data.requestId, text: '', error: String(err) };
        _results.set(data.requestId, { ...jobResult, ts: Date.now() });
        _onResult?.(jobResult);
        queueJobsTotal.inc({ queue: 'messages', event: 'failed' });
        log.error({ jobId: job.id, err }, 'Queue job failed');
    });
    // Purge stale results every minute
    setInterval(() => {
        const cutoff = Date.now() - 60_000;
        for (const [id, entry] of _results) {
            if (entry.ts < cutoff)
                _results.delete(id);
        }
    }, 60_000).unref();
    log.info({ concurrency: config.queue?.concurrency ?? 4 }, 'BullMQ worker started');
}
// ── Graceful shutdown ─────────────────────────────────────────────────────────
export async function closeQueue() {
    try {
        await _worker?.close();
        await _queue?.close();
        log.info('Queue closed');
    }
    catch (err) {
        log.warn({ err }, 'Queue close error (non-fatal)');
    }
}
//# sourceMappingURL=index.js.map