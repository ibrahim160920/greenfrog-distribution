/**
 * Distribution server handlers.
 *
 * Five endpoints:
 *   POST /api/distribution/enroll              — no auth (first boot)
 *   POST /api/distribution/backflow            — validateChildJwt
 *   GET  /api/distribution/inheritance/latest  — validateChildJwt
 *   GET  /api/distribution/inheritance/:releaseId — validateChildJwt
 *   POST /api/distribution/enroll/revoke       — validateChildJwt
 *
 * Auth model (two-phase):
 *
 *   Phase 1 — Bootstrap (enrollment only):
 *     - Child sends instanceId + enrollmentKey in POST /enroll body (no Bearer header)
 *     - enrollmentKey is 256-bit crypto-random, auto-generated at first boot
 *     - Server validates fields and issues a JWT signed with gateway secret (HMAC-SHA256)
 *
 *   Phase 2 — Ongoing (all subsequent calls):
 *     - Child uses the issued JWT as "Authorization: Bearer <JWT>"
 *     - Server verifies JWT signature + extracts instanceId from sub claim
 *     - Looks up instance in registry by instanceId to check revocation
 *     - enrollmentKey is NOT sent in API headers after enrollment
 *
 *   Revoke:
 *     - Child sends POST /enroll/revoke with its JWT
 *     - Server verifies JWT, marks instance revoked by instanceId
 *     - Subsequent calls with the same JWT are rejected (401)
 */
import crypto from 'node:crypto';
import { createLogger } from '../../utils/logger.js';
import { registerInstance, lookupByInstanceId, revokeByInstanceId, touchByInstanceId, } from './registry.js';
import { findLatestCompatible, findByReleaseId } from './manifest_store.js';
import { sanitizeBatch } from '../backflow/sanitizer.js';
const log = createLogger('distribution-server');
// ── JWT issuance + verification (HMAC-SHA256 for MVP) ────────────────────────
/** Issue a JWT with instanceId in the sub claim. */
function issueJwt(instanceId, secret) {
    const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
    const payload = Buffer.from(JSON.stringify({
        sub: instanceId,
        iat: Math.floor(Date.now() / 1000),
    })).toString('base64url');
    const sigInput = `${header}.${payload}`;
    const sig = crypto.createHmac('sha256', secret).update(sigInput).digest('base64url');
    return `${sigInput}.${sig}`;
}
/** Verify a JWT and return the instanceId (sub), or null if invalid. */
export function verifyChildJwt(token, secret) {
    const parts = token.split('.');
    if (parts.length !== 3)
        return null;
    const [headerB64, payloadB64, sigB64] = parts;
    const expectedSig = crypto
        .createHmac('sha256', secret)
        .update(`${headerB64}.${payloadB64}`)
        .digest('base64url');
    // Timing-safe comparison
    try {
        const a = Buffer.from(sigB64 ?? '', 'utf-8');
        const b = Buffer.from(expectedSig, 'utf-8');
        if (a.length !== b.length || !crypto.timingSafeEqual(a, b))
            return null;
    }
    catch {
        return null;
    }
    try {
        const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf-8'));
        if (typeof payload['sub'] !== 'string')
            return null;
        return payload['sub'];
    }
    catch {
        return null;
    }
}
/**
 * Express middleware that authenticates child instances via their issued JWT.
 *
 * Extracts Bearer token, verifies HMAC-SHA256 signature, extracts instanceId
 * from sub claim, checks registry for revocation, attaches enrolledInstance
 * to the request.
 */
export function validateChildJwt(req, res, next, opts) {
    const auth = req.headers['authorization'];
    if (!auth || !auth.startsWith('Bearer ')) {
        res.status(401).json({ ok: false, error: 'missing child JWT' });
        return;
    }
    const token = auth.slice(7).trim();
    const instanceId = verifyChildJwt(token, opts.jwtSecret);
    if (!instanceId) {
        res.status(401).json({ ok: false, error: 'invalid or expired JWT' });
        return;
    }
    const instance = lookupByInstanceId(instanceId, opts.baseDir);
    if (!instance) {
        res.status(401).json({ ok: false, error: 'instance not found or revoked' });
        return;
    }
    touchByInstanceId(instanceId, opts.baseDir);
    req.enrolledInstance = instance;
    next();
}
/** Factory that returns a validateChildJwt middleware bound to options. */
export function makeChildAuthMiddleware(opts) {
    return (req, res, next) => validateChildJwt(req, res, next, opts);
}
export function handleEnroll(opts) {
    return (req, res) => {
        const { jwtSecret, baseDir } = opts;
        const body = req.body;
        const instanceId = typeof body['instanceId'] === 'string' ? body['instanceId'] : '';
        const enrollmentKey = typeof body['enrollmentKey'] === 'string' ? body['enrollmentKey'] : '';
        const platform = typeof body['platform'] === 'string' ? body['platform'] : '';
        const arch = typeof body['arch'] === 'string' ? body['arch'] : '';
        const nodeVersion = typeof body['nodeVersion'] === 'string' ? body['nodeVersion'] : '';
        const appVersion = typeof body['appVersion'] === 'string' ? body['appVersion'] : '';
        if (!instanceId.match(/^[0-9a-f]{32}$/)) {
            res.status(400).json({ ok: false, error: 'invalid instanceId (must be 32 hex chars)' });
            return;
        }
        if (!enrollmentKey.match(/^[0-9a-f]{64}$/)) {
            res.status(400).json({ ok: false, error: 'invalid enrollmentKey (must be 64 hex chars)' });
            return;
        }
        if (!platform || !arch || !nodeVersion || !appVersion) {
            res.status(400).json({ ok: false, error: 'missing required fields: platform, arch, nodeVersion, appVersion' });
            return;
        }
        try {
            const instance = registerInstance({ instanceId, enrollmentKey, platform, arch, nodeVersion, appVersion }, baseDir);
            const jwt = issueJwt(instance.instanceId, jwtSecret);
            log.info({ instanceId: instance.instanceId, platform }, 'child instance enrolled');
            res.json({ ok: true, jwt, expiresAt: null });
        }
        catch (err) {
            log.error({ err }, 'enrollment error');
            res.status(500).json({ ok: false, error: 'internal error' });
        }
    };
}
// ── Handler: POST /api/distribution/backflow ─────────────────────────────────
export function handleBackflow(_baseDir) {
    return (req, res) => {
        const body = req.body;
        const entries = Array.isArray(body['entries']) ? body['entries'] : [];
        // Double-sanitize on server side
        const sanitized = sanitizeBatch(entries);
        log.info({ received: sanitized.length }, 'backflow received');
        res.json({ ok: true, received: sanitized.length });
    };
}
// ── Handler: GET /api/distribution/inheritance/latest ────────────────────────
export function handleInheritanceLatest(manifestsDir) {
    return (req, res) => {
        const currentVersion = typeof req.query['currentVersion'] === 'string'
            ? req.query['currentVersion']
            : '';
        if (!currentVersion) {
            res.status(400).json({ ok: false, error: 'currentVersion query param required' });
            return;
        }
        const manifest = findLatestCompatible(currentVersion, manifestsDir);
        if (!manifest) {
            res.json({ ok: true, noUpdate: true });
            return;
        }
        res.json({ ok: true, manifest });
    };
}
// ── Handler: GET /api/distribution/inheritance/:releaseId ────────────────────
export function handleInheritanceById(manifestsDir) {
    return (req, res) => {
        const releaseId = String(req.params['releaseId'] ?? '');
        const manifest = findByReleaseId(releaseId, manifestsDir);
        if (!manifest) {
            res.status(404).json({ ok: false, error: `manifest not found: ${releaseId}` });
            return;
        }
        res.json({ ok: true, manifest });
    };
}
// ── Handler: POST /api/distribution/enroll/revoke ────────────────────────────
export function handleRevoke(opts) {
    return (req, res) => {
        const instance = req.enrolledInstance;
        if (!instance) {
            res.status(401).json({ ok: false, error: 'not authenticated' });
            return;
        }
        const revoked = revokeByInstanceId(instance.instanceId, opts.baseDir);
        if (revoked) {
            log.info({ instanceId: instance.instanceId }, 'child instance revoked');
        }
        res.json({ ok: true });
    };
}
//# sourceMappingURL=index.js.map