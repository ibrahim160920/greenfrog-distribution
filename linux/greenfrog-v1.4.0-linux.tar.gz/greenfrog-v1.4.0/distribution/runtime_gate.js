/**
 * runtime_gate.ts — Enrollment gate for child instances.
 *
 * If process.env.GF_IS_CHILD_INSTANCE === 'true', the runtime gate
 * must be checked on startup. Any state other than 'enrolled' blocks
 * normal operation.
 *
 * Three entry points:
 *   assertEnrolled(baseDir?)          — throws EnrollmentRequiredError if not enrolled
 *   createEnrollmentGateMiddleware()  — Express middleware returning 503 if not enrolled
 *   checkEnrollmentOrExit(baseDir?)   — logs i18n message + process.exit(1) if not enrolled
 */
import { isEnrolled, getEnrollmentState } from './identity/first_boot.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('runtime-gate');
// ── Error type ────────────────────────────────────────────────────────────────
export class EnrollmentRequiredError extends Error {
    state;
    constructor(state) {
        super(`Instance not enrolled (state: ${state}). Complete first-boot registration before operation.`);
        this.name = 'EnrollmentRequiredError';
        this.state = state;
    }
}
// ── assertEnrolled ────────────────────────────────────────────────────────────
/**
 * Throw EnrollmentRequiredError if the instance is not in 'enrolled' state.
 * Safe to call repeatedly — no side effects.
 */
export function assertEnrolled(baseDir) {
    if (!isEnrolled(baseDir)) {
        const { state } = getEnrollmentState(baseDir);
        throw new EnrollmentRequiredError(state);
    }
}
// ── Express middleware ────────────────────────────────────────────────────────
/**
 * Returns an Express RequestHandler that responds 503 with an enrollment
 * error JSON body if the instance is not enrolled.
 *
 * Usage:
 *   app.use('/api', createEnrollmentGateMiddleware());
 */
export function createEnrollmentGateMiddleware(baseDir) {
    return (_req, res, next) => {
        if (!isEnrolled(baseDir)) {
            const { state } = getEnrollmentState(baseDir);
            res.status(503).json({
                error: 'enrollment_required',
                message: `Instance not enrolled (state: ${state}). Complete first-boot registration.`,
                state,
            });
            return;
        }
        next();
    };
}
// ── checkEnrollmentOrExit ─────────────────────────────────────────────────────
/**
 * Check enrollment state and exit the process if not enrolled.
 * Called during startup when GF_IS_CHILD_INSTANCE === 'true'.
 *
 * Logs a clear message before exiting so the user knows how to proceed.
 */
export function checkEnrollmentOrExit(baseDir) {
    if (isEnrolled(baseDir))
        return;
    const { state, failureReason } = getEnrollmentState(baseDir);
    const SEP = '================================================================';
    // Determine where the config file lives so we can give a precise path
    const os = process.platform;
    const home = process.env['HOME'] ?? process.env['USERPROFILE'] ?? '~';
    const dataDir = baseDir
        ?? process.env['GF_BASE_DIR']
        ?? (os === 'win32'
            ? `${process.env['APPDATA'] ?? '%APPDATA%'}\\GreenFrog`
            : `${home}/.greenfrog`);
    const configFile = os === 'win32'
        ? `${dataDir}\\config.ps1`
        : `${dataDir}/config.sh`;
    const enrollmentUrl = process.env['GF_ENROLLMENT_URL'];
    const lines = [
        SEP,
        '  GreenFrog -- Enrollment Required',
        SEP,
        `  State    : ${state}`,
    ];
    if (failureReason) {
        lines.push(`  Reason   : ${failureReason.slice(0, 100)}`);
    }
    lines.push('');
    if (!enrollmentUrl) {
        lines.push('  GF_ENROLLMENT_URL is not set.', '  Your enrollment URL is provided by your organization\'s administrator.', '', '  Quick setup — run with the enrollment URL:', `    greenfrog --enrollment-url https://your-server/api/distribution/enroll`, '', '  Or set it permanently in your config file:', `    ${configFile}`, '', `  Add this line:  GF_ENROLLMENT_URL=https://your-server/api/distribution/enroll`);
    }
    else {
        lines.push(`  Enrollment URL: ${enrollmentUrl}`, '', '  Enrollment has not completed. To retry, run:', `    greenfrog --enrollment-url ${enrollmentUrl}`);
    }
    lines.push('', '  This instance must complete enrollment before normal operation.', '  Enrollment is automatic once the URL is configured — no keys to type.', SEP);
    log.error({ state, failureReason, enrollmentUrl: enrollmentUrl ?? '(not set)' }, 'startup blocked: instance not enrolled');
    console.error(lines.join('\n'));
    process.exit(1);
}
//# sourceMappingURL=runtime_gate.js.map