/**
 * Research — 深度联网调研技能
 *
 * 不同于 web_search（返回原始链接列表），research 做三件事：
 *   1. 搜索 (Tavily → Serper → DuckDuckGo)
 *   2. 抓取页面正文
 *   3. LLM 综合 → 结构化报告
 *
 * 用法：
 *   research query="2025年全球AI芯片市场"
 *   research query="React 19新特性" depth=deep format=report
 */
import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class ResearchSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private searchTavily;
    private searchUrls;
    private fetchPages;
    private extractText;
    private synthesize;
}
//# sourceMappingURL=research.d.ts.map