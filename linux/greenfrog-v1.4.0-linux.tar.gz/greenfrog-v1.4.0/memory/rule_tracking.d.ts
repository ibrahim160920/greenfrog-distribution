/**
 * Rule Usage Tracking System
 *
 * Tracks when and how behavioral rules are applied to provide data for quality scoring.
 */
import type { ChannelName } from '../utils/types.js';
export interface RuleApplicationEvent {
    ruleId: string;
    workspaceId: string;
    channel: ChannelName;
    userId: string;
    appliedAt: Date;
    success: boolean;
    context?: string;
    errorMessage?: string;
}
export interface RuleValidationSample {
    workspaceId: string;
    channel: ChannelName;
    userId: string;
    appliedAt: Date;
    success: boolean;
    context?: string;
    errorMessage?: string;
}
/**
 * Track a rule application event.
 * Write-through: persists to SQLite immediately so stats survive restarts.
 * Also updates the in-memory cache for fast within-session reads.
 */
export declare function trackRuleApplication(event: RuleApplicationEvent): Promise<void>;
/**
 * Get usage statistics for a specific rule.
 * Reads from the durable SQLite store first, then merges with any in-memory
 * events not yet visible in the DB (same-request writes arrive here via cache).
 */
export declare function getRuleUsageStats(ruleId: string, workspaceId: string, channel: ChannelName): Promise<{
    totalApplications: number;
    successfulApplications: number;
    failedApplications: number;
    successRate: number;
    lastUsedAt: Date | null;
    firstUsedAt: Date | null;
}>;
/**
 * Get usage statistics for all rules in a workspace.
 * Reads from durable SQLite store, which survives restarts.
 */
export declare function getAllRuleUsageStats(workspaceId: string, channel: ChannelName): Promise<Map<string, {
    totalApplications: number;
    successfulApplications: number;
    failedApplications: number;
    successRate: number;
    lastUsedAt: Date | null;
}>>;
export declare function getRecentRuleValidationSamples(ruleId: string, opts?: {
    workspaceIds?: string[];
    limit?: number;
}): Promise<RuleValidationSample[]>;
export declare function getAggregatedRuleValidationStats(ruleId: string, opts?: {
    workspaceIds?: string[];
    sampleLimit?: number;
}): Promise<{
    totalApplications: number;
    successfulApplications: number;
    failedApplications: number;
    successRate: number | null;
    recentSamples: RuleValidationSample[];
}>;
/**
 * Clear old tracking data (for memory management)
 */
export declare function clearOldTrackingData(olderThanDays?: number): Promise<number>;
/**
 * Get tracking statistics summary
 */
export declare function getTrackingStatsSummary(): Promise<{
    totalEvents: number;
    totalWorkspaces: number;
    oldestEvent: Date | null;
    newestEvent: Date | null;
}>;
export declare function resetRuleTrackingForTests(): void;
//# sourceMappingURL=rule_tracking.d.ts.map