/**
 * Humanize Skill — 去AI味，让文字更像真人写的
 *
 * AI写作的典型病症（逐条处理）：
 *   1. 套话连接词      — "首先/其次/再次/最后"、"值得注意的是"、"综上所述"
 *   2. 空洞排比堆砌    — "不仅...而且...更..."、三段式列举
 *   3. 过度强调感叹    — "！！"、"非常非常"、"极其重要"
 *   4. 结尾升华        — "让我们共同努力"、"这正是X的意义所在"
 *   5. 被动句/长难句   — "通过X，我们可以Y，从而实现Z"
 *   6. 假装客观的模糊  — "可能"、"或许"、"在某种程度上"堆叠
 *   7. 段落首句公式化  — 每段都是"在XX领域/背景下，..."
 */
import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class HumanizeSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private rewrite;
    private rewriteInChunks;
}
//# sourceMappingURL=humanize.d.ts.map