/**
 * Reflection Engine — the "使用越久越智能" 核心
 *
 * 定期（或按需）对最近的交互进行自我反思：
 *   1. 收集最近负向/纠错的交互样本
 *   2. LLM 分析模式，提炼行为规则
 *   3. 将规则持久化到 behavioral_rules 表
 *   4. 规则注入 system prompt，永久改变行为
 *
 * 触发时机：
 *   - 自动：每积累 10 条负向反馈时
 *   - 手动：用户调用 reflect 技能
 *   - 定期：每 N 次交互（由 agent 调用）
 */
import type { ChannelName } from '../utils/types.js';
export interface ReflectionResult {
    rulesAdded: number;
    rulesReinforced: number;
    summary: string;
    rules: Array<{
        rule: string;
        category: string;
        confidence: number;
    }>;
}
export declare function runReflection(userId: string, channel: ChannelName, minSamples?: number): Promise<ReflectionResult>;
//# sourceMappingURL=reflector.d.ts.map