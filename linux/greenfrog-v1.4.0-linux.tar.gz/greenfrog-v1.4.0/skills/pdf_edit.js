/**
 * PDF Edit Skill — in-place text replacement in PDF files
 *
 * How it works:
 *   1. Loads the PDF with pdf-lib (handles all PDF structure, xref tables, etc.)
 *   2. Iterates all FlateDecode content streams in the document
 *   3. Decompresses each stream with zlib
 *   4. Searches for the target text using multiple encoding strategies:
 *      - UTF-16BE hex  (中文/CJK in most modern PDFs: "中" → "4E2D")
 *      - Latin-1 literal string  (ASCII text in parentheses: "(hello)")
 *      - Raw UTF-8 bytes  (some newer PDFs)
 *   5. Replaces all occurrences, recompresses, updates /Length in the dict
 *   6. pdf-lib.save() rebuilds the xref table correctly — no manual offset math
 *
 * Limitations:
 *   - Encrypted PDFs: cannot be edited
 *   - Scanned PDFs (image-only): no text streams to modify
 *   - If the font doesn't contain the replacement glyph, the glyph won't render
 *     (the bytes are written correctly but the font may lack the character)
 */
import { inflateSync, deflateSync } from 'zlib';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { dirname, join, basename, extname } from 'path';
import { PDFDocument, PDFRawStream, PDFName, PDFNumber, PDFArray } from 'pdf-lib';
import { BaseSkill } from './base.js';
// Allowed roots — same philosophy as file_ops.ts
const SAFE_ROOTS = [
    process.env.HOME ?? '',
    process.env.USERPROFILE ?? '',
    process.cwd(),
    'C:\\Users',
    '/tmp',
];
function isSafePath(p) {
    const normalized = p.replace(/\\/g, '/');
    return SAFE_ROOTS.some((root) => normalized.startsWith(root.replace(/\\/g, '/')));
}
// ─────────────────────────────────────────────────────────────────────────────
export class PdfEditSkill extends BaseSkill {
    definition = {
        name: 'pdf_edit',
        description: 'Edit a PDF file: find and replace text, fix typos, change specific words or phrases. ' +
            'Works with text-based PDFs (not scanned images). ' +
            'Supports Chinese/CJK text, Latin, and mixed content. ' +
            'The original file is preserved; a new file is created with _edited suffix unless output path is specified.',
        category: 'files',
        parameters: [
            {
                name: 'path',
                type: 'string',
                required: true,
                description: 'Local file path to the PDF file',
            },
            {
                name: 'find',
                type: 'string',
                required: true,
                description: 'The exact text to find and replace',
            },
            {
                name: 'replace',
                type: 'string',
                required: true,
                description: 'The replacement text',
            },
            {
                name: 'output',
                type: 'string',
                description: 'Output file path (optional). Defaults to original name with _edited suffix.',
            },
            {
                name: 'overwrite',
                type: 'boolean',
                description: 'Overwrite the original file. Default: false (creates new file)',
                default: false,
            },
        ],
        examples: [
            '把这个PDF里所有的"公式"改成"算法": /Users/me/report.pdf',
            'pdf_edit 把 /tmp/draft.pdf 第3行的错别字"申明"改成"声明"',
            '修改PDF: path=/home/user/contract.pdf find="甲方" replace="乙方"',
        ],
    };
    async execute(params, _ctx) {
        const filePath = (params.path ?? '').trim();
        const findText = (params.find ?? '').trim();
        const replText = (params.replace ?? '').trim();
        const outPath = (params.output ?? '').trim();
        const overwrite = params.overwrite === true;
        if (!filePath)
            return this.err('path is required');
        if (!findText)
            return this.err('find text is required');
        if (replText === undefined)
            return this.err('replace text is required');
        if (!existsSync(filePath))
            return this.err(`File not found: ${filePath}`);
        if (!isSafePath(filePath))
            return this.err(`Access denied: path outside allowed directories`);
        if (!filePath.toLowerCase().endsWith('.pdf'))
            return this.err('Only PDF files are supported');
        // Determine output path
        const ext = extname(filePath);
        const base = basename(filePath, ext);
        const dir = dirname(filePath);
        const targetPath = overwrite
            ? filePath
            : (outPath || join(dir, `${base}_edited${ext}`));
        try {
            const pdfBytes = readFileSync(filePath);
            const { outBytes, replacements, streamsProcessed, warnings } = await replacePdfText(pdfBytes, findText, replText);
            if (replacements === 0) {
                const hint = warnings.length > 0
                    ? `\n\n技术信息:\n${warnings.slice(0, 3).join('\n')}`
                    : '\n\n提示：\n- 检查文字是否完全一致（包括全半角、空格）\n- 如果是扫描件，PDF 内没有可编辑文字\n- 部分 PDF 使用特殊字体编码，无法直接识别文字';
                return this.text(`❌ 未找到要替换的文字 "${findText}"\n` +
                    `（已扫描 ${streamsProcessed} 个内容流）` +
                    hint);
            }
            writeFileSync(targetPath, outBytes);
            const warnSection = warnings.length > 0
                ? `\n\n⚠️ 注意事项:\n${warnings.slice(0, 3).map((w) => `- ${w}`).join('\n')}`
                : '';
            return this.text(`✅ PDF 编辑完成\n\n` +
                `- **查找:** "${findText}"\n` +
                `- **替换:** "${replText}"\n` +
                `- **替换次数:** ${replacements} 处\n` +
                `- **输出文件:** ${targetPath}` +
                warnSection);
        }
        catch (err) {
            return this.err(`PDF 编辑失败: ${String(err)}`);
        }
    }
}
async function replacePdfText(pdfBuffer, find, replace) {
    const warnings = [];
    let replacements = 0;
    let streamsProcessed = 0;
    let pdfDoc;
    try {
        pdfDoc = await PDFDocument.load(pdfBuffer, { ignoreEncryption: true, updateMetadata: false });
    }
    catch (e) {
        if (String(e).includes('encrypt')) {
            throw new Error('PDF 已加密，无法编辑');
        }
        throw e;
    }
    for (const [ref, obj] of pdfDoc.context.enumerateIndirectObjects()) {
        if (!(obj instanceof PDFRawStream))
            continue;
        const dict = obj.dict;
        const filter = dict.get(PDFName.of('Filter'));
        if (!isFlateDecoded(filter))
            continue;
        // Skip image streams — they contain binary pixel data, not text
        const subtype = dict.get(PDFName.of('Subtype'));
        if (subtype && subtype.toString() === '/Image')
            continue;
        streamsProcessed++;
        let decompressed;
        try {
            decompressed = inflateSync(Buffer.from(obj.contents));
        }
        catch {
            warnings.push(`跳过无法解压的流 (object ${ref})`);
            continue;
        }
        // Work in latin1 to preserve all byte values faithfully
        let streamText = decompressed.toString('latin1');
        let changed = false;
        const pairs = buildReplacePairs(find, replace);
        for (const [needle, nail] of pairs) {
            if (!needle)
                continue;
            if (!streamText.includes(needle))
                continue;
            const before = streamText;
            streamText = streamText.split(needle).join(nail);
            if (streamText !== before) {
                replacements += (before.split(needle).length - 1);
                changed = true;
            }
        }
        if (!changed)
            continue;
        // Recompress modified stream
        const recompressed = deflateSync(Buffer.from(streamText, 'latin1'), { level: 6 });
        // Update /Length — pdf-lib uses this value when serialising the stream
        dict.set(PDFName.of('Length'), PDFNumber.of(recompressed.byteLength));
        // Replace the stream object in the context
        pdfDoc.context.assign(ref, PDFRawStream.of(dict, recompressed));
    }
    const savedBytes = await pdfDoc.save({ useObjectStreams: false });
    return {
        outBytes: Buffer.from(savedBytes),
        replacements,
        streamsProcessed,
        warnings,
    };
}
// ─────────────────────────────────────────────────────────────────────────────
// Text encoding strategies
// ─────────────────────────────────────────────────────────────────────────────
/**
 * Build all (needle, replacement) pairs to try in a content stream.
 *
 * PDF text encoding depends on the font and PDF generator:
 *
 *  1. Latin-1 hex  — ASCII/Latin chars stored as 2-hex-digit sequence in < > strings
 *     "teh" → "746568"  (t=74, e=65, h=68)
 *     Most common for English PDFs generated by Word, LibreOffice, browsers.
 *
 *  2. Latin-1 literal — ASCII text in ( ) literal strings
 *     "teh" appears as the raw bytes in decompressed stream.
 *
 *  3. UTF-16BE hex — CJK characters stored as 4-hex-digit sequence in < > strings
 *     "中" → "4E2D"  (each char = 2 bytes = 4 hex digits)
 *     Standard for Chinese/Japanese/Korean text in most PDFs.
 *
 *  4. UTF-8 as latin1 — UTF-8 bytes stored raw in some streams
 *     "中" → bytes EF BF BD (or similar) interpreted as latin1
 */
function buildReplacePairs(find, replace) {
    const pairs = [];
    const seen = new Set();
    function add(needle, nail) {
        if (!needle || seen.has(needle))
            return;
        seen.add(needle);
        pairs.push([needle, nail]);
    }
    // ── Strategy 1: Latin-1 hex (ASCII/Latin text) ──────────────────────────────
    const findLatin1Hex = toLatin1Hex(find);
    const replLatin1Hex = toLatin1Hex(replace);
    if (findLatin1Hex && replLatin1Hex) {
        add(findLatin1Hex.toUpperCase(), replLatin1Hex.toUpperCase());
        add(findLatin1Hex.toLowerCase(), replLatin1Hex.toLowerCase());
    }
    // ── Strategy 2: Latin-1 literal bytes (inside parentheses strings) ──────────
    const findLatin1 = toLatin1Bytes(find);
    const replLatin1 = toLatin1Bytes(replace);
    if (findLatin1 !== null && replLatin1 !== null) {
        add(findLatin1, replLatin1);
    }
    // ── Strategy 3: UTF-16BE hex (CJK text) ─────────────────────────────────────
    const findUtf16 = toUtf16BeHex(find);
    const replUtf16 = toUtf16BeHex(replace);
    if (findUtf16 !== findLatin1Hex) { // skip if same as already-added latin1-hex
        add(findUtf16.toUpperCase(), replUtf16.toUpperCase());
        add(findUtf16.toLowerCase(), replUtf16.toLowerCase());
    }
    // ── Strategy 4: Raw UTF-8 bytes as latin1 ───────────────────────────────────
    const findUtf8 = Buffer.from(find, 'utf8').toString('latin1');
    const replUtf8 = Buffer.from(replace, 'utf8').toString('latin1');
    add(findUtf8, replUtf8);
    return pairs;
}
/** Each ASCII/Latin byte → 2 uppercase hex chars. Returns null if any char > U+00FF. */
function toLatin1Hex(text) {
    let result = '';
    for (const char of text) {
        const cp = char.codePointAt(0) ?? 0;
        if (cp > 255)
            return null;
        result += cp.toString(16).padStart(2, '0');
    }
    return result;
}
/** Convert string to latin-1 byte string. Returns null if any char > U+00FF. */
function toLatin1Bytes(text) {
    let result = '';
    for (const char of text) {
        const cp = char.codePointAt(0) ?? 0;
        if (cp > 255)
            return null;
        result += String.fromCharCode(cp);
    }
    return result;
}
/** Convert Unicode string to UTF-16BE hex. "中" → "4E2D". */
function toUtf16BeHex(text) {
    const chars = [];
    for (const char of text) {
        const cp = char.codePointAt(0) ?? 0;
        if (cp > 0xFFFF) {
            const hi = 0xD800 + ((cp - 0x10000) >> 10);
            const lo = 0xDC00 + ((cp - 0x10000) & 0x3FF);
            chars.push(hi.toString(16).padStart(4, '0'));
            chars.push(lo.toString(16).padStart(4, '0'));
        }
        else {
            chars.push(cp.toString(16).padStart(4, '0'));
        }
    }
    return chars.join('');
}
/**
 * Check if a PDF stream dict uses FlateDecode filter.
 * Note: pdf-lib's PDFName.asString() returns the name WITH the leading '/'.
 * e.g. filter.asString() === '/FlateDecode', NOT 'FlateDecode'.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function isFlateDecoded(filter) {
    if (!filter)
        return false;
    const str = filter.toString?.() ?? '';
    if (str === '/FlateDecode')
        return true;
    // Array of filters: check if any element is FlateDecode
    if (filter instanceof PDFArray) {
        for (let i = 0; i < filter.size(); i++) {
            if (filter.get(i)?.toString?.() === '/FlateDecode')
                return true;
        }
    }
    return false;
}
//# sourceMappingURL=pdf_edit.js.map