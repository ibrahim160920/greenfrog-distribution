/**
 * Prometheus metrics — singleton registry.
 *
 * Exposes:
 *   greenfrog_messages_total          — messages received per channel
 *   greenfrog_skill_calls_total       — skill invocations (skill, success labels)
 *   greenfrog_skill_duration_ms       — skill execution time histogram
 *   greenfrog_llm_latency_ms          — LLM API latency histogram
 *   greenfrog_llm_tokens_total        — LLM tokens consumed (provider, model, type)
 *   greenfrog_patrol_checks_total     — patrol check outcomes
 *   greenfrog_job_runs_total          — scheduled job completions
 *   greenfrog_websocket_clients       — active WS clients gauge
 *   greenfrog_queue_depth             — BullMQ queue depth gauge
 *   + default Node.js process metrics (memory, event loop, GC …)
 */
import { Registry, Counter, Histogram, Gauge } from 'prom-client';
export declare const register: Registry<"text/plain; version=0.0.4; charset=utf-8">;
export declare const messagesTotal: Counter<"channel">;
export declare const skillCallsTotal: Counter<"success" | "skill">;
export declare const llmTokensTotal: Counter<"model" | "type" | "provider">;
export declare const patrolChecksTotal: Counter<"status">;
export declare const jobRunsTotal: Counter<"status">;
export declare const authAttemptsTotal: Counter<"method" | "result">;
export declare const queueJobsTotal: Counter<"event" | "queue">;
export declare const skillDurationMs: Histogram<"skill">;
export declare const llmLatencyMs: Histogram<"model" | "provider">;
export declare const httpRequestDurationMs: Histogram<"status" | "method" | "route">;
export declare const wsClients: Gauge<string>;
export declare const queueDepth: Gauge<"queue">;
import type { Request, Response, NextFunction } from 'express';
export declare function httpMetricsMiddleware(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=index.d.ts.map