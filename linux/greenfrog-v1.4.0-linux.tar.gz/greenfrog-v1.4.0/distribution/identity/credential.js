/**
 * credential.ts — Local credential storage.
 *
 * Stores the JWT issued by the mother-body after successful enrollment.
 * Persisted at .greenfrog/identity/credential.json.
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
function getCredentialPath(baseDir) {
    const root = baseDir ?? path.join(os.homedir(), '.greenfrog');
    return path.join(root, 'identity', 'credential.json');
}
/** Save a credential record to disk. Overwrites any existing credential. */
export function saveCredential(credential, baseDir) {
    const credPath = getCredentialPath(baseDir);
    fs.mkdirSync(path.dirname(credPath), { recursive: true });
    fs.writeFileSync(credPath, JSON.stringify(credential, null, 2), 'utf-8');
}
/** Load credential from disk, or null if not present. */
export function loadCredential(baseDir) {
    const credPath = getCredentialPath(baseDir);
    if (!fs.existsSync(credPath))
        return null;
    try {
        return JSON.parse(fs.readFileSync(credPath, 'utf-8'));
    }
    catch {
        return null;
    }
}
/** Return true if a valid (non-expired) credential exists. */
export function hasValidCredential(baseDir) {
    const cred = loadCredential(baseDir);
    if (!cred?.jwt)
        return false;
    if (cred.expiresAt) {
        const expiresAt = new Date(cred.expiresAt).getTime();
        if (Date.now() > expiresAt)
            return false;
    }
    return true;
}
/** Delete the stored credential (used on re-enrollment). */
export function clearCredential(baseDir) {
    const credPath = getCredentialPath(baseDir);
    if (fs.existsSync(credPath)) {
        fs.rmSync(credPath);
    }
}
//# sourceMappingURL=credential.js.map