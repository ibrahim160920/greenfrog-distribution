import chalk from 'chalk';
import { memoryStore } from '../../memory/store.js';
export async function manageJobs(opts) {
    if (opts.delete) {
        const deleted = await memoryStore.deleteJob(opts.delete);
        if (deleted) {
            console.log(chalk.green(`✅ Job ${opts.delete} deleted`));
        }
        else {
            console.log(chalk.red(`❌ Job ${opts.delete} not found`));
        }
        return;
    }
    const jobs = await memoryStore.getJobs();
    if (jobs.length === 0) {
        console.log(chalk.yellow('No scheduled jobs. Create one by asking GreenFrog to schedule a task!'));
        return;
    }
    console.log(chalk.bold(`\n⏰ Scheduled Jobs (${jobs.length})\n`));
    for (const job of jobs) {
        const statusColor = {
            active: chalk.green,
            paused: chalk.yellow,
            completed: chalk.gray,
            failed: chalk.red,
        }[job.status] ?? chalk.white;
        console.log(`  ${statusColor(`[${job.status}]`)} ${chalk.bold(job.name)}`);
        console.log(`    ${chalk.gray('ID:')} ${job.id}`);
        console.log(`    ${chalk.gray('Cron:')} ${job.cron}`);
        console.log(`    ${chalk.gray('Prompt:')} ${job.prompt.slice(0, 80)}`);
        console.log(`    ${chalk.gray('Runs:')} ${job.runCount}${job.lastRun ? ` (last: ${job.lastRun.toLocaleString()})` : ''}`);
        console.log();
    }
}
//# sourceMappingURL=jobs.js.map