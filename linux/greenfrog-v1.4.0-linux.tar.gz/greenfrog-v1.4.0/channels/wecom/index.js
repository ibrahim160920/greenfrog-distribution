import express from 'express';
import { createServer as createHttpServer } from 'http';
import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'crypto';
import axios from 'axios';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { config } from '../../config/index.js';
// ── WeCom XML helpers ─────────────────────────────────────────────────────────
/** Parse WeCom's simple CDATA-wrapped XML into a flat key-value map. */
function parseXml(xml) {
    const result = {};
    const cdataRe = /<(\w+)><!\[CDATA\[([\s\S]*?)\]\]><\/\1>/g;
    const plainRe = /<(\w+)>([^<]*)<\/\1>/g;
    let m;
    while ((m = cdataRe.exec(xml)) !== null)
        result[m[1]] = m[2];
    while ((m = plainRe.exec(xml)) !== null) {
        if (!(m[1] in result))
            result[m[1]] = m[2];
    }
    return result;
}
// ── WeCom AES-256-CBC decryption ──────────────────────────────────────────────
//
// Key: Base64(encodingAESKey + "=")  → 32 bytes (AES-256)
// IV:  first 16 bytes of the key
// Plaintext layout: [16-byte random][4-byte msg-len BE][msg bytes][corpId bytes]
// Padding: PKCS7 with block-size=32
function decryptWeComMsg(encodingAESKey, encryptedMsg) {
    const aesKey = Buffer.from(encodingAESKey + '=', 'base64'); // 32 bytes
    const iv = aesKey.subarray(0, 16);
    const decipher = createDecipheriv('aes-256-cbc', aesKey, iv);
    decipher.setAutoPadding(false);
    const decrypted = Buffer.concat([
        decipher.update(Buffer.from(encryptedMsg, 'base64')),
        decipher.final(),
    ]);
    // Strip PKCS7 padding (block-size=32)
    const padLen = decrypted[decrypted.length - 1];
    const unpadded = decrypted.subarray(0, decrypted.length - padLen);
    // Skip 16 random bytes, read 4-byte big-endian message length
    const msgLen = unpadded.readUInt32BE(16);
    return unpadded.subarray(20, 20 + msgLen).toString('utf8');
}
// ── Signature verification ────────────────────────────────────────────────────
function verifyWeComSignature(token, timestamp, nonce, msg, signature) {
    const sorted = [token, timestamp, nonce, msg].sort().join('');
    const hash = createHash('sha1').update(sorted).digest('hex');
    return hash === signature;
}
// ── WeComChannel ──────────────────────────────────────────────────────────────
export class WeComChannel extends BaseChannel {
    name = 'wecom';
    // App (自建应用) credentials
    corpId = '';
    corpSecret = '';
    agentId = '';
    token = ''; // 消息接收 Token (for signature verification)
    encodingAESKey = ''; // 消息加解密密钥
    // 群机器人 Webhook URL (send-only mode)
    webhookUrl = '';
    // Callback HTTP server config
    callbackPort = 18890;
    // Access-token cache — stored AES-encrypted with a runtime session key
    // so the plaintext token is not visible in a heap dump.
    _encToken = ''; // encrypted token (base64)
    _encTokenIv = ''; // AES IV (base64)
    _tokenExpiresAt = 0;
    // Runtime-only session key — a random 32-byte key generated once per process start,
    // never persisted anywhere. Protects the token from heap-dump exposure.
    _sessionKey = (() => {
        const seed = randomBytes(32);
        return createHash('sha256').update(seed).digest();
    })();
    httpServer = null;
    _running = false;
    // ── Lifecycle ───────────────────────────────────────────────────────────────
    async start() {
        const cfg = config.channels.wecom;
        if (!cfg?.enabled) {
            this.log.info('WeCom not configured, skipping');
            return;
        }
        this.webhookUrl = cfg.webhookUrl ?? '';
        this.corpId = cfg.corpId ?? '';
        this.corpSecret = cfg.corpSecret ?? '';
        this.agentId = cfg.agentId ?? '';
        this.token = cfg.token ?? '';
        this.encodingAESKey = cfg.encodingAESKey ?? '';
        this.callbackPort = cfg.callbackPort ?? 18890;
        const hasAppCreds = this.corpId && this.corpSecret && this.agentId
            && this.token && this.encodingAESKey;
        if (hasAppCreds) {
            // Full bidirectional mode: start callback server + use app message API
            await this.startCallbackServer();
            this.log.info({ port: this.callbackPort }, 'WeCom channel started (app mode — bidirectional). ' +
                `Configure callback URL: http://<your-public-host>:${this.callbackPort}/wecom/callback`);
        }
        else if (this.webhookUrl) {
            // Webhook-only mode: send to group, cannot receive
            this._running = true;
            this.log.info('WeCom channel started (webhook/send-only mode)');
        }
        else {
            this.log.warn('WeCom: neither webhook URL nor full app credentials configured — channel inactive');
        }
    }
    async stop() {
        await new Promise((resolve) => {
            if (this.httpServer) {
                this.httpServer.close(() => resolve());
            }
            else {
                resolve();
            }
        });
        this._running = false;
        this.log.info('WeCom channel stopped');
    }
    isRunning() {
        return this._running;
    }
    // ── Callback HTTP server ────────────────────────────────────────────────────
    async startCallbackServer() {
        const app = express();
        // Parse body as raw Buffer for /wecom/callback (content-type is text/xml)
        app.use('/wecom/callback', express.raw({ type: '*/*' }));
        // GET — URL verification challenge (企业微信后台验证回调 URL 时调用)
        app.get('/wecom/callback', (req, res) => {
            const { msg_signature, timestamp, nonce, echostr } = req.query;
            if (!msg_signature || !timestamp || !nonce || !echostr) {
                res.status(400).send('missing params');
                return;
            }
            // Verify: SHA1(sort([token, timestamp, nonce, echostr]))
            if (!verifyWeComSignature(this.token, timestamp, nonce, echostr, msg_signature)) {
                this.log.warn('WeCom: URL verification signature mismatch');
                res.status(403).send('signature mismatch');
                return;
            }
            // echostr is encrypted — decrypt and return the plaintext to WeCom
            try {
                const plain = decryptWeComMsg(this.encodingAESKey, echostr);
                res.send(plain);
            }
            catch (err) {
                this.log.error({ err }, 'WeCom: failed to decrypt echostr during URL verification');
                res.status(500).send('decrypt error');
            }
        });
        // POST — incoming message from WeCom server
        app.post('/wecom/callback', async (req, res) => {
            // Respond immediately (WeCom expects response within 5 s)
            res.send('');
            try {
                const { msg_signature, timestamp, nonce } = req.query;
                const bodyBuf = req.body;
                const xmlStr = Buffer.isBuffer(bodyBuf) ? bodyBuf.toString('utf8') : String(bodyBuf);
                const outer = parseXml(xmlStr);
                const encryptedMsg = outer['Encrypt'];
                if (!encryptedMsg) {
                    this.log.warn('WeCom: no Encrypt field in callback body');
                    return;
                }
                // Verify message signature
                if (msg_signature && timestamp && nonce) {
                    if (!verifyWeComSignature(this.token, timestamp, nonce, encryptedMsg, msg_signature)) {
                        this.log.warn('WeCom: message signature verification failed — dropping message');
                        return;
                    }
                }
                // Decrypt and parse inner XML
                const plainXml = decryptWeComMsg(this.encodingAESKey, encryptedMsg);
                const msg = parseXml(plainXml);
                // Only handle user text messages
                if (msg['MsgType'] !== 'text') {
                    this.log.debug({ msgType: msg['MsgType'] }, 'WeCom: ignoring non-text message type');
                    return;
                }
                const userId = msg['FromUserName']?.trim() ?? '';
                const content = msg['Content']?.trim() ?? '';
                const msgId = msg['MsgId'] ?? nanoid();
                if (!userId || !content)
                    return;
                // allowedUsers check
                const allowed = config.channels.wecom?.allowedUsers;
                if (allowed && allowed.length > 0 && !allowed.includes(userId)) {
                    this.log.debug({ userId }, 'WeCom: user not in allowedUsers, ignoring');
                    return;
                }
                const incoming = {
                    id: msgId,
                    channel: 'wecom',
                    userId,
                    chatId: userId, // 1-on-1 app messages: chatId = userId
                    text: content,
                    timestamp: new Date(parseInt(msg['CreateTime'] ?? '0') * 1000),
                    raw: msg,
                };
                // handleMessage is non-blocking from WeCom's perspective (we already replied with '')
                await this.handleMessage(incoming);
            }
            catch (err) {
                this.log.error({ err }, 'WeCom: error processing incoming message');
            }
        });
        await new Promise((resolve, reject) => {
            this.httpServer = createHttpServer(app);
            this.httpServer.once('error', reject);
            this.httpServer.listen(this.callbackPort, '0.0.0.0', () => {
                this._running = true;
                resolve();
            });
        });
    }
    // ── Sending ─────────────────────────────────────────────────────────────────
    async send(message) {
        if (!message.text)
            return;
        const chunks = this.splitMessage(message.text, 2000);
        if (this.corpId && this.agentId) {
            // App mode: send to specific user via /message/send
            const toUser = message.chatId ?? '@all';
            for (const chunk of chunks) {
                try {
                    await this.sendViaApp(toUser, chunk);
                }
                catch (err) {
                    this.log.error({ err, toUser }, 'WeCom: sendViaApp failed');
                    throw err;
                }
            }
        }
        else if (this.webhookUrl) {
            // Webhook mode: send to group
            for (const chunk of chunks) {
                try {
                    await this.sendViaWebhook(chunk);
                }
                catch (err) {
                    this.log.error({ err }, 'WeCom: sendViaWebhook failed');
                    throw err;
                }
            }
        }
        else {
            this.log.warn('WeCom send() called but no send method configured');
        }
    }
    // ── Access token management ──────────────────────────────────────────────────
    storeToken(token) {
        const iv = randomBytes(16);
        const cipher = createCipheriv('aes-256-cbc', this._sessionKey, iv);
        this._encToken = Buffer.concat([
            cipher.update(token, 'utf8'), cipher.final(),
        ]).toString('base64');
        this._encTokenIv = iv.toString('base64');
    }
    loadToken() {
        if (!this._encToken)
            return '';
        const iv = Buffer.from(this._encTokenIv, 'base64');
        const decipher = createDecipheriv('aes-256-cbc', this._sessionKey, iv);
        return Buffer.concat([
            decipher.update(Buffer.from(this._encToken, 'base64')), decipher.final(),
        ]).toString('utf8');
    }
    async getAccessToken() {
        if (this._encToken && Date.now() < this._tokenExpiresAt) {
            return this.loadToken();
        }
        const url = `https://qyapi.weixin.qq.com/cgi-bin/gettoken` +
            `?corpid=${encodeURIComponent(this.corpId)}` +
            `&corpsecret=${encodeURIComponent(this.corpSecret)}`;
        const resp = await axios.get(url, { timeout: 10_000 });
        if (resp.data.errcode || !resp.data.access_token) {
            throw new Error(`WeCom gettoken error ${resp.data.errcode}: ${resp.data.errmsg}`);
        }
        this.storeToken(resp.data.access_token);
        // Cache for (expires_in − 5 min) to guarantee freshness
        this._tokenExpiresAt = Date.now() + ((resp.data.expires_in ?? 7200) - 300) * 1000;
        return this.loadToken();
    }
    async sendViaApp(toUser, content) {
        const token = await this.getAccessToken();
        const url = `https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=${token}`;
        const resp = await axios.post(url, {
            touser: toUser,
            msgtype: 'text',
            agentid: parseInt(this.agentId, 10),
            text: { content },
            safe: 0,
        }, { timeout: 10_000 });
        // 42001 = access token expired — refresh once and retry
        if (resp.data.errcode === 42001) {
            this._tokenExpiresAt = 0; // invalidate cache
            const newToken = await this.getAccessToken();
            const retry = await axios.post(`https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=${newToken}`, {
                touser: toUser,
                msgtype: 'text',
                agentid: parseInt(this.agentId, 10),
                text: { content },
                safe: 0,
            }, { timeout: 10_000 });
            if (retry.data.errcode !== 0) {
                throw new Error(`WeCom send error ${retry.data.errcode}: ${retry.data.errmsg}`);
            }
            return;
        }
        if (resp.data.errcode !== 0) {
            throw new Error(`WeCom send error ${resp.data.errcode}: ${resp.data.errmsg}`);
        }
    }
    async sendViaWebhook(content) {
        const resp = await axios.post(this.webhookUrl, { msgtype: 'text', text: { content } }, { timeout: 10_000 });
        if (resp.data.errcode !== 0) {
            throw new Error(`WeCom webhook error ${resp.data.errcode}: ${resp.data.errmsg}`);
        }
    }
    // ── Helpers ──────────────────────────────────────────────────────────────────
    splitMessage(text, maxLen) {
        if (text.length <= maxLen)
            return [text];
        const chunks = [];
        let remaining = text;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, maxLen);
            const lastNewline = chunk.lastIndexOf('\n');
            if (lastNewline > maxLen / 2)
                chunk = remaining.slice(0, lastNewline);
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }
        return chunks;
    }
}
//# sourceMappingURL=index.js.map