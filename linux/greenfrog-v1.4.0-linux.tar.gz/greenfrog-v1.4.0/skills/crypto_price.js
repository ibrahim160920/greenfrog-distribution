import { BaseSkill } from './base.js';
export class CryptoPriceSkill extends BaseSkill {
    definition = {
        name: 'crypto_price',
        description: 'Get cryptocurrency prices and market data (Bitcoin, Ethereum, and 200+ coins)',
        category: 'finance',
        parameters: [
            { name: 'coins', type: 'string', required: true, description: 'Coin IDs or symbols, comma-separated (e.g. "bitcoin,ethereum,solana" or "BTC,ETH")' },
            { name: 'currency', type: 'string', description: 'Fiat currency for price (default: usd)', default: 'usd' },
        ],
    };
    async execute(params, _ctx) {
        const coinsInput = params.coins.toLowerCase();
        const currency = params.currency ?? 'usd';
        // Normalize coin symbols to IDs
        const symbolMap = {
            btc: 'bitcoin', eth: 'ethereum', sol: 'solana', ada: 'cardano',
            dot: 'polkadot', bnb: 'binancecoin', xrp: 'ripple', matic: 'matic-network',
            avax: 'avalanche-2', link: 'chainlink', uni: 'uniswap', ltc: 'litecoin',
        };
        const coins = coinsInput.split(',').map((c) => {
            const clean = c.trim();
            return symbolMap[clean] ?? clean;
        });
        try {
            const url = `https://api.coingecko.com/api/v3/simple/price?ids=${coins.join(',')}&vs_currencies=${currency}&include_24hr_change=true&include_market_cap=true`;
            const res = await fetch(url);
            if (!res.ok)
                return this.err(`CoinGecko API error: ${res.status}`);
            const data = await res.json();
            if (!Object.keys(data).length) {
                return this.err(`No data found for coins: ${coins.join(', ')}. Try full names like "bitcoin,ethereum"`);
            }
            const lines = Object.entries(data).map(([coin, info]) => {
                const price = info[currency];
                const change = info[`${currency}_24h_change`];
                const mcap = info[`${currency}_market_cap`];
                const changeStr = change
                    ? `${change >= 0 ? '📈' : '📉'} ${change.toFixed(2)}%`
                    : '';
                const mcapStr = mcap
                    ? `  MktCap: $${(mcap / 1e9).toFixed(2)}B`
                    : '';
                const priceFormatted = price >= 1
                    ? price.toLocaleString('en-US', { style: 'currency', currency: currency.toUpperCase() })
                    : `${currency.toUpperCase()} ${price.toFixed(6)}`;
                return `• **${coin.charAt(0).toUpperCase() + coin.slice(1)}**: ${priceFormatted} ${changeStr}${mcapStr}`;
            });
            return this.text(`💰 **Crypto Prices (${currency.toUpperCase()})**\n\n${lines.join('\n')}`);
        }
        catch (err) {
            return this.err(`Crypto price error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=crypto_price.js.map