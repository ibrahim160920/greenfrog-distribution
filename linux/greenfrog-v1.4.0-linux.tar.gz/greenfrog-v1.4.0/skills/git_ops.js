import { spawnSync } from 'child_process';
import { resolve } from 'path';
import { homedir, tmpdir } from 'os';
import { BaseSkill } from './base.js';
// Restrict to safe roots — same pattern as file_ops.ts / coding_agent.ts
function getSafeRoots() {
    return [resolve(homedir()), resolve(process.cwd()), resolve(tmpdir())];
}
function isSafePath(p) {
    const resolved = resolve(p);
    return getSafeRoots().some((root) => resolved.startsWith(root + '/') || resolved.startsWith(root + '\\') || resolved === root);
}
export class GitOpsSkill extends BaseSkill {
    definition = {
        name: 'git',
        description: 'Git operations: status, log, diff, add, commit, push, pull, branch management',
        category: 'development',
        parameters: [
            {
                name: 'action',
                type: 'string',
                required: true,
                description: 'Git action',
                enum: ['status', 'log', 'diff', 'add', 'commit', 'push', 'pull', 'branch', 'checkout', 'stash', 'clone'],
            },
            { name: 'path', type: 'string', description: 'Repository path (defaults to current directory)' },
            { name: 'message', type: 'string', description: 'Commit message (for commit action)' },
            { name: 'branch', type: 'string', description: 'Branch name' },
            { name: 'files', type: 'string', description: 'Files to add (for add action, default: ".")' },
            { name: 'remote', type: 'string', description: 'Remote name (for push/pull, default: origin)' },
            { name: 'url', type: 'string', description: 'Repository URL (for clone action)' },
            { name: 'limit', type: 'number', description: 'Number of log entries (default: 10)' },
        ],
    };
    /**
     * Run git with an explicit arg list — avoids shell injection entirely.
     * spawnSync does NOT invoke a shell; each element is passed verbatim to the OS.
     */
    git(args, cwd) {
        const result = spawnSync('git', args, {
            cwd,
            encoding: 'utf8',
            timeout: 30_000,
            stdio: ['ignore', 'pipe', 'pipe'],
        });
        if (result.error)
            throw result.error;
        if (result.status !== 0) {
            throw new Error((result.stderr ?? result.stdout ?? '').trim() || `git exited with code ${result.status}`);
        }
        return (result.stdout ?? '').trim();
    }
    async execute(params, _ctx) {
        const rawPath = params.path ?? process.cwd();
        const cwd = resolve(rawPath);
        if (!isSafePath(cwd)) {
            return this.err(`Access denied: "${cwd}" is outside the allowed directories.`);
        }
        const limit = Math.max(1, Math.min(100, Number(params.limit ?? 10) || 10));
        try {
            switch (params.action) {
                case 'status': {
                    const status = this.git(['status'], cwd);
                    return this.text(`📋 **Git Status** (${cwd})\n\`\`\`\n${status}\n\`\`\``);
                }
                case 'log': {
                    const log = this.git(['log', '--oneline', `-${limit}`], cwd);
                    return this.text(`📜 **Git Log** (last ${limit} commits)\n\`\`\`\n${log}\n\`\`\``);
                }
                case 'diff': {
                    const diff = this.git(['diff'], cwd);
                    const staged = this.git(['diff', '--staged'], cwd);
                    const combined = [diff, staged].filter(Boolean).join('\n---\n');
                    return this.text(`📝 **Git Diff**\n\`\`\`diff\n${combined.slice(0, 3000) || 'No changes'}\n\`\`\``);
                }
                case 'add': {
                    // Split on whitespace so individual file paths stay separate args
                    const rawFiles = params.files ?? '.';
                    const fileArgs = rawFiles.split(/\s+/).filter(Boolean);
                    this.git(['add', ...fileArgs], cwd);
                    return this.text(`✅ Staged: ${rawFiles}`);
                }
                case 'commit': {
                    if (!params.message)
                        return this.err('commit message is required');
                    const output = this.git(['commit', '-m', params.message], cwd);
                    return this.text(`✅ **Committed!**\n\`\`\`\n${output}\n\`\`\``);
                }
                case 'push': {
                    const remote = params.remote ?? 'origin';
                    const branch = params.branch;
                    const args = branch ? ['push', remote, branch] : ['push', remote];
                    const output = this.git(args, cwd);
                    return this.text(`🚀 **Pushed!**\n\`\`\`\n${output || 'Push successful'}\n\`\`\``);
                }
                case 'pull': {
                    const remote = params.remote ?? 'origin';
                    const output = this.git(['pull', remote], cwd);
                    return this.text(`⬇️ **Pulled!**\n\`\`\`\n${output}\n\`\`\``);
                }
                case 'branch': {
                    const branches = this.git(['branch', '-a'], cwd);
                    return this.text(`🌿 **Branches:**\n\`\`\`\n${branches}\n\`\`\``);
                }
                case 'checkout': {
                    if (!params.branch)
                        return this.err('branch name is required');
                    const output = this.git(['checkout', params.branch], cwd);
                    return this.text(`✅ Checked out: ${params.branch}\n${output}`);
                }
                case 'stash': {
                    const output = this.git(['stash'], cwd);
                    return this.text(`📦 **Stashed!**\n${output}`);
                }
                case 'clone': {
                    if (!params.url)
                        return this.err('url is required');
                    // Validate URL scheme to prevent local-path or file:// abuse
                    const url = params.url;
                    if (!/^(https?|git|ssh):\/\//i.test(url)) {
                        return this.err(`Invalid repository URL. Only https://, http://, git://, and ssh:// are allowed.`);
                    }
                    const output = this.git(['clone', url], cwd);
                    return this.text(`✅ **Cloned!**\n${output}`);
                }
                default:
                    return this.err(`Unknown action: ${params.action}`);
            }
        }
        catch (err) {
            return this.err(`Git error: ${err instanceof Error ? err.message : String(err)}`);
        }
    }
}
//# sourceMappingURL=git_ops.js.map