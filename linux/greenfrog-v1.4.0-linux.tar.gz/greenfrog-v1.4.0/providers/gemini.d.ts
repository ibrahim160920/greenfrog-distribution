import type { ProviderRequest, ProviderResponse } from '../utils/types.js';
import { BaseProvider, type StreamingCall } from './base.js';
export declare class GeminiProvider extends BaseProvider {
    readonly name = "gemini";
    readonly defaultModel = "gemini-2.0-flash";
    private client;
    private model;
    private readonly safetySettings;
    constructor(apiKey: string, model?: string);
    chat(request: ProviderRequest): Promise<ProviderResponse>;
    chatStream(request: ProviderRequest): StreamingCall;
    isAvailable(): Promise<boolean>;
    listModels(): Promise<string[]>;
    private buildContents;
    private buildTools;
}
//# sourceMappingURL=gemini.d.ts.map