import type { ChannelName } from '../utils/types.js';
export interface ChallengeReflectionParams {
    workspaceId: string;
    challengedAgentId: string;
    userId: string;
    channel: ChannelName;
    taskTitle: string;
    taskDescription?: string | null;
    taskResult?: string | null;
    objections: string[];
    propagateToTeam?: boolean;
    /** Use a specific model/provider for the reflection LLM call (e.g. Haiku for low cost) */
    model?: string | null;
    provider?: string | null;
}
export declare function runChallengeReflectionSafe(params: ChallengeReflectionParams): Promise<void>;
//# sourceMappingURL=challenge_reflection.d.ts.map