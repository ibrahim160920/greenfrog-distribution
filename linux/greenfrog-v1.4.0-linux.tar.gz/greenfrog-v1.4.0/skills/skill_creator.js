import { writeFileSync, readFileSync, mkdirSync, existsSync, readdirSync } from 'fs';
import { join, resolve as resolvePath, dirname } from 'path';
import { fileURLToPath } from 'url';
import { createHash } from 'crypto';
import { Worker } from 'worker_threads';
import { z } from 'zod';
import { BaseSkill } from './base.js';
import { vetCode } from './vetter.js';
import { config } from '../config/index.js';
import { dockerSandbox } from '../sandbox/docker.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('skill-creator');
// ── Plugin manifest validation ──────────────────────────────────────────────
const PluginManifestSchema = z.object({
    name: z.string().regex(/^[a-z0-9_-]{1,50}$/),
    version: z.string().regex(/^\d+\.\d+\.\d+$/),
    description: z.string().max(500),
    author: z.string().max(100).optional(),
    skills: z.array(z.string()).optional(),
    permissions: z.array(z.enum(['network', 'filesystem', 'shell', 'memory'])).optional(),
    dependencies: z.record(z.string()).optional(),
    minGreenFrogVersion: z.string().optional(),
});
export function validatePluginManifest(manifest) {
    const result = PluginManifestSchema.safeParse(manifest);
    if (result.success)
        return { valid: true };
    return { valid: false, errors: result.error.errors.map(e => `${e.path.join('.')}: ${e.message}`) };
}
export function checkDependencies(deps) {
    const missing = [];
    for (const pkg of Object.keys(deps)) {
        const pkgPath = join(process.cwd(), 'node_modules', pkg);
        if (!existsSync(pkgPath))
            missing.push(pkg);
    }
    return { missing };
}
const MANIFEST_FILE = '.skill-manifest.json';
function sha256File(filePath) {
    return createHash('sha256').update(readFileSync(filePath)).digest('hex');
}
function readManifest(dir) {
    const p = join(dir, MANIFEST_FILE);
    if (!existsSync(p))
        return {};
    try {
        return JSON.parse(readFileSync(p, 'utf8'));
    }
    catch {
        return {};
    }
}
function writeManifest(dir, manifest) {
    writeFileSync(join(dir, MANIFEST_FILE), JSON.stringify(manifest, null, 2), 'utf8');
}
/** Record a skill file in the manifest after creation. */
export function registerSkillHash(dir, filename, filePath) {
    const manifest = readManifest(dir);
    manifest[filename] = { sha256: sha256File(filePath), createdAt: new Date().toISOString() };
    writeManifest(dir, manifest);
}
/**
 * Verify a skill file against the stored manifest.
 * Returns 'ok' | 'new' (not in manifest) | 'tampered' (hash mismatch).
 */
export function verifySkillHash(dir, filename, filePath) {
    const manifest = readManifest(dir);
    const entry = manifest[filename];
    if (!entry)
        return 'new';
    const actual = sha256File(filePath);
    return actual === entry.sha256 ? 'ok' : 'tampered';
}
const __dirname = dirname(fileURLToPath(import.meta.url));
const MAX_CONCURRENT_WORKERS = 3;
let activeWorkers = 0;
/**
 * Executes a custom skill in an isolated Worker thread.
 *
 * Security guarantees:
 *  - Worker thread's process.env is cleared (no API keys visible)
 *  - Memory capped at 64 MB (prevents resource exhaustion)
 *  - 10-second timeout prevents CPU exhaustion
 *  - Max 3 concurrent Workers prevents resource starvation
 */
function runInWorkerSandbox(filePath, params, ctxSafe, timeoutMs = 10_000) {
    return new Promise((resolve, reject) => {
        if (activeWorkers >= MAX_CONCURRENT_WORKERS) {
            reject(new Error('Too many concurrent skill executions. Try again shortly.'));
            return;
        }
        activeWorkers++;
        const workerPath = join(__dirname, 'custom_skill_worker.mjs');
        const worker = new Worker(workerPath, {
            workerData: { filePath, params, ctxSafe },
            resourceLimits: { maxOldGenerationSizeMb: 64, maxYoungGenerationSizeMb: 16 },
        });
        let done = false;
        const cleanup = () => { if (!done) {
            done = true;
            activeWorkers--;
        } };
        const timer = setTimeout(() => {
            worker.terminate();
            cleanup();
            reject(new Error(`Custom skill execution timed out after ${timeoutMs / 1000}s`));
        }, timeoutMs);
        worker.on('message', (msg) => {
            clearTimeout(timer);
            cleanup();
            if (msg.ok && msg.result) {
                resolve(msg.result);
            }
            else {
                reject(new Error(msg.error ?? 'Worker returned error'));
            }
        });
        worker.on('error', (err) => {
            clearTimeout(timer);
            cleanup();
            reject(err);
        });
        worker.on('exit', (code) => {
            clearTimeout(timer);
            cleanup();
            if (code !== 0)
                reject(new Error(`Worker exited with code ${code}`));
        });
    });
}
/**
 * Wraps a saved custom skill so its execute() call runs in an isolated sandbox.
 *
 * Isolation priority:
 *   1. Docker container (strongest — separate namespace, cgroups, no network)
 *   2. Worker thread (fallback when Docker unavailable)
 *
 * The skill's definition is loaded from the actual file (for LLM schema),
 * but execution is fully sandboxed either way.
 *
 * Exported so registry.ts can use it when loading custom skills on startup.
 */
export class SandboxedCustomSkill extends BaseSkill {
    definition;
    filePath;
    constructor(definition, filePath) {
        super();
        this.definition = definition;
        this.filePath = filePath;
    }
    async execute(params, ctx) {
        // Build a safe context — strip any sensitive fields before passing to sandbox
        const ctxSafe = {
            userId: ctx.userId,
            channel: ctx.channel,
            chatId: ctx.chatId,
            sessionId: ctx.sessionId,
        };
        try {
            // Prefer Docker container isolation
            if (await dockerSandbox.isAvailable()) {
                return await dockerSandbox.runCustomSkill(this.filePath, params, ctxSafe, 10_000);
            }
            // Fallback: Worker thread isolation
            return await runInWorkerSandbox(this.filePath, params, ctxSafe);
        }
        catch (err) {
            return this.err(`Sandboxed execution error: ${String(err)}`);
        }
    }
}
/**
 * skill_creator - The self-evolution skill!
 * Allows the AI to write new skills and register them at runtime.
 * Skills are saved as JavaScript files and hot-loaded immediately — no restart required.
 */
export class SkillCreatorSkill extends BaseSkill {
    definition = {
        name: 'skill_creator',
        description: `Create new skills/tools for GreenFrog. Write JavaScript (ESM) code that becomes a new persistent skill.
      The skill is saved to disk AND registered immediately — no restart required.
      Use this to extend your own capabilities!`,
        category: 'system',
        parameters: [
            { name: 'action', type: 'string', required: true, description: 'Action', enum: ['create', 'list_custom', 'delete'] },
            { name: 'skill_name', type: 'string', description: 'Name for the new skill (snake_case, e.g. my_skill)' },
            { name: 'description', type: 'string', description: 'What this skill does' },
            {
                name: 'code',
                type: 'string',
                description: 'Full JavaScript (ESM) implementation of the skill extending BaseSkill. ' +
                    'Import from \'../skills/base.js\'. The class must export a default or named export that extends BaseSkill.',
            },
        ],
        examples: [
            'Create a skill that checks cryptocurrency prices',
            'Create a skill to post to Twitter',
            'Create a skill to manage my todo list in Notion',
        ],
    };
    async execute(params, _ctx) {
        const customSkillsDir = join(config.dataDir, 'custom_skills');
        switch (params.action) {
            case 'create': {
                if (!params.skill_name || !params.code) {
                    return this.err('skill_name and code are required');
                }
                // Sanitize name — only lowercase letters, digits, underscores
                const name = params.skill_name.replace(/[^a-z0-9_]/gi, '_').toLowerCase();
                mkdirSync(customSkillsDir, { recursive: true });
                // Save as .js — can be directly imported at runtime without a TypeScript loader
                const filePath = join(customSkillsDir, `${name}.js`);
                let code = params.code;
                if (!code.includes('extends BaseSkill')) {
                    code = this.wrapSimpleCode(name, params.description ?? '', code);
                }
                // Security scan — reject high/critical risk code
                const vetResult = vetCode(code);
                if (vetResult.blocked) {
                    const topFindings = vetResult.findings.slice(0, 3)
                        .map(f => `  [${f.level.toUpperCase()}] ${f.rule}: ${f.detail}`)
                        .join('\n');
                    return this.err(`⚠️ Skill creation blocked (risk: ${vetResult.risk}, score: ${vetResult.score}/100)\n` +
                        `${vetResult.summary}\n\nFindings:\n${topFindings}\n\n` +
                        `If this is intentional, create the file manually in the custom_skills directory.`);
                }
                writeFileSync(filePath, code, 'utf8');
                // Record the SHA-256 hash in the manifest so integrity can be verified on next load
                registerSkillHash(customSkillsDir, `${name}.js`, filePath);
                // ── Hot-load: import definition, then register sandboxed wrapper ─────
                let hotLoaded = false;
                try {
                    // Import the module only to extract the skill's definition (schema)
                    // so the LLM can describe it. Execution will go through Worker sandbox.
                    const fileUrl = `file://${filePath.replace(/\\/g, '/')}?t=${Date.now()}`;
                    const mod = await import(fileUrl);
                    const { skillRegistry } = await import('./registry.js');
                    for (const value of Object.values(mod)) {
                        if (typeof value === 'function' &&
                            typeof value.prototype?.definition !== 'undefined') {
                            // Instantiate once just to read the definition
                            const instance = new value();
                            // Register the sandboxed wrapper instead of the raw instance
                            const sandboxed = new SandboxedCustomSkill(instance.definition, filePath);
                            skillRegistry.register(sandboxed);
                            hotLoaded = true;
                            break;
                        }
                    }
                    // Fallback: if we can't extract a definition, create a sandboxed skill
                    // with a minimal definition based on name/description params.
                    if (!hotLoaded) {
                        const minimalDefinition = {
                            name,
                            description: params.description ?? `Custom skill: ${name}`,
                            category: 'custom',
                            parameters: [],
                        };
                        const { skillRegistry } = await import('./registry.js');
                        skillRegistry.register(new SandboxedCustomSkill(minimalDefinition, filePath));
                        hotLoaded = true;
                    }
                }
                catch (err) {
                    // Hot-load failed (e.g. syntax error) — skill is saved but requires restart
                    return this.text([
                        `Skill saved but could NOT be hot-loaded: ${String(err)}`,
                        `Saved to: ${filePath}`,
                        `The skill will be available after restart.`,
                    ].join('\n'));
                }
                return this.text([
                    `✅ **New skill created: \`${name}\`**`,
                    `📁 Saved to: ${filePath}`,
                    `📝 Description: ${params.description ?? 'Custom skill'}`,
                    hotLoaded ? `⚡ Registered immediately — ready to use now!` : `♻️ Requires restart to activate.`,
                ].join('\n'));
            }
            case 'list_custom': {
                if (!existsSync(customSkillsDir)) {
                    return this.text('No custom skills created yet. Use skill_creator to create your first custom skill!');
                }
                const files = readdirSync(customSkillsDir).filter((f) => f.endsWith('.js'));
                if (files.length === 0) {
                    return this.text('No custom skills found.');
                }
                const lines = files.map((f) => `• \`${f.replace('.js', '')}\` — ${join(customSkillsDir, f)}`);
                return this.text(`🔧 **Custom Skills (${files.length}):**\n\n${lines.join('\n')}`);
            }
            case 'delete': {
                if (!params.skill_name)
                    return this.err('skill_name is required');
                const name = params.skill_name.replace(/[^a-z0-9_]/gi, '_').toLowerCase();
                const filePath = join(customSkillsDir, `${name}.js`);
                // Path traversal guard
                if (!resolvePath(filePath).startsWith(resolvePath(customSkillsDir))) {
                    return this.err('Invalid skill name');
                }
                if (!existsSync(filePath))
                    return this.err(`Custom skill "${name}" not found`);
                const { unlinkSync } = await import('fs');
                unlinkSync(filePath);
                return this.text(`🗑 Deleted custom skill: ${name}`);
            }
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
    /**
     * Wrap a simple code snippet into a full BaseSkill subclass.
     * Generates JavaScript (ESM) — no TypeScript type annotations.
     */
    wrapSimpleCode(name, description, code) {
        const className = name.split('_')
            .map((w) => (w[0] ?? '').toUpperCase() + w.slice(1))
            .join('') + 'Skill';
        return `import { BaseSkill } from '../skills/base.js';

export class ${className} extends BaseSkill {
  definition = {
    name: '${name}',
    description: '${description.replace(/'/g, "\\'")}',
    category: 'custom',
    parameters: [],
  };

  async execute(params, ctx) {
    ${code}
  }
}
`;
    }
}
//# sourceMappingURL=skill_creator.js.map