/**
 * verifier.ts — Inheritance bundle signature verification.
 *
 * Verifies Ed25519 signatures on release manifests using the
 * mother-body's public key (distributed with child runtime).
 *
 * Verification is mandatory before any inheritance bundle is applied.
 * A bundle without a valid signature is rejected — no override.
 */
import { type ReleaseManifest } from './manifest.js';
export interface VerificationResult {
    ok: boolean;
    reason?: string;
}
/**
 * Verify the Ed25519 signature on a release manifest.
 *
 * @param manifest  Parsed manifest (must include signature field)
 * @param publicKeyPath  Path to mother-body Ed25519 public key PEM (optional override)
 */
export declare function verifyManifestSignature(manifest: ReleaseManifest, publicKeyPath?: string): VerificationResult;
/**
 * Verify that downloaded bundle content matches the hash declared in the manifest.
 */
export declare function verifyBundleHash(content: Buffer, manifest: ReleaseManifest): VerificationResult;
//# sourceMappingURL=verifier.d.ts.map