/**
 * agent_heartbeat.ts
 *
 * In-memory heartbeat registry for core runtime actors.
 * Each actor (agent-loop, scheduler, workflow-runner) calls touchHeartbeat()
 * after completing real work. Status is computed on read — no background timer needed.
 *
 * Thresholds:
 *   healthy  = last heartbeat < 2 min ago
 *   stale    = 2–10 min ago
 *   dead     = > 10 min ago (or never seen)
 */
export type HeartbeatStatus = 'healthy' | 'stale' | 'dead';
export interface HeartbeatEntry {
    id: string;
    name: string;
    source: string;
    lastHeartbeatAt: number;
    lastSuccessAt: number | null;
    lastError: string | null;
    status: HeartbeatStatus;
}
/**
 * Record a heartbeat from a runtime actor.
 * @param id     Stable actor identifier (e.g. 'agent-loop')
 * @param name   Human-readable name (e.g. 'Agent Loop')
 * @param source Optional extra context (e.g. userId, workflowId)
 * @param error  If this beat is recording a failure, pass the error string
 */
export declare function touchHeartbeat(id: string, name: string, source?: string, error?: string): void;
/**
 * Return all registered heartbeat entries with freshly-computed status.
 */
export declare function getHeartbeats(): HeartbeatEntry[];
//# sourceMappingURL=agent_heartbeat.d.ts.map