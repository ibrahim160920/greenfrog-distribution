import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export interface VetFinding {
    level: 'critical' | 'high' | 'medium' | 'low';
    rule: string;
    detail: string;
    line?: number;
}
export interface VetResult {
    risk: 'safe' | 'low' | 'medium' | 'high' | 'critical';
    score: number;
    blocked: boolean;
    findings: VetFinding[];
    summary: string;
}
export declare function vetCode(code: string): VetResult;
export declare class VetterSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=vetter.d.ts.map