/**
 * Database factory — returns PostgresMemoryStore when config.database.url is set,
 * otherwise falls back to the SQLite MemoryStore.
 */
import { config } from '../config/index.js';
export async function createStore() {
    if (config.database?.url) {
        const { PostgresMemoryStore } = await import('./postgres.js');
        const store = new PostgresMemoryStore(config.database.url, config.database.poolMax ?? 10, config.database.idleTimeoutMs ?? 30_000);
        await store.init();
        return store;
    }
    // SQLite fallback — wrap synchronous MemoryStore in an async adapter
    const { MemoryStore } = await import('../memory/store.js');
    const sqlite = new MemoryStore();
    await sqlite.init();
    // Proxy: every method call is wrapped in Promise.resolve() so the sync store
    // satisfies the async IMemoryStore interface without modifying store.ts.
    return new Proxy(sqlite, {
        get(target, prop) {
            const val = target[prop];
            if (typeof val !== 'function')
                return val;
            return (...args) => Promise.resolve(val.apply(target, args));
        },
    });
}
//# sourceMappingURL=index.js.map