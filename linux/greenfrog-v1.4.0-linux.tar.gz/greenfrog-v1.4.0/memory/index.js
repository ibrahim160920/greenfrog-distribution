export { MemoryStore, memoryStore, setMemoryStore } from './store.js';
export { BM25Index } from './bm25.js';
export { scheduleMemoryExtraction } from './extractor.js';
export { compressBehavioralRulesIfNeeded, COMPRESS_THRESHOLD } from './rule_compressor.js';
export { GLOBAL_RULE_LIBRARY_WORKSPACE_ID } from './constants.js';
export { resolveMemoryScope, setScopedMemoryForContext, getScopedMemoryForContext, getAllScopedMemoryForContext, deleteScopedMemoryForContext, searchScopedMemoryForContext, searchScopedSemanticForContext, } from './scoped.js';
/**
 * Convenience helpers for managing per-user memory
 */
import { memoryStore } from './store.js';
import { getAllScopedMemoryForContext, searchScopedSemanticForContext } from './scoped.js';
import { compressBehavioralRulesIfNeeded, COMPRESS_THRESHOLD } from './rule_compressor.js';
import { GLOBAL_RULE_LIBRARY_WORKSPACE_ID } from './constants.js';
export async function remember(userId, channel, key, value) {
    await memoryStore.setMemory(userId, channel, key, value, 90);
}
export async function recall(userId, channel, key) {
    return memoryStore.getMemory(userId, channel, key);
}
export async function forget(userId, channel, key) {
    return memoryStore.deleteMemory(userId, channel, key);
}
export async function allMemory(userId, channel) {
    return memoryStore.getAllMemory(userId, channel);
}
/**
 * Build a memory summary enriched with semantically relevant entries for
 * the current query.  Combines recency (up to 10 recent entries) with
 * semantic relevance (up to 5 TF-IDF hits for the query).
 *
 * Also injects:
 *   - Structured entity context (people, projects, tasks, events)
 *   - Pending tasks with deadlines (proactive reminder)
 */
export async function buildContextualMemorySummary(userId, channel, query) {
    return buildContextualMemorySummaryForContext({ userId, channel }, query);
}
export async function buildContextualMemorySummaryForContext(ctx, query) {
    const parts = [];
    // ── 1. User facts (flat KV) ───────────────────────────────────────────────
    const all = await getAllScopedMemoryForContext(ctx);
    const allEntries = Object.entries(all);
    if (allEntries.length > 0) {
        const recent = new Set(allEntries.slice(-10).map(([k]) => k));
        memoryStore.warmQueryEmbedding(query).catch(() => { });
        const semantic = await searchScopedSemanticForContext(ctx, query, 5);
        const relevantKeys = new Set(semantic.map((e) => e.key));
        const combined = [...new Set([...relevantKeys, ...recent])].slice(0, 20);
        const lines = combined
            .map((k) => all[k] ? `- ${k}: ${all[k]}` : null)
            .filter(Boolean)
            .join('\n');
        if (lines)
            parts.push(`## What I remember about you:\n${lines}`);
    }
    // ── 2. Entity context (Ontology) ─────────────────────────────────────────
    const entitySection = await buildEntityContextForScope(ctx, query);
    if (entitySection)
        parts.push(entitySection);
    // ── 3. Pending tasks / upcoming events ───────────────────────────────────
    const taskSection = await buildPendingTasksContextForScope(ctx);
    if (taskSection)
        parts.push(taskSection);
    // ── 4. Learned behavioral rules ──────────────────────────────────────────
    const rulesSection = await buildBehavioralRulesContextForScope(ctx);
    if (rulesSection)
        parts.push(rulesSection);
    return parts.length > 0 ? '\n\n' + parts.join('\n\n') : '';
}
/** Inject learned behavioral rules into system prompt */
async function buildBehavioralRulesContext(userId, channel) {
    const rules = await memoryStore.getBehavioralRules(userId, channel, 50);
    if (rules.length === 0)
        return '';
    const CATEGORY_LABEL = {
        style: '写作风格', format: '格式', content: '内容', tone: '语气', workflow: '工作流程',
    };
    const lines = rules.map((r) => {
        const label = CATEGORY_LABEL[r.category] ?? r.category;
        const conf = r.confidence >= 80 ? '★★★' : r.confidence >= 60 ? '★★' : '★';
        return `- [${label}${conf}] ${r.rule}`;
    });
    return `## My learned preferences for you (follow these strictly):\n${lines.join('\n')}`;
}
async function buildBehavioralRulesContextForScope(ctx) {
    const scope = ctx.workspaceId || ctx.agentId
        ? { userId: ctx.userId, channel: ctx.channel, workspaceId: ctx.workspaceId, agentId: ctx.agentId }
        : null;
    // Cap at COMPRESS_THRESHOLD per source to bound prompt size.
    // Rules are ordered by confidence DESC, evidence_count DESC so we get the best ones first.
    const localRules = scope
        ? await memoryStore.getScopedBehavioralRules(scope, COMPRESS_THRESHOLD)
        : await memoryStore.getBehavioralRules(ctx.userId, ctx.channel, COMPRESS_THRESHOLD);
    const libraryRules = ctx.workspaceId && ctx.workspaceId !== GLOBAL_RULE_LIBRARY_WORKSPACE_ID
        ? await memoryStore.getScopedBehavioralRules({
            userId: ctx.userId,
            channel: ctx.channel,
            workspaceId: GLOBAL_RULE_LIBRARY_WORKSPACE_ID,
        }, COMPRESS_THRESHOLD)
        : [];
    const rules = [...localRules];
    for (const libraryRule of libraryRules) {
        if (rules.some((rule) => rule.rule === libraryRule.rule))
            continue;
        rules.push(libraryRule);
        if (rules.length >= COMPRESS_THRESHOLD)
            break; // hard cap on combined set
    }
    // Trigger background compression if local scope has grown beyond threshold.
    // Fire-and-forget: never blocks the response path.
    const effectiveScope = scope ?? { userId: ctx.userId, channel: ctx.channel };
    if (localRules.length >= COMPRESS_THRESHOLD) {
        compressBehavioralRulesIfNeeded(effectiveScope).catch(() => { });
    }
    if (rules.length === 0)
        return '';
    const CATEGORY_LABEL = {
        style: '鍐欎綔椋庢牸', format: '鏍煎紡', content: '鍐呭', tone: '璇皵', workflow: '宸ヤ綔娴佺▼',
    };
    const lines = rules.map((r) => {
        const label = CATEGORY_LABEL[r.category] ?? r.category;
        const conf = r.confidence >= 80 ? '鈽呪槄鈽?' : r.confidence >= 60 ? '鈽呪槄' : '鈽?';
        return `- [${label}${conf}] ${r.rule}`;
    });
    return `## My learned preferences for you (follow these strictly):\n${lines.join('\n')}`;
}
/** Format relevant entities for system prompt injection */
async function buildEntityContext(userId, channel, query) {
    const recent = await memoryStore.getRecentEntities(userId, channel, 12);
    const searched = query.length > 3 ? await memoryStore.searchEntities(userId, channel, query, 6) : [];
    const seen = new Set();
    const entities = [...searched, ...recent].filter((e) => {
        if (seen.has(e.name))
            return false;
        seen.add(e.name);
        return true;
    }).slice(0, 15);
    if (entities.length === 0)
        return '';
    const TYPE_ICON = {
        person: '👤', project: '📁', task: '✅', event: '📅', organization: '🏢', concept: '💡',
    };
    const lines = entities.map((e) => {
        const icon = TYPE_ICON[e.type] ?? '•';
        const attrsStr = Object.entries(e.attributes).map(([k, v]) => `${k}: ${v}`).join(', ');
        const relsStr = e.relations && e.relations.length > 0
            ? ` | relations: ${e.relations.map((r) => `${r.type} ${r.target}`).join(', ')}`
            : '';
        return `${icon} [${e.type}] **${e.name}**${attrsStr ? ` — ${attrsStr}` : ''}${relsStr}`;
    });
    return `## People, projects & tasks I know about:\n${lines.join('\n')}`;
}
async function buildEntityContextForScope(ctx, query) {
    const scope = ctx.workspaceId || ctx.agentId
        ? { userId: ctx.userId, channel: ctx.channel, workspaceId: ctx.workspaceId, agentId: ctx.agentId }
        : null;
    const recent = scope
        ? await memoryStore.getRecentScopedEntities(scope, 12)
        : await memoryStore.getRecentEntities(ctx.userId, ctx.channel, 12);
    const searched = query.length > 3
        ? scope
            ? await memoryStore.searchScopedEntities(scope, query, 6)
            : await memoryStore.searchEntities(ctx.userId, ctx.channel, query, 6)
        : [];
    const seen = new Set();
    const entities = [...searched, ...recent].filter((e) => {
        if (seen.has(e.name))
            return false;
        seen.add(e.name);
        return true;
    }).slice(0, 15);
    if (entities.length === 0)
        return '';
    const TYPE_ICON = {
        person: '馃懁', project: '馃搧', task: '鉁?', event: '馃搮', organization: '馃彚', concept: '馃挕',
    };
    const lines = entities.map((e) => {
        const icon = TYPE_ICON[e.type] ?? '鈥?';
        const attrsStr = Object.entries(e.attributes).map(([k, v]) => `${k}: ${v}`).join(', ');
        const relsStr = e.relations && e.relations.length > 0
            ? ` | relations: ${e.relations.map((r) => `${r.type} ${r.target}`).join(', ')}`
            : '';
        return `${icon} [${e.type}] **${e.name}**${attrsStr ? ` 鈥?${attrsStr}` : ''}${relsStr}`;
    });
    return `## People, projects & tasks I know about:\n${lines.join('\n')}`;
}
/** Inject pending tasks (task entities not marked done) */
async function buildPendingTasksContext(userId, channel) {
    const tasks = await memoryStore.getPendingTasks(userId, channel);
    if (tasks.length === 0)
        return '';
    const now = Date.now();
    const lines = tasks.slice(0, 8).map((t) => {
        const deadline = t.attributes['deadline'] ?? t.attributes['due'] ?? '';
        const priority = t.attributes['priority'] ?? '';
        const assignee = t.relations?.find((r) => r.type === 'assigned_to')?.target ?? '';
        const parts = [t.name];
        if (priority)
            parts.push(`[${priority}]`);
        if (deadline) {
            const deadlineMs = Date.parse(deadline);
            if (!isNaN(deadlineMs) && deadlineMs < now) {
                parts.push(`⚠️ 已逾期 (${deadline})`);
            }
            else {
                parts.push(`截止: ${deadline}`);
            }
        }
        if (assignee)
            parts.push(`→ ${assignee}`);
        return `- ${parts.join(' ')}`;
    });
    return `## Pending tasks (proactively remind user if relevant):\n${lines.join('\n')}`;
}
async function buildPendingTasksContextForScope(ctx) {
    const scope = ctx.workspaceId || ctx.agentId
        ? { userId: ctx.userId, channel: ctx.channel, workspaceId: ctx.workspaceId, agentId: ctx.agentId }
        : null;
    const tasks = scope
        ? await memoryStore.getPendingScopedTasks(scope)
        : await memoryStore.getPendingTasks(ctx.userId, ctx.channel);
    if (tasks.length === 0)
        return '';
    const now = Date.now();
    const lines = tasks.slice(0, 8).map((t) => {
        const deadline = t.attributes['deadline'] ?? t.attributes['due'] ?? '';
        const priority = t.attributes['priority'] ?? '';
        const assignee = t.relations?.find((r) => r.type === 'assigned_to')?.target ?? '';
        const parts = [t.name];
        if (priority)
            parts.push(`[${priority}]`);
        if (deadline) {
            const deadlineMs = Date.parse(deadline);
            if (!isNaN(deadlineMs) && deadlineMs < now) {
                parts.push(`鈿狅笍 宸查€炬湡 (${deadline})`);
            }
            else {
                parts.push(`鎴: ${deadline}`);
            }
        }
        if (assignee)
            parts.push(`鈫?${assignee}`);
        return `- ${parts.join(' ')}`;
    });
    return `## Pending tasks (proactively remind user if relevant):\n${lines.join('\n')}`;
}
//# sourceMappingURL=index.js.map