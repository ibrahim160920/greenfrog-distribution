import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class TodoSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    private getTodos;
    private saveTodos;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=todo.d.ts.map