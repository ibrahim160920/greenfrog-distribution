import { createClient, RoomEvent } from 'matrix-js-sdk';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { ChannelError } from '../../utils/errors.js';
import { config } from '../../config/index.js';
export class MatrixChannel extends BaseChannel {
    name = 'matrix';
    matrixClient = null;
    _running = false;
    _reconnectTimer = null;
    _reconnectAttempts = 0;
    static MAX_RECONNECT_DELAY_MS = 60_000;
    _homeserverUrl = '';
    _accessToken = '';
    async start() {
        const cfg = config.channels.matrix;
        if (!cfg?.enabled || !cfg.homeserverUrl || !cfg.accessToken) {
            this.log.info('Matrix not configured, skipping');
            return;
        }
        this._homeserverUrl = cfg.homeserverUrl;
        this._accessToken = cfg.accessToken;
        await this.connect(cfg.homeserverUrl, cfg.accessToken, cfg.allowedUsers ?? []);
    }
    async connect(homeserverUrl, accessToken, allowedUsers) {
        this.matrixClient = createClient({ baseUrl: homeserverUrl, accessToken });
        this.matrixClient.on(RoomEvent.Timeline, (event, room, toStartOfTimeline) => {
            if (toStartOfTimeline)
                return; // Skip historical events on initial sync
            if (event.getType() !== 'm.room.message')
                return;
            if (event.getSender() === this.matrixClient?.getUserId())
                return; // Skip own messages
            const content = event.getContent();
            if (content.msgtype !== 'm.text')
                return;
            const text = (content.body ?? '').trim();
            if (!text)
                return;
            const userId = event.getSender() ?? 'unknown';
            const chatId = event.getRoomId() ?? room?.roomId ?? nanoid();
            if (allowedUsers.length > 0 && !allowedUsers.includes(userId)) {
                this.log.debug({ userId }, 'Matrix: user not in allowedUsers, ignoring');
                return;
            }
            const msg = {
                id: event.getId() ?? nanoid(),
                channel: 'matrix',
                userId,
                username: room?.getMember(userId)?.name ?? userId,
                chatId,
                text,
                timestamp: new Date(event.getTs()),
                raw: event,
            };
            this.handleMessage(msg).catch((err) => {
                this.log.error({ err }, 'Matrix: error handling message');
            });
        });
        this.matrixClient.on('Session.logged_out', () => {
            this.log.warn('Matrix session logged out');
            this._running = false;
        });
        try {
            await this.matrixClient.startClient({ initialSyncLimit: 10 });
            this._running = true;
            this._reconnectAttempts = 0;
            this.log.info('Matrix channel started');
        }
        catch (err) {
            this.log.error({ err }, 'Matrix: failed to start client');
            this.scheduleReconnect(homeserverUrl, accessToken, allowedUsers);
        }
    }
    scheduleReconnect(homeserverUrl, accessToken, allowedUsers) {
        if (this._reconnectTimer)
            return;
        const delay = Math.min(1000 * Math.pow(2, this._reconnectAttempts), MatrixChannel.MAX_RECONNECT_DELAY_MS);
        this._reconnectAttempts++;
        this.log.info({ delay, attempt: this._reconnectAttempts }, 'Scheduling Matrix reconnect');
        this._reconnectTimer = setTimeout(async () => {
            this._reconnectTimer = null;
            try {
                await this.connect(homeserverUrl, accessToken, allowedUsers);
            }
            catch (err) {
                this.log.error({ err }, 'Matrix reconnect failed');
                this.scheduleReconnect(homeserverUrl, accessToken, allowedUsers);
            }
        }, delay);
    }
    async stop() {
        if (this._reconnectTimer) {
            clearTimeout(this._reconnectTimer);
            this._reconnectTimer = null;
        }
        try {
            this.matrixClient?.stopClient();
        }
        catch { /* ignore */ }
        this._running = false;
        this.log.info('Matrix channel stopped');
    }
    async send(message) {
        if (!this.matrixClient || !message.chatId)
            return;
        const chunks = this.splitMessage(message.text ?? '', 32768);
        for (const chunk of chunks) {
            try {
                await this.matrixClient.sendTextMessage(message.chatId, chunk);
            }
            catch (err) {
                throw new ChannelError(`Matrix send error: ${String(err)}`, 'matrix');
            }
        }
    }
    isRunning() {
        return this._running;
    }
    splitMessage(text, maxLen) {
        if (text.length <= maxLen)
            return [text];
        const chunks = [];
        let remaining = text;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, maxLen);
            const lastNewline = chunk.lastIndexOf('\n');
            if (lastNewline > maxLen / 2)
                chunk = remaining.slice(0, lastNewline);
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }
        return chunks;
    }
}
//# sourceMappingURL=index.js.map