import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
const PAPER_SYSTEM_ZH = `你是一位资深的学术论文写作专家，具备丰富的中文学术论文撰写和修改经验。
你熟悉各类学术期刊和会议的投稿规范，能够撰写结构严谨、逻辑清晰、语言规范的学术论文。
写作原则：论点明确、论据充分、方法科学、数据可靠、结论合理。`;
const PAPER_SYSTEM_EN = `You are a senior academic writing expert with extensive experience in writing and revising English academic papers.
You are familiar with the submission requirements of various academic journals and conferences, and can write well-structured, logically clear, and linguistically precise academic papers.
Writing principles: clear arguments, sufficient evidence, scientific methods, reliable data, and reasonable conclusions.`;
export class PaperWriterSkill extends BaseSkill {
    definition = {
        name: 'paper_writer',
        description: '学术论文撰写与修改。支持撰写期刊论文/会议论文/学位论文框架，对草稿进行修改完善，对语言进行学术润色，以及提供专业审稿意见。支持中英文。',
        category: 'professional',
        parameters: [
            { name: 'action', type: 'string', required: true, description: '操作类型：write=撰写论文，revise=修改完善，polish=语言润色，review=审稿意见', enum: ['write', 'revise', 'polish', 'review'] },
            { name: 'topic', type: 'string', required: true, description: '论文主题或标题' },
            { name: 'field', type: 'string', required: true, description: '学科领域，如：计算机科学、电子工程、材料科学、医学等' },
            { name: 'type', type: 'string', required: false, description: '论文类型：journal=期刊论文，conference=会议论文，thesis=学位论文，report=研究报告', default: 'journal', enum: ['journal', 'conference', 'thesis', 'report'] },
            { name: 'content', type: 'string', required: false, description: '论文内容/草稿（revise/polish/review时必需；write时可提供研究要点）' },
            { name: 'requirements', type: 'string', required: false, description: '期刊/会议要求，如字数限制、格式规范、特殊要求等' },
            { name: 'language', type: 'string', required: false, description: '语言：zh=中文，en=英文', default: 'zh', enum: ['zh', 'en'] },
            { name: 'section', type: 'string', required: false, description: '指定章节（可选）：abstract/intro/method/result/discussion/conclusion/all', default: 'all' },
        ],
        examples: [
            'paper_writer action=write topic="基于Transformer的中文命名实体识别方法" field="自然语言处理" type=journal language=zh',
            'paper_writer action=polish topic="Deep Learning for Medical Image Segmentation" field="Medical AI" content="[论文草稿]" language=en',
            'paper_writer action=review topic="新型锂电池材料研究" field="材料科学" content="[论文全文]"',
        ],
    };
    async execute(params, _ctx) {
        const action = String(params.action ?? '').trim();
        const topic = String(params.topic ?? '').trim();
        const field = String(params.field ?? '').trim();
        const type = String(params.type ?? 'journal').trim();
        const content = String(params.content ?? '').trim();
        const requirements = String(params.requirements ?? '').trim();
        const language = String(params.language ?? 'zh').trim();
        const section = String(params.section ?? 'all').trim();
        if (!action)
            return this.err('请指定操作类型：write、revise、polish 或 review');
        if (!topic)
            return this.err('请提供论文主题');
        if (!field)
            return this.err('请提供学科领域');
        const isEn = language === 'en';
        const systemPrompt = isEn ? PAPER_SYSTEM_EN : PAPER_SYSTEM_ZH;
        switch (action) {
            case 'write': return this.writePaper(topic, field, type, content, requirements, section, isEn, systemPrompt);
            case 'revise':
                if (!content)
                    return this.err('修改模式需要提供论文草稿（content参数）');
                return this.revisePaper(topic, field, content, requirements, section, isEn, systemPrompt);
            case 'polish':
                if (!content)
                    return this.err('润色模式需要提供论文内容（content参数）');
                return this.polishPaper(topic, content, section, isEn, systemPrompt);
            case 'review':
                if (!content)
                    return this.err('审稿模式需要提供论文内容（content参数）');
                return this.reviewPaper(topic, field, type, content, isEn, systemPrompt);
            default: return this.err(`不支持的操作类型：${action}`);
        }
    }
    async writePaper(topic, field, type, content, requirements, section, isEn, systemPrompt) {
        const typeLabel = { journal: isEn ? 'journal paper' : '期刊论文', conference: isEn ? 'conference paper' : '会议论文', thesis: isEn ? 'thesis' : '学位论文', report: isEn ? 'research report' : '研究报告' }[type] ?? (isEn ? 'paper' : '论文');
        const reqLine = requirements ? (isEn ? `\nRequirements: ${requirements}` : `\n投稿要求：${requirements}`) : '';
        const contentLine = content ? (isEn ? `\nKey points/outline provided:\n${content}` : `\n研究要点/大纲：\n${content}`) : '';
        const sectionFilter = section !== 'all' ? (isEn ? `\nPlease write only the "${section}" section.` : `\n请只撰写"${section}"章节。`) : '';
        const prompt = isEn
            ? `Please write a complete ${typeLabel} on the following topic:

Topic: ${topic}
Field: ${field}${reqLine}${contentLine}${sectionFilter}

Please output the complete paper with the following structure:

# ${topic}

## Abstract
[150-250 words, covering background, methods, results, and conclusions]

**Keywords:** [5-8 keywords]

## 1. Introduction
[Background, motivation, research gap, contributions, paper organization]

## 2. Related Work
[Review of relevant literature, comparison with existing methods]

## 3. Methodology
[Detailed description of proposed method/approach]

## 4. Experiments / Results
[Experimental setup, datasets, evaluation metrics, results and analysis]

## 5. Discussion
[Analysis of results, limitations, implications]

## 6. Conclusion
[Summary of contributions, future work]

## References
[List 10-15 representative references in standard format]`
            : `请撰写以下主题的完整${typeLabel}：

论文主题：${topic}
学科领域：${field}${reqLine}${contentLine}${sectionFilter}

请按以下结构输出完整论文：

# ${topic}

## 摘要
[200-300字，涵盖研究背景、方法、结果和结论]

**关键词：** [5-8个关键词]

## 1. 引言
[研究背景、研究意义、国内外研究现状、研究内容与贡献、论文结构]

## 2. 相关工作
[相关文献综述，与现有方法的对比分析]

## 3. 研究方法
[详细描述提出的方法/模型/算法]

## 4. 实验与结果
[实验设置、数据集、评价指标、实验结果与分析]

## 5. 讨论
[结果分析、局限性、研究意义]

## 6. 结论
[研究贡献总结、未来工作展望]

## 参考文献
[列出10-15篇代表性参考文献，格式规范]`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt,
                maxTokens: 4000,
                temperature: 0.3,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err(isEn ? 'Paper generation failed, please retry' : '论文生成失败，请重试');
            return this.text(output);
        }
        catch (err) {
            return this.err(`${isEn ? 'Paper generation failed' : '论文生成失败'}：${String(err)}`);
        }
    }
    async revisePaper(topic, field, content, requirements, section, isEn, systemPrompt) {
        const snippet = content.slice(0, 5000);
        const reqLine = requirements ? (isEn ? `\nTarget journal/conference requirements: ${requirements}` : `\n目标期刊/会议要求：${requirements}`) : '';
        const sectionLine = section !== 'all' ? (isEn ? `\nFocus on revising the "${section}" section.` : `\n重点修改"${section}"章节。`) : '';
        const prompt = isEn
            ? `Please revise and improve the following academic paper draft:

Topic: ${topic}
Field: ${field}${reqLine}${sectionLine}

[Paper Draft]
${snippet}${content.length > 5000 ? '\n[Content truncated to 5000 chars]' : ''}

Please provide:
1. **Revised Version** — improved text with tracked changes noted in [brackets]
2. **Revision Summary** — list of major changes made and reasons
3. **Remaining Issues** — aspects that still need improvement`
            : `请对以下学术论文草稿进行修改完善：

论文主题：${topic}
学科领域：${field}${reqLine}${sectionLine}

【论文草稿】
${snippet}${content.length > 5000 ? '\n[内容较长，已截取前5000字]' : ''}

请输出：
1. **修改后版本** — 改进后的文本，用【修改：原文→新文】标注主要修改处
2. **修改说明** — 列出主要修改内容及修改原因
3. **待改进问题** — 仍需进一步完善的方面`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt,
                maxTokens: 4000,
                temperature: 0.3,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err(isEn ? 'Revision failed, please retry' : '论文修改失败，请重试');
            return this.text(`# ${isEn ? 'Paper Revision' : '论文修改'} — ${topic}\n\n${output}`);
        }
        catch (err) {
            return this.err(`${isEn ? 'Revision failed' : '论文修改失败'}：${String(err)}`);
        }
    }
    async polishPaper(topic, content, section, isEn, systemPrompt) {
        const snippet = content.slice(0, 5000);
        const sectionLine = section !== 'all' ? (isEn ? `\nPolish only the "${section}" section.` : `\n只润色"${section}"章节。`) : '';
        const prompt = isEn
            ? `Please polish the following academic text to improve its academic writing quality:

Topic: ${topic}${sectionLine}

[Original Text]
${snippet}${content.length > 5000 ? '\n[Truncated to 5000 chars]' : ''}

Requirements:
- Improve academic tone and precision
- Fix grammar and sentence structure
- Enhance logical flow and coherence
- Use appropriate academic vocabulary
- Preserve the original meaning and technical content

Please output:
1. **Polished Version** — the improved text
2. **Key Changes** — summary of main improvements made`
            : `请对以下学术文本进行语言润色，提升学术写作质量：

论文主题：${topic}${sectionLine}

【原文】
${snippet}${content.length > 5000 ? '\n[内容较长，已截取前5000字]' : ''}

润色要求：
- 提升学术语言规范性和准确性
- 修正语法和句式问题
- 增强逻辑连贯性
- 使用恰当的学术词汇
- 保持原意和技术内容不变

请输出：
1. **润色后版本** — 改进后的文本
2. **主要改动说明** — 润色要点总结`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt,
                maxTokens: 4000,
                temperature: 0.2,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err(isEn ? 'Polishing failed, please retry' : '论文润色失败，请重试');
            return this.text(`# ${isEn ? 'Paper Polish' : '论文润色'} — ${topic}\n\n${output}`);
        }
        catch (err) {
            return this.err(`${isEn ? 'Polishing failed' : '论文润色失败'}：${String(err)}`);
        }
    }
    async reviewPaper(topic, field, type, content, isEn, systemPrompt) {
        const snippet = content.slice(0, 5000);
        const typeLabel = { journal: isEn ? 'journal paper' : '期刊论文', conference: isEn ? 'conference paper' : '会议论文', thesis: isEn ? 'thesis' : '学位论文', report: isEn ? 'research report' : '研究报告' }[type] ?? (isEn ? 'paper' : '论文');
        const prompt = isEn
            ? `Please provide a professional peer review for the following ${typeLabel}:

Topic: ${topic}
Field: ${field}

[Paper Content]
${snippet}${content.length > 5000 ? '\n[Truncated to 5000 chars]' : ''}

Please provide a structured review:

## Summary
[Brief summary of the paper's main contributions]

## Strengths
[List the paper's main strengths]

## Weaknesses / Major Concerns
[List major issues that must be addressed]

## Minor Comments
[List minor issues and suggestions]

## Detailed Review by Section
### Abstract
### Introduction
### Methodology
### Results & Discussion
### Conclusion

## Overall Assessment
- Novelty: [1-5 stars]
- Technical Quality: [1-5 stars]
- Presentation: [1-5 stars]
- Overall Score: [1-5 stars]
- Recommendation: [Accept / Minor Revision / Major Revision / Reject]`
            : `请对以下${typeLabel}提供专业审稿意见：

论文主题：${topic}
学科领域：${field}

【论文内容】
${snippet}${content.length > 5000 ? '\n[内容较长，已截取前5000字]' : ''}

请输出结构化审稿意见：

## 一、论文摘要
[简要概括论文主要贡献]

## 二、主要优点
[列出论文的主要优点]

## 三、主要问题（必须修改）
[列出必须解决的重大问题]

## 四、次要问题（建议修改）
[列出建议改进的次要问题]

## 五、分章节详细意见
### 摘要
### 引言
### 研究方法
### 实验结果与讨论
### 结论

## 六、综合评价
- 创新性：[1-5星]
- 技术质量：[1-5星]
- 写作质量：[1-5星]
- 综合评分：[1-5星]
- 处理意见：[接受 / 小修 / 大修 / 拒稿]`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt,
                maxTokens: 3000,
                temperature: 0.2,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err(isEn ? 'Review failed, please retry' : '论文审稿失败，请重试');
            return this.text(`# ${isEn ? 'Peer Review' : '审稿意见'} — ${topic}\n\n${output}`);
        }
        catch (err) {
            return this.err(`${isEn ? 'Review failed' : '论文审稿失败'}：${String(err)}`);
        }
    }
}
//# sourceMappingURL=paper_writer.js.map