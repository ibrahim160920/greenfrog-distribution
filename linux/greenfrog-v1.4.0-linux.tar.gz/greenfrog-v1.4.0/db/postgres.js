/**
 * PostgreSQL implementation of IMemoryStore.
 * Drop-in replacement for the SQLite MemoryStore.
 * Uses pg Pool with $1/$2 parameterized queries.
 */
import { Pool } from 'pg';
import { createHmac } from 'crypto';
import { nanoid } from 'nanoid';
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';
import { BM25Index } from '../memory/bm25.js';
import { generateEmbedding, cosineSimilarity } from '../memory/embedding.js';
import { hydrateTeamTopology, mergeTeamTopologyMetadata } from '../utils/team_topology.js';
import { publishTeamRuntimeWakeup } from '../runtime/team_runtime_wakeup.js';
const log = createLogger('postgres');
// ── Schema ────────────────────────────────────────────────────────────────────
const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS memory (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  embedding TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  expires_at BIGINT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_memory_unique ON memory(user_id, channel, key);
CREATE INDEX IF NOT EXISTS idx_memory_user ON memory(user_id, channel);

CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  tool_call_id TEXT,
  tool_name TEXT,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conv_session ON conversations(session_id);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  chat_id TEXT NOT NULL,
  created_at BIGINT NOT NULL,
  last_active BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_session_unique ON sessions(user_id, channel, chat_id);

CREATE TABLE IF NOT EXISTS scheduled_jobs (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  cron TEXT NOT NULL,
  prompt TEXT NOT NULL,
  channel TEXT NOT NULL,
  chat_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  last_run BIGINT,
  next_run BIGINT,
  run_count INTEGER NOT NULL DEFAULT 0,
  notify_if TEXT,
  last_result TEXT,
  created_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS interaction_feedback (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  workspace_id TEXT NOT NULL DEFAULT '',
  agent_id TEXT NOT NULL DEFAULT '',
  session_id TEXT NOT NULL,
  user_message TEXT NOT NULL,
  ai_response TEXT NOT NULL,
  feedback_type TEXT NOT NULL,
  signal TEXT,
  score INTEGER NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_feedback_user ON interaction_feedback(user_id, channel, workspace_id, agent_id, created_at);

CREATE TABLE IF NOT EXISTS behavioral_rules (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  workspace_id TEXT NOT NULL DEFAULT '',
  agent_id TEXT NOT NULL DEFAULT '',
  rule TEXT NOT NULL,
  category TEXT NOT NULL,
  confidence INTEGER NOT NULL DEFAULT 50,
  source TEXT NOT NULL,
  evidence_count INTEGER NOT NULL DEFAULT 1,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_rules_unique ON behavioral_rules(user_id, channel, workspace_id, agent_id, rule);

CREATE TABLE IF NOT EXISTS behavioral_rule_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  workspace_id TEXT NOT NULL DEFAULT '',
  agent_id TEXT NOT NULL DEFAULT '',
  rule TEXT NOT NULL,
  action TEXT NOT NULL,
  related_history_id TEXT,
  old_category TEXT,
  old_confidence INTEGER,
  old_source TEXT,
  old_evidence_count INTEGER,
  new_category TEXT,
  new_confidence INTEGER,
  new_source TEXT,
  new_evidence_count INTEGER,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_behavioral_rule_history_scope
  ON behavioral_rule_history(user_id, channel, workspace_id, agent_id, created_at DESC);

CREATE TABLE IF NOT EXISTS entities (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  workspace_id TEXT NOT NULL DEFAULT '',
  agent_id TEXT NOT NULL DEFAULT '',
  type TEXT NOT NULL,
  name TEXT NOT NULL,
  aliases TEXT,
  attributes TEXT NOT NULL DEFAULT '{}',
  relations TEXT,
  mention_count INTEGER NOT NULL DEFAULT 1,
  last_mentioned BIGINT NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_entities_unique ON entities(user_id, channel, workspace_id, agent_id, name);
CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(user_id, channel, workspace_id, agent_id, type);
CREATE INDEX IF NOT EXISTS idx_entities_last ON entities(user_id, channel, workspace_id, agent_id, last_mentioned);

CREATE TABLE IF NOT EXISTS patrol_checks (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'http',
  target TEXT NOT NULL,
  interval_min INTEGER NOT NULL DEFAULT 5,
  method TEXT,
  expected_status INTEGER,
  keyword TEXT,
  timeout_ms INTEGER NOT NULL DEFAULT 10000,
  alert_threshold INTEGER NOT NULL DEFAULT 2,
  channel TEXT NOT NULL,
  chat_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  last_check BIGINT,
  last_status TEXT,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS patrol_results (
  id TEXT PRIMARY KEY,
  check_id TEXT NOT NULL,
  ok BOOLEAN NOT NULL,
  status_code INTEGER,
  latency_ms INTEGER NOT NULL,
  error TEXT,
  checked_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_patrol_results_check ON patrol_results(check_id, checked_at);

CREATE TABLE IF NOT EXISTS workflows (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  trigger TEXT NOT NULL,
  steps TEXT NOT NULL,
  channel TEXT NOT NULL,
  chat_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  last_run BIGINT,
  run_count INTEGER NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0,
  reset_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS error_events (
  id TEXT PRIMARY KEY,
  level TEXT NOT NULL,
  message TEXT NOT NULL,
  context TEXT,
  stack TEXT,
  user_id TEXT,
  channel TEXT,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_errors_created ON error_events(created_at);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  timestamp BIGINT NOT NULL,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  chat_id TEXT,
  skill_name TEXT NOT NULL,
  params TEXT,
  success BOOLEAN NOT NULL,
  duration_ms INTEGER NOT NULL,
  error TEXT,
  role TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_skill ON audit_log(skill_name, timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(timestamp);

CREATE TABLE IF NOT EXISTS memory_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  workspace_id TEXT,
  agent_id TEXT,
  key TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT NOT NULL,
  source TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_memory_history_user ON memory_history(user_id, channel, created_at DESC);

CREATE TABLE IF NOT EXISTS scoped_memory (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  workspace_id TEXT NOT NULL DEFAULT '',
  agent_id TEXT NOT NULL DEFAULT '',
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  embedding TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  expires_at BIGINT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_scoped_memory_unique
  ON scoped_memory(user_id, channel, workspace_id, agent_id, key);
CREATE INDEX IF NOT EXISTS idx_scoped_memory_scope
  ON scoped_memory(user_id, channel, workspace_id, agent_id);

CREATE TABLE IF NOT EXISTS agent_registry (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  workspace_id TEXT NOT NULL,
  owner_user_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  memory_scope TEXT NOT NULL DEFAULT 'agent',
  provider TEXT,
  model TEXT,
  system_prompt TEXT,
  metadata TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agent_registry_workspace ON agent_registry(workspace_id, status);

CREATE TABLE IF NOT EXISTS agent_bindings (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  user_id TEXT NOT NULL DEFAULT '',
  chat_id TEXT NOT NULL DEFAULT '',
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_agent_bindings_unique
  ON agent_bindings(agent_id, channel, user_id, chat_id);
CREATE INDEX IF NOT EXISTS idx_agent_bindings_route
  ON agent_bindings(channel, user_id, chat_id, workspace_id);

CREATE TABLE IF NOT EXISTS team_tasks (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'todo',
  priority TEXT NOT NULL DEFAULT 'medium',
  assigned_agent_id TEXT,
  depends_on_task_ids TEXT NOT NULL DEFAULT '[]',
  review_required BOOLEAN NOT NULL DEFAULT FALSE,
  reviewer_agent_id TEXT,
  review_status TEXT NOT NULL DEFAULT 'not_required',
  attempt_count INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 1,
  last_attempt_at BIGINT,
  escalation_status TEXT NOT NULL DEFAULT 'none',
  escalation_reason TEXT,
  human_owner_user_id TEXT,
  blocked_reason TEXT,
  created_by TEXT NOT NULL,
  result_summary TEXT,
  due_at BIGINT,
  metadata TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_team_tasks_workspace
  ON team_tasks(workspace_id, status, priority, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_team_tasks_agent
  ON team_tasks(workspace_id, assigned_agent_id, status, updated_at DESC);

CREATE TABLE IF NOT EXISTS team_policies (
  workspace_id TEXT PRIMARY KEY,
  auto_dispatch BOOLEAN NOT NULL DEFAULT TRUE,
  auto_review BOOLEAN NOT NULL DEFAULT TRUE,
  max_auto_retries INTEGER NOT NULL DEFAULT 1,
  escalate_on_blocked BOOLEAN NOT NULL DEFAULT TRUE,
  escalate_on_review_changes BOOLEAN NOT NULL DEFAULT TRUE,
  escalate_on_sla_breach BOOLEAN NOT NULL DEFAULT TRUE,
  auto_share_task_results BOOLEAN NOT NULL DEFAULT FALSE,
  shared_memory_prefix TEXT NOT NULL DEFAULT 'team:',
  default_task_sla_hours INTEGER NOT NULL DEFAULT 24,
  default_human_owner_user_id TEXT,
  approval_reminder_after_minutes INTEGER NOT NULL DEFAULT 30,
  approval_escalation_after_minutes INTEGER NOT NULL DEFAULT 120,
  oncall_assignment_timeout_minutes INTEGER NOT NULL DEFAULT 10,
  oncall_max_handoffs_per_task INTEGER NOT NULL DEFAULT 4,
  escalation_owner_user_id TEXT,
  updated_by TEXT NOT NULL,
  metadata TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS team_task_approvals (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  task_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  requested_by TEXT NOT NULL,
  requested_for_user_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  resolution_notes TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  resolved_at BIGINT
);
CREATE INDEX IF NOT EXISTS idx_team_task_approvals_workspace
  ON team_task_approvals(workspace_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_team_task_approvals_task
  ON team_task_approvals(task_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS team_notifications (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  recipient_user_id TEXT NOT NULL,
  type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info',
  status TEXT NOT NULL DEFAULT 'unread',
  delivery_status TEXT NOT NULL DEFAULT 'pending',
  delivery_attempt_count INTEGER NOT NULL DEFAULT 0,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  task_id TEXT,
  approval_id TEXT,
  last_delivery_error TEXT,
  metadata TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  read_at BIGINT,
  last_delivery_attempt_at BIGINT,
  delivered_at BIGINT
);
CREATE INDEX IF NOT EXISTS idx_team_notifications_recipient
  ON team_notifications(recipient_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_team_notifications_workspace
  ON team_notifications(workspace_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS team_notification_routes (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  recipient_user_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  chat_id TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_by TEXT NOT NULL,
  metadata TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_team_notification_routes_unique
  ON team_notification_routes(workspace_id, recipient_user_id, channel, chat_id);
CREATE INDEX IF NOT EXISTS idx_team_notification_routes_recipient
  ON team_notification_routes(workspace_id, recipient_user_id, enabled, updated_at DESC);

CREATE TABLE IF NOT EXISTS team_mailbox_messages (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  thread_id TEXT NOT NULL,
  dedupe_key TEXT,
  sender_agent_id TEXT,
  sender_user_id TEXT,
  recipient_agent_id TEXT,
  task_id TEXT,
  type TEXT NOT NULL DEFAULT 'direct',
  status TEXT NOT NULL DEFAULT 'pending',
  subject TEXT,
  message TEXT NOT NULL,
  metadata TEXT,
  acknowledged_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_team_mailbox_workspace
  ON team_mailbox_messages(workspace_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_team_mailbox_dedupe
  ON team_mailbox_messages(workspace_id, dedupe_key, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_team_mailbox_recipient
  ON team_mailbox_messages(workspace_id, recipient_agent_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_team_mailbox_thread
  ON team_mailbox_messages(thread_id, created_at ASC);

CREATE TABLE IF NOT EXISTS team_oncall_rotations (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  name TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  schedule_type TEXT NOT NULL DEFAULT 'daily',
  anchor_date BIGINT NOT NULL,
  department TEXT,
  role TEXT,
  primary_agent_ids TEXT NOT NULL DEFAULT '[]',
  secondary_agent_ids TEXT NOT NULL DEFAULT '[]',
  created_by TEXT NOT NULL,
  metadata TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_team_oncall_rotations_workspace
  ON team_oncall_rotations(workspace_id, enabled, department, role, updated_at DESC);

CREATE TABLE IF NOT EXISTS team_templates (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  department TEXT,
  role TEXT,
  goal_template TEXT,
  variables TEXT NOT NULL DEFAULT '[]',
  task_blueprints TEXT NOT NULL DEFAULT '[]',
  created_by TEXT NOT NULL,
  metadata TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_team_templates_workspace
  ON team_templates(workspace_id, name, updated_at DESC);

CREATE TABLE IF NOT EXISTS team_topologies (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  name TEXT NOT NULL,
  department TEXT,
  role TEXT,
  supervisor_agent_id TEXT,
  worker_agent_ids TEXT NOT NULL DEFAULT '[]',
  default_template_ids TEXT NOT NULL DEFAULT '[]',
  default_human_owner_user_id TEXT,
  metadata TEXT,
  created_by TEXT NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_team_topologies_workspace
  ON team_topologies(workspace_id, department, role, updated_at DESC);

CREATE TABLE IF NOT EXISTS skill_stats (
  skill_name TEXT PRIMARY KEY,
  call_count INTEGER NOT NULL DEFAULT 0,
  success_count INTEGER NOT NULL DEFAULT 0,
  total_duration_ms BIGINT NOT NULL DEFAULT 0,
  last_called_at BIGINT
);

CREATE TABLE IF NOT EXISTS auth_revocations (
  user_id TEXT PRIMARY KEY,
  revoked_after BIGINT NOT NULL,
  revoked_by TEXT,
  reason TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS token_usage (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  workspace_id TEXT,
  agent_id TEXT,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  input_tokens BIGINT NOT NULL DEFAULT 0,
  output_tokens BIGINT NOT NULL DEFAULT 0,
  total_tokens BIGINT NOT NULL DEFAULT 0,
  cost_usd DOUBLE PRECISION,
  channel TEXT,
  session_key TEXT,
  recorded_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_token_usage_user ON token_usage(user_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_token_usage_workspace ON token_usage(workspace_id, recorded_at DESC);

CREATE TABLE IF NOT EXISTS user_quotas (
  scope_type TEXT NOT NULL CHECK(scope_type IN ('user','workspace')),
  scope_id TEXT NOT NULL,
  monthly_token_limit BIGINT,
  monthly_cost_limit_usd DOUBLE PRECISION,
  limit_behavior TEXT NOT NULL DEFAULT 'soft',
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (scope_type, scope_id)
);

CREATE TABLE IF NOT EXISTS workspace_members (
  workspace_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member',
  joined_at BIGINT NOT NULL,
  PRIMARY KEY (workspace_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_workspace_members_user ON workspace_members(user_id);
`;
// ── Helper ────────────────────────────────────────────────────────────────────
function rowToEntity(r) {
    return {
        id: r['id'],
        userId: r['user_id'],
        channel: r['channel'],
        type: r['type'],
        name: r['name'],
        aliases: r['aliases'] ? JSON.parse(r['aliases']) : undefined,
        attributes: JSON.parse(r['attributes']),
        relations: r['relations'] ? JSON.parse(r['relations']) : undefined,
        mentionCount: r['mention_count'],
        lastMentioned: new Date(r['last_mentioned']),
        createdAt: new Date(r['created_at']),
    };
}
function normalizeScope(scope) {
    return {
        userId: scope.userId,
        channel: scope.channel,
        workspaceId: scope.workspaceId ?? '',
        agentId: scope.agentId ?? '',
    };
}
function rowToMemoryEntry(r) {
    return {
        id: r['id'],
        userId: r['user_id'],
        channel: r['channel'],
        workspaceId: r['workspace_id'] || null,
        agentId: r['agent_id'] || null,
        key: r['key'],
        value: r['value'],
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
        expiresAt: r['expires_at'] ? new Date(r['expires_at']) : undefined,
    };
}
function rowToBehavioralRuleHistoryEntry(r) {
    return {
        id: r['id'],
        userId: r['user_id'],
        channel: r['channel'],
        workspaceId: r['workspace_id'] || null,
        agentId: r['agent_id'] || null,
        rule: r['rule'],
        action: r['action'],
        relatedHistoryId: r['related_history_id'] || null,
        oldCategory: r['old_category'] || null,
        oldConfidence: r['old_confidence'] === null || r['old_confidence'] === undefined ? null : Number(r['old_confidence']),
        oldSource: r['old_source'] || null,
        oldEvidenceCount: r['old_evidence_count'] === null || r['old_evidence_count'] === undefined ? null : Number(r['old_evidence_count']),
        newCategory: r['new_category'] || null,
        newConfidence: r['new_confidence'] === null || r['new_confidence'] === undefined ? null : Number(r['new_confidence']),
        newSource: r['new_source'] || null,
        newEvidenceCount: r['new_evidence_count'] === null || r['new_evidence_count'] === undefined ? null : Number(r['new_evidence_count']),
        createdAt: new Date(r['created_at']),
    };
}
function rowToAgent(r) {
    return {
        id: r['id'],
        name: r['name'],
        description: r['description'] ?? undefined,
        workspaceId: r['workspace_id'],
        ownerUserId: r['owner_user_id'],
        status: r['status'],
        memoryScope: r['memory_scope'],
        provider: r['provider'] ?? null,
        model: r['model'] ?? null,
        systemPrompt: r['system_prompt'] ?? undefined,
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    };
}
function rowToAgentBinding(r) {
    return {
        id: r['id'],
        agentId: r['agent_id'],
        workspaceId: r['workspace_id'],
        channel: r['channel'],
        userId: r['user_id'] || null,
        chatId: r['chat_id'] || null,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    };
}
function rowToTeamTask(r) {
    return {
        id: r['id'],
        workspaceId: r['workspace_id'],
        title: r['title'],
        description: r['description'] ?? undefined,
        status: r['status'],
        priority: r['priority'],
        assignedAgentId: r['assigned_agent_id'] ?? null,
        dependsOnTaskIds: r['depends_on_task_ids'] ? JSON.parse(r['depends_on_task_ids']) : [],
        reviewRequired: Boolean(r['review_required']),
        reviewerAgentId: r['reviewer_agent_id'] ?? null,
        reviewStatus: (r['review_status'] ?? 'not_required'),
        attemptCount: Number(r['attempt_count'] ?? 0),
        maxAttempts: Math.max(1, Number(r['max_attempts'] ?? 1)),
        lastAttemptAt: r['last_attempt_at'] ? new Date(r['last_attempt_at']) : null,
        escalationStatus: (r['escalation_status'] ?? 'none'),
        escalationReason: r['escalation_reason'] ?? null,
        humanOwnerUserId: r['human_owner_user_id'] ?? null,
        blockedReason: r['blocked_reason'] ?? null,
        createdBy: r['created_by'],
        resultSummary: r['result_summary'] ?? null,
        dueAt: r['due_at'] ? new Date(r['due_at']) : null,
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    };
}
function rowToTeamPolicy(r) {
    const meta = r['metadata'] ? JSON.parse(r['metadata']) : undefined;
    return {
        workspaceId: r['workspace_id'],
        autoDispatch: Boolean(r['auto_dispatch']),
        autoReview: Boolean(r['auto_review']),
        maxAutoRetries: Number(r['max_auto_retries'] ?? 1),
        escalateOnBlocked: Boolean(r['escalate_on_blocked']),
        escalateOnReviewChanges: Boolean(r['escalate_on_review_changes']),
        escalateOnSlaBreach: Boolean(r['escalate_on_sla_breach']),
        autoShareTaskResults: Boolean(r['auto_share_task_results']),
        autoPropagateLearnings: typeof meta?.['autoPropagateLearnings'] === 'boolean' ? meta['autoPropagateLearnings'] : true,
        autoGovernLearnedRules: typeof meta?.['autoGovernLearnedRules'] === 'boolean'
            ? meta['autoGovernLearnedRules']
            : typeof meta?.['ruleLibraryAutoGovernanceEnabled'] === 'boolean'
                ? meta['ruleLibraryAutoGovernanceEnabled']
                : false,
        sharedMemoryPrefix: r['shared_memory_prefix'] ?? 'team:',
        defaultTaskSlaHours: Number(r['default_task_sla_hours'] ?? 24),
        defaultHumanOwnerUserId: r['default_human_owner_user_id'] ?? null,
        approvalReminderAfterMinutes: Number(r['approval_reminder_after_minutes'] ?? 30),
        approvalEscalationAfterMinutes: Number(r['approval_escalation_after_minutes'] ?? 120),
        onCallAssignmentTimeoutMinutes: Number(r['oncall_assignment_timeout_minutes'] ?? 10),
        onCallMaxHandoffsPerTask: Number(r['oncall_max_handoffs_per_task'] ?? 4),
        escalationOwnerUserId: r['escalation_owner_user_id'] ?? null,
        updatedBy: r['updated_by'],
        metadata: meta,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    };
}
function rowToTeamTaskApproval(r) {
    return {
        id: r['id'],
        workspaceId: r['workspace_id'],
        taskId: r['task_id'],
        status: r['status'],
        requestedBy: r['requested_by'],
        requestedForUserId: r['requested_for_user_id'],
        reason: r['reason'],
        resolutionNotes: r['resolution_notes'] ?? null,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
        resolvedAt: r['resolved_at'] ? new Date(r['resolved_at']) : null,
    };
}
function rowToTeamTemplate(r) {
    return {
        id: r['id'],
        workspaceId: r['workspace_id'],
        name: r['name'],
        description: r['description'] ?? undefined,
        department: r['department'] ?? null,
        role: r['role'] ?? null,
        goalTemplate: r['goal_template'] ?? null,
        variables: r['variables'] ? JSON.parse(r['variables']) : [],
        taskBlueprints: r['task_blueprints'] ? JSON.parse(r['task_blueprints']) : [],
        createdBy: r['created_by'],
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    };
}
function rowToTeamTopology(r) {
    return hydrateTeamTopology({
        id: r['id'],
        workspaceId: r['workspace_id'],
        name: r['name'],
        department: r['department'] ?? null,
        role: r['role'] ?? null,
        supervisorAgentId: r['supervisor_agent_id'] ?? null,
        workerAgentIds: r['worker_agent_ids'] ? JSON.parse(r['worker_agent_ids']) : [],
        defaultTemplateIds: r['default_template_ids'] ? JSON.parse(r['default_template_ids']) : [],
        defaultHumanOwnerUserId: r['default_human_owner_user_id'] ?? null,
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdBy: r['created_by'],
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    });
}
function rowToTeamNotification(r) {
    return {
        id: r['id'],
        workspaceId: r['workspace_id'],
        recipientUserId: r['recipient_user_id'],
        type: r['type'],
        severity: r['severity'],
        status: r['status'],
        deliveryStatus: r['delivery_status'] ?? 'pending',
        deliveryAttemptCount: Number(r['delivery_attempt_count'] ?? 0),
        title: r['title'],
        message: r['message'],
        taskId: r['task_id'] ?? null,
        approvalId: r['approval_id'] ?? null,
        lastDeliveryError: r['last_delivery_error'] ?? null,
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
        readAt: r['read_at'] ? new Date(r['read_at']) : null,
        lastDeliveryAttemptAt: r['last_delivery_attempt_at'] ? new Date(r['last_delivery_attempt_at']) : null,
        deliveredAt: r['delivered_at'] ? new Date(r['delivered_at']) : null,
    };
}
function rowToTeamMailboxMessage(r) {
    return {
        id: r['id'],
        workspaceId: r['workspace_id'],
        threadId: r['thread_id'],
        dedupeKey: r['dedupe_key'] ?? null,
        senderAgentId: r['sender_agent_id'] ?? null,
        senderUserId: r['sender_user_id'] ?? null,
        recipientAgentId: r['recipient_agent_id'] ?? null,
        taskId: r['task_id'] ?? null,
        type: (r['type'] ?? 'direct'),
        status: (r['status'] ?? 'pending'),
        subject: r['subject'] ?? null,
        message: r['message'],
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
        acknowledgedAt: r['acknowledged_at'] ? new Date(r['acknowledged_at']) : null,
    };
}
function rowToTeamNotificationRoute(r) {
    return {
        id: r['id'],
        workspaceId: r['workspace_id'],
        recipientUserId: r['recipient_user_id'],
        channel: r['channel'],
        chatId: r['chat_id'],
        enabled: Boolean(r['enabled']),
        createdBy: r['created_by'],
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    };
}
function rowToTeamOnCallRotation(r) {
    return {
        id: r['id'],
        workspaceId: r['workspace_id'],
        name: r['name'],
        enabled: Boolean(r['enabled']),
        scheduleType: (r['schedule_type'] ?? 'daily'),
        anchorDate: new Date(r['anchor_date']),
        department: r['department'] ?? null,
        role: r['role'] ?? null,
        primaryAgentIds: r['primary_agent_ids'] ? JSON.parse(r['primary_agent_ids']) : [],
        secondaryAgentIds: r['secondary_agent_ids'] ? JSON.parse(r['secondary_agent_ids']) : [],
        createdBy: r['created_by'],
        metadata: r['metadata'] ? JSON.parse(r['metadata']) : undefined,
        createdAt: new Date(r['created_at']),
        updatedAt: new Date(r['updated_at']),
    };
}
// ── Class ─────────────────────────────────────────────────────────────────────
export class PostgresMemoryStore {
    pool;
    _queryEmbCache = new Map();
    constructor(connectionUrl, poolMax = 10, idleTimeoutMs = 30_000) {
        this.pool = new Pool({
            connectionString: connectionUrl,
            max: poolMax,
            idleTimeoutMillis: idleTimeoutMs,
            connectionTimeoutMillis: 5_000,
        });
        this.pool.on('error', (err) => log.error({ err }, 'PG pool error'));
    }
    async init() {
        const client = await this.pool.connect();
        try {
            await client.query(SCHEMA_SQL);
            await client.query(`ALTER TABLE memory_history ADD COLUMN IF NOT EXISTS workspace_id TEXT`);
            await client.query(`ALTER TABLE memory_history ADD COLUMN IF NOT EXISTS agent_id TEXT`);
            await client.query(`CREATE INDEX IF NOT EXISTS idx_memory_history_scope ON memory_history(user_id, channel, workspace_id, agent_id, created_at DESC)`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS depends_on_task_ids TEXT NOT NULL DEFAULT '[]'`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS review_required BOOLEAN NOT NULL DEFAULT FALSE`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS reviewer_agent_id TEXT`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS review_status TEXT NOT NULL DEFAULT 'not_required'`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS attempt_count INTEGER NOT NULL DEFAULT 0`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS max_attempts INTEGER NOT NULL DEFAULT 1`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS last_attempt_at BIGINT`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS escalation_status TEXT NOT NULL DEFAULT 'none'`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS escalation_reason TEXT`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS human_owner_user_id TEXT`);
            await client.query(`ALTER TABLE team_tasks ADD COLUMN IF NOT EXISTS blocked_reason TEXT`);
            await client.query(`ALTER TABLE team_policies ADD COLUMN IF NOT EXISTS escalate_on_sla_breach BOOLEAN NOT NULL DEFAULT TRUE`);
            await client.query(`ALTER TABLE team_policies ADD COLUMN IF NOT EXISTS default_task_sla_hours INTEGER NOT NULL DEFAULT 24`);
            await client.query(`ALTER TABLE team_policies ADD COLUMN IF NOT EXISTS approval_reminder_after_minutes INTEGER NOT NULL DEFAULT 30`);
            await client.query(`ALTER TABLE team_policies ADD COLUMN IF NOT EXISTS approval_escalation_after_minutes INTEGER NOT NULL DEFAULT 120`);
            await client.query(`ALTER TABLE team_policies ADD COLUMN IF NOT EXISTS oncall_assignment_timeout_minutes INTEGER NOT NULL DEFAULT 10`);
            await client.query(`ALTER TABLE team_policies ADD COLUMN IF NOT EXISTS oncall_max_handoffs_per_task INTEGER NOT NULL DEFAULT 4`);
            await client.query(`ALTER TABLE team_policies ADD COLUMN IF NOT EXISTS escalation_owner_user_id TEXT`);
            await client.query(`ALTER TABLE team_templates ADD COLUMN IF NOT EXISTS variables TEXT NOT NULL DEFAULT '[]'`);
            await client.query(`ALTER TABLE team_notifications ADD COLUMN IF NOT EXISTS delivery_status TEXT NOT NULL DEFAULT 'pending'`);
            await client.query(`ALTER TABLE team_notifications ADD COLUMN IF NOT EXISTS delivery_attempt_count INTEGER NOT NULL DEFAULT 0`);
            await client.query(`ALTER TABLE team_notifications ADD COLUMN IF NOT EXISTS last_delivery_error TEXT`);
            await client.query(`ALTER TABLE team_notifications ADD COLUMN IF NOT EXISTS last_delivery_attempt_at BIGINT`);
            await client.query(`ALTER TABLE team_notifications ADD COLUMN IF NOT EXISTS delivered_at BIGINT`);
            await client.query(`ALTER TABLE behavioral_rules ADD COLUMN IF NOT EXISTS workspace_id TEXT NOT NULL DEFAULT ''`);
            await client.query(`ALTER TABLE behavioral_rules ADD COLUMN IF NOT EXISTS agent_id TEXT NOT NULL DEFAULT ''`);
            await client.query(`ALTER TABLE entities ADD COLUMN IF NOT EXISTS workspace_id TEXT NOT NULL DEFAULT ''`);
            await client.query(`ALTER TABLE entities ADD COLUMN IF NOT EXISTS agent_id TEXT NOT NULL DEFAULT ''`);
            await client.query(`ALTER TABLE interaction_feedback ADD COLUMN IF NOT EXISTS workspace_id TEXT NOT NULL DEFAULT ''`);
            await client.query(`ALTER TABLE interaction_feedback ADD COLUMN IF NOT EXISTS agent_id TEXT NOT NULL DEFAULT ''`);
            await client.query(`ALTER TABLE team_mailbox_messages ADD COLUMN IF NOT EXISTS dedupe_key TEXT`);
            await client.query(`CREATE INDEX IF NOT EXISTS idx_team_mailbox_dedupe ON team_mailbox_messages(workspace_id, dedupe_key, updated_at DESC)`);
            await client.query(`DROP INDEX IF EXISTS idx_feedback_user`);
            await client.query(`CREATE INDEX IF NOT EXISTS idx_feedback_user ON interaction_feedback(user_id, channel, workspace_id, agent_id, created_at)`);
            await client.query(`DROP INDEX IF EXISTS idx_rules_unique`);
            await client.query(`CREATE UNIQUE INDEX IF NOT EXISTS idx_rules_unique ON behavioral_rules(user_id, channel, workspace_id, agent_id, rule)`);
            await client.query(`DROP INDEX IF EXISTS idx_entities_unique`);
            await client.query(`DROP INDEX IF EXISTS idx_entities_type`);
            await client.query(`DROP INDEX IF EXISTS idx_entities_last`);
            await client.query(`CREATE UNIQUE INDEX IF NOT EXISTS idx_entities_unique ON entities(user_id, channel, workspace_id, agent_id, name)`);
            await client.query(`CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(user_id, channel, workspace_id, agent_id, type)`);
            await client.query(`CREATE INDEX IF NOT EXISTS idx_entities_last ON entities(user_id, channel, workspace_id, agent_id, last_mentioned)`);
            log.info('PostgreSQL schema ready');
        }
        finally {
            client.release();
        }
    }
    async close() {
        await this.pool.end();
    }
    // ── Memory KV ──────────────────────────────────────────────────────────────
    async setMemory(userId, channel, key, value, ttlDays) {
        const now = Date.now();
        const expiresAt = ttlDays != null ? now + ttlDays * 24 * 3600 * 1000 : null;
        await this.pool.query(`INSERT INTO memory (id, user_id, channel, key, value, created_at, updated_at, expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (user_id, channel, key)
       DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at, expires_at = EXCLUDED.expires_at`, [nanoid(), userId, channel, key, value, now, now, expiresAt]);
        // fire-and-forget embedding
        const entryText = `${key} ${value}`;
        setImmediate(async () => {
            try {
                const embedding = await generateEmbedding(entryText);
                if (embedding) {
                    await this.pool.query(`UPDATE memory SET embedding = $1 WHERE user_id = $2 AND channel = $3 AND key = $4`, [JSON.stringify(embedding), userId, channel, key]);
                }
            }
            catch { /* non-fatal */ }
        });
    }
    async getMemory(userId, channel, key) {
        const res = await this.pool.query(`SELECT value FROM memory WHERE user_id=$1 AND channel=$2 AND key=$3
       AND (expires_at IS NULL OR expires_at > $4)`, [userId, channel, key, Date.now()]);
        return res.rows[0]?.value ?? null;
    }
    async getAllMemory(userId, channel) {
        const res = await this.pool.query(`SELECT key, value FROM memory WHERE user_id=$1 AND channel=$2
       AND (expires_at IS NULL OR expires_at > $3)`, [userId, channel, Date.now()]);
        return Object.fromEntries(res.rows.map((r) => [r.key, r.value]));
    }
    async deleteMemory(userId, channel, key) {
        const res = await this.pool.query(`DELETE FROM memory WHERE user_id=$1 AND channel=$2 AND key=$3`, [userId, channel, key]);
        return (res.rowCount ?? 0) > 0;
    }
    async searchSemantic(userId, channel, query, limit = 5) {
        const res = await this.pool.query(`SELECT * FROM memory WHERE user_id=$1 AND channel=$2
       AND (expires_at IS NULL OR expires_at > $3)`, [userId, channel, Date.now()]);
        const all = res.rows;
        if (all.length === 0)
            return [];
        const index = new BM25Index();
        index.build(all.map((r) => ({ id: r['id'], text: `${r['key']} ${r['value']}` })));
        const hits = index.query(query, limit * 2);
        const byId = new Map(all.map((r) => [r['id'], r]));
        let results = hits
            .map(({ id, score }) => ({ row: byId.get(id), bm25Score: score }))
            .filter((x) => x.row != null);
        const queryEmbedding = this._queryEmbCache.get(query) ?? null;
        if (queryEmbedding) {
            results = results.map(({ row, bm25Score }) => {
                let cosScore = 0;
                if (row['embedding']) {
                    try {
                        cosScore = cosineSimilarity(queryEmbedding, JSON.parse(row['embedding']));
                    }
                    catch { /* skip */ }
                }
                return { row, bm25Score: bm25Score * 0.6 + cosScore * 0.4 };
            });
            results.sort((a, b) => b.bm25Score - a.bm25Score);
        }
        return results.slice(0, limit).map(({ row: r }) => ({
            id: r['id'], userId: r['user_id'], channel: r['channel'],
            key: r['key'], value: r['value'],
            createdAt: new Date(r['created_at']), updatedAt: new Date(r['updated_at']),
            expiresAt: r['expires_at'] ? new Date(r['expires_at']) : undefined,
        }));
    }
    async warmQueryEmbedding(query) {
        if (this._queryEmbCache.has(query))
            return;
        const emb = await generateEmbedding(query);
        if (emb)
            this._queryEmbCache.set(query, emb);
        if (this._queryEmbCache.size > 100) {
            const first = this._queryEmbCache.keys().next().value;
            if (first)
                this._queryEmbCache.delete(first);
        }
    }
    async searchMemory(userId, channel, query, limit = 10) {
        const res = await this.pool.query(`SELECT * FROM memory WHERE user_id=$1 AND channel=$2
       AND (expires_at IS NULL OR expires_at > $3)
       AND (key ILIKE $4 OR value ILIKE $4) LIMIT $5`, [userId, channel, Date.now(), `%${query}%`, limit]);
        return res.rows.map((r) => ({
            id: r['id'], userId: r['user_id'], channel: r['channel'],
            key: r['key'], value: r['value'],
            createdAt: new Date(r['created_at']), updatedAt: new Date(r['updated_at']),
            expiresAt: r['expires_at'] ? new Date(r['expires_at']) : undefined,
        }));
    }
    async getCorrectionCount(userId, channel, windowMs) {
        const res = await this.pool.query(`SELECT COUNT(*) as cnt FROM memory WHERE key LIKE 'correction:%'
       AND user_id=$1 AND channel=$2 AND created_at > $3`, [userId, channel, Date.now() - windowMs]);
        return parseInt(res.rows[0]?.cnt ?? '0', 10);
    }
    async setScopedMemory(scope, key, value, ttlDays) {
        const normalized = normalizeScope(scope);
        const now = Date.now();
        const expiresAt = ttlDays != null ? now + ttlDays * 24 * 3600 * 1000 : null;
        await this.pool.query(`INSERT INTO scoped_memory (id, user_id, channel, workspace_id, agent_id, key, value, created_at, updated_at, expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT (user_id, channel, workspace_id, agent_id, key)
       DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at, expires_at = EXCLUDED.expires_at`, [nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, key, value, now, now, expiresAt]);
        const entryText = `${key} ${value}`;
        setImmediate(async () => {
            try {
                const embedding = await generateEmbedding(entryText);
                if (embedding) {
                    await this.pool.query(`UPDATE scoped_memory SET embedding = $1
             WHERE user_id = $2 AND channel = $3 AND workspace_id = $4 AND agent_id = $5 AND key = $6`, [JSON.stringify(embedding), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, key]);
                }
            }
            catch { /* non-fatal */ }
        });
    }
    async getScopedMemory(scope, key) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT value FROM scoped_memory
       WHERE user_id = $1 AND channel = $2 AND workspace_id = $3 AND agent_id = $4 AND key = $5
         AND (expires_at IS NULL OR expires_at > $6)`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, key, Date.now()]);
        return res.rows[0]?.value ?? null;
    }
    async getAllScopedMemory(scope) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT key, value FROM scoped_memory
       WHERE user_id = $1 AND channel = $2 AND workspace_id = $3 AND agent_id = $4
         AND (expires_at IS NULL OR expires_at > $5)`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, Date.now()]);
        return Object.fromEntries(res.rows.map((r) => [r.key, r.value]));
    }
    async deleteScopedMemory(scope, key) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`DELETE FROM scoped_memory
       WHERE user_id = $1 AND channel = $2 AND workspace_id = $3 AND agent_id = $4 AND key = $5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, key]);
        return (res.rowCount ?? 0) > 0;
    }
    async searchScopedSemantic(scope, query, limit = 5) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT * FROM scoped_memory
       WHERE user_id = $1 AND channel = $2 AND workspace_id = $3 AND agent_id = $4
         AND (expires_at IS NULL OR expires_at > $5)`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, Date.now()]);
        const all = res.rows;
        if (all.length === 0)
            return [];
        const index = new BM25Index();
        index.build(all.map((r) => ({ id: r['id'], text: `${r['key']} ${r['value']}` })));
        const hits = index.query(query, limit * 2);
        const byId = new Map(all.map((r) => [r['id'], r]));
        let results = hits
            .map(({ id, score }) => ({ row: byId.get(id), bm25Score: score }))
            .filter((x) => x.row != null);
        const queryEmbedding = this._queryEmbCache.get(query) ?? null;
        if (queryEmbedding) {
            results = results.map(({ row, bm25Score }) => {
                let cosScore = 0;
                if (row['embedding']) {
                    try {
                        cosScore = cosineSimilarity(queryEmbedding, JSON.parse(row['embedding']));
                    }
                    catch { /* skip */ }
                }
                return { row, bm25Score: bm25Score * 0.6 + cosScore * 0.4 };
            });
            results.sort((a, b) => b.bm25Score - a.bm25Score);
        }
        return results.slice(0, limit).map(({ row }) => rowToMemoryEntry(row));
    }
    async searchScopedMemory(scope, query, limit = 10) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT * FROM scoped_memory
       WHERE user_id = $1 AND channel = $2 AND workspace_id = $3 AND agent_id = $4
         AND (expires_at IS NULL OR expires_at > $5)
         AND (key ILIKE $6 OR value ILIKE $6)
       LIMIT $7`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, Date.now(), `%${query}%`, limit]);
        return res.rows.map((row) => rowToMemoryEntry(row));
    }
    async createAgent(agent) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO agent_registry
       (id, name, description, workspace_id, owner_user_id, status, memory_scope, provider, model, system_prompt, metadata, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       RETURNING *`, [
            nanoid(),
            agent.name,
            agent.description ?? null,
            agent.workspaceId,
            agent.ownerUserId,
            agent.status ?? 'active',
            agent.memoryScope ?? 'agent',
            agent.provider ?? null,
            agent.model ?? null,
            agent.systemPrompt ?? null,
            agent.metadata ? JSON.stringify(agent.metadata) : null,
            now,
            now,
        ]);
        return rowToAgent(res.rows[0]);
    }
    async getAgent(id) {
        const res = await this.pool.query(`SELECT * FROM agent_registry WHERE id = $1`, [id]);
        return res.rows[0] ? rowToAgent(res.rows[0]) : null;
    }
    async listAgents(workspaceId) {
        const res = workspaceId
            ? await this.pool.query(`SELECT * FROM agent_registry WHERE workspace_id = $1 ORDER BY created_at ASC`, [workspaceId])
            : await this.pool.query(`SELECT * FROM agent_registry ORDER BY created_at ASC`);
        return res.rows.map((row) => rowToAgent(row));
    }
    async updateAgent(id, updates) {
        const current = await this.getAgent(id);
        if (!current)
            return null;
        const res = await this.pool.query(`UPDATE agent_registry
       SET name = $1, description = $2, status = $3, memory_scope = $4, provider = $5, model = $6, system_prompt = $7, metadata = $8, updated_at = $9
       WHERE id = $10
       RETURNING *`, [
            updates.name ?? current.name,
            updates.description ?? current.description ?? null,
            updates.status ?? current.status,
            updates.memoryScope ?? current.memoryScope,
            updates.provider !== undefined ? updates.provider : current.provider ?? null,
            updates.model !== undefined ? updates.model : current.model ?? null,
            updates.systemPrompt ?? current.systemPrompt ?? null,
            updates.metadata ? JSON.stringify(updates.metadata) : current.metadata ? JSON.stringify(current.metadata) : null,
            Date.now(),
            id,
        ]);
        return res.rows[0] ? rowToAgent(res.rows[0]) : null;
    }
    async deleteAgent(id) {
        await this.pool.query(`DELETE FROM agent_bindings WHERE agent_id = $1`, [id]);
        await this.pool.query(`DELETE FROM scoped_memory WHERE agent_id = $1`, [id]);
        const res = await this.pool.query(`DELETE FROM agent_registry WHERE id = $1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async createAgentBinding(binding) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO agent_bindings (id, agent_id, workspace_id, channel, user_id, chat_id, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`, [nanoid(), binding.agentId, binding.workspaceId, binding.channel, binding.userId ?? '', binding.chatId ?? '', now, now]);
        return rowToAgentBinding(res.rows[0]);
    }
    async listAgentBindings(filter) {
        const conditions = [];
        const args = [];
        if (filter?.workspaceId) {
            conditions.push(`workspace_id = $${args.length + 1}`);
            args.push(filter.workspaceId);
        }
        if (filter?.agentId) {
            conditions.push(`agent_id = $${args.length + 1}`);
            args.push(filter.agentId);
        }
        if (filter?.channel) {
            conditions.push(`channel = $${args.length + 1}`);
            args.push(filter.channel);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const res = await this.pool.query(`SELECT * FROM agent_bindings ${where} ORDER BY created_at ASC`, args);
        return res.rows.map((row) => rowToAgentBinding(row));
    }
    async deleteAgentBinding(id) {
        const res = await this.pool.query(`DELETE FROM agent_bindings WHERE id = $1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async resolveAgentBinding(params) {
        const res = await this.pool.query(`SELECT b.*,
              a.id AS resolved_agent_id,
              a.name,
              a.description,
              a.workspace_id AS resolved_workspace_id,
              a.owner_user_id,
              a.status,
              a.memory_scope,
              a.provider,
              a.model,
              a.system_prompt,
              a.metadata,
              a.created_at AS agent_created_at,
              a.updated_at AS agent_updated_at
       FROM agent_bindings b
       JOIN agent_registry a ON a.id = b.agent_id
       WHERE b.channel = $1
         AND a.status = 'active'
         AND (b.user_id = '' OR b.user_id = $2)
         AND (b.chat_id = '' OR b.chat_id = $3)
       ORDER BY
         CASE WHEN b.user_id = $2 THEN 1 ELSE 0 END +
         CASE WHEN b.chat_id = $3 THEN 2 ELSE 0 END DESC,
         b.updated_at DESC
       LIMIT 1`, [params.channel, params.userId, params.chatId]);
        const row = res.rows[0];
        if (!row)
            return null;
        return {
            binding: rowToAgentBinding(row),
            agent: rowToAgent({
                id: row['resolved_agent_id'],
                name: row['name'],
                description: row['description'],
                workspace_id: row['resolved_workspace_id'],
                owner_user_id: row['owner_user_id'],
                status: row['status'],
                memory_scope: row['memory_scope'],
                provider: row['provider'],
                model: row['model'],
                system_prompt: row['system_prompt'],
                metadata: row['metadata'],
                created_at: row['agent_created_at'],
                updated_at: row['agent_updated_at'],
            }),
        };
    }
    // ── Conversations ──────────────────────────────────────────────────────────
    async createTeamTask(task) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO team_tasks (
         id, workspace_id, title, description, status, priority, assigned_agent_id,
         depends_on_task_ids, review_required, reviewer_agent_id, review_status,
         attempt_count, max_attempts, last_attempt_at, escalation_status, escalation_reason, human_owner_user_id, blocked_reason,
         created_by, result_summary, due_at, metadata, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)
       RETURNING *`, [
            nanoid(),
            task.workspaceId,
            task.title,
            task.description ?? null,
            task.status ?? (task.assignedAgentId ? 'claimed' : 'open'),
            task.priority ?? 'medium',
            task.assignedAgentId ?? null,
            JSON.stringify(task.dependsOnTaskIds ?? []),
            task.reviewRequired ?? false,
            task.reviewerAgentId ?? null,
            task.reviewStatus ?? (task.reviewRequired ? 'pending' : 'not_required'),
            task.attemptCount ?? 0,
            Math.max(1, task.maxAttempts ?? 1),
            task.lastAttemptAt ? task.lastAttemptAt.getTime() : null,
            task.escalationStatus ?? 'none',
            task.escalationReason ?? null,
            task.humanOwnerUserId ?? null,
            task.blockedReason ?? null,
            task.createdBy,
            task.resultSummary ?? null,
            task.dueAt ? task.dueAt.getTime() : null,
            task.metadata ? JSON.stringify(task.metadata) : null,
            now,
            now,
        ]);
        const created = rowToTeamTask(res.rows[0]);
        publishTeamRuntimeWakeup({
            kind: 'task_created',
            workspaceId: created.workspaceId,
            taskId: created.id,
            assignedAgentId: created.assignedAgentId,
            status: created.status,
        });
        return created;
    }
    async getTeamTask(id) {
        const res = await this.pool.query(`SELECT * FROM team_tasks WHERE id = $1`, [id]);
        const row = res.rows[0];
        return row ? rowToTeamTask(row) : null;
    }
    async listTeamTasks(filter) {
        const conditions = [];
        const args = [];
        if (filter?.workspaceId) {
            conditions.push(`workspace_id = $${args.length + 1}`);
            args.push(filter.workspaceId);
        }
        if (filter?.status) {
            conditions.push(`status = $${args.length + 1}`);
            args.push(filter.status);
        }
        if (filter?.assignedAgentId) {
            conditions.push(`assigned_agent_id = $${args.length + 1}`);
            args.push(filter.assignedAgentId);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const res = await this.pool.query(`SELECT * FROM team_tasks ${where} ORDER BY updated_at DESC, created_at DESC`, args);
        return res.rows.map((row) => rowToTeamTask(row));
    }
    async updateTeamTask(id, updates) {
        const sets = [];
        const args = [];
        if (updates.title !== undefined) {
            sets.push(`title = $${args.length + 1}`);
            args.push(updates.title);
        }
        if (updates.description !== undefined) {
            sets.push(`description = $${args.length + 1}`);
            args.push(updates.description);
        }
        if (updates.status !== undefined) {
            sets.push(`status = $${args.length + 1}`);
            args.push(updates.status);
        }
        if (updates.priority !== undefined) {
            sets.push(`priority = $${args.length + 1}`);
            args.push(updates.priority);
        }
        if (updates.assignedAgentId !== undefined) {
            sets.push(`assigned_agent_id = $${args.length + 1}`);
            args.push(updates.assignedAgentId);
        }
        if (updates.dependsOnTaskIds !== undefined) {
            sets.push(`depends_on_task_ids = $${args.length + 1}`);
            args.push(JSON.stringify(updates.dependsOnTaskIds));
        }
        if (updates.reviewRequired !== undefined) {
            sets.push(`review_required = $${args.length + 1}`);
            args.push(updates.reviewRequired);
        }
        if (updates.reviewerAgentId !== undefined) {
            sets.push(`reviewer_agent_id = $${args.length + 1}`);
            args.push(updates.reviewerAgentId);
        }
        if (updates.reviewStatus !== undefined) {
            sets.push(`review_status = $${args.length + 1}`);
            args.push(updates.reviewStatus);
        }
        if (updates.attemptCount !== undefined) {
            sets.push(`attempt_count = $${args.length + 1}`);
            args.push(updates.attemptCount);
        }
        if (updates.maxAttempts !== undefined) {
            sets.push(`max_attempts = $${args.length + 1}`);
            args.push(Math.max(1, updates.maxAttempts));
        }
        if (updates.lastAttemptAt !== undefined) {
            sets.push(`last_attempt_at = $${args.length + 1}`);
            args.push(updates.lastAttemptAt ? updates.lastAttemptAt.getTime() : null);
        }
        if (updates.escalationStatus !== undefined) {
            sets.push(`escalation_status = $${args.length + 1}`);
            args.push(updates.escalationStatus);
        }
        if (updates.escalationReason !== undefined) {
            sets.push(`escalation_reason = $${args.length + 1}`);
            args.push(updates.escalationReason);
        }
        if (updates.humanOwnerUserId !== undefined) {
            sets.push(`human_owner_user_id = $${args.length + 1}`);
            args.push(updates.humanOwnerUserId);
        }
        if (updates.blockedReason !== undefined) {
            sets.push(`blocked_reason = $${args.length + 1}`);
            args.push(updates.blockedReason);
        }
        if (updates.resultSummary !== undefined) {
            sets.push(`result_summary = $${args.length + 1}`);
            args.push(updates.resultSummary);
        }
        if (updates.dueAt !== undefined) {
            sets.push(`due_at = $${args.length + 1}`);
            args.push(updates.dueAt ? updates.dueAt.getTime() : null);
        }
        if (updates.metadata !== undefined) {
            sets.push(`metadata = $${args.length + 1}`);
            args.push(JSON.stringify(updates.metadata));
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_tasks SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        const updated = row ? rowToTeamTask(row) : null;
        if (updated) {
            publishTeamRuntimeWakeup({
                kind: 'task_updated',
                workspaceId: updated.workspaceId,
                taskId: updated.id,
                assignedAgentId: updated.assignedAgentId,
                status: updated.status,
            });
        }
        return updated;
    }
    async deleteTeamTask(id) {
        const res = await this.pool.query(`DELETE FROM team_tasks WHERE id = $1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async getTeamPolicy(workspaceId) {
        const res = await this.pool.query(`SELECT * FROM team_policies WHERE workspace_id = $1`, [workspaceId]);
        const row = res.rows[0];
        return row ? rowToTeamPolicy(row) : null;
    }
    async upsertTeamPolicy(policy) {
        const existing = await this.getTeamPolicy(policy.workspaceId);
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO team_policies (
         workspace_id, auto_dispatch, auto_review, max_auto_retries, escalate_on_blocked, escalate_on_review_changes,
         escalate_on_sla_breach, auto_share_task_results, shared_memory_prefix, default_task_sla_hours, default_human_owner_user_id,
         approval_reminder_after_minutes, approval_escalation_after_minutes, oncall_assignment_timeout_minutes, oncall_max_handoffs_per_task, escalation_owner_user_id,
         updated_by, metadata, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)
       ON CONFLICT (workspace_id) DO UPDATE SET
         auto_dispatch = EXCLUDED.auto_dispatch,
         auto_review = EXCLUDED.auto_review,
         max_auto_retries = EXCLUDED.max_auto_retries,
         escalate_on_blocked = EXCLUDED.escalate_on_blocked,
         escalate_on_review_changes = EXCLUDED.escalate_on_review_changes,
         escalate_on_sla_breach = EXCLUDED.escalate_on_sla_breach,
         auto_share_task_results = EXCLUDED.auto_share_task_results,
         shared_memory_prefix = EXCLUDED.shared_memory_prefix,
         default_task_sla_hours = EXCLUDED.default_task_sla_hours,
         default_human_owner_user_id = EXCLUDED.default_human_owner_user_id,
         approval_reminder_after_minutes = EXCLUDED.approval_reminder_after_minutes,
         approval_escalation_after_minutes = EXCLUDED.approval_escalation_after_minutes,
         oncall_assignment_timeout_minutes = EXCLUDED.oncall_assignment_timeout_minutes,
         oncall_max_handoffs_per_task = EXCLUDED.oncall_max_handoffs_per_task,
         escalation_owner_user_id = EXCLUDED.escalation_owner_user_id,
         updated_by = EXCLUDED.updated_by,
         metadata = EXCLUDED.metadata,
         updated_at = EXCLUDED.updated_at
       RETURNING *`, [
            policy.workspaceId,
            policy.autoDispatch ?? existing?.autoDispatch ?? true,
            policy.autoReview ?? existing?.autoReview ?? true,
            Math.max(0, policy.maxAutoRetries ?? existing?.maxAutoRetries ?? 1),
            policy.escalateOnBlocked ?? existing?.escalateOnBlocked ?? true,
            policy.escalateOnReviewChanges ?? existing?.escalateOnReviewChanges ?? true,
            policy.escalateOnSlaBreach ?? existing?.escalateOnSlaBreach ?? true,
            policy.autoShareTaskResults ?? existing?.autoShareTaskResults ?? false,
            (policy.sharedMemoryPrefix ?? existing?.sharedMemoryPrefix ?? 'team:').slice(0, 64),
            Math.max(1, policy.defaultTaskSlaHours ?? existing?.defaultTaskSlaHours ?? 24),
            policy.defaultHumanOwnerUserId ?? existing?.defaultHumanOwnerUserId ?? null,
            Math.max(1, policy.approvalReminderAfterMinutes ?? existing?.approvalReminderAfterMinutes ?? 30),
            Math.max(1, policy.approvalEscalationAfterMinutes ?? existing?.approvalEscalationAfterMinutes ?? 120),
            Math.max(1, policy.onCallAssignmentTimeoutMinutes ?? existing?.onCallAssignmentTimeoutMinutes ?? 10),
            Math.max(1, policy.onCallMaxHandoffsPerTask ?? existing?.onCallMaxHandoffsPerTask ?? 4),
            policy.escalationOwnerUserId ?? existing?.escalationOwnerUserId ?? null,
            policy.updatedBy,
            (() => {
                const merged = {
                    ...(existing?.metadata ?? {}),
                    ...(policy.metadata ?? {}),
                };
                if (policy.autoPropagateLearnings !== undefined) {
                    merged['autoPropagateLearnings'] = policy.autoPropagateLearnings;
                }
                if (policy.autoGovernLearnedRules !== undefined) {
                    merged['autoGovernLearnedRules'] = policy.autoGovernLearnedRules;
                    merged['ruleLibraryAutoGovernanceEnabled'] = policy.autoGovernLearnedRules;
                }
                return Object.keys(merged).length > 0 ? JSON.stringify(merged) : null;
            })(),
            existing?.createdAt.getTime() ?? now,
            now,
        ]);
        return rowToTeamPolicy(res.rows[0]);
    }
    async createTeamTaskApproval(approval) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO team_task_approvals (
         id, workspace_id, task_id, status, requested_by, requested_for_user_id, reason, resolution_notes, created_at, updated_at, resolved_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       RETURNING *`, [
            nanoid(),
            approval.workspaceId,
            approval.taskId,
            approval.status ?? 'pending',
            approval.requestedBy,
            approval.requestedForUserId,
            approval.reason,
            approval.resolutionNotes ?? null,
            now,
            now,
            approval.resolvedAt ? approval.resolvedAt.getTime() : null,
        ]);
        const created = rowToTeamTaskApproval(res.rows[0]);
        publishTeamRuntimeWakeup({
            kind: 'approval_created',
            workspaceId: created.workspaceId,
            approvalId: created.id,
            taskId: created.taskId,
            status: created.status,
        });
        return created;
    }
    async listTeamTaskApprovals(filter) {
        const conditions = [];
        const args = [];
        if (filter?.workspaceId) {
            conditions.push(`workspace_id = $${args.length + 1}`);
            args.push(filter.workspaceId);
        }
        if (filter?.taskId) {
            conditions.push(`task_id = $${args.length + 1}`);
            args.push(filter.taskId);
        }
        if (filter?.status) {
            conditions.push(`status = $${args.length + 1}`);
            args.push(filter.status);
        }
        if (filter?.requestedForUserId) {
            conditions.push(`requested_for_user_id = $${args.length + 1}`);
            args.push(filter.requestedForUserId);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const res = await this.pool.query(`SELECT * FROM team_task_approvals ${where} ORDER BY updated_at DESC, created_at DESC`, args);
        return res.rows.map((row) => rowToTeamTaskApproval(row));
    }
    async updateTeamTaskApproval(id, updates) {
        const sets = [];
        const args = [];
        if (updates.status !== undefined) {
            sets.push(`status = $${args.length + 1}`);
            args.push(updates.status);
        }
        if (updates.resolutionNotes !== undefined) {
            sets.push(`resolution_notes = $${args.length + 1}`);
            args.push(updates.resolutionNotes);
        }
        if (updates.resolvedAt !== undefined) {
            sets.push(`resolved_at = $${args.length + 1}`);
            args.push(updates.resolvedAt ? updates.resolvedAt.getTime() : null);
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_task_approvals SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        const updated = row ? rowToTeamTaskApproval(row) : null;
        if (updated) {
            publishTeamRuntimeWakeup({
                kind: 'approval_updated',
                workspaceId: updated.workspaceId,
                approvalId: updated.id,
                taskId: updated.taskId,
                status: updated.status,
            });
        }
        return updated;
    }
    async createTeamNotification(notification) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO team_notifications (
         id, workspace_id, recipient_user_id, type, severity, status, delivery_status, delivery_attempt_count,
         title, message, task_id, approval_id, last_delivery_error, metadata, created_at, updated_at, read_at, last_delivery_attempt_at, delivered_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
       RETURNING *`, [
            nanoid(),
            notification.workspaceId,
            notification.recipientUserId,
            notification.type,
            notification.severity ?? 'info',
            notification.status ?? 'unread',
            notification.deliveryStatus ?? 'pending',
            notification.deliveryAttemptCount ?? 0,
            notification.title,
            notification.message,
            notification.taskId ?? null,
            notification.approvalId ?? null,
            notification.lastDeliveryError ?? null,
            notification.metadata ? JSON.stringify(notification.metadata) : null,
            now,
            now,
            notification.readAt ? notification.readAt.getTime() : null,
            notification.lastDeliveryAttemptAt ? notification.lastDeliveryAttemptAt.getTime() : null,
            notification.deliveredAt ? notification.deliveredAt.getTime() : null,
        ]);
        return rowToTeamNotification(res.rows[0]);
    }
    async listTeamNotifications(filter) {
        const conditions = [];
        const args = [];
        if (filter?.workspaceId) {
            conditions.push(`workspace_id = $${args.length + 1}`);
            args.push(filter.workspaceId);
        }
        if (filter?.recipientUserId) {
            conditions.push(`recipient_user_id = $${args.length + 1}`);
            args.push(filter.recipientUserId);
        }
        if (filter?.status) {
            conditions.push(`status = $${args.length + 1}`);
            args.push(filter.status);
        }
        if (filter?.deliveryStatus) {
            conditions.push(`delivery_status = $${args.length + 1}`);
            args.push(filter.deliveryStatus);
        }
        if (filter?.type) {
            conditions.push(`type = $${args.length + 1}`);
            args.push(filter.type);
        }
        if (filter?.taskId) {
            conditions.push(`task_id = $${args.length + 1}`);
            args.push(filter.taskId);
        }
        if (filter?.approvalId) {
            conditions.push(`approval_id = $${args.length + 1}`);
            args.push(filter.approvalId);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const res = await this.pool.query(`SELECT * FROM team_notifications ${where} ORDER BY updated_at DESC, created_at DESC`, args);
        return res.rows.map((row) => rowToTeamNotification(row));
    }
    async updateTeamNotification(id, updates) {
        const sets = [];
        const args = [];
        if (updates.status !== undefined) {
            sets.push(`status = $${args.length + 1}`);
            args.push(updates.status);
        }
        if (updates.deliveryStatus !== undefined) {
            sets.push(`delivery_status = $${args.length + 1}`);
            args.push(updates.deliveryStatus);
        }
        if (updates.deliveryAttemptCount !== undefined) {
            sets.push(`delivery_attempt_count = $${args.length + 1}`);
            args.push(updates.deliveryAttemptCount);
        }
        if (updates.title !== undefined) {
            sets.push(`title = $${args.length + 1}`);
            args.push(updates.title);
        }
        if (updates.message !== undefined) {
            sets.push(`message = $${args.length + 1}`);
            args.push(updates.message);
        }
        if (updates.lastDeliveryError !== undefined) {
            sets.push(`last_delivery_error = $${args.length + 1}`);
            args.push(updates.lastDeliveryError);
        }
        if (updates.metadata !== undefined) {
            sets.push(`metadata = $${args.length + 1}`);
            args.push(JSON.stringify(updates.metadata));
        }
        if (updates.readAt !== undefined) {
            sets.push(`read_at = $${args.length + 1}`);
            args.push(updates.readAt ? updates.readAt.getTime() : null);
        }
        if (updates.lastDeliveryAttemptAt !== undefined) {
            sets.push(`last_delivery_attempt_at = $${args.length + 1}`);
            args.push(updates.lastDeliveryAttemptAt ? updates.lastDeliveryAttemptAt.getTime() : null);
        }
        if (updates.deliveredAt !== undefined) {
            sets.push(`delivered_at = $${args.length + 1}`);
            args.push(updates.deliveredAt ? updates.deliveredAt.getTime() : null);
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_notifications SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        return row ? rowToTeamNotification(row) : null;
    }
    async createTeamNotificationRoute(route) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO team_notification_routes (
         id, workspace_id, recipient_user_id, channel, chat_id, enabled, created_by, metadata, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING *`, [
            nanoid(),
            route.workspaceId,
            route.recipientUserId,
            route.channel,
            route.chatId,
            route.enabled ?? true,
            route.createdBy,
            route.metadata ? JSON.stringify(route.metadata) : null,
            now,
            now,
        ]);
        return rowToTeamNotificationRoute(res.rows[0]);
    }
    async listTeamNotificationRoutes(filter) {
        const conditions = [];
        const args = [];
        if (filter?.workspaceId) {
            conditions.push(`workspace_id = $${args.length + 1}`);
            args.push(filter.workspaceId);
        }
        if (filter?.recipientUserId) {
            conditions.push(`recipient_user_id = $${args.length + 1}`);
            args.push(filter.recipientUserId);
        }
        if (filter?.channel) {
            conditions.push(`channel = $${args.length + 1}`);
            args.push(filter.channel);
        }
        if (filter?.enabled !== undefined) {
            conditions.push(`enabled = $${args.length + 1}`);
            args.push(filter.enabled);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const res = await this.pool.query(`SELECT * FROM team_notification_routes ${where} ORDER BY updated_at DESC, created_at DESC`, args);
        return res.rows.map((row) => rowToTeamNotificationRoute(row));
    }
    async getTeamNotificationRoute(id) {
        const res = await this.pool.query(`SELECT * FROM team_notification_routes WHERE id = $1`, [id]);
        const row = res.rows[0];
        return row ? rowToTeamNotificationRoute(row) : null;
    }
    async updateTeamNotificationRoute(id, updates) {
        const sets = [];
        const args = [];
        if (updates.recipientUserId !== undefined) {
            sets.push(`recipient_user_id = $${args.length + 1}`);
            args.push(updates.recipientUserId);
        }
        if (updates.channel !== undefined) {
            sets.push(`channel = $${args.length + 1}`);
            args.push(updates.channel);
        }
        if (updates.chatId !== undefined) {
            sets.push(`chat_id = $${args.length + 1}`);
            args.push(updates.chatId);
        }
        if (updates.enabled !== undefined) {
            sets.push(`enabled = $${args.length + 1}`);
            args.push(updates.enabled);
        }
        if (updates.metadata !== undefined) {
            sets.push(`metadata = $${args.length + 1}`);
            args.push(JSON.stringify(updates.metadata));
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_notification_routes SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        return row ? rowToTeamNotificationRoute(row) : null;
    }
    async deleteTeamNotificationRoute(id) {
        const res = await this.pool.query(`DELETE FROM team_notification_routes WHERE id = $1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async createTeamMailboxMessage(message) {
        const now = Date.now();
        const dedupeKey = message.dedupeKey?.trim() || null;
        if (dedupeKey) {
            const existing = await this.pool.query(`SELECT * FROM team_mailbox_messages
         WHERE workspace_id = $1 AND dedupe_key = $2
         ORDER BY updated_at DESC
         LIMIT 1`, [message.workspaceId, dedupeKey]);
            const row = existing.rows[0];
            if (row) {
                return rowToTeamMailboxMessage(row);
            }
        }
        const id = nanoid();
        const threadId = message.threadId?.trim() || `thread:${message.workspaceId}:${id}`;
        const res = await this.pool.query(`INSERT INTO team_mailbox_messages (
         id, workspace_id, thread_id, dedupe_key, sender_agent_id, sender_user_id, recipient_agent_id, task_id,
         type, status, subject, message, metadata, acknowledged_at, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
       RETURNING *`, [
            id,
            message.workspaceId,
            threadId,
            dedupeKey,
            message.senderAgentId ?? null,
            message.senderUserId ?? null,
            message.recipientAgentId ?? null,
            message.taskId ?? null,
            message.type ?? 'direct',
            message.status ?? 'pending',
            message.subject ?? null,
            message.message,
            message.metadata ? JSON.stringify(message.metadata) : null,
            message.acknowledgedAt ? message.acknowledgedAt.getTime() : null,
            now,
            now,
        ]);
        const created = rowToTeamMailboxMessage(res.rows[0]);
        publishTeamRuntimeWakeup({
            kind: 'mailbox_created',
            workspaceId: created.workspaceId,
            messageId: created.id,
            recipientAgentId: created.recipientAgentId,
            taskId: created.taskId,
            status: created.status,
        });
        return created;
    }
    async listTeamMailboxMessages(filter) {
        const conditions = [];
        const args = [];
        if (filter?.workspaceId) {
            conditions.push(`workspace_id = $${args.length + 1}`);
            args.push(filter.workspaceId);
        }
        if (filter?.threadId) {
            conditions.push(`thread_id = $${args.length + 1}`);
            args.push(filter.threadId);
        }
        if (filter?.dedupeKey) {
            conditions.push(`dedupe_key = $${args.length + 1}`);
            args.push(filter.dedupeKey);
        }
        if (filter?.senderAgentId) {
            conditions.push(`sender_agent_id = $${args.length + 1}`);
            args.push(filter.senderAgentId);
        }
        if (filter?.recipientAgentId) {
            conditions.push(`(recipient_agent_id = $${args.length + 1} OR recipient_agent_id IS NULL)`);
            args.push(filter.recipientAgentId);
        }
        if (filter?.taskId) {
            conditions.push(`task_id = $${args.length + 1}`);
            args.push(filter.taskId);
        }
        if (filter?.type) {
            conditions.push(`type = $${args.length + 1}`);
            args.push(filter.type);
        }
        if (filter?.status) {
            conditions.push(`status = $${args.length + 1}`);
            args.push(filter.status);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const res = await this.pool.query(`SELECT * FROM team_mailbox_messages ${where} ORDER BY created_at DESC, updated_at DESC`, args);
        return res.rows.map((row) => rowToTeamMailboxMessage(row));
    }
    async updateTeamMailboxMessage(id, updates) {
        const sets = [];
        const args = [];
        if (updates.status !== undefined) {
            sets.push(`status = $${args.length + 1}`);
            args.push(updates.status);
        }
        if (updates.subject !== undefined) {
            sets.push(`subject = $${args.length + 1}`);
            args.push(updates.subject);
        }
        if (updates.message !== undefined) {
            sets.push(`message = $${args.length + 1}`);
            args.push(updates.message);
        }
        if (updates.metadata !== undefined) {
            sets.push(`metadata = $${args.length + 1}`);
            args.push(JSON.stringify(updates.metadata));
        }
        if (updates.acknowledgedAt !== undefined) {
            sets.push(`acknowledged_at = $${args.length + 1}`);
            args.push(updates.acknowledgedAt ? updates.acknowledgedAt.getTime() : null);
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_mailbox_messages SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        const updated = row ? rowToTeamMailboxMessage(row) : null;
        if (updated) {
            publishTeamRuntimeWakeup({
                kind: 'mailbox_updated',
                workspaceId: updated.workspaceId,
                messageId: updated.id,
                recipientAgentId: updated.recipientAgentId,
                taskId: updated.taskId,
                status: updated.status,
            });
        }
        return updated;
    }
    async createTeamOnCallRotation(rotation) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO team_oncall_rotations (
         id, workspace_id, name, enabled, schedule_type, anchor_date, department, role,
         primary_agent_ids, secondary_agent_ids, created_by, metadata, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       RETURNING *`, [
            nanoid(),
            rotation.workspaceId,
            rotation.name,
            rotation.enabled ?? true,
            rotation.scheduleType ?? 'daily',
            (rotation.anchorDate ?? new Date()).getTime(),
            rotation.department ?? null,
            rotation.role ?? null,
            JSON.stringify(rotation.primaryAgentIds ?? []),
            JSON.stringify(rotation.secondaryAgentIds ?? []),
            rotation.createdBy,
            rotation.metadata ? JSON.stringify(rotation.metadata) : null,
            now,
            now,
        ]);
        return rowToTeamOnCallRotation(res.rows[0]);
    }
    async listTeamOnCallRotations(filter) {
        const conditions = [];
        const args = [];
        if (filter?.workspaceId) {
            conditions.push(`workspace_id = $${args.length + 1}`);
            args.push(filter.workspaceId);
        }
        if (filter?.enabled !== undefined) {
            conditions.push(`enabled = $${args.length + 1}`);
            args.push(filter.enabled);
        }
        if (filter?.department) {
            conditions.push(`department = $${args.length + 1}`);
            args.push(filter.department);
        }
        if (filter?.role) {
            conditions.push(`role = $${args.length + 1}`);
            args.push(filter.role);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const res = await this.pool.query(`SELECT * FROM team_oncall_rotations ${where} ORDER BY updated_at DESC, created_at DESC`, args);
        return res.rows.map((row) => rowToTeamOnCallRotation(row));
    }
    async getTeamOnCallRotation(id) {
        const res = await this.pool.query(`SELECT * FROM team_oncall_rotations WHERE id = $1`, [id]);
        const row = res.rows[0];
        return row ? rowToTeamOnCallRotation(row) : null;
    }
    async updateTeamOnCallRotation(id, updates) {
        const sets = [];
        const args = [];
        if (updates.name !== undefined) {
            sets.push(`name = $${args.length + 1}`);
            args.push(updates.name);
        }
        if (updates.enabled !== undefined) {
            sets.push(`enabled = $${args.length + 1}`);
            args.push(updates.enabled);
        }
        if (updates.scheduleType !== undefined) {
            sets.push(`schedule_type = $${args.length + 1}`);
            args.push(updates.scheduleType);
        }
        if (updates.anchorDate !== undefined) {
            sets.push(`anchor_date = $${args.length + 1}`);
            args.push(updates.anchorDate.getTime());
        }
        if (updates.department !== undefined) {
            sets.push(`department = $${args.length + 1}`);
            args.push(updates.department);
        }
        if (updates.role !== undefined) {
            sets.push(`role = $${args.length + 1}`);
            args.push(updates.role);
        }
        if (updates.primaryAgentIds !== undefined) {
            sets.push(`primary_agent_ids = $${args.length + 1}`);
            args.push(JSON.stringify(updates.primaryAgentIds));
        }
        if (updates.secondaryAgentIds !== undefined) {
            sets.push(`secondary_agent_ids = $${args.length + 1}`);
            args.push(JSON.stringify(updates.secondaryAgentIds));
        }
        if (updates.metadata !== undefined) {
            sets.push(`metadata = $${args.length + 1}`);
            args.push(JSON.stringify(updates.metadata));
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_oncall_rotations SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        return row ? rowToTeamOnCallRotation(row) : null;
    }
    async deleteTeamOnCallRotation(id) {
        const res = await this.pool.query(`DELETE FROM team_oncall_rotations WHERE id = $1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async createTeamTemplate(template) {
        const now = Date.now();
        const res = await this.pool.query(`INSERT INTO team_templates (
         id, workspace_id, name, description, department, role, goal_template, variables, task_blueprints, created_by, metadata, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       RETURNING *`, [
            nanoid(),
            template.workspaceId,
            template.name,
            template.description ?? null,
            template.department ?? null,
            template.role ?? null,
            template.goalTemplate ?? null,
            JSON.stringify(template.variables ?? []),
            JSON.stringify(template.taskBlueprints ?? []),
            template.createdBy,
            template.metadata ? JSON.stringify(template.metadata) : null,
            now,
            now,
        ]);
        return rowToTeamTemplate(res.rows[0]);
    }
    async listTeamTemplates(workspaceId) {
        const res = workspaceId
            ? await this.pool.query(`SELECT * FROM team_templates WHERE workspace_id = $1 ORDER BY updated_at DESC, created_at DESC`, [workspaceId])
            : await this.pool.query(`SELECT * FROM team_templates ORDER BY updated_at DESC, created_at DESC`);
        return res.rows.map((row) => rowToTeamTemplate(row));
    }
    async getTeamTemplate(id) {
        const res = await this.pool.query(`SELECT * FROM team_templates WHERE id = $1`, [id]);
        const row = res.rows[0];
        return row ? rowToTeamTemplate(row) : null;
    }
    async updateTeamTemplate(id, updates) {
        const sets = [];
        const args = [];
        if (updates.name !== undefined) {
            sets.push(`name = $${args.length + 1}`);
            args.push(updates.name);
        }
        if (updates.description !== undefined) {
            sets.push(`description = $${args.length + 1}`);
            args.push(updates.description);
        }
        if (updates.department !== undefined) {
            sets.push(`department = $${args.length + 1}`);
            args.push(updates.department);
        }
        if (updates.role !== undefined) {
            sets.push(`role = $${args.length + 1}`);
            args.push(updates.role);
        }
        if (updates.goalTemplate !== undefined) {
            sets.push(`goal_template = $${args.length + 1}`);
            args.push(updates.goalTemplate);
        }
        if (updates.variables !== undefined) {
            sets.push(`variables = $${args.length + 1}`);
            args.push(JSON.stringify(updates.variables));
        }
        if (updates.taskBlueprints !== undefined) {
            sets.push(`task_blueprints = $${args.length + 1}`);
            args.push(JSON.stringify(updates.taskBlueprints));
        }
        if (updates.metadata !== undefined) {
            sets.push(`metadata = $${args.length + 1}`);
            args.push(JSON.stringify(updates.metadata));
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_templates SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        return row ? rowToTeamTemplate(row) : null;
    }
    async deleteTeamTemplate(id) {
        const res = await this.pool.query(`DELETE FROM team_templates WHERE id = $1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async createTeamTopology(topology) {
        const now = Date.now();
        const metadata = mergeTeamTopologyMetadata(topology.metadata, {
            ...(Object.prototype.hasOwnProperty.call(topology, 'orchestratorRules')
                ? { orchestratorRules: topology.orchestratorRules ?? null }
                : {}),
            ...(Object.prototype.hasOwnProperty.call(topology, 'adaptiveModelPolicy')
                ? { adaptiveModelPolicy: topology.adaptiveModelPolicy ?? null }
                : {}),
            ...(Object.prototype.hasOwnProperty.call(topology, 'modelRoutes')
                ? { modelRoutes: topology.modelRoutes ?? null }
                : {}),
            ...(Object.prototype.hasOwnProperty.call(topology, 'candidateStrategy')
                ? { candidateStrategy: topology.candidateStrategy ?? null }
                : {}),
            ...(Object.prototype.hasOwnProperty.call(topology, 'candidateRolloutPolicy')
                ? { candidateRolloutPolicy: topology.candidateRolloutPolicy ?? null }
                : {}),
            ...(Object.prototype.hasOwnProperty.call(topology, 'candidateRolloutControl')
                ? { candidateRolloutControl: topology.candidateRolloutControl ?? null }
                : {}),
        }, {
            nowIso: new Date(now).toISOString(),
        });
        const res = await this.pool.query(`INSERT INTO team_topologies (
         id, workspace_id, name, department, role, supervisor_agent_id, worker_agent_ids, default_template_ids,
         default_human_owner_user_id, metadata, created_by, created_at, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       RETURNING *`, [
            nanoid(),
            topology.workspaceId,
            topology.name,
            topology.department ?? null,
            topology.role ?? null,
            topology.supervisorAgentId ?? null,
            JSON.stringify(topology.workerAgentIds ?? []),
            JSON.stringify(topology.defaultTemplateIds ?? []),
            topology.defaultHumanOwnerUserId ?? null,
            metadata ? JSON.stringify(metadata) : null,
            topology.createdBy,
            now,
            now,
        ]);
        return rowToTeamTopology(res.rows[0]);
    }
    async listTeamTopologies(workspaceId) {
        const res = workspaceId
            ? await this.pool.query(`SELECT * FROM team_topologies WHERE workspace_id = $1 ORDER BY updated_at DESC, created_at DESC`, [workspaceId])
            : await this.pool.query(`SELECT * FROM team_topologies ORDER BY updated_at DESC, created_at DESC`);
        return res.rows.map((row) => rowToTeamTopology(row));
    }
    async getTeamTopology(id) {
        const res = await this.pool.query(`SELECT * FROM team_topologies WHERE id = $1`, [id]);
        const row = res.rows[0];
        return row ? rowToTeamTopology(row) : null;
    }
    async updateTeamTopology(id, updates) {
        const existing = await this.getTeamTopology(id);
        if (!existing)
            return null;
        const sets = [];
        const args = [];
        if (updates.name !== undefined) {
            sets.push(`name = $${args.length + 1}`);
            args.push(updates.name);
        }
        if (updates.department !== undefined) {
            sets.push(`department = $${args.length + 1}`);
            args.push(updates.department);
        }
        if (updates.role !== undefined) {
            sets.push(`role = $${args.length + 1}`);
            args.push(updates.role);
        }
        if (updates.supervisorAgentId !== undefined) {
            sets.push(`supervisor_agent_id = $${args.length + 1}`);
            args.push(updates.supervisorAgentId);
        }
        if (updates.workerAgentIds !== undefined) {
            sets.push(`worker_agent_ids = $${args.length + 1}`);
            args.push(JSON.stringify(updates.workerAgentIds));
        }
        if (updates.defaultTemplateIds !== undefined) {
            sets.push(`default_template_ids = $${args.length + 1}`);
            args.push(JSON.stringify(updates.defaultTemplateIds));
        }
        if (updates.defaultHumanOwnerUserId !== undefined) {
            sets.push(`default_human_owner_user_id = $${args.length + 1}`);
            args.push(updates.defaultHumanOwnerUserId);
        }
        const hasTopologyConfigUpdate = Object.prototype.hasOwnProperty.call(updates, 'orchestratorRules')
            || Object.prototype.hasOwnProperty.call(updates, 'adaptiveModelPolicy')
            || Object.prototype.hasOwnProperty.call(updates, 'modelRoutes')
            || Object.prototype.hasOwnProperty.call(updates, 'candidateStrategy')
            || Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutPolicy')
            || Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutControl');
        if (updates.metadata !== undefined || hasTopologyConfigUpdate) {
            const mergedMetadata = mergeTeamTopologyMetadata(updates.metadata !== undefined ? updates.metadata : existing.metadata, {
                ...(Object.prototype.hasOwnProperty.call(updates, 'orchestratorRules')
                    ? { orchestratorRules: updates.orchestratorRules ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(updates, 'adaptiveModelPolicy')
                    ? { adaptiveModelPolicy: updates.adaptiveModelPolicy ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(updates, 'modelRoutes')
                    ? { modelRoutes: updates.modelRoutes ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(updates, 'candidateStrategy')
                    ? { candidateStrategy: updates.candidateStrategy ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutPolicy')
                    ? { candidateRolloutPolicy: updates.candidateRolloutPolicy ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutControl')
                    ? { candidateRolloutControl: updates.candidateRolloutControl ?? null }
                    : {}),
            }, {
                existingTopology: existing,
                nowIso: new Date().toISOString(),
            });
            sets.push(`metadata = $${args.length + 1}`);
            args.push(mergedMetadata ? JSON.stringify(mergedMetadata) : null);
        }
        sets.push(`updated_at = $${args.length + 1}`);
        args.push(Date.now(), id);
        const res = await this.pool.query(`UPDATE team_topologies SET ${sets.join(', ')} WHERE id = $${args.length} RETURNING *`, args);
        const row = res.rows[0];
        return row ? rowToTeamTopology(row) : null;
    }
    async deleteTeamTopology(id) {
        const res = await this.pool.query(`DELETE FROM team_topologies WHERE id = $1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async addMessage(sessionId, userId, channel, message) {
        await this.pool.query(`INSERT INTO conversations (id, session_id, user_id, channel, role, content, tool_call_id, tool_name, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`, [nanoid(), sessionId, userId, channel, message.role, message.content,
            message.toolCallId ?? null, message.toolName ?? null, Date.now()]);
    }
    async getHistory(sessionId, limit = 20) {
        const res = await this.pool.query(`SELECT role, content, tool_call_id, tool_name FROM conversations
       WHERE session_id=$1 ORDER BY created_at DESC LIMIT $2`, [sessionId, limit]);
        return res.rows.reverse().map((r) => ({
            role: r.role,
            content: r.content,
            toolCallId: r.tool_call_id ?? undefined,
            toolName: r.tool_name ?? undefined,
        }));
    }
    async clearHistory(sessionId) {
        await this.pool.query(`DELETE FROM conversations WHERE session_id=$1`, [sessionId]);
    }
    async getHistoryForUser(sessionId, userId, limit = 20) {
        const res = await this.pool.query(`SELECT user_id FROM sessions WHERE id=$1`, [sessionId]);
        if (!res.rows[0] || res.rows[0].user_id !== userId)
            return null;
        return this.getHistory(sessionId, limit);
    }
    async clearHistoryForUser(sessionId, userId) {
        const res = await this.pool.query(`SELECT user_id FROM sessions WHERE id=$1`, [sessionId]);
        if (!res.rows[0] || res.rows[0].user_id !== userId)
            return false;
        await this.clearHistory(sessionId);
        return true;
    }
    // ── Sessions ───────────────────────────────────────────────────────────────
    async getOrCreateSession(userId, channel, chatId) {
        const existing = await this.pool.query(`SELECT id FROM sessions WHERE user_id=$1 AND channel=$2 AND chat_id=$3`, [userId, channel, chatId]);
        if (existing.rows[0]) {
            await this.pool.query(`UPDATE sessions SET last_active=$1 WHERE id=$2`, [Date.now(), existing.rows[0].id]);
            return existing.rows[0].id;
        }
        const hmacKey = config.gateway.secret || 'greenfrog-fallback';
        const id = createHmac('sha256', hmacKey).update(`${userId}:${channel}:${chatId}`).digest('hex').slice(0, 32);
        await this.pool.query(`INSERT INTO sessions (id, user_id, channel, chat_id, created_at, last_active) VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (user_id, channel, chat_id) DO UPDATE SET last_active = EXCLUDED.last_active`, [id, userId, channel, chatId, Date.now(), Date.now()]);
        return id;
    }
    // ── Scheduled Jobs ─────────────────────────────────────────────────────────
    async getSessionOwner(sessionId) {
        const res = await this.pool.query(`SELECT user_id FROM sessions WHERE id=$1`, [sessionId]);
        return res.rows[0]?.user_id ?? null;
    }
    async saveJob(job) {
        const id = nanoid();
        await this.pool.query(`INSERT INTO scheduled_jobs (id, name, cron, prompt, channel, chat_id, user_id, status, last_run, next_run, run_count, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,0,$11)`, [id, job.name, job.cron, job.prompt, job.channel, job.chatId, job.userId,
            job.status, job.lastRun?.getTime() ?? null, job.nextRun?.getTime() ?? null, Date.now()]);
        return id;
    }
    async getJobs(userId) {
        const res = await this.pool.query(userId ? `SELECT * FROM scheduled_jobs WHERE user_id=$1` : `SELECT * FROM scheduled_jobs`, userId ? [userId] : []);
        return res.rows.map((r) => ({
            id: r['id'], name: r['name'], cron: r['cron'],
            prompt: r['prompt'], channel: r['channel'],
            chatId: r['chat_id'], userId: r['user_id'],
            status: r['status'],
            lastRun: r['last_run'] ? new Date(r['last_run']) : undefined,
            nextRun: r['next_run'] ? new Date(r['next_run']) : undefined,
            runCount: r['run_count'], createdAt: new Date(r['created_at']),
        }));
    }
    async updateJobRun(id, nextRun) {
        await this.pool.query(`UPDATE scheduled_jobs SET last_run=$1, next_run=$2, run_count=run_count+1 WHERE id=$3`, [Date.now(), nextRun?.getTime() ?? null, id]);
    }
    async updateJobStatus(id, status) {
        await this.pool.query(`UPDATE scheduled_jobs SET status=$1 WHERE id=$2`, [status, id]);
    }
    async deleteJob(id) {
        const res = await this.pool.query(`DELETE FROM scheduled_jobs WHERE id=$1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async updateJobNotifyIf(id, notifyIf) {
        await this.pool.query(`UPDATE scheduled_jobs SET notify_if=$1 WHERE id=$2`, [notifyIf, id]);
    }
    async updateJobLastResult(id, lastResult) {
        await this.pool.query(`UPDATE scheduled_jobs SET last_result=$1 WHERE id=$2`, [lastResult, id]);
    }
    // ── Feedback & Rules ───────────────────────────────────────────────────────
    async saveInteractionFeedback(opts) {
        return this.saveScopedInteractionFeedback({ userId: opts.userId, channel: opts.channel }, {
            sessionId: opts.sessionId,
            userMessage: opts.userMessage,
            aiResponse: opts.aiResponse,
            feedbackType: opts.feedbackType,
            signal: opts.signal,
            score: opts.score,
        });
    }
    async saveScopedInteractionFeedback(scope, opts) {
        const normalized = normalizeScope(scope);
        await this.pool.query(`INSERT INTO interaction_feedback (id, user_id, channel, workspace_id, agent_id, session_id, user_message, ai_response, feedback_type, signal, score, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [
            nanoid(),
            normalized.userId,
            normalized.channel,
            normalized.workspaceId,
            normalized.agentId,
            opts.sessionId,
            opts.userMessage.slice(0, 500),
            opts.aiResponse.slice(0, 800),
            opts.feedbackType,
            opts.signal ?? null,
            opts.score,
            Date.now(),
        ]);
    }
    async getRecentFeedback(userId, channel, limit = 50) {
        return this.getRecentScopedFeedback({ userId, channel }, limit);
    }
    async getRecentScopedFeedback(scope, limit = 50) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT id, user_message, ai_response, feedback_type, signal, score, created_at
       FROM interaction_feedback WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4
       ORDER BY created_at DESC LIMIT $5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit]);
        return res.rows.map((r) => ({
            id: r['id'], userMessage: r['user_message'],
            aiResponse: r['ai_response'], feedbackType: r['feedback_type'],
            signal: r['signal'], score: r['score'],
            createdAt: new Date(r['created_at']),
        }));
    }
    async getFeedbackStats(userId, channel) {
        return this.getScopedFeedbackStats({ userId, channel });
    }
    async getScopedFeedbackStats(scope) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT COUNT(*) as total,
              SUM(CASE WHEN score > 0 THEN 1 ELSE 0 END) as positive,
              SUM(CASE WHEN score < 0 THEN 1 ELSE 0 END) as negative,
              AVG(score) as avg_score
       FROM interaction_feedback WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId]);
        const r = res.rows[0];
        return {
            total: parseInt(r?.total ?? '0', 10), positive: parseInt(r?.positive ?? '0', 10),
            negative: parseInt(r?.negative ?? '0', 10), avgScore: parseFloat(r?.avg_score ?? '0'),
        };
    }
    async upsertBehavioralRule(opts) {
        return this.upsertScopedBehavioralRule({ userId: opts.userId, channel: opts.channel }, { rule: opts.rule, category: opts.category, confidence: opts.confidence, source: opts.source });
    }
    async recordScopedBehavioralRuleHistory(scope, entry) {
        const normalized = normalizeScope(scope);
        await this.pool.query(`INSERT INTO behavioral_rule_history (
        id, user_id, channel, workspace_id, agent_id, rule, action, related_history_id,
        old_category, old_confidence, old_source, old_evidence_count,
        new_category, new_confidence, new_source, new_evidence_count, created_at
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`, [
            nanoid(),
            normalized.userId,
            normalized.channel,
            normalized.workspaceId,
            normalized.agentId,
            entry.rule,
            entry.action,
            entry.relatedHistoryId ?? null,
            entry.oldCategory ?? null,
            entry.oldConfidence ?? null,
            entry.oldSource ?? null,
            entry.oldEvidenceCount ?? null,
            entry.newCategory ?? null,
            entry.newConfidence ?? null,
            entry.newSource ?? null,
            entry.newEvidenceCount ?? null,
            Date.now(),
        ]);
    }
    async getScopedBehavioralRuleRecord(scope, rule) {
        const normalized = normalizeScope(scope);
        const existing = await this.pool.query(`SELECT id, category, confidence, source, evidence_count FROM behavioral_rules
       WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND rule=$5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, rule]);
        return existing.rows[0] ?? null;
    }
    async putScopedBehavioralRuleExact(scope, params) {
        const normalized = normalizeScope(scope);
        const existing = await this.getScopedBehavioralRuleRecord(scope, params.rule);
        const now = Date.now();
        if (existing) {
            await this.pool.query(`UPDATE behavioral_rules
         SET category=$1, confidence=$2, source=$3, evidence_count=$4, updated_at=$5
         WHERE id=$6`, [params.category, params.confidence, params.source, params.evidenceCount, now, existing.id]);
            return;
        }
        await this.pool.query(`INSERT INTO behavioral_rules (id, user_id, channel, workspace_id, agent_id, rule, category, confidence, source, evidence_count, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [
            nanoid(),
            normalized.userId,
            normalized.channel,
            normalized.workspaceId,
            normalized.agentId,
            params.rule,
            params.category,
            params.confidence,
            params.source,
            params.evidenceCount,
            now,
            now,
        ]);
    }
    async upsertScopedBehavioralRule(scope, opts) {
        const normalized = normalizeScope(scope);
        const now = Date.now();
        const existing = await this.getScopedBehavioralRuleRecord(scope, opts.rule);
        if (existing) {
            const e = existing;
            const newConf = Math.min(100, Math.round((e.confidence + opts.confidence) / 2 + 5));
            const newEvidenceCount = e.evidence_count + 1;
            await this.pool.query(`UPDATE behavioral_rules
         SET category=$1, confidence=$2, source=$3, evidence_count=$4, updated_at=$5
         WHERE id=$6`, [opts.category, newConf, opts.source, newEvidenceCount, now, e.id]);
            await this.recordScopedBehavioralRuleHistory(scope, {
                rule: opts.rule,
                action: 'update',
                oldCategory: e.category,
                oldConfidence: e.confidence,
                oldSource: e.source,
                oldEvidenceCount: e.evidence_count,
                newCategory: opts.category,
                newConfidence: newConf,
                newSource: opts.source,
                newEvidenceCount,
            });
        }
        else {
            await this.pool.query(`INSERT INTO behavioral_rules (id, user_id, channel, workspace_id, agent_id, rule, category, confidence, source, evidence_count, created_at, updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,1,$10,$11)`, [
                nanoid(),
                normalized.userId,
                normalized.channel,
                normalized.workspaceId,
                normalized.agentId,
                opts.rule,
                opts.category,
                opts.confidence,
                opts.source,
                now,
                now,
            ]);
            await this.recordScopedBehavioralRuleHistory(scope, {
                rule: opts.rule,
                action: 'insert',
                newCategory: opts.category,
                newConfidence: opts.confidence,
                newSource: opts.source,
                newEvidenceCount: 1,
            });
        }
    }
    async getBehavioralRules(userId, channel, minConfidence = 40) {
        return this.getScopedBehavioralRules({ userId, channel }, minConfidence);
    }
    async getScopedBehavioralRules(scope, minConfidence = 40) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT rule, category, confidence, source, evidence_count FROM behavioral_rules
       WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND confidence >= $5
       ORDER BY confidence DESC, evidence_count DESC`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, minConfidence]);
        return res.rows.map((r) => ({
            rule: r['rule'], category: r['category'],
            confidence: r['confidence'], source: r['source'],
            evidenceCount: r['evidence_count'],
        }));
    }
    async getBehavioralRuleHistory(userId, channel, limit = 50) {
        return this.getScopedBehavioralRuleHistory({ userId, channel }, limit);
    }
    async getScopedBehavioralRuleHistory(scope, limit = 50) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT * FROM behavioral_rule_history
       WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4
       ORDER BY created_at DESC
       LIMIT $5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit]);
        return res.rows.map((row) => rowToBehavioralRuleHistoryEntry(row));
    }
    async rollbackBehavioralRuleHistory(userId, channel, historyId, source = 'manual') {
        return this.rollbackScopedBehavioralRuleHistory({ userId, channel }, historyId, source);
    }
    async rollbackScopedBehavioralRuleHistory(scope, historyId, source = 'manual') {
        void source;
        const normalized = normalizeScope(scope);
        const history = await this.pool.query(`SELECT * FROM behavioral_rule_history
       WHERE id=$1 AND user_id=$2 AND channel=$3 AND workspace_id=$4 AND agent_id=$5`, [historyId, normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId]);
        const row = history.rows[0];
        if (!row)
            return false;
        const entry = rowToBehavioralRuleHistoryEntry(row);
        const current = await this.getScopedBehavioralRuleRecord(scope, entry.rule);
        if (entry.action === 'insert') {
            if (!current)
                return false;
            await this.pool.query(`DELETE FROM behavioral_rules
         WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND rule=$5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, entry.rule]);
            await this.recordScopedBehavioralRuleHistory(scope, {
                rule: entry.rule,
                action: 'rollback',
                relatedHistoryId: historyId,
                oldCategory: current.category,
                oldConfidence: current.confidence,
                oldSource: current.source,
                oldEvidenceCount: current.evidence_count,
                newCategory: null,
                newConfidence: null,
                newSource: null,
                newEvidenceCount: null,
            });
            return true;
        }
        if (!entry.oldCategory || entry.oldConfidence === null || entry.oldConfidence === undefined || !entry.oldSource || entry.oldEvidenceCount === null || entry.oldEvidenceCount === undefined) {
            return false;
        }
        await this.putScopedBehavioralRuleExact(scope, {
            rule: entry.rule,
            category: entry.oldCategory,
            confidence: entry.oldConfidence,
            source: entry.oldSource,
            evidenceCount: entry.oldEvidenceCount,
        });
        await this.recordScopedBehavioralRuleHistory(scope, {
            rule: entry.rule,
            action: 'rollback',
            relatedHistoryId: historyId,
            oldCategory: current?.category ?? null,
            oldConfidence: current?.confidence ?? null,
            oldSource: current?.source ?? null,
            oldEvidenceCount: current?.evidence_count ?? null,
            newCategory: entry.oldCategory,
            newConfidence: entry.oldConfidence,
            newSource: entry.oldSource,
            newEvidenceCount: entry.oldEvidenceCount,
        });
        return true;
    }
    async deleteBehavioralRule(userId, channel, rule) {
        return this.deleteScopedBehavioralRule({ userId, channel }, rule);
    }
    async deleteScopedBehavioralRule(scope, rule) {
        const normalized = normalizeScope(scope);
        const existing = await this.getScopedBehavioralRuleRecord(scope, rule);
        if (!existing)
            return false;
        const res = await this.pool.query(`DELETE FROM behavioral_rules
       WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND rule=$5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, rule]);
        if ((res.rowCount ?? 0) > 0) {
            await this.recordScopedBehavioralRuleHistory(scope, {
                rule,
                action: 'delete',
                oldCategory: existing.category,
                oldConfidence: existing.confidence,
                oldSource: existing.source,
                oldEvidenceCount: existing.evidence_count,
            });
            return true;
        }
        return false;
    }
    async bulkReplaceScopedBehavioralRules(scope, rules) {
        const normalized = normalizeScope(scope);
        const client = await this.pool.connect();
        try {
            await client.query('BEGIN');
            await client.query(`DELETE FROM behavioral_rules
         WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId]);
            const now = Date.now();
            for (const r of rules) {
                await client.query(`INSERT INTO behavioral_rules (id, user_id, channel, workspace_id, agent_id, rule, category, confidence, source, evidence_count, created_at, updated_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,1,$10,$11)`, [nanoid(), normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId,
                    r.rule, r.category, r.confidence, r.source, now, now]);
            }
            await client.query('COMMIT');
        }
        catch (err) {
            await client.query('ROLLBACK');
            throw err;
        }
        finally {
            client.release();
        }
    }
    async listBehavioralRuleScopes(limit = 200) {
        const res = await this.pool.query(`SELECT user_id, channel, workspace_id, agent_id, COUNT(*) AS rule_count, MAX(updated_at) AS latest_updated_at
       FROM behavioral_rules
       GROUP BY user_id, channel, workspace_id, agent_id
       ORDER BY rule_count DESC, latest_updated_at DESC
       LIMIT $1`, [limit]);
        return res.rows.map((row) => ({
            userId: String(row['user_id']),
            channel: row['channel'],
            ...(String(row['workspace_id'] ?? '') ? { workspaceId: String(row['workspace_id']) } : {}),
            ...(String(row['agent_id'] ?? '') ? { agentId: String(row['agent_id']) } : {}),
            ruleCount: Number(row['rule_count'] ?? 0),
            latestUpdatedAt: row['latest_updated_at'] ? new Date(Number(row['latest_updated_at'])) : null,
        }));
    }
    async decayScopedBehavioralRules(scope, opts) {
        const normalized = normalizeScope(scope);
        const staleAfterDays = Math.max(1, Math.floor(opts?.staleAfterDays ?? 30));
        const deleteAfterDays = Math.max(staleAfterDays, Math.floor(opts?.deleteAfterDays ?? 90));
        const lowEvidenceThreshold = Math.max(1, Math.floor(opts?.lowEvidenceThreshold ?? 1));
        const decayStep = Math.max(1, Math.floor(opts?.decayStep ?? 5));
        const floorConfidence = Math.max(0, Math.min(100, Math.floor(opts?.floorConfidence ?? 35)));
        const staleCutoff = Date.now() - staleAfterDays * 24 * 3600 * 1000;
        const deleteCutoff = Date.now() - deleteAfterDays * 24 * 3600 * 1000;
        const res = await this.pool.query(`SELECT rule, category, confidence, source, evidence_count, updated_at
       FROM behavioral_rules
       WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4
         AND updated_at <= $5 AND evidence_count <= $6 AND source != $7`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, staleCutoff, lowEvidenceThreshold, 'library']);
        let updated = 0;
        let deleted = 0;
        for (const row of res.rows) {
            const rule = String(row['rule']);
            const category = String(row['category']);
            const confidence = Number(row['confidence'] ?? 0);
            const source = String(row['source'] ?? 'decayed');
            const evidenceCount = Number(row['evidence_count'] ?? 1);
            const updatedAt = Number(row['updated_at'] ?? Date.now());
            if (updatedAt <= deleteCutoff && confidence <= floorConfidence) {
                if (await this.deleteScopedBehavioralRule(scope, rule))
                    deleted += 1;
                continue;
            }
            const nextConfidence = Math.max(floorConfidence, confidence - decayStep);
            if (nextConfidence === confidence)
                continue;
            await this.putScopedBehavioralRuleExact(scope, {
                rule,
                category,
                confidence: nextConfidence,
                source: source === 'compressed' ? 'compressed' : 'decayed',
                evidenceCount,
            });
            await this.recordScopedBehavioralRuleHistory(scope, {
                rule,
                action: 'update',
                oldCategory: category,
                oldConfidence: confidence,
                oldSource: source,
                oldEvidenceCount: evidenceCount,
                newCategory: category,
                newConfidence: nextConfidence,
                newSource: source === 'compressed' ? 'compressed' : 'decayed',
                newEvidenceCount: evidenceCount,
            });
            updated += 1;
        }
        return { updated, deleted };
    }
    async summarizeBehavioralRules() {
        const staleCutoff = Date.now() - 30 * 24 * 3600 * 1000;
        const res = await this.pool.query(`SELECT
         COUNT(*) AS total_rules,
         SUM(CASE WHEN source = 'compressed' THEN 1 ELSE 0 END) AS compressed_rules,
         AVG(confidence) AS avg_confidence,
         SUM(CASE WHEN confidence < 50 THEN 1 ELSE 0 END) AS low_confidence_rules,
         SUM(CASE WHEN updated_at <= $1 THEN 1 ELSE 0 END) AS stale_rules,
         COUNT(DISTINCT user_id || '::' || channel || '::' || workspace_id || '::' || agent_id) AS distinct_scopes
       FROM behavioral_rules`, [staleCutoff]);
        const row = res.rows[0];
        return {
            totalRules: Number(row?.['total_rules'] ?? 0),
            compressedRules: Number(row?.['compressed_rules'] ?? 0),
            avgConfidence: Number(Number(row?.['avg_confidence'] ?? 0).toFixed(1)),
            lowConfidenceRules: Number(row?.['low_confidence_rules'] ?? 0),
            staleRules: Number(row?.['stale_rules'] ?? 0),
            distinctScopes: Number(row?.['distinct_scopes'] ?? 0),
        };
    }
    // ── Entities ───────────────────────────────────────────────────────────────
    async upsertEntity(userId, channel, entity) {
        return this.upsertScopedEntity({ userId, channel }, entity);
    }
    async upsertScopedEntity(scope, entity) {
        const normalized = normalizeScope(scope);
        const now = Date.now();
        const existing = await this.pool.query(`SELECT id, attributes, relations, mention_count FROM entities
       WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND name=$5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, entity.name]);
        if (existing.rows[0]) {
            const e = existing.rows[0];
            const merged = { ...JSON.parse(e.attributes), ...entity.attributes };
            const oldRels = e.relations ? JSON.parse(e.relations) : [];
            const relMap = new Map((oldRels ?? []).map((r) => [`${r.type}:${r.target}`, r]));
            for (const r of entity.relations ?? [])
                relMap.set(`${r.type}:${r.target}`, r);
            const mergedRels = [...relMap.values()];
            await this.pool.query(`UPDATE entities SET type=$1, attributes=$2, relations=$3, aliases=$4, mention_count=mention_count+1, last_mentioned=$5 WHERE id=$6`, [entity.type, JSON.stringify(merged),
                mergedRels.length > 0 ? JSON.stringify(mergedRels) : null,
                entity.aliases ? JSON.stringify(entity.aliases) : null, now, e.id]);
            return e.id;
        }
        const id = nanoid();
        await this.pool.query(`INSERT INTO entities (id, user_id, channel, workspace_id, agent_id, type, name, aliases, attributes, relations, mention_count, last_mentioned, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,1,$11,$12)`, [id, normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, entity.type, entity.name,
            entity.aliases ? JSON.stringify(entity.aliases) : null,
            JSON.stringify(entity.attributes),
            entity.relations && entity.relations.length > 0 ? JSON.stringify(entity.relations) : null,
            now, now]);
        return id;
    }
    async getEntities(userId, channel, type) {
        return this.getScopedEntities({ userId, channel }, type);
    }
    async getScopedEntities(scope, type) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(type
            ? `SELECT * FROM entities WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND type=$5 ORDER BY last_mentioned DESC`
            : `SELECT * FROM entities WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 ORDER BY last_mentioned DESC`, type
            ? [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, type]
            : [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId]);
        return res.rows.map(rowToEntity);
    }
    async getEntity(userId, channel, name) {
        return this.getScopedEntity({ userId, channel }, name);
    }
    async getScopedEntity(scope, name) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT * FROM entities WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND name=$5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, name]);
        if (res.rows[0])
            return rowToEntity(res.rows[0]);
        // alias search
        const all = await this.pool.query(`SELECT * FROM entities WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4 AND aliases IS NOT NULL`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId]);
        for (const r of all.rows) {
            try {
                const aliases = JSON.parse(r['aliases']);
                if (aliases.some((a) => a.toLowerCase() === name.toLowerCase()))
                    return rowToEntity(r);
            }
            catch { /* skip */ }
        }
        return null;
    }
    async searchEntities(userId, channel, query, limit = 10) {
        return this.searchScopedEntities({ userId, channel }, query, limit);
    }
    async searchScopedEntities(scope, query, limit = 10) {
        const normalized = normalizeScope(scope);
        const q = `%${query}%`;
        const res = await this.pool.query(`SELECT * FROM entities WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4
       AND (name ILIKE $5 OR attributes ILIKE $5 OR aliases ILIKE $5)
       ORDER BY last_mentioned DESC LIMIT $6`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, q, limit]);
        return res.rows.map(rowToEntity);
    }
    async getRecentEntities(userId, channel, limit = 15) {
        return this.getRecentScopedEntities({ userId, channel }, limit);
    }
    async getRecentScopedEntities(scope, limit = 15) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT * FROM entities
       WHERE user_id=$1 AND channel=$2 AND workspace_id=$3 AND agent_id=$4
       ORDER BY last_mentioned DESC LIMIT $5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit]);
        return res.rows.map(rowToEntity);
    }
    async getPendingTasks(userId, channel) {
        return this.getPendingScopedTasks({ userId, channel });
    }
    async getPendingScopedTasks(scope) {
        const tasks = await this.getScopedEntities(scope, 'task');
        return tasks.filter((t) => {
            const status = (t.attributes['status'] ?? '').toLowerCase();
            return status !== 'done' && status !== 'completed' && status !== 'cancelled';
        });
    }
    async deleteEntity(userId, channel, name) {
        const res = await this.pool.query(`DELETE FROM entities WHERE user_id=$1 AND channel=$2 AND name=$3`, [userId, channel, name]);
        return (res.rowCount ?? 0) > 0;
    }
    // ── Patrol ─────────────────────────────────────────────────────────────────
    async savePatrolCheck(check) {
        const id = nanoid();
        await this.pool.query(`INSERT INTO patrol_checks (id, name, type, target, interval_min, method, expected_status, keyword,
       timeout_ms, alert_threshold, channel, chat_id, user_id, status, consecutive_failures, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'active',0,$14)`, [id, check.name, check.type, check.target, check.intervalMin,
            check.method ?? null, check.expectedStatus ?? null, check.keyword ?? null,
            check.timeoutMs, check.alertThreshold, check.channel, check.chatId, check.userId, Date.now()]);
        return id;
    }
    async getPatrolChecks(userId) {
        const res = await this.pool.query(userId ? `SELECT * FROM patrol_checks WHERE user_id=$1` : `SELECT * FROM patrol_checks`, userId ? [userId] : []);
        return res.rows.map((r) => ({
            id: r['id'], name: r['name'],
            type: r['type'], target: r['target'],
            intervalMin: r['interval_min'], method: r['method'],
            expectedStatus: r['expected_status'],
            keyword: r['keyword'],
            timeoutMs: r['timeout_ms'], alertThreshold: r['alert_threshold'],
            channel: r['channel'], chatId: r['chat_id'],
            userId: r['user_id'], status: r['status'],
            lastCheck: r['last_check'] ? new Date(r['last_check']) : undefined,
            lastStatus: r['last_status'],
            consecutiveFailures: r['consecutive_failures'],
            createdAt: new Date(r['created_at']),
        }));
    }
    async updatePatrolResult(id, ok, status, consecutiveFailures) {
        await this.pool.query(`UPDATE patrol_checks SET last_check=$1, last_status=$2, consecutive_failures=$3 WHERE id=$4`, [Date.now(), status, consecutiveFailures, id]);
    }
    async updatePatrolStatus(id, status) {
        await this.pool.query(`UPDATE patrol_checks SET status=$1 WHERE id=$2`, [status, id]);
    }
    async deletePatrolCheck(id) {
        await this.pool.query(`DELETE FROM patrol_results WHERE check_id=$1`, [id]);
        const res = await this.pool.query(`DELETE FROM patrol_checks WHERE id=$1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    async savePatrolResult(result) {
        await this.pool.query(`INSERT INTO patrol_results (id, check_id, ok, status_code, latency_ms, error, checked_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`, [nanoid(), result.checkId, result.ok, result.statusCode ?? null, result.latencyMs, result.error ?? null, Date.now()]);
    }
    async getPatrolHistory(checkId, limit = 20) {
        const res = await this.pool.query(`SELECT * FROM patrol_results WHERE check_id=$1 ORDER BY checked_at DESC LIMIT $2`, [checkId, limit]);
        return res.rows.map((r) => ({
            id: r['id'], checkId: r['check_id'],
            ok: r['ok'],
            statusCode: r['status_code'],
            latencyMs: r['latency_ms'],
            error: r['error'],
            checkedAt: new Date(r['checked_at']),
        }));
    }
    // ── Workflows ──────────────────────────────────────────────────────────────
    async saveWorkflow(wf) {
        const id = nanoid();
        await this.pool.query(`INSERT INTO workflows (id, name, description, trigger, steps, channel, chat_id, user_id, status, run_count, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'active',0,$9)`, [id, wf.name, wf.description ?? null, wf.trigger, JSON.stringify(wf.steps), wf.channel, wf.chatId, wf.userId, Date.now()]);
        return id;
    }
    async getWorkflows(userId) {
        const res = await this.pool.query(userId ? `SELECT * FROM workflows WHERE user_id=$1` : `SELECT * FROM workflows`, userId ? [userId] : []);
        return res.rows.map((r) => ({
            id: r['id'], name: r['name'],
            description: r['description'],
            trigger: r['trigger'],
            steps: JSON.parse(r['steps']),
            channel: r['channel'], chatId: r['chat_id'],
            userId: r['user_id'], status: r['status'],
            lastRun: r['last_run'] ? new Date(r['last_run']) : undefined,
            runCount: r['run_count'], createdAt: new Date(r['created_at']),
        }));
    }
    async updateWorkflowRun(id) {
        await this.pool.query(`UPDATE workflows SET last_run=$1, run_count=run_count+1 WHERE id=$2`, [Date.now(), id]);
    }
    async updateWorkflowStatus(id, status) {
        await this.pool.query(`UPDATE workflows SET status=$1 WHERE id=$2`, [status, id]);
    }
    async deleteWorkflow(id) {
        const res = await this.pool.query(`DELETE FROM workflows WHERE id=$1`, [id]);
        return (res.rowCount ?? 0) > 0;
    }
    // ── Reminders ──────────────────────────────────────────────────────────────
    async getDueReminders() {
        const now = Date.now();
        const res = await this.pool.query(`SELECT user_id, channel, key, value FROM memory
       WHERE key LIKE 'reminder:%' AND (expires_at IS NULL OR expires_at > $1)`, [now]);
        return res.rows.filter((r) => {
            try {
                const rem = JSON.parse(r.value);
                if (rem.done)
                    return false;
                if (!rem.dueAt)
                    return false;
                const due = new Date(rem.dueAt).getTime();
                return !isNaN(due) && due <= now;
            }
            catch {
                return false;
            }
        }).map((r) => ({ userId: r.user_id, channel: r.channel, key: r.key, value: r.value }));
    }
    async markReminderDone(userId, channel, key) {
        const res = await this.pool.query(`SELECT value FROM memory WHERE user_id=$1 AND channel=$2 AND key=$3`, [userId, channel, key]);
        if (!res.rows[0])
            return;
        try {
            const rem = JSON.parse(res.rows[0].value);
            rem.done = true;
            await this.pool.query(`UPDATE memory SET value=$1, updated_at=$2 WHERE user_id=$3 AND channel=$4 AND key=$5`, [JSON.stringify(rem), Date.now(), userId, channel, key]);
        }
        catch { /* ignore */ }
    }
    // ── Rate Limiting ──────────────────────────────────────────────────────────
    async checkRateLimit(key, limit, windowMs) {
        const now = Date.now();
        const res = await this.pool.query(`SELECT count, reset_at FROM rate_limits WHERE key=$1`, [key]);
        const row = res.rows[0];
        if (!row || now > row.reset_at) {
            await this.pool.query(`INSERT INTO rate_limits (key, count, reset_at) VALUES ($1,1,$2)
         ON CONFLICT (key) DO UPDATE SET count=1, reset_at=EXCLUDED.reset_at`, [key, now + windowMs]);
            return true;
        }
        if (row.count >= limit)
            return false;
        await this.pool.query(`UPDATE rate_limits SET count=count+1 WHERE key=$1`, [key]);
        return true;
    }
    async cleanupRateLimits() {
        await this.pool.query(`DELETE FROM rate_limits WHERE reset_at < $1`, [Date.now()]);
    }
    // ── Error Tracking ─────────────────────────────────────────────────────────
    async trackError(opts) {
        await this.pool.query(`INSERT INTO error_events (id, level, message, context, stack, user_id, channel, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, [nanoid(), opts.level ?? 'error', opts.message,
            opts.context ? JSON.stringify(opts.context) : null,
            opts.stack ?? null, opts.userId ?? null, opts.channel ?? null, Date.now()]);
    }
    async getRecentErrors(limit = 50) {
        const res = await this.pool.query(`SELECT id, level, message, context, user_id, channel, created_at
       FROM error_events ORDER BY created_at DESC LIMIT $1`, [limit]);
        return res.rows.map((r) => ({
            id: r['id'], level: r['level'], message: r['message'],
            context: r['context'] ? JSON.parse(r['context']) : null,
            userId: r['user_id'], channel: r['channel'],
            createdAt: new Date(r['created_at']),
        }));
    }
    // ── Audit Log ──────────────────────────────────────────────────────────────
    async logAudit(entry) {
        const SENSITIVE = new Set(['apiKey', 'token', 'secret', 'password', 'key']);
        let params = entry.params;
        if (params) {
            params = Object.fromEntries(Object.entries(params).map(([k, v]) => SENSITIVE.has(k) ? [k, '[REDACTED]'] : [k, v]));
        }
        await this.pool.query(`INSERT INTO audit_log (id, timestamp, user_id, channel, chat_id, skill_name, params, success, duration_ms, error, role)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`, [nanoid(), Date.now(), entry.userId, entry.channel, entry.chatId ?? null,
            entry.skillName, params ? JSON.stringify(params) : null,
            entry.success, entry.durationMs, entry.error ?? null, entry.role ?? null]);
        await this.pool.query(`INSERT INTO skill_stats (skill_name, call_count, success_count, total_duration_ms, last_called_at)
       VALUES ($1,1,$2,$3,$4)
       ON CONFLICT (skill_name) DO UPDATE SET
         call_count = skill_stats.call_count + 1,
         success_count = skill_stats.success_count + EXCLUDED.success_count,
         total_duration_ms = skill_stats.total_duration_ms + EXCLUDED.total_duration_ms,
         last_called_at = EXCLUDED.last_called_at`, [entry.skillName, entry.success ? 1 : 0, entry.durationMs, Date.now()]);
    }
    async queryAuditLog(opts) {
        const conditions = [];
        const args = [];
        let idx = 1;
        if (opts.userId) {
            conditions.push(`user_id=$${idx++}`);
            args.push(opts.userId);
        }
        if (opts.skillName) {
            conditions.push(`skill_name=$${idx++}`);
            args.push(opts.skillName);
        }
        if (opts.channel) {
            conditions.push(`channel=$${idx++}`);
            args.push(opts.channel);
        }
        if (opts.success !== undefined) {
            conditions.push(`success=$${idx++}`);
            args.push(opts.success);
        }
        if (opts.sinceMs) {
            conditions.push(`timestamp>=$${idx++}`);
            args.push(Date.now() - opts.sinceMs);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        args.push(opts.limit ?? 100);
        const res = await this.pool.query(`SELECT * FROM audit_log ${where} ORDER BY timestamp DESC LIMIT $${idx}`, args);
        return res.rows.map((r) => ({
            id: r['id'], timestamp: new Date(r['timestamp']),
            userId: r['user_id'], channel: r['channel'],
            chatId: r['chat_id'], skillName: r['skill_name'],
            params: r['params'] ? JSON.parse(r['params']) : null,
            success: r['success'],
            durationMs: r['duration_ms'], error: r['error'],
            role: r['role'],
        }));
    }
    // ── Skill Stats ────────────────────────────────────────────────────────────
    async getSkillStats() {
        const res = await this.pool.query(`SELECT skill_name, call_count, success_count, total_duration_ms, last_called_at
       FROM skill_stats ORDER BY call_count DESC`);
        return res.rows.map((r) => ({
            skillName: r['skill_name'],
            callCount: r['call_count'],
            successCount: r['success_count'],
            successRate: r['call_count'] > 0
                ? Math.round((r['success_count'] / r['call_count']) * 100) : 0,
            avgDurationMs: r['call_count'] > 0
                ? Math.round(r['total_duration_ms'] / r['call_count']) : 0,
            lastCalledAt: r['last_called_at'] ? new Date(r['last_called_at']) : null,
        }));
    }
    // ── Memory History & Rollback ──────────────────────────────────────────────
    async recordMemoryChange(userId, channel, key, oldValue, newValue, source) {
        await this.recordScopedMemoryChange({ userId, channel: channel }, key, oldValue, newValue, source);
    }
    async recordScopedMemoryChange(scope, key, oldValue, newValue, source) {
        const normalized = normalizeScope(scope);
        await this.pool.query(`INSERT INTO memory_history (id, user_id, channel, workspace_id, agent_id, key, old_value, new_value, source, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`, [
            nanoid(),
            normalized.userId,
            normalized.channel,
            normalized.workspaceId,
            normalized.agentId,
            key,
            oldValue ?? null,
            newValue,
            source,
            new Date().toISOString(),
        ]);
    }
    async getMemoryHistory(userId, channel, limit = 50) {
        return this.getScopedMemoryHistory({ userId, channel: channel }, limit);
    }
    async getScopedMemoryHistory(scope, limit = 50) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT * FROM memory_history WHERE user_id=$1 AND channel=$2
         AND COALESCE(workspace_id, '')=$3
         AND COALESCE(agent_id, '')=$4
       ORDER BY created_at DESC LIMIT $5`, [normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit]);
        return res.rows;
    }
    async rollbackMemory(userId, channel, historyId) {
        return this.rollbackScopedMemory({ userId, channel }, historyId);
    }
    async rollbackScopedMemory(scope, historyId) {
        const normalized = normalizeScope(scope);
        const res = await this.pool.query(`SELECT * FROM memory_history WHERE id=$1 AND user_id=$2 AND channel=$3
         AND COALESCE(workspace_id, '')=$4
         AND COALESCE(agent_id, '')=$5`, [historyId, normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId]);
        const entry = res.rows[0];
        if (!entry)
            return false;
        const hasScopedNamespace = Boolean(scope.workspaceId || scope.agentId);
        if (entry.old_value === null || entry.old_value === undefined) {
            if (hasScopedNamespace)
                await this.deleteScopedMemory(scope, entry.key);
            else
                await this.deleteMemory(scope.userId, scope.channel, entry.key);
        }
        else {
            if (hasScopedNamespace)
                await this.setScopedMemory(scope, entry.key, entry.old_value);
            else
                await this.setMemory(scope.userId, scope.channel, entry.key, entry.old_value);
        }
        await this.recordScopedMemoryChange(scope, entry.key, entry.new_value, entry.old_value ?? '', 'manual');
        return true;
    }
    // ── Conversation Search & Export ───────────────────────────────────────────
    async searchConversations(userId, channel, query, limit = 20) {
        const pattern = `%${query.replace(/[%_]/g, '\\$&')}%`;
        const res = await this.pool.query(`SELECT c.session_id, c.role, c.content, c.created_at
       FROM conversations c
       JOIN sessions s ON s.id = c.session_id
       WHERE s.user_id=$1 AND s.channel=$2
         AND c.role IN ('user','assistant')
         AND c.content ILIKE $3
       ORDER BY c.created_at DESC LIMIT $4`, [userId, channel, pattern, limit]);
        return res.rows.map((r) => ({
            sessionId: r['session_id'], role: r['role'], content: r['content'],
            createdAt: new Date(r['created_at']),
        }));
    }
    async exportConversation(sessionId, format) {
        const res = await this.pool.query(`SELECT role, content, created_at FROM conversations
       WHERE session_id=$1 AND role IN ('user','assistant')
       ORDER BY created_at ASC`, [sessionId]);
        if (format === 'json') {
            return JSON.stringify(res.rows.map((r) => ({ role: r.role, content: r.content, timestamp: new Date(r.created_at).toISOString() })), null, 2);
        }
        const lines = [`# Conversation Export\n\nSession: \`${sessionId}\`\n`];
        for (const r of res.rows) {
            const ts = new Date(r.created_at).toLocaleString();
            const label = r.role === 'user' ? '**You**' : '**GreenFrog**';
            lines.push(`### ${label} — ${ts}\n\n${r.content}\n`);
        }
        return lines.join('\n---\n\n');
    }
    // ── Maintenance ────────────────────────────────────────────────────────────
    async listUsers() {
        const result = await this.pool.query(`
      SELECT s.user_id AS "userId",
             COUNT(DISTINCT s.id) AS "sessionCount",
             COUNT(c.id) AS "conversationCount",
             MAX(c.created_at) AS "lastActive"
      FROM sessions s
      LEFT JOIN conversations c ON c.session_id = s.id
      GROUP BY s.user_id
      ORDER BY "lastActive" DESC NULLS LAST
    `);
        return result.rows.map((r) => ({
            userId: r.userId,
            sessionCount: parseInt(r.sessionCount, 10),
            conversationCount: parseInt(r.conversationCount, 10),
            lastActive: r.lastActive ? new Date(r.lastActive) : null,
        }));
    }
    async deleteUserData(userId) {
        await this.pool.query(`
      DELETE FROM conversations WHERE session_id IN (SELECT id FROM sessions WHERE user_id = $1)
    `, [userId]);
        await this.pool.query(`DELETE FROM sessions WHERE user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM memory WHERE user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM scoped_memory WHERE user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM entities WHERE user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM team_tasks WHERE created_by = $1`, [userId]);
        await this.pool.query(`DELETE FROM team_notifications WHERE recipient_user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM team_notification_routes WHERE recipient_user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM auth_revocations WHERE user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM agent_bindings WHERE user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM agent_registry WHERE owner_user_id = $1`, [userId]);
        await this.pool.query(`DELETE FROM rate_limits WHERE key LIKE $1`, [`%:${userId}`]);
        await this.pool.query(`UPDATE audit_log SET user_id = '[DELETED]' WHERE user_id = $1`, [userId]);
        log.info({ userId }, 'User data deleted (GDPR)');
    }
    async getAuthRevokedAfter(userId) {
        const result = await this.pool.query(`SELECT revoked_after AS "revokedAfter" FROM auth_revocations WHERE user_id = $1`, [userId]);
        if (result.rowCount === 0)
            return null;
        return parseInt(result.rows[0].revokedAfter, 10);
    }
    async revokeAuthSessions(userId, opts) {
        const revokedAfter = Math.floor(opts?.revokedAfter ?? Date.now() / 1000);
        const now = Date.now();
        await this.pool.query(`INSERT INTO auth_revocations (user_id, revoked_after, revoked_by, reason, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (user_id) DO UPDATE SET
         revoked_after = EXCLUDED.revoked_after,
         revoked_by = EXCLUDED.revoked_by,
         reason = EXCLUDED.reason,
         updated_at = EXCLUDED.updated_at`, [userId, revokedAfter, opts?.revokedBy ?? null, opts?.reason ?? null, now, now]);
    }
    async cleanup() {
        const now = Date.now();
        await this.pool.query(`DELETE FROM conversations WHERE created_at < $1`, [now - 90 * 24 * 3600 * 1000]);
        await this.pool.query(`DELETE FROM scoped_memory WHERE expires_at IS NOT NULL AND expires_at <= $1`, [now]);
        await this.pool.query(`DELETE FROM error_events WHERE created_at < $1`, [now - 30 * 24 * 3600 * 1000]);
        await this.pool.query(`DELETE FROM patrol_results WHERE checked_at < $1`, [now - 30 * 24 * 3600 * 1000]);
        await this.pool.query(`DELETE FROM audit_log WHERE timestamp < $1`, [now - 90 * 24 * 3600 * 1000]);
        await this.cleanupRateLimits();
        log.debug('PostgreSQL cleanup complete');
    }
    // ── Token Usage ────────────────────────────────────────────────────────────
    async recordTokenUsage(record) {
        const total = record.inputTokens + record.outputTokens;
        await this.pool.query(`
      INSERT INTO token_usage
        (id, user_id, workspace_id, agent_id, provider, model,
         input_tokens, output_tokens, total_tokens, cost_usd,
         channel, session_key, recorded_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
    `, [
            nanoid(), record.userId, record.workspaceId ?? null, record.agentId ?? null,
            record.provider, record.model,
            record.inputTokens, record.outputTokens, total, record.costUsd ?? null,
            record.channel ?? null, record.sessionKey ?? null, Date.now(),
        ]);
    }
    async getTokenUsageSummary(filter) {
        const period = filter.period ?? new Date().toISOString().slice(0, 7);
        const startMs = new Date(`${period}-01T00:00:00Z`).getTime();
        const endMs = new Date(new Date(`${period}-01T00:00:00Z`).setMonth(new Date(`${period}-01T00:00:00Z`).getMonth() + 1)).getTime();
        let result;
        if (filter.userId) {
            result = await this.pool.query(`
        SELECT 'user' AS scope_type, user_id AS scope_id,
               SUM(input_tokens)::BIGINT AS total_input, SUM(output_tokens)::BIGINT AS total_output,
               SUM(total_tokens)::BIGINT AS total_tokens, SUM(cost_usd) AS total_cost,
               COUNT(*)::BIGINT AS call_count
        FROM token_usage
        WHERE user_id = $1 AND recorded_at >= $2 AND recorded_at < $3
        GROUP BY user_id
      `, [filter.userId, startMs, endMs]);
        }
        else if (filter.workspaceId) {
            result = await this.pool.query(`
        SELECT 'workspace' AS scope_type, workspace_id AS scope_id,
               SUM(input_tokens)::BIGINT AS total_input, SUM(output_tokens)::BIGINT AS total_output,
               SUM(total_tokens)::BIGINT AS total_tokens, SUM(cost_usd) AS total_cost,
               COUNT(*)::BIGINT AS call_count
        FROM token_usage
        WHERE workspace_id = $1 AND recorded_at >= $2 AND recorded_at < $3
        GROUP BY workspace_id
      `, [filter.workspaceId, startMs, endMs]);
        }
        else {
            result = await this.pool.query(`
        SELECT 'global' AS scope_type, 'global' AS scope_id,
               SUM(input_tokens)::BIGINT AS total_input, SUM(output_tokens)::BIGINT AS total_output,
               SUM(total_tokens)::BIGINT AS total_tokens, SUM(cost_usd) AS total_cost,
               COUNT(*)::BIGINT AS call_count
        FROM token_usage
        WHERE recorded_at >= $1 AND recorded_at < $2
      `, [startMs, endMs]);
        }
        return result.rows.map((r) => ({
            scopeType: r['scope_type'],
            scopeId: r['scope_id'],
            period,
            totalInputTokens: Number(r['total_input'] ?? 0),
            totalOutputTokens: Number(r['total_output'] ?? 0),
            totalTokens: Number(r['total_tokens'] ?? 0),
            totalCostUsd: r['total_cost'] != null ? Number(r['total_cost']) : null,
            callCount: Number(r['call_count'] ?? 0),
        }));
    }
    async getTokenUsageDetail(filter) {
        const limit = Math.min(filter.limit ?? 50, 200);
        const offset = filter.offset ?? 0;
        let result;
        if (filter.userId) {
            result = await this.pool.query(`SELECT * FROM token_usage WHERE user_id = $1 ORDER BY recorded_at DESC LIMIT $2 OFFSET $3`, [filter.userId, limit, offset]);
        }
        else if (filter.workspaceId) {
            result = await this.pool.query(`SELECT * FROM token_usage WHERE workspace_id = $1 ORDER BY recorded_at DESC LIMIT $2 OFFSET $3`, [filter.workspaceId, limit, offset]);
        }
        else {
            result = await this.pool.query(`SELECT * FROM token_usage ORDER BY recorded_at DESC LIMIT $1 OFFSET $2`, [limit, offset]);
        }
        return result.rows.map((r) => ({
            id: r['id'],
            userId: r['user_id'],
            workspaceId: r['workspace_id'] ?? null,
            agentId: r['agent_id'] ?? null,
            provider: r['provider'],
            model: r['model'],
            inputTokens: Number(r['input_tokens']),
            outputTokens: Number(r['output_tokens']),
            totalTokens: Number(r['total_tokens']),
            costUsd: r['cost_usd'] != null ? Number(r['cost_usd']) : null,
            channel: r['channel'] ?? null,
            sessionKey: r['session_key'] ?? null,
            recordedAt: new Date(Number(r['recorded_at'])),
        }));
    }
    // ── User Quotas ────────────────────────────────────────────────────────────
    async setUserQuota(quota) {
        await this.pool.query(`
      INSERT INTO user_quotas (scope_type, scope_id, monthly_token_limit, monthly_cost_limit_usd, limit_behavior, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6)
      ON CONFLICT (scope_type, scope_id) DO UPDATE SET
        monthly_token_limit = EXCLUDED.monthly_token_limit,
        monthly_cost_limit_usd = EXCLUDED.monthly_cost_limit_usd,
        limit_behavior = EXCLUDED.limit_behavior,
        updated_at = EXCLUDED.updated_at
    `, [
            quota.scopeType, quota.scopeId,
            quota.monthlyTokenLimit ?? null,
            quota.monthlyCostLimitUsd ?? null,
            quota.limitBehavior ?? 'soft',
            Date.now(),
        ]);
    }
    async getUserQuota(scopeType, scopeId) {
        const result = await this.pool.query(`SELECT * FROM user_quotas WHERE scope_type = $1 AND scope_id = $2`, [scopeType, scopeId]);
        if (result.rowCount === 0)
            return null;
        const r = result.rows[0];
        return {
            scopeType: r['scope_type'],
            scopeId: r['scope_id'],
            monthlyTokenLimit: r['monthly_token_limit'] != null ? Number(r['monthly_token_limit']) : null,
            monthlyCostLimitUsd: r['monthly_cost_limit_usd'] != null ? Number(r['monthly_cost_limit_usd']) : null,
            limitBehavior: r['limit_behavior'] ?? 'soft',
            updatedAt: new Date(Number(r['updated_at'])),
        };
    }
    async listUserQuotas() {
        const result = await this.pool.query(`SELECT * FROM user_quotas ORDER BY scope_type, scope_id`);
        return result.rows.map((r) => ({
            scopeType: r['scope_type'],
            scopeId: r['scope_id'],
            monthlyTokenLimit: r['monthly_token_limit'] != null ? Number(r['monthly_token_limit']) : null,
            monthlyCostLimitUsd: r['monthly_cost_limit_usd'] != null ? Number(r['monthly_cost_limit_usd']) : null,
            limitBehavior: r['limit_behavior'] ?? 'soft',
            updatedAt: new Date(Number(r['updated_at'])),
        }));
    }
    // ── Workspace Membership ───────────────────────────────────────────────────
    async addWorkspaceMember(workspaceId, userId, role) {
        await this.pool.query(`
      INSERT INTO workspace_members (workspace_id, user_id, role, joined_at)
      VALUES ($1,$2,$3,$4)
      ON CONFLICT (workspace_id, user_id) DO UPDATE SET role = EXCLUDED.role
    `, [workspaceId, userId, role, Date.now()]);
    }
    async removeWorkspaceMember(workspaceId, userId) {
        await this.pool.query(`DELETE FROM workspace_members WHERE workspace_id = $1 AND user_id = $2`, [workspaceId, userId]);
    }
    async getWorkspaceMembership(workspaceId, userId) {
        const result = await this.pool.query(`SELECT role FROM workspace_members WHERE workspace_id = $1 AND user_id = $2`, [workspaceId, userId]);
        if (result.rowCount === 0)
            return null;
        return { role: result.rows[0].role };
    }
    async listWorkspaceMembers(workspaceId) {
        const result = await this.pool.query(`SELECT user_id, role, joined_at FROM workspace_members WHERE workspace_id = $1 ORDER BY joined_at`, [workspaceId]);
        return result.rows.map((r) => ({
            userId: r['user_id'],
            role: r['role'],
            joinedAt: new Date(Number(r['joined_at'])),
        }));
    }
    async listUserWorkspaces(userId) {
        const result = await this.pool.query(`SELECT workspace_id, role, joined_at FROM workspace_members WHERE user_id = $1 ORDER BY joined_at`, [userId]);
        return result.rows.map((r) => ({
            workspaceId: r['workspace_id'],
            role: r['role'],
            joinedAt: new Date(Number(r['joined_at'])),
        }));
    }
    // Not implemented for Postgres (SQLite-only feature used in single-user mode)
    async getLastJobRunTime() { return null; }
    async getLastWorkflowRunTime() { return null; }
    // Rule tracking persistence — not implemented for Postgres (single-user SQLite only)
    async upsertRuleTrackingStat(_workspaceId, _channel, _ruleId, _success) { }
    async getPersistedRuleStats(_workspaceId, _channel, _ruleId) { return null; }
    async getAllPersistedRuleStats(_workspaceId, _channel) { return new Map(); }
}
//# sourceMappingURL=postgres.js.map