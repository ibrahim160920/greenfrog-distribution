import { DWClient, TOPIC_ROBOT, EventAck } from 'dingtalk-stream';
import axios from 'axios';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { ChannelError } from '../../utils/errors.js';
import { config } from '../../config/index.js';
export class DingTalkChannel extends BaseChannel {
    name = 'dingtalk';
    dwClient = null;
    _running = false;
    _reconnectTimer = null;
    _reconnectAttempts = 0;
    static MAX_RECONNECT_DELAY_MS = 60_000;
    // Cache sessionWebhook per chatId (valid for ~2 hours per DingTalk docs)
    webhookCache = new Map();
    async start() {
        const cfg = config.channels.dingtalk;
        if (!cfg?.enabled || !cfg.clientId || !cfg.clientSecret) {
            this.log.info('DingTalk not configured, skipping');
            return;
        }
        await this.connect(cfg.clientId, cfg.clientSecret);
    }
    async connect(clientId, clientSecret) {
        const allowedUsers = config.channels.dingtalk?.allowedUsers ?? [];
        this.dwClient = new DWClient({ clientId, clientSecret });
        this.dwClient.registerAllEventListener((downstream) => {
            if (downstream.headers.topic !== TOPIC_ROBOT) {
                return { status: EventAck.SUCCESS };
            }
            this.handleRobotMessage(downstream, allowedUsers).catch((err) => {
                this.log.error({ err }, 'DingTalk: error handling message');
            });
            return { status: EventAck.SUCCESS };
        });
        this.dwClient.on('disconnect', () => {
            this.log.info('DingTalk disconnected');
            this._running = false;
            this.scheduleReconnect(clientId, clientSecret);
        });
        this.dwClient.on('error', (err) => {
            this.log.error({ err }, 'DingTalk connection error');
        });
        await this.dwClient.connect();
        this._running = true;
        this._reconnectAttempts = 0;
        this.log.info('DingTalk channel started');
    }
    async handleRobotMessage(downstream, allowedUsers) {
        let robotMsg;
        try {
            robotMsg = JSON.parse(downstream.data);
        }
        catch {
            this.log.warn({ data: downstream.data }, 'DingTalk: failed to parse robot message');
            return;
        }
        if (robotMsg.msgtype !== 'text')
            return;
        const userId = robotMsg.senderId;
        const chatId = robotMsg.conversationId;
        if (allowedUsers.length > 0 && !allowedUsers.includes(userId)) {
            this.log.debug({ userId }, 'DingTalk: user not in allowedUsers, ignoring');
            return;
        }
        // Cache sessionWebhook (expires 2 hours from creation)
        this.webhookCache.set(chatId, {
            url: robotMsg.sessionWebhook,
            expiresAt: Date.now() + 2 * 3600 * 1000,
        });
        const text = robotMsg.text.content.trim();
        if (!text)
            return;
        const msg = {
            id: robotMsg.msgId ?? nanoid(),
            channel: 'dingtalk',
            userId,
            username: robotMsg.senderNick,
            chatId,
            text,
            timestamp: new Date(robotMsg.createAt),
            raw: robotMsg,
        };
        await this.handleMessage(msg);
    }
    scheduleReconnect(clientId, clientSecret) {
        if (this._reconnectTimer)
            return;
        const delay = Math.min(1000 * Math.pow(2, this._reconnectAttempts), DingTalkChannel.MAX_RECONNECT_DELAY_MS);
        this._reconnectAttempts++;
        this.log.info({ delay, attempt: this._reconnectAttempts }, 'Scheduling DingTalk reconnect');
        this._reconnectTimer = setTimeout(async () => {
            this._reconnectTimer = null;
            try {
                await this.connect(clientId, clientSecret);
            }
            catch (err) {
                this.log.error({ err }, 'DingTalk reconnect failed');
                this.scheduleReconnect(clientId, clientSecret);
            }
        }, delay);
    }
    async stop() {
        if (this._reconnectTimer) {
            clearTimeout(this._reconnectTimer);
            this._reconnectTimer = null;
        }
        try {
            this.dwClient?.disconnect();
        }
        catch { /* ignore */ }
        this._running = false;
        this.log.info('DingTalk channel stopped');
    }
    async send(message) {
        if (!message.chatId)
            return;
        const cached = this.webhookCache.get(message.chatId);
        if (!cached || Date.now() > cached.expiresAt) {
            this.log.warn({ chatId: message.chatId }, 'DingTalk: no valid sessionWebhook for chatId — message dropped');
            return;
        }
        const chunks = this.splitMessage(message.text ?? '', 2000);
        for (const chunk of chunks) {
            try {
                await axios.post(cached.url, {
                    msgtype: 'text',
                    text: { content: chunk },
                });
            }
            catch (err) {
                throw new ChannelError(`DingTalk send error: ${String(err)}`, 'dingtalk');
            }
        }
    }
    isRunning() {
        return this._running;
    }
    splitMessage(text, maxLen) {
        if (text.length <= maxLen)
            return [text];
        const chunks = [];
        let remaining = text;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, maxLen);
            const lastNewline = chunk.lastIndexOf('\n');
            if (lastNewline > maxLen / 2)
                chunk = remaining.slice(0, lastNewline);
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }
        return chunks;
    }
}
//# sourceMappingURL=index.js.map