/**
 * registry.ts — Enrolled child instance store.
 *
 * Stores enrolled instances in memory (Map) with file-backed JSON persistence.
 * Persisted at <baseDir>/distribution/instances.json (default: .greenfrog/).
 */
export interface EnrolledInstance {
    instanceId: string;
    enrollmentKey: string;
    platform: string;
    arch: string;
    nodeVersion: string;
    appVersion: string;
    enrolledAt: string;
    lastSeenAt: string;
    revoked: boolean;
}
/** Register a new instance or return the existing record if already enrolled. */
export declare function registerInstance(data: Omit<EnrolledInstance, 'enrolledAt' | 'lastSeenAt' | 'revoked'>, baseDir?: string): EnrolledInstance;
/** Look up an enrolled instance by enrollmentKey. Returns null if not found or revoked. */
export declare function lookupInstance(enrollmentKey: string, baseDir?: string): EnrolledInstance | null;
/** Look up an enrolled instance by instanceId. Returns null if not found or revoked. */
export declare function lookupByInstanceId(instanceId: string, baseDir?: string): EnrolledInstance | null;
/** Mark an enrollment key as revoked. */
export declare function revokeInstance(enrollmentKey: string, baseDir?: string): boolean;
/** Revoke an instance by instanceId (used when authenticating via JWT). */
export declare function revokeByInstanceId(instanceId: string, baseDir?: string): boolean;
/** Update lastSeenAt for a key (called on each authenticated request). */
export declare function touchInstance(enrollmentKey: string, baseDir?: string): void;
/** Update lastSeenAt by instanceId. */
export declare function touchByInstanceId(instanceId: string, baseDir?: string): void;
/** Reset in-memory cache (used in tests). */
export declare function resetRegistry(): void;
//# sourceMappingURL=registry.d.ts.map