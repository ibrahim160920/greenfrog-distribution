/**
 * manifest.ts — Release manifest types and schema validation.
 *
 * The release manifest is a signed JSON document that describes an inheritance
 * bundle available for download. The child fetches the manifest, verifies its
 * signature, and only then downloads and applies the bundle.
 */
/** Schema version — increment when breaking changes are made. */
export declare const MANIFEST_VERSION = 1;
/** A signed release manifest from the mother-body distribution server. */
export interface ReleaseManifest {
    manifestVersion: 1;
    releaseId: string;
    version: string;
    releasedAt: string;
    compatibilityConstraint: string;
    bundleType: 'mother_promoted';
    bundleHash: string;
    bundleSize: number;
    downloadUrl: string;
    signature: string;
}
/** Minimal description returned by the "latest manifest" endpoint. */
export interface LatestManifestResponse {
    ok: boolean;
    manifest?: ReleaseManifest;
    noUpdate?: boolean;
    error?: string;
}
/** Validate that a parsed object conforms to ReleaseManifest shape. */
export declare function validateManifest(obj: unknown): obj is ReleaseManifest;
/**
 * Compute the canonical manifest digest for signing/verification.
 * Digest = SHA-256(JSON of manifest without the signature field).
 */
export declare function computeManifestDigest(manifest: ReleaseManifest): Buffer;
/**
 * Compute SHA-256 hash of bundle content.
 * Used to verify download integrity.
 */
export declare function computeBundleHash(content: Buffer): string;
//# sourceMappingURL=manifest.d.ts.map