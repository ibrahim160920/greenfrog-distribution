/**
 * runtime_gate.ts — Enrollment gate for child instances.
 *
 * If process.env.GF_IS_CHILD_INSTANCE === 'true', the runtime gate
 * must be checked on startup. Any state other than 'enrolled' blocks
 * normal operation.
 *
 * Three entry points:
 *   assertEnrolled(baseDir?)          — throws EnrollmentRequiredError if not enrolled
 *   createEnrollmentGateMiddleware()  — Express middleware returning 503 if not enrolled
 *   checkEnrollmentOrExit(baseDir?)   — logs i18n message + process.exit(1) if not enrolled
 */
import type { Request, Response, NextFunction } from 'express';
export declare class EnrollmentRequiredError extends Error {
    readonly state: string;
    constructor(state: string);
}
/**
 * Throw EnrollmentRequiredError if the instance is not in 'enrolled' state.
 * Safe to call repeatedly — no side effects.
 */
export declare function assertEnrolled(baseDir?: string): void;
/**
 * Returns an Express RequestHandler that responds 503 with an enrollment
 * error JSON body if the instance is not enrolled.
 *
 * Usage:
 *   app.use('/api', createEnrollmentGateMiddleware());
 */
export declare function createEnrollmentGateMiddleware(baseDir?: string): (_req: Request, res: Response, next: NextFunction) => void;
/**
 * Check enrollment state and exit the process if not enrolled.
 * Called during startup when GF_IS_CHILD_INSTANCE === 'true'.
 *
 * Logs a clear message before exiting so the user knows how to proceed.
 */
export declare function checkEnrollmentOrExit(baseDir?: string): void;
//# sourceMappingURL=runtime_gate.d.ts.map