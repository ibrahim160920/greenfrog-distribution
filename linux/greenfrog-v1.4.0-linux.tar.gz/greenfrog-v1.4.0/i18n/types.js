/**
 * i18n types for GreenFrog child distribution system.
 * Shared by installer, first-boot, and runtime.
 */
export const SUPPORTED_LOCALES = [
    { code: 'en', name: 'English', nativeName: 'English', dir: 'ltr' },
    { code: 'zh-CN', name: '简体中文', nativeName: '简体中文', dir: 'ltr' },
    { code: 'zh-TW', name: '繁體中文', nativeName: '繁體中文', dir: 'ltr' },
    { code: 'ja', name: '日本語', nativeName: '日本語', dir: 'ltr' },
    { code: 'ko', name: '한국어', nativeName: '한국어', dir: 'ltr' },
    { code: 'de', name: 'Deutsch', nativeName: 'Deutsch', dir: 'ltr' },
    { code: 'it', name: 'Italiano', nativeName: 'Italiano', dir: 'ltr' },
    { code: 'fr', name: 'Français', nativeName: 'Français', dir: 'ltr' },
    { code: 'es', name: 'Español', nativeName: 'Español', dir: 'ltr' },
    { code: 'pt', name: 'Português', nativeName: 'Português', dir: 'ltr' },
];
export const DEFAULT_LOCALE = 'en';
//# sourceMappingURL=types.js.map