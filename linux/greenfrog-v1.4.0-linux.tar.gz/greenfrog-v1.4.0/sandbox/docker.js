/**
 * DockerSandbox — container-level isolation for code execution.
 *
 * Security model per container:
 *   --network none        : no outbound network
 *   --read-only           : immutable root filesystem
 *   --tmpfs /tmp          : writable scratchpad, cleared on exit
 *   --memory 128m         : hard memory ceiling
 *   --cpus 0.5            : limit to half a CPU core
 *   --pids-limit 64       : blocks fork bombs
 *   --cap-drop ALL        : drop all Linux capabilities
 *   --security-opt no-new-privileges : prevents setuid escalation
 *   --user sandbox        : non-root uid 1001
 *
 * When Docker is unavailable the callers fall back to their existing
 * spawnSync / Worker-thread paths automatically.
 */
import Dockerode from 'dockerode';
import { writeFileSync, mkdirSync, rmSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { tmpdir } from 'os';
import { nanoid } from 'nanoid';
import { createLogger } from '../utils/logger.js';
import { config } from '../config/index.js';
const log = createLogger('sandbox:docker');
const __dirname = dirname(fileURLToPath(import.meta.url));
export const SANDBOX_IMAGE = 'greenfrog-sandbox:latest';
// Max concurrent containers — identical policy to Worker threads
const MAX_CONCURRENT = 3;
let active = 0;
export class DockerSandbox {
    docker;
    _available = null;
    _healthTimer = null;
    constructor() {
        this.docker = new Dockerode();
    }
    /**
     * Ping the Docker daemon and cache the result.
     * The first call performs a blocking ping; subsequent calls return the cached
     * value which is refreshed every 30 s by the background health monitor.
     */
    async isAvailable() {
        if (this._available !== null)
            return this._available;
        // Respect explicit opt-out in config
        if (config.sandbox?.enabled === false) {
            this._available = false;
            return false;
        }
        await this._probe();
        return this._available;
    }
    /** Internal probe — updates _available and logs state transitions. */
    async _probe() {
        const was = this._available;
        try {
            await this.docker.ping();
            if (was !== true) {
                if (was === false)
                    log.warn('Docker sandbox recovered — switching back to container isolation');
                else
                    log.info('Docker sandbox available');
            }
            this._available = true;
        }
        catch {
            if (was !== false) {
                log.error('Docker daemon unreachable — execution falling back to process/thread sandbox');
            }
            this._available = false;
        }
    }
    /**
     * Start a background health monitor that re-probes the Docker daemon every
     * `intervalMs` milliseconds (default 30 s). Call once at startup.
     * Safe to call multiple times — only one timer runs at a time.
     */
    startHealthMonitor(intervalMs = 30_000) {
        if (this._healthTimer)
            return;
        this._healthTimer = setInterval(() => {
            this._probe().catch(() => { });
        }, intervalMs);
        // Don't prevent process exit
        if (this._healthTimer.unref)
            this._healthTimer.unref();
    }
    /** Stop the background health monitor (called during graceful shutdown). */
    stopHealthMonitor() {
        if (this._healthTimer) {
            clearInterval(this._healthTimer);
            this._healthTimer = null;
        }
    }
    /**
     * Returns a warning message when Docker is unavailable and execution would
     * fall back to the process/thread sandbox, or null when Docker is available.
     * Callers use this together with `config.sandbox.fallbackPolicy` to decide
     * whether to proceed, warn, or deny.
     */
    getFallbackWarning() {
        if (this._available === true)
            return null;
        return 'Docker sandbox is unavailable — execution would use the less-isolated process/thread fallback.';
    }
    /**
     * Build the sandbox image if it does not already exist.
     * Called once at startup; non-blocking (fire-and-forget from index.ts).
     */
    async ensureImage(image = SANDBOX_IMAGE) {
        if (!(await this.isAvailable()))
            return;
        try {
            await this.docker.getImage(image).inspect();
            log.info({ image }, 'Sandbox image already present');
        }
        catch {
            log.info({ image }, 'Building sandbox image…');
            await this.buildImage(image);
        }
    }
    async buildImage(tag) {
        const contextPath = join(__dirname, '..', '..', 'src', 'sandbox');
        const stream = await this.docker.buildImage({ context: contextPath, src: ['Dockerfile.sandbox', 'base_stub.js', 'wrapper.mjs'] }, { t: tag, dockerfile: 'Dockerfile.sandbox' });
        await new Promise((resolve, reject) => {
            this.docker.modem.followProgress(stream, (err) => {
                if (err)
                    reject(err);
                else
                    resolve();
            });
        });
        log.info({ tag }, 'Sandbox image built');
    }
    /** Core container executor. */
    async run(opts) {
        if (active >= MAX_CONCURRENT) {
            throw new Error('Too many concurrent sandboxed executions. Try again shortly.');
        }
        active++;
        const sandboxCfg = config.sandbox ?? {};
        const image = opts.image ?? sandboxCfg.image ?? SANDBOX_IMAGE;
        const memBytes = (opts.memoryMb ?? sandboxCfg.memoryMb ?? 128) * 1024 * 1024;
        const nanoCpus = Math.floor((opts.cpuLimit ?? sandboxCfg.cpuLimit ?? 0.5) * 1e9);
        const pidsLimit = opts.pidsLimit ?? sandboxCfg.pidsLimit ?? 64;
        const netDisabled = opts.networkDisabled ?? sandboxCfg.networkDisabled ?? true;
        let container = null;
        let timer = null;
        try {
            container = await this.docker.createContainer({
                Image: image,
                Cmd: opts.command,
                Env: Object.entries(opts.env ?? {}).map(([k, v]) => `${k}=${v}`),
                NetworkDisabled: netDisabled,
                AttachStdout: true,
                AttachStderr: true,
                HostConfig: {
                    Memory: memBytes,
                    NanoCpus: nanoCpus,
                    PidsLimit: pidsLimit,
                    ReadonlyRootfs: true,
                    Tmpfs: { '/tmp': 'rw,noexec,nosuid,size=32m' },
                    CapDrop: ['ALL'],
                    SecurityOpt: ['no-new-privileges'],
                    AutoRemove: true,
                    Binds: opts.binds,
                    NetworkMode: netDisabled ? 'none' : undefined,
                },
            });
            // Collect stdout+stderr before starting
            const logStream = await container.attach({ stream: true, stdout: true, stderr: true });
            const stdoutChunks = [];
            const stderrChunks = [];
            const MAX_BUF = 2 * 1024 * 1024; // 2 MB each
            let stdoutSize = 0;
            let stderrSize = 0;
            const demuxPromise = new Promise((resolve) => {
                container.modem.demuxStream(logStream, {
                    write(chunk) {
                        stdoutSize += chunk.length;
                        if (stdoutSize <= MAX_BUF)
                            stdoutChunks.push(chunk);
                    },
                    end() { },
                }, {
                    write(chunk) {
                        stderrSize += chunk.length;
                        if (stderrSize <= MAX_BUF)
                            stderrChunks.push(chunk);
                    },
                    end() { },
                });
                logStream.on('end', resolve);
                logStream.on('error', resolve);
            });
            await container.start();
            // Timeout guard
            const waitPromise = new Promise((resolve, reject) => {
                timer = setTimeout(async () => {
                    log.warn({ timeoutMs: opts.timeoutMs }, 'Sandbox container timed out — stopping');
                    try {
                        await container.stop({ t: 2 });
                    }
                    catch { /* already stopped */ }
                    reject(new Error(`Execution timeout (>${opts.timeoutMs / 1000}s)`));
                }, opts.timeoutMs);
                container.wait().then(resolve).catch(reject);
            });
            const [exitInfo] = await Promise.all([waitPromise, demuxPromise]);
            if (timer)
                clearTimeout(timer);
            const stdout = Buffer.concat(stdoutChunks).toString('utf8');
            const stderr = Buffer.concat(stderrChunks).toString('utf8');
            return { stdout: stdout.trim(), stderr: stderr.trim(), exitCode: exitInfo.StatusCode };
        }
        catch (err) {
            if (timer)
                clearTimeout(timer);
            // Cleanup if AutoRemove didn't fire (e.g. container never started)
            if (container) {
                container.remove({ force: true }).catch(() => { });
            }
            throw err;
        }
        finally {
            active--;
        }
    }
    // ─── High-level helpers ──────────────────────────────────────────────────
    /**
     * Run JavaScript, Python, or Bash code in an isolated container.
     * Returns formatted output string (same shape as the existing subprocess path).
     */
    async runCode(language, code, timeoutMs) {
        const id = nanoid(10);
        const hostDir = join(tmpdir(), `gf-sandbox-${id}`);
        mkdirSync(hostDir, { recursive: true });
        // On Windows Docker Desktop the host path must be under a shared drive.
        // We use the system tmpdir which is always shared in Docker Desktop defaults.
        const containerDir = '/sandbox/code';
        const bind = `${hostDir.replace(/\\/g, '/')}:${containerDir}:ro`;
        let cmd;
        try {
            switch (language) {
                case 'javascript': {
                    // Wrap in the same console-capture wrapper as the subprocess path
                    const wrapper = `
const __out = [], __err = [];
const console = {
  log:   (...a) => __out.push(a.map(String).join(' ')),
  info:  (...a) => __out.push(a.map(String).join(' ')),
  warn:  (...a) => __err.push('[warn] '  + a.map(String).join(' ')),
  error: (...a) => __err.push('[error] ' + a.map(String).join(' ')),
  dir:   (x)   => __out.push(JSON.stringify(x, null, 2)),
  table: (x)   => __out.push(JSON.stringify(x, null, 2)),
};
try {
${code}
} catch (__e) { __err.push('Error: ' + String(__e)); }
process.stdout.write(JSON.stringify({ out: __out, err: __err }));
`.trim();
                    writeFileSync(join(hostDir, 'script.js'), wrapper, 'utf8');
                    cmd = ['node', '--eval', wrapper]; // eval avoids file path exposure
                    break;
                }
                case 'python': {
                    writeFileSync(join(hostDir, 'script.py'), code, 'utf8');
                    cmd = ['python3', '-E', '-S', '-B', `${containerDir}/script.py`];
                    break;
                }
                case 'bash':
                case 'shell': {
                    writeFileSync(join(hostDir, 'script.sh'), code, 'utf8');
                    cmd = ['bash', '--norc', '--noprofile', '-e', `${containerDir}/script.sh`];
                    break;
                }
                default:
                    throw new Error(`Unsupported language: ${language}`);
            }
            const result = await this.run({
                command: cmd,
                binds: language === 'javascript' ? [] : [bind],
                timeoutMs,
            });
            if (language === 'javascript') {
                // Try to parse the JSON console output
                try {
                    const parsed = JSON.parse(result.stdout);
                    const lines = [...parsed.out, ...parsed.err];
                    return lines.join('\n') || '(no output)';
                }
                catch {
                    return [result.stdout, result.stderr].filter(Boolean).join('\n') || '(no output)';
                }
            }
            const combined = [result.stdout, result.stderr].filter(Boolean).join('\n');
            if (result.exitCode !== 0) {
                return `Exit code ${result.exitCode}:\n${combined || 'No output'}`;
            }
            return combined || '(no output)';
        }
        finally {
            rmSync(hostDir, { recursive: true, force: true });
        }
    }
    /**
     * Run a shell command in an isolated container.
     * The command runs inside bash; the working directory is NOT mounted — the
     * container has a clean read-only filesystem.  Useful for command output
     * that doesn't depend on local project files.
     *
     * For commands that DO need host filesystem access (e.g. git, npm in a
     * project directory), we bind-mount the working directory read-only.
     */
    async runShell(command, workingDir, timeoutMs) {
        const binds = [];
        if (workingDir) {
            const containerWd = '/sandbox/workdir';
            binds.push(`${workingDir.replace(/\\/g, '/')}:${containerWd}:ro`);
        }
        const result = await this.run({
            command: ['bash', '--norc', '--noprofile', '-c', command],
            binds,
            timeoutMs,
        });
        const combined = [result.stdout, result.stderr].filter(Boolean).join('\n');
        if (result.exitCode !== 0) {
            return `Exit code ${result.exitCode}:\n${combined || 'No output'}`;
        }
        return combined || '(no output)';
    }
    /**
     * Run a custom skill file in an isolated container.
     * The skill file is bind-mounted read-only; the BaseSkill stub is pre-baked
     * into the image at /sandbox/skills/base.js.
     */
    async runCustomSkill(filePath, params, ctxSafe, timeoutMs) {
        const containerSkillPath = '/sandbox/usercode/skill.js';
        const bind = `${filePath.replace(/\\/g, '/')}:${containerSkillPath}:ro`;
        const result = await this.run({
            command: ['node', '/sandbox/wrapper.mjs'],
            env: {
                SKILL_PATH: containerSkillPath,
                SKILL_PARAMS: JSON.stringify(params),
                SKILL_CTX: JSON.stringify(ctxSafe),
            },
            binds: [bind],
            timeoutMs,
        });
        const output = result.stdout.trim();
        try {
            return JSON.parse(output);
        }
        catch {
            // Non-JSON output — wrap as text result
            const combined = [output, result.stderr].filter(Boolean).join('\n');
            if (result.exitCode !== 0) {
                return { success: false, error: combined || `Exit code ${result.exitCode}` };
            }
            return { success: true, text: combined || '(no output)' };
        }
    }
}
export const dockerSandbox = new DockerSandbox();
//# sourceMappingURL=docker.js.map