import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'fs';
import { dirname, isAbsolute, relative, resolve } from 'path';
import { spawnSync } from 'child_process';
import { createLogger } from '../utils/logger.js';
import { writeEvolutionOperationStatus } from '../memory/evolution_operation_status.js';
import { getRecentProjectEvolutionIncidentSummaries } from '../memory/project_evolution_incidents.js';
import { evaluateApprovalWindow, evaluateHealthChecks } from '../runtime/automation_policy.js';
import { evaluateProjectEvolutionReleaseAutomationGate } from '../memory/project_evolution_automation_gate.js';
const log = createLogger('project-release');
function runGit(repoPath, args) {
    const result = spawnSync('git', args, {
        cwd: repoPath,
        encoding: 'utf8',
        timeout: 30_000,
        stdio: ['ignore', 'pipe', 'pipe'],
    });
    if (result.error)
        throw result.error;
    if (result.status !== 0) {
        throw new Error((result.stderr ?? result.stdout ?? '').trim() || `git exited with code ${result.status}`);
    }
    return (result.stdout ?? '').trim();
}
function getCurrentBranch(repoPath) {
    const result = spawnSync('git', ['symbolic-ref', '--quiet', '--short', 'HEAD'], {
        cwd: repoPath,
        encoding: 'utf8',
        timeout: 30_000,
        stdio: ['ignore', 'pipe', 'pipe'],
    });
    if (result.error)
        throw result.error;
    if (result.status !== 0)
        return null;
    return (result.stdout ?? '').trim() || null;
}
function ensurePathInsideRepo(repoRoot, candidatePath) {
    const resolved = resolve(repoRoot, candidatePath);
    const rel = relative(repoRoot, resolved);
    if (rel.startsWith('..') || rel.includes(`..\\`) || rel.includes('../')) {
        throw new Error(`Path must stay inside the repository: ${candidatePath}`);
    }
    return resolved;
}
function stableJson(value) {
    return `${JSON.stringify(value, null, 2)}\n`;
}
function writeIfChanged(filePath, content) {
    const previous = existsSync(filePath) ? readFileSync(filePath, 'utf8') : null;
    if (previous === content)
        return false;
    mkdirSync(dirname(filePath), { recursive: true });
    writeFileSync(filePath, content, 'utf8');
    return true;
}
function isSemver(value) {
    return /^\d+\.\d+\.\d+$/.test(value);
}
function bumpSemver(version, bump) {
    if (bump === 'none')
        return version;
    const parts = version.split('.').map((part) => Number(part));
    if (parts.length !== 3 || parts.some((part) => !Number.isFinite(part))) {
        throw new Error(`package.json version is not a simple semver triplet: ${version}`);
    }
    const [major, minor, patch] = parts;
    if (bump === 'major')
        return `${major + 1}.0.0`;
    if (bump === 'minor')
        return `${major}.${minor + 1}.0`;
    return `${major}.${minor}.${patch + 1}`;
}
function buildDefaultConfig(partial) {
    return {
        enabled: false,
        repoPath: '',
        manifestPath: '.greenfrog/releases/latest.json',
        notesPath: '.greenfrog/releases/RELEASE_NOTES.md',
        bump: 'patch',
        autoCommit: false,
        autoPush: false,
        autoTag: false,
        createGithubRelease: false,
        remote: 'origin',
        baseBranch: 'main',
        releaseTitle: 'GreenFrog automated release',
        branchPrefix: 'greenfrog-evolution',
        commitMessage: 'chore(release): publish automated release metadata',
        tagPrefix: 'v',
        healthCheckCommands: [],
        minHealthChecksPassing: 0,
        respectAutomationPolicies: false,
        ...partial,
    };
}
function buildReleaseNotes(params) {
    const lines = [
        '# GreenFrog Automated Release Notes',
        '',
        `- Previous version: ${params.currentVersion}`,
        `- Release version: ${params.nextVersion}`,
        `- Generated at: ${new Date().toISOString()}`,
        `- Git SHA: ${params.gitSha ?? 'unknown'}`,
        '',
    ];
    const ruleCandidatesPath = resolve(params.repoRoot, '.greenfrog/evolution/rule_candidates.json');
    if (existsSync(ruleCandidatesPath)) {
        try {
            const payload = JSON.parse(readFileSync(ruleCandidatesPath, 'utf8'));
            lines.push('## Included Rule Evolution');
            lines.push('');
            lines.push(`- Accepted rule candidates: ${payload.candidateCount ?? 0}`);
            lines.push(`- Rejected rule candidates: ${payload.rejectedCount ?? 0}`);
            lines.push('');
        }
        catch {
            // ignore malformed optional metadata
        }
    }
    const codeCandidatesPath = resolve(params.repoRoot, '.greenfrog/evolution/core_code_candidates.json');
    if (existsSync(codeCandidatesPath)) {
        try {
            const payload = JSON.parse(readFileSync(codeCandidatesPath, 'utf8'));
            lines.push('## Included Core Code Evolution');
            lines.push('');
            lines.push(`- Accepted code candidates: ${payload.candidateCount ?? 0}`);
            lines.push(`- Rejected code candidates: ${payload.rejectedCount ?? 0}`);
            lines.push('');
        }
        catch {
            // ignore malformed optional metadata
        }
    }
    const recentIncidents = getRecentProjectEvolutionIncidentSummaries(params.repoRoot, { limit: 3 });
    if (recentIncidents.length > 0) {
        lines.push('## Recent Critical Incidents');
        lines.push('');
        for (const incident of recentIncidents) {
            lines.push(`- ${incident.createdAt} [${incident.priority}] ${incident.title}: ${incident.summary}`);
        }
        lines.push('');
    }
    lines.push('This release metadata was generated automatically after merged project learnings were promoted into the source repository.');
    return `${lines.join('\n')}\n`;
}
function runShellCommand(command, repoPath) {
    const result = spawnSync(command, {
        cwd: repoPath,
        encoding: 'utf8',
        timeout: 10 * 60_000,
        stdio: 'inherit',
        shell: true,
    });
    if (result.error)
        throw result.error;
    if (result.status !== 0) {
        throw new Error(`Command failed (${result.status}): ${command}`);
    }
}
function maybeCommitRelease(config, repoRoot, changedFiles) {
    if (!config.autoCommit) {
        return { committed: false, branch: null, skippedReason: 'autoCommit disabled' };
    }
    if (changedFiles.length === 0) {
        return { committed: false, branch: null, skippedReason: 'no file changes to commit' };
    }
    const currentBranch = getCurrentBranch(repoRoot);
    if (!currentBranch) {
        return { committed: false, branch: null, skippedReason: 'detached HEAD; refusing auto-commit' };
    }
    if (currentBranch !== config.baseBranch) {
        return { committed: false, branch: currentBranch, skippedReason: `current branch "${currentBranch}" is not release branch "${config.baseBranch}"` };
    }
    runGit(repoRoot, ['add', '--', ...changedFiles]);
    const staged = runGit(repoRoot, ['diff', '--cached', '--name-only', '--root', '--']);
    if (!staged.trim()) {
        return { committed: false, branch: currentBranch, skippedReason: 'no staged changes after add' };
    }
    runGit(repoRoot, ['commit', '-m', config.commitMessage]);
    return { committed: true, branch: currentBranch, skippedReason: null };
}
function maybePushRelease(config, repoRoot, branch) {
    if (!config.autoPush) {
        return { pushed: false, skippedReason: 'autoPush disabled' };
    }
    if (!branch) {
        return { pushed: false, skippedReason: 'no branch available for push' };
    }
    runGit(repoRoot, ['push', config.remote, branch]);
    return { pushed: true, skippedReason: null };
}
function maybeTagRelease(config, repoRoot, nextVersion) {
    if (!config.autoTag) {
        return { tagged: false, tagName: null, skippedReason: 'autoTag disabled' };
    }
    const currentBranch = getCurrentBranch(repoRoot);
    if (currentBranch !== config.baseBranch) {
        return { tagged: false, tagName: null, skippedReason: `current branch "${currentBranch}" is not release branch "${config.baseBranch}"` };
    }
    const tagName = `${config.tagPrefix}${nextVersion}`;
    const existing = spawnSync('git', ['tag', '--list', tagName], {
        cwd: repoRoot,
        encoding: 'utf8',
        timeout: 30_000,
        stdio: ['ignore', 'pipe', 'pipe'],
    });
    if ((existing.stdout ?? '').trim() === tagName) {
        return { tagged: false, tagName, skippedReason: `tag already exists: ${tagName}` };
    }
    runGit(repoRoot, ['tag', '-a', tagName, '-m', `${config.releaseTitle} ${nextVersion}`]);
    if (config.autoPush) {
        runGit(repoRoot, ['push', config.remote, tagName]);
    }
    return { tagged: true, tagName, skippedReason: null };
}
async function maybeCreateGithubRelease(params) {
    const { config, nextVersion, notes } = params;
    if (!config.createGithubRelease) {
        return { url: null, id: null, skippedReason: 'createGithubRelease disabled' };
    }
    if (!config.repo) {
        return { url: null, id: null, skippedReason: 'repo is required for createGithubRelease' };
    }
    if (!config.githubToken) {
        return { url: null, id: null, skippedReason: 'github token is required for createGithubRelease' };
    }
    const tagName = `${config.tagPrefix}${nextVersion}`;
    const headers = {
        Accept: 'application/vnd.github.v3+json',
        Authorization: `token ${config.githubToken}`,
        'User-Agent': 'GreenFrog-Agent/1.0',
    };
    const existingRes = await fetch(`https://api.github.com/repos/${config.repo}/releases/tags/${encodeURIComponent(tagName)}`, {
        method: 'GET',
        headers,
    });
    if (existingRes.ok) {
        const existing = await existingRes.json();
        return { url: existing.html_url, id: existing.id, skippedReason: 'github release already exists' };
    }
    if (existingRes.status !== 404) {
        const err = await existingRes.json().catch(() => ({ message: existingRes.statusText }));
        throw new Error(`GitHub API ${existingRes.status}: ${err.message ?? existingRes.statusText}`);
    }
    const createRes = await fetch(`https://api.github.com/repos/${config.repo}/releases`, {
        method: 'POST',
        headers: {
            ...headers,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            tag_name: tagName,
            name: `${config.releaseTitle} ${nextVersion}`,
            body: notes,
            draft: false,
            prerelease: false,
        }),
    });
    if (!createRes.ok) {
        const err = await createRes.json().catch(() => ({ message: createRes.statusText }));
        throw new Error(`GitHub API ${createRes.status}: ${err.message ?? createRes.statusText}`);
    }
    const created = await createRes.json();
    return { url: created.html_url, id: created.id, skippedReason: null };
}
export async function generateProjectRelease(partial) {
    const config = buildDefaultConfig(partial);
    const repoRoot = config.repoPath
        ? (isAbsolute(config.repoPath) ? config.repoPath : resolve(process.cwd(), config.repoPath))
        : null;
    if (!config.enabled) {
        const result = {
            changed: false,
            currentVersion: 'unknown',
            nextVersion: 'unknown',
            manifestPath: config.manifestPath,
            notesPath: config.notesPath,
            committed: false,
            pushed: false,
            tagged: false,
            branch: null,
            releaseUrl: null,
            releaseId: null,
            skippedReason: 'project release disabled',
        };
        if (repoRoot) {
            writeEvolutionOperationStatus(repoRoot, 'project_release', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    changed: result.changed,
                    currentVersion: result.currentVersion,
                    nextVersion: result.nextVersion,
                    committed: result.committed,
                    pushed: result.pushed,
                    tagged: result.tagged,
                },
            });
        }
        return result;
    }
    if (!config.repoPath) {
        throw new Error('repoPath is required when project release is enabled');
    }
    const resolvedRepoRoot = repoRoot;
    if (!resolvedRepoRoot) {
        throw new Error('repoPath is required when project release is enabled');
    }
    let releaseHealthChecks = null;
    let releaseAutomationGate = null;
    try {
        runGit(resolvedRepoRoot, ['rev-parse', '--show-toplevel']);
        const branch = getCurrentBranch(resolvedRepoRoot);
        if (!branch) {
            const result = {
                changed: false,
                currentVersion: 'unknown',
                nextVersion: 'unknown',
                manifestPath: config.manifestPath,
                notesPath: config.notesPath,
                committed: false,
                pushed: false,
                tagged: false,
                branch: null,
                releaseUrl: null,
                releaseId: null,
                skippedReason: 'detached HEAD; refusing automated release',
            };
            writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    branch: result.branch,
                    currentVersion: result.currentVersion,
                    nextVersion: result.nextVersion,
                },
            });
            return result;
        }
        if (branch.startsWith(`${config.branchPrefix}/`) || branch === config.branchPrefix) {
            const result = {
                changed: false,
                currentVersion: 'unknown',
                nextVersion: 'unknown',
                manifestPath: config.manifestPath,
                notesPath: config.notesPath,
                committed: false,
                pushed: false,
                tagged: false,
                branch,
                releaseUrl: null,
                releaseId: null,
                skippedReason: `current branch "${branch}" matches evolution branch prefix "${config.branchPrefix}"`,
            };
            writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    branch: result.branch,
                    currentVersion: result.currentVersion,
                    nextVersion: result.nextVersion,
                },
            });
            return result;
        }
        if (branch !== config.baseBranch) {
            const result = {
                changed: false,
                currentVersion: 'unknown',
                nextVersion: 'unknown',
                manifestPath: config.manifestPath,
                notesPath: config.notesPath,
                committed: false,
                pushed: false,
                tagged: false,
                branch,
                releaseUrl: null,
                releaseId: null,
                skippedReason: `current branch "${branch}" is not release branch "${config.baseBranch}"`,
            };
            writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
                status: 'skipped',
                skippedReason: result.skippedReason,
                summary: {
                    branch: result.branch,
                    currentVersion: result.currentVersion,
                    nextVersion: result.nextVersion,
                },
            });
            return result;
        }
        if (config.respectAutomationPolicies) {
            const approvalWindow = evaluateApprovalWindow({
                startHourUtc: config.approvalWindowStartHourUtc,
                endHourUtc: config.approvalWindowEndHourUtc,
                approvedWeekdaysUtc: config.approvedWeekdaysUtc,
            });
            if (!approvalWindow.allowed) {
                const result = {
                    changed: false,
                    currentVersion: 'unknown',
                    nextVersion: 'unknown',
                    manifestPath: config.manifestPath,
                    notesPath: config.notesPath,
                    committed: false,
                    pushed: false,
                    tagged: false,
                    branch,
                    releaseUrl: null,
                    releaseId: null,
                    skippedReason: approvalWindow.reason,
                };
                writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
                    status: 'skipped',
                    skippedReason: result.skippedReason,
                    summary: {
                        branch: result.branch,
                        approvalWindow,
                    },
                });
                return result;
            }
            const healthChecks = await evaluateHealthChecks({
                commands: config.healthCheckCommands,
                minPassing: config.minHealthChecksPassing,
            }, (command) => runShellCommand(command, resolvedRepoRoot));
            releaseHealthChecks = {
                total: healthChecks.total,
                passed: healthChecks.passed,
                required: healthChecks.required,
            };
            if (!healthChecks.allowed) {
                const result = {
                    changed: false,
                    currentVersion: 'unknown',
                    nextVersion: 'unknown',
                    manifestPath: config.manifestPath,
                    notesPath: config.notesPath,
                    committed: false,
                    pushed: false,
                    tagged: false,
                    branch,
                    releaseUrl: null,
                    releaseId: null,
                    skippedReason: healthChecks.reason,
                };
                writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
                    status: 'skipped',
                    skippedReason: result.skippedReason,
                    summary: {
                        branch: result.branch,
                        healthChecks: {
                            total: healthChecks.total,
                            passed: healthChecks.passed,
                            required: healthChecks.required,
                        },
                    },
                });
                return result;
            }
            releaseAutomationGate = evaluateProjectEvolutionReleaseAutomationGate(resolvedRepoRoot, branch);
            if (!releaseAutomationGate.allowed) {
                const result = {
                    changed: false,
                    currentVersion: 'unknown',
                    nextVersion: 'unknown',
                    manifestPath: config.manifestPath,
                    notesPath: config.notesPath,
                    committed: false,
                    pushed: false,
                    tagged: false,
                    branch,
                    releaseUrl: null,
                    releaseId: null,
                    skippedReason: releaseAutomationGate.reason,
                };
                writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
                    status: 'skipped',
                    skippedReason: result.skippedReason,
                    summary: {
                        branch: result.branch,
                        automationGate: releaseAutomationGate,
                    },
                });
                return result;
            }
        }
        const packageFile = ensurePathInsideRepo(resolvedRepoRoot, 'package.json');
        const pkg = JSON.parse(readFileSync(packageFile, 'utf8'));
        const currentVersion = typeof pkg.version === 'string' && isSemver(pkg.version) ? pkg.version : '0.0.0';
        const nextVersion = bumpSemver(currentVersion, config.bump);
        if (nextVersion !== currentVersion) {
            pkg.version = nextVersion;
        }
        const manifestFile = ensurePathInsideRepo(resolvedRepoRoot, config.manifestPath);
        const notesFile = ensurePathInsideRepo(resolvedRepoRoot, config.notesPath);
        const gitSha = (() => {
            try {
                return runGit(resolvedRepoRoot, ['rev-parse', 'HEAD']);
            }
            catch {
                return null;
            }
        })();
        const manifest = {
            generatedAt: new Date().toISOString(),
            version: nextVersion,
            previousVersion: currentVersion,
            gitSha,
            branch,
            artifacts: {
                ruleCandidates: existsSync(resolve(resolvedRepoRoot, '.greenfrog/evolution/rule_candidates.json')) ? '.greenfrog/evolution/rule_candidates.json' : null,
                codeCandidates: existsSync(resolve(resolvedRepoRoot, '.greenfrog/evolution/core_code_candidates.json')) ? '.greenfrog/evolution/core_code_candidates.json' : null,
                codePatch: existsSync(resolve(resolvedRepoRoot, '.greenfrog/evolution/core_changes.patch')) ? '.greenfrog/evolution/core_changes.patch' : null,
            },
            ...(releaseAutomationGate ? { automationGate: releaseAutomationGate.approval } : {}),
        };
        const notes = buildReleaseNotes({
            currentVersion,
            nextVersion,
            gitSha,
            repoRoot: resolvedRepoRoot,
        });
        const changedFiles = new Set();
        if (writeIfChanged(packageFile, stableJson(pkg))) {
            changedFiles.add('package.json');
        }
        if (writeIfChanged(manifestFile, stableJson(manifest))) {
            changedFiles.add(relative(resolvedRepoRoot, manifestFile));
        }
        if (writeIfChanged(notesFile, notes)) {
            changedFiles.add(relative(resolvedRepoRoot, notesFile));
        }
        const changedFileList = [...changedFiles].sort();
        const commitState = maybeCommitRelease(config, resolvedRepoRoot, changedFileList);
        const pushState = commitState.committed
            ? maybePushRelease(config, resolvedRepoRoot, commitState.branch)
            : { pushed: false, skippedReason: commitState.skippedReason };
        const tagState = commitState.committed
            ? maybeTagRelease(config, resolvedRepoRoot, nextVersion)
            : { tagged: false, tagName: null, skippedReason: commitState.skippedReason };
        const releaseState = tagState.tagged || config.createGithubRelease
            ? await maybeCreateGithubRelease({ config, nextVersion, notes })
            : { url: null, id: null, skippedReason: tagState.skippedReason };
        log.info({
            repoRoot: resolvedRepoRoot,
            currentVersion,
            nextVersion,
            changedFiles: changedFileList,
            committed: commitState.committed,
            pushed: pushState.pushed,
            tagged: tagState.tagged,
            releaseUrl: releaseState.url,
            skippedReason: releaseState.skippedReason ?? tagState.skippedReason ?? pushState.skippedReason ?? commitState.skippedReason,
        }, 'Project release generation completed');
        const result = {
            changed: changedFileList.length > 0,
            currentVersion,
            nextVersion,
            manifestPath: manifestFile,
            notesPath: notesFile,
            committed: commitState.committed,
            pushed: pushState.pushed,
            tagged: tagState.tagged,
            branch,
            releaseUrl: releaseState.url,
            releaseId: releaseState.id,
            skippedReason: releaseState.skippedReason ?? tagState.skippedReason ?? pushState.skippedReason ?? commitState.skippedReason,
        };
        writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
            status: result.changed || result.committed || result.pushed || result.tagged || result.releaseId != null ? 'success' : 'skipped',
            skippedReason: result.skippedReason,
            summary: {
                branch: result.branch,
                currentVersion: result.currentVersion,
                nextVersion: result.nextVersion,
                changed: result.changed,
                committed: result.committed,
                pushed: result.pushed,
                tagged: result.tagged,
                releaseUrl: result.releaseUrl,
                healthChecks: releaseHealthChecks,
                automationGate: releaseAutomationGate,
                approvalWindow: config.respectAutomationPolicies ? evaluateApprovalWindow({
                    startHourUtc: config.approvalWindowStartHourUtc,
                    endHourUtc: config.approvalWindowEndHourUtc,
                    approvedWeekdaysUtc: config.approvedWeekdaysUtc,
                }) : null,
            },
        });
        return result;
    }
    catch (err) {
        writeEvolutionOperationStatus(resolvedRepoRoot, 'project_release', {
            status: 'error',
            skippedReason: err instanceof Error ? err.message : String(err),
        });
        throw err;
    }
}
//# sourceMappingURL=project_release.js.map