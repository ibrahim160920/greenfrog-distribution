/**
 * sanitizer.ts — Backflow data sanitizer.
 *
 * Strips all user-identifiable fields from backflow payloads before transmission.
 * This sanitizer is non-bypassable: all backflow data passes through it.
 *
 * What is ALLOWED (anonymized structural data):
 *   - version, platform, arch
 *   - uptime (seconds)
 *   - capability usage counts (no content)
 *   - anonymized error codes (no stack traces, no messages)
 *   - performance metrics (latency buckets, no content)
 *
 * What is NEVER transmitted:
 *   - raw conversation content
 *   - private files or documents
 *   - personal or identifying information
 *   - proprietary work products
 *   - stack traces or error messages
 *   - file paths
 */
export interface RawBackflowEntry {
    type: string;
    [key: string]: unknown;
}
export interface SanitizedBackflowEntry {
    type: string;
    [key: string]: string | number | boolean | null;
}
/**
 * Sanitize a single backflow entry.
 * Returns null if the entry cannot be safely sanitized (skip silently).
 */
export declare function sanitizeEntry(raw: RawBackflowEntry): SanitizedBackflowEntry | null;
/**
 * Sanitize an array of backflow entries.
 * Drops any entries that fail sanitization.
 */
export declare function sanitizeBatch(entries: RawBackflowEntry[]): SanitizedBackflowEntry[];
//# sourceMappingURL=sanitizer.d.ts.map