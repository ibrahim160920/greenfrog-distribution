import type { WorkflowDef } from './utils/types.js';
export interface StartOptions {
    webEnabled?: boolean;
    gatewayEnabled?: boolean;
}
export declare function startPlatform(options?: StartOptions): Promise<void>;
export declare function scheduleWorkflow(wf: WorkflowDef): void;
/** Execute a workflow: run each step sequentially, handle notify_if and stop_if. */
export declare function executeWorkflow(wf: WorkflowDef, runId?: string): Promise<void>;
//# sourceMappingURL=index.d.ts.map