import { type ProjectEvolutionRecoverySignalKind, type ProjectEvolutionRecoverySignalPriority } from '../../memory/project_evolution_recovery_signals.js';
export interface RecordRecoverySignalOptions {
    repo?: string;
    kind: ProjectEvolutionRecoverySignalKind;
    priority?: ProjectEvolutionRecoverySignalPriority;
    title: string;
    summary: string;
    source: string;
    details?: string;
    passed?: boolean;
    id?: string;
}
export declare function recordRecoverySignalCommand(opts: RecordRecoverySignalOptions): Promise<void>;
//# sourceMappingURL=recovery_signal.d.ts.map