import { readdirSync, statSync, existsSync, readFileSync, writeFileSync, mkdirSync, copyFileSync, } from 'fs';
import { spawnSync } from 'child_process';
import { join, resolve, basename } from 'path';
import { homedir, tmpdir } from 'os';
import { nanoid } from 'nanoid';
import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
// Restrict project_path to safe roots — same pattern as file_ops / git_ops
function getSafeRoots() {
    return [resolve(homedir()), resolve(process.cwd()), resolve(tmpdir())];
}
function isSafePath(p) {
    const resolved = resolve(p);
    return getSafeRoots().some((root) => resolved.startsWith(root + '/') || resolved.startsWith(root + '\\') || resolved === root);
}
/**
 * Take a snapshot of a set of files before modification.
 * Returns a backup manifest mapping original path → backup path.
 */
function snapshotFiles(paths) {
    const backupDir = join(tmpdir(), `greenfrog_backup_${nanoid()}`);
    mkdirSync(backupDir, { recursive: true });
    const manifest = new Map();
    for (const p of paths) {
        if (existsSync(p) && statSync(p).isFile()) {
            const backupPath = join(backupDir, `${nanoid()}_${basename(p)}`);
            copyFileSync(p, backupPath);
            manifest.set(p, backupPath);
        }
    }
    return manifest;
}
/**
 * Restore files from a backup manifest.
 * Files that were NOT in the snapshot are left alone (they were created new).
 */
function restoreFiles(manifest) {
    for (const [original, backup] of manifest) {
        copyFileSync(backup, original);
    }
}
/**
 * Produce a line-level unified diff string between two text contents.
 * This is a minimal Myers-diff implementation — good enough for a preview.
 */
function unifiedDiff(oldText, newText, filename) {
    const oldLines = oldText.split('\n');
    const newLines = newText.split('\n');
    const hunks = [`--- ${filename} (before)`, `+++ ${filename} (after)`];
    let changed = false;
    // Simple approach: show changed regions with ±3 context lines
    const maxLen = Math.max(oldLines.length, newLines.length);
    let i = 0;
    while (i < maxLen) {
        const o = oldLines[i] ?? '';
        const n = newLines[i] ?? '';
        if (o !== n) {
            changed = true;
            const start = Math.max(0, i - 3);
            const end = Math.min(maxLen - 1, i + 3);
            hunks.push(`@@ line ${i + 1} @@`);
            for (let j = start; j <= end; j++) {
                const ol = oldLines[j] ?? '';
                const nl = newLines[j] ?? '';
                if (j < i - 1 || j > i + 1) {
                    // Context line — use whichever side has it
                    hunks.push(` ${ol || nl}`);
                }
                else {
                    if (ol !== nl) {
                        if (ol)
                            hunks.push(`-${ol}`);
                        if (nl)
                            hunks.push(`+${nl}`);
                    }
                    else {
                        hunks.push(` ${ol}`);
                    }
                }
            }
            i = end + 1;
        }
        else {
            i++;
        }
    }
    if (!changed)
        return '';
    const raw = hunks.join('\n');
    const MAX_DIFF = 50 * 1024;
    if (raw.length > MAX_DIFF) {
        return raw.slice(0, MAX_DIFF) + '\n... [diff truncated]';
    }
    return raw;
}
export class CodingAgentSkill extends BaseSkill {
    definition = {
        name: 'coding_agent',
        description: 'An autonomous coding agent that ACTUALLY reads and modifies files, runs tests, executes shell commands, and implements changes. Give it a task and it will do the work — not just describe it. Supports diff preview and rollback.',
        category: 'development',
        parameters: [
            {
                name: 'task',
                type: 'string',
                required: true,
                description: 'What to implement or fix (e.g. "fix the bug in src/auth.ts", "add unit tests for the parser")',
            },
            { name: 'project_path', type: 'string', description: 'Path to the project directory (defaults to cwd)' },
            { name: 'context', type: 'string', description: 'Additional context, relevant code snippets, or constraints' },
            { name: 'max_steps', type: 'number', description: 'Maximum tool-call iterations (default 8, max 15)' },
            {
                name: 'show_diff',
                type: 'boolean',
                description: 'Show a diff of every file changed (default: true)',
                default: true,
            },
            {
                name: 'rollback',
                type: 'boolean',
                description: 'If true, automatically restore all changed files to their pre-run state (dry-run mode)',
                default: false,
            },
        ],
    };
    async execute(params, ctx) {
        const task = params.task;
        const rawPath = params.project_path ?? process.cwd();
        const projectPath = resolve(rawPath);
        const extraContext = params.context ?? '';
        const maxSteps = Math.min(Math.max(1, Number(params.max_steps ?? 8) || 8), 15);
        const showDiff = params.show_diff !== false;
        const doRollback = params.rollback === true;
        // Security: only allow access to safe roots
        if (!isSafePath(projectPath)) {
            return this.err(`Access denied: "${projectPath}" is outside the allowed directories.`);
        }
        if (!existsSync(projectPath)) {
            return this.err(`Project path does not exist: "${projectPath}"`);
        }
        // ── Gather project context ────────────────────────────────────────────────
        const projectInfo = this.gatherProjectInfo(projectPath);
        const systemPrompt = `You are an expert software engineer with access to real tools.
You are working on the following project:

${projectInfo}

Your job: implement the task using the tools available to you.
- Use \`file_ops\` to read files BEFORE modifying them. Always read first, then write.
- Use \`shell\` to run tests, install packages, or check results.
- Use \`git\` for git operations if needed.
- Use \`code_exec\` to test logic in isolation.
- After finishing, provide a concise summary of every change you made.
- Be precise. Write clean, working code. Handle edge cases.
- Do NOT describe what to do — actually do it with the tools.`;
        const userMessage = `Task: ${task}${extraContext ? `\n\nAdditional context:\n${extraContext}` : ''}

Please implement this now using your tools.`;
        // ── Load only the coding-relevant tools ───────────────────────────────────
        const { skillRegistry } = await import('./registry.js');
        const codingToolNames = ['file_ops', 'shell', 'git', 'code_exec', 'web_search', 'web_fetch'];
        const codingTools = codingToolNames
            .map((n) => skillRegistry.get(n)?.toProviderTool())
            .filter((t) => t != null);
        // ── Snapshot files before modification ───────────────────────────────────
        // We track every file path touched by file_ops write/delete for diff/rollback
        const touchedFiles = new Set();
        let fileWriteCount = 0;
        const MAX_FILE_WRITES = 20; // hard cap per task run
        const preSnapshots = new Map(); // path → original content
        const trackWrite = (filePath) => {
            if (!touchedFiles.has(filePath)) {
                touchedFiles.add(filePath);
                if (existsSync(filePath)) {
                    try {
                        const MAX_SNAPSHOT = 200 * 1024;
                        const raw = readFileSync(filePath, 'utf8');
                        preSnapshots.set(filePath, raw.length > MAX_SNAPSHOT ? raw.slice(0, MAX_SNAPSHOT) + '\n... [truncated]' : raw);
                    }
                    catch { /* ignore */ }
                }
                else {
                    preSnapshots.set(filePath, ''); // file didn't exist before
                }
            }
        };
        // ── Mini agentic loop ─────────────────────────────────────────────────────
        const messages = [{ role: 'user', content: userMessage }];
        let finalSummary = '';
        const toolLog = [];
        for (let step = 0; step < maxSteps; step++) {
            const response = await providerRegistry.chatWithFallback({
                messages,
                tools: codingTools,
                systemPrompt,
                maxTokens: 4096,
                temperature: 0.2,
            });
            if (response.content)
                finalSummary = response.content;
            if (!response.toolCalls || response.toolCalls.length === 0)
                break;
            messages.push({
                role: 'assistant',
                content: response.content ?? '',
                rawContent: response.rawContent,
            });
            const toolResults = [];
            for (const toolCall of response.toolCalls) {
                toolLog.push(`[${toolCall.name}] ${JSON.stringify(toolCall.arguments).slice(0, 80)}`);
                // Intercept file writes for snapshot tracking
                if (toolCall.name === 'file_ops' &&
                    (toolCall.arguments.action === 'write' || toolCall.arguments.action === 'delete') &&
                    typeof toolCall.arguments.path === 'string') {
                    trackWrite(resolve(toolCall.arguments.path));
                    fileWriteCount++;
                    if (fileWriteCount > MAX_FILE_WRITES) {
                        toolResults.push({
                            id: toolCall.id,
                            name: toolCall.name,
                            content: `Error: File modification limit reached (${MAX_FILE_WRITES} writes per task). Task stopped for safety.`,
                        });
                        break;
                    }
                }
                const result = await skillRegistry.call(toolCall.name, toolCall.arguments, ctx);
                const resultText = result.text ?? (result.error ? `Error: ${result.error}` : JSON.stringify(result.data));
                toolResults.push({ id: toolCall.id, name: toolCall.name, content: resultText });
            }
            messages.push({ role: 'user', content: '', toolResults });
        }
        // ── Rollback if requested ─────────────────────────────────────────────────
        if (doRollback && touchedFiles.size > 0) {
            for (const [filePath, originalContent] of preSnapshots) {
                try {
                    if (originalContent === '') {
                        // File was created — remove it
                        const { unlinkSync } = await import('fs');
                        if (existsSync(filePath))
                            unlinkSync(filePath);
                    }
                    else {
                        writeFileSync(filePath, originalContent, 'utf8');
                    }
                }
                catch { /* best-effort */ }
            }
            const header = `🔄 **Rollback complete** — all ${touchedFiles.size} file(s) restored to pre-run state.\n\n`;
            return this.text(header + (finalSummary || 'Task would have made the above changes.'));
        }
        // ── Build diff output ─────────────────────────────────────────────────────
        // First, augment touchedFiles with any git-detected changes (captures shell-level edits)
        if (showDiff) {
            const gitChangedFiles = this.getGitChangedFiles(projectPath);
            for (const f of gitChangedFiles) {
                if (!touchedFiles.has(f)) {
                    // File changed via shell command — snapshot was NOT taken before, so we
                    // use git to get the original content.
                    touchedFiles.add(f);
                    const originalContent = this.getGitOriginalContent(f, projectPath);
                    if (originalContent !== null)
                        preSnapshots.set(f, originalContent);
                }
            }
        }
        const diffSections = [];
        if (showDiff && touchedFiles.size > 0) {
            for (const filePath of touchedFiles) {
                const before = preSnapshots.get(filePath) ?? '';
                let after = '';
                try {
                    if (existsSync(filePath)) {
                        const MAX_SNAPSHOT = 200 * 1024;
                        const raw = readFileSync(filePath, 'utf8');
                        after = raw.length > MAX_SNAPSHOT ? raw.slice(0, MAX_SNAPSHOT) + '\n... [truncated]' : raw;
                    }
                }
                catch { /* ignore */ }
                if (before === after)
                    continue; // no net change
                const diff = unifiedDiff(before, after, filePath);
                if (diff)
                    diffSections.push(`**\`${filePath}\`**\n\`\`\`diff\n${diff}\n\`\`\``);
            }
        }
        const header = toolLog.length > 0
            ? `🔧 **Coding Agent** (${toolLog.length} steps):\n${toolLog.map((l) => `  • ${l}`).join('\n')}\n\n`
            : '🤖 **Coding Agent**:\n\n';
        const diffBlock = diffSections.length > 0
            ? `\n\n---\n\n**Changes (${diffSections.length} file(s) modified):**\n\n${diffSections.join('\n\n')}`
            : '';
        return this.text(header + (finalSummary || 'Task completed.') + diffBlock);
    }
    /**
     * Use `git diff --name-only` + `git ls-files --others` to discover all files
     * changed since the last commit — including those modified by shell commands.
     * Returns absolute paths.
     */
    getGitChangedFiles(projectPath) {
        try {
            const modified = spawnSync('git', ['diff', '--name-only', 'HEAD'], {
                cwd: projectPath, encoding: 'utf8', shell: false, timeout: 5000,
                maxBuffer: 2 * 1024 * 1024,
            });
            const untracked = spawnSync('git', ['ls-files', '--others', '--exclude-standard'], {
                cwd: projectPath, encoding: 'utf8', shell: false, timeout: 5000,
                maxBuffer: 2 * 1024 * 1024,
            });
            const paths = [];
            for (const line of (modified.stdout ?? '').split('\n').concat((untracked.stdout ?? '').split('\n'))) {
                const trimmed = line.trim();
                if (trimmed)
                    paths.push(resolve(projectPath, trimmed));
            }
            return paths;
        }
        catch {
            return [];
        }
    }
    /**
     * Get the original (pre-modification) content of a file via `git show HEAD:<path>`.
     * Returns null if the file is new (not in HEAD) or if git is unavailable.
     */
    getGitOriginalContent(filePath, projectPath) {
        try {
            const rel = filePath.startsWith(projectPath)
                ? filePath.slice(projectPath.length).replace(/^[/\\]/, '')
                : filePath;
            const result = spawnSync('git', ['show', `HEAD:${rel}`], {
                cwd: projectPath, encoding: 'utf8', shell: false, timeout: 5000,
                maxBuffer: 2 * 1024 * 1024,
            });
            if (result.status === 0)
                return result.stdout;
            return null; // file is new (not in HEAD)
        }
        catch {
            return null;
        }
    }
    gatherProjectInfo(projectPath) {
        const lines = [`Project: ${projectPath}`];
        const pkgPath = join(projectPath, 'package.json');
        if (existsSync(pkgPath)) {
            try {
                const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
                lines.push(`Package: ${pkg.name}@${pkg.version}`);
                if (pkg.description)
                    lines.push(`Description: ${pkg.description}`);
                const deps = Object.keys(pkg.dependencies ?? {}).slice(0, 10).join(', ');
                if (deps)
                    lines.push(`Dependencies: ${deps}`);
            }
            catch { /* ignore */ }
        }
        try {
            const entries = readdirSync(projectPath).slice(0, 40);
            const annotated = entries.map((name) => {
                try {
                    return statSync(join(projectPath, name)).isDirectory() ? `${name}/` : name;
                }
                catch {
                    return name;
                }
            });
            lines.push(`Files: ${annotated.join('  ')}`);
        }
        catch { /* ignore */ }
        return lines.join('\n');
    }
}
//# sourceMappingURL=coding_agent.js.map