/**
 * Prometheus metrics — singleton registry.
 *
 * Exposes:
 *   greenfrog_messages_total          — messages received per channel
 *   greenfrog_skill_calls_total       — skill invocations (skill, success labels)
 *   greenfrog_skill_duration_ms       — skill execution time histogram
 *   greenfrog_llm_latency_ms          — LLM API latency histogram
 *   greenfrog_llm_tokens_total        — LLM tokens consumed (provider, model, type)
 *   greenfrog_patrol_checks_total     — patrol check outcomes
 *   greenfrog_job_runs_total          — scheduled job completions
 *   greenfrog_websocket_clients       — active WS clients gauge
 *   greenfrog_queue_depth             — BullMQ queue depth gauge
 *   + default Node.js process metrics (memory, event loop, GC …)
 */
import { Registry, Counter, Histogram, Gauge, collectDefaultMetrics, } from 'prom-client';
// ── Registry ──────────────────────────────────────────────────────────────────
export const register = new Registry();
register.setDefaultLabels({ app: 'greenfrog' });
collectDefaultMetrics({ register, prefix: 'greenfrog_node_' });
// ── Counters ──────────────────────────────────────────────────────────────────
export const messagesTotal = new Counter({
    name: 'greenfrog_messages_total',
    help: 'Total incoming messages processed',
    labelNames: ['channel'],
    registers: [register],
});
export const skillCallsTotal = new Counter({
    name: 'greenfrog_skill_calls_total',
    help: 'Total skill invocations',
    labelNames: ['skill', 'success'],
    registers: [register],
});
export const llmTokensTotal = new Counter({
    name: 'greenfrog_llm_tokens_total',
    help: 'Total LLM tokens consumed',
    labelNames: ['provider', 'model', 'type'], // type: input | output
    registers: [register],
});
export const patrolChecksTotal = new Counter({
    name: 'greenfrog_patrol_checks_total',
    help: 'Total patrol checks executed',
    labelNames: ['status'], // ok | error | timeout
    registers: [register],
});
export const jobRunsTotal = new Counter({
    name: 'greenfrog_job_runs_total',
    help: 'Total scheduled job runs',
    labelNames: ['status'], // success | error
    registers: [register],
});
export const authAttemptsTotal = new Counter({
    name: 'greenfrog_auth_attempts_total',
    help: 'OAuth2/OIDC and Bearer auth attempts',
    labelNames: ['method', 'result'], // method: oidc|bearer|hmac  result: ok|fail
    registers: [register],
});
export const queueJobsTotal = new Counter({
    name: 'greenfrog_queue_jobs_total',
    help: 'Total BullMQ jobs enqueued/completed/failed',
    labelNames: ['queue', 'event'], // event: added|completed|failed
    registers: [register],
});
// ── Histograms ────────────────────────────────────────────────────────────────
export const skillDurationMs = new Histogram({
    name: 'greenfrog_skill_duration_ms',
    help: 'Skill execution duration in milliseconds',
    labelNames: ['skill'],
    buckets: [10, 50, 100, 250, 500, 1_000, 2_500, 5_000, 10_000, 30_000],
    registers: [register],
});
export const llmLatencyMs = new Histogram({
    name: 'greenfrog_llm_latency_ms',
    help: 'LLM API round-trip latency in milliseconds',
    labelNames: ['provider', 'model'],
    buckets: [100, 250, 500, 1_000, 2_000, 5_000, 10_000, 30_000, 60_000],
    registers: [register],
});
export const httpRequestDurationMs = new Histogram({
    name: 'greenfrog_http_request_duration_ms',
    help: 'HTTP request duration in milliseconds',
    labelNames: ['method', 'route', 'status'],
    buckets: [5, 10, 25, 50, 100, 250, 500, 1_000, 2_500],
    registers: [register],
});
// ── Gauges ────────────────────────────────────────────────────────────────────
export const wsClients = new Gauge({
    name: 'greenfrog_websocket_clients',
    help: 'Current number of authenticated WebSocket clients',
    registers: [register],
});
export const queueDepth = new Gauge({
    name: 'greenfrog_queue_depth',
    help: 'BullMQ queue waiting job count',
    labelNames: ['queue'],
    registers: [register],
});
export function httpMetricsMiddleware(req, res, next) {
    const start = Date.now();
    res.on('finish', () => {
        // Normalise dynamic route segments so cardinality stays bounded
        const route = req.route?.path ?? req.path.replace(/\/[0-9a-f-]{8,}/gi, '/:id');
        httpRequestDurationMs.observe({ method: req.method, route, status: String(res.statusCode) }, Date.now() - start);
    });
    next();
}
//# sourceMappingURL=index.js.map