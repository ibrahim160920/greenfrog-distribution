import { providerRegistry } from '../providers/index.js';
import { skillRegistry } from '../skills/registry.js';
import { memoryStore } from '../memory/store.js';
import { SkillError } from '../utils/errors.js';
import { buildContextualMemorySummaryForContext } from '../memory/index.js';
import { scheduleMemoryExtraction, checkToolResultVsMemory, auditReplyForHallucinations } from '../memory/extractor.js';
import { createLogger } from '../utils/logger.js';
import { config } from '../config/index.js';
import { getOwnerKernelSummary } from '../memory/owner_kernel.js';
import { resolveConversationAgentIdentity } from './identity.js';
import { isAgentRunCancelled } from '../runtime/agent_run_control.js';
import { touchHeartbeat } from '../runtime/agent_heartbeat.js';
import { startTrace, addTraceEvent, completeTrace } from '../runtime/execution_trace.js';
const log = createLogger('agent');
const DEFAULT_AGENT_MAX_EXECUTION_MS = 120_000;
const DEFAULT_SYSTEM_PROMPT = `You are GreenFrog, a highly capable personal AI assistant running locally on the user's device.

You have access to powerful tools to help the user:
- Search the web and fetch URLs
- Execute code (JavaScript, Python, bash)
- Manage files and directories
- Run shell commands (git, npm, system commands)
- Check weather, news, and cryptocurrency prices
- Manage notes, todos, and reminders
- Translate text between languages
- Control a web browser
- Interact with GitHub
- Create and schedule automated tasks
- Generate images
- Remember information across conversations
- **coding_agent** — autonomous coding agent that ACTUALLY writes, edits, and tests code in real files
- CREATE NEW TOOLS for yourself using the skill_creator tool!

Key traits:
- You are running locally — the user's data never leaves their machine
- You are proactive and help the user accomplish tasks efficiently
- When you need information, use your tools rather than saying you can't help
- You remember context from previous conversations
- When asked to do something complex, break it into steps and execute them
- You can create new skills to extend your own capabilities
- When the user corrects you, acknowledge it briefly (e.g. "Thanks, noted."). The correction is automatically saved and will prevent the same mistake on similar topics in future.
- **When the user asks you to write, implement, create, fix, debug, or refactor code in a file, use the \`coding_agent\` tool** — it makes real file changes. Do NOT write code only in text responses when file modifications are expected.

Always be helpful, precise, and efficient. Use tools when they can help.`;
/**
 * Detect whether a message is a coding/implementation task.
 * Used to inject a routing hint so the LLM prefers coding_agent.
 */
function detectCodingIntent(text) {
    const EN_PATTERNS = [
        /\b(write|create|implement|build|develop|code)\b.{0,50}\b(function|method|class|script|module|api|endpoint|component|feature|algorithm|library|plugin|test|tests)\b/i,
        /\b(fix|debug|patch|resolve)\b.{0,50}\b(bug|error|issue|crash|exception|problem)\b.{0,30}\b(code|file|function|script|class)\b/i,
        /\b(refactor|optimize|rewrite|update|modify|edit)\b.{0,40}\b(code|function|class|file|module|script)\b/i,
        /\badd\b.{0,30}\b(unit tests?|integration tests?|test cases?|tests?)\b/i,
        /\bimplement\b.{0,60}\b(in|using|with)\b.{0,20}\b(python|javascript|typescript|java|go|rust|c\+\+|node)\b/i,
    ];
    const ZH_PATTERNS = [
        /请?(写|编写|实现|创建|开发|编码).{0,30}(函数|方法|类|脚本|模块|组件|接口|测试|代码)/,
        /(帮(我|忙)|帮助).{0,20}(写|实现|创建|编写|开发|修复|优化|重构)/,
        /(修复|调试|解决).{0,20}(bug|错误|问题|异常|崩溃)/,
        /(重构|优化|更新|修改).{0,20}(代码|函数|类|文件|模块)/,
    ];
    return [...EN_PATTERNS, ...ZH_PATTERNS].some((p) => p.test(text));
}
const CODING_ROUTING_HINT = `\n\n[ROUTING HINT] The user's message has been classified as a coding/implementation task. You MUST use the \`coding_agent\` tool to handle it — do not write code only in your text response.`;
function resolveAgentExecutionProfile(agentDef) {
    const provider = typeof agentDef?.provider === 'string' && agentDef.provider.trim()
        ? agentDef.provider.trim()
        : typeof agentDef?.metadata?.['provider'] === 'string' && String(agentDef.metadata['provider']).trim()
            ? String(agentDef.metadata['provider']).trim()
            : undefined;
    const model = typeof agentDef?.model === 'string' && agentDef.model.trim()
        ? agentDef.model.trim()
        : typeof agentDef?.metadata?.['model'] === 'string' && String(agentDef.metadata['model']).trim()
            ? String(agentDef.metadata['model']).trim()
            : config.defaultModel;
    return { provider, model };
}
function resolveMessageExecutionProfile(msg, agentDef) {
    const base = resolveAgentExecutionProfile(agentDef);
    const providerOverride = typeof msg.metadata?.['agentProviderOverride'] === 'string' && String(msg.metadata['agentProviderOverride']).trim()
        ? String(msg.metadata['agentProviderOverride']).trim()
        : undefined;
    const modelOverride = typeof msg.metadata?.['agentModelOverride'] === 'string' && String(msg.metadata['agentModelOverride']).trim()
        ? String(msg.metadata['agentModelOverride']).trim()
        : undefined;
    return {
        provider: providerOverride ?? base.provider,
        model: modelOverride ?? base.model,
    };
}
function resolveAgentMaxIterations(msg) {
    return typeof msg.metadata?.agentMaxIterationsOverride === 'number' && msg.metadata.agentMaxIterationsOverride >= 1
        ? Math.min(Math.floor(msg.metadata.agentMaxIterationsOverride), 200)
        : config.agentMaxIterations ?? 10;
}
function resolveAgentMaxExecutionMs(msg) {
    return typeof msg.metadata?.agentExecutionTimeoutMsOverride === 'number' && msg.metadata.agentExecutionTimeoutMsOverride >= 1
        ? Math.min(Math.floor(msg.metadata.agentExecutionTimeoutMsOverride), 900_000)
        : config.agentMaxExecutionMs ?? DEFAULT_AGENT_MAX_EXECUTION_MS;
}
function buildAgentLimitMessage(kind, value) {
    if (kind === 'iterations') {
        return `Stopped after reaching the agent iteration limit (${value}).`;
    }
    return `Stopped after reaching the agent execution time budget (${value}ms).`;
}
function hasAgentTimeBudgetExpired(startedAt, maxExecutionMs) {
    return Date.now() - startedAt >= maxExecutionMs;
}
function normalizeAgentCancellationReason(value) {
    if (typeof value === 'string' && value.trim())
        return value.trim();
    if (value === true)
        return 'Cancelled by operator';
    return null;
}
function resolveAgentCancellationReason(msg) {
    const metadata = msg.metadata ?? {};
    const directReason = normalizeAgentCancellationReason(metadata['agentCancellationReason']);
    if (directReason)
        return directReason;
    const shouldCancel = metadata['agentShouldCancel'];
    if (typeof shouldCancel === 'function') {
        try {
            return normalizeAgentCancellationReason(shouldCancel());
        }
        catch (err) {
            log.debug({ err: String(err) }, 'Agent cancellation callback failed');
        }
    }
    else {
        const inlineReason = normalizeAgentCancellationReason(shouldCancel);
        if (inlineReason)
            return inlineReason;
    }
    const runId = typeof metadata['agentRunId'] === 'string' && metadata['agentRunId'].trim()
        ? metadata['agentRunId'].trim()
        : null;
    return runId ? isAgentRunCancelled(runId) : null;
}
function buildAgentCancellationMessage(reason) {
    return reason
        ? `Stopped because this run was cancelled: ${reason}`
        : 'Stopped because this run was cancelled.';
}
/**
 * Build the Owner Kernel section for agent system prompts.
 *
 * The kernel is loaded lazily (file read, not in-memory singleton) so it
 * always reflects the latest promoted state. Failures are silently suppressed
 * to avoid breaking the agent loop — the kernel is advisory context, not
 * load-bearing for tool execution.
 *
 * Mother-body invariant: the kernel section is READ-ONLY from the agent's
 * perspective. Agents may PROPOSE changes via `proposeKernelUpdate()` but
 * cannot directly modify the kernel file.
 */
function buildOwnerKernelSection() {
    try {
        const summary = getOwnerKernelSummary();
        if (!summary || summary.trim().length === 0)
            return '';
        return `\n\n${summary}`;
    }
    catch {
        return '';
    }
}
export class GreenFrogAgent {
    systemPrompt;
    constructor() {
        let prompt = config.systemPrompt ?? DEFAULT_SYSTEM_PROMPT;
        // Remove browser capability line if the skill isn't registered
        if (!skillRegistry.get('browser')) {
            prompt = prompt.replace(/^- Control a web browser\n/m, '');
        }
        this.systemPrompt = prompt;
    }
    async processMessage(msg) {
        // Start execution trace
        const runId = typeof msg.metadata?.agentRunId === 'string' && msg.metadata.agentRunId.trim()
            ? msg.metadata.agentRunId.trim()
            : `run-${Date.now()}`;
        const traceId = startTrace({
            runId,
            userId: msg.userId,
            channel: msg.channel,
            label: msg.text.slice(0, 100),
        });
        const sessionKey = typeof msg.metadata?.sessionKey === 'string' && msg.metadata.sessionKey.trim()
            ? msg.metadata.sessionKey.trim()
            : msg.chatId;
        // Get or create session
        const sessionId = await memoryStore.getOrCreateSession(msg.userId, msg.channel, sessionKey);
        // Build conversation context
        const history = await memoryStore.getHistory(sessionId, 20);
        const resolvedIdentity = await resolveConversationAgentIdentity(msg);
        const ctx = {
            sessionId,
            userId: msg.userId,
            channel: msg.channel,
            chatId: msg.chatId,
            workspaceId: resolvedIdentity.workspaceId,
            agentId: resolvedIdentity.agentId,
            history,
        };
        // Capture last AI response BEFORE adding current user message (correction context)
        const prevAiMessage = [...ctx.history].reverse().find((h) => h.role === 'assistant')?.content;
        // Add user message to history
        const userMsg = { role: 'user', content: msg.text };
        await memoryStore.addMessage(sessionId, msg.userId, msg.channel, userMsg);
        ctx.history.push(userMsg);
        // Build system prompt with contextually relevant memory (RAG)
        const memorySummary = await buildContextualMemorySummaryForContext(ctx, msg.text);
        const agentPrompt = resolvedIdentity.agent?.systemPrompt ? `\n\n${resolvedIdentity.agent.systemPrompt}` : '';
        const codingHint = detectCodingIntent(msg.text) ? CODING_ROUTING_HINT : '';
        const ownerKernelSection = buildOwnerKernelSection();
        const fullSystemPrompt = this.systemPrompt + agentPrompt + ownerKernelSection + memorySummary + codingHint;
        const executionProfile = resolveMessageExecutionProfile(msg, resolvedIdentity.agent);
        // Get AI tools
        const tools = skillRegistry.toProviderTools();
        // ── Agentic loop ──────────────────────────────────────────────────────────
        // Build the provider message list from history, filtering out 'tool' and
        // 'system' role entries (those are stored for reference but not sent directly).
        const messages = ctx.history
            .filter((h) => h.role === 'user' || h.role === 'assistant')
            .map((h) => ({ role: h.role, content: h.content }));
        // Attach image data to the last user message (the current incoming message)
        const imageAttachments = msg.attachments
            ?.filter((a) => a.type === 'image' && a.data)
            .map((a) => ({
            base64: a.data.toString('base64'),
            mimeType: a.mimeType,
        }));
        if (imageAttachments && imageAttachments.length > 0) {
            let lastUserIdx = -1;
            for (let i = messages.length - 1; i >= 0; i--) {
                if (messages[i].role === 'user') {
                    lastUserIdx = i;
                    break;
                }
            }
            if (lastUserIdx !== -1) {
                messages[lastUserIdx] = { ...messages[lastUserIdx], imageAttachments };
            }
        }
        let finalResponse = '';
        let stoppedReason = null;
        const maxIterations = resolveAgentMaxIterations(msg);
        const maxExecutionMs = resolveAgentMaxExecutionMs(msg);
        const startedAt = Date.now();
        const autoCreatedSkills = new Set(); // track auto-created skills to prevent loops
        const usageContext = {
            userId: msg.userId,
            workspaceId: ctx.workspaceId ?? null,
            agentId: ctx.agentId ?? null,
            channel: msg.channel,
            sessionKey: typeof msg.metadata?.sessionKey === 'string' ? msg.metadata.sessionKey : `chat:${sessionId}`,
        };
        try {
            iterationLoop: for (let iteration = 0; iteration < maxIterations; iteration++) {
                addTraceEvent(traceId, 'iteration_start', { iteration });
                const cancellationReason = resolveAgentCancellationReason(msg);
                if (cancellationReason) {
                    stoppedReason = buildAgentCancellationMessage(cancellationReason);
                    break;
                }
                if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                    stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                    break;
                }
                addTraceEvent(traceId, 'provider_call_start', {
                    provider: executionProfile.provider,
                    model: executionProfile.model,
                    iteration,
                });
                // Create a per-call AbortController so we can interrupt a hung provider
                // call immediately when the time budget expires OR when a cancellation is
                // signalled (polled every 500 ms — acceptable for hung-call detection).
                const callController = new AbortController();
                const remainingMs = Math.max(100, maxExecutionMs - (Date.now() - startedAt));
                const callTimeoutId = setTimeout(() => callController.abort(), remainingMs);
                const callCancellationId = setInterval(() => {
                    if (resolveAgentCancellationReason(msg))
                        callController.abort();
                }, 500);
                let response;
                try {
                    response = await providerRegistry.chatWithFallback({
                        messages,
                        tools,
                        systemPrompt: fullSystemPrompt,
                        model: executionProfile.model,
                        maxTokens: 4096,
                        temperature: 0.7,
                        usageContext,
                        signal: callController.signal,
                    }, executionProfile.provider);
                }
                catch (err) {
                    if (callController.signal.aborted) {
                        // Determine whether the abort was triggered by cancellation or timeout
                        const cancelReason = resolveAgentCancellationReason(msg);
                        stoppedReason = cancelReason
                            ? buildAgentCancellationMessage(cancelReason)
                            : buildAgentLimitMessage('time', maxExecutionMs);
                        break iterationLoop;
                    }
                    throw err;
                }
                finally {
                    clearTimeout(callTimeoutId);
                    clearInterval(callCancellationId);
                }
                addTraceEvent(traceId, 'provider_call_complete', {
                    provider: executionProfile.provider,
                    model: executionProfile.model,
                    iteration,
                    hasToolCalls: response.toolCalls && response.toolCalls.length > 0,
                    toolCallCount: response.toolCalls?.length ?? 0,
                });
                const cancellationReasonAfterProvider = resolveAgentCancellationReason(msg);
                if (cancellationReasonAfterProvider) {
                    stoppedReason = buildAgentCancellationMessage(cancellationReasonAfterProvider);
                    break;
                }
                if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                    stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                    break;
                }
                if (response.content) {
                    finalResponse = response.content;
                }
                // No tool calls → done
                if (!response.toolCalls || response.toolCalls.length === 0) {
                    break;
                }
                // Push assistant message, preserving provider-native rawContent (tool_use blocks)
                messages.push({
                    role: 'assistant',
                    content: response.content ?? '',
                    rawContent: response.rawContent,
                });
                // Execute all tool calls and collect results
                const toolResults = [];
                // Extract optional progress callback (set by web channel for UI feedback)
                const onToolCall = msg.metadata?.onToolCall;
                for (const toolCall of response.toolCalls) {
                    const cancellationReasonBeforeTool = resolveAgentCancellationReason(msg);
                    if (cancellationReasonBeforeTool) {
                        stoppedReason = buildAgentCancellationMessage(cancellationReasonBeforeTool);
                        break iterationLoop;
                    }
                    if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                        stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                        break iterationLoop;
                    }
                    log.info({ tool: toolCall.name, params: toolCall.arguments }, 'Executing skill');
                    onToolCall?.(toolCall.name);
                    addTraceEvent(traceId, 'tool_call_start', {
                        toolName: toolCall.name,
                        iteration,
                    });
                    const toolStartTime = Date.now();
                    const result = await executeSkillWithAutoCreate(toolCall.name, toolCall.arguments, ctx, autoCreatedSkills);
                    const toolDuration = Date.now() - toolStartTime;
                    const cancellationReasonAfterTool = resolveAgentCancellationReason(msg);
                    if (cancellationReasonAfterTool) {
                        stoppedReason = buildAgentCancellationMessage(cancellationReasonAfterTool);
                        break iterationLoop;
                    }
                    if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                        stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                        break iterationLoop;
                    }
                    const resultText = result.text ?? (result.error ? `Error: ${result.error}` : JSON.stringify(result.data));
                    if (result.error) {
                        addTraceEvent(traceId, 'tool_call_error', {
                            toolName: toolCall.name,
                            error: result.error,
                            durationMs: toolDuration,
                            iteration,
                        });
                    }
                    else {
                        addTraceEvent(traceId, 'tool_call_complete', {
                            toolName: toolCall.name,
                            durationMs: toolDuration,
                            iteration,
                        });
                    }
                    toolResults.push({ id: toolCall.id, name: toolCall.name, content: resultText });
                    // Check tool result against stored memory — roll back hallucinated facts (fire-and-forget)
                    setImmediate(() => {
                        checkToolResultVsMemory(msg.userId, msg.channel, toolCall.name, resultText, {
                            userId: ctx.userId,
                            channel: ctx.channel,
                            workspaceId: ctx.workspaceId,
                            agentId: ctx.agentId,
                        })
                            .catch((err) => log.debug({ err: String(err) }, 'Tool-result memory check failed (non-fatal)'));
                    });
                    // Persist tool interaction in history for future context
                    await memoryStore.addMessage(sessionId, msg.userId, msg.channel, {
                        role: 'tool',
                        content: resultText,
                        toolCallId: toolCall.id,
                        toolName: toolCall.name,
                    });
                }
                // Push a single user turn carrying all tool results.
                // Each provider translates toolResults into its native format.
                messages.push({
                    role: 'user',
                    content: '',
                    toolResults,
                });
                if (iteration === maxIterations - 1) {
                    stoppedReason = buildAgentLimitMessage('iterations', maxIterations);
                }
                addTraceEvent(traceId, 'iteration_complete', { iteration });
            }
        }
        catch (err) {
            log.error({ err: String(err) }, 'Agent error');
            completeTrace(traceId, 'error', String(err));
            touchHeartbeat('agent-loop', 'Agent Loop', msg.userId, String(err));
            return {
                text: `I encountered an error: ${String(err)}`,
                channel: msg.channel,
                chatId: msg.chatId,
                replyToId: msg.id,
            };
        }
        // Persist final assistant response
        if (!finalResponse && stoppedReason) {
            finalResponse = stoppedReason;
        }
        else if (finalResponse && stoppedReason) {
            finalResponse = `${finalResponse}\n\n[Agent runtime] ${stoppedReason}`;
        }
        if (finalResponse) {
            await memoryStore.addMessage(sessionId, msg.userId, msg.channel, {
                role: 'assistant',
                content: finalResponse,
            });
            // Auto-extract user facts + detect corrections (fire-and-forget, non-blocking)
            scheduleMemoryExtraction(msg.userId, msg.channel, msg.text, finalResponse, prevAiMessage, sessionId, {
                userId: ctx.userId,
                channel: ctx.channel,
                workspaceId: ctx.workspaceId,
                agentId: ctx.agentId,
            });
            // Audit reply for hallucinated user facts — roll back any phantom memory (fire-and-forget)
            setImmediate(() => {
                auditReplyForHallucinations(msg.userId, msg.channel, finalResponse, {
                    userId: ctx.userId,
                    channel: ctx.channel,
                    workspaceId: ctx.workspaceId,
                    agentId: ctx.agentId,
                })
                    .catch((err) => log.debug({ err: String(err) }, 'Reply hallucination audit failed (non-fatal)'));
            });
        }
        // Complete trace — distinguish cancellation from normal completion
        const nonStreamTraceFinalStatus = stoppedReason?.startsWith('Stopped because this run was cancelled')
            ? 'cancelled'
            : 'completed';
        completeTrace(traceId, nonStreamTraceFinalStatus, stoppedReason ?? undefined);
        touchHeartbeat('agent-loop', 'Agent Loop', msg.userId);
        return {
            text: finalResponse || 'I processed your request but had nothing to say.',
            channel: msg.channel,
            chatId: msg.chatId,
            replyToId: msg.id,
        };
    }
    /**
     * Streaming version of processMessage.
     *
     * Yields AgentStreamEvents:
     *   - { type: 'token', text }  — individual text deltas from the model
     *   - { type: 'thinking', tool } — a tool is about to be executed
     *   - { type: 'done', response } — stream finished, full OutgoingMessage attached
     *   - { type: 'error', error }  — an error occurred
     */
    async *processMessageStream(msg) {
        // Start execution trace — mirrors non-streaming path
        const streamRunId = typeof msg.metadata?.agentRunId === 'string' && msg.metadata.agentRunId.trim()
            ? msg.metadata.agentRunId.trim()
            : `stream-${Date.now()}`;
        const streamTraceId = startTrace({
            runId: streamRunId,
            userId: msg.userId,
            channel: msg.channel,
            label: msg.text.slice(0, 100),
        });
        const sessionKey = typeof msg.metadata?.sessionKey === 'string' && msg.metadata.sessionKey.trim()
            ? msg.metadata.sessionKey.trim()
            : msg.chatId;
        const sessionId = await memoryStore.getOrCreateSession(msg.userId, msg.channel, sessionKey);
        const streamHistory = await memoryStore.getHistory(sessionId, 20);
        const resolvedIdentity = await resolveConversationAgentIdentity(msg);
        const ctx = {
            sessionId,
            userId: msg.userId,
            channel: msg.channel,
            chatId: msg.chatId,
            workspaceId: resolvedIdentity.workspaceId,
            agentId: resolvedIdentity.agentId,
            history: streamHistory,
        };
        // Capture last AI response BEFORE adding current user message (correction context)
        const prevAiMessage = [...ctx.history].reverse().find((h) => h.role === 'assistant')?.content;
        const userMsg = { role: 'user', content: msg.text };
        await memoryStore.addMessage(sessionId, msg.userId, msg.channel, userMsg);
        ctx.history.push(userMsg);
        const memorySummary = await buildContextualMemorySummaryForContext(ctx, msg.text);
        const agentPrompt = resolvedIdentity.agent?.systemPrompt ? `\n\n${resolvedIdentity.agent.systemPrompt}` : '';
        const codingHintStream = detectCodingIntent(msg.text) ? CODING_ROUTING_HINT : '';
        const ownerKernelSectionStream = buildOwnerKernelSection();
        const fullSystemPrompt = this.systemPrompt + agentPrompt + ownerKernelSectionStream + memorySummary + codingHintStream;
        const executionProfile = resolveAgentExecutionProfile(resolvedIdentity.agent);
        const tools = skillRegistry.toProviderTools();
        const messages = ctx.history
            .filter((h) => h.role === 'user' || h.role === 'assistant')
            .map((h) => ({ role: h.role, content: h.content }));
        // Attach image data to the last user message (the current incoming message)
        const streamImageAttachments = msg.attachments
            ?.filter((a) => a.type === 'image' && a.data)
            .map((a) => ({
            base64: a.data.toString('base64'),
            mimeType: a.mimeType,
        }));
        if (streamImageAttachments && streamImageAttachments.length > 0) {
            let lastUserIdx = -1;
            for (let i = messages.length - 1; i >= 0; i--) {
                if (messages[i].role === 'user') {
                    lastUserIdx = i;
                    break;
                }
            }
            if (lastUserIdx !== -1) {
                messages[lastUserIdx] = { ...messages[lastUserIdx], imageAttachments: streamImageAttachments };
            }
        }
        let finalResponse = '';
        let stoppedReason = null;
        const maxIterations = resolveAgentMaxIterations(msg);
        const maxExecutionMs = resolveAgentMaxExecutionMs(msg);
        const startedAt = Date.now();
        const autoCreatedSkillsStream = new Set(); // track auto-created skills to prevent loops
        const streamUsageContext = {
            userId: msg.userId,
            workspaceId: ctx.workspaceId ?? null,
            agentId: ctx.agentId ?? null,
            channel: msg.channel,
            sessionKey: typeof msg.metadata?.sessionKey === 'string' ? msg.metadata.sessionKey : `chat:${sessionId}`,
        };
        try {
            iterationLoop: for (let iteration = 0; iteration < maxIterations; iteration++) {
                addTraceEvent(streamTraceId, 'iteration_start', { iteration });
                const cancellationReason = resolveAgentCancellationReason(msg);
                if (cancellationReason) {
                    stoppedReason = buildAgentCancellationMessage(cancellationReason);
                    break;
                }
                if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                    stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                    break;
                }
                const request = {
                    messages,
                    tools,
                    systemPrompt: fullSystemPrompt,
                    model: executionProfile.model,
                    maxTokens: 4096,
                    temperature: 0.7,
                    usageContext: streamUsageContext,
                };
                addTraceEvent(streamTraceId, 'provider_call_start', {
                    provider: executionProfile.provider,
                    model: executionProfile.model,
                    iteration,
                });
                const streaming = await providerRegistry.chatStreamWithFallback(request, executionProfile.provider);
                const cancellationReasonAfterProvider = resolveAgentCancellationReason(msg);
                if (cancellationReasonAfterProvider) {
                    stoppedReason = buildAgentCancellationMessage(cancellationReasonAfterProvider);
                    break;
                }
                // Stream text tokens
                let tokenBuffer = '';
                for await (const token of streaming.textStream) {
                    const cancellationReasonDuringStream = resolveAgentCancellationReason(msg);
                    if (cancellationReasonDuringStream) {
                        stoppedReason = buildAgentCancellationMessage(cancellationReasonDuringStream);
                        break;
                    }
                    tokenBuffer += token;
                    yield { type: 'token', text: token };
                }
                if (stoppedReason) {
                    if (tokenBuffer)
                        finalResponse = tokenBuffer;
                    break;
                }
                // Collect full response (includes tool calls)
                const response = await streaming.complete();
                addTraceEvent(streamTraceId, 'provider_call_complete', {
                    provider: executionProfile.provider,
                    model: executionProfile.model,
                    iteration,
                    hasToolCalls: !!(response.toolCalls?.length),
                    toolCallCount: response.toolCalls?.length ?? 0,
                });
                const cancellationReasonAfterComplete = resolveAgentCancellationReason(msg);
                if (cancellationReasonAfterComplete) {
                    stoppedReason = buildAgentCancellationMessage(cancellationReasonAfterComplete);
                    if (tokenBuffer)
                        finalResponse = tokenBuffer;
                    break;
                }
                if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                    stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                    break;
                }
                if (response.content)
                    finalResponse = response.content;
                else if (tokenBuffer)
                    finalResponse = tokenBuffer;
                if (!response.toolCalls || response.toolCalls.length === 0)
                    break;
                // Thread assistant message
                messages.push({
                    role: 'assistant',
                    content: response.content ?? '',
                    rawContent: response.rawContent,
                });
                // Execute tool calls
                const toolResults = [];
                for (const toolCall of response.toolCalls) {
                    const cancellationReasonBeforeTool = resolveAgentCancellationReason(msg);
                    if (cancellationReasonBeforeTool) {
                        stoppedReason = buildAgentCancellationMessage(cancellationReasonBeforeTool);
                        break iterationLoop;
                    }
                    if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                        stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                        break iterationLoop;
                    }
                    log.info({ tool: toolCall.name }, 'Executing skill (stream)');
                    yield { type: 'thinking', tool: toolCall.name };
                    addTraceEvent(streamTraceId, 'tool_call_start', { toolName: toolCall.name, iteration });
                    const streamToolStartTime = Date.now();
                    const result = await executeSkillWithAutoCreate(toolCall.name, toolCall.arguments, ctx, autoCreatedSkillsStream);
                    const streamToolDuration = Date.now() - streamToolStartTime;
                    const cancellationReasonAfterTool = resolveAgentCancellationReason(msg);
                    if (cancellationReasonAfterTool) {
                        stoppedReason = buildAgentCancellationMessage(cancellationReasonAfterTool);
                        break iterationLoop;
                    }
                    if (hasAgentTimeBudgetExpired(startedAt, maxExecutionMs)) {
                        stoppedReason = buildAgentLimitMessage('time', maxExecutionMs);
                        break iterationLoop;
                    }
                    const resultText = result.text ?? (result.error ? `Error: ${result.error}` : JSON.stringify(result.data));
                    if (result.error) {
                        addTraceEvent(streamTraceId, 'tool_call_error', { toolName: toolCall.name, error: result.error, durationMs: streamToolDuration, iteration });
                    }
                    else {
                        addTraceEvent(streamTraceId, 'tool_call_complete', { toolName: toolCall.name, durationMs: streamToolDuration, iteration });
                    }
                    toolResults.push({ id: toolCall.id, name: toolCall.name, content: resultText });
                    // Check tool result against stored memory — roll back hallucinated facts (fire-and-forget)
                    setImmediate(() => {
                        checkToolResultVsMemory(msg.userId, msg.channel, toolCall.name, resultText, {
                            userId: ctx.userId,
                            channel: ctx.channel,
                            workspaceId: ctx.workspaceId,
                            agentId: ctx.agentId,
                        })
                            .catch((err) => log.debug({ err: String(err) }, 'Tool-result memory check failed (non-fatal)'));
                    });
                    await memoryStore.addMessage(sessionId, msg.userId, msg.channel, {
                        role: 'tool',
                        content: resultText,
                        toolCallId: toolCall.id,
                        toolName: toolCall.name,
                    });
                }
                messages.push({ role: 'user', content: '', toolResults });
                if (iteration === maxIterations - 1) {
                    stoppedReason = buildAgentLimitMessage('iterations', maxIterations);
                }
                addTraceEvent(streamTraceId, 'iteration_complete', { iteration });
            }
            if (!finalResponse && stoppedReason) {
                finalResponse = stoppedReason;
            }
            else if (finalResponse && stoppedReason) {
                finalResponse = `${finalResponse}\n\n[Agent runtime] ${stoppedReason}`;
            }
            if (finalResponse) {
                await memoryStore.addMessage(sessionId, msg.userId, msg.channel, {
                    role: 'assistant',
                    content: finalResponse,
                });
                // Auto-extract user facts + detect corrections (fire-and-forget, non-blocking)
                scheduleMemoryExtraction(msg.userId, msg.channel, msg.text, finalResponse, prevAiMessage, sessionId, {
                    userId: ctx.userId,
                    channel: ctx.channel,
                    workspaceId: ctx.workspaceId,
                    agentId: ctx.agentId,
                });
                // Audit reply for hallucinated user facts — roll back any phantom memory (fire-and-forget)
                setImmediate(() => {
                    auditReplyForHallucinations(msg.userId, msg.channel, finalResponse, {
                        userId: ctx.userId,
                        channel: ctx.channel,
                        workspaceId: ctx.workspaceId,
                        agentId: ctx.agentId,
                    })
                        .catch((err) => log.debug({ err: String(err) }, 'Reply hallucination audit failed (non-fatal)'));
                });
            }
            const outgoing = {
                text: finalResponse || 'I processed your request but had nothing to say.',
                channel: msg.channel,
                chatId: msg.chatId,
                replyToId: msg.id,
            };
            const streamTraceFinalStatus = stoppedReason?.startsWith('Stopped because this run was cancelled')
                ? 'cancelled'
                : 'completed';
            completeTrace(streamTraceId, streamTraceFinalStatus, stoppedReason ?? undefined);
            touchHeartbeat('agent-loop', 'Agent Loop', msg.userId);
            yield { type: 'done', response: outgoing };
        }
        catch (err) {
            completeTrace(streamTraceId, 'error', String(err));
            touchHeartbeat('agent-loop', 'Agent Loop', msg.userId, String(err));
            yield { type: 'error', error: String(err) };
        }
    }
    async clearHistory(userId, channel, chatId) {
        const sessionId = await memoryStore.getOrCreateSession(userId, channel, chatId);
        await memoryStore.clearHistory(sessionId);
    }
}
export const agent = new GreenFrogAgent();
// ── Auto-skill helper ─────────────────────────────────────────────────────────
//
// Wraps skillRegistry.call() with a one-shot auto-creation fallback:
// If the skill is not found, call skill_creator to generate + register it,
// wait for chokidar hot-reload, then retry once.
// `autoCreated` is a Set<string> scoped per agent run — prevents infinite loops.
async function executeSkillWithAutoCreate(skillName, args, ctx, autoCreated) {
    try {
        return await skillRegistry.call(skillName, args, ctx);
    }
    catch (err) {
        if (!(err instanceof SkillError) || !String(err.message).includes('not found')) {
            // Not a missing-skill error — surface as a result error, don't rethrow.
            return { success: false, error: String(err) };
        }
        if (autoCreated.has(skillName)) {
            // Already tried once this run — abort to prevent loop.
            return {
                success: false,
                error: `Skill "${skillName}" not found. Auto-creation already attempted once this run — aborting to prevent a loop.`,
            };
        }
        autoCreated.add(skillName);
        log.info({ skillName }, 'Skill not found — attempting auto-creation via skill_creator');
        // Ask skill_creator to generate and register the missing skill.
        const creationResult = await skillRegistry.call('skill_creator', {
            action: 'create',
            name: skillName,
            description: `Auto-created to handle: "${skillName}". ` +
                `Arguments hint: ${JSON.stringify(args).slice(0, 300)}`,
        }, ctx);
        if (!creationResult.success) {
            return {
                success: false,
                error: `Skill "${skillName}" not found. Auto-creation failed: ${creationResult.error ?? 'unknown'}`,
            };
        }
        // Wait for chokidar to stabilise and hot-load the new skill file.
        await new Promise((r) => setTimeout(r, 700));
        // Retry the original call once.
        try {
            const retryResult = await skillRegistry.call(skillName, args, ctx);
            log.info({ skillName }, 'Auto-created skill successfully executed on retry');
            // Annotate the result so the user knows a new skill was created.
            const notice = `[✓ 新技能 \`${skillName}\` 已自动创建并注册]\n\n`;
            return {
                ...retryResult,
                text: retryResult.text ? notice + retryResult.text : (retryResult.success ? notice.trim() : retryResult.text),
            };
        }
        catch (retryErr) {
            return {
                success: false,
                error: `Skill "${skillName}" was auto-created but failed on retry: ${String(retryErr)}`,
            };
        }
    }
}
//# sourceMappingURL=agent.js.map