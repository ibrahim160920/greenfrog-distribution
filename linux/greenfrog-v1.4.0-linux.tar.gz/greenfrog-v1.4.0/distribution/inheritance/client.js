/**
 * client.ts — Inheritance pull client.
 *
 * Pull model: child polls the mother-body distribution server for inheritance
 * bundles. Only bundles tagged bundleType='mother_promoted' are accepted.
 *
 * Flow:
 *   1. GET /api/distribution/inheritance/latest → manifest
 *   2. Verify manifest signature (Ed25519)
 *   3. Check compatibility (semver constraint)
 *   4. Download bundle (URL from manifest)
 *   5. Verify bundle hash
 *   6. Archive current bundle as "previous" (for rollback)
 *   7. Apply: write to .greenfrog/inheritance/current.json
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { createLogger } from '../../utils/logger.js';
import { loadCredential } from '../identity/credential.js';
import { validateManifest } from './manifest.js';
import { verifyManifestSignature, verifyBundleHash } from './verifier.js';
const log = createLogger('inheritance-client');
function getInheritanceDir(baseDir) {
    const root = baseDir ?? path.join(os.homedir(), '.greenfrog');
    return path.join(root, 'inheritance');
}
function getConfigPath(baseDir) {
    return path.join(getInheritanceDir(baseDir), 'config.json');
}
function getCurrentBundlePath(baseDir) {
    return path.join(getInheritanceDir(baseDir), 'current.json');
}
function getPreviousBundlePath(baseDir) {
    return path.join(getInheritanceDir(baseDir), 'previous', 'bundle.json');
}
export function readInheritanceConfig(baseDir) {
    const configPath = getConfigPath(baseDir);
    if (!fs.existsSync(configPath))
        return { mode: 'stable' };
    try {
        return JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    }
    catch {
        return { mode: 'stable' };
    }
}
export function writeInheritanceConfig(config, baseDir) {
    const configPath = getConfigPath(baseDir);
    fs.mkdirSync(path.dirname(configPath), { recursive: true });
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');
}
// ── Compatibility check ────────────────────────────────────────────────────────
/**
 * Minimal semver compat check: constraint is ">=X.Y.Z <A.B.C".
 * Uses a simple range parser — not a full semver library to avoid deps.
 */
function parseVersion(v) {
    const parts = v.replace(/[^0-9.]/g, '').split('.').map(Number);
    return [parts[0] ?? 0, parts[1] ?? 0, parts[2] ?? 0];
}
function versionGte(a, b) {
    for (let i = 0; i < 3; i++) {
        if ((a[i] ?? 0) > (b[i] ?? 0))
            return true;
        if ((a[i] ?? 0) < (b[i] ?? 0))
            return false;
    }
    return true;
}
function versionLt(a, b) {
    return !versionGte(a, b);
}
export function checkCompatibility(constraint, currentVersion) {
    // Parse constraint like ">=1.0.0 <2.0.0"
    const gteMatch = constraint.match(/>=(\S+)/);
    const ltMatch = constraint.match(/<(\S+)/);
    const current = parseVersion(currentVersion);
    if (gteMatch?.[1]) {
        if (!versionGte(current, parseVersion(gteMatch[1])))
            return false;
    }
    if (ltMatch?.[1]) {
        if (!versionLt(current, parseVersion(ltMatch[1])))
            return false;
    }
    return true;
}
/**
 * Pull and apply the latest inheritance bundle from the mother-body.
 * No-op if inheritance is disabled, already up to date, or not enrolled.
 */
export async function pullInheritance(opts) {
    const { distributionUrl, currentVersion, baseDir, publicKeyPath } = opts;
    const fetchFn = opts.fetchFn ?? globalThis.fetch;
    // Check mode
    const config = readInheritanceConfig(baseDir);
    if (config.mode === 'disabled') {
        return { ok: true, applied: false, skippedReason: 'inheritance disabled' };
    }
    // Require credential
    const credential = loadCredential(baseDir);
    if (!credential?.jwt) {
        return { ok: false, error: 'not enrolled — credential missing' };
    }
    // Fetch latest manifest
    const manifestUrl = `${distributionUrl}/api/distribution/inheritance/latest?currentVersion=${encodeURIComponent(currentVersion)}`;
    let manifest;
    try {
        const response = await fetchFn(manifestUrl, {
            headers: { 'Authorization': `Bearer ${credential.jwt}` },
        });
        if (!response.ok) {
            return { ok: false, error: `manifest fetch failed: HTTP ${response.status}` };
        }
        const body = await response.json();
        if (body.noUpdate) {
            return { ok: true, applied: false, skippedReason: 'already up to date' };
        }
        if (!body.manifest || !validateManifest(body.manifest)) {
            return { ok: false, error: 'invalid manifest structure' };
        }
        manifest = body.manifest;
    }
    catch (err) {
        return { ok: false, error: `manifest fetch threw: ${String(err)}` };
    }
    // Verify signature
    const sigResult = verifyManifestSignature(manifest, publicKeyPath);
    if (!sigResult.ok) {
        log.warn({ reason: sigResult.reason }, 'inheritance-client: manifest signature invalid');
        return { ok: false, error: `signature verification failed: ${sigResult.reason}` };
    }
    // Compatibility check
    if (!checkCompatibility(manifest.compatibilityConstraint, currentVersion)) {
        log.warn({ constraint: manifest.compatibilityConstraint, currentVersion }, 'inheritance-client: compatibility check failed');
        return { ok: false, error: `incompatible: ${manifest.compatibilityConstraint} vs ${currentVersion}` };
    }
    // Already applied this version?
    if (config.lastAppliedVersion === manifest.version) {
        return { ok: true, applied: false, skippedReason: 'already at this version' };
    }
    // Download bundle
    let bundleContent;
    try {
        const dlResponse = await fetchFn(manifest.downloadUrl, {
            headers: { 'Authorization': `Bearer ${credential.jwt}` },
        });
        if (!dlResponse.ok) {
            return { ok: false, error: `bundle download failed: HTTP ${dlResponse.status}` };
        }
        bundleContent = Buffer.from(await dlResponse.arrayBuffer());
    }
    catch (err) {
        return { ok: false, error: `bundle download threw: ${String(err)}` };
    }
    // Verify bundle hash
    const hashResult = verifyBundleHash(bundleContent, manifest);
    if (!hashResult.ok) {
        return { ok: false, error: hashResult.reason };
    }
    // Archive current bundle as previous (rollback support)
    const currentPath = getCurrentBundlePath(baseDir);
    if (fs.existsSync(currentPath)) {
        const prevPath = getPreviousBundlePath(baseDir);
        fs.mkdirSync(path.dirname(prevPath), { recursive: true });
        fs.copyFileSync(currentPath, prevPath);
    }
    // Apply: write new bundle
    const inheritanceDir = getInheritanceDir(baseDir);
    fs.mkdirSync(inheritanceDir, { recursive: true });
    fs.writeFileSync(currentPath, bundleContent);
    // Update config
    writeInheritanceConfig({
        ...config,
        lastAppliedVersion: manifest.version,
        lastAppliedAt: new Date().toISOString(),
    }, baseDir);
    log.info({ version: manifest.version, releaseId: manifest.releaseId }, 'inheritance-client: bundle applied');
    return { ok: true, applied: true, version: manifest.version };
}
/**
 * Roll back to the previous inheritance bundle.
 * Returns false if no previous bundle exists.
 */
export function rollbackInheritance(baseDir) {
    const prevPath = getPreviousBundlePath(baseDir);
    const currentPath = getCurrentBundlePath(baseDir);
    if (!fs.existsSync(prevPath))
        return false;
    fs.copyFileSync(prevPath, currentPath);
    fs.rmSync(prevPath);
    log.warn('inheritance-client: rolled back to previous bundle');
    return true;
}
//# sourceMappingURL=client.js.map