import { chromium } from 'playwright';
import { createLogger } from '../utils/logger.js';
import { BaseSkill } from '../skills/base.js';
const log = createLogger('browser');
class BrowserManager {
    browser = null;
    context = null;
    page = null;
    async launch() {
        if (this.browser?.isConnected())
            return;
        log.info('Launching browser...');
        this.browser = await chromium.launch({
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
            ],
        });
        this.context = await this.browser.newContext({
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            viewport: { width: 1280, height: 720 },
        });
        this.page = await this.context.newPage();
        log.info('Browser launched');
    }
    async getPage() {
        await this.launch();
        return this.page;
    }
    async navigate(url) {
        const page = await this.getPage();
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    }
    async screenshot(path) {
        const page = await this.getPage();
        const buf = await page.screenshot({ type: 'png', fullPage: false });
        return buf;
    }
    async getContent() {
        const page = await this.getPage();
        return page.evaluate(() => document.body.innerText);
    }
    async getTitle() {
        const page = await this.getPage();
        return page.title();
    }
    async getCurrentUrl() {
        const page = await this.getPage();
        return page.url();
    }
    async click(selector) {
        const page = await this.getPage();
        await page.click(selector, { timeout: 10000 });
    }
    async type(selector, text) {
        const page = await this.getPage();
        await page.fill(selector, text);
    }
    async evaluate(script) {
        const page = await this.getPage();
        return page.evaluate(script);
    }
    /**
     * Execute a script in a fully isolated BrowserContext.
     *
     * Security guarantees (defence-in-depth):
     *  1. Fresh BrowserContext — completely isolated from the main session's
     *     cookies, localStorage, IndexedDB, and service workers.
     *  2. Network封锁 via context.route() — ALL requests are aborted at the
     *     network layer, including fetch/XHR/WebSocket upgrade frames.
     *     This is enforced by the browser process, not bypassable from JS.
     *  3. addInitScript with Object.defineProperty(writable:false, configurable:false)
     *     — prevents script from restoring globals via `window.fetch = realFetch`.
     *     Unlike `var fetch = undefined`, defineProperty with these flags is
     *     permanent and survives prototype-chain introspection attempts.
     *  4. 30-second timeout kills runaway scripts.
     *  5. finally block guarantees page + context are always closed.
     */
    async evaluateSandboxed(script) {
        await this.launch(); // ensure browser is running
        const evalContext = await this.browser.newContext({
            javaScriptEnabled: true,
            serviceWorkers: 'block',
        });
        // Block ALL network at the context level — cannot be bypassed from JS
        await evalContext.route('**/*', (route) => route.abort('blockedbyclient'));
        const evalPage = await evalContext.newPage();
        // Overwrite sensitive globals before any user code runs.
        // configurable:false + writable:false means window.fetch = anything
        // will silently fail (strict mode: throws), and delete window.fetch fails.
        await evalPage.addInitScript(() => {
            const LOCKED_GLOBALS = [
                'fetch', 'XMLHttpRequest', 'WebSocket', 'EventSource',
                'SharedWorker', 'Worker', 'ServiceWorkerContainer',
                'localStorage', 'sessionStorage', 'indexedDB', 'caches',
                'crypto', // subtle crypto for key derivation
                'eval',
                'performance', // timing side-channel
                'navigator', // device info / geolocation / credentials
                'Atomics', // SAB-based timing attacks
                'SharedArrayBuffer', // cross-origin timing
                'BroadcastChannel', // cross-context messaging
                'crossOriginIsolated',
            ];
            for (const key of LOCKED_GLOBALS) {
                try {
                    Object.defineProperty(window, key, {
                        value: undefined,
                        writable: false,
                        configurable: false,
                    });
                }
                catch {
                    // Some properties may already be non-configurable on certain browser versions
                }
            }
            // Also lock Function constructor to prevent `new Function('return fetch')()`
            try {
                Object.defineProperty(window, 'Function', {
                    value: class SafeFunction {
                        constructor() {
                            throw new Error('Function constructor is disabled in sandbox');
                        }
                    },
                    writable: false,
                    configurable: false,
                });
            }
            catch { /* ignore */ }
        });
        try {
            const result = await Promise.race([
                evalPage.evaluate(script),
                new Promise((_, reject) => setTimeout(() => reject(new Error('Evaluation timeout (30s)')), 30_000)),
            ]);
            return result;
        }
        finally {
            await evalPage.close().catch(() => { });
            await evalContext.close().catch(() => { });
        }
    }
    async close() {
        await this.browser?.close();
        this.browser = null;
        this.context = null;
        this.page = null;
    }
}
export const browserManager = new BrowserManager();
// ── Browser Control Skill ────────────────────────────────────────────────────
export class BrowserSkill extends BaseSkill {
    definition = {
        name: 'browser',
        description: 'Control a web browser: navigate to URLs, take screenshots, click elements, fill forms, extract content',
        category: 'automation',
        parameters: [
            {
                name: 'action',
                type: 'string',
                required: true,
                description: 'Browser action',
                enum: ['navigate', 'screenshot', 'get_content', 'click', 'type', 'evaluate', 'get_url', 'go_back'],
            },
            { name: 'url', type: 'string', description: 'URL to navigate to (for navigate action)' },
            { name: 'selector', type: 'string', description: 'CSS selector (for click/type actions)' },
            { name: 'text', type: 'string', description: 'Text to type (for type action)' },
            { name: 'script', type: 'string', description: 'JavaScript to evaluate (for evaluate action)' },
            { name: 'max_chars', type: 'number', description: 'Max characters for content extraction', default: 3000 },
        ],
    };
    async execute(params, _ctx) {
        try {
            switch (params.action) {
                case 'navigate': {
                    if (!params.url)
                        return this.err('url is required');
                    const url = params.url;
                    if (!/^https?:\/\//i.test(url)) {
                        return this.err('Only http:// and https:// URLs are allowed for browser navigation.');
                    }
                    await browserManager.navigate(url);
                    const title = await browserManager.getTitle();
                    return this.text(`🌐 **Navigated to:** ${url}\n📄 **Title:** ${title}`);
                }
                case 'screenshot': {
                    const buf = await browserManager.screenshot();
                    const url = await browserManager.getCurrentUrl();
                    const title = await browserManager.getTitle();
                    // Return as base64 for display
                    const base64 = buf.toString('base64');
                    return {
                        success: true,
                        text: `📸 **Screenshot taken**\n🌐 ${url}\n📄 ${title}`,
                        data: { base64, mimeType: 'image/png' },
                    };
                }
                case 'get_content': {
                    const maxChars = params.max_chars ?? 3000;
                    const content = await browserManager.getContent();
                    const url = await browserManager.getCurrentUrl();
                    const title = await browserManager.getTitle();
                    return this.text(`📄 **${title}**\n🌐 ${url}\n\n${content.slice(0, maxChars)}${content.length > maxChars ? '\n...(truncated)' : ''}`);
                }
                case 'click': {
                    if (!params.selector)
                        return this.err('selector is required');
                    await browserManager.click(params.selector);
                    return this.text(`✅ Clicked: ${params.selector}`);
                }
                case 'type': {
                    if (!params.selector || !params.text)
                        return this.err('selector and text are required');
                    await browserManager.type(params.selector, params.text);
                    return this.text(`✅ Typed into ${params.selector}`);
                }
                case 'evaluate': {
                    if (!params.script)
                        return this.err('script is required');
                    const userScript = params.script;
                    // First-line heuristic block: reject obviously dangerous patterns
                    // (defence-in-depth — the sandbox below is the real protection)
                    const BLOCKED_PATTERNS = [
                        /\bdocument\.cookie\b/i,
                        /\bnavigator\.credentials\b/i,
                        /\bimportScripts\b/i,
                        /process\.env\b/i,
                        /require\s*\(/i,
                    ];
                    for (const p of BLOCKED_PATTERNS) {
                        if (p.test(userScript)) {
                            return this.err(`Script blocked: contains a restricted pattern (${p.source}). ` +
                                `The evaluate action is limited to DOM inspection. ` +
                                `Use get_content to extract page text instead.`);
                        }
                    }
                    // Execute in fully isolated sandbox context:
                    //   • Fresh BrowserContext (separate cookies/storage/SW)
                    //   • All network requests blocked at network layer
                    //   • Sensitive globals locked via Object.defineProperty
                    const result = await browserManager.evaluateSandboxed(userScript);
                    return this.text(`**Script result:**\n\`\`\`json\n${JSON.stringify(result, null, 2)}\n\`\`\``);
                }
                case 'get_url': {
                    const url = await browserManager.getCurrentUrl();
                    return this.text(`🌐 Current URL: ${url}`);
                }
                case 'go_back': {
                    const page = await browserManager.getPage();
                    await page.goBack();
                    const url = await browserManager.getCurrentUrl();
                    return this.text(`⬅️ Navigated back to: ${url}`);
                }
                default:
                    return this.err(`Unknown action: ${params.action}`);
            }
        }
        catch (err) {
            return this.err(`Browser error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=index.js.map