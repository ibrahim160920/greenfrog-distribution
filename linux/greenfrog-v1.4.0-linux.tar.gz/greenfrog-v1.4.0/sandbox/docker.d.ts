import type { SkillCallResult } from '../utils/types.js';
export declare const SANDBOX_IMAGE = "greenfrog-sandbox:latest";
interface RunOpts {
    image?: string;
    command: string[];
    env?: Record<string, string>;
    binds?: string[];
    timeoutMs: number;
    memoryMb?: number;
    cpuLimit?: number;
    pidsLimit?: number;
    networkDisabled?: boolean;
}
interface RunResult {
    stdout: string;
    stderr: string;
    exitCode: number;
}
export declare class DockerSandbox {
    private docker;
    private _available;
    private _healthTimer;
    constructor();
    /**
     * Ping the Docker daemon and cache the result.
     * The first call performs a blocking ping; subsequent calls return the cached
     * value which is refreshed every 30 s by the background health monitor.
     */
    isAvailable(): Promise<boolean>;
    /** Internal probe — updates _available and logs state transitions. */
    private _probe;
    /**
     * Start a background health monitor that re-probes the Docker daemon every
     * `intervalMs` milliseconds (default 30 s). Call once at startup.
     * Safe to call multiple times — only one timer runs at a time.
     */
    startHealthMonitor(intervalMs?: number): void;
    /** Stop the background health monitor (called during graceful shutdown). */
    stopHealthMonitor(): void;
    /**
     * Returns a warning message when Docker is unavailable and execution would
     * fall back to the process/thread sandbox, or null when Docker is available.
     * Callers use this together with `config.sandbox.fallbackPolicy` to decide
     * whether to proceed, warn, or deny.
     */
    getFallbackWarning(): string | null;
    /**
     * Build the sandbox image if it does not already exist.
     * Called once at startup; non-blocking (fire-and-forget from index.ts).
     */
    ensureImage(image?: string): Promise<void>;
    private buildImage;
    /** Core container executor. */
    run(opts: RunOpts): Promise<RunResult>;
    /**
     * Run JavaScript, Python, or Bash code in an isolated container.
     * Returns formatted output string (same shape as the existing subprocess path).
     */
    runCode(language: string, code: string, timeoutMs: number): Promise<string>;
    /**
     * Run a shell command in an isolated container.
     * The command runs inside bash; the working directory is NOT mounted — the
     * container has a clean read-only filesystem.  Useful for command output
     * that doesn't depend on local project files.
     *
     * For commands that DO need host filesystem access (e.g. git, npm in a
     * project directory), we bind-mount the working directory read-only.
     */
    runShell(command: string, workingDir: string | undefined, timeoutMs: number): Promise<string>;
    /**
     * Run a custom skill file in an isolated container.
     * The skill file is bind-mounted read-only; the BaseSkill stub is pre-baked
     * into the image at /sandbox/skills/base.js.
     */
    runCustomSkill(filePath: string, params: Record<string, unknown>, ctxSafe: Record<string, unknown>, timeoutMs: number): Promise<SkillCallResult>;
}
export declare const dockerSandbox: DockerSandbox;
export {};
//# sourceMappingURL=docker.d.ts.map