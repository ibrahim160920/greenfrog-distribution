import { BaseSkill } from './base.js';
import type { ConversationContext, IncomingMessage, SkillCallResult, SkillDefinition, TeamNotification, TeamOnCallRotation, TeamPolicy, TeamTask, TeamTaskApproval, TeamTemplate } from '../utils/types.js';
export type TeamTemplateVariableValues = Record<string, string>;
export declare function buildDefaultTeamPolicy(workspaceId: string, updatedBy?: string): TeamPolicy;
export declare function parseTeamTemplateVariableDefinitions(value: unknown): TeamTemplate['variables'] | undefined;
export declare function parseTeamTemplateVariableValues(value: unknown): TeamTemplateVariableValues | undefined;
export declare function interpolateTeamTemplateString(value: string | null | undefined, variables: TeamTemplateVariableValues): string | null | undefined;
export declare function resolveTeamTemplateVariables(template: Pick<TeamTemplate, 'variables'>, provided?: Record<string, unknown> | null): TeamTemplateVariableValues;
export declare function canUserResolveTeamApproval(approval: Pick<TeamTaskApproval, 'requestedForUserId'>, actorUserId?: string | null): boolean;
export declare function isTeamTaskReady(task: TeamTask): Promise<boolean>;
export declare function buildTeamSharedMemoryVersionKey(key: string): string;
export declare function isTeamSharedMemoryMetaKey(key: string): boolean;
type TeamSharedMemoryWriteResult = {
    conflictDetected: boolean;
    versionConflict: boolean;
    applied: boolean;
    currentVersion: number;
    nextVersion: number;
    unauthorized: boolean;
    authorityPrefix: string | null;
    approvalRequired: boolean;
};
type TeamSharedMemoryRollbackResult = {
    ok: boolean;
    applied: boolean;
    unauthorized: boolean;
    currentVersion: number;
    nextVersion: number;
    historyId: string | null;
    key: string;
    value: string | null;
    authorityPrefix: string | null;
    approvalRequired: boolean;
};
type SharedMemoryAuthorityOverride = {
    approvalId: string;
    approvedByUserId: string;
};
export declare function resolveApprovalEscalationRecipient(task: TeamTask, approval: TeamTaskApproval, policy: TeamPolicy): string | null;
export declare function resolveOnCallAgentId(rotation: TeamOnCallRotation, level: 'primary' | 'secondary', at?: number): string | null;
export declare function resolveNextOnCallAgentId(rotation: TeamOnCallRotation, level: 'primary' | 'secondary', activeAgentIds: Iterable<string>, currentAgentId?: string | null, at?: number): string | null;
export declare function isTeamNotificationRetryDue(notification: TeamNotification, now?: number): boolean;
export declare function doesNotificationRouteMatch(route: {
    metadata?: Record<string, unknown>;
}, notification: TeamNotification): boolean;
export declare function deliverTeamNotification(notification: TeamNotification): Promise<TeamNotification>;
export declare function retryPendingTeamNotifications(limit?: number): Promise<number>;
export declare function writeTeamSharedMemoryEntry(params: {
    workspaceId: string;
    userId: string;
    channel: IncomingMessage['channel'];
    key: string;
    value: string;
    actorUserId: string;
    actorAgentId?: string | null;
    expectedVersion?: number | null;
    conflictTaskId?: string | null;
    conflictRecipientUserId?: string | null;
    conflictRecipientAgentId?: string | null;
    conflictTitle?: string;
    authorityOverride?: SharedMemoryAuthorityOverride | null;
}): Promise<TeamSharedMemoryWriteResult>;
export declare function rollbackTeamSharedMemoryEntry(params: {
    workspaceId: string;
    userId: string;
    channel: IncomingMessage['channel'];
    key: string;
    actorUserId: string;
    actorAgentId?: string | null;
    historyId?: string | null;
    reason?: string | null;
    conflictTaskId?: string | null;
    conflictRecipientUserId?: string | null;
    conflictRecipientAgentId?: string | null;
    conflictTitle?: string;
    authorityOverride?: SharedMemoryAuthorityOverride | null;
}): Promise<TeamSharedMemoryRollbackResult>;
export declare function retrySharedMemoryGovernanceTaskById(taskId: string, actorUserId?: string | null): Promise<{
    ok: boolean;
    task: TeamTask | null;
    error?: string | null;
}>;
export declare function resolveTeamApprovalById(approvalId: string, decision: 'approve' | 'reject', notes?: string | null, actorUserId?: string | null, opts?: {
    bypassActorCheck?: boolean;
}): Promise<{
    approvalUpdated: boolean;
    task: TeamTask | null;
}>;
export declare function instantiateTeamTemplateById(templateId: string, ctx: ConversationContext, overrides?: {
    humanOwnerUserId?: string | null;
    variables?: Record<string, unknown> | null;
    topologyId?: string;
    topologyName?: string;
    workerAgentIds?: string[];
    supervisorAgentId?: string | null;
}): Promise<TeamTask[]>;
export declare function instantiateTeamTopologyById(topologyId: string, ctx: ConversationContext, overrides?: {
    humanOwnerUserId?: string | null;
    variables?: Record<string, unknown> | null;
    templateIds?: string[];
    workerAgentIds?: string[];
    supervisorAgentId?: string | null;
}): Promise<TeamTask[]>;
export declare function dispatchTeamTaskById(taskId: string, promptOverride?: string, policyOverride?: TeamPolicy, options?: {
    runId?: string;
}): Promise<TeamTask | null>;
export declare function claimTeamTaskById(taskId: string, agentId: string, actorUserId?: string): Promise<TeamTask | null>;
export declare function raiseTeamTaskChallengeById(params: {
    taskId: string;
    challengerAgentId: string;
    summary: string;
    threadId?: string;
}): Promise<TeamTask | null>;
export declare function requestTeamTaskConsensusById(params: {
    taskId: string;
    requesterAgentId: string;
    summary: string;
    participantAgentIds?: string[];
    participantWeights?: Record<string, number>;
    protocolMetadata?: Record<string, unknown>;
    threadId?: string;
    requestKey?: string;
}): Promise<TeamTask | null>;
export declare function reviewTeamTaskById(taskId: string, policyOverride?: TeamPolicy): Promise<TeamTask | null>;
export declare function processTeamSwarmProtocol(workspaceId?: string): Promise<number>;
export declare function processOnCallTaskHandoffs(workspaceId?: string): Promise<number>;
export declare function processReadyTeamTasks(workspaceId?: string, 
/** When set, only tasks with one of these priorities are processed (fast-path for critical/high). */
priorityFilter?: Array<TeamTask['priority']>): Promise<number>;
export declare function processPendingTeamApprovals(workspaceId?: string): Promise<number>;
export declare class TeamSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    private planGoal;
    private createTask;
    private listTasks;
    private assignTask;
    private claimTask;
    private raiseChallenge;
    private requestConsensus;
    private updateTask;
    private dispatchTask;
    private reviewTask;
    private runSupervisor;
    private getPolicy;
    private setPolicy;
    private listSharedMemory;
    private listRuleLibrary;
    private listRuleLibraryHistory;
    private listRuleLibraryCandidates;
    private promoteRuleToLibrary;
    private removeRuleFromLibrary;
    private rollbackRuleLibrary;
    private promoteMemory;
    private rollbackMemory;
    private listMailbox;
    private sendMail;
    private ackMail;
    private listApprovals;
    private resolveApproval;
    private listNotificationRoutes;
    private saveNotificationRoute;
    private listOnCallRotations;
    private saveOnCallRotation;
    private listTemplates;
    private saveTemplate;
    private instantiateTemplate;
    private listTopologies;
    private saveTopology;
    private promoteTopologyStrategy;
    private promoteTopologyCandidate;
    private setTopologyCandidateRolloutFrozen;
    private setTopologyOrchestratorFrozen;
    private rollbackTopologyStrategy;
    private instantiateTopology;
}
export {};
//# sourceMappingURL=team.d.ts.map