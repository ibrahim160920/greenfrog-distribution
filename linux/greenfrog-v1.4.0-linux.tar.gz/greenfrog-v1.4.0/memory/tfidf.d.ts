/**
 * Lightweight TF-IDF implementation for semantic memory search.
 *
 * No external dependencies — operates purely on the in-memory document set.
 * Suitable for personal-scale corpora (hundreds to low thousands of entries).
 */
export interface TFIDFDocument {
    id: string;
    text: string;
}
export interface ScoredDocument {
    id: string;
    score: number;
}
export declare class TFIDFIndex {
    private docs;
    private tfMaps;
    private idf;
    private built;
    /** Add documents and (re)build the index */
    build(docs: TFIDFDocument[]): void;
    /** TF-IDF vector for arbitrary text (uses corpus IDF) */
    private vector;
    /** Cosine similarity between two sparse vectors */
    private cosine;
    /**
     * Return the top-k most relevant document IDs for the given query.
     * Combines TF-IDF cosine similarity with exact substring match bonus.
     */
    query(queryText: string, topK?: number): ScoredDocument[];
}
//# sourceMappingURL=tfidf.d.ts.map