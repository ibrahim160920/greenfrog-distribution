import chalk from 'chalk';
import { agent } from '../../agents/agent.js';
import { withAgentExecutionLease } from '../../runtime/agent_runtime_guard.js';
import { nanoid } from 'nanoid';
export async function sendMessage(message, opts) {
    const msg = {
        id: nanoid(),
        channel: opts.channel ?? 'web',
        userId: 'cli-user',
        chatId: 'cli',
        text: message,
        timestamp: new Date(),
    };
    if (!opts.json) {
        process.stdout.write(chalk.cyan('You: ') + message + '\n');
        process.stdout.write(chalk.green('GreenFrog: '));
    }
    try {
        const response = await withAgentExecutionLease({ userId: msg.userId, channel: msg.channel, label: 'cli_send' }, () => agent.processMessage(msg));
        if (opts.json) {
            console.log(JSON.stringify({ response: response.text }, null, 2));
        }
        else {
            console.log(response.text);
        }
    }
    catch (err) {
        if (opts.json) {
            console.log(JSON.stringify({ error: String(err) }));
        }
        else {
            console.error(chalk.red('Error: ' + String(err)));
        }
        process.exit(1);
    }
}
//# sourceMappingURL=send.js.map