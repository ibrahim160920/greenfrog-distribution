export declare const GLOBAL_RULE_LIBRARY_WORKSPACE_ID = "__global_rule_library__";
//# sourceMappingURL=constants.d.ts.map