import { Bot } from 'grammy';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { ChannelError } from '../../utils/errors.js';
import { config } from '../../config/index.js';
export class TelegramChannel extends BaseChannel {
    name = 'telegram';
    bot = null;
    _running = false;
    _token = '';
    _reconnectTimer = null;
    _reconnectAttempts = 0;
    static MAX_RECONNECT_DELAY_MS = 60_000;
    async start() {
        const cfg = config.channels.telegram;
        if (!cfg?.enabled || !cfg.token) {
            this.log.info('Telegram not configured, skipping');
            return;
        }
        this._token = cfg.token;
        await this.connect(cfg.token);
    }
    async connect(token) {
        this.bot = new Bot(token);
        const allowedUsers = config.channels.telegram?.allowedUsers ?? [];
        const isAllowed = (userId) => {
            if (allowedUsers.length === 0)
                return true;
            return allowedUsers.includes(String(userId));
        };
        // Handle text messages
        this.bot.on('message:text', async (ctx) => {
            if (!ctx.message || !ctx.from)
                return;
            if (!isAllowed(ctx.from.id)) {
                await ctx.reply('⛔ You are not authorized to use this bot.');
                return;
            }
            const chatId = ctx.chat?.id ?? ctx.from.id;
            const chatType = ctx.chat?.type;
            const chatTitle = chatType && chatType !== 'private' && 'title' in (ctx.chat ?? {})
                ? ctx.chat.title
                : undefined;
            const msg = {
                id: nanoid(),
                channel: 'telegram',
                userId: String(ctx.from.id),
                username: ctx.from.username ?? ctx.from.first_name,
                chatId: String(chatId),
                chatName: chatTitle,
                text: ctx.message.text ?? '',
                timestamp: new Date(ctx.message.date * 1000),
                raw: ctx.message,
            };
            if (!msg.text)
                return; // ignore non-text messages (photos, stickers, etc.)
            await ctx.replyWithChatAction('typing').catch(() => { });
            await this.handleMessage(msg);
        });
        // Handle photo messages (vision)
        this.bot.on('message:photo', async (ctx) => {
            if (!ctx.message || !ctx.from)
                return;
            if (!isAllowed(ctx.from.id))
                return;
            const chatId = ctx.chat?.id ?? ctx.from.id;
            const caption = ctx.message.caption ?? '请描述这张图片'; // default prompt if no caption
            // Get the highest-resolution photo
            const photos = ctx.message.photo;
            if (!photos || photos.length === 0)
                return;
            const photo = photos[photos.length - 1]; // last = highest res
            try {
                // Download photo via bot API
                const file = await ctx.api.getFile(photo.file_id);
                const fileUrl = `https://api.telegram.org/file/bot${this._token}/${file.file_path}`;
                const response = await fetch(fileUrl);
                const arrayBuffer = await response.arrayBuffer();
                const buffer = Buffer.from(arrayBuffer);
                const msg = {
                    id: nanoid(),
                    channel: 'telegram',
                    userId: String(ctx.from.id),
                    username: ctx.from.username ?? ctx.from.first_name,
                    chatId: String(chatId),
                    text: caption,
                    attachments: [{
                            type: 'image',
                            data: buffer,
                            mimeType: 'image/jpeg',
                        }],
                    timestamp: new Date(ctx.message.date * 1000),
                    raw: ctx.message,
                };
                await ctx.replyWithChatAction('typing').catch(() => { });
                await this.handleMessage(msg);
            }
            catch (err) {
                this.log.error({ err }, 'Telegram: failed to process photo');
                await ctx.reply('Failed to process image.').catch(() => { });
            }
        });
        // Handle /start command
        this.bot.command('start', async (ctx) => {
            await ctx.reply('🐸 **GreenFrog AI Assistant** is ready!\n\n' +
                'I\'m your personal AI agent running locally on your device.\n' +
                'I can help you with:\n' +
                '• Web search & information\n' +
                '• Code execution & file management\n' +
                '• GitHub & git operations\n' +
                '• Weather, news, crypto prices\n' +
                '• Notes, todos & reminders\n' +
                '• Browser control\n' +
                '• Scheduled tasks\n' +
                '• And much more!\n\n' +
                'Just send me a message!', { parse_mode: 'Markdown' });
        });
        // Handle /clear command
        this.bot.command('clear', async (ctx) => {
            if (!ctx.from)
                return;
            const { memoryStore } = await import('../../memory/store.js');
            const chatId = String(ctx.chat?.id ?? ctx.from.id);
            const sessionId = await memoryStore.getOrCreateSession(String(ctx.from.id), 'telegram', chatId);
            await memoryStore.clearHistory(sessionId);
            await ctx.reply('🧹 Conversation history cleared!');
        });
        // Handle /help command
        this.bot.command('help', async (ctx) => {
            await ctx.reply('🐸 **GreenFrog Commands:**\n\n' +
                '/start - Welcome message\n' +
                '/clear - Clear conversation history\n' +
                '/help - Show this help\n\n' +
                'Just send any message to chat with your AI assistant!', { parse_mode: 'Markdown' });
        });
        this.bot.catch((err) => {
            this.log.error({ err }, 'Telegram bot error');
        });
        this.bot.start({ drop_pending_updates: true }).catch((err) => {
            this.log.error({ err }, 'Telegram polling stopped');
            this._running = false;
            this.scheduleReconnect();
        });
        this._running = true;
        this._reconnectAttempts = 0;
        this.log.info('Telegram channel started');
    }
    scheduleReconnect() {
        if (this._reconnectTimer)
            return;
        // Exponential backoff: 2^n * 1s, capped at 60s
        const delay = Math.min(1000 * Math.pow(2, this._reconnectAttempts), TelegramChannel.MAX_RECONNECT_DELAY_MS);
        this._reconnectAttempts++;
        this.log.info({ delay, attempt: this._reconnectAttempts }, 'Scheduling Telegram reconnect');
        this._reconnectTimer = setTimeout(async () => {
            this._reconnectTimer = null;
            try {
                await this.connect(this._token);
            }
            catch (err) {
                this.log.error({ err }, 'Telegram reconnect failed');
                this.scheduleReconnect();
            }
        }, delay);
    }
    async stop() {
        if (this._reconnectTimer) {
            clearTimeout(this._reconnectTimer);
            this._reconnectTimer = null;
        }
        await this.bot?.stop();
        this._running = false;
        this.log.info('Telegram channel stopped');
    }
    async send(message) {
        if (!this.bot || !message.chatId)
            return;
        try {
            const text = message.text ?? '';
            const chunks = this.splitMessage(text, 4000);
            for (const chunk of chunks) {
                await this.bot.api.sendMessage(message.chatId, chunk, {
                    parse_mode: 'Markdown',
                    reply_parameters: message.replyToId
                        ? { message_id: parseInt(message.replyToId) }
                        : undefined,
                }).catch(async () => {
                    // If markdown parsing fails, retry as plain text
                    await this.bot.api.sendMessage(message.chatId, chunk);
                });
            }
        }
        catch (err) {
            throw new ChannelError(`Telegram send error: ${String(err)}`, 'telegram');
        }
    }
    isRunning() {
        return this._running;
    }
    splitMessage(text, maxLen) {
        if (text.length <= maxLen)
            return [text];
        const chunks = [];
        let remaining = text;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, maxLen);
            const lastNewline = chunk.lastIndexOf('\n');
            if (lastNewline > maxLen / 2) {
                chunk = remaining.slice(0, lastNewline);
            }
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }
        return chunks;
    }
}
//# sourceMappingURL=index.js.map