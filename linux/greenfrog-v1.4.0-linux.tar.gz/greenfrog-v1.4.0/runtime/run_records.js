/**
 * Execution run records for workflows and scheduled jobs.
 *
 * Design:
 *   - In-memory ring buffer (max 500 records each) — same pattern as execution_trace.ts
 *   - Typed records, not strings — queryable by workflowId / jobId
 *   - Survives within a process lifetime; not persisted across restarts
 *   - Exposed via API for UI/harness consumption
 *
 * Why not SQLite? Adding a new table requires a migration step. For an
 * observability-tier store (recent runs only) the in-memory approach is
 * the right trade-off. Evidence that matters long-term lives in task metadata.
 */
import { nanoid } from 'nanoid';
const MAX_WORKFLOW_RUNS = 500;
const workflowRuns = new Map(); // runId → record
const workflowRunsByWorkflowId = new Map(); // workflowId → runId[]
export function createWorkflowRun(workflowId, workflowName, trigger = 'manual') {
    const runId = nanoid();
    const rec = {
        runId,
        workflowId,
        workflowName,
        trigger,
        startedAt: new Date().toISOString(),
        endedAt: null,
        status: 'running',
        stepResults: [],
        durationMs: null,
    };
    workflowRuns.set(runId, rec);
    const ids = workflowRunsByWorkflowId.get(workflowId) ?? [];
    ids.push(runId);
    workflowRunsByWorkflowId.set(workflowId, ids);
    // Evict oldest if over limit
    if (workflowRuns.size > MAX_WORKFLOW_RUNS) {
        const oldestKey = workflowRuns.keys().next().value;
        if (oldestKey)
            workflowRuns.delete(oldestKey);
    }
    return rec;
}
export function addWorkflowStepResult(runId, step) {
    const rec = workflowRuns.get(runId);
    if (rec)
        rec.stepResults.push(step);
}
export function completeWorkflowRun(runId, durationMs) {
    const rec = workflowRuns.get(runId);
    if (!rec)
        return;
    rec.status = 'success';
    rec.endedAt = new Date().toISOString();
    rec.durationMs = durationMs;
}
export function failWorkflowRun(runId, error, durationMs) {
    const rec = workflowRuns.get(runId);
    if (!rec)
        return;
    rec.status = 'failed';
    rec.error = error;
    rec.endedAt = new Date().toISOString();
    rec.durationMs = durationMs ?? null;
}
export function getWorkflowRun(runId) {
    return workflowRuns.get(runId) ?? null;
}
export function getWorkflowRunsForWorkflow(workflowId, limit = 20) {
    const ids = workflowRunsByWorkflowId.get(workflowId) ?? [];
    return ids
        .slice(-limit)
        .map((id) => workflowRuns.get(id))
        .filter((r) => r !== undefined)
        .reverse();
}
export function getAllWorkflowRuns(limit = 50) {
    const all = Array.from(workflowRuns.values());
    return all.slice(-limit).reverse();
}
const MAX_JOB_RUNS = 500;
const jobRuns = new Map(); // runId → record
const jobRunsByJobId = new Map(); // jobId → runId[]
export function createJobRun(jobId, jobName) {
    const runId = nanoid();
    const rec = {
        runId,
        jobId,
        jobName,
        startedAt: new Date().toISOString(),
        endedAt: null,
        status: 'running',
        resultSummary: '',
        notified: false,
        durationMs: null,
    };
    jobRuns.set(runId, rec);
    const ids = jobRunsByJobId.get(jobId) ?? [];
    ids.push(runId);
    jobRunsByJobId.set(jobId, ids);
    if (jobRuns.size > MAX_JOB_RUNS) {
        const oldestKey = jobRuns.keys().next().value;
        if (oldestKey)
            jobRuns.delete(oldestKey);
    }
    return rec;
}
export function completeJobRun(runId, resultSummary, notified, durationMs) {
    const rec = jobRuns.get(runId);
    if (!rec)
        return;
    rec.status = 'success';
    rec.resultSummary = resultSummary;
    rec.notified = notified;
    rec.endedAt = new Date().toISOString();
    rec.durationMs = durationMs;
}
export function failJobRun(runId, error, durationMs) {
    const rec = jobRuns.get(runId);
    if (!rec)
        return;
    rec.status = 'failed';
    rec.error = error;
    rec.endedAt = new Date().toISOString();
    rec.durationMs = durationMs;
}
export function getJobRun(runId) {
    return jobRuns.get(runId) ?? null;
}
export function getJobRunsForJob(jobId, limit = 20) {
    const ids = jobRunsByJobId.get(jobId) ?? [];
    return ids
        .slice(-limit)
        .map((id) => jobRuns.get(id))
        .filter((r) => r !== undefined)
        .reverse();
}
export function getAllJobRuns(limit = 50) {
    const all = Array.from(jobRuns.values());
    return all.slice(-limit).reverse();
}
//# sourceMappingURL=run_records.js.map