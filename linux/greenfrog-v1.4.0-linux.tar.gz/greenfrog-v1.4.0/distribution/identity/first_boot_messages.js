/**
 * first_boot_messages.ts — i18n message set for the first-boot enrollment flow.
 *
 * Provides typed access to all messages shown during enrollment states.
 * Locale defaults to system locale detection; falls back to 'en'.
 */
import { I18n, detectSystemLocale } from '../../i18n/loader.js';
// ── Factory ───────────────────────────────────────────────────────────────────
/**
 * Return the typed first-boot message set for the given locale.
 * If no locale is provided, the system locale is detected automatically.
 *
 * @param locale  BCP-47 locale tag, e.g. 'en', 'zh-CN', 'ja'. Optional.
 */
export function getFirstBootMessages(locale) {
    const resolvedLocale = locale ?? detectSystemLocale();
    const i18n = new I18n(resolvedLocale);
    return {
        generating: i18n.t('firstBoot.generating'),
        title: i18n.t('firstBoot.title'),
        subtitle: i18n.t('firstBoot.subtitle'),
        enrollmentKeyLabel: i18n.t('firstBoot.enrollmentKey.label'),
        enrollmentKeyHint: i18n.t('firstBoot.enrollmentKey.hint'),
        enrollmentKeyCopied: i18n.t('firstBoot.enrollmentKey.copied'),
        submitLabel: i18n.t('enrollment.submit'),
        submitting: i18n.t('enrollment.submitting'),
        success: i18n.t('enrollment.success'),
        alreadyEnrolled: i18n.t('enrollment.alreadyEnrolled'),
        credentialSaved: i18n.t('enrollment.credential.saved'),
        errorNetwork: i18n.t('enrollment.error.network'),
        errorServer: i18n.t('enrollment.error.server'),
        errorGeneric: i18n.t('enrollment.error.generic'),
    };
}
/**
 * Return a credential location message with the path interpolated.
 * Separate from the main set because it requires a variable.
 */
export function getCredentialLocationMessage(storagePath, locale) {
    const resolvedLocale = locale ?? detectSystemLocale();
    const i18n = new I18n(resolvedLocale);
    return i18n.t('enrollment.credential.location', { path: storagePath });
}
//# sourceMappingURL=first_boot_messages.js.map