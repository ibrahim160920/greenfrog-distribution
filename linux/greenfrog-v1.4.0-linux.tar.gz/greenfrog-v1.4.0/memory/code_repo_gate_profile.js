const PROFILE_THRESHOLDS = {
    strict: {
        minDecisionScore: 92,
        minValidationCount: 5,
        minSuccessRate: 0.85,
    },
    balanced: {
        minDecisionScore: 85,
        minValidationCount: 3,
        minSuccessRate: 0.75,
    },
    aggressive: {
        minDecisionScore: 75,
        minValidationCount: 2,
        minSuccessRate: 0.6,
    },
};
export function resolveCodeRepoGateConfig(input) {
    const requestedProfile = input?.gateProfile ?? 'balanced';
    const hasExplicitOverrides = (input?.minDecisionScore !== undefined
        || input?.minValidationCount !== undefined
        || input?.minSuccessRate !== undefined);
    const baseProfile = requestedProfile === 'custom'
        ? 'balanced'
        : requestedProfile;
    const baseThresholds = PROFILE_THRESHOLDS[baseProfile];
    const thresholds = {
        minDecisionScore: input?.minDecisionScore ?? baseThresholds.minDecisionScore,
        minValidationCount: input?.minValidationCount ?? baseThresholds.minValidationCount,
        minSuccessRate: input?.minSuccessRate ?? baseThresholds.minSuccessRate,
    };
    let source = 'default';
    if (requestedProfile === 'custom') {
        source = 'custom-profile';
    }
    else if (hasExplicitOverrides) {
        source = 'profile+overrides';
    }
    else if (input?.gateProfile) {
        source = 'named-profile';
    }
    return {
        requestedProfile,
        effectiveProfile: hasExplicitOverrides ? 'custom' : requestedProfile,
        baseProfile,
        source,
        hasExplicitOverrides,
        thresholds,
    };
}
//# sourceMappingURL=code_repo_gate_profile.js.map