/**
 * BM25 (Best Match 25) — industry-standard probabilistic ranking function.
 *
 * Significantly more accurate than plain TF-IDF:
 *  - Term-frequency saturation (k1 parameter) prevents high-frequency terms
 *    from dominating unrealistically.
 *  - Document-length normalisation (b parameter) prevents shorter documents
 *    from being artificially penalised.
 *
 * Used by Elasticsearch, Solr, Lucene, and SQLite FTS5 as the default scorer.
 *
 * No external dependencies — operates purely in memory.
 */
const K1 = 1.5; // term saturation: higher = more weight on frequency
const B = 0.75; // length normalisation: 0 = none, 1 = full
/** Tokenise text into lowercase alphanumeric + CJK tokens */
function tokenise(text) {
    return text.toLowerCase().match(/[a-z0-9]+|[\u4e00-\u9fff]/g) ?? [];
}
/** Term-frequency map for a single document */
function termFreq(tokens) {
    const tf = new Map();
    for (const t of tokens)
        tf.set(t, (tf.get(t) ?? 0) + 1);
    return tf;
}
export class BM25Index {
    docs = [];
    tfMaps = [];
    docLengths = [];
    avgDocLength = 0;
    idf = new Map();
    built = false;
    build(docs) {
        this.docs = docs;
        this.tfMaps = docs.map((d) => termFreq(tokenise(d.text)));
        this.docLengths = this.tfMaps.map((tf) => {
            let len = 0;
            for (const v of tf.values())
                len += v;
            return len;
        });
        this.avgDocLength = this.docLengths.length > 0
            ? this.docLengths.reduce((a, b) => a + b, 0) / this.docLengths.length
            : 1;
        const N = docs.length;
        const df = new Map();
        for (const tf of this.tfMaps) {
            for (const term of tf.keys())
                df.set(term, (df.get(term) ?? 0) + 1);
        }
        // IDF (Robertson-Sparck Jones variant, smoothed)
        // IDF(t) = log((N - df(t) + 0.5) / (df(t) + 0.5) + 1)
        this.idf = new Map();
        for (const [term, count] of df) {
            this.idf.set(term, Math.log((N - count + 0.5) / (count + 0.5) + 1));
        }
        this.built = true;
    }
    /**
     * Score all documents against the query and return the top-k by BM25 score.
     * Adds a small substring-match bonus for exact phrase hits.
     */
    query(queryText, topK = 5) {
        if (!this.built || this.docs.length === 0)
            return [];
        const queryTerms = tokenise(queryText);
        const queryLower = queryText.toLowerCase();
        const scores = this.docs.map((doc, idx) => {
            const tf = this.tfMaps[idx];
            const dl = this.docLengths[idx];
            let score = 0;
            for (const term of queryTerms) {
                const tfVal = tf.get(term) ?? 0;
                if (tfVal === 0)
                    continue;
                const idf = this.idf.get(term) ?? 0;
                // BM25 term score
                const numerator = tfVal * (K1 + 1);
                const denominator = tfVal + K1 * (1 - B + B * (dl / this.avgDocLength));
                score += idf * (numerator / denominator);
            }
            // Substring match bonus (helps with exact queries)
            if (score > 0 && doc.text.toLowerCase().includes(queryLower))
                score += 0.3;
            return { id: doc.id, score };
        });
        return scores
            .filter((s) => s.score > 0)
            .sort((a, b) => b.score - a.score)
            .slice(0, topK);
    }
    /** Returns the number of indexed documents */
    get size() {
        return this.docs.length;
    }
}
//# sourceMappingURL=bm25.js.map