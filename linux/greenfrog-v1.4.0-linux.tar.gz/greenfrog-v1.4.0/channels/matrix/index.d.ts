import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class MatrixChannel extends BaseChannel {
    readonly name: "matrix";
    private matrixClient;
    private _running;
    private _reconnectTimer;
    private _reconnectAttempts;
    private static readonly MAX_RECONNECT_DELAY_MS;
    private _homeserverUrl;
    private _accessToken;
    start(): Promise<void>;
    private connect;
    private scheduleReconnect;
    stop(): Promise<void>;
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
    private splitMessage;
}
//# sourceMappingURL=index.d.ts.map