import type { SkillDefinition, SkillCallResult, ConversationContext, ProviderTool } from '../utils/types.js';
export declare abstract class BaseSkill {
    abstract readonly definition: SkillDefinition;
    abstract execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    /** Convert to AI provider tool format */
    toProviderTool(): ProviderTool;
    ok(data: unknown, text?: string): SkillCallResult;
    err(message: string): SkillCallResult;
    text(message: string): SkillCallResult;
}
//# sourceMappingURL=base.d.ts.map