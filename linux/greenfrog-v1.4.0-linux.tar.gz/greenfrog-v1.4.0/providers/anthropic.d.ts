import type { ProviderRequest, ProviderResponse } from '../utils/types.js';
import { BaseProvider, type StreamingCall } from './base.js';
export declare class AnthropicProvider extends BaseProvider {
    readonly name = "anthropic";
    readonly defaultModel = "claude-sonnet-4-6";
    private client;
    private model;
    constructor(apiKey: string, model?: string, baseUrl?: string, extraHeaders?: Record<string, string>);
    chat(request: ProviderRequest): Promise<ProviderResponse>;
    chatStream(request: ProviderRequest): StreamingCall;
    /** Extract the api messages array for reuse between chat() and chatStream() */
    private buildApiMessages;
    isAvailable(): Promise<boolean>;
    listModels(): Promise<string[]>;
}
//# sourceMappingURL=anthropic.d.ts.map