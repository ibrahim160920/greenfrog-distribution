import { createLogger } from './utils/logger.js';
import { channelManager } from './channels/index.js';
import { gateway } from './gateway/index.js';
import { scheduler } from './scheduler/index.js';
import { skillRegistry } from './skills/registry.js';
import { agent } from './agents/agent.js';
import { memoryStore, setMemoryStore } from './memory/store.js';
import { createStore } from './db/index.js';
import { config } from './config/index.js';
import { dockerSandbox } from './sandbox/docker.js';
import chalk from 'chalk';
import { nanoid } from 'nanoid';
import { matchesCondition, renderTemplate } from './skills/workflow.js';
import { runCheck } from './skills/patrol.js';
import { processOnCallTaskHandoffs, processPendingTeamApprovals, processReadyTeamTasks, processTeamSwarmProtocol, retryPendingTeamNotifications } from './skills/team.js';
import cron from 'node-cron';
import { initQueue, closeQueue } from './queue/index.js';
import { messagesTotal } from './metrics/index.js';
import { getScopedMemoryForContext, setScopedMemoryForContext } from './memory/index.js';
import { runAgentHeartbeatCycle, runAgentMailboxCycle } from './agents/heartbeat.js';
import { configureTeamRuntimeWakeups } from './runtime/team_runtime_wakeup.js';
import { providerRegistry } from './providers/index.js';
import { withAgentExecutionLease } from './runtime/agent_runtime_guard.js';
import { assertSafeSqliteRuntime } from './runtime/sqlite_runtime_guard.js';
import { touchHeartbeat } from './runtime/agent_heartbeat.js';
import { pluginWatcher } from './plugins/index.js';
import { RULE_MAINTENANCE_INTERVAL_MS, RULE_MAINTENANCE_STARTUP_DELAY_MS, runBehavioralRuleMaintenanceCycle, } from './memory/rule_maintenance.js';
import { startPeriodicSync } from './memory/federated_learning.js';
import { startEvolutionScheduler } from './memory/evolution_scheduler.js';
import { startMotherRepoScheduler, stopMotherRepoScheduler } from './memory/mother_repo_scheduler.js';
import { activateMotherBodyLocal } from './memory/mother_body_activation.js';
import { detectAndRecoverStaleTasks } from './agents/stale_recovery.js';
import { getProjectEvolutionCapabilities, resolveProjectEvolutionMode } from './memory/evolution_mode.js';
import { emitProjectEvolutionGateAlertNotifications } from './memory/project_evolution_gate_notifications.js';
import { importMergedSourceRepoRules } from './memory/source_repo_runtime.js';
import { checkForProjectUpgrade, applyProjectUpgrade } from './runtime/project_upgrade.js';
import { resolveCodeRepoGateConfig } from './memory/code_repo_gate_profile.js';
import { cancelStuckRuns, releaseStuckCancelledRuns, startAgentRun } from './runtime/agent_run_control.js';
import { registerWorkflowExecutor } from './runtime/workflow_executor.js';
import { checkEnrollmentOrExit } from './distribution/runtime_gate.js';
import { runFirstBoot, isEnrolled } from './distribution/identity/first_boot.js';
import { createWorkflowRun, completeWorkflowRun, failWorkflowRun, addWorkflowStepResult, createJobRun, completeJobRun, failJobRun, } from './runtime/run_records.js';
const log = createLogger('platform');
let teamSupervisorRunning = false;
let teamNotificationRetryRunning = false;
let teamApprovalMonitorRunning = false;
let agentHeartbeatRunning = false;
const teamSupervisorWorkspaceRunning = new Set();
const agentHeartbeatScopeRunning = new Set();
const agentMailboxCycleRunning = new Set();
async function runControlledAgentMessage(msg, label) {
    const run = startAgentRun({
        userId: msg.userId,
        channel: msg.channel,
        label,
        taskId: typeof msg.metadata?.taskId === 'string' ? msg.metadata.taskId : null,
        workspaceId: typeof msg.metadata?.workspaceId === 'string' ? msg.metadata.workspaceId : null,
        agentId: typeof msg.metadata?.agentId === 'string' ? msg.metadata.agentId : null,
    });
    msg.metadata = { ...(msg.metadata ?? {}), agentRunId: run.runId };
    return withAgentExecutionLease({ userId: msg.userId, channel: msg.channel, label }, async () => {
        try {
            return await agent.processMessage(msg);
        }
        finally {
            run.release();
        }
    });
}
async function maybeApplyProjectUpgradeOnStartup() {
    const evolutionMode = resolveProjectEvolutionMode(config.evolution);
    const capabilities = getProjectEvolutionCapabilities(evolutionMode);
    const upgradeConfig = {
        enabled: capabilities.allowUpgradeAutomation && Boolean(config.evolution?.upgrade?.enabled),
        repoPath: config.evolution?.upgrade?.repoPath ?? process.cwd(),
        manifestPath: config.evolution?.upgrade?.manifestPath ?? '.greenfrog/releases/latest.json',
        remote: config.evolution?.upgrade?.remote ?? 'origin',
        baseBranch: config.evolution?.upgrade?.baseBranch ?? 'main',
        autoApply: config.evolution?.upgrade?.autoApply ?? false,
        approvalWindowStartHourUtc: config.evolution?.upgrade?.approvalWindowStartHourUtc,
        approvalWindowEndHourUtc: config.evolution?.upgrade?.approvalWindowEndHourUtc,
        approvedWeekdaysUtc: config.evolution?.upgrade?.approvedWeekdaysUtc,
        rolloutPercentage: config.evolution?.upgrade?.rolloutPercentage ?? 100,
        rolloutSeed: config.evolution?.upgrade?.rolloutSeed,
        healthCheckCommands: config.evolution?.upgrade?.healthCheckCommands ?? [],
        minHealthChecksPassing: config.evolution?.upgrade?.minHealthChecksPassing ?? 0,
        verificationCommands: config.evolution?.upgrade?.verificationCommands ?? [],
        minVerificationChecksPassing: config.evolution?.upgrade?.minVerificationChecksPassing ?? 0,
        autoRollbackOnVerificationFailure: config.evolution?.upgrade?.autoRollbackOnVerificationFailure ?? false,
        requireCleanWorkingTree: config.evolution?.upgrade?.requireCleanWorkingTree ?? true,
        installCommand: config.evolution?.upgrade?.installCommand,
        buildCommand: config.evolution?.upgrade?.buildCommand,
        restartOnApply: config.evolution?.upgrade?.restartOnApply ?? true,
        respectAutomationPolicies: true,
    };
    if (!upgradeConfig.enabled)
        return;
    const upgradeCheck = await checkForProjectUpgrade(upgradeConfig);
    if (upgradeCheck.available) {
        log.info(upgradeCheck, 'Project upgrade available');
        if (upgradeConfig.autoApply) {
            const applied = await applyProjectUpgrade(upgradeConfig);
            if (applied.applied) {
                log.warn(applied, 'Project upgrade applied before startup');
                if (upgradeConfig.restartOnApply) {
                    log.warn('Restart required after project upgrade; exiting before platform bootstrap');
                    process.exit(0);
                }
            }
        }
    }
    else if (upgradeCheck.skippedReason && upgradeCheck.skippedReason !== 'already up to date') {
        log.info(upgradeCheck, 'Project upgrade check skipped');
    }
}
export async function startPlatform(options = {}) {
    const { webEnabled = true, gatewayEnabled = true } = options;
    const startupEvolutionMode = resolveProjectEvolutionMode(config.evolution);
    const startupEvolutionCaps = getProjectEvolutionCapabilities(startupEvolutionMode);
    console.log(chalk.green('\n🐸 GreenFrog AI Agent Platform\n'));
    // ── Child instance enrollment gate ─────────────────────────────────────────
    if (process.env['GF_IS_CHILD_INSTANCE'] === 'true') {
        // Support: greenfrog --enrollment-url <url> for one-shot first-run enrollment
        const enrollmentUrlArg = (() => {
            const argv = process.argv;
            const idx = argv.findIndex(a => a === '--enrollment-url');
            return idx !== -1 ? (argv[idx + 1] ?? '') : '';
        })();
        const enrollmentUrl = enrollmentUrlArg || process.env['GF_ENROLLMENT_URL'];
        if (enrollmentUrl && !isEnrolled()) {
            const baseDir = process.env['GF_BASE_DIR'];
            let appVersion = '0.0.0';
            try {
                const { readFileSync } = await import('node:fs');
                const { createRequire } = await import('node:module');
                const req = createRequire(import.meta.url);
                const pkg = req('../package.json');
                appVersion = pkg.version ?? appVersion;
            }
            catch { /* use default */ }
            console.log(`\n  Auto-enrolling with: ${enrollmentUrl}\n`);
            const result = await runFirstBoot({ enrollmentUrl, appVersion, baseDir });
            if (!result.ok || result.state !== 'enrolled') {
                console.error(`\n  Enrollment failed (state: ${result.state}). ${result.error ?? ''}`);
                console.error('  Check that the enrollment URL is correct and the server is reachable.\n');
                process.exit(1);
            }
            console.log(`  Enrolled successfully (instanceId: ${result.instanceId})\n`);
        }
        checkEnrollmentOrExit();
    }
    // ── Database initialization (PostgreSQL if DATABASE_URL set, else SQLite) ─
    await maybeApplyProjectUpgradeOnStartup();
    assertSafeSqliteRuntime({
        usingSqlite: !config.database?.url,
        dataDir: config.dataDir,
    });
    const store = await createStore();
    setMemoryStore(store);
    const sourceRepoImportResult = await importMergedSourceRepoRules({
        enabled: startupEvolutionCaps.allowLocalArtifacts && Boolean(config.evolution?.sourceRepo?.enabled),
        repoPath: config.evolution?.sourceRepo?.repoPath ?? '',
        outputPath: config.evolution?.sourceRepo?.outputPath ?? '.greenfrog/evolution/rule_candidates.json',
        branchPrefix: config.evolution?.sourceRepo?.branchPrefix ?? 'greenfrog-evolution',
    });
    if (sourceRepoImportResult.imported) {
        log.info(sourceRepoImportResult, 'Loaded merged source-repo rules into global rule library');
    }
    else if (sourceRepoImportResult.skippedReason && sourceRepoImportResult.skippedReason !== 'source repo evolution disabled') {
        log.info(sourceRepoImportResult, 'Skipped source-repo runtime import');
    }
    // ── Task queue (BullMQ + Redis, no-op when queue.redisUrl is absent) ──────
    await initQueue(async (data) => {
        const msg = {
            id: nanoid(),
            channel: data.channel,
            userId: data.userId,
            chatId: data.chatId,
            text: data.text,
            timestamp: new Date(),
            metadata: {
                ...(data.agentId ? { agentId: data.agentId } : {}),
                ...(data.workspaceId ? { workspaceId: data.workspaceId } : {}),
            },
        };
        messagesTotal.inc({ channel: data.channel });
        const response = await runControlledAgentMessage(msg, 'queue_worker');
        return response.text ?? '';
    });
    // ── Node.js version check ─────────────────────────────────────────────────
    const nodeMajor = parseInt(process.versions.node);
    if (nodeMajor < 22) {
        log.warn({ nodeVersion: process.versions.node }, 'Node.js < 22 detected — --permission flag may not be stable. Docker sandbox strongly recommended.');
    }
    // ── Provider baseURL sanity check ─────────────────────────────────────────
    // If the configured Anthropic baseURL looks like a custom proxy that is not
    // the official Anthropic API, warn the operator so they can fix it in Settings.
    const anthropicBaseUrl = config.providers?.anthropic?.baseUrl;
    if (anthropicBaseUrl && !anthropicBaseUrl.includes('api.anthropic.com')) {
        log.warn({ anthropicBaseUrl }, 'Anthropic baseURL does not point to api.anthropic.com — AI calls may fail. ' +
            'To fix: open Settings → Anthropic → Base URL and set it to https://api.anthropic.com');
    }
    // ── Sandbox: ensure Docker image + start health monitor ──────────────────
    if (config.sandbox?.enabled !== false) {
        dockerSandbox.ensureImage(config.sandbox?.image).catch((err) => {
            log.warn({ err }, 'Sandbox image build failed — execution will use fallback');
        });
        // Re-probe Docker daemon every 30 s so we detect daemon restarts/crashes
        dockerSandbox.startHealthMonitor(30_000);
    }
    // ── Load custom skills ────────────────────────────────────────────────────
    await skillRegistry.loadCustomSkills();
    pluginWatcher.start();
    log.info({ count: skillRegistry.list().length }, 'Skills loaded');
    // ── Register browser skill (optional — Playwright may not be installed) ───
    try {
        const { BrowserSkill } = await import('./browser/index.js');
        skillRegistry.register(new BrowserSkill());
        log.info('Browser skill registered');
    }
    catch (err) {
        log.warn({ err }, 'Browser skill unavailable (Playwright not installed?)');
    }
    // ── Start WebSocket Gateway ───────────────────────────────────────────────
    if (gatewayEnabled) {
        gateway.registerHandler('chat', async (_type, payload, _client, reply) => {
            const { text: rawText, userId = 'gateway-user', chatId = 'gateway' } = payload;
            // Guard against excessively large payloads that could cause memory exhaustion
            const MAX_MESSAGE_CHARS = 32_000;
            if (!rawText || typeof rawText !== 'string') {
                reply('chat_response', { text: 'Message text is required.', chatId });
                return;
            }
            const text = rawText.length > MAX_MESSAGE_CHARS
                ? rawText.slice(0, MAX_MESSAGE_CHARS)
                : rawText;
            const msg = {
                id: nanoid(),
                channel: 'web',
                userId,
                chatId,
                text,
                timestamp: new Date(),
            };
            try {
                const response = await runControlledAgentMessage(msg, 'gateway_chat');
                reply('chat_response', { text: response.text, chatId });
            }
            catch (err) {
                reply('chat_response', { text: String(err), chatId });
            }
        });
        await gateway.start();
        log.info({ port: config.gateway.port }, 'Gateway started');
    }
    // ── Start Messaging Channels ──────────────────────────────────────────────
    await channelManager.startAll(config.channels);
    // ── Provider fallback alerting ────────────────────────────────────────────
    // Log at ERROR severity (more visible than WARN) and notify admin channels
    // when the primary LLM provider is unavailable and a fallback is used.
    // Bounded LRU map: at most 64 provider-pair entries (10 providers → max 90 pairs).
    // Prevents unbounded growth if provider names are dynamic or misconfigured.
    const FALLBACK_COOLDOWN_MAP_MAX = 64;
    const fallbackAlertCooldowns = new Map();
    providerRegistry.onFallback = (primary, used, label) => {
        const key = `${primary}→${used}`;
        const now = Date.now();
        const lastAlert = fallbackAlertCooldowns.get(key) ?? 0;
        // Suppress repeat alerts for the same pair within 5 minutes
        if (now - lastAlert < 5 * 60_000)
            return;
        // Evict oldest entry if the map is at capacity (FIFO eviction)
        if (!fallbackAlertCooldowns.has(key) && fallbackAlertCooldowns.size >= FALLBACK_COOLDOWN_MAP_MAX) {
            const oldestKey = fallbackAlertCooldowns.keys().next().value;
            if (oldestKey !== undefined)
                fallbackAlertCooldowns.delete(oldestKey);
        }
        fallbackAlertCooldowns.set(key, now);
        log.error({ primary, used, label }, `AI provider fallback: "${primary}" unavailable, using "${used}" instead. ` +
            'Check API key / quota / network for the primary provider.');
        // Deliver to all configured admin channels as a system alert
        const adminChannels = config.roles?.admin ?? [];
        if (adminChannels.length > 0) {
            const alertText = `⚠️ *Provider fallback alert*\n` +
                `Primary: \`${primary}\` → Using: \`${used}\`\n` +
                `Reason: primary provider unavailable (check API key / quota)\n` +
                `Time: ${new Date().toLocaleString()}`;
            for (const principal of adminChannels.slice(0, 3)) {
                // principal format: "channel:userId" or bare "userId"
                const parts = principal.split(':');
                const channel = parts.length >= 2 ? parts[0] : 'web';
                const userId = parts.length >= 2 ? parts.slice(1).join(':') : parts[0];
                channelManager.send(channel, {
                    text: alertText,
                    chatId: userId,
                    markdown: true,
                }).catch(() => { });
            }
        }
    };
    // ── Start Scheduler ───────────────────────────────────────────────────────
    const evolution = config.evolution;
    const evolutionMode = resolveProjectEvolutionMode(evolution);
    const evolutionCaps = getProjectEvolutionCapabilities(evolutionMode);
    const ruleSyncConfig = {
        enabled: evolutionCaps.allowRemoteSync && Boolean(evolution?.ruleSync?.enabled),
        mode: evolution?.ruleSync?.mode ?? 'manual',
        uploadRules: evolution?.ruleSync?.uploadRules ?? true,
        uploadStats: evolution?.ruleSync?.uploadStats ?? false,
        anonymize: evolution?.ruleSync?.anonymize ?? true,
        reviewBeforeUpload: evolution?.ruleSync?.reviewBeforeUpload ?? true,
        remoteUrl: evolution?.ruleSync?.remoteUrl ?? '',
        ...(evolution?.ruleSync?.accessToken ? { accessToken: evolution.ruleSync.accessToken } : {}),
        syncIntervalHours: evolution?.ruleSync?.syncIntervalHours ?? 24,
    };
    const sourceRepoConfig = {
        enabled: evolutionCaps.allowLocalArtifacts && Boolean(evolution?.sourceRepo?.enabled),
        repoPath: evolution?.sourceRepo?.repoPath ?? '',
        outputPath: evolution?.sourceRepo?.outputPath ?? '.greenfrog/evolution/rule_candidates.json',
        summaryPath: evolution?.sourceRepo?.summaryPath ?? '.greenfrog/evolution/RULE_CANDIDATES.md',
        minConfidence: evolution?.sourceRepo?.minConfidence ?? 92,
        minEvidenceCount: evolution?.sourceRepo?.minEvidenceCount ?? 20,
        minWorkspaceCount: evolution?.sourceRepo?.minWorkspaceCount ?? 3,
        autoCommit: evolutionCaps.allowSourceRepoMutation ? (evolution?.sourceRepo?.autoCommit ?? false) : false,
        autoPush: evolutionCaps.allowSourceRepoMutation ? (evolution?.sourceRepo?.autoPush ?? false) : false,
        createPullRequest: evolutionCaps.allowSourceRepoMutation ? (evolution?.sourceRepo?.createPullRequest ?? false) : false,
        remote: evolution?.sourceRepo?.remote ?? 'origin',
        repo: evolution?.sourceRepo?.repo,
        baseBranch: evolution?.sourceRepo?.baseBranch ?? 'main',
        headOwner: evolution?.sourceRepo?.headOwner,
        githubToken: config.skills.github?.token,
        pullRequestTitle: evolution?.sourceRepo?.pullRequestTitle ?? 'chore(evolution): promote curated rule candidates',
        branchPrefix: evolution?.sourceRepo?.branchPrefix ?? 'greenfrog-evolution',
        commitMessage: evolution?.sourceRepo?.commitMessage ?? 'chore(evolution): update curated rule candidates',
    };
    const resolvedCodeRepoGate = resolveCodeRepoGateConfig(evolution?.codeRepo);
    const codeRepoConfig = {
        ...resolvedCodeRepoGate,
        enabled: evolutionCaps.allowLocalArtifacts && Boolean(evolution?.codeRepo?.enabled),
        repoPath: evolution?.codeRepo?.repoPath ?? '',
        manifestPath: evolution?.codeRepo?.manifestPath ?? '.greenfrog/evolution/core_code_candidates.json',
        summaryPath: evolution?.codeRepo?.summaryPath ?? '.greenfrog/evolution/CORE_CODE_CANDIDATES.md',
        patchPath: evolution?.codeRepo?.patchPath ?? '.greenfrog/evolution/core_changes.patch',
        minDecisionScore: resolvedCodeRepoGate.thresholds.minDecisionScore,
        minValidationCount: resolvedCodeRepoGate.thresholds.minValidationCount,
        minSuccessRate: resolvedCodeRepoGate.thresholds.minSuccessRate,
        autoApplyPatch: evolutionCaps.allowSourceRepoMutation ? (evolution?.codeRepo?.autoApplyPatch ?? false) : false,
        autoCommit: evolutionCaps.allowSourceRepoMutation ? (evolution?.codeRepo?.autoCommit ?? false) : false,
        autoPush: evolutionCaps.allowSourceRepoMutation ? (evolution?.codeRepo?.autoPush ?? false) : false,
        createPullRequest: evolutionCaps.allowSourceRepoMutation ? (evolution?.codeRepo?.createPullRequest ?? false) : false,
        remote: evolution?.codeRepo?.remote ?? 'origin',
        repo: evolution?.codeRepo?.repo,
        baseBranch: evolution?.codeRepo?.baseBranch ?? 'main',
        headOwner: evolution?.codeRepo?.headOwner,
        githubToken: config.skills.github?.token,
        pullRequestTitle: evolution?.codeRepo?.pullRequestTitle ?? 'chore(evolution): promote core code candidates',
        branchPrefix: evolution?.codeRepo?.branchPrefix ?? 'greenfrog-evolution',
        commitMessage: evolution?.codeRepo?.commitMessage ?? 'chore(evolution): update core code candidates',
    };
    const codeGenerationConfig = {
        enabled: evolutionCaps.allowLocalArtifacts && Boolean(evolution?.codeRepo?.autoGenerateCandidates),
        repoPath: evolution?.codeRepo?.repoPath ?? '',
        lookbackDays: evolution?.codeRepo?.generationLookbackDays ?? 14,
        maxAuditEntries: evolution?.codeRepo?.generationMaxAuditEntries ?? 200,
        maxCandidates: evolution?.codeRepo?.generationMaxCandidates ?? 3,
        maxEvidencePerCandidate: evolution?.codeRepo?.generationMaxEvidencePerCandidate ?? 8,
        maxFileContextChars: evolution?.codeRepo?.generationMaxFileContextChars ?? 8000,
        minEvidenceCount: evolution?.codeRepo?.generationMinEvidenceCount ?? 4,
        minFailureCount: evolution?.codeRepo?.generationMinFailureCount ?? 2,
        minSuccessCount: evolution?.codeRepo?.generationMinSuccessCount ?? 1,
        skills: ['coding_agent', 'file_ops', 'shell', 'git', 'code_exec', 'skill_creator'],
        provider: evolution?.codeRepo?.generationProvider,
        model: evolution?.codeRepo?.generationModel,
    };
    const releaseConfig = {
        enabled: evolutionCaps.allowReleaseAutomation && Boolean(evolution?.release?.enabled),
        repoPath: evolution?.release?.repoPath ?? '',
        manifestPath: evolution?.release?.manifestPath ?? '.greenfrog/releases/latest.json',
        notesPath: evolution?.release?.notesPath ?? '.greenfrog/releases/RELEASE_NOTES.md',
        bump: evolution?.release?.bump ?? 'patch',
        approvalWindowStartHourUtc: evolution?.release?.approvalWindowStartHourUtc,
        approvalWindowEndHourUtc: evolution?.release?.approvalWindowEndHourUtc,
        approvedWeekdaysUtc: evolution?.release?.approvedWeekdaysUtc,
        healthCheckCommands: evolution?.release?.healthCheckCommands ?? [],
        minHealthChecksPassing: evolution?.release?.minHealthChecksPassing ?? 0,
        autoCommit: evolutionCaps.allowReleaseAutomation ? (evolution?.release?.autoCommit ?? false) : false,
        autoPush: evolutionCaps.allowReleaseAutomation ? (evolution?.release?.autoPush ?? false) : false,
        autoTag: evolutionCaps.allowReleaseAutomation ? (evolution?.release?.autoTag ?? false) : false,
        createGithubRelease: evolutionCaps.allowReleaseAutomation ? (evolution?.release?.createGithubRelease ?? false) : false,
        remote: evolution?.release?.remote ?? 'origin',
        repo: evolution?.release?.repo,
        baseBranch: evolution?.release?.baseBranch ?? 'main',
        githubToken: config.skills.github?.token,
        releaseTitle: evolution?.release?.releaseTitle ?? 'GreenFrog automated release',
        branchPrefix: evolution?.release?.branchPrefix ?? 'greenfrog-evolution',
        commitMessage: evolution?.release?.commitMessage ?? 'chore(release): publish automated release metadata',
        tagPrefix: evolution?.release?.tagPrefix ?? 'v',
        respectAutomationPolicies: true,
    };
    const upgradeConfig = {
        enabled: evolutionCaps.allowUpgradeAutomation && Boolean(evolution?.upgrade?.enabled),
        repoPath: evolution?.upgrade?.repoPath ?? process.cwd(),
        manifestPath: evolution?.upgrade?.manifestPath ?? '.greenfrog/releases/latest.json',
        remote: evolution?.upgrade?.remote ?? 'origin',
        baseBranch: evolution?.upgrade?.baseBranch ?? 'main',
        autoApply: evolutionCaps.allowUpgradeAutomation ? (evolution?.upgrade?.autoApply ?? false) : false,
        requireCleanWorkingTree: evolution?.upgrade?.requireCleanWorkingTree ?? true,
        installCommand: evolution?.upgrade?.installCommand,
        buildCommand: evolution?.upgrade?.buildCommand,
        restartOnApply: evolution?.upgrade?.restartOnApply ?? true,
        approvalWindowStartHourUtc: evolution?.upgrade?.approvalWindowStartHourUtc,
        approvalWindowEndHourUtc: evolution?.upgrade?.approvalWindowEndHourUtc,
        approvedWeekdaysUtc: evolution?.upgrade?.approvedWeekdaysUtc,
        rolloutPercentage: evolution?.upgrade?.rolloutPercentage ?? 100,
        rolloutSeed: evolution?.upgrade?.rolloutSeed,
        healthCheckCommands: evolution?.upgrade?.healthCheckCommands ?? [],
        minHealthChecksPassing: evolution?.upgrade?.minHealthChecksPassing ?? 0,
        verificationCommands: evolution?.upgrade?.verificationCommands ?? [],
        minVerificationChecksPassing: evolution?.upgrade?.minVerificationChecksPassing ?? 0,
        autoRollbackOnVerificationFailure: evolution?.upgrade?.autoRollbackOnVerificationFailure ?? false,
        respectAutomationPolicies: true,
    };
    const schedulerEnabled = Boolean(evolution?.scheduler?.enabled
        || sourceRepoConfig.enabled
        || codeGenerationConfig.enabled
        || codeRepoConfig.enabled
        || releaseConfig.enabled
        || upgradeConfig.enabled);
    if (schedulerEnabled) {
        log.info({ evolutionMode }, 'Project evolution mode active');
        const gateAlertActionUrl = config.webui?.enabled !== false
            ? `http://${config.webui.host}:${config.webui.port}/`
            : null;
        const gateAlertNotifier = evolutionMode === 'source-owner' && Array.isArray(config.roles?.admin) && config.roles.admin.length > 0
            ? async (changes) => {
                try {
                    const delivered = await emitProjectEvolutionGateAlertNotifications(changes, {
                        adminPrincipals: config.roles?.admin ?? [],
                        workspaceId: 'project-evolution-private',
                        actionUrl: gateAlertActionUrl,
                    });
                    if (delivered.openedDelivered > 0 || delivered.resolvedDelivered > 0) {
                        log.warn({
                            opened: changes.opened.length,
                            resolved: changes.resolved.length,
                            openedDelivered: delivered.openedDelivered,
                            resolvedDelivered: delivered.resolvedDelivered,
                        }, 'Delivered private project evolution gate notifications');
                    }
                }
                catch (err) {
                    log.error({ err: String(err) }, 'Failed to deliver private project evolution gate notifications');
                }
            }
            : undefined;
        await startEvolutionScheduler({
            enabled: true,
            scoringIntervalHours: evolution?.scheduler?.scoringIntervalHours ?? 1,
            uploadIntervalHours: evolution?.scheduler?.uploadIntervalHours ?? 24,
            syncIntervalHours: evolution?.scheduler?.syncIntervalHours ?? ruleSyncConfig.syncIntervalHours,
            cleanupIntervalHours: evolution?.scheduler?.cleanupIntervalHours ?? 168,
            sourceRepoIntervalHours: evolution?.scheduler?.sourceRepoIntervalHours ?? 24,
            trackingCleanupDays: evolution?.scheduler?.trackingCleanupDays ?? 90,
        }, ruleSyncConfig, sourceRepoConfig, codeGenerationConfig, codeRepoConfig, releaseConfig, upgradeConfig, gateAlertNotifier);
    }
    else if (ruleSyncConfig.enabled) {
        await startPeriodicSync(ruleSyncConfig);
    }
    // ── Mother-body local activation ───────────────────────────────────────────
    // When GF_MOTHER_BODY_ACTIVE=true (and no full evolution scheduler is running),
    // activate the local import path: reads any existing capability bundle from the
    // local source repo path and imports it into the capability store.
    if (process.env['GF_MOTHER_BODY_ACTIVE'] === 'true' && !schedulerEnabled) {
        const activationResult = await activateMotherBodyLocal({
            repoPath: process.env['GF_SOURCE_REPO_PATH'] ?? process.cwd(),
            outputPath: config.evolution?.sourceRepo?.outputPath ?? '.greenfrog/evolution/rule_candidates.json',
        });
        log.info({ activationResult }, 'Mother-body local activation attempted');
    }
    // ── Mother-repo scheduler ───────────────────────────────────────────────────
    // Starts only if GF_MOTHER_REPO_SCHEDULER_ENABLED=true AND GF_MOTHER_REPO_PATH is set.
    // Safe to call unconditionally — the scheduler checks its own env gate.
    const motherRepoSchedulerStarted = startMotherRepoScheduler();
    if (motherRepoSchedulerStarted) {
        log.info({ motherRepoPath: process.env['GF_MOTHER_REPO_PATH'] ?? '(via config)' }, 'Mother-repo background scheduler started');
    }
    scheduler.setRunner(async (job) => {
        log.info({ jobId: job.id, name: job.name }, 'Running scheduled job');
        const runRec = createJobRun(job.id, job.name);
        const jobStart = Date.now();
        const msg = {
            id: nanoid(),
            channel: job.channel,
            userId: job.userId,
            chatId: job.chatId,
            text: job.prompt,
            timestamp: new Date(),
        };
        let resultText = '';
        let notified = false;
        try {
            const response = await runControlledAgentMessage(msg, 'scheduled_job');
            resultText = response.text ?? '';
            touchHeartbeat('scheduler', 'Scheduler', `job:${job.id}`);
            // ── Conditional notification (notify_if) ───────────────────────────────
            const notifyIf = job.notifyIf ?? 'always';
            const shouldNotify = matchesCondition(resultText, notifyIf, job.lastResult);
            if (shouldNotify && resultText) {
                await channelManager.send(job.channel, {
                    text: resultText,
                    chatId: job.chatId,
                }).catch((err) => {
                    log.error({ jobId: job.id, err }, 'Failed to deliver scheduled job response');
                });
                notified = true;
                log.info({ jobId: job.id, notifyIf, preview: resultText.slice(0, 100) }, 'Scheduled job response delivered');
            }
            else if (resultText) {
                log.info({ jobId: job.id, notifyIf }, 'Scheduled job ran silently (notify_if condition not met)');
            }
            // Persist last result for if_changed comparison
            if (notifyIf === 'if_changed' && resultText) {
                await memoryStore.updateJobLastResult(job.id, resultText);
            }
            completeJobRun(runRec.runId, resultText.slice(0, 500), notified, Date.now() - jobStart);
        }
        catch (err) {
            failJobRun(runRec.runId, String(err), Date.now() - jobStart);
            throw err;
        }
    });
    await scheduler.start();
    configureTeamRuntimeWakeups({
        debounceMs: 250,
        processWorkspace: async ({ workspaceId, reasons }) => {
            log.info({ workspaceId, reasons }, 'Event-driven team supervisor wakeup scheduled');
            await runTeamSupervisorCycleForWorkspace(workspaceId);
        },
        runAgentHeartbeat: async ({ workspaceId, agentId, reasons }) => {
            log.info({ workspaceId, agentId, reasons }, 'Event-driven agent heartbeat wakeup scheduled');
            await runAgentHeartbeatMonitorCycleForScope({ workspaceId, agentId });
        },
        // Fast-path: mailbox_created fires this instead of the full heartbeat.
        // Auto-acks passive messages (broadcast, task_event) with zero LLM cost;
        // runs a small focused LLM call for messages that require reasoning.
        processAgentMailbox: async ({ workspaceId, agentId, reasons }) => {
            const key = `${workspaceId}:${agentId}`;
            if (agentMailboxCycleRunning.has(key))
                return;
            agentMailboxCycleRunning.add(key);
            try {
                const result = await runAgentMailboxCycle({ workspaceId, agentId });
                if (result.acked > 0 || result.sent > 0) {
                    log.info({ workspaceId, agentId, reasons, ...result }, 'Mailbox fast-path cycle completed');
                }
            }
            catch (err) {
                log.error({ err, workspaceId, agentId }, 'Mailbox fast-path cycle failed');
            }
            finally {
                agentMailboxCycleRunning.delete(key);
            }
        },
    });
    // ── Stale task recovery — reset interrupted in_progress tasks ───────────────
    detectAndRecoverStaleTasks().then(({ recovered, details }) => {
        if (recovered > 0) {
            log.info({ recovered, details }, '[startup] Recovered stale tasks');
        }
    }).catch(() => { });
    // ── Workflow runner — schedule active workflows with cron triggers ─────────
    await startWorkflowRunner();
    // ── Patrol runner — check every minute, run due checks ───────────────────
    setInterval(async () => {
        await runPatrolCycle();
    }, 60_000);
    // ── Stale task recovery — periodic sweep every 15 min ─────────────────────
    setInterval(() => { void detectAndRecoverStaleTasks(); }, 15 * 60_000);
    setInterval(async () => {
        await runTeamSupervisorCycle();
    }, 30_000);
    // ── Fast-path: critical/high tasks dispatched within 5 s ─────────────────
    // The regular 30 s supervisor handles everything; this lighter cycle only
    // processes critical and high priority tasks so they aren't delayed.
    let urgentCycleRunning = false;
    setInterval(async () => {
        if (urgentCycleRunning)
            return;
        urgentCycleRunning = true;
        try {
            const processed = await processReadyTeamTasks(undefined, ['critical', 'high']);
            if (processed > 0) {
                log.info({ processed }, 'Urgent task cycle dispatched critical/high priority tasks');
            }
        }
        catch (err) {
            log.error({ err }, 'Urgent task cycle failed');
        }
        finally {
            urgentCycleRunning = false;
        }
    }, 5_000);
    setInterval(async () => {
        await runTeamNotificationRetryCycle();
    }, 30_000);
    setInterval(async () => {
        await runTeamApprovalMonitorCycle();
    }, 30_000);
    setInterval(async () => {
        await runAgentHeartbeatMonitorCycle();
    }, 60_000);
    setTimeout(() => {
        runBehavioralRuleMaintenanceCycle().catch((err) => {
            log.error({ err }, 'Startup behavioral rule maintenance cycle failed');
        });
    }, RULE_MAINTENANCE_STARTUP_DELAY_MS);
    setInterval(() => {
        runBehavioralRuleMaintenanceCycle().catch((err) => {
            log.error({ err }, 'Behavioral rule maintenance cycle failed');
        });
    }, RULE_MAINTENANCE_INTERVAL_MS);
    // ── Reminder delivery — check every 60 s ─────────────────────────────────
    setInterval(async () => {
        const due = await memoryStore.getDueReminders();
        for (const entry of due) {
            try {
                const reminder = JSON.parse(entry.value);
                await channelManager.send(reminder.channel, {
                    text: `⏰ **Reminder:** ${reminder.text}`,
                    chatId: reminder.chatId,
                });
                await memoryStore.markReminderDone(entry.userId, entry.channel, entry.key);
                log.info({ key: entry.key, userId: entry.userId }, 'Reminder delivered');
            }
            catch (err) {
                log.error({ err, key: entry.key }, 'Failed to deliver reminder');
            }
        }
    }, 60_000);
    // ── Stuck run governance — sweep every 60s ────────────────────────────────
    // Phase 1: mark runs > 120s as cancelled (signals the agent loop to stop)
    // Phase 2: force-GC runs that have been cancellation-pending for > 60s
    //          (cleans up activeRuns when the underlying async call never returns)
    setInterval(() => {
        const cancelled = cancelStuckRuns(120_000);
        if (cancelled > 0)
            log.warn({ cancelled }, 'Auto-cancelled stuck agent runs');
        const released = releaseStuckCancelledRuns(60_000);
        if (released > 0)
            log.warn({ released }, 'Force-released stuck-cancelled agent runs from activeRuns');
    }, 60_000);
    // ── Daily memory cleanup ──────────────────────────────────────────────────
    setInterval(() => {
        memoryStore.cleanup().catch((err) => log.error({ err }, 'Memory cleanup failed'));
    }, 24 * 3600 * 1000);
    // ── Daily auto-backup (only when enabled in config) ───────────────────────
    const backupCfg = config.backup;
    if (backupCfg?.autoBackup) {
        // Run once 5 minutes after startup, then every 24 hours
        setTimeout(async () => {
            const { autoBackup } = await import('./cli/commands/backup.js');
            await autoBackup();
            setInterval(async () => {
                const { autoBackup: ab } = await import('./cli/commands/backup.js');
                await ab();
            }, 24 * 3600 * 1000);
        }, 5 * 60 * 1000);
    }
    // ── Print startup summary ─────────────────────────────────────────────────
    const channelStatus = channelManager.getStatus();
    const activeChannels = Object.entries(channelStatus).filter(([, v]) => v).map(([k]) => k);
    console.log(chalk.bold('\n📊 Platform Status:'));
    console.log(`  ${chalk.cyan('Provider:')} ${config.defaultProvider} (${config.defaultModel})`);
    console.log(`  ${chalk.cyan('Skills:')} ${skillRegistry.list().length} loaded`);
    console.log(`  ${chalk.cyan('Channels:')} ${activeChannels.join(', ') || 'none'}`);
    if (gatewayEnabled) {
        console.log(`  ${chalk.cyan('Gateway:')} ws://${config.gateway.host}:${config.gateway.port}`);
    }
    if (webEnabled) {
        console.log(`  ${chalk.cyan('Web UI:')} http://${config.webui.host}:${config.webui.port}`);
    }
    console.log(chalk.green('\n✅ GreenFrog is ready!\n'));
    if (activeChannels.length === 0) {
        console.log(chalk.yellow('⚠️  No channels configured. Run: greenfrog setup'));
        console.log(chalk.yellow('   Or add tokens to your .env file.\n'));
    }
    // ── Global exception guards — prevent a single channel crash from killing the process ──
    process.on('uncaughtException', (err) => {
        log.error({ err: err.message }, 'Uncaught exception (process kept alive)');
    });
    process.on('unhandledRejection', (reason) => {
        log.error({ reason: String(reason) }, 'Unhandled rejection (process kept alive)');
    });
    // ── Graceful shutdown ─────────────────────────────────────────────────────
    const shutdown = async (signal) => {
        console.log(chalk.yellow(`\n${signal} received. Shutting down gracefully...`));
        dockerSandbox.stopHealthMonitor();
        scheduler.stopAll();
        stopMotherRepoScheduler();
        await closeQueue();
        await channelManager.stopAll();
        await gateway.stop();
        configureTeamRuntimeWakeups(null);
        await memoryStore.close();
        console.log(chalk.green('Goodbye! 🐸'));
        process.exit(0);
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    // Keep the process alive
    await new Promise(() => { });
}
// ─── Workflow Runner ───────────────────────────────────────────────────────────
/** Schedule all active workflows that have cron triggers. */
async function startWorkflowRunner() {
    const workflows = (await memoryStore.getWorkflows()).filter((wf) => wf.status === 'active' && wf.trigger !== 'manual');
    for (const wf of workflows) {
        scheduleWorkflow(wf);
    }
    log.info({ count: workflows.length }, 'Workflows scheduled');
}
// In-process map for workflow cron tasks
const workflowTasks = new Map();
function workflowRuntimeContext(wf) {
    return {
        userId: wf.userId,
        channel: wf.channel,
        workspaceId: `workflow:${wf.id}`,
    };
}
export function scheduleWorkflow(wf) {
    const taskKey = `wf:${wf.id}`;
    const existing = workflowTasks.get(taskKey);
    if (existing) {
        existing.stop();
        workflowTasks.delete(taskKey);
    }
    if (!cron.validate(wf.trigger))
        return;
    const task = cron.schedule(wf.trigger, async () => {
        log.info({ workflowId: wf.id, name: wf.name }, 'Running workflow');
        const cronRec = createWorkflowRun(wf.id, wf.name, 'cron');
        const wfStart = Date.now();
        try {
            await executeWorkflow(wf, cronRec.runId);
            await memoryStore.updateWorkflowRun(wf.id);
            completeWorkflowRun(cronRec.runId, Date.now() - wfStart);
            touchHeartbeat('workflow-runner', 'Workflow Runner', `workflow:${wf.id}`);
        }
        catch (err) {
            failWorkflowRun(cronRec.runId, String(err), Date.now() - wfStart);
            log.error({ workflowId: wf.id, err }, 'Workflow execution failed');
            touchHeartbeat('workflow-runner', 'Workflow Runner', `workflow:${wf.id}`, String(err));
        }
    }, { scheduled: true, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone });
    workflowTasks.set(taskKey, task);
    log.info({ workflowId: wf.id, trigger: wf.trigger }, 'Workflow scheduled');
}
/** Execute a workflow: run each step sequentially, handle notify_if and stop_if. */
export async function executeWorkflow(wf, runId) {
    const context = {};
    for (const step of wf.steps) {
        // Render template variables from previous steps
        const prompt = renderTemplate(step.prompt, context);
        log.info({ workflowId: wf.id, stepId: step.id }, 'Executing workflow step');
        const stepStart = Date.now();
        const msg = {
            id: nanoid(),
            channel: wf.channel,
            userId: wf.userId,
            chatId: wf.chatId,
            text: prompt,
            timestamp: new Date(),
            metadata: {
                workspaceId: `workflow:${wf.id}`,
                sessionKey: `workflow:${wf.id}`,
            },
        };
        const response = await runControlledAgentMessage(msg, 'workflow_run');
        const resultText = response.text ?? '';
        // Save result for use in later steps
        const saveKey = step.saveAs ?? step.id;
        context[saveKey] = resultText;
        // Notify user if condition met
        const notifyIf = step.notifyIf ?? 'always';
        const runtimeCtx = workflowRuntimeContext(wf);
        const prevResult = await getScopedMemoryForContext(runtimeCtx, `wf_step:${wf.id}:${step.id}`);
        const didNotify = matchesCondition(resultText, notifyIf, prevResult ?? undefined) && !!resultText;
        if (didNotify) {
            await channelManager.send(wf.channel, {
                text: `🔄 **${wf.name}** › ${step.id}\n\n${resultText}`,
                chatId: wf.chatId,
            }).catch((err) => log.error({ err, workflowId: wf.id }, 'Failed to notify workflow step result'));
        }
        // Persist last result for if_changed
        if (notifyIf === 'if_changed' && resultText) {
            await setScopedMemoryForContext(runtimeCtx, `wf_step:${wf.id}:${step.id}`, resultText);
        }
        // Persist last result for stop_if if_changed (symmetric with notifyIf)
        if (step.stopIf === 'if_changed' && resultText) {
            await setScopedMemoryForContext(runtimeCtx, `wf_stop:${wf.id}:${step.id}`, resultText);
        }
        // Stop workflow if stop_if condition met
        const stopPrevResult = await getScopedMemoryForContext(runtimeCtx, `wf_stop:${wf.id}:${step.id}`);
        const didStop = !!(step.stopIf && matchesCondition(resultText, step.stopIf, stopPrevResult ?? undefined));
        // Write step result to run record
        if (runId) {
            addWorkflowStepResult(runId, {
                stepId: step.id,
                prompt,
                result: resultText.slice(0, 1000),
                notified: didNotify,
                stopped: didStop,
                durationMs: Date.now() - stepStart,
            });
        }
        if (didStop) {
            log.info({ workflowId: wf.id, stepId: step.id, stopIf: step.stopIf }, 'Workflow stopped by stop_if condition');
            break;
        }
    }
}
// Register executeWorkflow as the workflow executor so triggerWorkflowNow() (run_now)
// uses the same logic as the cron path.
registerWorkflowExecutor(async (wf, runId) => {
    const start = Date.now();
    try {
        await executeWorkflow(wf, runId);
        await memoryStore.updateWorkflowRun(wf.id);
        completeWorkflowRun(runId, Date.now() - start);
        touchHeartbeat('workflow-runner', 'Workflow Runner', `workflow:${wf.id}`);
    }
    catch (err) {
        failWorkflowRun(runId, String(err), Date.now() - start);
        touchHeartbeat('workflow-runner', 'Workflow Runner', `workflow:${wf.id}`, String(err));
        throw err;
    }
});
// ─── Patrol Runner ────────────────────────────────────────────────────────────
async function runPatrolCycle() {
    const now = Date.now();
    const checks = (await memoryStore.getPatrolChecks()).filter((c) => c.status === 'active');
    for (const check of checks) {
        // Only run if enough time has passed since last check
        const lastCheckMs = check.lastCheck?.getTime() ?? 0;
        if (now - lastCheckMs < check.intervalMin * 60_000)
            continue;
        try {
            const result = await runCheck(check);
            const wasOk = check.lastStatus === 'ok' || check.lastStatus === undefined;
            const newFailures = result.ok ? 0 : check.consecutiveFailures + 1;
            const newStatus = result.ok ? 'ok' : (result.error?.includes('timeout') ? 'timeout' : 'error');
            await memoryStore.savePatrolResult({
                checkId: check.id, ok: result.ok,
                statusCode: result.statusCode, latencyMs: result.latencyMs, error: result.error,
            });
            await memoryStore.updatePatrolResult(check.id, result.ok, newStatus, newFailures);
            // Alert: when consecutive failures reach threshold
            if (!result.ok && newFailures >= check.alertThreshold) {
                const alertText = `🚨 **巡检告警: ${check.name}**\n\n` +
                    `目标: ${check.target}\n` +
                    `状态: ${newStatus === 'timeout' ? '超时' : '错误'}\n` +
                    `错误: ${result.error ?? '未知'}\n` +
                    `响应时间: ${result.latencyMs}ms\n` +
                    `连续失败: ${newFailures} 次\n` +
                    `时间: ${new Date().toLocaleString()}`;
                await channelManager.send(check.channel, { text: alertText, chatId: check.chatId })
                    .catch((err) => log.error({ checkId: check.id, err }, 'Failed to deliver patrol alert'));
                log.warn({ checkId: check.id, name: check.name, failures: newFailures }, 'Patrol alert sent');
            }
            // Recovery notification: was down, now ok
            if (result.ok && !wasOk && check.consecutiveFailures > 0) {
                const recoveryText = `✅ **巡检恢复: ${check.name}**\n\n` +
                    `目标: ${check.target}\n` +
                    `响应时间: ${result.latencyMs}ms\n` +
                    `时间: ${new Date().toLocaleString()}`;
                await channelManager.send(check.channel, { text: recoveryText, chatId: check.chatId })
                    .catch((err) => log.error({ checkId: check.id, err }, 'Failed to deliver patrol recovery'));
            }
        }
        catch (err) {
            log.error({ checkId: check.id, err }, 'Patrol check threw unexpected error');
        }
    }
}
async function runTeamSupervisorCycle() {
    if (teamSupervisorRunning)
        return;
    teamSupervisorRunning = true;
    try {
        const protocol = await processTeamSwarmProtocol();
        const handoffs = await processOnCallTaskHandoffs();
        const processed = await processReadyTeamTasks();
        if (protocol > 0) {
            log.info({ processed: protocol }, 'Team supervisor cycle applied swarm protocol rules');
        }
        if (handoffs > 0) {
            log.info({ processed: handoffs }, 'Team supervisor cycle rotated on-call tasks');
        }
        if (processed > 0) {
            log.info({ processed }, 'Team supervisor cycle processed ready tasks');
        }
    }
    catch (err) {
        log.error({ err }, 'Team supervisor cycle failed');
    }
    finally {
        teamSupervisorRunning = false;
    }
}
async function runTeamSupervisorCycleForWorkspace(workspaceId) {
    if (!workspaceId || teamSupervisorWorkspaceRunning.has(workspaceId))
        return;
    teamSupervisorWorkspaceRunning.add(workspaceId);
    try {
        const protocol = await processTeamSwarmProtocol(workspaceId);
        const handoffs = await processOnCallTaskHandoffs(workspaceId);
        const processed = await processReadyTeamTasks(workspaceId);
        const approvals = await processPendingTeamApprovals(workspaceId);
        if (protocol > 0 || handoffs > 0 || processed > 0 || approvals > 0) {
            log.info({ workspaceId, protocol, handoffs, processed, approvals }, 'Event-driven workspace supervisor cycle completed');
        }
    }
    catch (err) {
        log.error({ err, workspaceId }, 'Event-driven workspace supervisor cycle failed');
    }
    finally {
        teamSupervisorWorkspaceRunning.delete(workspaceId);
    }
}
async function runTeamNotificationRetryCycle() {
    if (teamNotificationRetryRunning)
        return;
    teamNotificationRetryRunning = true;
    try {
        const processed = await retryPendingTeamNotifications();
        if (processed > 0) {
            log.info({ processed }, 'Team notification retry cycle processed pending deliveries');
        }
    }
    catch (err) {
        log.error({ err }, 'Team notification retry cycle failed');
    }
    finally {
        teamNotificationRetryRunning = false;
    }
}
async function runTeamApprovalMonitorCycle() {
    if (teamApprovalMonitorRunning)
        return;
    teamApprovalMonitorRunning = true;
    try {
        const processed = await processPendingTeamApprovals();
        if (processed > 0) {
            log.info({ processed }, 'Team approval monitor cycle processed reminders/escalations');
        }
    }
    catch (err) {
        log.error({ err }, 'Team approval monitor cycle failed');
    }
    finally {
        teamApprovalMonitorRunning = false;
    }
}
async function runAgentHeartbeatMonitorCycle() {
    if (agentHeartbeatRunning)
        return;
    agentHeartbeatRunning = true;
    try {
        const result = await runAgentHeartbeatCycle();
        if (result.processed > 0 || result.errors > 0) {
            log.info(result, 'Agent heartbeat cycle completed');
        }
    }
    catch (err) {
        log.error({ err }, 'Agent heartbeat cycle failed');
    }
    finally {
        agentHeartbeatRunning = false;
    }
}
async function runAgentHeartbeatMonitorCycleForScope(params) {
    const key = params.agentId ? `${params.workspaceId}:${params.agentId}` : params.workspaceId;
    if (!params.workspaceId || agentHeartbeatScopeRunning.has(key))
        return;
    agentHeartbeatScopeRunning.add(key);
    try {
        const result = await runAgentHeartbeatCycle({
            workspaceId: params.workspaceId,
            agentId: params.agentId,
        });
        if (result.processed > 0 || result.errors > 0 || result.actionable > 0) {
            log.info({ ...params, ...result }, 'Event-driven agent heartbeat cycle completed');
        }
    }
    catch (err) {
        log.error({ err, ...params }, 'Event-driven agent heartbeat cycle failed');
    }
    finally {
        agentHeartbeatScopeRunning.delete(key);
    }
}
//# sourceMappingURL=index.js.map