/**
 * Memory Extraction Task Queue with Backpressure
 *
 * Prevents memory extraction tasks from piling up under high load by:
 * - Limiting concurrent extraction tasks
 * - Queueing tasks with priority
 * - Rejecting new tasks when queue is full (backpressure)
 * - Graceful degradation under load
 */
import type { ChannelName, MemoryScope } from '../utils/types.js';
export interface ExtractionTask {
    id: string;
    userId: string;
    channel: ChannelName;
    userMessage: string;
    assistantResponse: string;
    previousAiMessage?: string;
    memoryScope?: MemoryScope;
    priority: number;
    createdAt: number;
    retryCount?: number;
}
export interface QueueStats {
    queueSize: number;
    activeCount: number;
    totalProcessed: number;
    totalRejected: number;
    totalRetried: number;
    avgProcessingTimeMs: number;
}
export declare class ExtractionQueue {
    private queue;
    private activeCount;
    private totalProcessed;
    private totalRejected;
    private totalRetried;
    private processingTimes;
    private readonly maxQueueSize;
    private readonly maxConcurrent;
    private readonly maxRetries;
    private readonly processingTimeWindow;
    constructor(maxQueueSize?: number, maxConcurrent?: number, maxRetries?: number);
    /**
     * Enqueue a new extraction task
     * Returns true if enqueued, false if rejected (backpressure)
     */
    enqueue(task: ExtractionTask): boolean;
    /**
     * Process next task if capacity available
     */
    private processNext;
    private recordProcessingTime;
    /**
     * Get queue statistics
     */
    getStats(): QueueStats;
    /**
     * Check if queue is under pressure (>80% full)
     */
    isUnderPressure(): boolean;
}
export declare const extractionQueue: ExtractionQueue;
/**
 * Calculate task priority based on message characteristics
 */
export declare function calculatePriority(userMessage: string, assistantResponse: string): number;
//# sourceMappingURL=extraction_queue.d.ts.map