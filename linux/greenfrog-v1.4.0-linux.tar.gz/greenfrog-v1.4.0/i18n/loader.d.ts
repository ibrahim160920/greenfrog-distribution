/**
 * i18n loader for GreenFrog child distribution system.
 *
 * Key design decisions:
 *   - Locale JSON files use nested objects; they are flattened to dot-notation keys at load time.
 *   - Fallback chain: <full-locale> → <language-only> → 'en'
 *     e.g. zh-CN → zh → en; pt-BR → pt → en; en-GB → en
 *   - Variable interpolation: {key} in message strings.
 *   - Missing keys fall back to the key itself (never throws).
 *   - All locale files are loaded lazily and cached.
 */
import { type SupportedLocale } from './types.js';
/**
 * Resolve a raw locale string to a supported locale + fallback chain.
 * 'zh-CN' → ['zh-CN', 'zh', 'en']
 * 'pt-BR' → ['pt-BR', 'pt', 'en']
 * 'en-GB' → ['en-GB', 'en']
 * 'en'    → ['en']
 * unknown → ['en']
 */
export declare function resolveLocaleChain(raw: string): string[];
export declare class I18n {
    private _locale;
    private _messages;
    private _fallbackMessages;
    constructor(locale?: string);
    /** Return the currently active locale code. */
    get locale(): string;
    /** Switch to a different locale. */
    setLocale(locale: string): void;
    /**
     * Translate a dot-notation key with optional variable interpolation.
     * t('firstBoot.title')
     * t('update.version', { version: '1.2.0' })
     *
     * Falls back to key if missing in all locales.
     */
    t(key: string, vars?: Record<string, string>): string;
    /** Load messages for the current locale chain. */
    private _loadMessages;
}
export declare function detectSystemLocale(): SupportedLocale | string;
export declare function getI18n(locale?: string): I18n;
export declare function resetI18n(): void;
//# sourceMappingURL=loader.d.ts.map