/**
 * Verdict derivation for GreenFrog Harness Engineering (P3/P3-A).
 *
 * Design principle (P3-A):
 *   - Default to automatic acceptance. Human intervention only for
 *     true contradictions and explicitly required reviews.
 *   - `needs_review` is deliberately narrow — not a catch-all.
 *   - Human decisions (approved / rejected / retry_requested) stored in
 *     task.metadata and always take precedence over the system verdict.
 *
 * Separation of concerns:
 *   - `status`        = operational state (what the system is doing)
 *   - `verdict`       = acceptance result (did the task produce an acceptable outcome?)
 *   - `verdictSource` = who made the call — 'system' (automatic) or 'human' (override)
 *
 * This is a pure function — no I/O, no DB access.
 */
// ── Human decision helpers ───────────────────────────────────────────────────
function extractHumanDecision(task) {
    const m = task.metadata ?? {};
    const decision = typeof m['lastHumanDecision'] === 'string'
        ? m['lastHumanDecision']
        : undefined;
    const at = typeof m['lastHumanDecisionAt'] === 'string' ? m['lastHumanDecisionAt'] : undefined;
    const by = typeof m['lastHumanDecisionBy'] === 'string' ? m['lastHumanDecisionBy'] : undefined;
    const reason = typeof m['lastHumanDecisionReason'] === 'string' ? m['lastHumanDecisionReason'] : undefined;
    return { decision, at, by, reason };
}
// ── Core function ───────────────────────────────────────────────────────────
export function deriveVerdict(task, runtime) {
    const { status, resultSummary, blockedReason, escalationReason, escalationStatus, reviewStatus, } = task;
    const hd = extractHumanDecision(task);
    const humanBase = hd.decision
        ? {
            humanDecision: hd.decision,
            humanDecisionAt: hd.at,
            humanDecisionBy: hd.by,
            humanDecisionReason: hd.reason,
        }
        : {};
    // ── ① Human decision always wins ──────────────────────────────────────────
    //
    // If a human has already made a call, we honour it.
    // The system verdict becomes the context, human verdict is the ruling.
    if (hd.decision === 'approved') {
        return {
            verdict: 'success',
            reason: hd.reason ? `人工确认通过：${hd.reason}` : '人工确认通过',
            needsHuman: false,
            verdictSource: 'human',
            ...humanBase,
        };
    }
    if (hd.decision === 'rejected') {
        return {
            verdict: 'failed',
            reason: hd.reason ? `人工标记不合格：${hd.reason}` : '人工标记不合格',
            needsHuman: false,
            verdictSource: 'human',
            ...humanBase,
        };
    }
    if (hd.decision === 'retry_requested') {
        // Retry was requested — the task should be running or queued again.
        // Report as needs_review until it completes.
        return {
            verdict: 'needs_review',
            reason: hd.reason ? `已请求重跑：${hd.reason}` : '已请求重跑，等待新结果',
            needsHuman: false, // system will handle the retry; no further human action
            verdictSource: 'human',
            ...humanBase,
        };
    }
    // ── ② Still running — too early to judge ──────────────────────────────────
    if (runtime.isRunning || status === 'in_progress') {
        return {
            verdict: 'unknown',
            reason: '任务执行中，结果待定',
            needsHuman: false,
            verdictSource: 'system',
        };
    }
    // ── ③ Blocked or escalated ────────────────────────────────────────────────
    if (status === 'blocked' || status === 'escalated' || escalationStatus === 'pending') {
        const detail = blockedReason ?? escalationReason ?? '无详细说明';
        return {
            verdict: 'blocked',
            reason: `任务被阻塞：${detail}`,
            needsHuman: true,
            verdictSource: 'system',
        };
    }
    // ── ④ Cancelled — system is certain ──────────────────────────────────────
    if (status === 'cancelled') {
        return {
            verdict: 'failed',
            reason: '任务已取消',
            needsHuman: false, // intentional cancellation — no human action needed
            verdictSource: 'system',
        };
    }
    // ── ⑤ Explicitly required review ─────────────────────────────────────────
    //
    // Only flag needs_review when it was explicitly required
    // (e.g. reviewRequired flag set on task creation or template-level policy).
    if (reviewStatus === 'pending' || status === 'review_pending') {
        return {
            verdict: 'needs_review',
            reason: '此任务已标记为需要人工审核',
            needsHuman: true,
            verdictSource: 'system',
        };
    }
    // review_approved / changes_requested are final human decisions already reflected via metadata above
    // (they should have set lastHumanDecision too, but handle the edge case)
    if (reviewStatus === 'approved') {
        return {
            verdict: 'success',
            reason: '已通过人工审核',
            needsHuman: false,
            verdictSource: 'human',
        };
    }
    if (reviewStatus === 'changes_requested') {
        return {
            verdict: 'failed',
            reason: '人工审核要求修改，结果不合格',
            needsHuman: false,
            verdictSource: 'human',
        };
    }
    // ── ⑥ Done — evidence-priority acceptance ────────────────────────────────
    //
    // P4.4 update:
    //   Priority: evidence > textual > summary
    //   If evidence checks ran:
    //     evidence_verified → success (verdictSource='evidence', skip confidence gate)
    //     evidence_failed   → needs_review (evidence contradicts "done" status)
    //   If no evidence checks, fall through to confidence gate.
    //
    if (status === 'done') {
        const traceError = runtime.trace?.status === 'error' || runtime.trace?.errorMessage;
        const runError = runtime.lastRunError || runtime.lastRunStatus === 'error';
        if (traceError || runError) {
            const errMsg = runtime.lastRunError ?? runtime.trace?.errorMessage ?? '运行错误';
            return {
                verdict: 'needs_review',
                reason: `任务标记完成，但运行中有错误（矛盾信号）：${errMsg}`,
                needsHuman: true,
                verdictSource: 'system',
            };
        }
        // ── Risky gate ①: requiresHumanApproval — always route to needs_review ──
        //
        // Tasks created with expectedAutoAccept=false set this flag so the harness
        // (and any run_now path) can never auto-accept them.
        if (task.metadata?.['requiresHumanApproval'] === true) {
            return {
                verdict: 'needs_review',
                reason: '此任务标记为需要人工审核（requiresHumanApproval），不允许系统自动验收',
                needsHuman: true,
                verdictSource: 'system',
            };
        }
        // ── P4.4: Evidence-based verdict ────────────────────────────────────────
        const verificationMode = typeof task.metadata?.['verificationMode'] === 'string'
            ? task.metadata['verificationMode']
            : null;
        // P4.5: read evidenceSeverity for richer verdict
        const evidenceSeverity = typeof task.metadata?.['evidenceSeverity'] === 'string'
            ? task.metadata['evidenceSeverity']
            : null;
        const hasAutoGenChecks = task.metadata?.['hasAutoGeneratedChecks'] === true;
        if (verificationMode === 'evidence_verified') {
            // Hard proof: real-world checks passed — auto-accept regardless of confidence
            const checksPassed = typeof task.metadata?.['acceptanceChecksPassed'] === 'number'
                ? task.metadata['acceptanceChecksPassed'] : null;
            const checksTotal = typeof task.metadata?.['acceptanceChecksTotal'] === 'number'
                ? task.metadata['acceptanceChecksTotal'] : null;
            const checksNote = checksPassed !== null && checksTotal !== null
                ? ` (${checksPassed}/${checksTotal} 项)`
                : '';
            const severityNote = evidenceSeverity === 'hard_verified' ? '（硬验证）' : '（软验证）';
            const autoNote = hasAutoGenChecks ? '，验收条件自动推断' : '';
            return {
                verdict: 'success',
                reason: `证据验证通过${checksNote}${severityNote}${autoNote}，系统自动验收`,
                needsHuman: false,
                verdictSource: 'evidence',
            };
        }
        if (verificationMode === 'evidence_failed') {
            // Evidence explicitly failed — evidence contradicts "done" status
            const evidenceRecords = Array.isArray(task.metadata?.['acceptanceEvidence'])
                ? task.metadata['acceptanceEvidence']
                : [];
            const contradictedRecord = evidenceRecords.find(r => r && r.severity === 'contradicted');
            const failDetail = contradictedRecord?.reason
                ?? evidenceRecords.find(r => r && typeof r === 'object')?.reason
                ?? '证据验证未通过';
            const isContradicted = evidenceSeverity === 'contradicted';
            return {
                verdict: 'needs_review',
                reason: isContradicted
                    ? `证据与声明矛盾（${failDetail.slice(0, 100)}）——文件系统状态与任务完成声明不符`
                    : `证据验证失败（${failDetail.slice(0, 100)}），需确认`,
                needsHuman: true,
                verdictSource: 'evidence',
            };
        }
        // ── Risky gate ②: requiresEvidence — must have real evidence verification ─
        //
        // File/config/artifact tasks where the creator declares real-world I/O
        // verification is required. Text summaries alone are insufficient.
        if (task.metadata?.['requiresEvidence'] === true && verificationMode !== 'evidence_verified') {
            return {
                verdict: 'needs_review',
                reason: '此任务要求证据验证（requiresEvidence），但尚未通过文件/配置实际检查',
                needsHuman: true,
                verdictSource: 'system',
            };
        }
        // ── P4.1/P4.4: Confidence gate (textual / unverifiable path) ────────────
        const contractMeta = task.metadata?.['contract'];
        const doneCriteria = Array.isArray(contractMeta?.doneCriteria)
            ? contractMeta.doneCriteria
            : [];
        const confidence = typeof task.metadata?.['confidence'] === 'number'
            ? task.metadata['confidence']
            : null;
        // ── Risky gate ③: unverifiable + artifact-signal title ───────────────────
        //
        // If NO verifiable evidence ran at all (verificationMode=unverifiable,
        // meaning no doneCriteria AND no acceptance checks), AND the task title
        // contains keywords suggesting real file/config/artifact output, do not
        // auto-accept. This is the conservative default for tasks that should have
        // produced real I/O but were never explicitly flagged.
        //
        // Evidence-verified tasks escaped above. Tasks with doneCriteria use the
        // confidence gate below. This only fires when both are absent.
        if (verificationMode === 'unverifiable' && doneCriteria.length === 0) {
            const titleLower = (task.title ?? '').toLowerCase();
            const ARTIFACT_KEYWORDS = [
                'file', 'config', 'report', 'csv', 'json', 'yaml', 'yml',
                'write', 'create', 'generate', 'output', 'artifact', 'export',
                '文件', '配置', '报告', '生成', '创建', '写入', '导出',
            ];
            if (ARTIFACT_KEYWORDS.some(kw => titleLower.includes(kw))) {
                return {
                    verdict: 'needs_review',
                    reason: '任务提示应产生实际输出（文件/配置/报告等），但未通过任何可验证检查，建议人工确认',
                    needsHuman: true,
                    verdictSource: 'system',
                };
            }
        }
        if (doneCriteria.length > 0 && confidence !== null && confidence < 0.45) {
            const pct = (confidence * 100).toFixed(0);
            return {
                verdict: 'needs_review',
                reason: `任务完成，但完成标准覆盖置信度偏低（${pct}%），建议人工确认`,
                needsHuman: true,
                verdictSource: 'textual',
            };
        }
        // No error, confidence acceptable — auto-approve.
        const isTextual = verificationMode === 'summary_verified' || verificationMode === 'summary_failed';
        const sourceLabel = isTextual ? '摘要分析' : '系统';
        const criteriaNote = doneCriteria.length > 0 && confidence !== null
            ? `，完成标准覆盖置信度 ${(confidence * 100).toFixed(0)}%`
            : '';
        const severityNote = evidenceSeverity === 'soft_verified' ? '（软验证）'
            : evidenceSeverity === 'unverifiable' ? '（未验证）'
                : '';
        const autoNote = hasAutoGenChecks ? '，验收条件自动推断' : '';
        const autoReason = resultSummary && resultSummary.trim().length > 10
            ? `任务完成，含结果摘要${criteriaNote}${severityNote}${autoNote}（${sourceLabel}自动验收）`
            : `任务完成${criteriaNote}${severityNote}${autoNote}（${sourceLabel}自动验收，无错误信号）`;
        return {
            verdict: 'success',
            reason: autoReason,
            needsHuman: false,
            verdictSource: isTextual ? 'textual' : 'system',
        };
    }
    // ── ⑦ Non-done with clear run error — system is certain it failed ─────────
    if (runtime.lastRunStatus === 'error' || runtime.trace?.status === 'error') {
        const errMsg = runtime.lastRunError ?? runtime.trace?.errorMessage ?? '未知错误';
        return {
            verdict: 'failed',
            reason: `运行失败：${errMsg}`,
            needsHuman: false, // system is certain — no human needed to confirm failure
            verdictSource: 'system',
        };
    }
    // ── ⑧ Pending states — not yet run ───────────────────────────────────────
    if (['todo', 'open', 'proposed', 'claimed', 'assigned'].includes(status)) {
        return {
            verdict: 'unknown',
            reason: '任务尚未执行',
            needsHuman: false,
            verdictSource: 'system',
        };
    }
    return {
        verdict: 'unknown',
        reason: '结果状态未知',
        needsHuman: false,
        verdictSource: 'system',
    };
}
// ── Display helpers ──────────────────────────────────────────────────────────
export const VERDICT_LABEL = {
    success: '验收通过',
    failed: '执行失败',
    blocked: '已阻塞',
    needs_review: '待人工核验',
    unknown: '结果待定',
};
export const VERDICT_COLOR = {
    success: '#57c88a',
    failed: '#f85149',
    blocked: '#e3b341',
    needs_review: '#79c0ff',
    unknown: '#768390',
};
export const HUMAN_DECISION_LABEL = {
    approved: '人工确认通过',
    rejected: '人工标记不合格',
    retry_requested: '已请求重跑',
};
//# sourceMappingURL=verdict.js.map