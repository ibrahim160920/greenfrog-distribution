/**
 * Verdict derivation for GreenFrog Harness Engineering (P3/P3-A).
 *
 * Design principle (P3-A):
 *   - Default to automatic acceptance. Human intervention only for
 *     true contradictions and explicitly required reviews.
 *   - `needs_review` is deliberately narrow — not a catch-all.
 *   - Human decisions (approved / rejected / retry_requested) stored in
 *     task.metadata and always take precedence over the system verdict.
 *
 * Separation of concerns:
 *   - `status`        = operational state (what the system is doing)
 *   - `verdict`       = acceptance result (did the task produce an acceptable outcome?)
 *   - `verdictSource` = who made the call — 'system' (automatic) or 'human' (override)
 *
 * This is a pure function — no I/O, no DB access.
 */
import type { TeamTask } from '../utils/types.js';
export type Verdict = 'success' | 'failed' | 'blocked' | 'needs_review' | 'unknown';
export type HumanDecision = 'approved' | 'rejected' | 'retry_requested';
/**
 * P4.4: Expanded verdict source.
 *   evidence  — real-world I/O verification determined the outcome
 *   textual   — keyword / structural heuristics determined the outcome
 *   system    — general system determination (non-done states: blocked, running, etc.)
 *   human     — human override
 */
export type VerdictSource = 'evidence' | 'textual' | 'system' | 'human';
export interface VerdictResult {
    verdict: Verdict;
    reason: string;
    /** Whether human intervention is still needed */
    needsHuman: boolean;
    /** Who made the determination */
    verdictSource: VerdictSource;
    /** Human override, if any */
    humanDecision?: HumanDecision;
    humanDecisionAt?: string;
    humanDecisionBy?: string;
    humanDecisionReason?: string;
}
interface RuntimeSnapshot {
    isRunning: boolean;
    lastRunStatus?: string | null;
    lastRunError?: string | null;
    trace?: {
        status: string;
        errorMessage?: string | null;
        toolCallCount?: number;
        providerCallCount?: number;
        durationMs?: number | null;
    } | null;
}
export declare function deriveVerdict(task: TeamTask, runtime: RuntimeSnapshot): VerdictResult;
export declare const VERDICT_LABEL: Record<Verdict, string>;
export declare const VERDICT_COLOR: Record<Verdict, string>;
export declare const HUMAN_DECISION_LABEL: Record<HumanDecision, string>;
export {};
//# sourceMappingURL=verdict.d.ts.map