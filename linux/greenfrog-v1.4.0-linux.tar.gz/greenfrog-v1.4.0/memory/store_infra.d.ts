import Database from 'better-sqlite3';
export declare function createInfraStore(db: Database.Database, rlCache: Map<string, {
    count: number;
    resetAt: number;
}>): {
    checkRateLimit(key: string, limit: number, windowMs: number): boolean;
    cleanupRateLimits(): void;
    trackError(opts: {
        level?: "error" | "warn";
        message: string;
        context?: Record<string, unknown>;
        stack?: string;
        userId?: string;
        channel?: string;
    }): void;
    getRecentErrors(limit?: number): Array<{
        id: string;
        level: string;
        message: string;
        context: Record<string, unknown> | null;
        userId: string | null;
        channel: string | null;
        createdAt: Date;
    }>;
    logAudit(entry: {
        userId: string;
        channel: string;
        chatId?: string;
        skillName: string;
        params?: Record<string, unknown>;
        success: boolean;
        durationMs: number;
        error?: string;
        role?: string;
    }): void;
    queryAuditLog(opts: {
        userId?: string;
        skillName?: string;
        channel?: string;
        success?: boolean;
        sinceMs?: number;
        limit?: number;
    }): Array<{
        id: string;
        timestamp: Date;
        userId: string;
        channel: string;
        chatId: string | null;
        skillName: string;
        params: Record<string, unknown> | null;
        success: boolean;
        durationMs: number;
        error: string | null;
        role: string | null;
    }>;
    getSkillStats(): Array<{
        skillName: string;
        callCount: number;
        successCount: number;
        successRate: number;
        avgDurationMs: number;
        lastCalledAt: Date | null;
    }>;
    getAuthRevokedAfter(userId: string): number | null;
    revokeAuthSessions(userId: string, opts?: {
        revokedAfter?: number;
        revokedBy?: string;
        reason?: string;
    }): void;
    recordTokenUsage(record: {
        userId: string;
        workspaceId?: string | null;
        agentId?: string | null;
        provider: string;
        model: string;
        inputTokens: number;
        outputTokens: number;
        costUsd?: number | null;
        channel?: string | null;
        sessionKey?: string | null;
    }): void;
    getTokenUsageSummary(filter: {
        userId?: string;
        workspaceId?: string;
        period?: string;
    }): Array<{
        scopeType: string;
        scopeId: string;
        period: string;
        totalInputTokens: number;
        totalOutputTokens: number;
        totalTokens: number;
        totalCostUsd: number | null;
        callCount: number;
    }>;
    getTokenUsageDetail(filter: {
        userId?: string;
        workspaceId?: string;
        limit?: number;
        offset?: number;
    }): Array<{
        id: string;
        userId: string;
        workspaceId: string | null;
        agentId: string | null;
        provider: string;
        model: string;
        inputTokens: number;
        outputTokens: number;
        totalTokens: number;
        costUsd: number | null;
        channel: string | null;
        sessionKey: string | null;
        recordedAt: Date;
    }>;
    setUserQuota(quota: {
        scopeType: "user" | "workspace";
        scopeId: string;
        monthlyTokenLimit?: number | null;
        monthlyCostLimitUsd?: number | null;
        limitBehavior?: "soft" | "hard";
    }): void;
    getUserQuota(scopeType: "user" | "workspace", scopeId: string): {
        scopeType: "user" | "workspace";
        scopeId: string;
        monthlyTokenLimit: number | null;
        monthlyCostLimitUsd: number | null;
        limitBehavior: "soft" | "hard";
        updatedAt: Date;
    } | null;
    listUserQuotas(): Array<{
        scopeType: "user" | "workspace";
        scopeId: string;
        monthlyTokenLimit: number | null;
        monthlyCostLimitUsd: number | null;
        limitBehavior: "soft" | "hard";
        updatedAt: Date;
    }>;
    addWorkspaceMember(workspaceId: string, userId: string, role: "owner" | "member" | "viewer"): void;
    removeWorkspaceMember(workspaceId: string, userId: string): void;
    getWorkspaceMembership(workspaceId: string, userId: string): {
        role: "owner" | "member" | "viewer";
    } | null;
    listWorkspaceMembers(workspaceId: string): Array<{
        userId: string;
        role: string;
        joinedAt: Date;
    }>;
    listUserWorkspaces(userId: string): Array<{
        workspaceId: string;
        role: string;
        joinedAt: Date;
    }>;
};
//# sourceMappingURL=store_infra.d.ts.map