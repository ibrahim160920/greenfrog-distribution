/**
 * Artifact Protocol for GreenFrog P4.5.
 *
 * A TaskArtifact is a structured record of something a task produced:
 *   a file, a JSON result, a report, a config patch, etc.
 *
 * Artifacts serve as:
 *   1. Evidence anchors — acceptance checks can target artifact.path directly
 *   2. Downstream inputs — later tasks can reference a prior task's artifact
 *   3. Audit trail — system knows what each run actually produced
 *
 * Artifacts can come from:
 *   - auto_detected: extracted from resultSummary via pattern matching (best-effort)
 *   - agent_declared: agent explicitly emits a structured artifact block
 *
 * Written to metadata.artifacts[]. No DB migration required.
 *
 * Auto-detection is CONSERVATIVE:
 *   Only extract paths where there is clear action language nearby
 *   (created/wrote/generated/saved/output) AND a recognized file extension.
 *   Aim for zero false positives over maximum recall.
 */
export type ArtifactType = 'file' | 'json' | 'report' | 'config' | 'patch' | 'dataset' | 'unknown';
export interface TaskArtifact {
    /** Short unique ID for this artifact (within the task) */
    id: string;
    type: ArtifactType;
    /** Human-readable name (filename or label) */
    name: string;
    /** Absolute or relative file path, if applicable */
    path?: string;
    /** MIME type hint (e.g. 'application/json', 'text/markdown') */
    mime?: string;
    /** Format label (e.g. 'json', 'markdown', 'csv') */
    format?: string;
    /** Brief description of what this artifact contains */
    summary?: string;
    producedAt: string;
    sourceRunId: string;
    /** How this artifact was discovered */
    detectionMethod: 'auto_detected' | 'agent_declared';
}
/**
 * Extract artifacts from a resultSummary string.
 * Conservative: only extract paths with recognized extensions in action contexts.
 * Returns deduplicated list.
 */
export declare function detectArtifactsFromSummary(summary: string, sourceRunId: string): TaskArtifact[];
/**
 * Parse agent-declared artifacts from a structured block in resultSummary.
 *
 * Agents can emit a JSON block like:
 *   ```artifacts
 *   [{"type":"json","name":"result.json","path":"/tmp/result.json","summary":"..."}]
 *   ```
 *   or plain text with key:value pairs.
 *
 * Returns parsed artifacts marked as 'agent_declared'.
 */
export declare function parseAgentDeclaredArtifacts(summary: string, sourceRunId: string): TaskArtifact[];
/**
 * Merge new artifacts into existing list.
 * Agent-declared always wins over auto-detected for the same path.
 * Deduplicates by path (or id if no path).
 */
export declare function mergeArtifacts(existing: TaskArtifact[], incoming: TaskArtifact[]): TaskArtifact[];
//# sourceMappingURL=artifact.d.ts.map