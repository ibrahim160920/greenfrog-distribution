import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class WebSearchSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    /** Strip common prompt-injection phrases from untrusted search content */
    private sanitizeSearchContent;
    private formatResults;
    private searchSerper;
    private searchBrave;
    /**
     * Scrape DuckDuckGo's HTML search endpoint.
     * Attempts two different regex patterns to handle DDG HTML structure changes.
     */
    private searchDuckDuckGoHtml;
    private parseDDGHtml;
    private searchDDGInstant;
}
//# sourceMappingURL=web_search.d.ts.map