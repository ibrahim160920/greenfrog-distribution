import { config } from '../config/index.js';
import { RuntimeLimitError } from '../utils/errors.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('runtime-guard');
const activeByUser = new Map();
let activeExecutions = 0;
let totalRejectedGlobal = 0;
let totalRejectedPerUser = 0;
function resolveMaxConcurrent() {
    const value = config.agentMaxConcurrency ?? config.queue?.concurrency ?? 4;
    // Validate configuration
    if (value < 1 || value > 1000) {
        log.warn({ value }, 'Invalid agentMaxConcurrency, using default 4');
        return 4;
    }
    return value;
}
function resolveMaxConcurrentPerUser() {
    const globalCap = resolveMaxConcurrent();
    const perUserCap = config.agentMaxConcurrencyPerUser ?? 2;
    // Validate configuration
    if (perUserCap < 1 || perUserCap > globalCap) {
        log.warn({ perUserCap, globalCap }, 'Invalid agentMaxConcurrencyPerUser, using min(2, globalCap)');
        return Math.min(2, globalCap);
    }
    return Math.min(perUserCap, globalCap);
}
function buildUserKey(userId, channel) {
    const normalizedUser = userId.trim() || 'anonymous';
    const normalizedChannel = (channel ?? 'unknown').trim() || 'unknown';
    return `${normalizedChannel}:${normalizedUser}`;
}
function buildRuntimeSnapshot(userKey) {
    return {
        active: activeExecutions,
        maxConcurrent: resolveMaxConcurrent(),
        perUserActive: activeByUser.get(userKey) ?? 0,
        maxConcurrentPerUser: resolveMaxConcurrentPerUser(),
        userKey,
    };
}
export function getAgentRuntimeSnapshot(userId, channel) {
    return buildRuntimeSnapshot(buildUserKey(userId, channel));
}
export function getAgentRuntimeOverview() {
    const busiestUsers = [...activeByUser.entries()]
        .map(([userKey, active]) => ({ userKey, active }))
        .sort((a, b) => b.active - a.active || a.userKey.localeCompare(b.userKey))
        .slice(0, 5);
    return {
        active: activeExecutions,
        maxConcurrent: resolveMaxConcurrent(),
        maxConcurrentPerUser: resolveMaxConcurrentPerUser(),
        activeUsers: activeByUser.size,
        totalRejectedGlobal,
        totalRejectedPerUser,
        busiestUsers,
    };
}
export function acquireAgentExecutionLease(params) {
    const userKey = buildUserKey(params.userId, params.channel);
    const maxConcurrent = resolveMaxConcurrent();
    const maxConcurrentPerUser = resolveMaxConcurrentPerUser();
    const currentPerUser = activeByUser.get(userKey) ?? 0;
    // Check global limit first
    if (activeExecutions >= maxConcurrent) {
        totalRejectedGlobal++;
        log.warn({ active: activeExecutions, max: maxConcurrent, userKey }, 'Global concurrency limit reached');
        throw new RuntimeLimitError(`Agent runtime is saturated (${activeExecutions}/${maxConcurrent} active).`, {
            scope: 'global',
            label: params.label ?? 'agent',
            ...buildRuntimeSnapshot(userKey),
        });
    }
    // Check per-user limit
    if (currentPerUser >= maxConcurrentPerUser) {
        totalRejectedPerUser++;
        log.warn({ active: currentPerUser, max: maxConcurrentPerUser, userKey }, 'Per-user concurrency limit reached');
        throw new RuntimeLimitError(`User concurrency limit reached (${currentPerUser}/${maxConcurrentPerUser} active).`, {
            scope: 'user',
            label: params.label ?? 'agent',
            ...buildRuntimeSnapshot(userKey),
        });
    }
    // Acquire lease
    activeExecutions += 1;
    activeByUser.set(userKey, currentPerUser + 1);
    log.debug({ active: activeExecutions, perUser: currentPerUser + 1, userKey }, 'Execution lease acquired');
    let released = false;
    return {
        release: () => {
            if (released)
                return;
            released = true;
            activeExecutions = Math.max(0, activeExecutions - 1);
            const nextCount = Math.max(0, (activeByUser.get(userKey) ?? 1) - 1);
            if (nextCount === 0)
                activeByUser.delete(userKey);
            else
                activeByUser.set(userKey, nextCount);
            log.debug({ active: activeExecutions, perUser: nextCount, userKey }, 'Execution lease released');
        },
    };
}
export async function withAgentExecutionLease(params, fn) {
    const lease = acquireAgentExecutionLease(params);
    try {
        return await fn();
    }
    finally {
        lease.release();
    }
}
//# sourceMappingURL=agent_runtime_guard.js.map