import { load as cheerioLoad } from 'cheerio';
import { BaseSkill } from './base.js';
const FETCH_TIMEOUT = 20_000;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const HEADERS = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,*/*;q=0.9',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'no-cache',
};
// ─────────────────────────────────────────────────────────────────────────────
export class ReaderSkill extends BaseSkill {
    definition = {
        name: 'reader',
        description: 'Extract the full article content from any web page and return it as clean Markdown. ' +
            'Preserves all formatting: headings, bold, italics, links, images, code blocks, tables, lists. ' +
            'Bypasses JS copy-protection (user-select:none, clipboard hijack) since extraction is server-side. ' +
            'Ideal for research: feed the clean Markdown to further analysis or summarization. ' +
            'Supports: WeChat articles, Zhihu, 36kr, 虎嗅, 少数派, Medium, Substack, GitHub, ' +
            'Wikipedia, arXiv, and any generic web page.',
        category: 'information',
        parameters: [
            {
                name: 'url',
                type: 'string',
                required: true,
                description: 'URL of the article or web page to extract',
            },
            {
                name: 'include_images',
                type: 'boolean',
                description: 'Include image markdown (![alt](url)). Default: true',
                default: true,
            },
            {
                name: 'include_links',
                type: 'boolean',
                description: 'Include hyperlinks. Default: true',
                default: true,
            },
            {
                name: 'max_chars',
                type: 'number',
                description: 'Maximum characters to return. Default: 50000 (0 = no limit)',
                default: 50000,
            },
        ],
        examples: [
            '帮我把这篇公众号文章转成Markdown: https://mp.weixin.qq.com/s/...',
            '提取这篇知乎文章的全文: https://zhuanlan.zhihu.com/p/...',
            'reader https://en.wikipedia.org/wiki/Transformer_(machine_learning_model)',
            '把这个网页的内容扒下来: https://example.com/article',
        ],
    };
    async execute(params, _ctx) {
        const url = (params.url ?? '').trim();
        const includeImages = params.include_images !== false;
        const includeLinks = params.include_links !== false;
        const maxChars = typeof params.max_chars === 'number' ? params.max_chars : 50_000;
        if (!url.startsWith('http'))
            return this.err('URL must start with http:// or https://');
        try {
            const { title, author, date, markdown, source } = await extractArticle(url, {
                includeImages,
                includeLinks,
            });
            const meta = [
                `# ${title || 'Untitled'}`,
                [
                    author && `**作者:** ${author}`,
                    date && `**日期:** ${date}`,
                    `**来源:** ${source}`,
                    `**原文:** [${url}](${url})`,
                ].filter(Boolean).join('  |  '),
                '',
                '---',
                '',
            ].join('\n');
            const body = maxChars > 0 ? markdown.slice(0, maxChars) : markdown;
            const truncated = maxChars > 0 && markdown.length > maxChars
                ? `\n\n---\n*（内容已截断，原文共 ${markdown.length.toLocaleString()} 字符，` +
                    `已返回前 ${maxChars.toLocaleString()} 字符）*`
                : '';
            return this.text(meta + body + truncated);
        }
        catch (err) {
            return this.err(`Reader failed: ${String(err)}`);
        }
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Main extraction router
// ─────────────────────────────────────────────────────────────────────────────
async function extractArticle(url, opts) {
    const lower = url.toLowerCase();
    if (/mp\.weixin\.qq\.com/.test(lower))
        return extractWeChat(url, opts);
    if (/zhihu\.com\/(p\/|question\/|answer\/)/.test(lower) ||
        /zhuanlan\.zhihu\.com/.test(lower))
        return extractZhihu(url, opts);
    if (/36kr\.com/.test(lower))
        return extractChinaTech(url, '36氪', opts);
    if (/huxiu\.com/.test(lower))
        return extractChinaTech(url, '虎嗅', opts);
    if (/sspai\.com/.test(lower))
        return extractChinaTech(url, '少数派', opts);
    if (/medium\.com\//.test(lower))
        return extractMedium(url, opts);
    if (/\.substack\.com|substack\.com\/p\//.test(lower))
        return extractSubstack(url, opts);
    if (/wikipedia\.org\/wiki\//.test(lower))
        return extractWikipedia(url, opts);
    if (/arxiv\.org\/abs\//.test(lower))
        return extractArxiv(url, opts);
    if (/github\.com\//.test(lower))
        return extractGitHub(url, opts);
    if (/news\.ycombinator\.com/.test(lower))
        return extractHN(url, opts);
    return extractGeneric(url, opts);
}
// ─────────────────────────────────────────────────────────────────────────────
// Fetch helper
// ─────────────────────────────────────────────────────────────────────────────
async function fetchHtml(url, extra) {
    const res = await fetch(url, {
        headers: { ...HEADERS, ...extra },
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
        redirect: 'follow',
    });
    if (!res.ok)
        throw new Error(`HTTP ${res.status} ${res.statusText} — ${url}`);
    return res.text();
}
// ─────────────────────────────────────────────────────────────────────────────
// Platform extractors
// ─────────────────────────────────────────────────────────────────────────────
// ── WeChat ────────────────────────────────────────────────────────────────────
async function extractWeChat(url, opts) {
    const html = await fetchHtml(url, { Referer: 'https://mp.weixin.qq.com/' });
    const $ = cheerioLoad(html);
    const title = $('#activity-name, .rich_media_title').first().text().trim()
        || $('meta[property="og:title"]').attr('content') || 'WeChat Article';
    const author = $('.profile_nickname, #js_name').first().text().trim();
    const date = $('#publish_time, .publish_time').first().text().trim()
        || $('meta[property="article:published_time"]').attr('content')?.slice(0, 10) || '';
    // Resolve WeChat lazy images before conversion
    $('#js_content img[data-src]').each((_, el) => {
        const dataSrc = $(el).attr('data-src') ?? '';
        if (dataSrc)
            $(el).attr('src', dataSrc);
    });
    $('#js_content').find('script, style, .data_tips, .js_jump_icon, .weui-hidden_').remove();
    const contentEl = $('#js_content');
    if (!contentEl.length)
        throw new Error('Could not find WeChat article content (#js_content not found — may require login)');
    return {
        title,
        author,
        date,
        markdown: htmlToMarkdown(contentEl.html() ?? '', opts),
        source: '微信公众号',
    };
}
// ── Zhihu ─────────────────────────────────────────────────────────────────────
async function extractZhihu(url, opts) {
    const html = await fetchHtml(url, { Referer: 'https://www.zhihu.com/' });
    const $ = cheerioLoad(html);
    const title = $('h1.Post-Title, h1.QuestionHeader-title, .ArticleItem-title').first().text().trim()
        || $('meta[property="og:title"]').attr('content') || 'Zhihu';
    const author = $('.AuthorInfo-name, .UserLink-link').first().text().trim();
    const date = $('time').first().attr('datetime')?.slice(0, 10) || '';
    // Resolve lazy images
    $('img[data-actualsrc], img[data-original]').each((_, el) => {
        const real = $(el).attr('data-actualsrc') ?? $(el).attr('data-original') ?? '';
        if (real)
            $(el).attr('src', real);
    });
    let contentHtml = '';
    const contentEl = $('.RichContent-inner, .Post-RichTextContainer').first();
    if (contentEl.length) {
        contentEl.find('script, style, .RichContent-actions').remove();
        contentHtml = contentEl.html() ?? '';
    }
    // Fallback: extract from embedded JSON
    if (!contentHtml) {
        const jsonMatch = html.match(/<script id="js-initialData" type="text\/json">(.+?)<\/script>/s);
        if (jsonMatch) {
            try {
                const data = JSON.parse(jsonMatch[1]);
                const entities = data?.initialState?.entities;
                contentHtml =
                    Object.values(entities?.answers ?? {})[0]?.content ??
                        Object.values(entities?.articles ?? {})[0]?.content ?? '';
            }
            catch { /* ignore */ }
        }
    }
    if (!contentHtml)
        throw new Error('Could not extract Zhihu content (may require login)');
    return {
        title, author, date,
        markdown: htmlToMarkdown(contentHtml, opts),
        source: '知乎',
    };
}
// ── Chinese tech media ────────────────────────────────────────────────────────
async function extractChinaTech(url, siteName, opts) {
    const html = await fetchHtml(url);
    const $ = cheerioLoad(html);
    const title = $('h1').first().text().trim()
        || $('meta[property="og:title"]').attr('content') || siteName;
    const author = $('[class*="author"]').first().text().trim();
    const date = $('time, [class*="time"], [class*="date"]').first().text().trim().slice(0, 20);
    const SELECTORS = {
        '36氪': ['.article-detail-content', '.articleDetailContent'],
        '虎嗅': ['.article-content', '.content-wrap', '.article-body'],
        '少数派': ['.article-body', '.post-content', '.content'],
    };
    const selectors = [...(SELECTORS[siteName] ?? []), 'article', 'main', '.content'];
    let contentHtml = '';
    for (const sel of selectors) {
        const el = $(sel).first();
        if (el.length && el.text().trim().length > 300) {
            el.find('script, style, .ad, [class*="recommend"], [class*="related"]').remove();
            contentHtml = el.html() ?? '';
            break;
        }
    }
    if (!contentHtml)
        throw new Error(`Could not extract ${siteName} article content`);
    return {
        title, author, date,
        markdown: htmlToMarkdown(contentHtml, opts),
        source: siteName,
    };
}
// ── Medium ────────────────────────────────────────────────────────────────────
async function extractMedium(url, opts) {
    const html = await fetchHtml(url, { Referer: 'https://medium.com/' });
    const $ = cheerioLoad(html);
    const title = $('h1').first().text().trim()
        || $('meta[property="og:title"]').attr('content') || 'Medium';
    const author = $('[data-testid="authorName"], .pw-author-name').first().text().trim()
        || $('meta[name="author"]').attr('content') || '';
    const date = $('time').first().attr('datetime')?.slice(0, 10) || '';
    const articleEl = $('article').first();
    articleEl.find('script, style, footer, .js-postShareWidget').remove();
    const contentHtml = articleEl.html() ?? '';
    if (!contentHtml || contentHtml.length < 100)
        throw new Error('Could not extract Medium article (may be paywalled)');
    return {
        title, author, date,
        markdown: htmlToMarkdown(contentHtml, opts),
        source: 'Medium',
    };
}
// ── Substack ──────────────────────────────────────────────────────────────────
async function extractSubstack(url, opts) {
    const html = await fetchHtml(url);
    const $ = cheerioLoad(html);
    const title = $('h1.post-title, h1').first().text().trim()
        || $('meta[property="og:title"]').attr('content') || 'Substack';
    const author = $('.byline-names a, .author-name').first().text().trim()
        || $('meta[name="author"]').attr('content') || '';
    const date = $('time').first().attr('datetime')?.slice(0, 10) || '';
    const bodyEl = $('.body, .post-content, article').first();
    bodyEl.find('script, style, .subscribe-widget, .paywall, footer').remove();
    const contentHtml = bodyEl.html() ?? '';
    if (!contentHtml || contentHtml.length < 100)
        throw new Error('Could not extract Substack content (may require subscription)');
    return {
        title, author, date,
        markdown: htmlToMarkdown(contentHtml, opts),
        source: 'Substack',
    };
}
// ── Wikipedia ─────────────────────────────────────────────────────────────────
async function extractWikipedia(url, opts) {
    const match = url.match(/https?:\/\/([a-z]{2,3})\.wikipedia\.org\/wiki\/(.+)/);
    if (!match)
        throw new Error('Cannot parse Wikipedia URL');
    const [, lang, slug] = match;
    const title = decodeURIComponent(slug.replace(/_/g, ' '));
    const html = await fetchHtml(`https://${lang}.wikipedia.org/api/rest_v1/page/html/${encodeURIComponent(slug)}`, { Accept: 'text/html; charset=utf-8' });
    const $ = cheerioLoad(html);
    // Remove edit links, reference lists, navboxes, TOC
    $('script, style, .mw-editsection, .reflist, .navbox, .toc, .mw-references-wrap, figure').remove();
    $('sup.reference, sup.noprint').remove();
    const body = $('section, article, body').first();
    return {
        title,
        author: '',
        date: '',
        markdown: htmlToMarkdown(body.html() ?? html, opts),
        source: `Wikipedia (${lang})`,
    };
}
// ── arXiv ─────────────────────────────────────────────────────────────────────
async function extractArxiv(url, opts) {
    const idMatch = url.match(/arxiv\.org\/abs\/([0-9]{4}\.[0-9]+(?:v\d+)?)/);
    if (!idMatch)
        throw new Error('Cannot parse arXiv ID from URL');
    const paperId = idMatch[1];
    // Get metadata
    const apiXml = await fetchHtml(`https://export.arxiv.org/api/query?id_list=${paperId}`);
    const $m = cheerioLoad(apiXml, { xmlMode: true });
    const title = $m('entry > title').text().trim().replace(/\s+/g, ' ');
    const authors = $m('author name').map((_, el) => $m(el).text()).get().join(', ');
    const abstract = $m('entry > summary').text().trim().replace(/\s+/g, ' ');
    const published = $m('entry > published').text().slice(0, 10);
    // Try ar5iv full HTML
    let contentMd = `**Abstract**\n\n${abstract}`;
    try {
        const html = await fetchHtml(`https://ar5iv.org/html/${paperId}`);
        const $ = cheerioLoad(html);
        $('script, style, .ltx_bibliography, figure, .ltx_appendix, nav').remove();
        const bodyEl = $('article, body').first();
        if (bodyEl.text().trim().length > 500) {
            contentMd = htmlToMarkdown(bodyEl.html() ?? '', opts);
        }
    }
    catch { /* use abstract */ }
    return {
        title: title || `arXiv:${paperId}`,
        author: authors,
        date: published,
        markdown: contentMd,
        source: 'arXiv',
    };
}
// ── GitHub ─────────────────────────────────────────────────────────────────────
async function extractGitHub(url, opts) {
    const parts = new URL(url).pathname.split('/').filter(Boolean);
    const [owner, repo, type, ...rest] = parts;
    if (!owner || !repo)
        throw new Error('Invalid GitHub URL');
    const ghHeaders = { ...HEADERS, Accept: 'application/vnd.github.v3+json' };
    // README / repo
    if (!type || type === 'tree') {
        const readmeRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/readme`, { headers: { ...ghHeaders, Accept: 'application/vnd.github.v3.raw' }, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
        if (!readmeRes.ok)
            throw new Error(`GitHub API ${readmeRes.status}`);
        const md = await readmeRes.text();
        return { title: `${owner}/${repo}`, author: owner, date: '', markdown: md, source: 'GitHub' };
    }
    // Blob — raw file
    if (type === 'blob' && rest.length >= 2) {
        const [branch, ...fp] = rest;
        const raw = await fetchHtml(`https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${fp.join('/')}`);
        const ext = fp[fp.length - 1]?.split('.').pop() ?? '';
        const lang = ext === 'ts' ? 'typescript' : ext === 'js' ? 'javascript' : ext === 'py' ? 'python' : ext;
        const md = ['md', 'markdown'].includes(ext) ? raw : `\`\`\`${lang}\n${raw}\n\`\`\``;
        return { title: fp.join('/'), author: owner, date: '', markdown: md, source: 'GitHub' };
    }
    // Issue or PR — render HTML body
    const issuePath = type === 'pull' ? 'pulls' : 'issues';
    if ((type === 'issues' || type === 'pull') && rest[0]) {
        const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/${issuePath}/${rest[0]}`, { headers: ghHeaders, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
        if (!res.ok)
            throw new Error(`GitHub API ${res.status}`);
        const data = await res.json();
        const md = data.body ? htmlToMarkdown(`<div>${data.body}</div>`, opts) : '*(no description)*';
        return {
            title: `[${type === 'pull' ? 'PR' : 'Issue'} #${rest[0]}] ${data.title}`,
            author: data.user.login,
            date: data.created_at.slice(0, 10),
            markdown: md,
            source: 'GitHub',
        };
    }
    throw new Error(`Unsupported GitHub URL type: ${type}`);
}
// ── Hacker News ───────────────────────────────────────────────────────────────
async function extractHN(url, opts) {
    const idMatch = url.match(/[?&]id=(\d+)/);
    if (!idMatch)
        throw new Error('Cannot parse HN item ID');
    const res = await fetch(`https://hacker-news.firebaseio.com/v0/item/${idMatch[1]}.json`, {
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!res.ok)
        throw new Error(`HN API ${res.status}`);
    const item = await res.json();
    const date = new Date(item.time * 1000).toISOString().slice(0, 10);
    let markdown = item.text ? htmlToMarkdown(item.text, opts) : '';
    // For link posts, fetch the linked article
    if (item.url) {
        try {
            const linked = await extractGeneric(item.url, opts);
            markdown = [
                item.text ? `**HN Post:**\n\n${markdown}\n\n---\n` : '',
                `**Linked Article: ${linked.title}**\n\n${linked.markdown}`,
            ].filter(Boolean).join('');
        }
        catch {
            if (!markdown)
                markdown = `*Link: ${item.url}*`;
        }
    }
    // Top comments
    const commentIds = (item.kids ?? []).slice(0, 10);
    if (commentIds.length) {
        const comments = await Promise.allSettled(commentIds.slice(0, 8).map(async (cid) => {
            const r = await fetch(`https://hacker-news.firebaseio.com/v0/item/${cid}.json`, {
                signal: AbortSignal.timeout(5_000),
            });
            if (!r.ok)
                return '';
            const c = await r.json();
            if (c.deleted || !c.text)
                return '';
            return `**${c.by ?? 'anon'}:** ${htmlToMarkdown(c.text, opts)}`;
        }));
        const commentMd = comments.map((r) => r.status === 'fulfilled' ? r.value : '').filter(Boolean).join('\n\n---\n');
        if (commentMd)
            markdown += `\n\n---\n## Top Comments\n\n${commentMd}`;
    }
    return {
        title: item.title || 'Hacker News',
        author: item.by,
        date,
        markdown,
        source: 'Hacker News',
    };
}
// ── Generic web page ──────────────────────────────────────────────────────────
async function extractGeneric(url, opts) {
    const html = await fetchHtml(url);
    const $ = cheerioLoad(html);
    const title = $('meta[property="og:title"]').attr('content')
        || $('h1').first().text().trim()
        || $('title').text().trim()
        || url;
    const author = $('meta[name="author"]').attr('content')
        || $('[rel="author"], [class*="author"]').first().text().trim() || '';
    const date = $('meta[property="article:published_time"]').attr('content')?.slice(0, 10)
        || $('time').first().attr('datetime')?.slice(0, 10)
        || $('time').first().text().trim().slice(0, 20) || '';
    // Resolve lazy images globally
    $('img[data-src], img[data-original], img[data-lazy-src]').each((_, el) => {
        const real = $(el).attr('data-src') ?? $(el).attr('data-original') ?? $(el).attr('data-lazy-src') ?? '';
        if (real)
            $(el).attr('src', real);
    });
    // Remove noise
    $('script, style, nav, header, footer, aside, .ad, .advertisement, .sidebar, ' +
        '.comment, .comments, .social-share, .related-posts, .newsletter-signup, ' +
        '[class*="banner"], [class*="popup"], [id*="cookie"]').remove();
    const SELECTORS = [
        'article', 'main', '[role="main"]',
        '.article-body', '.article-content', '.post-content', '.entry-content',
        '.content-body', '#content', '.main-content', '.rich_media_content',
        '[class*="article-body"]', '[class*="article-content"]',
        '[class*="post-body"]', '[class*="entry-body"]',
    ];
    let contentHtml = '';
    for (const sel of SELECTORS) {
        const el = $(sel).first();
        if (el.length && el.text().trim().length > 300) {
            contentHtml = el.html() ?? '';
            break;
        }
    }
    if (!contentHtml)
        contentHtml = $('body').html() ?? html;
    return {
        title: title.slice(0, 120),
        author,
        date,
        markdown: htmlToMarkdown(contentHtml, opts),
        source: new URL(url).hostname,
    };
}
// ─────────────────────────────────────────────────────────────────────────────
// HTML → Markdown converter
// ─────────────────────────────────────────────────────────────────────────────
function htmlToMarkdown(html, opts) {
    const $ = cheerioLoad(`<div id="__root__">${html}</div>`);
    const root = $('#__root__').get(0);
    if (!root)
        return '';
    const md = nodeToMd(root, $, opts, 0);
    return cleanMarkdown(md);
}
function nodeToMd(node, $, opts, listDepth) {
    // Text node
    if (node.type === 'text') {
        const text = node.data ?? '';
        // Collapse whitespace but preserve intentional newlines within pre/code
        return text.replace(/\r?\n/g, ' ').replace(/\s+/g, ' ');
    }
    // Only process element nodes
    if (node.type !== 'tag')
        return '';
    const el = node;
    const tag = (el.tagName ?? '').toLowerCase();
    const $el = $(el);
    // Elements to completely skip
    if (['script', 'style', 'noscript', 'iframe', 'nav', 'header',
        'footer', 'form', 'button', 'select', 'input', 'textarea',
        'meta', 'link', 'svg', 'canvas'].includes(tag)) {
        return '';
    }
    // Recurse into children
    const children = () => $el.contents().toArray().map((n) => nodeToMd(n, $, opts, listDepth)).join('');
    // --- Block elements ---
    if (tag === 'h1')
        return `\n\n# ${children().trim()}\n\n`;
    if (tag === 'h2')
        return `\n\n## ${children().trim()}\n\n`;
    if (tag === 'h3')
        return `\n\n### ${children().trim()}\n\n`;
    if (tag === 'h4')
        return `\n\n#### ${children().trim()}\n\n`;
    if (tag === 'h5')
        return `\n\n##### ${children().trim()}\n\n`;
    if (tag === 'h6')
        return `\n\n###### ${children().trim()}\n\n`;
    if (tag === 'p') {
        const inner = children().trim();
        return inner ? `\n\n${inner}\n\n` : '';
    }
    if (tag === 'br')
        return '  \n';
    if (tag === 'hr')
        return '\n\n---\n\n';
    if (tag === 'blockquote') {
        const inner = children().trim();
        const quoted = inner.split('\n').map((l) => `> ${l}`).join('\n');
        return `\n\n${quoted}\n\n`;
    }
    if (tag === 'pre') {
        const codeEl = $el.find('code').first();
        const lang = (codeEl.attr('class') ?? '').match(/language-(\w+)/)?.[1] ?? '';
        const code = codeEl.length ? codeEl.text() : $el.text();
        return `\n\n\`\`\`${lang}\n${code.trimEnd()}\n\`\`\`\n\n`;
    }
    if (tag === 'table')
        return convertTable(el, $, opts) + '\n\n';
    if (tag === 'ul') {
        const indent = '  '.repeat(listDepth);
        const items = $el.children('li').toArray().map((li) => {
            const content = nodeToMd(li, $, opts, listDepth + 1).trim();
            return `${indent}- ${content.replace(/\n{2,}/g, '\n').replace(/\n/g, `\n${indent}  `)}`;
        });
        return `\n${items.join('\n')}\n`;
    }
    if (tag === 'ol') {
        const indent = '  '.repeat(listDepth);
        const items = $el.children('li').toArray().map((li, i) => {
            const content = nodeToMd(li, $, opts, listDepth + 1).trim();
            return `${indent}${i + 1}. ${content.replace(/\n{2,}/g, '\n').replace(/\n/g, `\n${indent}   `)}`;
        });
        return `\n${items.join('\n')}\n`;
    }
    if (tag === 'li')
        return children().trim();
    // --- Inline elements ---
    if (tag === 'strong' || tag === 'b') {
        const inner = children().trim();
        return inner ? `**${inner}**` : '';
    }
    if (tag === 'em' || tag === 'i') {
        const inner = children().trim();
        return inner ? `*${inner}*` : '';
    }
    if (tag === 's' || tag === 'del' || tag === 'strike') {
        const inner = children().trim();
        return inner ? `~~${inner}~~` : '';
    }
    if (tag === 'code') {
        // Don't double-wrap if inside <pre>
        const parentTag = (el.parent?.tagName ?? '').toLowerCase();
        if (parentTag === 'pre')
            return $el.text();
        const inner = $el.text().trim();
        return inner ? `\`${inner}\`` : '';
    }
    if (tag === 'a') {
        const href = $el.attr('href') ?? '';
        const inner = children().trim();
        if (!inner)
            return '';
        if (!opts.includeLinks || !href || href.startsWith('javascript') || href === '#') {
            return inner;
        }
        // Make relative URLs absolute is not needed here since we keep them as-is
        return `[${inner}](${href})`;
    }
    if (tag === 'img') {
        if (!opts.includeImages)
            return '';
        const src = $el.attr('src') ?? $el.attr('data-src') ?? $el.attr('data-original') ?? '';
        const alt = $el.attr('alt') ?? '';
        if (!src || src.startsWith('data:'))
            return alt ? `[Image: ${alt}]` : '';
        return `![${alt}](${src})`;
    }
    // Superscript / subscript
    if (tag === 'sup')
        return `^${children()}`;
    if (tag === 'sub')
        return `~${children()}`;
    // Details/summary
    if (tag === 'summary')
        return `\n**${children().trim()}**\n`;
    if (tag === 'details')
        return `\n\n${children().trim()}\n\n`;
    // Description list
    if (tag === 'dt')
        return `\n**${children().trim()}**\n`;
    if (tag === 'dd')
        return `  ${children().trim()}\n`;
    // Figure / figcaption
    if (tag === 'figure')
        return `\n\n${children().trim()}\n\n`;
    if (tag === 'figcaption')
        return `\n*${children().trim()}*\n`;
    // Generic block containers — just pass through with spacing
    const BLOCK_TAGS = new Set(['div', 'section', 'article', 'main', 'aside',
        'header', 'footer', 'address', 'fieldset',
        'td', 'th', 'caption', '#root', '__root__']);
    if (BLOCK_TAGS.has(tag)) {
        return children();
    }
    // Everything else: pass children through as-is
    return children();
}
// ── Table converter ───────────────────────────────────────────────────────────
function convertTable(el, $, opts) {
    const rows = [];
    $(el).find('tr').each((_, trEl) => {
        const cells = [];
        $(trEl).find('td, th').each((_, cellEl) => {
            const text = $(cellEl).text().replace(/\|/g, '\\|').replace(/\s+/g, ' ').trim();
            cells.push(text);
        });
        if (cells.length > 0)
            rows.push(cells);
    });
    if (rows.length === 0)
        return '';
    const colCount = Math.max(...rows.map((r) => r.length));
    const padRow = (row) => {
        while (row.length < colCount)
            row.push('');
        return `| ${row.join(' | ')} |`;
    };
    const lines = [];
    // Check if first row is a header (came from thead or th cells)
    const firstEl = $(el).find('tr').first();
    const isHeader = firstEl.find('th').length > 0 || $(el).find('thead').length > 0;
    if (isHeader && rows.length > 0) {
        lines.push(padRow(rows[0]));
        lines.push(`| ${rows[0].map(() => '---').join(' | ')} |`);
        rows.slice(1).forEach((r) => lines.push(padRow(r)));
    }
    else {
        rows.forEach((r, i) => {
            lines.push(padRow(r));
            if (i === 0)
                lines.push(`| ${r.map(() => '---').join(' | ')} |`);
        });
    }
    return `\n\n${lines.join('\n')}\n`;
}
// ── Post-process Markdown ─────────────────────────────────────────────────────
function cleanMarkdown(md) {
    return md
        // Collapse 3+ blank lines → 2
        .replace(/\n{3,}/g, '\n\n')
        // Remove trailing spaces on lines
        .replace(/ +\n/g, '\n')
        // Remove blank lines inside lists
        .replace(/(^[-*\d].*)\n\n([-*\d])/gm, '$1\n$2')
        .trim();
}
//# sourceMappingURL=reader.js.map