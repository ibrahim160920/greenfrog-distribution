/**
 * Plugin Marketplace - MVP implementation
 * Provides a curated list of community plugins that can be installed
 */
/**
 * Curated marketplace plugins (MVP: hardcoded list)
 * In production, this would come from a database or external API
 */
export const MARKETPLACE_PLUGINS = [
    {
        id: 'weather-extended',
        name: 'Weather Extended',
        description: 'Advanced weather forecasting with 7-day predictions, severe weather alerts, and historical data',
        author: 'GreenFrog Community',
        version: '1.0.0',
        category: 'Utilities',
        tags: ['weather', 'forecast', 'alerts'],
        sourceUrl: 'https://raw.githubusercontent.com/greenfrog-plugins/weather-extended/main/weather_extended.js',
        installSize: 15360,
        downloads: 1247,
        createdAt: '2026-01-15T00:00:00Z',
        updatedAt: '2026-03-10T00:00:00Z',
    },
    {
        id: 'crypto-tracker',
        name: 'Crypto Price Tracker',
        description: 'Real-time cryptocurrency prices, market cap, and portfolio tracking for 100+ coins',
        author: 'CryptoDevs',
        version: '2.1.0',
        category: 'Finance',
        tags: ['crypto', 'bitcoin', 'ethereum', 'finance'],
        sourceUrl: 'https://raw.githubusercontent.com/greenfrog-plugins/crypto-tracker/main/crypto_tracker.js',
        installSize: 22500,
        downloads: 892,
        createdAt: '2026-02-01T00:00:00Z',
        updatedAt: '2026-03-15T00:00:00Z',
    },
    {
        id: 'calendar-sync',
        name: 'Calendar Sync',
        description: 'Sync with Google Calendar, Outlook, and iCal. Create events, set reminders, and manage schedules',
        author: 'ProductivityTeam',
        version: '1.5.2',
        category: 'Productivity',
        tags: ['calendar', 'schedule', 'events', 'google'],
        sourceUrl: 'https://raw.githubusercontent.com/greenfrog-plugins/calendar-sync/main/calendar_sync.js',
        installSize: 18900,
        downloads: 2103,
        createdAt: '2025-12-10T00:00:00Z',
        updatedAt: '2026-03-20T00:00:00Z',
    },
    {
        id: 'image-generator',
        name: 'AI Image Generator',
        description: 'Generate images using DALL-E, Stable Diffusion, or Midjourney APIs',
        author: 'AIArtists',
        version: '3.0.0',
        category: 'Creative',
        tags: ['image', 'ai', 'art', 'generation'],
        sourceUrl: 'https://raw.githubusercontent.com/greenfrog-plugins/image-generator/main/image_generator.js',
        installSize: 31200,
        downloads: 3456,
        createdAt: '2025-11-20T00:00:00Z',
        updatedAt: '2026-03-18T00:00:00Z',
    },
    {
        id: 'database-query',
        name: 'Database Query Tool',
        description: 'Execute SQL queries on MySQL, PostgreSQL, MongoDB, and Redis databases',
        author: 'DataEngineers',
        version: '2.3.1',
        category: 'Development',
        tags: ['database', 'sql', 'query', 'mysql', 'postgres'],
        sourceUrl: 'https://raw.githubusercontent.com/greenfrog-plugins/database-query/main/database_query.js',
        installSize: 27800,
        downloads: 1567,
        createdAt: '2026-01-05T00:00:00Z',
        updatedAt: '2026-03-12T00:00:00Z',
    },
];
/**
 * Get all marketplace plugins
 */
export function getMarketplacePlugins() {
    return MARKETPLACE_PLUGINS;
}
/**
 * Get a specific plugin by ID
 */
export function getMarketplacePlugin(id) {
    return MARKETPLACE_PLUGINS.find(p => p.id === id) || null;
}
/**
 * Search plugins by query (name, description, tags)
 */
export function searchMarketplacePlugins(query) {
    const lowerQuery = query.toLowerCase();
    return MARKETPLACE_PLUGINS.filter(p => p.name.toLowerCase().includes(lowerQuery) ||
        p.description.toLowerCase().includes(lowerQuery) ||
        p.tags.some(t => t.toLowerCase().includes(lowerQuery)) ||
        p.category.toLowerCase().includes(lowerQuery));
}
/**
 * Filter plugins by category
 */
export function getPluginsByCategory(category) {
    return MARKETPLACE_PLUGINS.filter(p => p.category === category);
}
/**
 * Get all unique categories
 */
export function getCategories() {
    return [...new Set(MARKETPLACE_PLUGINS.map(p => p.category))];
}
//# sourceMappingURL=index.js.map