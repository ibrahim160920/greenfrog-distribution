export declare class GreenFrogError extends Error {
    readonly code: string;
    readonly details?: unknown | undefined;
    constructor(message: string, code: string, details?: unknown | undefined);
}
export declare class ProviderError extends GreenFrogError {
    constructor(message: string, details?: unknown);
}
export declare class ChannelError extends GreenFrogError {
    constructor(message: string, channel: string, details?: unknown);
}
export declare class SkillError extends GreenFrogError {
    constructor(message: string, skill: string, details?: unknown);
}
export declare class ConfigError extends GreenFrogError {
    constructor(message: string, details?: unknown);
}
export declare class RuntimeLimitError extends GreenFrogError {
    constructor(message: string, details?: unknown);
}
export declare function isGreenFrogError(err: unknown): err is GreenFrogError;
export declare function toErrorMessage(err: unknown): string;
//# sourceMappingURL=errors.d.ts.map