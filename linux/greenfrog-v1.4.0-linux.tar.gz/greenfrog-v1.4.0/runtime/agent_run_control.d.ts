import type { ChannelName } from '../utils/types.js';
type StartAgentRunParams = {
    runId?: string;
    userId: string;
    channel: ChannelName;
    label?: string | null;
    taskId?: string | null;
    workspaceId?: string | null;
    agentId?: string | null;
};
export declare function startAgentRun(params: StartAgentRunParams): {
    runId: string;
    release: () => void;
};
export declare function cancelAgentRun(runId: string, reason?: string): boolean;
export declare function getAgentRun(runId: string): {
    runId: string;
    userId: string;
    channel: ChannelName;
    label: string | null;
    taskId: string | null;
    workspaceId: string | null;
    agentId: string | null;
    startedAt: string;
    cancelledAt: string | null;
    cancellationReason: string | null;
    cancellationPending: boolean;
    runningMs: number;
} | null;
export declare function isAgentRunCancelled(runId: string): string | null;
/**
 * Cancel any active runs that have been running longer than thresholdMs.
 * Returns the number of runs that were newly cancelled.
 * Safe to call repeatedly — already-cancelled runs are skipped.
 */
export declare function cancelStuckRuns(thresholdMs: number): number;
/**
 * Force-remove runs that have been in cancellation-pending state longer than
 * cancelledForMs.  Called by the stuck-run sweep in index.ts, after
 * cancelStuckRuns() has had time to signal the agent loop.
 *
 * This is the structural GC step that prevents stuck-cancelled runs from
 * accumulating in activeRuns indefinitely when the underlying async call
 * never returns.
 *
 * Returns the number of runs force-released.
 */
export declare function releaseStuckCancelledRuns(cancelledForMs: number): number;
export declare function getActiveAgentRunsOverview(): {
    activeRuns: number;
    cancellationPending: number;
    runs: {
        runId: string;
        userId: string;
        channel: ChannelName;
        label: string | null;
        taskId: string | null;
        workspaceId: string | null;
        agentId: string | null;
        startedAt: string;
        cancelledAt: string | null;
        cancellationReason: string | null;
        cancellationPending: boolean;
        runningMs: number;
    }[];
};
export {};
//# sourceMappingURL=agent_run_control.d.ts.map