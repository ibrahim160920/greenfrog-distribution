import cron from 'node-cron';
import { BaseSkill } from './base.js';
import { memoryStore } from '../memory/store.js';
import { scheduler } from '../scheduler/index.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('cron_job');
export class CronJobSkill extends BaseSkill {
    definition = {
        name: 'schedule_job',
        description: 'Create, list, pause, resume, and delete scheduled jobs. Run AI prompts on a cron schedule (e.g. daily weather report, hourly monitoring).',
        category: 'automation',
        parameters: [
            {
                name: 'action', type: 'string', required: true,
                description: 'Action to perform',
                enum: ['create', 'list', 'delete', 'pause', 'resume'],
            },
            { name: 'name', type: 'string', description: 'Job name (required for create)' },
            { name: 'cron', type: 'string', description: 'Cron expression, 5 fields. E.g. "0 9 * * *" = 9 am daily, "*/30 * * * *" = every 30 min' },
            { name: 'prompt', type: 'string', description: 'AI prompt to run on schedule' },
            { name: 'job_id', type: 'string', description: 'Job ID (required for delete / pause / resume)' },
            {
                name: 'notify_if', type: 'string',
                description: '推送条件：always=每次推送（默认）| on_alert=仅AI响应含告警词时 | if_changed=仅结果与上次不同时 | never=静默运行 | keyword:XXX=响应含XXX时',
                enum: ['always', 'on_alert', 'if_changed', 'never'],
                default: 'always',
            },
        ],
        examples: [
            '每天早8点推送天气日报',
            '每小时检查 GitHub Issues，notify_if=on_alert 有新 issue 才通知',
            '每天收集竞品信息存入记忆，notify_if=never 静默运行',
            '每4小时查加密货币价格，notify_if=if_changed 价格变化才通知',
        ],
    };
    async execute(params, ctx) {
        const { userId, channel, chatId } = ctx;
        switch (params.action) {
            case 'create': {
                if (!params.name || !params.cron || !params.prompt) {
                    return this.err('name, cron, and prompt are required');
                }
                const cronExpr = params.cron;
                if (!cron.validate(cronExpr)) {
                    return this.err(`Invalid cron expression: "${cronExpr}". ` +
                        'Must be 5 fields: minute hour day-of-month month day-of-week. ' +
                        'Example: "0 9 * * *" = every day at 9am.');
                }
                const notifyIf = params.notify_if ?? 'always';
                const jobId = await memoryStore.saveJob({
                    id: '',
                    name: params.name,
                    cron: cronExpr,
                    prompt: params.prompt,
                    channel,
                    chatId,
                    userId,
                    status: 'active',
                    notifyIf,
                });
                // Register in the live scheduler immediately (don't wait for restart)
                try {
                    const allUserJobs = await memoryStore.getJobs(userId);
                    const savedJob = allUserJobs.find((j) => j.id === jobId)
                        ?? (await memoryStore.getJobs()).find((j) => j.id === jobId);
                    if (savedJob) {
                        scheduler.scheduleJob(savedJob);
                        log.info({ jobId, name: savedJob.name }, 'Job registered in live scheduler');
                    }
                    else {
                        log.warn({ jobId }, 'Saved job not found for live scheduler registration');
                    }
                }
                catch (schedErr) {
                    log.warn({ jobId, err: schedErr }, 'Failed to register job in live scheduler — will run after restart');
                }
                const notifyDesc = {
                    always: '每次运行后推送',
                    on_alert: '仅 AI 响应含告警词时推送',
                    if_changed: '仅结果与上次不同时推送',
                    never: '静默运行（不推送）',
                };
                return this.text([
                    `⏰ **定时任务已创建**`,
                    `ID: \`${jobId}\``,
                    `名称: ${params.name}`,
                    `计划: \`${cronExpr}\``,
                    `推送: ${notifyDesc[notifyIf] ?? notifyIf}`,
                    `Prompt: ${params.prompt}`,
                    ``,
                    `任务已激活，将自动运行。使用 \`schedule_job list\` 查看所有任务。`,
                ].join('\n'));
            }
            case 'list': {
                const jobs = await memoryStore.getJobs(userId);
                if (jobs.length === 0) {
                    return this.text('No scheduled jobs yet. Create one with schedule_job!');
                }
                const emoji = { active: '✅', paused: '⏸', completed: '✔️', failed: '❌' };
                const lines = jobs.map((j) => `${emoji[j.status] ?? '?'} \`${j.id}\` **${j.name}** [\`${j.cron}\`]\n` +
                    `  Prompt: ${j.prompt.slice(0, 80)}${j.prompt.length > 80 ? '…' : ''}\n` +
                    `  Runs: ${j.runCount}${j.lastRun ? `  Last: ${j.lastRun.toLocaleString()}` : ''}`);
                return this.text(`⏰ **Scheduled Jobs (${jobs.length}):**\n\n${lines.join('\n\n')}`);
            }
            case 'delete': {
                if (!params.job_id)
                    return this.err('job_id is required');
                // Verify ownership before deleting
                const allJobs = await memoryStore.getJobs(userId);
                if (!allJobs.find((j) => j.id === params.job_id)) {
                    return this.err(`Job not found or not owned by you: ${params.job_id}`);
                }
                const deleted = await memoryStore.deleteJob(params.job_id);
                if (!deleted)
                    return this.err(`Job not found: ${params.job_id}`);
                // Also cancel the live cron task
                scheduler.cancelJob(params.job_id);
                return this.text(`Job deleted: ${params.job_id}`);
            }
            case 'pause': {
                if (!params.job_id)
                    return this.err('job_id is required');
                // Verify ownership before pausing
                const userJobs = await memoryStore.getJobs(userId);
                if (!userJobs.find((j) => j.id === params.job_id)) {
                    return this.err(`Job not found or not owned by you: ${params.job_id}`);
                }
                await memoryStore.updateJobStatus(params.job_id, 'paused');
                scheduler.cancelJob(params.job_id);
                return this.text(`Job paused: ${params.job_id}`);
            }
            case 'resume': {
                if (!params.job_id)
                    return this.err('job_id is required');
                const jobs = await memoryStore.getJobs(userId);
                const job = jobs.find((j) => j.id === params.job_id);
                if (!job)
                    return this.err(`Job not found: ${params.job_id}`);
                await memoryStore.updateJobStatus(params.job_id, 'active');
                scheduler.scheduleJob({ ...job, status: 'active' });
                return this.text(`▶️ Job resumed: ${job.name}`);
            }
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
}
//# sourceMappingURL=cron_job.js.map