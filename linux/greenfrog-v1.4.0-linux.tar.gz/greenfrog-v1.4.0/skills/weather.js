import { BaseSkill } from './base.js';
// WMO Weather Interpretation Codes → emoji + label
const WMO = {
    0: '☀️ Clear sky', 1: '🌤 Mainly clear', 2: '⛅ Partly cloudy', 3: '☁️ Overcast',
    45: '🌫 Fog', 48: '🌫 Icy fog',
    51: '🌦 Light drizzle', 53: '🌦 Drizzle', 55: '🌧 Heavy drizzle',
    61: '🌧 Light rain', 63: '🌧 Rain', 65: '🌧 Heavy rain',
    71: '🌨 Light snow', 73: '🌨 Snow', 75: '❄️ Heavy snow', 77: '🌨 Snow grains',
    80: '🌦 Light showers', 81: '🌧 Showers', 82: '⛈ Violent showers',
    85: '🌨 Snow showers', 86: '❄️ Heavy snow showers',
    95: '⛈ Thunderstorm', 96: '⛈ Thunderstorm + hail', 99: '⛈ Thunderstorm + heavy hail',
};
function wmo(code) { return WMO[code] ?? `Code ${code}`; }
export class WeatherSkill extends BaseSkill {
    definition = {
        name: 'get_weather',
        description: 'Get current weather and 3-day forecast for any city or location (free, no API key required)',
        category: 'information',
        parameters: [
            { name: 'location', type: 'string', description: 'City name or location (e.g. "Beijing", "New York", "东京")', required: true },
            { name: 'units', type: 'string', description: 'Temperature units: metric (Celsius) or imperial (Fahrenheit)', enum: ['metric', 'imperial'], default: 'metric' },
        ],
        examples: ["What's the weather in Shanghai?", 'Will it rain in London tomorrow?', '北京今天天气怎么样？'],
    };
    async execute(params, _ctx) {
        const location = params.location?.trim();
        if (!location)
            return this.err('Location is required');
        const imperial = params.units === 'imperial';
        try {
            return await this.fetchOpenMeteo(location, imperial);
        }
        catch {
            // fallback to wttr.in
            return this.fetchWttr(location);
        }
    }
    /** Primary: Open-Meteo (fully free, no key) */
    async fetchOpenMeteo(location, imperial) {
        // Step 1: Geocode
        const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1&language=en&format=json`, { signal: AbortSignal.timeout(8_000) });
        if (!geoRes.ok)
            throw new Error('Geocoding failed');
        const geoData = await geoRes.json();
        const place = geoData.results?.[0];
        if (!place)
            return this.err(`Location "${location}" not found. Try a different city name.`);
        // Step 2: Fetch weather
        const tempUnit = imperial ? 'fahrenheit' : 'celsius';
        const windUnit = imperial ? 'mph' : 'kmh';
        const url = [
            `https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}`,
            `&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code,precipitation`,
            `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max`,
            `&timezone=${encodeURIComponent(place.timezone)}`,
            `&forecast_days=4&temperature_unit=${tempUnit}&wind_speed_unit=${windUnit}`,
        ].join('');
        const wRes = await fetch(url, { signal: AbortSignal.timeout(8_000) });
        if (!wRes.ok)
            throw new Error('Weather fetch failed');
        const w = await wRes.json();
        const u = imperial ? '°F' : '°C';
        const wu = imperial ? 'mph' : 'km/h';
        const c = w.current;
        // Current conditions
        const lines = [
            `🌍 **${place.name}, ${place.country}**`,
            `${wmo(c.weather_code)}`,
            `🌡 **${c.temperature_2m}${u}** (feels like ${c.apparent_temperature}${u})`,
            `💧 Humidity: ${c.relative_humidity_2m}%   💨 Wind: ${c.wind_speed_10m} ${wu}`,
            c.precipitation > 0 ? `🌧 Precipitation: ${c.precipitation} mm` : '',
            '',
            '**3-Day Forecast:**',
        ].filter(s => s !== undefined);
        // Daily forecast (skip today at index 0)
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        for (let i = 1; i <= 3 && i < w.daily.time.length; i++) {
            const d = new Date(w.daily.time[i]);
            const dayName = days[d.getUTCDay()];
            const rain = w.daily.precipitation_probability_max[i];
            lines.push(`${dayName}: ${wmo(w.daily.weather_code[i])} · ` +
                `${w.daily.temperature_2m_min[i]}–${w.daily.temperature_2m_max[i]}${u}` +
                (rain > 0 ? ` · 🌧 ${rain}%` : ''));
        }
        return this.text(lines.join('\n'));
    }
    /** Fallback: wttr.in */
    async fetchWttr(location) {
        try {
            const res = await fetch(`https://wttr.in/${encodeURIComponent(location)}?format=j1`, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(8_000) });
            if (!res.ok)
                return this.err(`Cannot get weather for "${location}"`);
            const data = await res.json();
            const cur = data['current_condition'][0];
            const area = data['nearest_area'][0];
            const areaName = area['areaName'][0]?.value;
            return this.text([
                `🌍 **${areaName}**`,
                `🌡 ${cur['temp_C']}°C (feels like ${cur['FeelsLikeC']}°C)`,
                `${cur['weatherDesc'][0]?.value}`,
                `💧 Humidity: ${cur['humidity']}%   💨 Wind: ${cur['windspeedKmph']} km/h`,
            ].join('\n'));
        }
        catch (err) {
            return this.err(`Failed to get weather: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=weather.js.map