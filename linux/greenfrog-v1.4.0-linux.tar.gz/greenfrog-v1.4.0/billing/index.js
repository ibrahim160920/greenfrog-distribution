/**
 * Multi-tenant Billing System - MVP implementation
 * Provides subscription tiers, usage tracking, and billing reports
 */
/**
 * Subscription tiers (MVP: hardcoded)
 */
export const SUBSCRIPTION_TIERS = [
    {
        id: 'free',
        name: 'Free',
        description: 'Perfect for personal projects and testing',
        priceUsd: 0,
        billingPeriod: 'monthly',
        features: {
            monthlyTokenLimit: 100000,
            monthlyCostLimitUsd: 5,
            maxWorkspaces: 1,
            maxAgents: 3,
            maxCustomSkills: 5,
            prioritySupport: false,
            advancedAnalytics: false,
            apiAccess: false,
        },
    },
    {
        id: 'pro',
        name: 'Professional',
        description: 'For power users and small teams',
        priceUsd: 29,
        billingPeriod: 'monthly',
        features: {
            monthlyTokenLimit: 1000000,
            monthlyCostLimitUsd: 50,
            maxWorkspaces: 5,
            maxAgents: 20,
            maxCustomSkills: 50,
            prioritySupport: true,
            advancedAnalytics: true,
            apiAccess: true,
        },
    },
    {
        id: 'enterprise',
        name: 'Enterprise',
        description: 'For large teams and organizations',
        priceUsd: 199,
        billingPeriod: 'monthly',
        features: {
            monthlyTokenLimit: 10000000,
            monthlyCostLimitUsd: 500,
            maxWorkspaces: 50,
            maxAgents: 200,
            maxCustomSkills: 500,
            prioritySupport: true,
            advancedAnalytics: true,
            apiAccess: true,
        },
    },
];
/**
 * Get all subscription tiers
 */
export function getSubscriptionTiers() {
    return SUBSCRIPTION_TIERS;
}
/**
 * Get a specific tier by ID
 */
export function getSubscriptionTier(id) {
    return SUBSCRIPTION_TIERS.find(t => t.id === id) || null;
}
/**
 * Calculate usage cost based on token usage
 * This is a simplified pricing model for MVP
 */
export function calculateUsageCost(provider, model, inputTokens, outputTokens) {
    // Simplified pricing (per 1M tokens)
    const pricing = {
        'anthropic:claude-sonnet-4-6': { input: 3, output: 15 },
        'anthropic:claude-opus-4-6': { input: 15, output: 75 },
        'openai:gpt-4o': { input: 5, output: 15 },
        'openai:gpt-4o-mini': { input: 0.15, output: 0.6 },
        'ollama:*': { input: 0, output: 0 }, // Local models are free
    };
    const key = `${provider}:${model}`;
    const prices = pricing[key] || pricing[`${provider}:*`] || { input: 1, output: 3 };
    const inputCost = (inputTokens / 1000000) * prices.input;
    const outputCost = (outputTokens / 1000000) * prices.output;
    return inputCost + outputCost;
}
/**
 * Check if user is within tier limits
 */
export function checkTierLimits(tier, usage) {
    const violations = [];
    if (usage.monthlyTokens > tier.features.monthlyTokenLimit) {
        violations.push(`Token limit exceeded: ${usage.monthlyTokens.toLocaleString()} / ${tier.features.monthlyTokenLimit.toLocaleString()}`);
    }
    if (usage.monthlyCostUsd > tier.features.monthlyCostLimitUsd) {
        violations.push(`Cost limit exceeded: $${usage.monthlyCostUsd.toFixed(2)} / $${tier.features.monthlyCostLimitUsd.toFixed(2)}`);
    }
    if (usage.workspaceCount > tier.features.maxWorkspaces) {
        violations.push(`Workspace limit exceeded: ${usage.workspaceCount} / ${tier.features.maxWorkspaces}`);
    }
    if (usage.agentCount > tier.features.maxAgents) {
        violations.push(`Agent limit exceeded: ${usage.agentCount} / ${tier.features.maxAgents}`);
    }
    if (usage.customSkillCount > tier.features.maxCustomSkills) {
        violations.push(`Custom skill limit exceeded: ${usage.customSkillCount} / ${tier.features.maxCustomSkills}`);
    }
    return {
        withinLimits: violations.length === 0,
        violations,
    };
}
//# sourceMappingURL=index.js.map