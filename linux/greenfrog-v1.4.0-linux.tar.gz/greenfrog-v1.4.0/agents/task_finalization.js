/**
 * Shared task-done finalization logic for GreenFrog P4.6.2.
 *
 * Both the worker loop done path (team.ts) and the heartbeat done path
 * (heartbeat.ts) must run the same evaluation + artifact detection pipeline
 * when a task transitions to `done`. This module provides a single shared
 * helper so the logic is never duplicated.
 *
 * Callers are responsible for writing the returned fields into the task
 * metadata update — this function performs no DB writes.
 */
import { buildTaskContract } from './contract.js';
import { evaluateDoneCriteria } from './evaluate.js';
import { detectArtifactsFromSummary, mergeArtifacts, parseAgentDeclaredArtifacts } from './artifact.js';
import { generateAcceptanceChecks } from './check_generator.js';
// ── Core function ─────────────────────────────────────────────────────────────
/**
 * Run artifact detection + acceptance evaluation for a completed task.
 *
 * Pure evaluation — no DB access, no side effects.
 * The caller merges the returned fields into its metadata update payload.
 *
 * @param task          The task record as it exists just before done write
 * @param resultSummary The agent's result text (may be null)
 * @param runId         The run ID for artifact provenance
 */
export async function finalizeTaskDone(task, resultSummary, runId) {
    const summary = resultSummary ?? '';
    // ── Artifact detection ────────────────────────────────────────────────────
    const existingArtifacts = Array.isArray((task.metadata ?? {})['artifacts'])
        ? task.metadata['artifacts']
        : [];
    const autoArtifacts = detectArtifactsFromSummary(summary, runId);
    const declaredArtifacts = parseAgentDeclaredArtifacts(summary, runId);
    const mergedArtifacts = mergeArtifacts(existingArtifacts, [...declaredArtifacts, ...autoArtifacts]);
    // ── Acceptance checks ─────────────────────────────────────────────────────
    const contract = buildTaskContract(task);
    const manualChecks = contract.acceptanceChecks ?? [];
    const expectedEvidence = typeof (task.metadata ?? {})['currentPlan'] === 'object'
        ? task.metadata['currentPlan']['expectedEvidence']
        : undefined;
    const effectiveChecks = manualChecks.length > 0
        ? manualChecks
        : generateAcceptanceChecks(contract, expectedEvidence, mergedArtifacts.length > 0 ? mergedArtifacts : undefined);
    // ── Evaluate ──────────────────────────────────────────────────────────────
    const doneCriteria = contract.doneCriteria ?? [];
    const evalResult = await evaluateDoneCriteria(doneCriteria, summary, effectiveChecks.length > 0 ? effectiveChecks : undefined);
    return {
        evalResult,
        artifacts: mergedArtifacts.length > 0 ? mergedArtifacts : existingArtifacts,
        effectiveChecksCount: effectiveChecks.length,
    };
}
//# sourceMappingURL=task_finalization.js.map