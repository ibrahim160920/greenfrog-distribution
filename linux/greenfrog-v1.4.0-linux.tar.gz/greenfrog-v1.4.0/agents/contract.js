/**
 * Task Contract layer for GreenFrog P4.
 *
 * A TaskContract is a structured, immutable description of what a task
 * must accomplish and under what constraints. It is derived once at
 * dispatch time from the existing task record (no DB migration needed).
 *
 * The contract shapes:
 *   - The worker prompt (objective + done criteria injected)
 *   - The recovery policy (retryPolicy drives retry logic)
 *   - Evaluation (doneCriteria evaluated post-execution)
 */
// ── Defaults ─────────────────────────────────────────────────────────────────
const DEFAULT_RETRY_POLICY = {
    maxAttempts: 2,
    retryDelayMs: 0,
    retryOn: ['provider_error', 'tool_error', 'environment_issue'],
};
// ── Core function ─────────────────────────────────────────────────────────────
/**
 * Derive a TaskContract from an existing TeamTask.
 * This is a pure function — no I/O, no DB access.
 */
export function buildTaskContract(task) {
    const m = task.metadata ?? {};
    // Support nested contract object in metadata (e.g. { contract: { doneCriteria: [...] } })
    // Flat fields take precedence; nested contract is a fallback.
    const nestedContract = (m['contract'] !== null && typeof m['contract'] === 'object' && !Array.isArray(m['contract']))
        ? m['contract']
        : null;
    // Objective: prefer explicit field, then nested contract, fall back to title
    const objective = (typeof m['objective'] === 'string' && m['objective'].trim())
        ? m['objective']
        : (typeof nestedContract?.['objective'] === 'string' && nestedContract['objective'].trim())
            ? nestedContract['objective'].trim()
            : task.title.trim() || '完成分配的任务';
    // Done criteria: flat field → nested contract → empty
    let doneCriteria = [];
    if (Array.isArray(m['doneCriteria'])) {
        doneCriteria = m['doneCriteria'].filter((x) => typeof x === 'string');
    }
    else if (typeof m['doneCriteria'] === 'string' && m['doneCriteria'].trim()) {
        doneCriteria = m['doneCriteria'].split('\n').map((s) => s.trim()).filter(Boolean);
    }
    else if (nestedContract && Array.isArray(nestedContract['doneCriteria'])) {
        doneCriteria = nestedContract['doneCriteria'].filter((x) => typeof x === 'string');
    }
    // Constraints: flat → nested contract
    let constraints = [];
    if (Array.isArray(m['constraints'])) {
        constraints = m['constraints'].filter((x) => typeof x === 'string');
    }
    else if (typeof m['constraints'] === 'string' && m['constraints'].trim()) {
        constraints = m['constraints'].split('\n').map((s) => s.trim()).filter(Boolean);
    }
    else if (nestedContract && Array.isArray(nestedContract['constraints'])) {
        constraints = nestedContract['constraints'].filter((x) => typeof x === 'string');
    }
    // Inputs: flat → nested contract
    const inputs = (m['inputs'] !== null && typeof m['inputs'] === 'object' && !Array.isArray(m['inputs']))
        ? m['inputs']
        : (nestedContract && nestedContract['inputs'] !== null && typeof nestedContract['inputs'] === 'object' && !Array.isArray(nestedContract['inputs']))
            ? nestedContract['inputs']
            : {};
    // Allowed tools
    let allowedTools = [];
    if (Array.isArray(m['allowedTools'])) {
        allowedTools = m['allowedTools'].filter((x) => typeof x === 'string');
    }
    else if (nestedContract && Array.isArray(nestedContract['allowedTools'])) {
        allowedTools = nestedContract['allowedTools'].filter((x) => typeof x === 'string');
    }
    // Retry policy: flat → nested contract → defaults
    const policyOverride = (m['retryPolicy'] !== null && typeof m['retryPolicy'] === 'object' && !Array.isArray(m['retryPolicy']))
        ? m['retryPolicy']
        : (nestedContract && nestedContract['retryPolicy'] !== null && typeof nestedContract['retryPolicy'] === 'object' && !Array.isArray(nestedContract['retryPolicy']))
            ? nestedContract['retryPolicy']
            : {};
    const retryPolicy = {
        ...DEFAULT_RETRY_POLICY,
        ...policyOverride,
        retryOn: Array.isArray(policyOverride.retryOn)
            ? policyOverride.retryOn
            : DEFAULT_RETRY_POLICY.retryOn,
    };
    // Acceptance checks: flat → nested contract
    let acceptanceChecks = [];
    const rawChecks = Array.isArray(m['acceptanceChecks'])
        ? m['acceptanceChecks']
        : (nestedContract && Array.isArray(nestedContract['acceptanceChecks']))
            ? nestedContract['acceptanceChecks']
            : null;
    if (rawChecks) {
        acceptanceChecks = rawChecks.filter((x) => x !== null && typeof x === 'object' && !Array.isArray(x) &&
            typeof x['type'] === 'string' &&
            typeof x['target'] === 'string');
    }
    // Recovery mode (P4.3): restartable (default) or resumable
    const recoveryMode = m['recoveryMode'] === 'resumable' ? 'resumable' : 'restartable';
    // Source
    const metaWorkflowId = typeof m['workflowId'] === 'string' ? m['workflowId'] : null;
    const source = (typeof m['source'] === 'string' && m['source'].trim())
        ? m['source']
        : metaWorkflowId
            ? `workflow:${metaWorkflowId}`
            : 'manual';
    return {
        taskId: task.id,
        objective,
        doneCriteria,
        constraints,
        inputs,
        allowedTools,
        retryPolicy,
        acceptanceChecks,
        recoveryMode,
        source,
        builtAt: new Date().toISOString(),
    };
}
// ── Prompt rendering ──────────────────────────────────────────────────────────
/**
 * Render a contract into the structured section of a worker prompt.
 * Returns a multi-line string to be injected into the prompt.
 */
export function renderContractPrompt(contract) {
    const lines = [
        `# Task Contract`,
        `**Task ID:** ${contract.taskId}`,
        `**Source:** ${contract.source}`,
        ``,
        `## Objective`,
        contract.objective,
    ];
    if (contract.doneCriteria.length > 0) {
        lines.push(``, `## Done Criteria`);
        for (const c of contract.doneCriteria) {
            lines.push(`- ${c}`);
        }
    }
    if (contract.constraints.length > 0) {
        lines.push(``, `## Constraints`);
        for (const c of contract.constraints) {
            lines.push(`- ${c}`);
        }
    }
    if (Object.keys(contract.inputs).length > 0) {
        lines.push(``, `## Inputs`);
        for (const [k, v] of Object.entries(contract.inputs)) {
            lines.push(`- **${k}:** ${JSON.stringify(v)}`);
        }
    }
    if (contract.allowedTools.length > 0) {
        lines.push(``, `## Allowed Tools`);
        lines.push(contract.allowedTools.join(', '));
    }
    lines.push(``, `---`, `Complete the task and write a concise resultSummary when done.`);
    return lines.join('\n');
}
//# sourceMappingURL=contract.js.map