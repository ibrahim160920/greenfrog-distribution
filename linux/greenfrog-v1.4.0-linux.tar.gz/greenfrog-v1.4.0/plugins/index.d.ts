export declare class PluginWatcher {
    private watcher;
    private debounceTimers;
    get watchDir(): string;
    start(): void;
    stop(): Promise<void>;
    /**
     * Shared load logic: path-guard → vet → update hash → dynamic import → register.
     * Returns the registered skill name on success, null on any failure.
     */
    loadFile(filePath: string): Promise<{
        name: string;
    } | null>;
    private debounce;
    private handleAdd;
    private handleChange;
    private handleUnlink;
}
export declare const pluginWatcher: PluginWatcher;
//# sourceMappingURL=index.d.ts.map