/**
 * store_rule_tracking.ts — SQLite persistence for rule application stats (Sprint M4)
 *
 * Provides durable tracking of per-rule success/failure counts.
 * Survives process restarts — the in-memory ruleApplicationCache in rule_tracking.ts
 * is now populated from this table on first access.
 *
 * Table: rule_tracking_stats
 *   PK: (rule_id, workspace_id, channel)
 *   Columns: total_applications, successful_applications, failed_applications,
 *            last_used_at, created_at
 *
 * All writes are synchronous (better-sqlite3). The caller wraps in async to
 * match IMemoryStore async declarations.
 */
export function createRuleTrackingStore(db) {
    // ── Prepared statements ────────────────────────────────────────────────────
    const upsertStmt = db.prepare(`
    INSERT INTO rule_tracking_stats
      (rule_id, workspace_id, channel, total_applications, successful_applications,
       failed_applications, last_used_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, unixepoch('now') * 1000)
    ON CONFLICT (rule_id, workspace_id, channel) DO UPDATE SET
      total_applications      = total_applications + excluded.total_applications,
      successful_applications = successful_applications + excluded.successful_applications,
      failed_applications     = failed_applications + excluded.failed_applications,
      last_used_at            = excluded.last_used_at
  `);
    const getOneStmt = db.prepare(`
    SELECT rule_id, workspace_id, channel,
           total_applications, successful_applications, failed_applications,
           last_used_at, created_at
    FROM rule_tracking_stats
    WHERE rule_id = ? AND workspace_id = ? AND channel = ?
  `);
    const getAllStmt = db.prepare(`
    SELECT rule_id, workspace_id, channel,
           total_applications, successful_applications, failed_applications,
           last_used_at, created_at
    FROM rule_tracking_stats
    WHERE workspace_id = ? AND channel = ?
  `);
    // ── Helpers ────────────────────────────────────────────────────────────────
    function rowToStats(row) {
        return {
            ruleId: row['rule_id'],
            workspaceId: row['workspace_id'],
            channel: row['channel'],
            totalApplications: row['total_applications'] ?? 0,
            successfulApplications: row['successful_applications'] ?? 0,
            failedApplications: row['failed_applications'] ?? 0,
            lastUsedAt: row['last_used_at']
                ? new Date(row['last_used_at'])
                : null,
            createdAt: new Date(row['created_at']),
        };
    }
    // ── Public API ─────────────────────────────────────────────────────────────
    return {
        /**
         * Record a rule application event (upsert: +1 to total, +1 to success or failure).
         */
        upsertRuleTrackingStat(workspaceId, channel, ruleId, success) {
            const successDelta = success ? 1 : 0;
            const failureDelta = success ? 0 : 1;
            const now = Date.now();
            upsertStmt.run(ruleId, workspaceId, channel, 1, successDelta, failureDelta, now);
        },
        /**
         * Get persisted stats for a single rule in a workspace.
         * Returns null if this rule has never been tracked.
         */
        getPersistedRuleStats(workspaceId, channel, ruleId) {
            const row = getOneStmt.get(ruleId, workspaceId, channel);
            if (!row)
                return null;
            return rowToStats(row);
        },
        /**
         * Get persisted stats for all rules in a workspace.
         * Returns a Map keyed by ruleId.
         */
        getAllPersistedRuleStats(workspaceId, channel) {
            const rows = getAllStmt.all(workspaceId, channel);
            const map = new Map();
            for (const row of rows) {
                const stats = rowToStats(row);
                map.set(stats.ruleId, stats);
            }
            return map;
        },
    };
}
//# sourceMappingURL=store_rule_tracking.js.map