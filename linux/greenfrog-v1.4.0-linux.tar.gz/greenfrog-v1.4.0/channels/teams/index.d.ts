import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class TeamsChannel extends BaseChannel {
    readonly name: "teams";
    private adapter;
    private server;
    private _running;
    private _appId;
    private readonly convRefs;
    start(): Promise<void>;
    stop(): Promise<void>;
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
    private splitMessage;
}
//# sourceMappingURL=index.d.ts.map