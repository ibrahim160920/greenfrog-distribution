import { readFileSync, existsSync, mkdirSync, writeFileSync, chmodSync } from 'fs';
import { join, resolve } from 'path';
import { homedir, hostname, userInfo, platform } from 'os';
import { execSync } from 'child_process';
import { randomBytes, pbkdf2Sync, createCipheriv, createDecipheriv } from 'crypto';
import yaml from 'yaml';
import { config as loadDotenv } from 'dotenv';
import { z } from 'zod';
import { ConfigError } from '../utils/errors.js';
import { resolveRoleFromConfig } from '../authz/roles.js';
const DEFAULT_SECRET = 'greenfrog-local-secret';
// ── Config encryption (AES-256-GCM) ──────────────────────────────────────────
function getEncryptionKey() {
    const machineId = hostname() + userInfo().username;
    // GF_CONFIG_PASSPHRASE: if set, adds user-controlled entropy so the key is no longer
    // purely machine-derived. Set it in .env to make config portable across machines.
    const passphrase = process.env.GF_CONFIG_PASSPHRASE ?? '';
    return pbkdf2Sync(machineId + passphrase, 'greenfrog-salt-v1', 100_000, 32, 'sha256');
}
function encryptValue(plain) {
    if (!plain || plain.startsWith('enc:v1:'))
        return plain;
    const key = getEncryptionKey();
    const iv = randomBytes(16);
    const cipher = createCipheriv('aes-256-gcm', key, iv);
    const ct = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();
    return `enc:v1:${iv.toString('base64')}:${tag.toString('base64')}:${ct.toString('base64')}`;
}
function decryptValue(enc) {
    if (!enc.startsWith('enc:v1:'))
        return enc;
    const parts = enc.split(':');
    if (parts.length !== 5)
        return enc;
    try {
        const key = getEncryptionKey();
        const iv = Buffer.from(parts[2], 'base64');
        const tag = Buffer.from(parts[3], 'base64');
        const ct = Buffer.from(parts[4], 'base64');
        const decipher = createDecipheriv('aes-256-gcm', key, iv);
        decipher.setAuthTag(tag);
        return decipher.update(ct).toString('utf8') + decipher.final('utf8');
    }
    catch {
        return enc;
    }
}
/** Sentinel value returned by getPublicConfig() for set sensitive fields */
export const CONFIG_MASKED_SENTINEL = '__GF_MASKED__';
/** Field names that hold secrets and should be encrypted in config.yaml */
const SENSITIVE_FIELD_NAMES = new Set([
    'apiKey', 'token', 'botToken', 'appToken', 'signingSecret', 'secret', 'appId',
    'corpSecret', 'encodingAESKey',
    'clientSecret', 'authToken', 'refreshToken', 'accessToken', 'privateKey',
    // New channels
    'appSecret', 'appPassword', 'channelAccessToken', 'channelSecret',
    // OAuth / JWT
    'jwtSecret',
]);
function traverseSensitiveFields(obj, transform) {
    if (typeof obj !== 'object' || obj === null)
        return obj;
    if (Array.isArray(obj))
        return obj.map((item) => traverseSensitiveFields(item, transform));
    const result = {};
    for (const [key, val] of Object.entries(obj)) {
        if (SENSITIVE_FIELD_NAMES.has(key) && typeof val === 'string' && val) {
            result[key] = transform(val);
        }
        else {
            result[key] = traverseSensitiveFields(val, transform);
        }
    }
    return result;
}
/** Recursively normalize identity/member arrays to string[] (YAML may parse numeric IDs as numbers) */
function normalizeAllowedUsers(obj) {
    if (typeof obj !== 'object' || obj === null)
        return obj;
    if (Array.isArray(obj))
        return obj.map((item) => normalizeAllowedUsers(item));
    const result = {};
    for (const [key, val] of Object.entries(obj)) {
        if ((key === 'allowedUsers' || key === 'admin' || key === 'user' || key === 'readonly' || key === 'members' || key === 'externalGroups' || key === 'scopes') && Array.isArray(val)) {
            result[key] = val.map(String);
        }
        else {
            result[key] = normalizeAllowedUsers(val);
        }
    }
    return result;
}
// Load .env from project root
loadDotenv({ path: resolve(process.cwd(), '.env') });
function parseIntListEnv(value) {
    if (!value)
        return undefined;
    const parsed = value
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean)
        .map((item) => parseInt(item, 10))
        .filter((item) => Number.isFinite(item));
    return parsed.length > 0 ? parsed : undefined;
}
function parseCommandListEnv(value) {
    if (!value)
        return undefined;
    const parsed = value
        .split(';;')
        .map((item) => item.trim())
        .filter(Boolean);
    return parsed.length > 0 ? parsed : undefined;
}
function parseStringMapEnv(name, value) {
    if (!value)
        return undefined;
    try {
        const parsed = JSON.parse(value);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            throw new Error('not an object');
        }
        const entries = Object.entries(parsed)
            .filter(([key, item]) => key.trim().length > 0 && typeof item === 'string' && item.trim().length > 0)
            .map(([key, item]) => [key, item.trim()]);
        return entries.length > 0 ? Object.fromEntries(entries) : undefined;
    }
    catch {
        throw new ConfigError(`${name} must be a JSON object with non-empty string values`);
    }
}
// ── Zod runtime validation schema ─────────────────────────────────────────────
const portSchema = z.number().int().min(1).max(65535);
const nonEmptyStr = z.string().min(1);
const ProviderSchema = z.object({
    apiKey: nonEmptyStr,
    model: z.string().optional(),
    baseUrl: z.string().url().optional(),
});
/** Shared relay/auth fields for all OpenAI-compatible compat providers */
const RelayProviderSchema = ProviderSchema.extend({
    authMode: z.enum(['bearer', 'apikey', 'raw']).optional(),
    authHeader: z.string().min(1).optional(),
    authScheme: z.string().optional(),
    extraHeaders: z.record(z.string(), z.string().min(1)).optional(),
    disableResponseStorage: z.boolean().optional(),
});
const OpenAIProviderSchema = ProviderSchema.extend({
    useResponsesApi: z.boolean().optional(),
    reasoningEffort: z.string().optional(),
    authMode: z.enum(['bearer', 'apikey', 'raw']).optional(),
    authHeader: z.string().min(1).optional(),
    authScheme: z.string().optional(),
    extraHeaders: z.record(z.string(), z.string().min(1)).optional(),
    sendClientRequestId: z.boolean().optional(),
    disableResponseStorage: z.boolean().optional(),
    responsesMaxAttempts: z.number().int().min(1).max(10).optional(),
    responsesRetryBaseDelayMs: z.number().int().min(0).max(60000).optional(),
});
const OllamaProviderSchema = z.object({
    baseUrl: z.string().url(),
    model: z.string().optional(),
});
const AllowedUsersSchema = z.array(z.string()).optional();
const GreenFrogConfigSchema = z.object({
    dataDir: nonEmptyStr,
    gateway: z.object({
        port: portSchema,
        host: nonEmptyStr,
        secret: nonEmptyStr,
    }),
    webui: z.object({
        port: portSchema,
        host: nonEmptyStr,
        enabled: z.boolean(),
        publicBaseUrl: z.string().url().optional(),
    }),
    defaultProvider: z.enum(['anthropic', 'openai', 'ollama', 'gemini', 'mistral', 'groq', 'deepseek', 'qwen', 'kimi', 'glm']),
    defaultModel: nonEmptyStr,
    providers: z.object({
        anthropic: ProviderSchema.extend({
            extraHeaders: z.record(z.string(), z.string().min(1)).optional(),
        }).optional(),
        openai: OpenAIProviderSchema.optional(),
        ollama: OllamaProviderSchema.optional(),
        gemini: RelayProviderSchema.optional(),
        mistral: RelayProviderSchema.optional(),
        groq: RelayProviderSchema.optional(),
        deepseek: RelayProviderSchema.optional(),
        qwen: RelayProviderSchema.optional(),
        kimi: RelayProviderSchema.optional(),
        glm: RelayProviderSchema.optional(),
    }),
    channels: z.object({
        telegram: z.object({
            enabled: z.boolean(),
            token: z.string().optional(),
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        discord: z.object({
            enabled: z.boolean(),
            token: z.string().optional(),
            clientId: z.string().optional(),
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        slack: z.object({
            enabled: z.boolean(),
            botToken: z.string().optional(),
            appToken: z.string().optional(),
            signingSecret: z.string().optional(),
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        whatsapp: z.object({
            enabled: z.boolean(),
            allowedUsers: AllowedUsersSchema,
            groupPrefix: z.string().optional(),
        }).optional(),
        wecom: z.object({
            enabled: z.boolean(),
            webhookUrl: z.string().optional(),
            corpId: z.string().optional(),
            corpSecret: z.string().optional(),
            agentId: z.string().optional(),
            token: z.string().optional(),
            encodingAESKey: z.string().optional(),
            callbackPort: portSchema.optional(),
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        web: z.object({
            enabled: z.boolean(),
            port: portSchema.optional(),
        }).optional(),
        feishu: z.object({
            enabled: z.boolean(),
            appId: nonEmptyStr,
            appSecret: nonEmptyStr,
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        dingtalk: z.object({
            enabled: z.boolean(),
            clientId: nonEmptyStr,
            clientSecret: nonEmptyStr,
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        teams: z.object({
            enabled: z.boolean(),
            appId: nonEmptyStr,
            appPassword: nonEmptyStr,
            port: portSchema.optional(),
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        line: z.object({
            enabled: z.boolean(),
            channelAccessToken: nonEmptyStr,
            channelSecret: nonEmptyStr,
            port: portSchema.optional(),
            allowedUsers: AllowedUsersSchema,
        }).optional(),
        matrix: z.object({
            enabled: z.boolean(),
            homeserverUrl: z.string().url(),
            accessToken: nonEmptyStr,
            allowedUsers: AllowedUsersSchema,
        }).optional(),
    }),
    sandbox: z.object({
        enabled: z.boolean().optional(),
        image: z.string().optional(),
        memoryMb: z.number().int().min(32).max(4096).optional(),
        cpuLimit: z.number().min(0.1).max(16).optional(),
        pidsLimit: z.number().int().min(16).max(1024).optional(),
        networkDisabled: z.boolean().optional(),
        autoRebuildImage: z.boolean().optional(),
        fallbackPolicy: z.enum(['allow', 'warn', 'deny']).default('allow'),
    }).optional(),
    skills: z.object({
        weather: z.object({ apiKey: nonEmptyStr }).optional(),
        github: z.object({ token: nonEmptyStr }).optional(),
        news: z.object({ apiKey: nonEmptyStr }).optional(),
        search: z.object({ apiKey: nonEmptyStr }).optional(),
        wolfram: z.object({ appId: nonEmptyStr }).optional(),
    }),
    tls: z.object({
        certFile: z.string().optional(),
        keyFile: z.string().optional(),
    }).optional(),
    systemPrompt: z.string().optional(),
    persona: z.string().optional(),
    memory: z.object({
        enabled: z.boolean(),
        maxEntries: z.number().int().min(100),
        ttlDays: z.number().int().min(1),
        embeddingModel: z.string().optional(),
    }),
    roles: z.object({
        admin: z.array(z.string()).optional(),
        user: z.array(z.string()).optional(),
        readonly: z.array(z.string()).optional(),
        groups: z.record(z.object({
            role: z.enum(['admin', 'user', 'readonly']),
            members: z.array(z.string()),
            externalGroups: z.array(z.string()).optional(),
        })).optional(),
        defaultRole: z.enum(['admin', 'user', 'readonly', 'deny']).optional(),
    }).optional(),
    log: z.object({
        level: z.enum(['trace', 'debug', 'info', 'warn', 'error', 'fatal']),
        pretty: z.boolean(),
    }),
    agentMaxIterations: z.number().int().min(1).max(200).optional(),
    agentMaxExecutionMs: z.number().int().min(1000).max(900000).optional(),
    agentMaxConcurrency: z.number().int().min(1).max(256).optional(),
    agentMaxConcurrencyPerUser: z.number().int().min(1).max(64).optional(),
    hardQuotaReservationTokens: z.number().int().min(256).max(65536).optional(),
    database: z.object({
        url: nonEmptyStr,
        poolMax: z.number().int().min(1).max(100).optional(),
        idleTimeoutMs: z.number().int().min(1000).optional(),
    }).optional(),
    metrics: z.object({
        enabled: z.boolean().optional(),
        token: z.string().optional(),
    }).optional(),
    queue: z.object({
        redisUrl: z.string().optional(),
        concurrency: z.number().int().min(1).max(64).optional(),
        maxPendingJobs: z.number().int().min(1).max(1_000_000).optional(),
    }).optional(),
    auth: z.object({
        enabled: z.boolean().optional(),
        issuer: z.string().optional(),
        clientId: z.string().optional(),
        clientSecret: z.string().optional(),
        redirectUri: z.string().optional(),
        jwtSecret: z.string().optional(),
        jwtExpiresIn: z.string().optional(),
        scopes: z.array(z.string()).optional(),
        groupClaim: z.string().optional(),
    }).optional(),
    evolution: z.object({
        projectMode: z.enum(['off', 'local', 'source-owner']).optional(),
        ruleSync: z.object({
            enabled: z.boolean().optional(),
            mode: z.enum(['manual', 'auto']).optional(),
            uploadRules: z.boolean().optional(),
            uploadStats: z.boolean().optional(),
            anonymize: z.boolean().optional(),
            reviewBeforeUpload: z.boolean().optional(),
            remoteUrl: z.string().optional(),
            accessToken: z.string().optional(),
            syncIntervalHours: z.number().min(1).max(24 * 365).optional(),
        }).optional(),
        scheduler: z.object({
            enabled: z.boolean().optional(),
            scoringIntervalHours: z.number().min(1).max(24 * 365).optional(),
            uploadIntervalHours: z.number().min(1).max(24 * 365).optional(),
            syncIntervalHours: z.number().min(1).max(24 * 365).optional(),
            cleanupIntervalHours: z.number().min(1).max(24 * 365).optional(),
            sourceRepoIntervalHours: z.number().min(1).max(24 * 365).optional(),
            trackingCleanupDays: z.number().int().min(1).max(3650).optional(),
        }).optional(),
        sourceRepo: z.object({
            enabled: z.boolean().optional(),
            repoPath: z.string().optional(),
            outputPath: z.string().optional(),
            summaryPath: z.string().optional(),
            minConfidence: z.number().min(0).max(100).optional(),
            minEvidenceCount: z.number().int().min(1).max(100000).optional(),
            minWorkspaceCount: z.number().int().min(1).max(100000).optional(),
            autoCommit: z.boolean().optional(),
            autoPush: z.boolean().optional(),
            createPullRequest: z.boolean().optional(),
            remote: z.string().optional(),
            repo: z.string().optional(),
            baseBranch: z.string().optional(),
            headOwner: z.string().optional(),
            pullRequestTitle: z.string().optional(),
            branchPrefix: z.string().optional(),
            commitMessage: z.string().optional(),
        }).optional(),
        codeRepo: z.object({
            enabled: z.boolean().optional(),
            repoPath: z.string().optional(),
            manifestPath: z.string().optional(),
            summaryPath: z.string().optional(),
            patchPath: z.string().optional(),
            gateProfile: z.enum(['strict', 'balanced', 'aggressive', 'custom']).optional(),
            autoGenerateCandidates: z.boolean().optional(),
            generationLookbackDays: z.number().int().min(1).max(365).optional(),
            generationMaxAuditEntries: z.number().int().min(1).max(10000).optional(),
            generationMaxCandidates: z.number().int().min(1).max(100).optional(),
            generationMaxEvidencePerCandidate: z.number().int().min(1).max(100).optional(),
            generationMaxFileContextChars: z.number().int().min(256).max(200000).optional(),
            generationMinEvidenceCount: z.number().int().min(1).max(100000).optional(),
            generationMinFailureCount: z.number().int().min(1).max(100000).optional(),
            generationMinSuccessCount: z.number().int().min(1).max(100000).optional(),
            generationProvider: z.string().optional(),
            generationModel: z.string().optional(),
            minDecisionScore: z.number().min(0).max(100).optional(),
            minValidationCount: z.number().int().min(1).max(100000).optional(),
            minSuccessRate: z.number().min(0).max(1).optional(),
            autoApplyPatch: z.boolean().optional(),
            autoCommit: z.boolean().optional(),
            autoPush: z.boolean().optional(),
            createPullRequest: z.boolean().optional(),
            remote: z.string().optional(),
            repo: z.string().optional(),
            baseBranch: z.string().optional(),
            headOwner: z.string().optional(),
            pullRequestTitle: z.string().optional(),
            branchPrefix: z.string().optional(),
            commitMessage: z.string().optional(),
        }).optional(),
        release: z.object({
            enabled: z.boolean().optional(),
            repoPath: z.string().optional(),
            manifestPath: z.string().optional(),
            notesPath: z.string().optional(),
            bump: z.enum(['none', 'patch', 'minor', 'major']).optional(),
            approvalWindowStartHourUtc: z.number().int().min(0).max(23).optional(),
            approvalWindowEndHourUtc: z.number().int().min(0).max(23).optional(),
            approvedWeekdaysUtc: z.array(z.number().int().min(0).max(6)).optional(),
            healthCheckCommands: z.array(z.string().min(1)).optional(),
            minHealthChecksPassing: z.number().int().min(0).max(100).optional(),
            autoCommit: z.boolean().optional(),
            autoPush: z.boolean().optional(),
            autoTag: z.boolean().optional(),
            createGithubRelease: z.boolean().optional(),
            remote: z.string().optional(),
            repo: z.string().optional(),
            baseBranch: z.string().optional(),
            releaseTitle: z.string().optional(),
            branchPrefix: z.string().optional(),
            commitMessage: z.string().optional(),
            tagPrefix: z.string().optional(),
        }).optional(),
        upgrade: z.object({
            enabled: z.boolean().optional(),
            repoPath: z.string().optional(),
            manifestPath: z.string().optional(),
            remote: z.string().optional(),
            baseBranch: z.string().optional(),
            approvalWindowStartHourUtc: z.number().int().min(0).max(23).optional(),
            approvalWindowEndHourUtc: z.number().int().min(0).max(23).optional(),
            approvedWeekdaysUtc: z.array(z.number().int().min(0).max(6)).optional(),
            rolloutPercentage: z.number().int().min(0).max(100).optional(),
            rolloutSeed: z.string().optional(),
            healthCheckCommands: z.array(z.string().min(1)).optional(),
            minHealthChecksPassing: z.number().int().min(0).max(100).optional(),
            verificationCommands: z.array(z.string().min(1)).optional(),
            minVerificationChecksPassing: z.number().int().min(0).max(100).optional(),
            autoRollbackOnVerificationFailure: z.boolean().optional(),
            autoApply: z.boolean().optional(),
            requireCleanWorkingTree: z.boolean().optional(),
            installCommand: z.string().optional(),
            buildCommand: z.string().optional(),
            restartOnApply: z.boolean().optional(),
        }).optional(),
    }).optional(),
});
/**
 * Validate the fully-merged config against the Zod schema.
 * Throws ConfigError with a human-readable message listing all validation failures.
 */
function validateConfig(cfg) {
    const result = GreenFrogConfigSchema.safeParse(cfg);
    if (result.success)
        return result.data;
    const issues = result.error.issues.map((issue) => {
        const path = issue.path.join('.') || '(root)';
        return `  • ${path}: ${issue.message}`;
    });
    throw new ConfigError(`Configuration validation failed (${issues.length} error${issues.length === 1 ? '' : 's'}):\n${issues.join('\n')}\n\n` +
        `Check your config file or environment variables.`);
}
const DEFAULT_CONFIG = {
    dataDir: join(homedir(), '.greenfrog'),
    gateway: {
        port: 18888,
        host: '127.0.0.1',
        secret: DEFAULT_SECRET,
    },
    webui: {
        port: 18889,
        host: '127.0.0.1',
        enabled: true,
    },
    defaultProvider: 'openai',
    defaultModel: 'gpt-4o',
    providers: {},
    channels: {},
    skills: {},
    memory: {
        enabled: true,
        maxEntries: 10000,
        ttlDays: 90,
    },
    roles: { defaultRole: 'user' },
    log: {
        level: 'info',
        pretty: true,
    },
};
function mergeDeep(target, source) {
    const out = { ...target };
    for (const [key, val] of Object.entries(source)) {
        if (val !== null && typeof val === 'object' && !Array.isArray(val)) {
            out[key] = mergeDeep(out[key] ?? {}, val);
        }
        else if (val !== undefined) {
            out[key] = val;
        }
    }
    return out;
}
function loadFromEnv() {
    const cfg = { providers: {}, channels: {}, skills: {} };
    if (process.env.DATA_DIR)
        cfg.dataDir = process.env.DATA_DIR;
    if (process.env.LOG_LEVEL)
        cfg.log = { level: process.env.LOG_LEVEL, pretty: process.env.LOG_PRETTY !== 'false' };
    if (process.env.DEFAULT_PROVIDER)
        cfg.defaultProvider = process.env.DEFAULT_PROVIDER;
    if (process.env.DEFAULT_MODEL)
        cfg.defaultModel = process.env.DEFAULT_MODEL;
    if (process.env.GATEWAY_PORT || process.env.GATEWAY_SECRET) {
        cfg.gateway = {
            port: parseInt(process.env.GATEWAY_PORT ?? '18888'),
            host: process.env.GATEWAY_HOST ?? '127.0.0.1',
            secret: process.env.GATEWAY_SECRET ?? 'greenfrog-local-secret',
        };
    }
    if (process.env.WEBUI_PORT) {
        cfg.webui = {
            port: parseInt(process.env.WEBUI_PORT),
            host: process.env.WEBUI_HOST ?? '127.0.0.1',
            enabled: true,
            ...(process.env.WEBUI_PUBLIC_BASE_URL ? { publicBaseUrl: process.env.WEBUI_PUBLIC_BASE_URL } : {}),
        };
    }
    else if (process.env.WEBUI_PUBLIC_BASE_URL) {
        cfg.webui = {
            ...DEFAULT_CONFIG.webui,
            publicBaseUrl: process.env.WEBUI_PUBLIC_BASE_URL,
        };
    }
    // Providers
    if (process.env.ANTHROPIC_API_KEY) {
        cfg.providers.anthropic = {
            apiKey: process.env.ANTHROPIC_API_KEY,
            ...(process.env.ANTHROPIC_BASE_URL ? { baseUrl: process.env.ANTHROPIC_BASE_URL } : {}),
        };
    }
    if (process.env.OPENAI_API_KEY) {
        const openaiExtraHeaders = {
            ...(parseStringMapEnv('OPENAI_EXTRA_HEADERS', process.env.OPENAI_EXTRA_HEADERS) ?? {}),
            ...(process.env.OPENAI_CODEX_TURN_METADATA ? { 'x-codex-turn-metadata': process.env.OPENAI_CODEX_TURN_METADATA } : {}),
            ...(process.env.OPENAI_OPENAI_BETA ? { 'OpenAI-Beta': process.env.OPENAI_OPENAI_BETA } : {}),
        };
        cfg.providers.openai = {
            apiKey: process.env.OPENAI_API_KEY,
            ...(process.env.OPENAI_BASE_URL ? { baseUrl: process.env.OPENAI_BASE_URL } : {}),
            ...(process.env.OPENAI_MODEL ? { model: process.env.OPENAI_MODEL } : {}),
            ...(process.env.OPENAI_USE_RESPONSES_API === 'true' ? { useResponsesApi: true } : {}),
            ...(process.env.OPENAI_REASONING_EFFORT ? { reasoningEffort: process.env.OPENAI_REASONING_EFFORT } : {}),
            ...(process.env.OPENAI_AUTH_MODE ? { authMode: process.env.OPENAI_AUTH_MODE } : {}),
            ...(process.env.OPENAI_AUTH_HEADER ? { authHeader: process.env.OPENAI_AUTH_HEADER } : {}),
            ...(process.env.OPENAI_AUTH_SCHEME ? { authScheme: process.env.OPENAI_AUTH_SCHEME } : {}),
            ...(Object.keys(openaiExtraHeaders).length > 0 ? { extraHeaders: openaiExtraHeaders } : {}),
            ...(process.env.OPENAI_SEND_CLIENT_REQUEST_ID === 'true' ? { sendClientRequestId: true } : {}),
            ...(process.env.OPENAI_DISABLE_RESPONSE_STORAGE === 'true' ? { disableResponseStorage: true } : {}),
            ...(process.env.OPENAI_RESPONSES_MAX_ATTEMPTS ? { responsesMaxAttempts: parseInt(process.env.OPENAI_RESPONSES_MAX_ATTEMPTS, 10) } : {}),
            ...(process.env.OPENAI_RESPONSES_RETRY_BASE_DELAY_MS ? { responsesRetryBaseDelayMs: parseInt(process.env.OPENAI_RESPONSES_RETRY_BASE_DELAY_MS, 10) } : {}),
        };
    }
    if (process.env.OLLAMA_BASE_URL) {
        cfg.providers.ollama = {
            baseUrl: process.env.OLLAMA_BASE_URL,
            model: process.env.OLLAMA_MODEL,
        };
    }
    if (process.env.GEMINI_API_KEY) {
        cfg.providers.gemini = {
            apiKey: process.env.GEMINI_API_KEY,
            ...(process.env.GEMINI_MODEL ? { model: process.env.GEMINI_MODEL } : {}),
        };
    }
    if (process.env.MISTRAL_API_KEY) {
        cfg.providers.mistral = {
            apiKey: process.env.MISTRAL_API_KEY,
            ...(process.env.MISTRAL_BASE_URL ? { baseUrl: process.env.MISTRAL_BASE_URL } : {}),
            ...(process.env.MISTRAL_MODEL ? { model: process.env.MISTRAL_MODEL } : {}),
        };
    }
    if (process.env.GROQ_API_KEY) {
        cfg.providers.groq = {
            apiKey: process.env.GROQ_API_KEY,
            ...(process.env.GROQ_BASE_URL ? { baseUrl: process.env.GROQ_BASE_URL } : {}),
            ...(process.env.GROQ_MODEL ? { model: process.env.GROQ_MODEL } : {}),
        };
    }
    if (process.env.DEEPSEEK_API_KEY) {
        cfg.providers.deepseek = {
            apiKey: process.env.DEEPSEEK_API_KEY,
            ...(process.env.DEEPSEEK_BASE_URL ? { baseUrl: process.env.DEEPSEEK_BASE_URL } : {}),
            ...(process.env.DEEPSEEK_MODEL ? { model: process.env.DEEPSEEK_MODEL } : {}),
        };
    }
    if (process.env.QWEN_API_KEY) {
        cfg.providers.qwen = {
            apiKey: process.env.QWEN_API_KEY,
            ...(process.env.QWEN_BASE_URL ? { baseUrl: process.env.QWEN_BASE_URL } : {}),
            ...(process.env.QWEN_MODEL ? { model: process.env.QWEN_MODEL } : {}),
        };
    }
    if (process.env.KIMI_API_KEY) {
        cfg.providers.kimi = {
            apiKey: process.env.KIMI_API_KEY,
            ...(process.env.KIMI_BASE_URL ? { baseUrl: process.env.KIMI_BASE_URL } : {}),
            ...(process.env.KIMI_MODEL ? { model: process.env.KIMI_MODEL } : {}),
        };
    }
    if (process.env.GLM_API_KEY) {
        cfg.providers.glm = {
            apiKey: process.env.GLM_API_KEY,
            ...(process.env.GLM_BASE_URL ? { baseUrl: process.env.GLM_BASE_URL } : {}),
            ...(process.env.GLM_MODEL ? { model: process.env.GLM_MODEL } : {}),
        };
    }
    // Channels
    if (process.env.TELEGRAM_BOT_TOKEN) {
        cfg.channels.telegram = {
            enabled: true,
            token: process.env.TELEGRAM_BOT_TOKEN,
            allowedUsers: process.env.TELEGRAM_ALLOWED_USERS?.split(',').filter(Boolean),
        };
    }
    if (process.env.DISCORD_BOT_TOKEN) {
        cfg.channels.discord = {
            enabled: true,
            token: process.env.DISCORD_BOT_TOKEN,
            clientId: process.env.DISCORD_CLIENT_ID,
            allowedUsers: process.env.DISCORD_ALLOWED_USERS?.split(',').filter(Boolean),
        };
    }
    if (process.env.SLACK_BOT_TOKEN) {
        cfg.channels.slack = {
            enabled: true,
            botToken: process.env.SLACK_BOT_TOKEN,
            appToken: process.env.SLACK_APP_TOKEN ?? '',
            signingSecret: process.env.SLACK_SIGNING_SECRET ?? '',
            allowedUsers: process.env.SLACK_ALLOWED_USERS?.split(',').filter(Boolean),
        };
    }
    if (process.env.WHATSAPP_ENABLED === 'true') {
        cfg.channels.whatsapp = {
            enabled: true,
            ...(process.env.WHATSAPP_ALLOWED_USERS
                ? { allowedUsers: process.env.WHATSAPP_ALLOWED_USERS.split(',').filter(Boolean) }
                : {}),
            ...(process.env.WHATSAPP_GROUP_PREFIX
                ? { groupPrefix: process.env.WHATSAPP_GROUP_PREFIX }
                : {}),
        };
    }
    if (process.env.WECOM_ENABLED === 'true' || process.env.WECOM_WEBHOOK_URL) {
        cfg.channels.wecom = {
            enabled: true,
            ...(process.env.WECOM_WEBHOOK_URL ? { webhookUrl: process.env.WECOM_WEBHOOK_URL } : {}),
            ...(process.env.WECOM_CORP_ID ? { corpId: process.env.WECOM_CORP_ID } : {}),
            ...(process.env.WECOM_CORP_SECRET ? { corpSecret: process.env.WECOM_CORP_SECRET } : {}),
            ...(process.env.WECOM_AGENT_ID ? { agentId: process.env.WECOM_AGENT_ID } : {}),
            ...(process.env.WECOM_TOKEN ? { token: process.env.WECOM_TOKEN } : {}),
            ...(process.env.WECOM_ENCODING_AES_KEY ? { encodingAESKey: process.env.WECOM_ENCODING_AES_KEY } : {}),
            ...(process.env.WECOM_CALLBACK_PORT ? { callbackPort: parseInt(process.env.WECOM_CALLBACK_PORT, 10) } : {}),
            ...(process.env.WECOM_ALLOWED_USERS ? { allowedUsers: process.env.WECOM_ALLOWED_USERS.split(',').filter(Boolean) } : {}),
        };
    }
    // Skills
    if (process.env.OPENWEATHER_API_KEY)
        cfg.skills.weather = { apiKey: process.env.OPENWEATHER_API_KEY };
    if (process.env.GITHUB_TOKEN)
        cfg.skills.github = { token: process.env.GITHUB_TOKEN };
    if (process.env.NEWS_API_KEY)
        cfg.skills.news = { apiKey: process.env.NEWS_API_KEY };
    if (process.env.SERPER_API_KEY)
        cfg.skills.search = { apiKey: process.env.SERPER_API_KEY };
    if (process.env.WOLFRAM_APP_ID)
        cfg.skills.wolfram = { appId: process.env.WOLFRAM_APP_ID };
    // TLS
    if (process.env.TLS_CERT_FILE || process.env.TLS_KEY_FILE) {
        cfg.tls = {
            certFile: process.env.TLS_CERT_FILE,
            keyFile: process.env.TLS_KEY_FILE,
        };
    }
    // Agent loop
    if (process.env.AGENT_MAX_ITERATIONS) {
        const parsed = parseInt(process.env.AGENT_MAX_ITERATIONS, 10);
        if (!isNaN(parsed) && parsed >= 1)
            cfg.agentMaxIterations = Math.min(parsed, 200);
    }
    if (process.env.AGENT_MAX_EXECUTION_MS) {
        const parsed = parseInt(process.env.AGENT_MAX_EXECUTION_MS, 10);
        if (!isNaN(parsed) && parsed >= 1000)
            cfg.agentMaxExecutionMs = Math.min(parsed, 900000);
    }
    if (process.env.AGENT_MAX_CONCURRENCY) {
        const parsed = parseInt(process.env.AGENT_MAX_CONCURRENCY, 10);
        if (!isNaN(parsed) && parsed >= 1)
            cfg.agentMaxConcurrency = Math.min(parsed, 256);
    }
    if (process.env.AGENT_MAX_CONCURRENCY_PER_USER) {
        const parsed = parseInt(process.env.AGENT_MAX_CONCURRENCY_PER_USER, 10);
        if (!isNaN(parsed) && parsed >= 1)
            cfg.agentMaxConcurrencyPerUser = Math.min(parsed, 64);
    }
    if (process.env.HARD_QUOTA_RESERVATION_TOKENS) {
        const parsed = parseInt(process.env.HARD_QUOTA_RESERVATION_TOKENS, 10);
        if (!isNaN(parsed) && parsed >= 256)
            cfg.hardQuotaReservationTokens = Math.min(parsed, 65536);
    }
    // Database (PostgreSQL)
    if (process.env.DATABASE_URL) {
        cfg.database = { url: process.env.DATABASE_URL };
        if (process.env.DATABASE_POOL_MAX)
            cfg.database.poolMax = parseInt(process.env.DATABASE_POOL_MAX, 10);
    }
    // Metrics
    if (process.env.METRICS_ENABLED === 'true' || process.env.METRICS_TOKEN) {
        cfg.metrics = {
            enabled: process.env.METRICS_ENABLED !== 'false',
            token: process.env.METRICS_TOKEN,
        };
    }
    // Queue (Redis/BullMQ)
    if (process.env.REDIS_URL) {
        cfg.queue = {
            redisUrl: process.env.REDIS_URL,
            concurrency: process.env.QUEUE_CONCURRENCY ? parseInt(process.env.QUEUE_CONCURRENCY, 10) : 4,
            ...(process.env.QUEUE_MAX_PENDING_JOBS ? { maxPendingJobs: parseInt(process.env.QUEUE_MAX_PENDING_JOBS, 10) } : {}),
        };
    }
    // OAuth2/OIDC
    if (process.env.OAUTH_ISSUER || process.env.OAUTH_CLIENT_ID) {
        cfg.auth = {
            enabled: process.env.OAUTH_ENABLED !== 'false',
            issuer: process.env.OAUTH_ISSUER,
            clientId: process.env.OAUTH_CLIENT_ID,
            clientSecret: process.env.OAUTH_CLIENT_SECRET,
            redirectUri: process.env.OAUTH_REDIRECT_URI,
            jwtSecret: process.env.JWT_SECRET,
            jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? '24h',
        };
    }
    if (process.env.GF_PROJECT_EVOLUTION_MODE
        || process.env.GF_EVOLUTION_SINGLE_USER
        || process.env.GF_RULE_SYNC_ENABLED
        || process.env.GF_RULE_SYNC_REMOTE_URL
        || process.env.GF_EVOLUTION_SCHEDULER_ENABLED
        || process.env.GF_SOURCE_REPO_EVOLUTION_ENABLED
        || process.env.GF_SOURCE_REPO_PATH
        || process.env.GF_CODE_REPO_EVOLUTION_ENABLED
        || process.env.GF_CODE_REPO_PATH
        || process.env.GF_PROJECT_RELEASE_ENABLED
        || process.env.GF_PROJECT_RELEASE_REPO_PATH
        || process.env.GF_PROJECT_UPGRADE_ENABLED
        || process.env.GF_PROJECT_UPGRADE_REPO_PATH) {
        cfg.evolution = {
            ...(cfg.evolution ?? {}),
            ...(process.env.GF_PROJECT_EVOLUTION_MODE ? { projectMode: process.env.GF_PROJECT_EVOLUTION_MODE } : {}),
            ...(process.env.GF_EVOLUTION_SINGLE_USER ? { singleUser: process.env.GF_EVOLUTION_SINGLE_USER === 'true' } : {}),
        };
    }
    if (process.env.GF_RULE_SYNC_ENABLED
        || process.env.GF_RULE_SYNC_REMOTE_URL
        || process.env.GF_EVOLUTION_SCHEDULER_ENABLED
        || process.env.GF_SOURCE_REPO_EVOLUTION_ENABLED
        || process.env.GF_SOURCE_REPO_PATH
        || process.env.GF_CODE_REPO_EVOLUTION_ENABLED
        || process.env.GF_CODE_REPO_PATH
        || process.env.GF_PROJECT_RELEASE_ENABLED
        || process.env.GF_PROJECT_RELEASE_REPO_PATH
        || process.env.GF_PROJECT_UPGRADE_ENABLED
        || process.env.GF_PROJECT_UPGRADE_REPO_PATH) {
        cfg.evolution ??= {};
    }
    if (process.env.GF_RULE_SYNC_ENABLED
        || process.env.GF_RULE_SYNC_REMOTE_URL
        || process.env.GF_RULE_SYNC_MODE
        || process.env.GF_RULE_SYNC_UPLOAD_RULES
        || process.env.GF_RULE_SYNC_UPLOAD_STATS
        || process.env.GF_RULE_SYNC_ACCESS_TOKEN) {
        cfg.evolution ??= {};
        cfg.evolution.ruleSync = {
            ...(process.env.GF_RULE_SYNC_ENABLED ? { enabled: process.env.GF_RULE_SYNC_ENABLED === 'true' } : {}),
            ...(process.env.GF_RULE_SYNC_MODE ? { mode: process.env.GF_RULE_SYNC_MODE } : {}),
            ...(process.env.GF_RULE_SYNC_UPLOAD_RULES ? { uploadRules: process.env.GF_RULE_SYNC_UPLOAD_RULES === 'true' } : {}),
            ...(process.env.GF_RULE_SYNC_UPLOAD_STATS ? { uploadStats: process.env.GF_RULE_SYNC_UPLOAD_STATS === 'true' } : {}),
            ...(process.env.GF_RULE_SYNC_ANONYMIZE ? { anonymize: process.env.GF_RULE_SYNC_ANONYMIZE === 'true' } : {}),
            ...(process.env.GF_RULE_SYNC_REVIEW_BEFORE_UPLOAD ? { reviewBeforeUpload: process.env.GF_RULE_SYNC_REVIEW_BEFORE_UPLOAD === 'true' } : {}),
            ...(process.env.GF_RULE_SYNC_REMOTE_URL ? { remoteUrl: process.env.GF_RULE_SYNC_REMOTE_URL } : {}),
            ...(process.env.GF_RULE_SYNC_ACCESS_TOKEN ? { accessToken: process.env.GF_RULE_SYNC_ACCESS_TOKEN } : {}),
            ...(process.env.GF_RULE_SYNC_INTERVAL_HOURS ? { syncIntervalHours: parseInt(process.env.GF_RULE_SYNC_INTERVAL_HOURS, 10) } : {}),
        };
    }
    if (process.env.GF_EVOLUTION_SCHEDULER_ENABLED
        || process.env.GF_EVOLUTION_SCORING_INTERVAL_HOURS
        || process.env.GF_EVOLUTION_UPLOAD_INTERVAL_HOURS
        || process.env.GF_EVOLUTION_SYNC_INTERVAL_HOURS
        || process.env.GF_EVOLUTION_CLEANUP_INTERVAL_HOURS
        || process.env.GF_EVOLUTION_SOURCE_REPO_INTERVAL_HOURS
        || process.env.GF_EVOLUTION_TRACKING_CLEANUP_DAYS) {
        cfg.evolution ??= {};
        cfg.evolution.scheduler = {
            ...(process.env.GF_EVOLUTION_SCHEDULER_ENABLED ? { enabled: process.env.GF_EVOLUTION_SCHEDULER_ENABLED === 'true' } : {}),
            ...(process.env.GF_EVOLUTION_SCORING_INTERVAL_HOURS ? { scoringIntervalHours: parseInt(process.env.GF_EVOLUTION_SCORING_INTERVAL_HOURS, 10) } : {}),
            ...(process.env.GF_EVOLUTION_UPLOAD_INTERVAL_HOURS ? { uploadIntervalHours: parseInt(process.env.GF_EVOLUTION_UPLOAD_INTERVAL_HOURS, 10) } : {}),
            ...(process.env.GF_EVOLUTION_SYNC_INTERVAL_HOURS ? { syncIntervalHours: parseInt(process.env.GF_EVOLUTION_SYNC_INTERVAL_HOURS, 10) } : {}),
            ...(process.env.GF_EVOLUTION_CLEANUP_INTERVAL_HOURS ? { cleanupIntervalHours: parseInt(process.env.GF_EVOLUTION_CLEANUP_INTERVAL_HOURS, 10) } : {}),
            ...(process.env.GF_EVOLUTION_SOURCE_REPO_INTERVAL_HOURS ? { sourceRepoIntervalHours: parseInt(process.env.GF_EVOLUTION_SOURCE_REPO_INTERVAL_HOURS, 10) } : {}),
            ...(process.env.GF_EVOLUTION_TRACKING_CLEANUP_DAYS ? { trackingCleanupDays: parseInt(process.env.GF_EVOLUTION_TRACKING_CLEANUP_DAYS, 10) } : {}),
        };
    }
    if (process.env.GF_SOURCE_REPO_EVOLUTION_ENABLED
        || process.env.GF_SOURCE_REPO_PATH
        || process.env.GF_SOURCE_REPO_OUTPUT_PATH
        || process.env.GF_SOURCE_REPO_SUMMARY_PATH
        || process.env.GF_SOURCE_REPO_AUTO_COMMIT
        || process.env.GF_SOURCE_REPO_AUTO_PUSH
        || process.env.GF_SOURCE_REPO_CREATE_PR
        || process.env.GF_SOURCE_REPO_REMOTE
        || process.env.GF_SOURCE_REPO_REPO
        || process.env.GF_SOURCE_REPO_BASE_BRANCH
        || process.env.GF_SOURCE_REPO_HEAD_OWNER
        || process.env.GF_SOURCE_REPO_PULL_REQUEST_TITLE) {
        cfg.evolution ??= {};
        cfg.evolution.sourceRepo = {
            ...(process.env.GF_SOURCE_REPO_EVOLUTION_ENABLED ? { enabled: process.env.GF_SOURCE_REPO_EVOLUTION_ENABLED === 'true' } : {}),
            ...(process.env.GF_SOURCE_REPO_PATH ? { repoPath: process.env.GF_SOURCE_REPO_PATH } : {}),
            ...(process.env.GF_SOURCE_REPO_OUTPUT_PATH ? { outputPath: process.env.GF_SOURCE_REPO_OUTPUT_PATH } : {}),
            ...(process.env.GF_SOURCE_REPO_SUMMARY_PATH ? { summaryPath: process.env.GF_SOURCE_REPO_SUMMARY_PATH } : {}),
            ...(process.env.GF_SOURCE_REPO_MIN_CONFIDENCE ? { minConfidence: parseInt(process.env.GF_SOURCE_REPO_MIN_CONFIDENCE, 10) } : {}),
            ...(process.env.GF_SOURCE_REPO_MIN_EVIDENCE_COUNT ? { minEvidenceCount: parseInt(process.env.GF_SOURCE_REPO_MIN_EVIDENCE_COUNT, 10) } : {}),
            ...(process.env.GF_SOURCE_REPO_MIN_WORKSPACE_COUNT ? { minWorkspaceCount: parseInt(process.env.GF_SOURCE_REPO_MIN_WORKSPACE_COUNT, 10) } : {}),
            ...(process.env.GF_SOURCE_REPO_AUTO_COMMIT ? { autoCommit: process.env.GF_SOURCE_REPO_AUTO_COMMIT === 'true' } : {}),
            ...(process.env.GF_SOURCE_REPO_AUTO_PUSH ? { autoPush: process.env.GF_SOURCE_REPO_AUTO_PUSH === 'true' } : {}),
            ...(process.env.GF_SOURCE_REPO_CREATE_PR ? { createPullRequest: process.env.GF_SOURCE_REPO_CREATE_PR === 'true' } : {}),
            ...(process.env.GF_SOURCE_REPO_REMOTE ? { remote: process.env.GF_SOURCE_REPO_REMOTE } : {}),
            ...(process.env.GF_SOURCE_REPO_REPO ? { repo: process.env.GF_SOURCE_REPO_REPO } : {}),
            ...(process.env.GF_SOURCE_REPO_BASE_BRANCH ? { baseBranch: process.env.GF_SOURCE_REPO_BASE_BRANCH } : {}),
            ...(process.env.GF_SOURCE_REPO_HEAD_OWNER ? { headOwner: process.env.GF_SOURCE_REPO_HEAD_OWNER } : {}),
            ...(process.env.GF_SOURCE_REPO_PULL_REQUEST_TITLE ? { pullRequestTitle: process.env.GF_SOURCE_REPO_PULL_REQUEST_TITLE } : {}),
            ...(process.env.GF_SOURCE_REPO_BRANCH_PREFIX ? { branchPrefix: process.env.GF_SOURCE_REPO_BRANCH_PREFIX } : {}),
            ...(process.env.GF_SOURCE_REPO_COMMIT_MESSAGE ? { commitMessage: process.env.GF_SOURCE_REPO_COMMIT_MESSAGE } : {}),
        };
    }
    if (process.env.GF_CODE_REPO_EVOLUTION_ENABLED
        || process.env.GF_CODE_REPO_PATH
        || process.env.GF_CODE_REPO_MANIFEST_PATH
        || process.env.GF_CODE_REPO_SUMMARY_PATH
        || process.env.GF_CODE_REPO_PATCH_PATH
        || process.env.GF_CODE_REPO_GATE_PROFILE
        || process.env.GF_CODE_REPO_AUTO_GENERATE_CANDIDATES
        || process.env.GF_CODE_REPO_AUTO_APPLY_PATCH
        || process.env.GF_CODE_REPO_AUTO_COMMIT
        || process.env.GF_CODE_REPO_AUTO_PUSH
        || process.env.GF_CODE_REPO_CREATE_PR) {
        cfg.evolution ??= {};
        cfg.evolution.codeRepo = {
            ...(process.env.GF_CODE_REPO_EVOLUTION_ENABLED ? { enabled: process.env.GF_CODE_REPO_EVOLUTION_ENABLED === 'true' } : {}),
            ...(process.env.GF_CODE_REPO_PATH ? { repoPath: process.env.GF_CODE_REPO_PATH } : {}),
            ...(process.env.GF_CODE_REPO_MANIFEST_PATH ? { manifestPath: process.env.GF_CODE_REPO_MANIFEST_PATH } : {}),
            ...(process.env.GF_CODE_REPO_SUMMARY_PATH ? { summaryPath: process.env.GF_CODE_REPO_SUMMARY_PATH } : {}),
            ...(process.env.GF_CODE_REPO_PATCH_PATH ? { patchPath: process.env.GF_CODE_REPO_PATCH_PATH } : {}),
            ...(process.env.GF_CODE_REPO_GATE_PROFILE ? { gateProfile: process.env.GF_CODE_REPO_GATE_PROFILE } : {}),
            ...(process.env.GF_CODE_REPO_AUTO_GENERATE_CANDIDATES ? { autoGenerateCandidates: process.env.GF_CODE_REPO_AUTO_GENERATE_CANDIDATES === 'true' } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_LOOKBACK_DAYS ? { generationLookbackDays: parseInt(process.env.GF_CODE_REPO_GENERATION_LOOKBACK_DAYS, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MAX_AUDIT_ENTRIES ? { generationMaxAuditEntries: parseInt(process.env.GF_CODE_REPO_GENERATION_MAX_AUDIT_ENTRIES, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MAX_CANDIDATES ? { generationMaxCandidates: parseInt(process.env.GF_CODE_REPO_GENERATION_MAX_CANDIDATES, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MAX_EVIDENCE_PER_CANDIDATE ? { generationMaxEvidencePerCandidate: parseInt(process.env.GF_CODE_REPO_GENERATION_MAX_EVIDENCE_PER_CANDIDATE, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MAX_FILE_CONTEXT_CHARS ? { generationMaxFileContextChars: parseInt(process.env.GF_CODE_REPO_GENERATION_MAX_FILE_CONTEXT_CHARS, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MIN_EVIDENCE_COUNT ? { generationMinEvidenceCount: parseInt(process.env.GF_CODE_REPO_GENERATION_MIN_EVIDENCE_COUNT, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MIN_FAILURE_COUNT ? { generationMinFailureCount: parseInt(process.env.GF_CODE_REPO_GENERATION_MIN_FAILURE_COUNT, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MIN_SUCCESS_COUNT ? { generationMinSuccessCount: parseInt(process.env.GF_CODE_REPO_GENERATION_MIN_SUCCESS_COUNT, 10) } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_PROVIDER ? { generationProvider: process.env.GF_CODE_REPO_GENERATION_PROVIDER } : {}),
            ...(process.env.GF_CODE_REPO_GENERATION_MODEL ? { generationModel: process.env.GF_CODE_REPO_GENERATION_MODEL } : {}),
            ...(process.env.GF_CODE_REPO_MIN_DECISION_SCORE ? { minDecisionScore: parseInt(process.env.GF_CODE_REPO_MIN_DECISION_SCORE, 10) } : {}),
            ...(process.env.GF_CODE_REPO_MIN_VALIDATION_COUNT ? { minValidationCount: parseInt(process.env.GF_CODE_REPO_MIN_VALIDATION_COUNT, 10) } : {}),
            ...(process.env.GF_CODE_REPO_MIN_SUCCESS_RATE ? { minSuccessRate: parseFloat(process.env.GF_CODE_REPO_MIN_SUCCESS_RATE) } : {}),
            ...(process.env.GF_CODE_REPO_AUTO_APPLY_PATCH ? { autoApplyPatch: process.env.GF_CODE_REPO_AUTO_APPLY_PATCH === 'true' } : {}),
            ...(process.env.GF_CODE_REPO_AUTO_COMMIT ? { autoCommit: process.env.GF_CODE_REPO_AUTO_COMMIT === 'true' } : {}),
            ...(process.env.GF_CODE_REPO_AUTO_PUSH ? { autoPush: process.env.GF_CODE_REPO_AUTO_PUSH === 'true' } : {}),
            ...(process.env.GF_CODE_REPO_CREATE_PR ? { createPullRequest: process.env.GF_CODE_REPO_CREATE_PR === 'true' } : {}),
            ...(process.env.GF_CODE_REPO_REMOTE ? { remote: process.env.GF_CODE_REPO_REMOTE } : {}),
            ...(process.env.GF_CODE_REPO_REPO ? { repo: process.env.GF_CODE_REPO_REPO } : {}),
            ...(process.env.GF_CODE_REPO_BASE_BRANCH ? { baseBranch: process.env.GF_CODE_REPO_BASE_BRANCH } : {}),
            ...(process.env.GF_CODE_REPO_HEAD_OWNER ? { headOwner: process.env.GF_CODE_REPO_HEAD_OWNER } : {}),
            ...(process.env.GF_CODE_REPO_PULL_REQUEST_TITLE ? { pullRequestTitle: process.env.GF_CODE_REPO_PULL_REQUEST_TITLE } : {}),
            ...(process.env.GF_CODE_REPO_BRANCH_PREFIX ? { branchPrefix: process.env.GF_CODE_REPO_BRANCH_PREFIX } : {}),
            ...(process.env.GF_CODE_REPO_COMMIT_MESSAGE ? { commitMessage: process.env.GF_CODE_REPO_COMMIT_MESSAGE } : {}),
        };
    }
    if (process.env.GF_PROJECT_RELEASE_ENABLED
        || process.env.GF_PROJECT_RELEASE_REPO_PATH
        || process.env.GF_PROJECT_RELEASE_MANIFEST_PATH
        || process.env.GF_PROJECT_RELEASE_NOTES_PATH
        || process.env.GF_PROJECT_RELEASE_BUMP
        || process.env.GF_PROJECT_RELEASE_APPROVAL_START_HOUR_UTC
        || process.env.GF_PROJECT_RELEASE_APPROVAL_END_HOUR_UTC
        || process.env.GF_PROJECT_RELEASE_APPROVED_WEEKDAYS_UTC
        || process.env.GF_PROJECT_RELEASE_HEALTHCHECK_COMMANDS
        || process.env.GF_PROJECT_RELEASE_MIN_HEALTH_CHECKS_PASSING
        || process.env.GF_PROJECT_RELEASE_AUTO_COMMIT
        || process.env.GF_PROJECT_RELEASE_AUTO_PUSH
        || process.env.GF_PROJECT_RELEASE_AUTO_TAG
        || process.env.GF_PROJECT_RELEASE_CREATE_GITHUB_RELEASE) {
        cfg.evolution ??= {};
        cfg.evolution.release = {
            ...(process.env.GF_PROJECT_RELEASE_ENABLED ? { enabled: process.env.GF_PROJECT_RELEASE_ENABLED === 'true' } : {}),
            ...(process.env.GF_PROJECT_RELEASE_REPO_PATH ? { repoPath: process.env.GF_PROJECT_RELEASE_REPO_PATH } : {}),
            ...(process.env.GF_PROJECT_RELEASE_MANIFEST_PATH ? { manifestPath: process.env.GF_PROJECT_RELEASE_MANIFEST_PATH } : {}),
            ...(process.env.GF_PROJECT_RELEASE_NOTES_PATH ? { notesPath: process.env.GF_PROJECT_RELEASE_NOTES_PATH } : {}),
            ...(process.env.GF_PROJECT_RELEASE_BUMP ? { bump: process.env.GF_PROJECT_RELEASE_BUMP } : {}),
            ...(process.env.GF_PROJECT_RELEASE_APPROVAL_START_HOUR_UTC ? { approvalWindowStartHourUtc: parseInt(process.env.GF_PROJECT_RELEASE_APPROVAL_START_HOUR_UTC, 10) } : {}),
            ...(process.env.GF_PROJECT_RELEASE_APPROVAL_END_HOUR_UTC ? { approvalWindowEndHourUtc: parseInt(process.env.GF_PROJECT_RELEASE_APPROVAL_END_HOUR_UTC, 10) } : {}),
            ...(parseIntListEnv(process.env.GF_PROJECT_RELEASE_APPROVED_WEEKDAYS_UTC) ? { approvedWeekdaysUtc: parseIntListEnv(process.env.GF_PROJECT_RELEASE_APPROVED_WEEKDAYS_UTC) } : {}),
            ...(parseCommandListEnv(process.env.GF_PROJECT_RELEASE_HEALTHCHECK_COMMANDS) ? { healthCheckCommands: parseCommandListEnv(process.env.GF_PROJECT_RELEASE_HEALTHCHECK_COMMANDS) } : {}),
            ...(process.env.GF_PROJECT_RELEASE_MIN_HEALTH_CHECKS_PASSING ? { minHealthChecksPassing: parseInt(process.env.GF_PROJECT_RELEASE_MIN_HEALTH_CHECKS_PASSING, 10) } : {}),
            ...(process.env.GF_PROJECT_RELEASE_AUTO_COMMIT ? { autoCommit: process.env.GF_PROJECT_RELEASE_AUTO_COMMIT === 'true' } : {}),
            ...(process.env.GF_PROJECT_RELEASE_AUTO_PUSH ? { autoPush: process.env.GF_PROJECT_RELEASE_AUTO_PUSH === 'true' } : {}),
            ...(process.env.GF_PROJECT_RELEASE_AUTO_TAG ? { autoTag: process.env.GF_PROJECT_RELEASE_AUTO_TAG === 'true' } : {}),
            ...(process.env.GF_PROJECT_RELEASE_CREATE_GITHUB_RELEASE ? { createGithubRelease: process.env.GF_PROJECT_RELEASE_CREATE_GITHUB_RELEASE === 'true' } : {}),
            ...(process.env.GF_PROJECT_RELEASE_REMOTE ? { remote: process.env.GF_PROJECT_RELEASE_REMOTE } : {}),
            ...(process.env.GF_PROJECT_RELEASE_REPO ? { repo: process.env.GF_PROJECT_RELEASE_REPO } : {}),
            ...(process.env.GF_PROJECT_RELEASE_BASE_BRANCH ? { baseBranch: process.env.GF_PROJECT_RELEASE_BASE_BRANCH } : {}),
            ...(process.env.GF_PROJECT_RELEASE_TITLE ? { releaseTitle: process.env.GF_PROJECT_RELEASE_TITLE } : {}),
            ...(process.env.GF_PROJECT_RELEASE_BRANCH_PREFIX ? { branchPrefix: process.env.GF_PROJECT_RELEASE_BRANCH_PREFIX } : {}),
            ...(process.env.GF_PROJECT_RELEASE_COMMIT_MESSAGE ? { commitMessage: process.env.GF_PROJECT_RELEASE_COMMIT_MESSAGE } : {}),
            ...(process.env.GF_PROJECT_RELEASE_TAG_PREFIX ? { tagPrefix: process.env.GF_PROJECT_RELEASE_TAG_PREFIX } : {}),
        };
    }
    if (process.env.GF_PROJECT_UPGRADE_ENABLED
        || process.env.GF_PROJECT_UPGRADE_REPO_PATH
        || process.env.GF_PROJECT_UPGRADE_MANIFEST_PATH
        || process.env.GF_PROJECT_UPGRADE_APPROVAL_START_HOUR_UTC
        || process.env.GF_PROJECT_UPGRADE_APPROVAL_END_HOUR_UTC
        || process.env.GF_PROJECT_UPGRADE_APPROVED_WEEKDAYS_UTC
        || process.env.GF_PROJECT_UPGRADE_ROLLOUT_PERCENTAGE
        || process.env.GF_PROJECT_UPGRADE_ROLLOUT_SEED
        || process.env.GF_PROJECT_UPGRADE_HEALTHCHECK_COMMANDS
        || process.env.GF_PROJECT_UPGRADE_MIN_HEALTH_CHECKS_PASSING
        || process.env.GF_PROJECT_UPGRADE_VERIFICATION_COMMANDS
        || process.env.GF_PROJECT_UPGRADE_MIN_VERIFICATION_CHECKS_PASSING
        || process.env.GF_PROJECT_UPGRADE_AUTO_ROLLBACK_ON_VERIFY_FAILURE
        || process.env.GF_PROJECT_UPGRADE_AUTO_APPLY) {
        cfg.evolution ??= {};
        cfg.evolution.upgrade = {
            ...(process.env.GF_PROJECT_UPGRADE_ENABLED ? { enabled: process.env.GF_PROJECT_UPGRADE_ENABLED === 'true' } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_REPO_PATH ? { repoPath: process.env.GF_PROJECT_UPGRADE_REPO_PATH } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_MANIFEST_PATH ? { manifestPath: process.env.GF_PROJECT_UPGRADE_MANIFEST_PATH } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_REMOTE ? { remote: process.env.GF_PROJECT_UPGRADE_REMOTE } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_BASE_BRANCH ? { baseBranch: process.env.GF_PROJECT_UPGRADE_BASE_BRANCH } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_APPROVAL_START_HOUR_UTC ? { approvalWindowStartHourUtc: parseInt(process.env.GF_PROJECT_UPGRADE_APPROVAL_START_HOUR_UTC, 10) } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_APPROVAL_END_HOUR_UTC ? { approvalWindowEndHourUtc: parseInt(process.env.GF_PROJECT_UPGRADE_APPROVAL_END_HOUR_UTC, 10) } : {}),
            ...(parseIntListEnv(process.env.GF_PROJECT_UPGRADE_APPROVED_WEEKDAYS_UTC) ? { approvedWeekdaysUtc: parseIntListEnv(process.env.GF_PROJECT_UPGRADE_APPROVED_WEEKDAYS_UTC) } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_ROLLOUT_PERCENTAGE ? { rolloutPercentage: parseInt(process.env.GF_PROJECT_UPGRADE_ROLLOUT_PERCENTAGE, 10) } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_ROLLOUT_SEED ? { rolloutSeed: process.env.GF_PROJECT_UPGRADE_ROLLOUT_SEED } : {}),
            ...(parseCommandListEnv(process.env.GF_PROJECT_UPGRADE_HEALTHCHECK_COMMANDS) ? { healthCheckCommands: parseCommandListEnv(process.env.GF_PROJECT_UPGRADE_HEALTHCHECK_COMMANDS) } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_MIN_HEALTH_CHECKS_PASSING ? { minHealthChecksPassing: parseInt(process.env.GF_PROJECT_UPGRADE_MIN_HEALTH_CHECKS_PASSING, 10) } : {}),
            ...(parseCommandListEnv(process.env.GF_PROJECT_UPGRADE_VERIFICATION_COMMANDS) ? { verificationCommands: parseCommandListEnv(process.env.GF_PROJECT_UPGRADE_VERIFICATION_COMMANDS) } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_MIN_VERIFICATION_CHECKS_PASSING ? { minVerificationChecksPassing: parseInt(process.env.GF_PROJECT_UPGRADE_MIN_VERIFICATION_CHECKS_PASSING, 10) } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_AUTO_ROLLBACK_ON_VERIFY_FAILURE ? { autoRollbackOnVerificationFailure: process.env.GF_PROJECT_UPGRADE_AUTO_ROLLBACK_ON_VERIFY_FAILURE === 'true' } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_AUTO_APPLY ? { autoApply: process.env.GF_PROJECT_UPGRADE_AUTO_APPLY === 'true' } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_REQUIRE_CLEAN ? { requireCleanWorkingTree: process.env.GF_PROJECT_UPGRADE_REQUIRE_CLEAN === 'true' } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_INSTALL_COMMAND ? { installCommand: process.env.GF_PROJECT_UPGRADE_INSTALL_COMMAND } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_BUILD_COMMAND ? { buildCommand: process.env.GF_PROJECT_UPGRADE_BUILD_COMMAND } : {}),
            ...(process.env.GF_PROJECT_UPGRADE_RESTART_ON_APPLY ? { restartOnApply: process.env.GF_PROJECT_UPGRADE_RESTART_ON_APPLY === 'true' } : {}),
        };
    }
    return cfg;
}
class ConfigManager {
    _config;
    configPath;
    constructor() {
        const dataDir = process.env.DATA_DIR || join(homedir(), '.greenfrog');
        this.configPath = join(dataDir, 'config.yaml');
        // Start with defaults
        let cfg = { ...DEFAULT_CONFIG };
        // Load from YAML file if exists
        if (existsSync(this.configPath)) {
            try {
                const raw = readFileSync(this.configPath, 'utf8');
                const fromFile = yaml.parse(raw);
                const merged = mergeDeep(cfg, fromFile);
                // Decrypt stored secrets and normalize YAML-parsed numeric IDs to strings
                cfg = traverseSensitiveFields(normalizeAllowedUsers(merged), decryptValue);
            }
            catch (err) {
                // Will warn after logger is set up
            }
        }
        // Layer .env on top (env vars take precedence — already plaintext, normalize IDs)
        cfg = normalizeAllowedUsers(mergeDeep(cfg, loadFromEnv()));
        // Runtime schema validation — catches typos and misconfiguration early
        try {
            cfg = validateConfig(cfg);
        }
        catch (err) {
            // Print a clear error and exit so misconfigured deployments fail fast
            console.error(`\n❌ [GreenFrog] ${err.message}\n`);
            process.exit(1);
        }
        this._config = cfg;
        // Ensure data directory exists
        mkdirSync(this._config.dataDir, { recursive: true });
        // Auto-generate a random gateway secret on first run.
        // If the secret is still the insecure default value, replace it with a
        // cryptographically random token and persist it to the YAML config file
        // so it survives restarts without needing the user to set it manually.
        if (this._config.gateway.secret === DEFAULT_SECRET) {
            this._config.gateway.secret = randomBytes(32).toString('hex');
            this.save();
            console.warn('\n⚠️  [GreenFrog] Gateway secret was the default value — a new random secret has been generated and saved to:\n' +
                `   ${this.configPath}\n` +
                '   Update your Web UI / API clients to use the new value from that file.\n');
        }
    }
    get() {
        return this._config;
    }
    getPublicConfig() {
        return traverseSensitiveFields(this._config, (v) => (v ? CONFIG_MASKED_SENTINEL : ''));
    }
    set(updates) {
        // mergeDeep always returns a fresh object — if we did `this._config = merged`,
        // the module-level `export const config = configManager.get()` would keep
        // pointing at the old snapshot forever.  Instead we mutate the existing
        // object in-place so every importer that captured the reference at startup
        // automatically sees the new values.
        const merged = mergeDeep(this._config, updates);
        Object.assign(this._config, merged);
        this.save();
    }
    save() {
        mkdirSync(this._config.dataDir, { recursive: true });
        // Encrypt sensitive fields before writing — keep _config in-memory as plaintext
        const toStore = traverseSensitiveFields(this._config, encryptValue);
        writeFileSync(this.configPath, yaml.stringify(toStore), 'utf8');
        // Restrict config file permissions: owner read/write only
        if (platform() === 'win32') {
            try {
                // Remove all inherited permissions, grant current user full control only
                const p = this.configPath.replace(/\//g, '\\');
                execSync(`icacls "${p}" /inheritance:r /grant:r "%USERNAME%:(F)"`, { stdio: 'ignore' });
            }
            catch { /* best-effort on restricted environments */ }
        }
        else {
            try {
                chmodSync(this.configPath, 0o600);
            }
            catch { /* ignore on restricted fs */ }
        }
    }
    get dataDir() {
        return this._config.dataDir;
    }
}
export const configManager = new ConfigManager();
export const config = configManager.get();
/**
 * Resolve the effective role for a user in a given channel.
 * Format checked: "channel:userId" first, then bare "userId".
 * Returns 'admin' if roles is not configured (backward-compat).
 */
export function resolveRole(userId, channel) {
    return resolveRoleFromConfig(config.roles, userId, channel);
    /*
    if (!roles) return 'user'; // no roles config → everyone is a regular user (safe default)
  }
    */
}
//# sourceMappingURL=index.js.map