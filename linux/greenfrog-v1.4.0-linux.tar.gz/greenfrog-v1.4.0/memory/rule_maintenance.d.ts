export declare const RULE_MAINTENANCE_INTERVAL_MS: number;
export declare const RULE_MAINTENANCE_STARTUP_DELAY_MS: number;
export declare const RULE_MAINTENANCE_SCOPE_LIMIT: number;
type RuleSummary = {
    totalRules: number;
    compressedRules: number;
    avgConfidence: number;
    lowConfidenceRules: number;
    staleRules: number;
    distinctScopes: number;
};
export type BehavioralRuleMaintenanceOverview = {
    running: boolean;
    intervalMs: number;
    startupDelayMs: number;
    scopeLimit: number;
    cycleCount: number;
    lastStartedAt: string | null;
    lastFinishedAt: string | null;
    lastDurationMs: number | null;
    lastError: string | null;
    lastCycle: {
        discoveredScopes: number;
        processedScopes: number;
        scopesWithChanges: number;
        scopesWithErrors: number;
        decayedRules: number;
        deletedRules: number;
        compressionAttempts: number;
        compressedScopes: number;
        compressionCooldownSkips: number;
        rulesBeforeCompression: number;
        rulesAfterCompression: number;
    };
    ruleSummary: RuleSummary;
};
export declare function getBehavioralRuleMaintenanceOverview(): BehavioralRuleMaintenanceOverview;
export declare function runBehavioralRuleMaintenanceCycle(opts?: {
    scopeLimit?: number;
    provider?: string | null;
    model?: string | null;
}): Promise<BehavioralRuleMaintenanceOverview>;
export {};
//# sourceMappingURL=rule_maintenance.d.ts.map