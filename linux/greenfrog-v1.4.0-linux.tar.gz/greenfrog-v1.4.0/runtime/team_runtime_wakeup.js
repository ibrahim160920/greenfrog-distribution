import { createLogger } from '../utils/logger.js';
const log = createLogger('team-runtime-wakeup');
let handlers = null;
const workspaceWakeups = new Map();
const agentWakeups = new Map();
/** Separate debounce map for mailbox-only fast-path wakeups. */
const agentMailboxWakeups = new Map();
function normalizeReason(signal) {
    return signal.kind;
}
function clearWakeupMap(map) {
    for (const pending of map.values()) {
        clearTimeout(pending.timer);
    }
    map.clear();
}
function scheduleWakeup(map, key, reason, delayMs, run) {
    const existing = map.get(key);
    if (existing) {
        existing.reasons.add(reason);
        return;
    }
    const reasons = new Set([reason]);
    const timer = setTimeout(() => {
        map.delete(key);
        void run([...reasons]).catch((err) => {
            log.warn({ err: String(err), key, reasons: [...reasons] }, 'Team runtime wakeup failed');
        });
    }, delayMs);
    map.set(key, { reasons, timer });
}
export function configureTeamRuntimeWakeups(nextHandlers) {
    clearWakeupMap(workspaceWakeups);
    clearWakeupMap(agentWakeups);
    clearWakeupMap(agentMailboxWakeups);
    handlers = nextHandlers;
}
export function publishTeamRuntimeWakeup(signal) {
    if (!handlers)
        return;
    const debounceMs = Math.max(0, handlers.debounceMs ?? 250);
    const reason = normalizeReason(signal);
    scheduleWakeup(workspaceWakeups, signal.workspaceId, reason, debounceMs, async (reasons) => handlers?.processWorkspace({ workspaceId: signal.workspaceId, reasons }) ?? undefined);
    const agentId = 'recipientAgentId' in signal
        ? signal.recipientAgentId
        : ('assignedAgentId' in signal ? signal.assignedAgentId : null);
    if (!agentId || !agentId.trim())
        return;
    const agentKey = `${signal.workspaceId}:${agentId}`;
    // mailbox_created → fast-path mailbox handler (if registered).
    // All other agent-scoped events → full heartbeat cycle.
    if (signal.kind === 'mailbox_created' && handlers.processAgentMailbox) {
        scheduleWakeup(agentMailboxWakeups, agentKey, reason, debounceMs, async (reasons) => handlers?.processAgentMailbox?.({ workspaceId: signal.workspaceId, agentId, reasons }) ?? undefined);
    }
    else {
        scheduleWakeup(agentWakeups, agentKey, reason, debounceMs, async (reasons) => handlers?.runAgentHeartbeat({ workspaceId: signal.workspaceId, agentId, reasons }) ?? undefined);
    }
}
export function resetTeamRuntimeWakeupsForTests() {
    configureTeamRuntimeWakeups(null);
}
//# sourceMappingURL=team_runtime_wakeup.js.map