import { BaseProvider } from './base.js';
import { AnthropicProvider } from './anthropic.js';
import { OpenAIProvider } from './openai.js';
import { OllamaProvider } from './ollama.js';
import { GeminiProvider } from './gemini.js';
import { MistralProvider, GroqProvider, DeepSeekProvider, QwenProvider, KimiProvider, GLMProvider, GeminiRelayProvider } from './compat.js';
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';
import { ProviderError } from '../utils/errors.js';
import { memoryStore } from '../memory/store.js';
const log = createLogger('providers');
const MODEL_COST_TABLE = [
    // Anthropic Claude
    [/claude-opus/i, { inputPer1M: 15.00, outputPer1M: 75.00 }],
    [/claude-sonnet/i, { inputPer1M: 3.00, outputPer1M: 15.00 }],
    [/claude-haiku/i, { inputPer1M: 0.25, outputPer1M: 1.25 }],
    // OpenAI
    [/gpt-4o-mini/i, { inputPer1M: 0.15, outputPer1M: 0.60 }],
    [/gpt-4o/i, { inputPer1M: 2.50, outputPer1M: 10.00 }],
    [/gpt-4-turbo/i, { inputPer1M: 10.00, outputPer1M: 30.00 }],
    [/gpt-3\.5-turbo/i, { inputPer1M: 0.50, outputPer1M: 1.50 }],
    // Gemini
    [/gemini-1\.5-pro/i, { inputPer1M: 3.50, outputPer1M: 10.50 }],
    [/gemini-1\.5-flash/i, { inputPer1M: 0.075, outputPer1M: 0.30 }],
    // Groq
    [/llama3/i, { inputPer1M: 0.05, outputPer1M: 0.08 }],
    [/mixtral/i, { inputPer1M: 0.24, outputPer1M: 0.24 }],
    // DeepSeek
    [/deepseek-chat/i, { inputPer1M: 0.14, outputPer1M: 0.28 }],
];
function estimateCostUsd(model, inputTokens, outputTokens) {
    for (const [pattern, rate] of MODEL_COST_TABLE) {
        if (pattern.test(model)) {
            return (inputTokens * rate.inputPer1M + outputTokens * rate.outputPer1M) / 1_000_000;
        }
    }
    return null; // local or unknown model
}
/**
 * Maximum wall-clock time for the entire provider fallback chain.
 * If all providers are slow and the chain hasn't produced a response within
 * this window, the call is rejected with a clear error instead of hanging.
 * Overridable via env: PROVIDER_CHAIN_TIMEOUT_MS (default 30 s).
 */
const PROVIDER_CHAIN_TIMEOUT_MS = parseInt(process.env.PROVIDER_CHAIN_TIMEOUT_MS ?? '90000', 10);
function chainTimeout(ms, label) {
    return new Promise((_, reject) => setTimeout(() => reject(new Error(`LLM provider chain timed out after ${ms}ms (${label})`)), ms));
}
/**
 * Check whether the given usage context is over its monthly quota.
 * Returns a ProviderError if the quota is exceeded with hard enforcement,
 * logs a warning for soft enforcement, and returns null if within limits.
 * Fire-and-forget safe: never throws.
 */
async function checkAndEnforceQuota(usageCtx) {
    try {
        const period = new Date().toISOString().slice(0, 7); // 'YYYY-MM'
        const quotaChecks = [
            { scopeType: 'user', scopeId: usageCtx.userId },
        ];
        if (usageCtx.workspaceId) {
            quotaChecks.push({ scopeType: 'workspace', scopeId: usageCtx.workspaceId });
        }
        for (const { scopeType, scopeId } of quotaChecks) {
            const quota = await memoryStore.getUserQuota(scopeType, scopeId);
            if (!quota)
                continue;
            if (!quota.monthlyTokenLimit && !quota.monthlyCostLimitUsd)
                continue;
            const [summary] = await memoryStore.getTokenUsageSummary({
                ...(scopeType === 'user' ? { userId: scopeId } : { workspaceId: scopeId }),
                period,
            });
            if (!summary)
                continue;
            if (quota.monthlyTokenLimit && summary.totalTokens >= quota.monthlyTokenLimit) {
                const msg = `Monthly token limit exceeded for ${scopeType} ${scopeId}: ${summary.totalTokens} / ${quota.monthlyTokenLimit}`;
                if (quota.limitBehavior === 'hard') {
                    return new ProviderError(msg);
                }
                log.warn({ scopeType, scopeId, used: summary.totalTokens, limit: quota.monthlyTokenLimit }, 'Soft token quota exceeded');
            }
            if (quota.monthlyCostLimitUsd && summary.totalCostUsd != null && summary.totalCostUsd >= quota.monthlyCostLimitUsd) {
                const msg = `Monthly cost limit exceeded for ${scopeType} ${scopeId}: $${summary.totalCostUsd.toFixed(4)} / $${quota.monthlyCostLimitUsd}`;
                if (quota.limitBehavior === 'hard') {
                    return new ProviderError(msg);
                }
                log.warn({ scopeType, scopeId, usedUsd: summary.totalCostUsd, limitUsd: quota.monthlyCostLimitUsd }, 'Soft cost quota exceeded');
            }
        }
    }
    catch (err) {
        // Quota check must never crash the provider chain
        log.warn({ err: String(err) }, 'Quota check failed (non-fatal)');
    }
    return null;
}
const quotaReservations = new Map();
const reservedQuotaByScope = new Map();
export function getQuotaReservationOverview() {
    let reservedTokens = 0;
    let reservedCostUsd = 0;
    for (const value of reservedQuotaByScope.values()) {
        reservedTokens += value.tokens;
        reservedCostUsd += value.costUsd;
    }
    return {
        activeReservations: quotaReservations.size,
        reservedScopes: reservedQuotaByScope.size,
        reservedTokens,
        reservedCostUsd: Number(reservedCostUsd.toFixed(4)),
    };
}
function buildQuotaScopeKey(scopeType, scopeId, period) {
    return `${scopeType}:${scopeId}:${period}`;
}
function getReservedQuota(scopeKey) {
    return reservedQuotaByScope.get(scopeKey) ?? { tokens: 0, costUsd: 0 };
}
function applyReservedQuota(scopeKey, deltaTokens, deltaCostUsd) {
    const current = getReservedQuota(scopeKey);
    const nextTokens = Math.max(0, current.tokens + deltaTokens);
    const nextCostUsd = Math.max(0, current.costUsd + deltaCostUsd);
    if (nextTokens === 0 && nextCostUsd === 0) {
        reservedQuotaByScope.delete(scopeKey);
        return;
    }
    reservedQuotaByScope.set(scopeKey, { tokens: nextTokens, costUsd: nextCostUsd });
}
function estimateReservedUsage(request) {
    const serializedPrompt = JSON.stringify({
        systemPrompt: request.systemPrompt ?? '',
        messages: request.messages,
        toolNames: request.tools?.map((tool) => tool.name) ?? [],
    });
    const estimatedInputTokens = Math.max(256, Math.min(8192, Math.ceil(serializedPrompt.length / 4)));
    const configuredFloor = config.hardQuotaReservationTokens ?? 4096;
    const estimatedOutputTokens = Math.max(256, request.maxTokens ?? 0);
    const reservedTokens = Math.max(configuredFloor, estimatedInputTokens + estimatedOutputTokens);
    const model = request.model ?? config.defaultModel;
    return {
        tokens: reservedTokens,
        inputTokens: estimatedInputTokens,
        outputTokens: Math.max(256, reservedTokens - estimatedInputTokens),
        costUsd: estimateCostUsd(model, estimatedInputTokens, Math.max(256, reservedTokens - estimatedInputTokens)),
    };
}
async function reserveQuotaBudget(request) {
    if (!request.usageContext)
        return null;
    const usageCtx = request.usageContext;
    const period = new Date().toISOString().slice(0, 7);
    const estimated = estimateReservedUsage(request);
    const scopes = [];
    const quotaChecks = [
        { scopeType: 'user', scopeId: usageCtx.userId },
    ];
    if (usageCtx.workspaceId) {
        quotaChecks.push({ scopeType: 'workspace', scopeId: usageCtx.workspaceId });
    }
    for (const { scopeType, scopeId } of quotaChecks) {
        const quota = await memoryStore.getUserQuota(scopeType, scopeId);
        if (!quota)
            continue;
        if (!quota.monthlyTokenLimit && !quota.monthlyCostLimitUsd)
            continue;
        const [summary] = await memoryStore.getTokenUsageSummary({
            ...(scopeType === 'user' ? { userId: scopeId } : { workspaceId: scopeId }),
            period,
        });
        const scopeKey = buildQuotaScopeKey(scopeType, scopeId, period);
        const reserved = getReservedQuota(scopeKey);
        const totalTokens = (summary?.totalTokens ?? 0) + reserved.tokens + estimated.tokens;
        const totalCostUsd = (summary?.totalCostUsd ?? 0) + reserved.costUsd + (estimated.costUsd ?? 0);
        if (quota.monthlyTokenLimit && totalTokens > quota.monthlyTokenLimit) {
            const msg = `Monthly token limit would be exceeded for ${scopeType} ${scopeId}: ${totalTokens} / ${quota.monthlyTokenLimit}`;
            if (quota.limitBehavior === 'hard') {
                throw new ProviderError(msg);
            }
            log.warn({ scopeType, scopeId, reservedTokens: estimated.tokens, used: totalTokens, limit: quota.monthlyTokenLimit }, 'Soft token quota would be exceeded');
        }
        if (quota.monthlyCostLimitUsd && totalCostUsd > quota.monthlyCostLimitUsd) {
            const msg = `Monthly cost limit would be exceeded for ${scopeType} ${scopeId}: $${totalCostUsd.toFixed(4)} / $${quota.monthlyCostLimitUsd}`;
            if (quota.limitBehavior === 'hard') {
                throw new ProviderError(msg);
            }
            log.warn({ scopeType, scopeId, reservedCostUsd: estimated.costUsd, usedUsd: totalCostUsd, limitUsd: quota.monthlyCostLimitUsd }, 'Soft cost quota would be exceeded');
        }
        scopes.push({
            key: scopeKey,
            scopeType,
            scopeId,
            tokens: estimated.tokens,
            costUsd: estimated.costUsd,
        });
    }
    if (scopes.length === 0)
        return null;
    const reservation = {
        id: `${Date.now()}:${Math.random().toString(36).slice(2, 10)}`,
        scopes,
    };
    for (const scope of scopes) {
        applyReservedQuota(scope.key, scope.tokens, scope.costUsd ?? 0);
    }
    quotaReservations.set(reservation.id, reservation);
    return reservation;
}
function releaseQuotaBudget(reservation) {
    if (!reservation)
        return;
    if (!quotaReservations.delete(reservation.id))
        return;
    for (const scope of reservation.scopes) {
        applyReservedQuota(scope.key, -scope.tokens, -(scope.costUsd ?? 0));
    }
}
/**
 * Record token usage after a successful provider call.
 * Fire-and-forget — never blocks the response path.
 */
function recordUsageAsync(usageCtx, providerName, response) {
    const inputTokens = response.usage?.inputTokens ?? 0;
    const outputTokens = response.usage?.outputTokens ?? 0;
    if (inputTokens === 0 && outputTokens === 0)
        return; // nothing to record
    const model = response.model ?? 'unknown';
    const costUsd = estimateCostUsd(model, inputTokens, outputTokens);
    memoryStore.recordTokenUsage({
        userId: usageCtx.userId,
        workspaceId: usageCtx.workspaceId ?? null,
        agentId: usageCtx.agentId ?? null,
        provider: providerName,
        model,
        inputTokens,
        outputTokens,
        costUsd,
        channel: usageCtx.channel ?? null,
        sessionKey: usageCtx.sessionKey ?? null,
    }).catch((err) => {
        log.warn({ err: String(err) }, 'Failed to record token usage (non-fatal)');
    });
}
export class ProviderRegistry {
    providers = new Map();
    defaultProviderName;
    /** Total number of times a request fell back to a non-preferred provider (chat). */
    _fallbackCount = 0;
    /** Total number of times a streaming request fell back to a non-preferred provider. */
    _streamFallbackCount = 0;
    /**
     * Optional callback invoked whenever a request falls back to a non-preferred
     * provider.  Register this in index.ts to send admin notifications.
     * Signature: (primary, used, requestLabel) => void
     */
    onFallback;
    /** Total provider fallback count (chat + stream). */
    getFallbackCount() {
        return this._fallbackCount + this._streamFallbackCount;
    }
    constructor(autoInit = true) {
        this.defaultProviderName = config.defaultProvider;
        if (autoInit)
            this.initialize();
    }
    /** Returns an empty registry with no pre-registered providers (useful for unit tests). */
    static createEmpty() {
        return new ProviderRegistry(false);
    }
    initialize() {
        const { providers } = config;
        if (providers.anthropic?.apiKey) {
            this.register(new AnthropicProvider(providers.anthropic.apiKey, providers.anthropic.model, providers.anthropic.baseUrl, providers.anthropic.extraHeaders));
            log.info({ baseUrl: providers.anthropic.baseUrl ?? 'official' }, 'Anthropic provider registered');
        }
        if (providers.openai?.apiKey) {
            const openaiProvider = new OpenAIProvider(providers.openai.apiKey, providers.openai.model, providers.openai.baseUrl, providers.openai.useResponsesApi, providers.openai.reasoningEffort, providers.openai.authMode, providers.openai.authHeader, providers.openai.authScheme, providers.openai.extraHeaders, providers.openai.sendClientRequestId, providers.openai.disableResponseStorage, providers.openai.responsesMaxAttempts, providers.openai.responsesRetryBaseDelayMs);
            this.register(openaiProvider);
            log.info({
                baseUrl: providers.openai.baseUrl ?? 'official',
                model: providers.openai.model ?? 'gpt-4o',
                auth: openaiProvider.getAuthDebugInfo(),
            }, 'OpenAI provider registered');
        }
        // Ollama is always available (local)
        const ollamaUrl = providers.ollama?.baseUrl ?? 'http://localhost:11434';
        this.register(new OllamaProvider(ollamaUrl, providers.ollama?.model));
        log.info('Ollama provider registered');
        if (providers.gemini?.apiKey) {
            if (providers.gemini.baseUrl) {
                this.register(new GeminiRelayProvider(providers.gemini.apiKey, providers.gemini.model, providers.gemini.baseUrl, providers.gemini.authMode, providers.gemini.authHeader, providers.gemini.authScheme, providers.gemini.extraHeaders, providers.gemini.disableResponseStorage));
                log.info({ baseUrl: providers.gemini.baseUrl }, 'Gemini relay provider registered');
            }
            else {
                this.register(new GeminiProvider(providers.gemini.apiKey, providers.gemini.model));
                log.info('Gemini provider registered');
            }
        }
        if (providers.mistral?.apiKey) {
            this.register(new MistralProvider(providers.mistral.apiKey, providers.mistral.model, providers.mistral.baseUrl, providers.mistral.authMode, providers.mistral.authHeader, providers.mistral.authScheme, providers.mistral.extraHeaders, providers.mistral.disableResponseStorage));
            log.info({ baseUrl: providers.mistral.baseUrl ?? 'official' }, 'Mistral provider registered');
        }
        if (providers.groq?.apiKey) {
            this.register(new GroqProvider(providers.groq.apiKey, providers.groq.model, providers.groq.baseUrl, providers.groq.authMode, providers.groq.authHeader, providers.groq.authScheme, providers.groq.extraHeaders, providers.groq.disableResponseStorage));
            log.info({ baseUrl: providers.groq.baseUrl ?? 'official' }, 'Groq provider registered');
        }
        if (providers.deepseek?.apiKey) {
            this.register(new DeepSeekProvider(providers.deepseek.apiKey, providers.deepseek.model, providers.deepseek.baseUrl, providers.deepseek.authMode, providers.deepseek.authHeader, providers.deepseek.authScheme, providers.deepseek.extraHeaders, providers.deepseek.disableResponseStorage));
            log.info({ baseUrl: providers.deepseek.baseUrl ?? 'official' }, 'DeepSeek provider registered');
        }
        if (providers.qwen?.apiKey) {
            this.register(new QwenProvider(providers.qwen.apiKey, providers.qwen.model, providers.qwen.baseUrl, providers.qwen.authMode, providers.qwen.authHeader, providers.qwen.authScheme, providers.qwen.extraHeaders, providers.qwen.disableResponseStorage));
            log.info({ baseUrl: providers.qwen.baseUrl ?? 'official' }, 'Qwen provider registered');
        }
        if (providers.kimi?.apiKey) {
            this.register(new KimiProvider(providers.kimi.apiKey, providers.kimi.model, providers.kimi.baseUrl, providers.kimi.authMode, providers.kimi.authHeader, providers.kimi.authScheme, providers.kimi.extraHeaders, providers.kimi.disableResponseStorage));
            log.info({ baseUrl: providers.kimi.baseUrl ?? 'official' }, 'Kimi provider registered');
        }
        if (providers.glm?.apiKey) {
            this.register(new GLMProvider(providers.glm.apiKey, providers.glm.model, providers.glm.baseUrl, providers.glm.authMode, providers.glm.authHeader, providers.glm.authScheme, providers.glm.extraHeaders, providers.glm.disableResponseStorage));
            log.info({ baseUrl: providers.glm.baseUrl ?? 'official' }, 'GLM provider registered');
        }
    }
    /**
     * Rebuild the registry from the current live config.
     * Called after PUT /api/config so provider changes take effect immediately
     * without a process restart.
     */
    reload() {
        this.providers.clear();
        this.defaultProviderName = config.defaultProvider;
        this.initialize();
        log.info('ProviderRegistry reloaded');
    }
    register(provider) {
        this.providers.set(provider.name, provider);
    }
    /** Returns registered providers with their default model names. */
    listMeta() {
        return [...this.providers.entries()].map(([name, p]) => ({
            name,
            defaultModel: p.defaultModel,
        }));
    }
    get(name) {
        const providerName = name ?? this.defaultProviderName;
        const provider = this.providers.get(providerName);
        if (!provider) {
            const fallbacks = ['openai', 'gemini', 'mistral', 'groq', 'deepseek', 'qwen', 'kimi', 'glm', 'ollama'];
            for (const fb of fallbacks) {
                const fbProvider = this.providers.get(fb);
                if (fbProvider) {
                    log.warn(`Provider "${providerName}" not found, falling back to "${fb}"`);
                    return fbProvider;
                }
            }
            throw new ProviderError(`No AI provider available. Please configure OPENAI_API_KEY, GEMINI_API_KEY, KIMI_API_KEY, or ensure Ollama is running.`);
        }
        return provider;
    }
    /**
     * 带自动 fallback + 全局超时的 chat 调用。
     * 主 provider 失败时，按顺序尝试备用 provider。
     * 整个链路若超过 PROVIDER_CHAIN_TIMEOUT_MS 仍无响应，抛出超时错误。
     */
    async chatWithFallback(request, preferredProvider) {
        return Promise.race([
            this._chatFallbackChain(request, preferredProvider),
            chainTimeout(PROVIDER_CHAIN_TIMEOUT_MS, `preferred=${preferredProvider ?? this.defaultProviderName}`),
        ]);
    }
    async _chatFallbackChain(request, preferredProvider) {
        // 构建尝试顺序：preferred → anthropic → openai → gemini → mistral → groq → deepseek → qwen → kimi → glm → ollama
        const order = [];
        const preferred = preferredProvider ?? this.defaultProviderName;
        order.push(preferred);
        for (const fb of ['anthropic', 'openai', 'gemini', 'mistral', 'groq', 'deepseek', 'qwen', 'kimi', 'glm', 'ollama', ...this.providers.keys()]) {
            if (!order.includes(fb) && this.providers.has(fb))
                order.push(fb);
        }
        // Budget check (runs once before any provider attempt).
        // Design note: this is a best-effort TOCTOU check — concurrent requests can
        // briefly exceed the quota between the check and the actual call.  For hard
        // limits this is acceptable: the overage is at most one concurrent request
        // worth of tokens, and the next check will catch it.  A distributed atomic
        // counter (Redis INCR) would be needed for strict enforcement.
        const reservation = request.usageContext
            ? await reserveQuotaBudget(request)
            : null;
        let lastError;
        try {
            for (const providerName of order) {
                const provider = this.providers.get(providerName);
                if (!provider)
                    continue;
                try {
                    log.debug({ provider: providerName }, 'Attempting chat request');
                    // 切换到备用 provider 时，清掉原来的 model，让备用 provider 用自己的默认 model
                    const providerRequest = providerName === preferred
                        ? request
                        : { ...request, model: undefined };
                    const response = await provider.chat(providerRequest);
                    if (providerName !== preferred) {
                        this._fallbackCount++;
                        log.warn({ primary: preferred, used: providerName }, 'Used fallback provider');
                        try {
                            this.onFallback?.(preferred, providerName, `model=${request.model ?? 'default'}`);
                        }
                        catch { /* hook must not crash chain */ }
                    }
                    // Record token usage (fire-and-forget)
                    if (request.usageContext)
                        recordUsageAsync(request.usageContext, providerName, response);
                    return response;
                }
                catch (err) {
                    // If the caller's AbortSignal fired, propagate immediately — don't
                    // silently retry on a different provider after an intentional abort.
                    if (request.signal?.aborted)
                        throw err;
                    lastError = err;
                    log.warn({ provider: providerName, err: String(err) }, 'Provider failed, trying next');
                }
            }
        }
        finally {
            releaseQuotaBudget(reservation);
        }
        throw new ProviderError(`All providers failed. Last error: ${String(lastError)}`, lastError);
    }
    /**
     * Like chatWithFallback but returns a StreamingCall.
     * Falls back to a non-streaming wrapper if the preferred provider
     * doesn't implement chatStream.
     */
    async chatStreamWithFallback(request, preferredProvider) {
        const order = [];
        const preferred = preferredProvider ?? this.defaultProviderName;
        order.push(preferred);
        for (const fb of ['anthropic', 'openai', 'gemini', 'mistral', 'groq', 'deepseek', 'qwen', 'kimi', 'glm', 'ollama']) {
            if (!order.includes(fb) && this.providers.has(fb))
                order.push(fb);
        }
        const reservation = request.usageContext
            ? await reserveQuotaBudget(request)
            : null;
        // Find first provider that supports streaming
        for (const name of order) {
            const provider = this.providers.get(name);
            if (provider?.chatStream) {
                if (name !== preferred) {
                    this._streamFallbackCount++;
                    log.warn({ primary: preferred, used: name }, 'Used fallback provider for streaming');
                    try {
                        this.onFallback?.(preferred, name, `stream,model=${request.model ?? 'default'}`);
                    }
                    catch { /* hook must not crash */ }
                }
                let streaming;
                try {
                    streaming = provider.chatStream(name === preferred ? request : { ...request, model: undefined });
                }
                catch (err) {
                    releaseQuotaBudget(reservation);
                    throw err;
                }
                return {
                    textStream: streaming.textStream,
                    complete: async () => {
                        try {
                            const response = await streaming.complete();
                            if (request.usageContext)
                                recordUsageAsync(request.usageContext, name, response);
                            return response;
                        }
                        finally {
                            releaseQuotaBudget(reservation);
                        }
                    },
                };
            }
        }
        // No streaming provider — wrap non-streaming in a fake StreamingCall
        const fallbackProvider = this.providers.get(order[0]) ?? [...this.providers.values()][0];
        if (!fallbackProvider) {
            releaseQuotaBudget(reservation);
            throw new ProviderError('No provider available for streaming');
        }
        // Non-streaming shim: yield the full content at once then complete
        const responsePromise = fallbackProvider.chat(request);
        async function* textStream() {
            const response = await responsePromise;
            if (response.content)
                yield response.content;
        }
        return {
            textStream: textStream(),
            complete: async () => {
                try {
                    const response = await responsePromise;
                    if (request.usageContext)
                        recordUsageAsync(request.usageContext, fallbackProvider.name, response);
                    return response;
                }
                finally {
                    releaseQuotaBudget(reservation);
                }
            },
        };
    }
    list() {
        return [...this.providers.keys()];
    }
    setDefault(name) {
        if (!this.providers.has(name)) {
            throw new ProviderError(`Provider "${name}" is not registered`);
        }
        this.defaultProviderName = name;
    }
}
export const providerRegistry = new ProviderRegistry();
export { BaseProvider, AnthropicProvider, OpenAIProvider, OllamaProvider, GeminiProvider, MistralProvider, GroqProvider, DeepSeekProvider, QwenProvider, KimiProvider, GLMProvider, GeminiRelayProvider };
//# sourceMappingURL=index.js.map