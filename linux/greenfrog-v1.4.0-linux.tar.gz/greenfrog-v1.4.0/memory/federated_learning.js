/**
 * Rule Synchronization System
 *
 * Internal module for syncing behavioral rules across deployments.
 * Not exposed in public documentation.
 */
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
import { GLOBAL_RULE_LIBRARY_WORKSPACE_ID } from './index.js';
import { getRuleUsageStats } from './rule_tracking.js';
const log = createLogger('rule-sync');
const DEFAULT_CONFIG = {
    enabled: false, // Disabled by default
    mode: 'manual',
    uploadRules: true,
    uploadStats: false,
    anonymize: true,
    reviewBeforeUpload: true,
    remoteUrl: '', // Must be configured by user
    syncIntervalHours: 24,
};
// ── 匿名化处理 ──────────────────────────────────────────────────────────
const SENSITIVE_PATTERNS = [
    /password|passwd|pwd/i,
    /secret|key|token|api[_-]?key/i,
    /email|mail|@/i,
    /phone|tel|mobile/i,
    /address|addr/i,
    /credit[_-]?card|visa|mastercard/i,
    /ssn|social[_-]?security/i,
    /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/, // 电话号码
    /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/, // 邮箱
];
/**
 * 检查规则是否包含敏感信息
 */
function containsSensitiveInfo(rule) {
    return SENSITIVE_PATTERNS.some(pattern => pattern.test(rule));
}
/**
 * 生成匿名实例 ID（基于机器指纹，但不可逆）
 */
async function generateAnonymousInstanceId() {
    const { createHash } = await import('crypto');
    const os = await import('os');
    // 使用机器信息生成指纹（但不包含可识别信息）
    const fingerprint = [
        os.platform(),
        os.arch(),
        os.cpus().length.toString(),
        // 不使用 hostname、MAC 地址等可识别信息
    ].join('|');
    // 加盐 hash，确保不可逆
    const salt = 'greenfrog-federated-v1';
    return createHash('sha256').update(fingerprint + salt).digest('hex').slice(0, 16);
}
/**
 * 匿名化规则（去除敏感信息）
 */
function anonymizeRule(rule) {
    if (containsSensitiveInfo(rule)) {
        return null; // 拒绝包含敏感信息的规则
    }
    // 去除可能的企业特定信息
    let anonymized = rule;
    // 替换可能的企业名称（简单启发式）
    anonymized = anonymized.replace(/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:Inc|Corp|Ltd|LLC|Co)\b/g, '[Company]');
    // 替换可能的项目名称（大写开头的连续单词）
    anonymized = anonymized.replace(/\b[A-Z][a-z]+(?:[A-Z][a-z]+)+\b/g, '[Project]');
    return anonymized;
}
// ── 规则收集 ────────────────────────────────────────────────────────────
/**
 * 从 workspace 收集可上报的规则
 */
export async function collectUploadableRules(workspaceId, minConfidence = 70, minEvidenceCount = 5) {
    // 获取 workspace 的所有行为规则
    const rules = await memoryStore.getBehavioralRules?.(workspaceId, 'web') ?? [];
    const uploadable = [];
    for (const rule of rules) {
        // 质量过滤
        if (rule.confidence < minConfidence)
            continue;
        // Get real tracking stats — skip rules with insufficient evidence
        const stats = await getRuleUsageStats(rule.rule, workspaceId, 'web');
        if (stats.totalApplications < minEvidenceCount)
            continue;
        // 匿名化
        const anonymized = anonymizeRule(rule.rule);
        if (!anonymized)
            continue;
        uploadable.push({
            rule: anonymized,
            category: rule.category,
            confidence: rule.confidence,
            evidenceCount: stats.totalApplications,
            successRate: stats.successRate,
            language: 'en', // TODO: detect from rule content if needed
            domain: 'general',
        });
    }
    return uploadable;
}
/**
 * 收集统计数据（匿名）
 */
export async function collectAnonymousStats(workspaceId) {
    // 简化实现：实际应该从审计日志统计
    return {
        totalTasks: 0,
        successfulTasks: 0,
        averageConfidence: 0,
    };
}
// ── 上报到中心服务器 ────────────────────────────────────────────────────
/**
 * Upload rules to remote server
 */
export async function uploadRulesToServer(config, workspaceId) {
    if (!config.enabled || !config.uploadRules) {
        return { success: false, message: 'Rule sync is disabled' };
    }
    try {
        // 收集规则
        const rules = await collectUploadableRules(workspaceId);
        if (rules.length === 0) {
            return { success: false, message: 'No uploadable rules found' };
        }
        // 收集统计数据（可选）
        const stats = config.uploadStats ? await collectAnonymousStats(workspaceId) : undefined;
        // Build payload
        const payload = {
            version: '1.0',
            timestamp: new Date().toISOString(),
            instanceId: await generateAnonymousInstanceId(),
            rules,
            stats,
        };
        // Send to remote server
        const response = await fetch(`${config.remoteUrl}/upload`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'GreenFrog/1.0',
            },
            body: JSON.stringify(payload),
        });
        if (!response.ok) {
            throw new Error(`Server returned ${response.status}: ${response.statusText}`);
        }
        const result = await response.json();
        log.info({ rulesCount: rules.length }, 'Rules uploaded successfully');
        return result;
    }
    catch (err) {
        log.error({ err: String(err) }, 'Failed to upload rules');
        return { success: false, message: String(err) };
    }
}
// ── 从全局规则库同步 ────────────────────────────────────────────────────
/**
 * Download global rule library from remote
 */
export async function downloadGlobalRuleLibrary(config) {
    try {
        if (!config.remoteUrl) {
            log.warn('Remote URL not configured');
            return null;
        }
        // Download from remote
        const headers = {
            'User-Agent': 'GreenFrog/1.0',
        };
        // Add authentication if token is provided
        if (config.accessToken) {
            headers['Authorization'] = `token ${config.accessToken}`;
        }
        const response = await fetch(config.remoteUrl, { headers });
        if (!response.ok) {
            throw new Error(`Failed to download: ${response.status}`);
        }
        const library = await response.json();
        log.info({ rulesCount: library.rules.length, version: library.version }, 'Global rule library downloaded');
        return library;
    }
    catch (err) {
        log.error({ err: String(err) }, 'Failed to download global rule library');
        return null;
    }
}
/**
 * 将全局规则库同步到本地
 */
export async function syncGlobalRulesToLocal(library, minConfidence = 80, minUpvotes = 10) {
    let imported = 0;
    let skipped = 0;
    for (const globalRule of library.rules) {
        // 质量过滤
        if (globalRule.confidence < minConfidence) {
            skipped++;
            continue;
        }
        // 社区验证过滤
        if (globalRule.votes.upvotes < minUpvotes) {
            skipped++;
            continue;
        }
        // 检查是否已存在
        const existing = await memoryStore.getBehavioralRules?.(GLOBAL_RULE_LIBRARY_WORKSPACE_ID, 'web') ?? [];
        const alreadyExists = existing.some(r => r.rule === globalRule.rule);
        if (alreadyExists) {
            skipped++;
            continue;
        }
        // 导入到全局规则库
        await memoryStore.upsertBehavioralRule({
            userId: GLOBAL_RULE_LIBRARY_WORKSPACE_ID,
            channel: 'web',
            rule: globalRule.rule,
            category: globalRule.category,
            confidence: globalRule.confidence,
            source: `Imported from global library (${globalRule.id})`,
        });
        imported++;
    }
    log.info({ imported, skipped }, 'Global rules synced to local');
    return { imported, skipped };
}
/**
 * Start periodic sync (background task)
 */
export async function startPeriodicSync(config) {
    if (!config.enabled) {
        log.info('Rule sync is disabled, skipping periodic sync');
        return;
    }
    const syncInterval = config.syncIntervalHours * 60 * 60 * 1000;
    const sync = async () => {
        log.info('Starting periodic rule sync');
        const library = await downloadGlobalRuleLibrary(config);
        if (library) {
            await syncGlobalRulesToLocal(library);
        }
    };
    // 立即执行一次
    await sync();
    // 定期执行
    setInterval(sync, syncInterval);
}
// ── 导出功能（手动上报） ────────────────────────────────────────────────
/**
 * 导出规则为 JSON 文件（用户可以手动提交 PR）
 */
export async function exportRulesToFile(workspaceId, outputPath) {
    try {
        const rules = await collectUploadableRules(workspaceId);
        if (rules.length === 0) {
            return { success: false, message: 'No uploadable rules found', rulesCount: 0 };
        }
        const payload = {
            version: '1.0',
            timestamp: new Date().toISOString(),
            instanceId: await generateAnonymousInstanceId(),
            rules,
        };
        const fs = await import('fs/promises');
        await fs.writeFile(outputPath, JSON.stringify(payload, null, 2), 'utf-8');
        log.info({ rulesCount: rules.length, outputPath }, 'Rules exported to file');
        return { success: true, message: `Exported ${rules.length} rules to ${outputPath}`, rulesCount: rules.length };
    }
    catch (err) {
        log.error({ err: String(err) }, 'Failed to export rules');
        return { success: false, message: String(err), rulesCount: 0 };
    }
}
/**
 * 从 JSON 文件导入规则
 */
export async function importRulesFromFile(inputPath, targetWorkspaceId) {
    try {
        const fs = await import('fs/promises');
        const content = await fs.readFile(inputPath, 'utf-8');
        const payload = JSON.parse(content);
        let imported = 0;
        for (const rule of payload.rules) {
            await memoryStore.upsertBehavioralRule({
                userId: targetWorkspaceId,
                channel: 'web',
                rule: rule.rule,
                category: rule.category,
                confidence: rule.confidence,
                source: `Imported from file: ${inputPath}`,
            });
            imported++;
        }
        log.info({ imported, inputPath }, 'Rules imported from file');
        return { success: true, message: `Imported ${imported} rules`, imported };
    }
    catch (err) {
        log.error({ err: String(err) }, 'Failed to import rules');
        return { success: false, message: String(err), imported: 0 };
    }
}
// ── 统计和监控 ──────────────────────────────────────────────────────────
/**
 * Get rule sync statistics
 */
export async function getRuleSyncStats(workspaceId) {
    const localRules = await memoryStore.getBehavioralRules?.(workspaceId, 'web') ?? [];
    const globalRules = await memoryStore.getBehavioralRules?.(GLOBAL_RULE_LIBRARY_WORKSPACE_ID, 'web') ?? [];
    const uploadableRules = await collectUploadableRules(workspaceId);
    return {
        localRulesCount: localRules.length,
        globalRulesCount: globalRules.length,
        uploadableRulesCount: uploadableRules.length,
        lastSyncTime: null, // TODO: 从数据库读取
    };
}
//# sourceMappingURL=federated_learning.js.map