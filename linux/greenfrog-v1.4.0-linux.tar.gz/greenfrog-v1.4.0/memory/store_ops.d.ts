import Database from 'better-sqlite3';
import type { JobStatus, PatrolCheck, PatrolResult, ScheduledJob, WorkflowDef } from '../utils/types.js';
export declare function createOpsStore(db: Database.Database): {
    saveJob(job: Omit<ScheduledJob, "runCount" | "createdAt">): string;
    getJobs(userId?: string): ScheduledJob[];
    updateJobRun(id: string, nextRun?: Date): void;
    updateJobStatus(id: string, status: JobStatus): void;
    deleteJob(id: string): boolean;
    updateJobNotifyIf(id: string, notifyIf: string): void;
    updateJobLastResult(id: string, lastResult: string): void;
    savePatrolCheck(check: Omit<PatrolCheck, "id" | "createdAt" | "consecutiveFailures" | "lastCheck" | "lastStatus">): string;
    getPatrolChecks(userId?: string): PatrolCheck[];
    updatePatrolResult(id: string, ok: boolean, status: "ok" | "error" | "timeout", consecutiveFailures: number): void;
    updatePatrolStatus(id: string, status: "active" | "paused"): void;
    deletePatrolCheck(id: string): boolean;
    savePatrolResult(result: Omit<PatrolResult, "id" | "checkedAt">): void;
    getPatrolHistory(checkId: string, limit?: number): PatrolResult[];
    saveWorkflow(wf: Omit<WorkflowDef, "id" | "createdAt" | "runCount" | "lastRun">): string;
    getWorkflows(userId?: string): WorkflowDef[];
    updateWorkflowRun(id: string): void;
    updateWorkflowStatus(id: string, status: "active" | "paused"): void;
    deleteWorkflow(id: string): boolean;
    /** Returns the timestamp (ms) of the most recently completed scheduled job run, or null. */
    getLastJobRunTime(): number | null;
    /** Returns the timestamp (ms) of the most recently completed workflow run, or null. */
    getLastWorkflowRunTime(): number | null;
};
//# sourceMappingURL=store_ops.d.ts.map