import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
const WRITE_SYSTEM = `你是一位资深的投标文件撰写专家，拥有丰富的政府采购、工程招标、IT系统采购等领域的投标经验。
你熟悉《中华人民共和国招标投标法》及相关法规，能够撰写符合规范、竞争力强的投标文件。
输出格式要求：结构清晰、条款完整、语言专业、符合中国招投标规范。`;
const REVIEW_SYSTEM = `你是一位资深的投标文件审核专家，具备丰富的招投标评审经验。
你能够从符合性、技术方案、商务条款、价格竞争力等多个维度对投标文件进行全面审核，
识别潜在风险点，并提出具体可操作的改进建议。`;
export class BidDocumentSkill extends BaseSkill {
    definition = {
        name: 'bid_document',
        description: '投标文件撰写与审核。支持生成完整投标文件（投标函/技术方案/商务方案/报价表等）或对已有投标文件进行专业审核，识别风险点并提出改进建议。',
        category: 'professional',
        parameters: [
            { name: 'action', type: 'string', required: true, description: '操作类型：write=撰写投标文件，review=审核投标文件', enum: ['write', 'review'] },
            { name: 'project_name', type: 'string', required: true, description: '项目名称' },
            { name: 'project_type', type: 'string', required: false, description: '项目类型，如：IT系统建设、工程施工、服务采购、货物采购等', default: 'IT系统建设' },
            { name: 'requirements', type: 'string', required: false, description: '招标要求/技术规格/招标文件核心内容（write时建议提供）' },
            { name: 'document', type: 'string', required: false, description: '待审核的投标文件内容（review时必需）' },
            { name: 'budget', type: 'string', required: false, description: '预算金额或投标报价' },
            { name: 'company_info', type: 'string', required: false, description: '投标公司基本信息（名称/资质/业绩等）' },
            { name: 'format', type: 'string', required: false, description: '输出格式：full=完整文件，outline=大纲框架', default: 'full', enum: ['full', 'outline'] },
        ],
        examples: [
            'bid_document action=write project_name="智慧城市数据平台建设项目" project_type="IT系统建设" requirements="需要大数据平台、GIS系统、数据治理模块"',
            'bid_document action=review project_name="办公楼改造工程" document="[投标文件内容]"',
        ],
    };
    async execute(params, _ctx) {
        const action = String(params.action ?? '').trim();
        const projectName = String(params.project_name ?? '').trim();
        const projectType = String(params.project_type ?? 'IT系统建设').trim();
        const requirements = String(params.requirements ?? '').trim();
        const document = String(params.document ?? '').trim();
        const budget = String(params.budget ?? '').trim();
        const companyInfo = String(params.company_info ?? '').trim();
        const format = String(params.format ?? 'full').trim();
        if (!action)
            return this.err('请指定操作类型：write 或 review');
        if (!projectName)
            return this.err('请提供项目名称');
        if (action === 'write') {
            return this.writeDocument(projectName, projectType, requirements, budget, companyInfo, format);
        }
        else if (action === 'review') {
            if (!document)
                return this.err('审核模式需要提供待审核的投标文件内容（document参数）');
            return this.reviewDocument(projectName, projectType, document, requirements);
        }
        return this.err(`不支持的操作类型：${action}，请使用 write 或 review`);
    }
    async writeDocument(projectName, projectType, requirements, budget, companyInfo, format) {
        const isOutline = format === 'outline';
        const budgetLine = budget ? `\n- 预算/报价：${budget}` : '';
        const companyLine = companyInfo ? `\n- 投标方信息：${companyInfo}` : '';
        const reqLine = requirements ? `\n\n【招标要求/技术规格】\n${requirements}` : '';
        const prompt = isOutline
            ? `请为以下项目生成投标文件大纲框架：
项目名称：${projectName}
项目类型：${projectType}${budgetLine}${companyLine}${reqLine}

请输出：
1. 投标文件目录结构（含各章节标题和主要内容说明）
2. 各章节撰写要点提示
3. 需要特别注意的关键事项`
            : `请为以下项目撰写完整的投标文件：
项目名称：${projectName}
项目类型：${projectType}${budgetLine}${companyLine}${reqLine}

请按以下结构输出完整投标文件：

## 一、投标函
（正式投标意向声明，包含项目名称、投标报价、有效期、承诺事项）

## 二、法定代表人授权书
（授权委托书模板）

## 三、投标报价表
（分项报价明细，含人工/设备/软件/服务等）

## 四、技术方案
### 4.1 需求理解与分析
### 4.2 总体技术方案
### 4.3 技术规格响应表（逐条响应招标要求）
### 4.4 关键技术实现方案
### 4.5 系统架构设计

## 五、项目管理方案
### 5.1 项目组织架构
### 5.2 实施进度计划
### 5.3 质量保证措施
### 5.4 风险管理方案

## 六、售后服务承诺
（保修期、响应时间、培训、维护等）

## 七、资质证明清单
（需提供的证书、业绩、人员资质清单）`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt: WRITE_SYSTEM,
                maxTokens: isOutline ? 1500 : 4000,
                temperature: 0.3,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err('投标文件生成失败，请重试');
            return this.text(`# 投标文件 — ${projectName}\n\n${output}`);
        }
        catch (err) {
            return this.err(`投标文件生成失败：${String(err)}`);
        }
    }
    async reviewDocument(projectName, projectType, document, requirements) {
        const reqSection = requirements ? `\n\n【招标要求（用于对照审核）】\n${requirements}` : '';
        const docSnippet = document.slice(0, 6000);
        const prompt = `请对以下投标文件进行专业审核：

项目名称：${projectName}
项目类型：${projectType}${reqSection}

【待审核投标文件】
${docSnippet}${document.length > 6000 ? '\n\n[文件内容较长，已截取前6000字进行审核]' : ''}

请从以下维度进行全面审核，输出结构化审核报告：

## 一、符合性检查
（逐项检查是否满足招标文件的必要条件，标注：✅符合 / ❌不符合 / ⚠️需补充）

## 二、技术方案评分（满分100分）
| 评分维度 | 分值 | 得分 | 评价 |
|---------|------|------|------|
| 需求理解准确性 | 20 | | |
| 技术方案可行性 | 25 | | |
| 方案创新性 | 15 | | |
| 实施计划合理性 | 20 | | |
| 风险管控能力 | 20 | | |

## 三、商务条款风险点
（列出合同条款、付款方式、违约责任等方面的风险）

## 四、价格竞争力分析
（报价合理性、成本构成、与市场价格对比）

## 五、改进建议（按优先级排序）
### 高优先级（必须修改）
### 中优先级（建议修改）
### 低优先级（可选优化）

## 六、综合评估
（总体评价、中标概率预估、核心竞争力分析）`;
        try {
            const res = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: prompt }],
                systemPrompt: REVIEW_SYSTEM,
                maxTokens: 3000,
                temperature: 0.2,
            });
            const output = res.content?.trim() ?? '';
            if (!output)
                return this.err('投标文件审核失败，请重试');
            return this.text(`# 投标文件审核报告 — ${projectName}\n\n${output}`);
        }
        catch (err) {
            return this.err(`投标文件审核失败：${String(err)}`);
        }
    }
}
//# sourceMappingURL=bid_document.js.map