function toNullableString(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : null;
}
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
export function parseTeamTopologyModelRoute(raw) {
    if (!isRecord(raw))
        return null;
    const provider = toNullableString(raw['provider']);
    const model = toNullableString(raw['model']);
    if (!provider && !model)
        return null;
    return { provider, model };
}
export function parseTeamTopologyModelRoutes(raw) {
    if (!isRecord(raw))
        return null;
    const keys = [
        'orchestrator',
        'challenge_reflection',
        'success_reflection',
        'reviewer',
        'heartbeat',
        'default_worker',
    ];
    const routes = {};
    for (const key of keys) {
        const route = parseTeamTopologyModelRoute(raw[key]);
        if (route) {
            routes[key] = route;
        }
    }
    return Object.keys(routes).length > 0 ? routes : null;
}
export function parseAdaptiveModelPolicyInput(raw) {
    if (!isRecord(raw))
        return null;
    const promotedProvider = toNullableString(raw['promotedProvider']);
    const promotedModel = toNullableString(raw['promotedModel']);
    const revertProvider = toNullableString(raw['revertProvider']);
    const revertModel = toNullableString(raw['revertModel']);
    if (!promotedProvider && !promotedModel && !revertProvider && !revertModel)
        return null;
    return {
        promotedProvider,
        promotedModel,
        revertProvider,
        revertModel,
        promoteOnChallengeSuccessRate: Number.isFinite(Number(raw['promoteOnChallengeSuccessRate']))
            ? Math.min(1, Math.max(0, Number(raw['promoteOnChallengeSuccessRate'])))
            : 0.8,
        revertOnChallengeSuccessRate: Number.isFinite(Number(raw['revertOnChallengeSuccessRate']))
            ? Math.min(1, Math.max(0, Number(raw['revertOnChallengeSuccessRate'])))
            : 0.5,
        minChallengedTasks: Number.isFinite(Number(raw['minChallengedTasks']))
            ? Math.max(1, Math.floor(Number(raw['minChallengedTasks'])))
            : 3,
        cooldownMinutes: Number.isFinite(Number(raw['cooldownMinutes']))
            ? Math.max(1, Math.floor(Number(raw['cooldownMinutes'])))
            : 60,
    };
}
function readTopologyOrchestratorRules(raw) {
    if (!isRecord(raw))
        return null;
    return {
        onConflict: raw['onConflict'] === 'supervisor_resolve' ? 'supervisor_resolve' : 'consensus',
        onConsensusRejected: raw['onConsensusRejected'] === 'reflect_and_retry' ? 'reflect_and_retry' : 'block',
        onTaskDone: raw['onTaskDone'] === 'broadcast_result' ? 'broadcast_result' : 'silent',
        model: toNullableString(raw['model']),
        provider: toNullableString(raw['provider']),
    };
}
function readStrategyVersion(raw) {
    const value = Number(raw);
    return Number.isFinite(value) && value >= 1 ? Math.floor(value) : 1;
}
function readStrategyUpdatedAt(raw) {
    return toNullableString(raw);
}
function parseTeamTopologyStrategyHistory(raw) {
    if (!Array.isArray(raw))
        return null;
    const history = raw
        .filter((item) => isRecord(item))
        .map((item) => ({
        version: readStrategyVersion(item['version']),
        updatedAt: readStrategyUpdatedAt(item['updatedAt']) ?? new Date(0).toISOString(),
        orchestratorRules: readTopologyOrchestratorRules(item['orchestratorRules']),
        adaptiveModelPolicy: parseAdaptiveModelPolicyInput(item['adaptiveModelPolicy']),
        modelRoutes: parseTeamTopologyModelRoutes(item['modelRoutes']),
    }))
        .filter((item) => Boolean(item.updatedAt));
    return history.length > 0 ? history : null;
}
export function parseTeamTopologyCandidateStrategy(raw) {
    if (!isRecord(raw))
        return null;
    const rolloutPercent = Number(raw['rolloutPercent']);
    const normalizedRolloutPercent = Number.isFinite(rolloutPercent)
        ? Math.min(100, Math.max(0, Math.round(rolloutPercent)))
        : 0;
    const orchestratorRules = readTopologyOrchestratorRules(raw['orchestratorRules']);
    const adaptiveModelPolicy = parseAdaptiveModelPolicyInput(raw['adaptiveModelPolicy']);
    const modelRoutes = parseTeamTopologyModelRoutes(raw['modelRoutes']);
    if (!orchestratorRules && !adaptiveModelPolicy && !modelRoutes)
        return null;
    return {
        version: readStrategyVersion(raw['version']),
        updatedAt: readStrategyUpdatedAt(raw['updatedAt']) ?? new Date(0).toISOString(),
        rolloutPercent: normalizedRolloutPercent,
        orchestratorRules,
        adaptiveModelPolicy,
        modelRoutes,
    };
}
export function parseTeamTopologyCandidateRolloutPolicy(raw) {
    if (!isRecord(raw))
        return null;
    return {
        minTaskCount: Number.isFinite(Number(raw['minTaskCount']))
            ? Math.max(1, Math.floor(Number(raw['minTaskCount'])))
            : 5,
        minChallengedTasks: Number.isFinite(Number(raw['minChallengedTasks']))
            ? Math.max(1, Math.floor(Number(raw['minChallengedTasks'])))
            : 3,
        cooldownMinutes: Number.isFinite(Number(raw['cooldownMinutes']))
            ? Math.max(1, Math.floor(Number(raw['cooldownMinutes'])))
            : 60,
        stepUpPercent: Number.isFinite(Number(raw['stepUpPercent']))
            ? Math.min(100, Math.max(1, Math.round(Number(raw['stepUpPercent']))))
            : 10,
        stepDownPercent: Number.isFinite(Number(raw['stepDownPercent']))
            ? Math.min(100, Math.max(1, Math.round(Number(raw['stepDownPercent']))))
            : 25,
        maxRolloutPercent: Number.isFinite(Number(raw['maxRolloutPercent']))
            ? Math.min(100, Math.max(1, Math.round(Number(raw['maxRolloutPercent']))))
            : 100,
        promoteToStablePercent: Number.isFinite(Number(raw['promoteToStablePercent']))
            ? Math.min(100, Math.max(1, Math.round(Number(raw['promoteToStablePercent']))))
            : 100,
        promoteOnChallengeSuccessRate: Number.isFinite(Number(raw['promoteOnChallengeSuccessRate']))
            ? Math.min(1, Math.max(0, Number(raw['promoteOnChallengeSuccessRate'])))
            : 0.8,
        rollbackOnChallengeSuccessRate: Number.isFinite(Number(raw['rollbackOnChallengeSuccessRate']))
            ? Math.min(1, Math.max(0, Number(raw['rollbackOnChallengeSuccessRate'])))
            : 0.5,
        rollbackOnConsensusTimeoutRate: Number.isFinite(Number(raw['rollbackOnConsensusTimeoutRate']))
            ? Math.min(1, Math.max(0, Number(raw['rollbackOnConsensusTimeoutRate'])))
            : 0.3,
        rollbackOnBlockedRate: Number.isFinite(Number(raw['rollbackOnBlockedRate']))
            ? Math.min(1, Math.max(0, Number(raw['rollbackOnBlockedRate'])))
            : 0.25,
        healthyConsensusTimeoutRate: Number.isFinite(Number(raw['healthyConsensusTimeoutRate']))
            ? Math.min(1, Math.max(0, Number(raw['healthyConsensusTimeoutRate'])))
            : 0.1,
        healthyBlockedRate: Number.isFinite(Number(raw['healthyBlockedRate']))
            ? Math.min(1, Math.max(0, Number(raw['healthyBlockedRate'])))
            : 0.1,
    };
}
export function parseTeamTopologyCandidateRolloutControl(raw) {
    if (!isRecord(raw))
        return null;
    const frozen = raw['frozen'] === true;
    const enabled = raw['enabled'] !== false;
    return {
        enabled,
        frozen,
        requirePromotionApproval: raw['requirePromotionApproval'] === true,
        approvalUserIds: Array.isArray(raw['approvalUserIds'])
            ? raw['approvalUserIds']
                .filter((item) => typeof item === 'string' && item.trim().length > 0)
                .map((item) => item.trim())
            : null,
        freezeReason: toNullableString(raw['freezeReason']),
        frozenAt: toNullableString(raw['frozenAt']),
        frozenBy: toNullableString(raw['frozenBy']),
        updatedAt: toNullableString(raw['updatedAt']),
        updatedBy: toNullableString(raw['updatedBy']),
    };
}
export function parseTeamTopologyCandidateRolloutAudit(raw) {
    if (!Array.isArray(raw))
        return null;
    const audit = raw
        .filter((item) => isRecord(item))
        .map((item) => {
        const action = item['action'] === 'increase'
            || item['action'] === 'decrease'
            || item['action'] === 'promote'
            || item['action'] === 'freeze'
            || item['action'] === 'resume'
            || item['action'] === 'manual_promote'
            || item['action'] === 'approval_requested'
            || item['action'] === 'approval_approved'
            || item['action'] === 'approval_rejected'
            ? item['action']
            : 'observe';
        const actor = item['actor'] === 'user' ? 'user' : 'system';
        return {
            action,
            at: readStrategyUpdatedAt(item['at']) ?? new Date(0).toISOString(),
            actor,
            reason: toNullableString(item['reason']),
            fromRolloutPercent: Number.isFinite(Number(item['fromRolloutPercent'])) ? Number(item['fromRolloutPercent']) : null,
            toRolloutPercent: Number.isFinite(Number(item['toRolloutPercent'])) ? Number(item['toRolloutPercent']) : null,
            candidateVersion: Number.isFinite(Number(item['candidateVersion'])) ? Number(item['candidateVersion']) : null,
            stableVersion: Number.isFinite(Number(item['stableVersion'])) ? Number(item['stableVersion']) : null,
            metrics: isRecord(item['metrics']) ? item['metrics'] : null,
        };
    })
        .filter((item) => Boolean(item.at));
    return audit.length > 0 ? audit : null;
}
function normalizeStrategyConfig(raw) {
    return {
        orchestratorRules: raw.orchestratorRules ?? null,
        adaptiveModelPolicy: raw.adaptiveModelPolicy ?? null,
        modelRoutes: raw.modelRoutes ?? null,
    };
}
function readStrategyConfigFromMetadata(metadata) {
    return normalizeStrategyConfig({
        orchestratorRules: readTopologyOrchestratorRules(metadata?.['orchestratorRules']),
        adaptiveModelPolicy: parseAdaptiveModelPolicyInput(metadata?.['adaptiveModelPolicy']),
        modelRoutes: parseTeamTopologyModelRoutes(metadata?.['modelRoutes']),
    });
}
function buildStrategySnapshot(config, version, updatedAt) {
    return {
        version,
        updatedAt,
        orchestratorRules: config.orchestratorRules,
        adaptiveModelPolicy: config.adaptiveModelPolicy,
        modelRoutes: config.modelRoutes,
    };
}
function sameStrategyConfig(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
}
export function hydrateTeamTopology(topology) {
    const metadata = topology.metadata ?? {};
    return {
        ...topology,
        orchestratorRules: topology.orchestratorRules ?? readTopologyOrchestratorRules(metadata['orchestratorRules']),
        adaptiveModelPolicy: topology.adaptiveModelPolicy ?? parseAdaptiveModelPolicyInput(metadata['adaptiveModelPolicy']),
        modelRoutes: topology.modelRoutes ?? parseTeamTopologyModelRoutes(metadata['modelRoutes']),
        strategyVersion: topology.strategyVersion ?? readStrategyVersion(metadata['strategyVersion']),
        strategyUpdatedAt: topology.strategyUpdatedAt ?? readStrategyUpdatedAt(metadata['strategyUpdatedAt']),
        strategyHistory: topology.strategyHistory ?? parseTeamTopologyStrategyHistory(metadata['strategyHistory']),
        candidateStrategy: topology.candidateStrategy ?? parseTeamTopologyCandidateStrategy(metadata['candidateStrategy']),
        candidateRolloutPolicy: topology.candidateRolloutPolicy ?? parseTeamTopologyCandidateRolloutPolicy(metadata['candidateRolloutPolicy']),
        candidateRolloutControl: topology.candidateRolloutControl ?? parseTeamTopologyCandidateRolloutControl(metadata['candidateRolloutControl']),
        candidateRolloutAudit: topology.candidateRolloutAudit ?? parseTeamTopologyCandidateRolloutAudit(metadata['candidateRolloutAudit']),
    };
}
export function mergeTeamTopologyMetadata(metadata, updates, options) {
    const next = { ...(metadata ?? {}) };
    const existingMetadata = options?.existingTopology?.metadata ?? metadata;
    const nowIso = options?.nowIso ?? new Date().toISOString();
    if ('orchestratorRules' in updates) {
        if (updates.orchestratorRules)
            next['orchestratorRules'] = updates.orchestratorRules;
        else
            delete next['orchestratorRules'];
    }
    if ('adaptiveModelPolicy' in updates) {
        if (updates.adaptiveModelPolicy)
            next['adaptiveModelPolicy'] = updates.adaptiveModelPolicy;
        else
            delete next['adaptiveModelPolicy'];
    }
    if ('modelRoutes' in updates) {
        if (updates.modelRoutes && Object.keys(updates.modelRoutes).length > 0)
            next['modelRoutes'] = updates.modelRoutes;
        else
            delete next['modelRoutes'];
    }
    if ('candidateStrategy' in updates) {
        if (updates.candidateStrategy) {
            const previousCandidate = options?.existingTopology?.candidateStrategy
                ?? parseTeamTopologyCandidateStrategy(existingMetadata?.['candidateStrategy']);
            const previousVersion = previousCandidate?.version ?? 0;
            const candidateChanged = !previousCandidate
                || JSON.stringify({
                    rolloutPercent: previousCandidate.rolloutPercent,
                    orchestratorRules: previousCandidate.orchestratorRules ?? null,
                    adaptiveModelPolicy: previousCandidate.adaptiveModelPolicy ?? null,
                    modelRoutes: previousCandidate.modelRoutes ?? null,
                }) !== JSON.stringify({
                    rolloutPercent: updates.candidateStrategy.rolloutPercent,
                    orchestratorRules: updates.candidateStrategy.orchestratorRules ?? null,
                    adaptiveModelPolicy: updates.candidateStrategy.adaptiveModelPolicy ?? null,
                    modelRoutes: updates.candidateStrategy.modelRoutes ?? null,
                });
            const currentCandidate = {
                ...updates.candidateStrategy,
                version: candidateChanged ? previousVersion + 1 : previousVersion,
                updatedAt: candidateChanged ? nowIso : (previousCandidate?.updatedAt ?? nowIso),
            };
            next['candidateStrategy'] = currentCandidate;
        }
        else {
            delete next['candidateStrategy'];
        }
    }
    if ('candidateRolloutPolicy' in updates) {
        if (updates.candidateRolloutPolicy)
            next['candidateRolloutPolicy'] = updates.candidateRolloutPolicy;
        else
            delete next['candidateRolloutPolicy'];
    }
    if ('candidateRolloutControl' in updates) {
        if (updates.candidateRolloutControl)
            next['candidateRolloutControl'] = updates.candidateRolloutControl;
        else
            delete next['candidateRolloutControl'];
    }
    const previousConfig = options?.existingTopology
        ? normalizeStrategyConfig({
            orchestratorRules: options.existingTopology.orchestratorRules ?? null,
            adaptiveModelPolicy: options.existingTopology.adaptiveModelPolicy ?? null,
            modelRoutes: options.existingTopology.modelRoutes ?? null,
        })
        : readStrategyConfigFromMetadata(existingMetadata);
    const existingHasStrategyState = Boolean(options?.existingTopology
        || readTopologyOrchestratorRules(existingMetadata?.['orchestratorRules'])
        || parseAdaptiveModelPolicyInput(existingMetadata?.['adaptiveModelPolicy'])
        || parseTeamTopologyModelRoutes(existingMetadata?.['modelRoutes'])
        || parseTeamTopologyStrategyHistory(existingMetadata?.['strategyHistory'])
        || existingMetadata?.['strategyVersion'] !== undefined
        || existingMetadata?.['strategyUpdatedAt'] !== undefined);
    const currentConfig = readStrategyConfigFromMetadata(next);
    const previousVersion = options?.existingTopology?.strategyVersion
        ?? readStrategyVersion(existingMetadata?.['strategyVersion']);
    const previousUpdatedAt = options?.existingTopology?.strategyUpdatedAt
        ?? readStrategyUpdatedAt(existingMetadata?.['strategyUpdatedAt']);
    const previousHistory = options?.existingTopology?.strategyHistory
        ?? parseTeamTopologyStrategyHistory(existingMetadata?.['strategyHistory'])
        ?? [];
    const configChanged = !sameStrategyConfig(previousConfig, currentConfig);
    const version = !existingHasStrategyState
        ? 1
        : (configChanged ? previousVersion + 1 : previousVersion);
    const effectiveUpdatedAt = configChanged || !previousUpdatedAt ? nowIso : previousUpdatedAt;
    const nextHistory = configChanged || previousHistory.length === 0
        ? [...previousHistory, buildStrategySnapshot(currentConfig, version, effectiveUpdatedAt)].slice(-20)
        : previousHistory;
    next['strategyVersion'] = version;
    next['strategyUpdatedAt'] = effectiveUpdatedAt;
    next['strategyHistory'] = nextHistory;
    return Object.keys(next).length > 0 ? next : undefined;
}
export function buildTeamTopologyStrategySnapshot(topology) {
    const hydrated = hydrateTeamTopology(topology);
    return buildStrategySnapshot(normalizeStrategyConfig({
        orchestratorRules: hydrated.orchestratorRules ?? null,
        adaptiveModelPolicy: hydrated.adaptiveModelPolicy ?? null,
        modelRoutes: hydrated.modelRoutes ?? null,
    }), hydrated.strategyVersion ?? 1, hydrated.strategyUpdatedAt ?? new Date(0).toISOString());
}
export function findTeamTopologyStrategySnapshot(topology, version) {
    if (!topology)
        return null;
    const hydrated = hydrateTeamTopology(topology);
    const normalizedVersion = Number.isFinite(version) && version >= 1 ? Math.floor(version) : 0;
    if (!normalizedVersion)
        return null;
    return hydrated.strategyHistory?.find((snapshot) => snapshot.version === normalizedVersion) ?? null;
}
function computeRolloutBucket(seed) {
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
        hash = ((hash << 5) - hash + seed.charCodeAt(i)) | 0;
    }
    return Math.abs(hash) % 100;
}
export function selectTeamTopologyStrategyTrack(topology, seed) {
    if (!topology)
        return null;
    const hydrated = hydrateTeamTopology(topology);
    const stable = buildTeamTopologyStrategySnapshot(hydrated);
    const candidate = hydrated.candidateStrategy;
    if (!candidate || candidate.rolloutPercent <= 0) {
        return { track: 'stable', snapshot: stable };
    }
    return computeRolloutBucket(`${hydrated.id}:${seed}`) < candidate.rolloutPercent
        ? { track: 'candidate', snapshot: candidate }
        : { track: 'stable', snapshot: stable };
}
export function buildPromoteCandidateStrategyUpdates(topology) {
    if (!topology)
        return null;
    const hydrated = hydrateTeamTopology(topology);
    const candidate = hydrated.candidateStrategy;
    if (!candidate)
        return null;
    return {
        candidate,
        updates: {
            orchestratorRules: candidate.orchestratorRules ?? null,
            adaptiveModelPolicy: candidate.adaptiveModelPolicy ?? null,
            modelRoutes: candidate.modelRoutes ?? null,
            candidateStrategy: null,
        },
    };
}
export function appendCandidateRolloutAuditEvent(metadata, event) {
    const current = parseTeamTopologyCandidateRolloutAudit(metadata?.['candidateRolloutAudit']) ?? [];
    return {
        ...(metadata ?? {}),
        candidateRolloutAudit: [...current, event].slice(-50),
    };
}
export function resolveTeamTopologyModelRoute(topology, routeKey, fallback) {
    if (!topology)
        return fallback ?? null;
    const hydrated = hydrateTeamTopology(topology);
    const route = hydrated.modelRoutes?.[routeKey] ?? null;
    if (route?.provider || route?.model)
        return route;
    if ((routeKey === 'orchestrator' || routeKey === 'challenge_reflection' || routeKey === 'success_reflection')
        && (hydrated.orchestratorRules?.provider || hydrated.orchestratorRules?.model)) {
        return {
            provider: hydrated.orchestratorRules.provider ?? null,
            model: hydrated.orchestratorRules.model ?? null,
        };
    }
    return fallback ?? null;
}
export function materializeTaskTopology(task, liveTopology) {
    const metadata = task.metadata ?? {};
    const topologyId = toNullableString(metadata['topologyId']) ?? liveTopology?.id ?? null;
    const topologyName = toNullableString(metadata['topologyName']) ?? liveTopology?.name ?? null;
    const strategyTrack = metadata['topologyStrategyTrack'] === 'candidate' ? 'candidate' : 'stable';
    if (!topologyId && !topologyName && !liveTopology)
        return null;
    const snapshotOrchestratorRules = readTopologyOrchestratorRules(metadata['topologyOrchestratorRules'])
        ?? liveTopology?.orchestratorRules
        ?? null;
    const snapshotAdaptiveModelPolicy = parseAdaptiveModelPolicyInput(metadata['topologyAdaptiveModelPolicy'])
        ?? liveTopology?.adaptiveModelPolicy
        ?? null;
    const snapshotModelRoutes = parseTeamTopologyModelRoutes(metadata['topologyModelRoutes'])
        ?? liveTopology?.modelRoutes
        ?? null;
    const snapshotStrategyVersion = Number.isFinite(Number(metadata['topologyStrategyVersion']))
        ? Math.max(1, Math.floor(Number(metadata['topologyStrategyVersion'])))
        : (liveTopology?.strategyVersion ?? 1);
    const snapshotStrategyUpdatedAt = readStrategyUpdatedAt(metadata['topologyStrategyUpdatedAt'])
        ?? liveTopology?.strategyUpdatedAt
        ?? null;
    const snapshotStrategyHistory = parseTeamTopologyStrategyHistory(metadata['topologyStrategyHistory'])
        ?? (strategyTrack === 'candidate' ? null : (liveTopology?.strategyHistory ?? null))
        ?? null;
    const workerAgentIds = Array.isArray(metadata['topologyWorkerAgentIds'])
        ? metadata['topologyWorkerAgentIds']
            .filter((item) => typeof item === 'string' && item.trim().length > 0)
            .map((item) => item.trim())
        : (liveTopology?.workerAgentIds ?? []);
    const supervisorAgentId = toNullableString(metadata['topologySupervisorAgentId'])
        ?? liveTopology?.supervisorAgentId
        ?? null;
    const mergedMetadata = mergeTeamTopologyMetadata(liveTopology?.metadata, {
        orchestratorRules: snapshotOrchestratorRules,
        adaptiveModelPolicy: snapshotAdaptiveModelPolicy,
        modelRoutes: snapshotModelRoutes,
    });
    if (mergedMetadata) {
        mergedMetadata['strategyVersion'] = snapshotStrategyVersion;
        mergedMetadata['strategyUpdatedAt'] = snapshotStrategyUpdatedAt;
        if (snapshotStrategyHistory)
            mergedMetadata['strategyHistory'] = snapshotStrategyHistory;
    }
    return hydrateTeamTopology({
        id: topologyId ?? `task-topology:${task.id}`,
        workspaceId: task.workspaceId,
        name: topologyName ?? liveTopology?.name ?? `Task topology ${task.id}`,
        department: liveTopology?.department ?? null,
        role: liveTopology?.role ?? null,
        supervisorAgentId,
        workerAgentIds,
        defaultTemplateIds: liveTopology?.defaultTemplateIds ?? [],
        defaultHumanOwnerUserId: liveTopology?.defaultHumanOwnerUserId ?? task.humanOwnerUserId ?? null,
        orchestratorRules: snapshotOrchestratorRules,
        adaptiveModelPolicy: snapshotAdaptiveModelPolicy,
        modelRoutes: snapshotModelRoutes,
        strategyVersion: snapshotStrategyVersion,
        strategyUpdatedAt: snapshotStrategyUpdatedAt,
        strategyHistory: snapshotStrategyHistory,
        metadata: mergedMetadata,
        createdBy: liveTopology?.createdBy ?? task.createdBy,
        createdAt: liveTopology?.createdAt ?? task.createdAt,
        updatedAt: liveTopology?.updatedAt ?? task.updatedAt,
    });
}
//# sourceMappingURL=team_topology.js.map