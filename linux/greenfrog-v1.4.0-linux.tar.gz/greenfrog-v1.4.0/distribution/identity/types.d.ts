/**
 * Types for the GreenFrog child distribution identity system.
 */
/** Current enrollment/registration state of this instance. */
export type EnrollmentState = 'unregistered' | 'generating' | 'pending' | 'submitted' | 'enrolled' | 'failed';
/** Persisted at .greenfrog/identity/install.json */
export interface InstallRecord {
    installId: string;
    instanceId: string;
    enrollmentKey: string;
    platform: string;
    createdAt: string;
}
/** Persisted at .greenfrog/identity/state.json */
export interface EnrollmentStateRecord {
    state: EnrollmentState;
    updatedAt: string;
    failureReason?: string;
    attemptCount: number;
    lastAttemptAt?: string;
    enrolledAt?: string;
}
/** Persisted at .greenfrog/identity/credential.json */
export interface CredentialRecord {
    instanceId: string;
    jwt: string;
    issuedAt: string;
    expiresAt: string | null;
}
/** Payload sent to the mother-body during registration. */
export interface EnrollmentRequest {
    instanceId: string;
    enrollmentKey: string;
    platform: NodeJS.Platform;
    arch: string;
    nodeVersion: string;
    appVersion: string;
}
/** Response from the mother-body registration endpoint. */
export interface EnrollmentResponse {
    ok: boolean;
    jwt?: string;
    expiresAt?: string;
    error?: string;
}
//# sourceMappingURL=types.d.ts.map