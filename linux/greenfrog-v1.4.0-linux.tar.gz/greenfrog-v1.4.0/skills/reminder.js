import { BaseSkill } from './base.js';
import { setScopedMemoryForContext, getAllScopedMemoryForContext, getScopedMemoryForContext, deleteScopedMemoryForContext, } from '../memory/index.js';
import { nanoid } from 'nanoid';
/**
 * Parse common natural-language date expressions to a Date.
 * Returns null if the expression is unrecognisable.
 *
 * Supported:
 *   ISO 8601 / JS Date strings → new Date(s)
 *   "in X minutes/hours/days/weeks"
 *   "tomorrow [at HH:MM] [Xam/pm]" — defaults to 09:00
 *   "today at HH:MM [am/pm]"
 *   "HH:MM" or "H am/pm" — treated as today at that time
 */
function parseDueDate(s) {
    if (!s)
        return null;
    // Try direct ISO / JS parsing first
    const direct = new Date(s);
    if (!isNaN(direct.getTime()))
        return direct;
    const lower = s.toLowerCase().trim();
    const now = new Date();
    // "in X minutes/hours/days/weeks"
    const relMatch = lower.match(/in\s+(\d+)\s+(minute|hour|day|week)s?/);
    if (relMatch) {
        const n = parseInt(relMatch[1]);
        const units = {
            minute: 60_000, hour: 3_600_000, day: 86_400_000, week: 604_800_000,
        };
        const ms = units[relMatch[2]];
        if (ms)
            return new Date(now.getTime() + n * ms);
    }
    /** Extract HH:MM [am/pm] from a string, returning [hours, minutes] or null. */
    function extractTime(str) {
        const m = str.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
        if (!m)
            return null;
        let h = parseInt(m[1]);
        const min = parseInt(m[2] ?? '0');
        const ampm = m[3];
        if (ampm === 'pm' && h < 12)
            h += 12;
        if (ampm === 'am' && h === 12)
            h = 0;
        if (h > 23 || min > 59)
            return null;
        return [h, min];
    }
    if (lower.includes('tomorrow')) {
        const d = new Date(now);
        d.setDate(d.getDate() + 1);
        const t = extractTime(lower);
        if (t)
            d.setHours(t[0], t[1], 0, 0);
        else
            d.setHours(9, 0, 0, 0);
        return d;
    }
    if (lower.includes('today')) {
        const d = new Date(now);
        const t = extractTime(lower);
        if (t) {
            d.setHours(t[0], t[1], 0, 0);
            return d;
        }
    }
    // "9am", "14:30", "3 pm" — treat as today
    const t = extractTime(lower);
    if (t && lower.match(/^\d{1,2}(?::\d{2})?\s*(?:am|pm)?$/)) {
        const d = new Date(now);
        d.setHours(t[0], t[1], 0, 0);
        return d;
    }
    return null;
}
export class ReminderSkill extends BaseSkill {
    definition = {
        name: 'reminder',
        description: 'Create, list, and manage reminders. The platform will automatically deliver the reminder at the specified time.',
        category: 'productivity',
        parameters: [
            { name: 'action', type: 'string', required: true, description: 'Action', enum: ['create', 'list', 'done', 'delete'] },
            { name: 'text', type: 'string', description: 'Reminder text (for create)' },
            {
                name: 'due',
                type: 'string',
                description: 'When to remind. Examples: "2026-03-17 09:00", "in 2 hours", "tomorrow 9am", "today at 14:30". Use ISO 8601 when possible.',
            },
            { name: 'id', type: 'string', description: 'Reminder ID (for done/delete)' },
        ],
        examples: [
            'Remind me to take medicine in 30 minutes',
            'Set a reminder for tomorrow at 9am to check emails',
            'What reminders do I have?',
        ],
    };
    keyPrefix = 'reminder:';
    async execute(params, ctx) {
        const { userId, channel, chatId } = ctx;
        switch (params.action) {
            case 'create': {
                if (!params.text)
                    return this.err('text is required');
                const id = nanoid(8);
                const dueRaw = params.due ?? '';
                const dueDate = dueRaw ? parseDueDate(dueRaw) : null;
                const dueIso = dueDate ? dueDate.toISOString() : null;
                if (dueRaw && !dueDate) {
                    return this.err(`Could not understand the date: "${dueRaw}". ` +
                        `Try ISO format like "2026-03-17 09:00", or "in 2 hours", "tomorrow 9am".`);
                }
                const reminder = {
                    id,
                    text: params.text,
                    dueAt: dueIso,
                    dueAtRaw: dueRaw || 'no specific time',
                    createdAt: new Date().toISOString(),
                    done: false,
                    chatId,
                    userId,
                    channel,
                };
                await setScopedMemoryForContext(ctx, `${this.keyPrefix}${id}`, JSON.stringify(reminder));
                const dueDisplay = dueDate
                    ? dueDate.toLocaleString()
                    : (dueRaw || 'no specific time');
                return this.text(`⏰ **Reminder set!**\n` +
                    `**ID:** \`${id}\`\n` +
                    `**Text:** ${reminder.text}\n` +
                    `**Due:** ${dueDisplay}${dueDate ? '' : '\n⚠️ No auto-delivery — no parseable time given.'}`);
            }
            case 'list': {
                const all = await getAllScopedMemoryForContext(ctx);
                const reminders = Object.entries(all)
                    .filter(([k]) => k.startsWith(this.keyPrefix))
                    .map(([, v]) => {
                    try {
                        return JSON.parse(v);
                    }
                    catch {
                        return null;
                    }
                })
                    .filter((r) => r !== null && !r.done)
                    .sort((a, b) => {
                    if (!a.dueAt && !b.dueAt)
                        return 0;
                    if (!a.dueAt)
                        return 1;
                    if (!b.dueAt)
                        return -1;
                    return new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime();
                });
                if (reminders.length === 0)
                    return this.text('No active reminders.');
                const lines = reminders.map((r) => {
                    const due = r.dueAt
                        ? new Date(r.dueAt).toLocaleString()
                        : r.dueAtRaw;
                    return `⏰ \`${r.id}\` **${r.text}** — ${due}`;
                });
                return this.text(`**Your reminders (${reminders.length}):**\n\n${lines.join('\n')}`);
            }
            case 'done': {
                if (!params.id)
                    return this.err('id is required');
                const key = `${this.keyPrefix}${params.id}`;
                const raw = await getScopedMemoryForContext(ctx, key);
                if (!raw)
                    return this.err(`Reminder \`${params.id}\` not found`);
                const r = JSON.parse(raw);
                r.done = true;
                await setScopedMemoryForContext(ctx, key, JSON.stringify(r));
                return this.text(`✅ Reminder completed: **${r.text}**`);
            }
            case 'delete': {
                if (!params.id)
                    return this.err('id is required');
                const deleted = await deleteScopedMemoryForContext(ctx, `${this.keyPrefix}${params.id}`);
                return this.text(deleted ? `🗑 Reminder deleted` : `Reminder \`${params.id}\` not found`);
            }
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
}
//# sourceMappingURL=reminder.js.map