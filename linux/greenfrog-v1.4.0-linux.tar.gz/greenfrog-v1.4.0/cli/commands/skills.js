import chalk from 'chalk';
import { skillRegistry } from '../../skills/registry.js';
export async function listSkills(opts) {
    const byCategory = skillRegistry.listByCategory();
    const categories = opts.category
        ? { [opts.category]: byCategory[opts.category] ?? [] }
        : byCategory;
    console.log(chalk.bold(`\n🐸 GreenFrog Skills (${skillRegistry.list().length} total)\n`));
    for (const [category, skills] of Object.entries(categories)) {
        if (!skills?.length)
            continue;
        console.log(chalk.bold.cyan(`  ${category.toUpperCase()}`));
        for (const skill of skills) {
            const { name, description } = skill.definition;
            const params = skill.definition.parameters.filter((p) => p.required).map((p) => p.name);
            console.log(`  ${chalk.green('•')} ${chalk.bold(name)}: ${description}`);
            if (params.length > 0) {
                console.log(`    ${chalk.gray('Required: ' + params.join(', '))}`);
            }
        }
        console.log();
    }
}
//# sourceMappingURL=skills.js.map