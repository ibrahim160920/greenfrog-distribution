import OpenAI from 'openai';
import { randomUUID } from 'node:crypto';
import { BaseProvider } from './base.js';
import { ProviderError } from '../utils/errors.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('openai');
function normalizeOpenAIAuthMode(authMode) {
    if (authMode === 'apikey' || authMode === 'raw')
        return authMode;
    return 'bearer';
}
function resolveOpenAIAuth(authMode, authHeader, authScheme) {
    const mode = normalizeOpenAIAuthMode(authMode);
    const defaults = mode === 'apikey'
        ? { header: 'api-key', scheme: undefined }
        : mode === 'raw'
            ? { header: 'Authorization', scheme: undefined }
            : { header: 'Authorization', scheme: 'Bearer' };
    const header = authHeader?.trim() || defaults.header;
    const scheme = authScheme?.trim() || defaults.scheme;
    return { header, ...(scheme ? { scheme } : {}) };
}
function truncateForLog(text, maxLen = 600) {
    const normalized = text.replace(/\s+/g, ' ').trim();
    return normalized.length > maxLen
        ? `${normalized.slice(0, maxLen)}...`
        : normalized;
}
function getProviderErrorStatus(err) {
    const details = err.details;
    return typeof details?.status === 'number' ? details.status : undefined;
}
function isRetryableResponsesError(err) {
    if (!(err instanceof ProviderError))
        return false;
    const status = getProviderErrorStatus(err);
    if (typeof status === 'number' && (status >= 500 || status === 429))
        return true;
    const msg = err.message.toLowerCase();
    return msg.includes('could not parse your authentication token')
        || msg.includes('token_invalidated')
        || msg.includes('internal server error');
}
function sleep(ms) {
    if (ms <= 0)
        return Promise.resolve();
    return new Promise((resolve) => setTimeout(resolve, ms));
}
async function readResponseText(response) {
    try {
        const text = await response.text();
        return text ? truncateForLog(text) : undefined;
    }
    catch {
        return undefined;
    }
}
export function buildOpenAIAuthHeaders(apiKey, authMode, authHeader, authScheme) {
    const auth = resolveOpenAIAuth(authMode, authHeader, authScheme);
    return { [auth.header]: auth.scheme ? `${auth.scheme} ${apiKey}` : apiKey };
}
function normalizeOpenAIExtraHeaders(extraHeaders) {
    if (!extraHeaders)
        return {};
    return Object.fromEntries(Object.entries(extraHeaders)
        .filter(([key, value]) => key.trim().length > 0 && value.trim().length > 0)
        .map(([key, value]) => [key.trim(), value.trim()]));
}
class RelayAwareOpenAIClient extends OpenAI {
    relayAuthHeaders;
    constructor(opts, relayAuthHeaders) {
        super(opts);
        this.relayAuthHeaders = relayAuthHeaders;
    }
    authHeaders(_opts) {
        return this.relayAuthHeaders;
    }
}
export class OpenAIProvider extends BaseProvider {
    name = 'openai';
    defaultModel = 'codex-mini-latest'; // OpenAI Codex — primary model
    client;
    model;
    baseUrl;
    authHeaders;
    authMode;
    authHeaderName;
    authScheme;
    extraHeaders;
    sendClientRequestId;
    useResponsesApi;
    reasoningEffort;
    disableResponseStorage;
    responsesMaxAttempts;
    responsesRetryBaseDelayMs;
    constructor(apiKey, model, baseUrl, useResponsesApi, reasoningEffort, authMode, authHeader, authScheme, extraHeaders, sendClientRequestId, disableResponseStorage, responsesMaxAttempts, responsesRetryBaseDelayMs) {
        super();
        this.baseUrl = (baseUrl ?? 'https://api.openai.com/v1').replace(/\/$/, '');
        const resolvedAuth = resolveOpenAIAuth(authMode, authHeader, authScheme);
        this.authMode = normalizeOpenAIAuthMode(authMode);
        this.authHeaderName = resolvedAuth.header;
        this.authScheme = resolvedAuth.scheme;
        this.authHeaders = buildOpenAIAuthHeaders(apiKey, this.authMode, this.authHeaderName, this.authScheme);
        this.extraHeaders = normalizeOpenAIExtraHeaders(extraHeaders);
        this.sendClientRequestId = sendClientRequestId ?? false;
        this.client = new RelayAwareOpenAIClient({ apiKey, baseURL: baseUrl }, { ...this.authHeaders, ...this.extraHeaders });
        this.model = model ?? this.defaultModel;
        this.useResponsesApi = useResponsesApi ?? false;
        this.reasoningEffort = reasoningEffort;
        this.disableResponseStorage = disableResponseStorage ?? false;
        this.responsesMaxAttempts = Math.max(1, responsesMaxAttempts ?? 1);
        this.responsesRetryBaseDelayMs = Math.max(0, responsesRetryBaseDelayMs ?? 0);
    }
    getAuthDebugInfo() {
        return {
            mode: this.authMode,
            header: this.authHeaderName,
            ...(this.authScheme ? { scheme: this.authScheme } : {}),
            ...(Object.keys(this.extraHeaders).length > 0 ? { extraHeaders: Object.keys(this.extraHeaders) } : {}),
            ...(this.sendClientRequestId ? { autoClientRequestId: true } : {}),
        };
    }
    buildRequestHeaders() {
        const headers = {
            ...this.authHeaders,
            ...this.extraHeaders,
            Accept: 'text/event-stream',
        };
        if (this.sendClientRequestId && !headers['x-client-request-id']) {
            headers['x-client-request-id'] = randomUUID();
        }
        return headers;
    }
    async throwResponsesApiError(response, url, model) {
        const responseBody = await readResponseText(response);
        log.warn({
            endpoint: url,
            model,
            status: response.status,
            auth: this.getAuthDebugInfo(),
            responseBody,
        }, 'Responses API request failed');
        const detail = responseBody ? ` ${responseBody}` : ` ${response.statusText}`;
        throw new ProviderError(`Responses API error ${response.status}:${detail}`.trim(), { status: response.status });
    }
    async postResponsesFetch(url, body, model, signal) {
        let lastErr;
        for (let attempt = 1; attempt <= this.responsesMaxAttempts; attempt += 1) {
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { ...this.buildRequestHeaders(), 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ...body, stream: true }),
                    signal,
                });
                if (!response.ok) {
                    await this.throwResponsesApiError(response, url, model);
                }
                return response;
            }
            catch (err) {
                lastErr = err;
                if (!isRetryableResponsesError(err) || attempt >= this.responsesMaxAttempts) {
                    throw err;
                }
                const delayMs = this.responsesRetryBaseDelayMs * (2 ** (attempt - 1));
                log.warn({
                    endpoint: url,
                    model,
                    attempt,
                    nextAttempt: attempt + 1,
                    delayMs,
                }, 'Responses API request hit a transient relay failure, retrying');
                await sleep(delayMs);
            }
        }
        throw lastErr;
    }
    async consumeResponsesStream(stream, onText, toolCalls, rawOutputItems, onUsage) {
        if (!stream)
            return;
        const reader = stream.getReader();
        const decoder = new TextDecoder();
        let buf = '';
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            buf += decoder.decode(value, { stream: true });
            const lines = buf.split('\n');
            buf = lines.pop() ?? '';
            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed.startsWith('data:'))
                    continue;
                const raw = trimmed.slice(5).trim();
                if (raw === '[DONE]')
                    continue;
                try {
                    const ev = JSON.parse(raw);
                    this.applyResponsesEvent(ev, onText, toolCalls, rawOutputItems, onUsage);
                }
                catch {
                    // Ignore malformed SSE lines from the relay.
                }
            }
        }
        buf += decoder.decode();
        const finalLine = buf.trim();
        if (!finalLine.startsWith('data:'))
            return;
        const raw = finalLine.slice(5).trim();
        if (raw === '[DONE]')
            return;
        try {
            const ev = JSON.parse(raw);
            this.applyResponsesEvent(ev, onText, toolCalls, rawOutputItems, onUsage);
        }
        catch {
            // Ignore malformed trailing SSE chunk.
        }
    }
    async chat(request) {
        if (this.useResponsesApi) {
            return this.chatViaResponsesApi(request);
        }
        const model = request.model ?? this.model;
        const messages = this.buildMessages(request);
        const tools = this.buildTools(request);
        try {
            // Try streaming-to-collect first (required by some relay services)
            return await this.chatStreamInternal(model, messages, tools, request);
        }
        catch {
            // Fall back to non-streaming
            try {
                return await this.chatNonStream(model, messages, tools, request);
            }
            catch (err2) {
                if (err2 instanceof OpenAI.APIError) {
                    throw new ProviderError(`OpenAI API error: ${err2.message}`, { status: err2.status });
                }
                throw err2;
            }
        }
    }
    async chatViaResponsesApi(request) {
        const model = request.model ?? this.model;
        const input = this.buildInputForResponsesApi(request);
        const tools = this.buildToolsForResponsesApi(request);
        const body = { model, input };
        if (tools && tools.length > 0)
            body.tools = tools;
        if (this.reasoningEffort)
            body.reasoning = { effort: this.reasoningEffort };
        // capi.quan2go.com relay (号池中转) requires store:false to prevent
        // response data being saved under the pool's master OpenAI account.
        if (this.disableResponseStorage)
            body.store = false;
        // Retry without `reasoning` if the relay rejects that field.
        try {
            return await this.postResponsesApi(body, model, request.signal);
        }
        catch (err) {
            if (this.reasoningEffort && err instanceof ProviderError && getProviderErrorStatus(err) === 400) {
                log.warn({ endpoint: `${this.baseUrl}/responses`, model }, 'Responses API 400 — retrying without reasoning');
                const bodyNoReasoning = { ...body };
                delete bodyNoReasoning.reasoning;
                return await this.postResponsesApi(bodyNoReasoning, model, request.signal);
            }
            throw err;
        }
    }
    async postResponsesApi(body, model, signal) {
        // Relay requires stream:true — consume the SSE and collect everything
        const url = `${this.baseUrl}/responses`;
        log.info({
            endpoint: url,
            stream: true,
            model,
            reasoning: !!(body.reasoning),
            auth: this.getAuthDebugInfo(),
        }, 'Responses API request (non-streaming collect)');
        const res = await this.postResponsesFetch(url, body, model, signal);
        let content = '';
        const toolCalls = [];
        const rawOutputItems = [];
        let usage;
        await this.consumeResponsesStream(res.body, (t) => { content += t; }, toolCalls, rawOutputItems, (u) => { usage = u; });
        log.debug({ contentLen: content.length, toolCalls: toolCalls.length }, 'Responses API stream done');
        return {
            content,
            toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
            rawContent: toolCalls.length > 0 ? { _responsesApi: true, output: rawOutputItems } : undefined,
            usage: usage ? { inputTokens: usage.input_tokens, outputTokens: usage.output_tokens } : undefined,
            model,
        };
    }
    /** Parse a single Responses API SSE event and call the provided callbacks */
    applyResponsesEvent(ev, onText, toolCalls, rawOutputItems, onUsage) {
        const type = ev.type;
        if (type === 'response.output_text.delta') {
            if (typeof ev.delta === 'string')
                onText(ev.delta);
        }
        else if (type === 'response.output_item.done') {
            const item = ev.item;
            if (item?.type === 'function_call') {
                rawOutputItems.push(item);
                let args = {};
                try {
                    args = JSON.parse(item.arguments ?? '{}');
                }
                catch { /* empty */ }
                toolCalls.push({ id: (item.call_id ?? item.id ?? ''), name: (item.name ?? ''), arguments: args });
            }
        }
        else if (type === 'response.completed') {
            const resp = ev.response;
            const u = resp?.usage;
            if (u)
                onUsage(u);
        }
    }
    buildInputForResponsesApi(request) {
        const input = [];
        // capi.quan2go.com relay requires content as parts array, not plain string
        const textPart = (text) => [{ type: 'input_text', text }];
        if (request.systemPrompt) {
            input.push({ role: 'system', content: textPart(request.systemPrompt) });
        }
        for (const m of request.messages) {
            if (m.role === 'assistant' && m.rawContent) {
                const raw = m.rawContent;
                if (raw._responsesApi && raw.output) {
                    // Responses API: push stored output items directly (function_call items)
                    for (const item of raw.output)
                        input.push(item);
                    // Also push the assistant message text if any
                    if (m.content)
                        input.push({ role: 'assistant', content: m.content });
                    continue;
                }
                // Chat Completions rawContent — treat as plain assistant text
                input.push({ role: 'assistant', content: raw.content ?? m.content });
                continue;
            }
            if (m.toolResults && m.toolResults.length > 0) {
                for (const r of m.toolResults) {
                    input.push({ type: 'function_call_output', call_id: r.id, output: r.content });
                }
                continue;
            }
            if (m.imageAttachments && m.imageAttachments.length > 0) {
                const parts = m.imageAttachments.map((img) => ({
                    type: 'input_image',
                    image_url: `data:${img.mimeType};base64,${img.base64}`,
                }));
                if (m.content)
                    parts.push({ type: 'input_text', text: m.content });
                input.push({ role: 'user', content: parts });
            }
            else {
                input.push({ role: m.role, content: textPart(m.content) });
            }
        }
        return input;
    }
    buildToolsForResponsesApi(request) {
        return request.tools?.map((t) => ({
            type: 'function',
            name: t.name,
            description: t.description,
            parameters: t.parameters,
        }));
    }
    async chatNonStream(model, messages, tools, request) {
        const response = await this.client.chat.completions.create({
            model,
            messages,
            tools,
            max_tokens: request.maxTokens ?? 4096,
            temperature: request.temperature,
            stream: false,
        }, { signal: request.signal });
        const choice = response.choices[0];
        const msg = choice.message;
        const toolCalls = (msg.tool_calls ?? []).map((tc) => {
            let args = {};
            try {
                args = JSON.parse(tc.function.arguments);
            }
            catch { /* keep empty */ }
            return { id: tc.id, name: tc.function.name, arguments: args };
        });
        return {
            content: msg.content ?? '',
            toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
            // Preserve for threading on the next turn
            rawContent: msg.tool_calls
                ? { content: msg.content ?? null, tool_calls: msg.tool_calls }
                : undefined,
            usage: response.usage
                ? { inputTokens: response.usage.prompt_tokens, outputTokens: response.usage.completion_tokens }
                : undefined,
            model,
        };
    }
    async chatStreamInternal(model, messages, tools, request) {
        const stream = await this.client.chat.completions.create({
            model,
            messages,
            tools,
            max_tokens: request.maxTokens ?? 4096,
            temperature: request.temperature,
            stream: true,
        }, { signal: request.signal });
        let content = '';
        const toolCallMap = new Map();
        for await (const chunk of stream) {
            const delta = chunk.choices[0]?.delta;
            if (!delta)
                continue;
            if (delta.content)
                content += delta.content;
            for (const tc of delta.tool_calls ?? []) {
                const idx = tc.index;
                if (!toolCallMap.has(idx)) {
                    toolCallMap.set(idx, { id: tc.id ?? '', name: tc.function?.name ?? '', args: '' });
                }
                const entry = toolCallMap.get(idx);
                if (tc.id)
                    entry.id = tc.id;
                if (tc.function?.name)
                    entry.name = tc.function.name;
                if (tc.function?.arguments)
                    entry.args += tc.function.arguments;
            }
        }
        const toolCalls = [...toolCallMap.values()].map((tc) => {
            let args = {};
            try {
                if (tc.args)
                    args = JSON.parse(tc.args);
            }
            catch { /* keep empty */ }
            return { id: tc.id, name: tc.name, arguments: args };
        });
        // Reconstruct tool_calls array in OpenAI format for rawContent
        const rawToolCalls = toolCalls.length > 0
            ? toolCalls.map((tc) => ({
                id: tc.id,
                type: 'function',
                function: { name: tc.name, arguments: JSON.stringify(tc.arguments) },
            }))
            : undefined;
        return {
            content,
            toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
            rawContent: rawToolCalls ? { content: content || null, tool_calls: rawToolCalls } : undefined,
            model,
        };
    }
    chatStream(request) {
        if (this.useResponsesApi) {
            return this.chatStreamViaResponsesApi(request);
        }
        const model = request.model ?? this.model;
        const messages = this.buildMessages(request);
        const tools = this.buildTools(request);
        // Accumulate the full response while streaming text deltas
        let content = '';
        const toolCallMap = new Map();
        let streamDone = false;
        let streamError;
        // Create the stream promise once
        const streamPromise = this.client.chat.completions.create({
            model,
            messages,
            tools,
            max_tokens: request.maxTokens ?? 4096,
            temperature: request.temperature,
            stream: true,
        }, { signal: request.signal });
        // We need the same chunks for both textStream and complete().
        // Buffer all chunks so complete() can reconstruct the response.
        const chunks = [];
        async function* textStream() {
            try {
                const stream = await streamPromise;
                for await (const chunk of stream) {
                    chunks.push(chunk);
                    const delta = chunk.choices[0]?.delta;
                    if (delta?.content) {
                        content += delta.content;
                        yield delta.content;
                    }
                    // Accumulate tool calls
                    for (const tc of delta?.tool_calls ?? []) {
                        if (!toolCallMap.has(tc.index)) {
                            toolCallMap.set(tc.index, { id: tc.id ?? '', name: tc.function?.name ?? '', args: '' });
                        }
                        const entry = toolCallMap.get(tc.index);
                        if (tc.id)
                            entry.id = tc.id;
                        if (tc.function?.name)
                            entry.name = tc.function.name;
                        if (tc.function?.arguments)
                            entry.args += tc.function.arguments;
                    }
                }
                streamDone = true;
            }
            catch (err) {
                streamError = err;
                streamDone = true;
                throw err;
            }
        }
        const complete = async () => {
            // Drain textStream if not already consumed
            if (!streamDone) {
                for await (const _ of textStream()) { /* drain */ }
            }
            if (streamError)
                throw streamError;
            const toolCalls = [...toolCallMap.values()].map((tc) => {
                let args = {};
                try {
                    if (tc.args)
                        args = JSON.parse(tc.args);
                }
                catch { /* keep empty */ }
                return { id: tc.id, name: tc.name, arguments: args };
            });
            const rawToolCalls = toolCalls.length > 0
                ? toolCalls.map((tc) => ({
                    id: tc.id,
                    type: 'function',
                    function: { name: tc.name, arguments: JSON.stringify(tc.arguments) },
                }))
                : undefined;
            return {
                content,
                toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                rawContent: rawToolCalls ? { content: content || null, tool_calls: rawToolCalls } : undefined,
                model,
            };
        };
        return { textStream: textStream(), complete };
    }
    chatStreamViaResponsesApi(request) {
        const model = request.model ?? this.model;
        const input = this.buildInputForResponsesApi(request);
        const tools = this.buildToolsForResponsesApi(request);
        const body = { model, input };
        if (tools && tools.length > 0)
            body.tools = tools;
        if (this.reasoningEffort)
            body.reasoning = { effort: this.reasoningEffort };
        if (this.disableResponseStorage)
            body.store = false;
        const url = `${this.baseUrl}/responses`;
        let content = '';
        const toolCalls = [];
        const rawOutputItems = [];
        let usage;
        let streamDone = false;
        let streamError;
        // Token queue so textStream can yield tokens as they arrive
        const tokenQueue = [];
        const waiter = { resolve: null };
        const pushToken = (t) => { tokenQueue.push(t); waiter.resolve?.(); waiter.resolve = null; };
        const waitForToken = () => new Promise((r) => { waiter.resolve = r; });
        const self = this;
        const runStream = (async () => {
            const makeBody = (withReasoning) => {
                const b = { ...body, stream: true };
                if (!withReasoning)
                    delete b['reasoning'];
                return b;
            };
            try {
                log.info({
                    endpoint: url,
                    stream: true,
                    model,
                    reasoning: !!(body.reasoning),
                    auth: self.getAuthDebugInfo(),
                }, 'Responses API request (streaming)');
                let res;
                try {
                    res = await self.postResponsesFetch(url, body, model);
                }
                catch (err) {
                    if (err instanceof ProviderError && getProviderErrorStatus(err) === 400 && body.reasoning) {
                        log.warn({ endpoint: url, model }, 'Responses API 400 — retrying without reasoning');
                        res = await self.postResponsesFetch(url, makeBody(false), model);
                    }
                    else {
                        throw err;
                    }
                }
                await self.consumeResponsesStream(res.body, (t) => { content += t; pushToken(t); }, toolCalls, rawOutputItems, (u) => { usage = u; });
            }
            catch (err) {
                streamError = err;
            }
            finally {
                streamDone = true;
                waiter.resolve?.();
                waiter.resolve = null;
            }
        })();
        async function* textStream() {
            while (true) {
                while (tokenQueue.length > 0)
                    yield tokenQueue.shift();
                if (streamDone)
                    break;
                await waitForToken();
            }
            while (tokenQueue.length > 0)
                yield tokenQueue.shift(); // flush
            if (streamError)
                throw streamError;
        }
        const complete = async () => {
            await runStream;
            if (streamError)
                throw streamError;
            return {
                content,
                toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                rawContent: toolCalls.length > 0 ? { _responsesApi: true, output: rawOutputItems } : undefined,
                usage: usage ? { inputTokens: usage.input_tokens, outputTokens: usage.output_tokens } : undefined,
                model,
            };
        };
        return { textStream: textStream(), complete };
    }
    /** Shared message builder for chat() and chatStream() */
    buildMessages(request) {
        const messages = [];
        if (request.systemPrompt) {
            messages.push({ role: 'system', content: request.systemPrompt });
        }
        for (const m of request.messages) {
            if (m.role === 'assistant' && m.rawContent) {
                const raw = m.rawContent;
                messages.push({ role: 'assistant', content: raw.content ?? null, tool_calls: raw.tool_calls });
                continue;
            }
            if (m.toolResults && m.toolResults.length > 0) {
                for (const r of m.toolResults) {
                    messages.push({ role: 'tool', tool_call_id: r.id, content: r.content });
                }
                continue;
            }
            if (m.imageAttachments && m.imageAttachments.length > 0) {
                const parts = m.imageAttachments.map((img) => ({
                    type: 'image_url',
                    image_url: { url: `data:${img.mimeType};base64,${img.base64}` },
                }));
                if (m.content)
                    parts.push({ type: 'text', text: m.content });
                messages.push({ role: 'user', content: parts });
            }
            else {
                messages.push({ role: m.role, content: m.content });
            }
        }
        return messages;
    }
    /** Shared tool builder */
    buildTools(request) {
        return request.tools?.map((t) => ({
            type: 'function',
            function: { name: t.name, description: t.description, parameters: t.parameters },
        }));
    }
    async isAvailable() {
        try {
            await this.client.models.list();
            return true;
        }
        catch {
            return false;
        }
    }
    async listModels() {
        try {
            const res = await this.client.models.list();
            return res.data.map((m) => m.id);
        }
        catch {
            // Known OpenAI / Codex models as fallback
            return [
                'codex-mini-latest', // Codex — fast, cost-efficient
                'o4-mini', // o4-mini — reasoning
                'o3', // o3 — advanced reasoning
                'o3-mini', // o3-mini
                'gpt-4o', // GPT-4o
                'gpt-4o-mini', // GPT-4o mini
                'gpt-4.1', // GPT-4.1
                'gpt-4.1-mini', // GPT-4.1 mini
                'gpt-4.1-nano', // GPT-4.1 nano
            ];
        }
    }
}
//# sourceMappingURL=openai.js.map