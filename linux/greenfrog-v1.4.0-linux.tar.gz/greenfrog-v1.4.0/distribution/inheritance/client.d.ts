/**
 * client.ts — Inheritance pull client.
 *
 * Pull model: child polls the mother-body distribution server for inheritance
 * bundles. Only bundles tagged bundleType='mother_promoted' are accepted.
 *
 * Flow:
 *   1. GET /api/distribution/inheritance/latest → manifest
 *   2. Verify manifest signature (Ed25519)
 *   3. Check compatibility (semver constraint)
 *   4. Download bundle (URL from manifest)
 *   5. Verify bundle hash
 *   6. Archive current bundle as "previous" (for rollback)
 *   7. Apply: write to .greenfrog/inheritance/current.json
 */
export type InheritanceMode = 'stable' | 'security_only' | 'disabled';
interface InheritanceConfig {
    mode: InheritanceMode;
    lastAppliedVersion?: string;
    lastAppliedAt?: string;
}
export declare function readInheritanceConfig(baseDir?: string): InheritanceConfig;
export declare function writeInheritanceConfig(config: InheritanceConfig, baseDir?: string): void;
export declare function checkCompatibility(constraint: string, currentVersion: string): boolean;
export interface InheritancePullOptions {
    /** Base URL of the mother-body distribution server. */
    distributionUrl: string;
    /** Current app/capability version for compatibility check. */
    currentVersion: string;
    /** Override for .greenfrog root (used in tests). */
    baseDir?: string;
    /** Override for Ed25519 public key path (used in tests). */
    publicKeyPath?: string;
    /** Override fetch function (used in tests). */
    fetchFn?: (url: string, opts?: RequestInit) => Promise<Response>;
}
export interface InheritancePullResult {
    ok: boolean;
    applied?: boolean;
    version?: string;
    skippedReason?: string;
    error?: string;
}
/**
 * Pull and apply the latest inheritance bundle from the mother-body.
 * No-op if inheritance is disabled, already up to date, or not enrolled.
 */
export declare function pullInheritance(opts: InheritancePullOptions): Promise<InheritancePullResult>;
/**
 * Roll back to the previous inheritance bundle.
 * Returns false if no previous bundle exists.
 */
export declare function rollbackInheritance(baseDir?: string): boolean;
export {};
//# sourceMappingURL=client.d.ts.map