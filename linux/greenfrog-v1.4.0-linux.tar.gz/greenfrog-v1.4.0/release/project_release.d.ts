export interface ProjectReleaseConfig {
    enabled: boolean;
    repoPath: string;
    manifestPath: string;
    notesPath: string;
    bump: 'none' | 'patch' | 'minor' | 'major';
    autoCommit: boolean;
    autoPush: boolean;
    autoTag: boolean;
    createGithubRelease: boolean;
    remote: string;
    repo?: string;
    baseBranch: string;
    githubToken?: string;
    releaseTitle: string;
    branchPrefix: string;
    commitMessage: string;
    tagPrefix: string;
    approvalWindowStartHourUtc?: number;
    approvalWindowEndHourUtc?: number;
    approvedWeekdaysUtc?: number[];
    healthCheckCommands?: string[];
    minHealthChecksPassing?: number;
    respectAutomationPolicies?: boolean;
}
export interface ProjectReleaseResult {
    changed: boolean;
    currentVersion: string;
    nextVersion: string;
    manifestPath: string;
    notesPath: string;
    committed: boolean;
    pushed: boolean;
    tagged: boolean;
    branch: string | null;
    releaseUrl: string | null;
    releaseId: number | null;
    skippedReason: string | null;
}
export declare function generateProjectRelease(partial?: Partial<ProjectReleaseConfig>): Promise<ProjectReleaseResult>;
//# sourceMappingURL=project_release.d.ts.map