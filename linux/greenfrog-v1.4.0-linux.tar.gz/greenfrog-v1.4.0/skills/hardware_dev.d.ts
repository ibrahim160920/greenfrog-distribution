import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class HardwareDevSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private llm;
    private schematic;
    private pcbReview;
    private bom;
    private firmware;
    private datasheet;
    private debug;
}
//# sourceMappingURL=hardware_dev.d.ts.map