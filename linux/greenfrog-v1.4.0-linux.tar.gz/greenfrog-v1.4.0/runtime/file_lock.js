/**
 * OS-level file locking for SQLite database protection.
 * Uses exclusive file creation (O_EXCL) for cross-platform lock detection.
 */
import { open, close, writeFile, unlink, constants } from 'fs';
import { promisify } from 'util';
import { hostname } from 'os';
import { createLogger } from '../utils/logger.js';
const log = createLogger('file-lock');
const openAsync = promisify(open);
const closeAsync = promisify(close);
const writeFileAsync = promisify(writeFile);
const unlinkAsync = promisify(unlink);
export class FileLock {
    fd = null;
    lockPath;
    constructor(lockPath) {
        this.lockPath = lockPath;
    }
    /**
     * Acquire an exclusive lock on the file.
     * Throws if the lock is already held by another process.
     */
    async acquire() {
        if (this.fd !== null) {
            throw new Error('Lock already acquired by this process');
        }
        try {
            // Try to create lock file exclusively (fails if already exists)
            // O_CREAT | O_EXCL | O_RDWR = create new file, fail if exists
            this.fd = await openAsync(this.lockPath, constants.O_CREAT | constants.O_EXCL | constants.O_RDWR, 0o644);
            // Write PID to lock file for debugging
            const pidInfo = JSON.stringify({
                pid: process.pid,
                timestamp: Date.now(),
                hostname: hostname(),
            });
            await writeFileAsync(this.lockPath, pidInfo, 'utf8');
            log.info({ lockPath: this.lockPath, pid: process.pid }, 'File lock acquired');
        }
        catch (err) {
            // Clean up fd if lock acquisition failed
            if (this.fd !== null) {
                try {
                    await closeAsync(this.fd);
                }
                catch {
                    // Ignore close errors
                }
                this.fd = null;
            }
            // Check if lock file exists (EEXIST means another process holds the lock)
            if (err.code === 'EEXIST') {
                throw new Error(`Database is locked by another process. Lock file: ${this.lockPath}`);
            }
            throw err;
        }
    }
    /**
     * Release the lock and delete the lock file.
     */
    async release() {
        if (this.fd === null) {
            return; // Already released or never acquired
        }
        try {
            await closeAsync(this.fd);
            // Delete lock file after closing
            try {
                await unlinkAsync(this.lockPath);
            }
            catch (err) {
                // Ignore unlink errors (file might already be deleted)
                log.warn({ lockPath: this.lockPath, err }, 'Failed to delete lock file');
            }
            log.info({ lockPath: this.lockPath, pid: process.pid }, 'File lock released');
        }
        finally {
            this.fd = null;
        }
    }
    /**
     * Check if this instance currently holds the lock.
     */
    isHeld() {
        return this.fd !== null;
    }
}
/**
 * Global lock instance for SQLite database.
 * Should be acquired before opening the database.
 */
let globalSqliteLock = null;
export function getGlobalSqliteLock(lockPath) {
    if (!globalSqliteLock) {
        globalSqliteLock = new FileLock(lockPath);
    }
    return globalSqliteLock;
}
/**
 * Release global SQLite lock on process exit.
 */
export function setupLockCleanup() {
    const cleanup = async () => {
        if (globalSqliteLock?.isHeld()) {
            await globalSqliteLock.release();
        }
    };
    process.on('exit', () => {
        // Synchronous cleanup on exit
        if (globalSqliteLock?.isHeld()) {
            try {
                if (globalSqliteLock['fd'] !== null) {
                    close(globalSqliteLock['fd'], () => { });
                }
            }
            catch {
                // Ignore errors during exit
            }
        }
    });
    process.on('SIGINT', async () => {
        await cleanup();
        process.exit(130); // 128 + SIGINT(2)
    });
    process.on('SIGTERM', async () => {
        await cleanup();
        process.exit(143); // 128 + SIGTERM(15)
    });
}
//# sourceMappingURL=file_lock.js.map