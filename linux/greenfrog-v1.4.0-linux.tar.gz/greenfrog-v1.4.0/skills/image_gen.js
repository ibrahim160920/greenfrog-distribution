import { BaseSkill } from './base.js';
import { config } from '../config/index.js';
export class ImageGenSkill extends BaseSkill {
    definition = {
        name: 'generate_image',
        description: 'Generate images using AI. Free options: pollinations (default), stable_diffusion (local SD WebUI), flux (Together.ai free tier). Paid: dalle3 (requires OpenAI key).',
        category: 'creative',
        parameters: [
            { name: 'prompt', type: 'string', required: true, description: 'Image description/prompt' },
            { name: 'size', type: 'string', description: 'Image size', enum: ['256x256', '512x512', '1024x1024'], default: '512x512' },
            { name: 'model', type: 'string', description: 'Model: pollinations (free, default), stable_diffusion (local SD WebUI at localhost:7860), flux (Together.ai free), dalle3 (OpenAI key required)', enum: ['pollinations', 'stable_diffusion', 'flux', 'dalle3'], default: 'pollinations' },
        ],
    };
    async execute(params, _ctx) {
        const prompt = params.prompt;
        const model = params.model ?? 'pollinations';
        const size = params.size ?? '512x512';
        if (model === 'dalle3') {
            if (!config.providers.openai?.apiKey)
                return this.err('DALL-E requires an OpenAI API key. Use pollinations, stable_diffusion, or flux instead.');
            return this.generateDalle(prompt, size, config.providers.openai.apiKey);
        }
        if (model === 'stable_diffusion') {
            return this.generateStableDiffusion(prompt, size);
        }
        if (model === 'flux') {
            return this.generateFlux(prompt, size);
        }
        // Default: Pollinations.ai (free, no API key needed)
        return this.generatePollinations(prompt);
    }
    async generateDalle(prompt, size, apiKey) {
        try {
            const res = await fetch('https://api.openai.com/v1/images/generations', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    model: 'dall-e-3',
                    prompt,
                    n: 1,
                    size: size === '256x256' ? '1024x1024' : size,
                }),
                signal: AbortSignal.timeout(60_000),
            });
            if (!res.ok)
                return this.err(`DALL-E error: ${res.status}`);
            const data = await res.json();
            const url = data.data[0]?.url;
            if (!url)
                return this.err('DALL-E returned no image URL');
            return this.text(`🎨 **Generated image (DALL-E 3):**\n${url}\n\nPrompt: "${prompt}"`);
        }
        catch (err) {
            return this.err(`DALL-E error: ${String(err)}`);
        }
    }
    async generatePollinations(prompt) {
        const encoded = encodeURIComponent(prompt);
        const seed = Math.floor(Math.random() * 1_000_000);
        const url = `https://image.pollinations.ai/prompt/${encoded}?seed=${seed}&width=512&height=512&nologo=1`;
        // Verify the image actually generates (Pollinations can fail silently)
        try {
            const check = await fetch(url, {
                method: 'HEAD',
                signal: AbortSignal.timeout(20_000),
            });
            if (!check.ok) {
                return this.err(`Image generation failed (HTTP ${check.status}). Try a different prompt.`);
            }
            const contentType = check.headers.get('content-type') ?? '';
            if (!contentType.startsWith('image/')) {
                return this.err('Image generation returned an unexpected response. Try again or use a different prompt.');
            }
        }
        catch (err) {
            return this.err(`Could not verify image generation: ${String(err)}`);
        }
        return this.text(`🎨 **Generated image (Pollinations.ai):**\n${url}\n\nPrompt: "${prompt}"`);
    }
    async generateStableDiffusion(prompt, size) {
        const [width, height] = (size === '256x256') ? [512, 512] : size.split('x').map(Number);
        try {
            const res = await fetch('http://localhost:7860/sdapi/v1/txt2img', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt, steps: 20, width, height }),
                signal: AbortSignal.timeout(120_000),
            });
            if (!res.ok)
                return this.err(`Stable Diffusion WebUI error: ${res.status}. Make sure SD WebUI is running at localhost:7860 with --api flag.`);
            const data = await res.json();
            const b64 = data.images?.[0];
            if (!b64)
                return this.err('Stable Diffusion returned no image.');
            return this.text(`🎨 **Generated image (Stable Diffusion):**\ndata:image/png;base64,${b64}\n\nPrompt: "${prompt}"`);
        }
        catch (err) {
            return this.err(`Stable Diffusion error: ${String(err)}. Make sure SD WebUI is running at localhost:7860 with --api flag.`);
        }
    }
    async generateFlux(prompt, size) {
        const [width, height] = (size === '256x256') ? [512, 512] : size.split('x').map(Number);
        const apiKey = process.env.TOGETHER_API_KEY ?? '';
        try {
            const res = await fetch('https://api.together.xyz/v1/images/generations', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {}),
                },
                body: JSON.stringify({
                    model: 'black-forest-labs/FLUX.1-schnell-Free',
                    prompt,
                    width,
                    height,
                    steps: 4,
                    n: 1,
                }),
                signal: AbortSignal.timeout(60_000),
            });
            if (!res.ok) {
                const errText = await res.text();
                return this.err(`Flux (Together.ai) error: ${res.status} — ${errText}`);
            }
            const data = await res.json();
            const item = data.data?.[0];
            if (!item)
                return this.err('Flux returned no image.');
            const imgUrl = item.url ?? (item.b64_json ? `data:image/png;base64,${item.b64_json}` : '');
            if (!imgUrl)
                return this.err('Flux returned no image URL.');
            return this.text(`🎨 **Generated image (Flux / Together.ai):**\n${imgUrl}\n\nPrompt: "${prompt}"`);
        }
        catch (err) {
            return this.err(`Flux error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=image_gen.js.map