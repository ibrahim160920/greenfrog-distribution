import { BaseSkill } from './base.js';
// Safe math evaluator (no eval)
function safeMath(expr) {
    // Remove whitespace and validate characters
    const clean = expr.replace(/\s+/g, '');
    if (!/^[\d+\-*/().,%^sqrtabsceilflooroundpie]+$/.test(clean)) {
        throw new Error('Invalid expression characters');
    }
    // Replace math functions and constants
    const normalized = clean
        .replace(/sqrt\(/g, 'Math.sqrt(')
        .replace(/abs\(/g, 'Math.abs(')
        .replace(/ceil\(/g, 'Math.ceil(')
        .replace(/floor\(/g, 'Math.floor(')
        .replace(/round\(/g, 'Math.round(')
        .replace(/pi/g, 'Math.PI')
        .replace(/\^/g, '**')
        .replace(/%/g, '/100');
    // Use Function instead of eval (slightly safer, still sandboxed)
    // eslint-disable-next-line @typescript-eslint/no-implied-eval
    const fn = new Function('Math', `"use strict"; return (${normalized});`);
    return fn(Math);
}
export class CalculatorSkill extends BaseSkill {
    definition = {
        name: 'calculate',
        description: 'Evaluate mathematical expressions and calculations. Supports +, -, *, /, **, sqrt, abs, ceil, floor, round, pi',
        category: 'utilities',
        parameters: [
            { name: 'expression', type: 'string', description: 'Mathematical expression to evaluate (e.g. "2+2", "sqrt(16)", "100*1.07")', required: true },
        ],
        examples: ['Calculate 15% tip on $45', 'What is sqrt(144)?', '2^10'],
    };
    async execute(params, _ctx) {
        const expr = params.expression;
        try {
            const result = safeMath(expr);
            if (!isFinite(result)) {
                return this.err(`Result is not a finite number: ${result}`);
            }
            // Format nicely
            const formatted = Number.isInteger(result)
                ? result.toString()
                : result.toFixed(10).replace(/\.?0+$/, '');
            return this.text(`🧮 **${expr} = ${formatted}**`);
        }
        catch (err) {
            return this.err(`Calculation error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=calculator.js.map