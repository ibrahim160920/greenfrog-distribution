import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
import { createLogger } from '../utils/logger.js';
import { deriveSpecialistContext } from '../agents/identity.js';
const log = createLogger('multi_agent');
/**
 * Specialist agent definitions.
 * Each specialist has a focused system prompt and a curated set of tools.
 */
const SPECIALISTS = {
    researcher: {
        description: 'Deep research using web search, URL fetching, and synthesis',
        systemPrompt: `You are an expert research assistant. Your job is to find accurate, up-to-date information.
- Use web_search to find relevant information
- Use web_fetch to read specific pages in detail
- Synthesize information from multiple sources
- Always cite your sources
- Be thorough but concise in your summary`,
        tools: ['web_search', 'web_fetch', 'memory'],
    },
    coder: {
        description: 'Software development: write, read, run, and fix code',
        systemPrompt: `You are an expert software engineer. Your job is to write clean, working code.
- Always read files before modifying them
- Run tests after changes to verify correctness
- Use shell for build/test commands
- Provide a summary of every change made
- Handle edge cases and write idiomatic code`,
        tools: ['file_ops', 'shell', 'git', 'code_exec', 'web_search', 'web_fetch'],
    },
    analyst: {
        description: 'Data analysis, calculations, and structured reasoning',
        systemPrompt: `You are an expert data analyst and mathematician. Your job is to analyse data and reason rigorously.
- Use execute_code to run calculations and data transformations
- Present results clearly with supporting evidence
- Show your working step-by-step
- Draw precise, evidence-based conclusions`,
        tools: ['code_exec', 'file_ops', 'web_search'],
    },
    writer: {
        description: 'Creative writing, editing, summarisation, and translation',
        systemPrompt: `You are an expert writer and editor. Your job is to produce high-quality text.
- Write clearly, engagingly, and at the appropriate level
- Respect the requested format (markdown, plain text, etc.)
- Translate accurately, preserving tone and nuance
- Summarise concisely without losing key information`,
        tools: ['translate', 'memory'],
    },
    sysadmin: {
        description: 'System operations: file management, shell commands, process monitoring',
        systemPrompt: `You are an expert sysadmin. Your job is to manage the local system safely.
- Use shell commands conservatively — verify before destructive actions
- Monitor system resources and diagnose issues
- Manage files and directories efficiently
- Explain what each command does before running it`,
        tools: ['shell', 'file_ops', 'system_info', 'git'],
    },
};
function parseModelRoute(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return undefined;
    const record = value;
    const provider = typeof record['provider'] === 'string' && record['provider'].trim()
        ? record['provider'].trim()
        : undefined;
    const model = typeof record['model'] === 'string' && record['model'].trim()
        ? record['model'].trim()
        : undefined;
    if (!provider && !model)
        return undefined;
    return { ...(provider ? { provider } : {}), ...(model ? { model } : {}) };
}
function parseSpecialistRoutes(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return {};
    return Object.fromEntries(Object.entries(value)
        .map(([name, route]) => [name, parseModelRoute(route)])
        .filter((entry) => Boolean(entry[1])));
}
export class MultiAgentSkill extends BaseSkill {
    definition = {
        name: 'multi_agent',
        description: `Orchestrate multiple specialised AI sub-agents to solve complex tasks.
A supervisor decomposes the task, delegates to the best specialist(s), and synthesises the results.
Available specialists: ${Object.entries(SPECIALISTS).map(([k, v]) => `${k} (${v.description})`).join(', ')}.
Use this for tasks that benefit from specialised expertise or parallel sub-task execution.`,
        category: 'system',
        parameters: [
            {
                name: 'task',
                type: 'string',
                required: true,
                description: 'The overall task to accomplish',
            },
            {
                name: 'specialist',
                type: 'string',
                description: `Which specialist to use directly (${Object.keys(SPECIALISTS).join('|')}). Omit to let the supervisor choose.`,
                enum: [...Object.keys(SPECIALISTS), 'auto'],
                default: 'auto',
            },
            {
                name: 'context',
                type: 'string',
                description: 'Additional context or constraints',
            },
            {
                name: 'max_steps',
                type: 'number',
                description: 'Maximum tool-call steps per specialist (default 8, max 12)',
                default: 8,
            },
            {
                name: 'supervisor_provider',
                type: 'string',
                description: 'Provider for orchestration and synthesis',
            },
            {
                name: 'supervisor_model',
                type: 'string',
                description: 'Model for orchestration and synthesis',
            },
            {
                name: 'specialist_provider',
                type: 'string',
                description: 'Default provider for all specialist agents',
            },
            {
                name: 'specialist_model',
                type: 'string',
                description: 'Default model for all specialist agents',
            },
            {
                name: 'specialist_routes',
                type: 'object',
                description: 'Per-specialist provider/model map, e.g. {"researcher":{"provider":"ollama","model":"llama3.2"}}',
            },
        ],
    };
    async execute(params, ctx) {
        const task = params.task;
        const extraContext = params.context ?? '';
        const maxSteps = Math.min(Math.max(1, Number(params.max_steps ?? 8) || 8), 12);
        const specialistKey = params.specialist ?? 'auto';
        const supervisorRoute = parseModelRoute({
            provider: params.supervisor_provider,
            model: params.supervisor_model,
        });
        const defaultSpecialistRoute = parseModelRoute({
            provider: params.specialist_provider,
            model: params.specialist_model,
        });
        const specialistRoutes = parseSpecialistRoutes(params.specialist_routes);
        // ── Step 1: Route to the right specialist(s) ─────────────────────────────
        let assignments;
        if (specialistKey !== 'auto' && SPECIALISTS[specialistKey]) {
            assignments = [{ specialist: specialistKey, subtask: task }];
        }
        else {
            assignments = await this.supervisorRoute(task, extraContext, supervisorRoute);
        }
        // ── Step 2: Execute specialists in parallel ────────────────────────────────
        const routedPromises = assignments.map(({ specialist, subtask }) => {
            const spec = SPECIALISTS[specialist];
            if (!spec)
                return Promise.resolve({ specialist, output: '' });
            log.info({ specialist, subtask: subtask.slice(0, 60) }, 'Delegating to specialist');
            const specialistCtx = deriveSpecialistContext(ctx, specialist);
            const specialistRoute = specialistRoutes[specialist] ?? defaultSpecialistRoute;
            return this.runSpecialist(specialist, spec, subtask, extraContext, maxSteps, specialistCtx, specialistRoute)
                .then(output => ({ specialist, output }));
        });
        const settled = await Promise.allSettled(routedPromises);
        const results = settled
            .filter((r) => r.status === 'fulfilled')
            .map(r => r.value)
            .filter(r => r.output);
        // Log any failures
        for (const r of settled) {
            if (r.status === 'rejected') {
                log.warn({ error: String(r.reason) }, 'Specialist execution failed');
            }
        }
        // ── Step 3: Synthesise if multiple specialists ran ────────────────────────
        if (results.length === 1) {
            const r = results[0];
            return this.text(`**[${r.specialist}]**\n\n${r.output}`);
        }
        if (results.length > 1) {
            const synthesis = await this.synthesise(task, results, supervisorRoute);
            const details = results
                .map((r) => `**[${r.specialist}]**\n${r.output}`)
                .join('\n\n---\n\n');
            return this.text(`**Multi-Agent Result:**\n\n${synthesis}\n\n---\n\n**Individual Specialist Outputs:**\n\n${details}`);
        }
        return this.err('No specialist was able to handle this task.');
    }
    /** Ask the supervisor model which specialist(s) should handle the task. */
    async supervisorRoute(task, context, route) {
        const specList = Object.entries(SPECIALISTS)
            .map(([k, v]) => `- ${k}: ${v.description}`)
            .join('\n');
        const systemPrompt = `You are a task supervisor. Analyse the task and assign it to the best specialist(s).

Available specialists:
${specList}

Reply ONLY with a JSON array like:
[{"specialist":"<name>","subtask":"<focused description for this specialist>"}]

Rules:
- Use 1 specialist for simple focused tasks
- Use 2-3 specialists for complex tasks that span multiple domains
- Always use the specialist most suited to each subtask
- Keep subtask descriptions clear and focused`;
        const userMessage = `Task: ${task}${context ? `\n\nContext: ${context}` : ''}`;
        try {
            const response = await providerRegistry.chatWithFallback({
                messages: [{ role: 'user', content: userMessage }],
                systemPrompt,
                ...(route?.model ? { model: route.model } : {}),
                maxTokens: 512,
                temperature: 0,
            }, route?.provider);
            const jsonMatch = response.content.match(/\[[\s\S]*?\]/);
            if (jsonMatch) {
                const assignments = JSON.parse(jsonMatch[0]);
                // Validate and filter to known specialists
                return assignments
                    .filter((a) => SPECIALISTS[a.specialist])
                    .map((a) => ({ specialist: a.specialist, subtask: a.subtask || task }));
            }
        }
        catch {
            /* fall through to default */
        }
        // Default: researcher for general tasks, coder for code-related tasks
        const isCodeTask = /\b(code|function|bug|implement|fix|test|refactor|class|api)\b/i.test(task);
        return [{ specialist: isCodeTask ? 'coder' : 'researcher', subtask: task }];
    }
    /** Run a single specialist's agentic loop and return its output. */
    async runSpecialist(name, spec, task, context, maxSteps, ctx, route) {
        // Lazy load to avoid circular dependency
        const { skillRegistry } = await import('./registry.js');
        const tools = spec.tools
            .map((n) => skillRegistry.get(n)?.toProviderTool())
            .filter((t) => t != null);
        const messages = [
            {
                role: 'user',
                content: `Task: ${task}${context ? `\n\nAdditional context:\n${context}` : ''}\n\nPlease complete this task using your tools.`,
            },
        ];
        let finalOutput = '';
        for (let step = 0; step < maxSteps; step++) {
            const response = await providerRegistry.chatWithFallback({
                messages,
                tools,
                systemPrompt: spec.systemPrompt,
                ...(route?.model ? { model: route.model } : {}),
                maxTokens: 4096,
                temperature: 0.3,
            }, route?.provider);
            if (response.content)
                finalOutput = response.content;
            if (!response.toolCalls || response.toolCalls.length === 0)
                break;
            messages.push({
                role: 'assistant',
                content: response.content ?? '',
                rawContent: response.rawContent,
            });
            const toolResults = [];
            for (const toolCall of response.toolCalls) {
                const result = await skillRegistry.call(toolCall.name, toolCall.arguments, ctx);
                const resultText = result.text ?? (result.error ? `Error: ${result.error}` : JSON.stringify(result.data));
                toolResults.push({ id: toolCall.id, name: toolCall.name, content: resultText });
            }
            messages.push({ role: 'user', content: '', toolResults });
        }
        return finalOutput || `${name} completed the task.`;
    }
    /** Synthesise outputs from multiple specialists into a unified answer. */
    async synthesise(originalTask, results, route) {
        const summaries = results
            .map((r) => `[${r.specialist.toUpperCase()} SPECIALIST]\n${r.output}`)
            .join('\n\n');
        try {
            const response = await providerRegistry.chatWithFallback({
                messages: [
                    {
                        role: 'user',
                        content: `Original task: ${originalTask}\n\nSpecialist outputs:\n${summaries}\n\nPlease synthesise these outputs into a single coherent, concise answer that directly addresses the original task.`,
                    },
                ],
                systemPrompt: 'You are an expert synthesiser. Combine multiple specialist outputs into one clear, unified response. Remove redundancy. Highlight key findings.',
                ...(route?.model ? { model: route.model } : {}),
                maxTokens: 2048,
                temperature: 0.3,
            }, route?.provider);
            return response.content;
        }
        catch {
            return results.map((r) => `**${r.specialist}**: ${r.output}`).join('\n\n');
        }
    }
}
//# sourceMappingURL=multi_agent.js.map