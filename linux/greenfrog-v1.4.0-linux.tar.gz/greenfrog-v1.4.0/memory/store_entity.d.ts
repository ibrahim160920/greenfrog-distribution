import Database from 'better-sqlite3';
import type { ChannelName, Entity, EntityType, MemoryScope } from '../utils/types.js';
export declare function createEntityStore(db: Database.Database): {
    upsertEntity(userId: string, channel: ChannelName, entity: Omit<Entity, "id" | "userId" | "channel" | "mentionCount" | "lastMentioned" | "createdAt">): string;
    upsertScopedEntity(scope: MemoryScope, entity: Omit<Entity, "id" | "userId" | "channel" | "mentionCount" | "lastMentioned" | "createdAt">): string;
    getEntities(userId: string, channel: ChannelName, type?: EntityType): Entity[];
    getScopedEntities(scope: MemoryScope, type?: EntityType): Entity[];
    getEntity(userId: string, channel: ChannelName, name: string): Entity | null;
    getScopedEntity(scope: MemoryScope, name: string): Entity | null;
    searchEntities(userId: string, channel: ChannelName, query: string, limit?: number): Entity[];
    searchScopedEntities(scope: MemoryScope, query: string, limit?: number): Entity[];
    getRecentEntities(userId: string, channel: ChannelName, limit?: number): Entity[];
    getRecentScopedEntities(scope: MemoryScope, limit?: number): Entity[];
    getPendingTasks(userId: string, channel: ChannelName): Entity[];
    getPendingScopedTasks(scope: MemoryScope): Entity[];
    deleteEntity(userId: string, channel: ChannelName, name: string): boolean;
};
//# sourceMappingURL=store_entity.d.ts.map