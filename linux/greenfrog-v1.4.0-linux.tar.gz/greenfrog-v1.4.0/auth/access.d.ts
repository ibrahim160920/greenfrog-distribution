export interface ScopedAuthUser {
    sub: string;
    role: 'admin' | 'user' | 'readonly';
}
/**
 * Legacy Bearer-only mode does not attach a user identity. In that mode we
 * preserve backward compatibility by treating the caller as trusted.
 */
export declare function canAccessUserScope(authUser: ScopedAuthUser | undefined, targetUserId: string): boolean;
export declare function isAdminUser(authUser: ScopedAuthUser | undefined): boolean;
//# sourceMappingURL=access.d.ts.map