import { createLogger } from '../utils/logger.js';
export class BaseChannel {
    // Lazy logger: `this.name` is an abstract property and not available until
    // the subclass is fully constructed, so we defer logger creation.
    _log;
    get log() {
        if (!this._log)
            this._log = createLogger(`channel:${this.name}`);
        return this._log;
    }
    messageHandler = null;
    onMessage(handler) {
        this.messageHandler = handler;
    }
    async handleMessage(msg) {
        if (!this.messageHandler) {
            this.log.warn('No message handler registered');
            return;
        }
        try {
            const response = await this.messageHandler(msg);
            if (response.text) {
                await this.send(response);
            }
        }
        catch (err) {
            this.log.error({ err, msgId: msg.id }, 'Error handling message');
            await this.send({
                text: `⚠️ Error: ${String(err)}`,
                chatId: msg.chatId,
            }).catch(() => { });
        }
    }
}
//# sourceMappingURL=base.js.map