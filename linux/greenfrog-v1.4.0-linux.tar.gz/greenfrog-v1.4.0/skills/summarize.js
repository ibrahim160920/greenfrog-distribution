/**
 * Universal Summarizer
 *
 * Supported content sources:
 *  - Bilibili videos        (api.bilibili.com — title + subtitles)
 *  - YouTube videos         (youtube.com — captions/transcript)
 *  - WeChat articles        (mp.weixin.qq.com — cheerio #js_content)
 *  - Zhihu articles/answers (zhihu.com — RichContent)
 *  - arXiv papers           (export.arxiv.org API + ar5iv HTML)
 *  - DOI / Semantic Scholar (open-access PDF or metadata+abstract)
 *  - GitHub repos/issues/PRs/files (GitHub API + raw)
 *  - Hacker News            (Firebase API + top comments)
 *  - Wikipedia              (REST API summary + sections)
 *  - Medium articles        (medium.com — specific selectors)
 *  - Substack               (newsletter HTML + RSS fallback)
 *  - Chinese tech media     (36kr / 虎嗅 / 少数派 — targeted selectors)
 *  - RSS / Atom feeds       (auto-detected, items aggregated)
 *  - PDF files              (URL or local path — pdf-parse)
 *  - Local files            (.pdf / .txt / .md)
 *  - Any web page           (cheerio article-body extraction)
 *
 * Long content is chunked (≤5000 chars each) and summarised in parallel,
 * then synthesised into a final structured summary.
 */
import { createRequire } from 'module';
import { existsSync, readFileSync } from 'fs';
import { load as cheerioLoad } from 'cheerio';
import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
// pdf-parse is CJS — import via createRequire
const _require = createRequire(import.meta.url);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const pdfParse = _require('pdf-parse');
// ─────────────────────────────────────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────────────────────────────────────
const FETCH_TIMEOUT = 15_000;
const CHUNK_SIZE = 5_000; // chars per chunk
const MAX_CHUNKS = 20; // safety cap
const PARALLEL = 4; // concurrent LLM chunk calls
const HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
};
// ─────────────────────────────────────────────────────────────────────────────
// Skill definition
// ─────────────────────────────────────────────────────────────────────────────
export class SummarizeSkill extends BaseSkill {
    definition = {
        name: 'summarize',
        description: 'Summarize any content: Bilibili/YouTube video, WeChat/Medium/Substack article, ' +
            'arXiv/DOI paper, GitHub repo/issue/PR, Hacker News post, Wikipedia article, ' +
            'Zhihu article/answer, 36kr/虎嗅/少数派 article, RSS feed, PDF (URL or local path), ' +
            'or any web page. Returns title, core summary, key points, and conclusion.',
        category: 'information',
        parameters: [
            {
                name: 'url',
                type: 'string',
                required: true,
                description: 'URL or local file path to summarize. Supports: bilibili.com, youtube.com, ' +
                    'mp.weixin.qq.com, zhihu.com, arxiv.org, doi.org, github.com, ' +
                    'news.ycombinator.com, wikipedia.org, medium.com, substack.com, ' +
                    '36kr.com, huxiu.com, sspai.com, any RSS/Atom feed, .pdf URL, any webpage',
            },
            {
                name: 'style',
                type: 'string',
                description: 'Summary style: brief (3 points), bullets (5 points, default), detailed (8+ points with quotes)',
                enum: ['brief', 'bullets', 'detailed'],
                default: 'bullets',
            },
            {
                name: 'lang',
                type: 'string',
                description: 'Output language: zh (Chinese), en (English). Defaults to content language.',
            },
        ],
        examples: [
            '总结这个B站视频: https://www.bilibili.com/video/BV1xx...',
            '这个YouTube视频说了什么: https://www.youtube.com/watch?v=...',
            '帮我读这篇论文: https://arxiv.org/abs/2312.xxxxx',
            '这个GitHub仓库是做什么的: https://github.com/owner/repo',
            '这篇知乎文章的核心观点是什么: https://zhuanlan.zhihu.com/p/...',
            '总结HN这个帖子: https://news.ycombinator.com/item?id=...',
        ],
    };
    async execute(params, _ctx) {
        const url = (params.url ?? '').trim();
        const style = params.style || 'bullets';
        const lang = params.lang || '';
        if (!url)
            return this.err('url is required');
        try {
            const { title, text, source, meta } = await extractContent(url);
            if (!text || text.trim().length < 50) {
                return this.err(`Could not extract readable content from: ${url}`);
            }
            const summary = await summariseText(text, title, style, lang);
            const header = [
                `📋 **${title || 'Summary'}**`,
                meta ? `> ${meta}` : '',
                `*Source: ${source}  |  ~${Math.ceil(text.length / 500)} min read*`,
                '',
            ].filter((l) => l !== undefined).join('\n');
            return this.text(header + summary);
        }
        catch (err) {
            return this.err(`Summarize failed: ${String(err)}`);
        }
    }
}
async function extractContent(url) {
    // Local file
    if (!url.startsWith('http') && existsSync(url)) {
        return extractLocalFile(url);
    }
    const lower = url.toLowerCase();
    // Chinese video
    if (/bilibili\.com\/video\//.test(lower))
        return extractBilibili(url);
    // Western video
    if (/youtube\.com\/watch|youtu\.be\//.test(lower))
        return extractYouTube(url);
    // Chinese article platforms
    if (/mp\.weixin\.qq\.com/.test(lower))
        return extractWeChat(url);
    if (/zhihu\.com/.test(lower))
        return extractZhihu(url);
    if (/36kr\.com/.test(lower))
        return extractChinaTechMedia(url, '36氪');
    if (/huxiu\.com/.test(lower))
        return extractChinaTechMedia(url, '虎嗅');
    if (/sspai\.com/.test(lower))
        return extractChinaTechMedia(url, '少数派');
    // Academic
    if (/arxiv\.org/.test(lower))
        return extractArxiv(url);
    if (/doi\.org\/|semanticscholar\.org/.test(lower))
        return extractDOI(url);
    // Developer platforms
    if (/github\.com\//.test(lower))
        return extractGitHub(url);
    if (/news\.ycombinator\.com/.test(lower))
        return extractHackerNews(url);
    // Reference
    if (/wikipedia\.org/.test(lower))
        return extractWikipedia(url);
    // Western media
    if (/medium\.com\//.test(lower))
        return extractMedium(url);
    if (/\.substack\.com|substack\.com\/p\//.test(lower))
        return extractSubstack(url);
    // PDF
    if (lower.endsWith('.pdf') || lower.includes('.pdf?'))
        return extractPdfUrl(url);
    // Generic (also handles RSS/Atom auto-detection)
    return extractGenericUrl(url);
}
// ─────────────────────────────────────────────────────────────────────────────
// Extractors
// ─────────────────────────────────────────────────────────────────────────────
// ── Bilibili ──────────────────────────────────────────────────────────────────
async function extractBilibili(url) {
    const bvMatch = url.match(/BV[a-zA-Z0-9]+/);
    const avMatch = url.match(/av(\d+)/i);
    if (!bvMatch && !avMatch)
        throw new Error('Cannot parse Bilibili video ID from URL');
    const viewApi = bvMatch
        ? `https://api.bilibili.com/x/web-interface/view?bvid=${bvMatch[0]}`
        : `https://api.bilibili.com/x/web-interface/view?aid=${avMatch[1]}`;
    const viewRes = await fetch(viewApi, { headers: HEADERS, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
    if (!viewRes.ok)
        throw new Error(`Bilibili API error: ${viewRes.status}`);
    const view = await viewRes.json();
    if (view.code !== 0)
        throw new Error(`Bilibili API: code=${view.code}`);
    const d = view.data;
    const mins = Math.floor(d.duration / 60);
    const secs = d.duration % 60;
    const meta = `UP: ${d.owner.name} | 时长: ${mins}:${secs.toString().padStart(2, '0')}`;
    let subtitleText = '';
    try {
        const subApi = `https://api.bilibili.com/x/player/v2?bvid=${d.bvid}&cid=${d.cid}`;
        const subRes = await fetch(subApi, { headers: { ...HEADERS, Referer: url }, signal: AbortSignal.timeout(8_000) });
        if (subRes.ok) {
            const subData = await subRes.json();
            const subtitles = subData.data?.subtitle?.subtitles ?? [];
            const sub = subtitles.find((s) => s.lan.startsWith('zh')) ?? subtitles[0];
            if (sub?.subtitle_url) {
                const fileUrl = sub.subtitle_url.startsWith('//') ? 'https:' + sub.subtitle_url : sub.subtitle_url;
                const fileRes = await fetch(fileUrl, { signal: AbortSignal.timeout(8_000) });
                if (fileRes.ok) {
                    const fileData = await fileRes.json();
                    subtitleText = (fileData.body ?? []).map((b) => b.content).join(' ');
                }
            }
        }
    }
    catch { /* subtitles are best-effort */ }
    const text = subtitleText
        ? `[字幕内容]\n${subtitleText}`
        : `[视频描述]\n${d.desc || '（无描述）'}`;
    return { title: d.title, text, source: 'Bilibili', meta };
}
// ── YouTube ───────────────────────────────────────────────────────────────────
async function extractYouTube(url) {
    const idMatch = url.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    if (!idMatch)
        throw new Error('Cannot parse YouTube video ID from URL');
    const videoId = idMatch[1];
    const pageRes = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
        headers: HEADERS,
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!pageRes.ok)
        throw new Error(`YouTube fetch error: ${pageRes.status}`);
    const html = await pageRes.text();
    let title = '';
    let description = '';
    let channelName = '';
    let duration = '';
    let subtitleText = '';
    // Extract embedded player JSON
    const playerMatch = html.match(/ytInitialPlayerResponse\s*=\s*(\{.{50,}\});(?:\s*var |<\/script>)/s);
    if (playerMatch) {
        try {
            const player = JSON.parse(playerMatch[1]);
            title = player.videoDetails?.title ?? '';
            description = (player.videoDetails?.shortDescription ?? '').slice(0, 2000);
            channelName = player.videoDetails?.author ?? '';
            const lengthSec = parseInt(player.videoDetails?.lengthSeconds ?? '0', 10);
            if (lengthSec) {
                const m = Math.floor(lengthSec / 60);
                const s = lengthSec % 60;
                duration = `${m}:${s.toString().padStart(2, '0')}`;
            }
            // Fetch captions (prefer Chinese, then English, then first available)
            const tracks = player.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? [];
            const track = tracks.find((t) => t.languageCode?.startsWith('zh')) ??
                tracks.find((t) => t.languageCode?.startsWith('en')) ??
                tracks[0];
            if (track?.baseUrl) {
                try {
                    const capRes = await fetch(track.baseUrl + '&fmt=json3', {
                        headers: HEADERS, signal: AbortSignal.timeout(8_000),
                    });
                    if (capRes.ok) {
                        const capData = await capRes.json();
                        subtitleText = (capData.events ?? [])
                            .flatMap((e) => e.segs ?? [])
                            .map((s) => (s.utf8 ?? '').replace('\n', ' '))
                            .filter((s) => s.trim())
                            .join(' ');
                    }
                }
                catch { /* captions best-effort */ }
            }
        }
        catch { /* JSON parse error */ }
    }
    // Fallback title from og:title
    if (!title) {
        const $ = cheerioLoad(html);
        title = $('meta[property="og:title"]').attr('content') ?? $('title').text().trim() ?? `YouTube: ${videoId}`;
    }
    const meta = [
        channelName && `Channel: ${channelName}`,
        duration && `Duration: ${duration}`,
    ].filter(Boolean).join(' | ');
    const text = subtitleText
        ? `[Transcript]\n${subtitleText}`
        : `[Description]\n${description || '(no description)'}`;
    return { title: title || `YouTube: ${videoId}`, text, source: 'YouTube', meta: meta || undefined };
}
// ── WeChat article ─────────────────────────────────────────────────────────────
async function extractWeChat(url) {
    const res = await fetch(url, {
        headers: {
            ...HEADERS,
            Referer: 'https://mp.weixin.qq.com/',
            Accept: 'text/html,application/xhtml+xml,*/*',
        },
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!res.ok)
        throw new Error(`WeChat fetch failed: ${res.status}`);
    const html = await res.text();
    const $ = cheerioLoad(html);
    const title = $('#activity-name, .rich_media_title').first().text().trim()
        || $('title').text().trim().replace(' - 微信公众平台', '');
    const content = $('#js_content');
    content.find('script, style, .data_tips, .js_jump_icon').remove();
    const text = content.text().replace(/\s{3,}/g, '\n\n').trim();
    if (!text)
        throw new Error('Could not extract WeChat article content (may require login)');
    const author = $('.profile_nickname, #js_name').first().text().trim();
    return {
        title,
        text,
        source: '微信公众号',
        meta: author ? `作者: ${author}` : undefined,
    };
}
// ── Zhihu ─────────────────────────────────────────────────────────────────────
async function extractZhihu(url) {
    const res = await fetch(url, {
        headers: { ...HEADERS, Referer: 'https://www.zhihu.com/' },
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!res.ok)
        throw new Error(`Zhihu fetch failed: ${res.status}`);
    const html = await res.text();
    const $ = cheerioLoad(html);
    $('script, style').remove();
    const title = $('h1.QuestionHeader-title, h1.Post-Title, .ArticleItem-title').first().text().trim()
        || $('meta[property="og:title"]').attr('content')
        || $('title').text().trim();
    const author = $('.AuthorInfo-name, .UserLink-link').first().text().trim();
    let text = '';
    const contentEl = $('.RichContent-inner, .Post-RichTextContainer, .ArticleItem-content').first();
    if (contentEl.length && contentEl.text().trim().length > 100) {
        text = contentEl.text().replace(/\s{3,}/g, '\n\n').trim();
    }
    // Fallback: parse embedded JSON initialData
    if (!text) {
        const jsonMatch = html.match(/<script id="js-initialData" type="text\/json">(.+?)<\/script>/s);
        if (jsonMatch) {
            try {
                const data = JSON.parse(jsonMatch[1]);
                const entities = data?.initialState?.entities;
                const contentHtml = Object.values(entities?.answers ?? {})[0]?.content ??
                    Object.values(entities?.articles ?? {})[0]?.content ?? '';
                if (contentHtml)
                    text = cheerioLoad(contentHtml).text().trim();
            }
            catch { /* ignore */ }
        }
    }
    return {
        title: (title || '知乎').slice(0, 100),
        text: text.slice(0, 80_000),
        source: '知乎',
        meta: author ? `作者: ${author}` : undefined,
    };
}
// ── Chinese tech media (36kr / 虎嗅 / 少数派) ─────────────────────────────────
async function extractChinaTechMedia(url, siteName) {
    const res = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
    if (!res.ok)
        throw new Error(`${siteName} fetch failed: ${res.status}`);
    const html = await res.text();
    const $ = cheerioLoad(html);
    $('script, style, nav, header, footer, .ad, .recommend, .related').remove();
    const title = $('h1').first().text().trim()
        || $('meta[property="og:title"]').attr('content')
        || $('title').text().trim();
    const author = $('.author-name, .user-name, .article-author, [class*="author"]').first().text().trim();
    const date = $('time, .publish-time, .article-time, [class*="time"]').first().text().trim();
    // Try site-specific selectors
    const SITE_SELECTORS = {
        '36氪': ['.article-detail-content', '.articleDetailContent', '.content'],
        '虎嗅': ['.article-content', '.content-wrap', '.article-body'],
        '少数派': ['.article-body', '.post-content', '.content'],
    };
    const COMMON = ['article', 'main', '.article-content', '.content', '[class*="article"]', '[class*="content"]'];
    const selectors = [...(SITE_SELECTORS[siteName] ?? []), ...COMMON];
    let text = '';
    for (const sel of selectors) {
        const el = $(sel).first();
        if (el.length && el.text().trim().length > 300) {
            text = el.text().replace(/\s{3,}/g, '\n\n').trim();
            break;
        }
    }
    if (!text)
        text = $('body').text().replace(/\s{3,}/g, '\n\n').trim();
    const meta = [author, date].filter(Boolean).join(' | ');
    return {
        title: (title || siteName).slice(0, 100),
        text: text.slice(0, 80_000),
        source: siteName,
        meta: meta || undefined,
    };
}
// ── arXiv ─────────────────────────────────────────────────────────────────────
async function extractArxiv(url) {
    const idMatch = url.match(/arxiv\.org\/(?:abs|pdf|html)\/([0-9]{4}\.[0-9]+(?:v\d+)?)/);
    if (!idMatch)
        throw new Error('Cannot parse arXiv paper ID from URL');
    const paperId = idMatch[1];
    const apiRes = await fetch(`https://export.arxiv.org/api/query?id_list=${paperId}`, {
        headers: HEADERS, signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!apiRes.ok)
        throw new Error(`arXiv API error: ${apiRes.status}`);
    const xml = await apiRes.text();
    const $ = cheerioLoad(xml, { xmlMode: true });
    const title = $('entry > title').text().trim().replace(/\s+/g, ' ');
    const authors = $('author name').map((_, el) => $(el).text()).get().slice(0, 4).join(', ');
    const abstract = $('entry > summary').text().trim().replace(/\s+/g, ' ');
    const published = $('entry > published').text().slice(0, 10);
    let fullText = '';
    try {
        const htmlRes = await fetch(`https://ar5iv.org/html/${paperId}`, {
            headers: HEADERS, signal: AbortSignal.timeout(12_000),
        });
        if (htmlRes.ok) {
            const html = await htmlRes.text();
            const $h = cheerioLoad(html);
            $h('script, style, .ltx_bibliography, .ltx_appendix, figure, table').remove();
            const sections = [];
            $h('section.ltx_section, .ltx_abstract').each((_, el) => {
                const t = $h(el).text().replace(/\s{3,}/g, '\n\n').trim();
                if (t.length > 100)
                    sections.push(t);
            });
            fullText = sections.join('\n\n').slice(0, 60_000);
        }
    }
    catch { /* fallback to abstract */ }
    return {
        title: title || `arXiv:${paperId}`,
        text: fullText || abstract,
        source: 'arXiv',
        meta: `${authors}${published ? ' | ' + published : ''}`,
    };
}
// ── DOI / Semantic Scholar ─────────────────────────────────────────────────────
async function extractDOI(url) {
    const doiMatch = url.match(/(?:doi\.org\/|semanticscholar\.org\/paper\/[^/]+\/)?(10\.\d{4,}\/[^\s?#]+)/i)
        ?? url.match(/semanticscholar\.org\/paper\/([a-f0-9]{40})/i);
    // Semantic Scholar paper page (by hash ID)
    if (/semanticscholar\.org\/paper\//.test(url) && !doiMatch?.[1]?.startsWith('10.')) {
        const hashMatch = url.match(/paper\/[^/]+\/([a-f0-9]{40})/i);
        if (hashMatch)
            return extractSemanticScholarById(hashMatch[1]);
    }
    const doi = doiMatch?.[1];
    if (doi) {
        // Try Semantic Scholar API (free, open-access metadata)
        try {
            const ssRes = await fetch(`https://api.semanticscholar.org/graph/v1/paper/DOI:${encodeURIComponent(doi)}` +
                `?fields=title,authors,year,abstract,tldr,openAccessPdf`, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(10_000) });
            if (ssRes.ok) {
                const ss = await ssRes.json();
                const authors = (ss.authors ?? []).slice(0, 4).map((a) => a.name).join(', ');
                const meta = [authors, ss.year].filter(Boolean).join(' | ');
                let text = '';
                if (ss.openAccessPdf?.url) {
                    try {
                        const pdfRes = await fetch(ss.openAccessPdf.url, {
                            headers: HEADERS, signal: AbortSignal.timeout(30_000),
                        });
                        if (pdfRes.ok) {
                            const buf = Buffer.from(await pdfRes.arrayBuffer());
                            const parsed = await parsePdfBuffer(buf, doi);
                            text = parsed.text;
                        }
                    }
                    catch { /* use abstract */ }
                }
                if (!text) {
                    text = [ss.tldr?.text && `[TL;DR] ${ss.tldr.text}`, ss.abstract]
                        .filter(Boolean).join('\n\n');
                }
                if (text)
                    return { title: ss.title ?? `DOI:${doi}`, text, source: 'Semantic Scholar', meta };
            }
        }
        catch { /* try direct access */ }
        // Follow DOI redirect → try generic extraction
        try {
            const res = await fetch(`https://doi.org/${doi}`, {
                headers: { ...HEADERS, Accept: 'text/html' },
                signal: AbortSignal.timeout(FETCH_TIMEOUT),
                redirect: 'follow',
            });
            if (res.ok)
                return extractGenericUrl(res.url || url);
        }
        catch { /* ignore */ }
    }
    return extractGenericUrl(url);
}
async function extractSemanticScholarById(paperId) {
    const res = await fetch(`https://api.semanticscholar.org/graph/v1/paper/${paperId}` +
        `?fields=title,authors,year,abstract,tldr,openAccessPdf`, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(10_000) });
    if (!res.ok)
        throw new Error(`Semantic Scholar API error: ${res.status}`);
    const ss = await res.json();
    const authors = (ss.authors ?? []).slice(0, 4).map((a) => a.name).join(', ');
    const meta = [authors, ss.year].filter(Boolean).join(' | ');
    const text = [ss.tldr?.text && `[TL;DR] ${ss.tldr.text}`, ss.abstract]
        .filter(Boolean).join('\n\n');
    return { title: ss.title ?? `SS:${paperId}`, text: text || paperId, source: 'Semantic Scholar', meta };
}
// ── GitHub ─────────────────────────────────────────────────────────────────────
async function extractGitHub(url) {
    const parsed = new URL(url);
    const parts = parsed.pathname.split('/').filter(Boolean);
    const [owner, repo, type, ...rest] = parts;
    if (!owner || !repo)
        throw new Error('Invalid GitHub URL');
    const apiBase = 'https://api.github.com';
    const gh = { ...HEADERS, Accept: 'application/vnd.github.v3+json' };
    // Issue
    if (type === 'issues' && rest[0] && /^\d+$/.test(rest[0])) {
        const num = rest[0];
        const issueRes = await fetch(`${apiBase}/repos/${owner}/${repo}/issues/${num}`, {
            headers: gh, signal: AbortSignal.timeout(FETCH_TIMEOUT),
        });
        if (!issueRes.ok)
            throw new Error(`GitHub API ${issueRes.status}`);
        const issue = await issueRes.json();
        let commentsText = '';
        if (issue.comments > 0) {
            const cRes = await fetch(`${apiBase}/repos/${owner}/${repo}/issues/${num}/comments?per_page=15`, { headers: gh, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
            if (cRes.ok) {
                const comments = await cRes.json();
                commentsText = comments.slice(0, 10)
                    .map((c) => `**${c.user.login}**: ${c.body}`)
                    .join('\n\n');
            }
        }
        const text = [issue.body ?? '', commentsText].filter(Boolean).join('\n\n---\n\n');
        return {
            title: `[Issue #${num}] ${issue.title}`,
            text,
            source: 'GitHub',
            meta: `${issue.user.login} | ${issue.state} | ${issue.created_at.slice(0, 10)}`,
        };
    }
    // Pull request
    if (type === 'pull' && rest[0] && /^\d+$/.test(rest[0])) {
        const num = rest[0];
        const prRes = await fetch(`${apiBase}/repos/${owner}/${repo}/pulls/${num}`, {
            headers: gh, signal: AbortSignal.timeout(FETCH_TIMEOUT),
        });
        if (!prRes.ok)
            throw new Error(`GitHub API ${prRes.status}`);
        const pr = await prRes.json();
        const meta = `${pr.user.login} | ${pr.merged ? 'merged' : pr.state} | +${pr.additions}/-${pr.deletions} | ${pr.changed_files} files`;
        return {
            title: `[PR #${num}] ${pr.title}`,
            text: pr.body ?? '(no description)',
            source: 'GitHub',
            meta,
        };
    }
    // Blob / raw file
    if (type === 'blob' && rest.length >= 2) {
        const [branch, ...fileParts] = rest;
        const filePath = fileParts.join('/');
        const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${filePath}`;
        const rawRes = await fetch(rawUrl, { headers: HEADERS, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
        if (!rawRes.ok)
            throw new Error(`GitHub raw file ${rawRes.status}`);
        const text = await rawRes.text();
        return { title: filePath, text: text.slice(0, 80_000), source: 'GitHub' };
    }
    // Repository homepage — get metadata + README
    const repoRes = await fetch(`${apiBase}/repos/${owner}/${repo}`, {
        headers: gh, signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!repoRes.ok)
        throw new Error(`GitHub API ${repoRes.status}`);
    const repoData = await repoRes.json();
    const readmeRes = await fetch(`${apiBase}/repos/${owner}/${repo}/readme`, {
        headers: { ...gh, Accept: 'application/vnd.github.v3.raw' },
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    const readmeText = readmeRes.ok ? await readmeRes.text() : '';
    const meta = [
        `⭐ ${repoData.stargazers_count}`,
        repoData.language && `Language: ${repoData.language}`,
        `Forks: ${repoData.forks_count}`,
    ].filter(Boolean).join(' | ');
    const text = [
        repoData.description,
        repoData.topics?.length ? `Topics: ${repoData.topics.join(', ')}` : '',
        readmeText,
    ].filter(Boolean).join('\n\n').slice(0, 80_000);
    return { title: `${owner}/${repo}`, text, source: 'GitHub', meta };
}
// ── Hacker News ───────────────────────────────────────────────────────────────
async function extractHackerNews(url) {
    const idMatch = url.match(/[?&]id=(\d+)/);
    if (!idMatch)
        throw new Error('Cannot parse Hacker News item ID from URL');
    const id = idMatch[1];
    const res = await fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`, {
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!res.ok)
        throw new Error(`HN API error: ${res.status}`);
    const item = await res.json();
    const title = item.title || 'Hacker News';
    const date = new Date(item.time * 1000).toISOString().slice(0, 10);
    const meta = `by ${item.by} | ⬆️ ${item.score} | ${date}`;
    let articleText = item.text ? cheerioLoad(item.text).text() : '';
    // For link posts, also fetch the linked article
    if (item.url) {
        try {
            const linked = await extractGenericUrl(item.url);
            if (linked.text.length > 200) {
                articleText = [item.text && `[HN Post]\n${item.text}`, `[Linked Article]\n${linked.text}`]
                    .filter(Boolean).join('\n\n---\n\n');
            }
        }
        catch { /* use just the HN post text */ }
    }
    // Fetch top comments (parallel, up to 15)
    const commentIds = (item.kids ?? []).slice(0, 15);
    if (commentIds.length > 0) {
        const commentResults = await Promise.allSettled(commentIds.slice(0, 12).map(async (cid) => {
            const r = await fetch(`https://hacker-news.firebaseio.com/v0/item/${cid}.json`, {
                signal: AbortSignal.timeout(5_000),
            });
            if (!r.ok)
                return '';
            const c = await r.json();
            if (c.deleted || !c.text)
                return '';
            return `[${c.by ?? 'anon'}] ${cheerioLoad(c.text).text().trim()}`;
        }));
        const comments = commentResults
            .map((r) => r.status === 'fulfilled' ? r.value : '')
            .filter(Boolean);
        if (comments.length > 0) {
            articleText += '\n\n---\n[Top Comments]\n' + comments.join('\n\n');
        }
    }
    return { title, text: articleText || title, source: 'Hacker News', meta };
}
// ── Wikipedia ─────────────────────────────────────────────────────────────────
async function extractWikipedia(url) {
    // Detect language and article title from URL
    const match = url.match(/https?:\/\/([a-z]{2,3})\.wikipedia\.org\/wiki\/(.+)/);
    if (!match)
        throw new Error('Cannot parse Wikipedia URL');
    const lang = match[1];
    const title = decodeURIComponent(match[2].replace(/_/g, ' '));
    // Use Wikipedia REST API for summary
    const summaryRes = await fetch(`https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(match[2])}`, { headers: { Accept: 'application/json; charset=utf-8' }, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
    let summaryText = '';
    if (summaryRes.ok) {
        const summary = await summaryRes.json();
        summaryText = summary.extract ?? '';
    }
    // Also fetch the full article HTML for more content
    let fullText = summaryText;
    try {
        const htmlRes = await fetch(`https://${lang}.wikipedia.org/api/rest_v1/page/html/${encodeURIComponent(match[2])}`, { headers: { Accept: 'text/html; charset=utf-8' }, signal: AbortSignal.timeout(12_000) });
        if (htmlRes.ok) {
            const html = await htmlRes.text();
            const $ = cheerioLoad(html);
            $('script, style, .mw-editsection, .reference, .reflist, .navbox, figure').remove();
            const sections = [];
            $('section').each((_, el) => {
                const t = $(el).text().replace(/\s{3,}/g, '\n\n').trim();
                if (t.length > 100)
                    sections.push(t);
            });
            if (sections.length > 0)
                fullText = sections.join('\n\n').slice(0, 60_000);
        }
    }
    catch { /* use summary only */ }
    return {
        title,
        text: fullText || '(no content extracted)',
        source: `Wikipedia (${lang})`,
    };
}
// ── Medium ────────────────────────────────────────────────────────────────────
async function extractMedium(url) {
    const res = await fetch(url, {
        headers: { ...HEADERS, Accept: 'text/html,*/*' },
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!res.ok)
        throw new Error(`Medium fetch failed: ${res.status}`);
    const html = await res.text();
    const $ = cheerioLoad(html);
    $('script, style, nav, footer, .js-postShareWidget').remove();
    const title = $('h1').first().text().trim()
        || $('meta[property="og:title"]').attr('content')
        || $('title').text().trim();
    const author = $('[data-testid="authorName"], .pw-author-name').first().text().trim()
        || $('meta[name="author"]').attr('content');
    const pubDate = $('time').first().attr('datetime')?.slice(0, 10);
    // Medium article body
    let text = '';
    const articleEl = $('article').first();
    if (articleEl.length) {
        text = articleEl.text().replace(/\s{3,}/g, '\n\n').trim();
    }
    if (!text || text.length < 200) {
        // Fallback to og:description if content-gated
        const desc = $('meta[property="og:description"]').attr('content') ?? '';
        text = desc || $('body').text().replace(/\s{3,}/g, '\n\n').trim();
    }
    const meta = [author, pubDate].filter(Boolean).join(' | ');
    return {
        title: (title || 'Medium').slice(0, 100),
        text: text.slice(0, 80_000),
        source: 'Medium',
        meta: meta || undefined,
    };
}
// ── Substack ──────────────────────────────────────────────────────────────────
async function extractSubstack(url) {
    const res = await fetch(url, {
        headers: { ...HEADERS, Accept: 'text/html,*/*' },
        signal: AbortSignal.timeout(FETCH_TIMEOUT),
    });
    if (!res.ok)
        throw new Error(`Substack fetch failed: ${res.status}`);
    const html = await res.text();
    const $ = cheerioLoad(html);
    $('script, style, nav, footer, .subscribe-widget, .paywall').remove();
    const title = $('h1.post-title, h1').first().text().trim()
        || $('meta[property="og:title"]').attr('content')
        || $('title').text().trim();
    const author = $('.byline-names a, .author-name').first().text().trim()
        || $('meta[name="author"]').attr('content');
    const pubDate = $('time').first().attr('datetime')?.slice(0, 10);
    let text = '';
    const bodyEl = $('.body, .post-content, article').first();
    if (bodyEl.length) {
        text = bodyEl.text().replace(/\s{3,}/g, '\n\n').trim();
    }
    if (!text || text.length < 200) {
        // Try RSS fallback for the newsletter
        try {
            const rssUrl = url.replace(/\/p\/[^/]+.*/, '') + '/feed';
            const rssRes = await fetch(rssUrl, { headers: HEADERS, signal: AbortSignal.timeout(8_000) });
            if (rssRes.ok) {
                const rssXml = await rssRes.text();
                const $r = cheerioLoad(rssXml, { xmlMode: true });
                const firstItem = $r('item, entry').first();
                const content = firstItem.find('content\\:encoded, content, description').first().text();
                if (content)
                    text = cheerioLoad(content).text().trim();
            }
        }
        catch { /* ignore */ }
    }
    if (!text)
        text = $('body').text().replace(/\s{3,}/g, '\n\n').trim();
    const meta = [author, pubDate].filter(Boolean).join(' | ');
    return {
        title: (title || 'Substack').slice(0, 100),
        text: text.slice(0, 80_000),
        source: 'Substack',
        meta: meta || undefined,
    };
}
// ── PDF URL ───────────────────────────────────────────────────────────────────
async function extractPdfUrl(url) {
    const res = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(30_000) });
    if (!res.ok)
        throw new Error(`PDF fetch failed: ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    return parsePdfBuffer(buf, url);
}
// ── Local file ────────────────────────────────────────────────────────────────
async function extractLocalFile(filePath) {
    const lower = filePath.toLowerCase();
    if (lower.endsWith('.pdf')) {
        const buf = readFileSync(filePath);
        return parsePdfBuffer(buf, filePath);
    }
    const text = readFileSync(filePath, 'utf8');
    const title = text.split('\n').find((l) => l.trim())?.slice(0, 80) ?? filePath;
    return { title, text: text.slice(0, 100_000), source: 'Local file' };
}
async function parsePdfBuffer(buf, source) {
    const result = await pdfParse(buf);
    const pages = result.numpages;
    const title = result.info?.['Title']?.trim()
        || source.split('/').pop()?.replace('.pdf', '') || 'PDF Document';
    return {
        title,
        text: result.text.slice(0, 100_000),
        source: 'PDF',
        meta: `${pages} pages`,
    };
}
// ── Generic URL (also handles RSS/Atom) ───────────────────────────────────────
async function extractGenericUrl(url) {
    const res = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(FETCH_TIMEOUT) });
    if (!res.ok)
        throw new Error(`Fetch failed: ${res.status}`);
    const contentType = res.headers.get('content-type') ?? '';
    // PDF served with correct MIME
    if (contentType.includes('application/pdf')) {
        const buf = Buffer.from(await res.arrayBuffer());
        return parsePdfBuffer(buf, url);
    }
    const body = await res.text();
    // RSS / Atom feed detection
    if (contentType.includes('application/rss') ||
        contentType.includes('application/atom') ||
        contentType.includes('application/xml') ||
        contentType.includes('text/xml') ||
        body.trimStart().startsWith('<?xml') ||
        /<(rss|feed|rdf:RDF)[\s>]/.test(body.slice(0, 500))) {
        return extractRssFeed(body, url);
    }
    const $ = cheerioLoad(body);
    const title = $('meta[property="og:title"]').attr('content')
        || $('title').text().trim()
        || url;
    $('script, style, nav, header, footer, aside, .ad, .advertisement, .sidebar, .comment, .comments').remove();
    const SELECTORS = [
        'article', 'main', '[role="main"]',
        '.article-body', '.article-content', '.post-content', '.entry-content',
        '.content-body', '#content', '.main-content', '.rich_media_content',
        '[class*="article"]', '[class*="content"]',
    ];
    let text = '';
    for (const sel of SELECTORS) {
        const el = $(sel).first();
        if (el.length && el.text().trim().length > 300) {
            text = el.text().replace(/\s{3,}/g, '\n\n').trim();
            break;
        }
    }
    if (!text)
        text = $('body').text().replace(/\s{3,}/g, '\n\n').trim();
    return { title: title.slice(0, 100), text: text.slice(0, 80_000), source: new URL(url).hostname };
}
// ── RSS / Atom feed ───────────────────────────────────────────────────────────
function extractRssFeed(xml, feedUrl) {
    const $ = cheerioLoad(xml, { xmlMode: true });
    const feedTitle = $('channel > title, feed > title').first().text().trim()
        || new URL(feedUrl).hostname;
    // Collect items (up to 20)
    const items = [];
    $('item, entry').slice(0, 20).each((_, el) => {
        const $el = $(el);
        const itemTitle = $el.find('title').first().text().trim();
        const desc = $el.find('description, summary, content').first().text();
        const cleanDesc = cheerioLoad(desc).text().trim().slice(0, 500);
        const pubDate = $el.find('pubDate, published, updated').first().text().slice(0, 10);
        items.push(`### ${itemTitle}${pubDate ? ` (${pubDate})` : ''}\n${cleanDesc}`);
    });
    return {
        title: `${feedTitle} — RSS Feed`,
        text: items.join('\n\n'),
        source: 'RSS Feed',
        meta: `${items.length} items`,
    };
}
// ─────────────────────────────────────────────────────────────────────────────
// Summarisation engine (chunked LLM calls)
// ─────────────────────────────────────────────────────────────────────────────
function buildSummarisePrompt(content, style, lang) {
    const langInst = lang === 'zh' ? '用中文回答。' : lang === 'en' ? 'Respond in English.' : '';
    const points = style === 'brief' ? 3 : style === 'detailed' ? '7-10' : 5;
    const quoteInst = style === 'detailed' ? '\n- 引用1-2句原文中的关键表述（用 > 引用块）' : '';
    return (`${langInst}请对以下内容进行结构化总结，输出格式：\n\n` +
        `## 核心摘要\n（2-3句话，概括最重要的内容）\n\n` +
        `## 关键要点\n（${points}条，每条一行，用 - 开头）${quoteInst}\n\n` +
        `## 结论\n（1-2句，读完这篇内容最值得记住的东西）\n\n` +
        `---\n内容：\n\n${content}`);
}
function buildChunkPrompt(chunk, idx, total, lang) {
    const langInst = lang === 'zh' ? '用中文回答。' : lang === 'en' ? 'Respond in English.' : '';
    return (`${langInst}这是文档第 ${idx + 1}/${total} 段，请用3-5句话提炼本段核心内容，` +
        `保留重要数据、结论和关键观点：\n\n${chunk}`);
}
function buildSynthesisPrompt(chunkSummaries, title, style, lang) {
    const langInst = lang === 'zh' ? '用中文回答。' : lang === 'en' ? 'Respond in English.' : '';
    const points = style === 'brief' ? 3 : style === 'detailed' ? '7-10' : 5;
    const combined = chunkSummaries.map((s, i) => `[第${i + 1}部分]\n${s}`).join('\n\n');
    return (`${langInst}以下是《${title || '文档'}》各部分的摘要，请综合成一份完整的总结：\n\n` +
        `## 核心摘要\n（2-3句话，覆盖全文最重要的内容）\n\n` +
        `## 关键要点\n（${points}条）\n\n` +
        `## 结论\n（1-2句，读完这篇内容最值得记住的东西）\n\n` +
        `---\n各段摘要：\n\n${combined}`);
}
function splitIntoChunks(text, size) {
    const chunks = [];
    const paras = text.split(/\n{2,}/);
    let current = '';
    for (const para of paras) {
        if (current.length + para.length > size && current.length > 0) {
            chunks.push(current.trim());
            current = '';
        }
        current += para + '\n\n';
        while (current.length > size * 1.5) {
            chunks.push(current.slice(0, size).trim());
            current = current.slice(size);
        }
    }
    if (current.trim())
        chunks.push(current.trim());
    return chunks;
}
async function llmCall(prompt) {
    const res = await providerRegistry.chatWithFallback({
        messages: [{ role: 'user', content: prompt }],
        maxTokens: 800,
        temperature: 0.3,
    });
    return res.content ?? '';
}
async function summariseText(text, title, style, lang) {
    const clean = text.replace(/[ \t]{4,}/g, ' ').trim();
    if (clean.length <= CHUNK_SIZE) {
        return llmCall(buildSummarisePrompt(clean, style, lang));
    }
    const chunks = splitIntoChunks(clean, CHUNK_SIZE).slice(0, MAX_CHUNKS);
    const chunkSummaries = new Array(chunks.length).fill('');
    for (let i = 0; i < chunks.length; i += PARALLEL) {
        const batch = chunks.slice(i, i + PARALLEL);
        const results = await Promise.all(batch.map((chunk, j) => llmCall(buildChunkPrompt(chunk, i + j, chunks.length, lang))));
        results.forEach((r, j) => { chunkSummaries[i + j] = r; });
    }
    return llmCall(buildSynthesisPrompt(chunkSummaries, title, style, lang));
}
//# sourceMappingURL=summarize.js.map