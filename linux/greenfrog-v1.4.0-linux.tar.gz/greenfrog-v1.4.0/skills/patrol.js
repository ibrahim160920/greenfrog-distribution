/**
 * Patrol — 主动巡检技能
 *
 * 支持 HTTP 和 TCP 两种巡检类型：
 *   HTTP：检查状态码、响应时间、响应体关键词
 *   TCP ：检查端口是否可达
 *
 * 核心逻辑：
 *   - 每次 patrol runner 触发时，检查距上次巡检是否已超过 interval_min
 *   - 连续失败次数 >= alert_threshold 才推送告警（防止偶发抖动误报）
 *   - 服务恢复时自动推送恢复通知
 *   - 历史记录保留最近 100 条，供用户查询
 */
import * as net from 'net';
import { BaseSkill } from './base.js';
import { memoryStore } from '../memory/store.js';
export class PatrolSkill extends BaseSkill {
    definition = {
        name: 'patrol',
        description: '主动巡检：定时检查 HTTP 接口或 TCP 端口是否正常，异常时自动推送告警，恢复时推送恢复通知。' +
            '支持状态码检查、响应时间监控、关键词匹配、连续失败阈值（防抖）。',
        category: 'automation',
        parameters: [
            {
                name: 'action', type: 'string', required: true,
                description: '操作',
                enum: ['add', 'remove', 'list', 'check_now', 'pause', 'resume', 'history'],
            },
            { name: 'name', type: 'string', description: '巡检项名称（add 时必填）' },
            { name: 'type', type: 'string', description: '类型：http 或 tcp（默认 http）', enum: ['http', 'tcp'], default: 'http' },
            { name: 'target', type: 'string', description: 'HTTP URL 或 host:port（TCP）' },
            { name: 'interval', type: 'number', description: '检查间隔（分钟），默认 5' },
            { name: 'keyword', type: 'string', description: '响应体必须包含该关键词（HTTP 专用）' },
            { name: 'expected_status', type: 'number', description: '期望 HTTP 状态码（默认 200）' },
            { name: 'timeout', type: 'number', description: '超时毫秒数（默认 10000）' },
            { name: 'threshold', type: 'number', description: '连续失败几次才告警（默认 2，防止偶发抖动）' },
            { name: 'check_id', type: 'string', description: 'check ID（remove/pause/resume/history 时需要）' },
        ],
        examples: [
            '每5分钟检查我的网站 https://example.com 是否在线',
            '巡检 MySQL：TCP host=db.example.com:3306 每2分钟',
            '检查 API 返回包含 "status:ok" patrol add type=http keyword=status:ok',
        ],
    };
    async execute(params, ctx) {
        const { userId, channel, chatId } = ctx;
        const action = params.action;
        switch (action) {
            case 'add': return this.addCheck(params, userId, channel, chatId);
            case 'remove': return await this.removeCheck(params, userId);
            case 'list': return await this.listChecks(userId);
            case 'check_now': return this.checkNow(params, userId);
            case 'pause': return await this.setStatus(params, userId, 'paused');
            case 'resume': return await this.setStatus(params, userId, 'active');
            case 'history': return await this.showHistory(params, userId);
            default: return this.err(`未知操作: ${action}`);
        }
    }
    addCheck(params, userId, channel, chatId) {
        const name = (params.name ?? '').trim();
        const type = (params.type ?? 'http');
        const target = (params.target ?? '').trim();
        if (!name)
            return this.err('name 不能为空');
        if (!target)
            return this.err('target 不能为空（HTTP URL 或 host:port）');
        if (type === 'http' && !target.startsWith('http')) {
            return this.err('HTTP 类型的 target 必须以 http:// 或 https:// 开头');
        }
        const id = memoryStore.savePatrolCheck({
            name, type, target,
            intervalMin: typeof params.interval === 'number' ? params.interval : 5,
            expectedStatus: typeof params.expected_status === 'number' ? params.expected_status : (type === 'http' ? 200 : undefined),
            keyword: typeof params.keyword === 'string' ? params.keyword : undefined,
            method: 'GET',
            timeoutMs: typeof params.timeout === 'number' ? params.timeout : 10_000,
            alertThreshold: typeof params.threshold === 'number' ? params.threshold : 2,
            channel, chatId, userId, status: 'active',
        });
        return this.text(`✅ **巡检项已添加**\n\n` +
            `ID: \`${id}\`\n` +
            `名称: ${name}\n` +
            `类型: ${type.toUpperCase()}\n` +
            `目标: ${target}\n` +
            `间隔: 每 ${params.interval ?? 5} 分钟\n` +
            `告警阈值: 连续失败 ${params.threshold ?? 2} 次\n\n` +
            `巡检已启动，异常时会主动推送告警。`);
    }
    async removeCheck(params, userId) {
        const id = (params.check_id ?? '').trim();
        if (!id)
            return this.err('check_id 不能为空');
        const checks = await memoryStore.getPatrolChecks(userId);
        if (!checks.find((c) => c.id === id))
            return this.err(`未找到巡检项: ${id}`);
        await memoryStore.deletePatrolCheck(id);
        return this.text(`已删除巡检项: ${id}`);
    }
    async listChecks(userId) {
        const checks = await memoryStore.getPatrolChecks(userId);
        if (checks.length === 0) {
            return this.text('暂无巡检项。用 patrol add 添加一个。');
        }
        const statusIcon = (c) => c.status === 'paused' ? '⏸' :
            c.lastStatus === 'ok' ? '✅' :
                c.lastStatus === 'error' ? '❌' :
                    c.lastStatus === 'timeout' ? '⏱' : '⏳';
        const lines = checks.map((c) => `${statusIcon(c)} \`${c.id.slice(0, 8)}\` **${c.name}**\n` +
            `  ${c.type.toUpperCase()} ${c.target}\n` +
            `  间隔: ${c.intervalMin}min · 阈值: ${c.alertThreshold}次 · 连续失败: ${c.consecutiveFailures}\n` +
            `  上次检查: ${c.lastCheck ? c.lastCheck.toLocaleString() : '从未'}`);
        return this.text(`🔍 **巡检列表 (${checks.length})**\n\n${lines.join('\n\n')}`);
    }
    async checkNow(params, userId) {
        const id = (params.check_id ?? '').trim();
        if (!id)
            return this.err('check_id 不能为空');
        const checks = await memoryStore.getPatrolChecks(userId);
        const check = checks.find((c) => c.id === id);
        if (!check)
            return this.err(`未找到巡检项: ${id}`);
        const result = await runCheck(check);
        const icon = result.ok ? '✅' : (result.error?.includes('timeout') ? '⏱' : '❌');
        return this.text(`${icon} **立即检查结果**: ${check.name}\n\n` +
            `状态: ${result.ok ? '正常' : '异常'}\n` +
            (result.statusCode ? `HTTP状态码: ${result.statusCode}\n` : '') +
            `响应时间: ${result.latencyMs}ms\n` +
            (result.error ? `错误: ${result.error}` : ''));
    }
    async setStatus(params, userId, status) {
        const id = (params.check_id ?? '').trim();
        if (!id)
            return this.err('check_id 不能为空');
        const checks = await memoryStore.getPatrolChecks(userId);
        if (!checks.find((c) => c.id === id))
            return this.err(`未找到巡检项: ${id}`);
        await memoryStore.updatePatrolStatus(id, status);
        return this.text(`${status === 'paused' ? '⏸ 已暂停' : '▶️ 已恢复'}巡检: ${id}`);
    }
    async showHistory(params, userId) {
        const id = (params.check_id ?? '').trim();
        if (!id)
            return this.err('check_id 不能为空');
        const checks = await memoryStore.getPatrolChecks(userId);
        const check = checks.find((c) => c.id === id);
        if (!check)
            return this.err(`未找到巡检项: ${id}`);
        const history = await memoryStore.getPatrolHistory(id, 20);
        if (history.length === 0)
            return this.text('暂无检查记录');
        const lines = history.map((r) => `${r.ok ? '✅' : '❌'} ${r.checkedAt.toLocaleString()} · ${r.latencyMs}ms` +
            (r.statusCode ? ` · HTTP ${r.statusCode}` : '') +
            (r.error ? ` · ${r.error}` : ''));
        return this.text(`📋 **${check.name} 历史记录** (最近 ${history.length} 条)\n\n${lines.join('\n')}`);
    }
}
export async function runCheck(check) {
    const start = Date.now();
    if (check.type === 'tcp') {
        return runTcpCheck(check.target, check.timeoutMs, start);
    }
    // HTTP check
    try {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), check.timeoutMs);
        const res = await fetch(check.target, {
            method: check.method ?? 'GET',
            signal: ctrl.signal,
            headers: { 'User-Agent': 'GreenFrog-Patrol/1.0' },
        }).finally(() => clearTimeout(timer));
        const latencyMs = Date.now() - start;
        const expectedStatus = check.expectedStatus ?? 200;
        if (res.status !== expectedStatus) {
            return { ok: false, statusCode: res.status, latencyMs, error: `状态码 ${res.status}，期望 ${expectedStatus}` };
        }
        if (check.keyword) {
            const body = await res.text();
            if (!body.includes(check.keyword)) {
                return { ok: false, statusCode: res.status, latencyMs, error: `响应体未包含关键词: "${check.keyword}"` };
            }
        }
        return { ok: true, statusCode: res.status, latencyMs };
    }
    catch (err) {
        const latencyMs = Date.now() - start;
        const msg = String(err);
        if (msg.includes('abort') || msg.includes('timeout')) {
            return { ok: false, latencyMs, error: `timeout (>${check.timeoutMs}ms)` };
        }
        return { ok: false, latencyMs, error: msg.slice(0, 120) };
    }
}
function runTcpCheck(target, timeoutMs, start) {
    return new Promise((resolve) => {
        const [host, portStr] = target.includes(':') ? target.split(':') : [target, '80'];
        const port = parseInt(portStr ?? '80', 10);
        const socket = new net.Socket();
        const timer = setTimeout(() => {
            socket.destroy();
            resolve({ ok: false, latencyMs: Date.now() - start, error: `TCP timeout (>${timeoutMs}ms)` });
        }, timeoutMs);
        socket.connect(port, host, () => {
            clearTimeout(timer);
            socket.destroy();
            resolve({ ok: true, latencyMs: Date.now() - start });
        });
        socket.on('error', (err) => {
            clearTimeout(timer);
            resolve({ ok: false, latencyMs: Date.now() - start, error: err.message });
        });
    });
}
//# sourceMappingURL=patrol.js.map