/**
 * channel.ts — Mandatory backflow channel.
 *
 * Flushes the local backflow queue to the mother-body endpoint.
 * Uses exponential backoff on failure.
 * All data passes through the sanitizer before transmission.
 *
 * This channel is mandatory and cannot be disabled.
 * The optional "experience sharing" channel (controlled backflow) is a
 * separate concern handled by the same flush mechanism with a different
 * endpoint and an opt-in flag.
 */
import { createLogger } from '../../utils/logger.js';
import { sanitizeBatch } from './sanitizer.js';
import { enqueue, peekBatch, ackBatch, nackBatch } from './queue.js';
import { loadCredential } from '../identity/credential.js';
const log = createLogger('backflow-channel');
const BATCH_SIZE = 50;
/**
 * Enqueue raw data for backflow transmission.
 * Sanitizes the entry before queuing; silently drops if sanitization fails.
 */
export function recordBackflow(raw, baseDir) {
    const sanitized = sanitizeBatch([raw]);
    if (sanitized.length > 0) {
        enqueue(sanitized[0], baseDir);
    }
}
/**
 * Flush pending backflow entries to the mother-body.
 * Requires a valid credential (JWT). Skips silently if not enrolled.
 */
export async function flushBackflow(cfg) {
    const { backflowUrl, baseDir } = cfg;
    const fetchFn = cfg.fetchFn ?? globalThis.fetch;
    const credential = loadCredential(baseDir);
    if (!credential?.jwt) {
        log.debug('backflow-channel: no credential — skipping flush');
        return { ok: false, sent: 0, failed: 0, skippedReason: 'not enrolled' };
    }
    const batch = peekBatch(BATCH_SIZE, baseDir);
    if (batch.length === 0) {
        return { ok: true, sent: 0, failed: 0 };
    }
    const ids = batch.map(e => e.id);
    try {
        const response = await fetchFn(backflowUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${credential.jwt}`,
            },
            body: JSON.stringify({ entries: batch.map(e => e.data) }),
        });
        if (!response.ok) {
            nackBatch(ids, baseDir);
            log.warn({ status: response.status }, 'backflow-channel: flush failed');
            return { ok: false, sent: 0, failed: batch.length };
        }
        ackBatch(ids, baseDir);
        log.debug({ sent: batch.length }, 'backflow-channel: flush complete');
        return { ok: true, sent: batch.length, failed: 0 };
    }
    catch (err) {
        nackBatch(ids, baseDir);
        log.warn({ err: String(err) }, 'backflow-channel: flush threw');
        return { ok: false, sent: 0, failed: batch.length };
    }
}
//# sourceMappingURL=channel.js.map