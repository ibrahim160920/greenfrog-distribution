import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class WebChannel extends BaseChannel {
    readonly name: "web";
    private httpServer;
    private wss;
    private clients;
    private _running;
    start(): Promise<void>;
    stop(): Promise<void>;
    /**
     * Broadcast a message to ALL authenticated web clients.
     * Using stable chatId means any open browser tab will receive
     * scheduled job results, even after reconnection.
     */
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
}
//# sourceMappingURL=index.d.ts.map