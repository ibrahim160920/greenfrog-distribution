import { memoryStore } from './store.js';
export function resolveMemoryScope(ctx) {
    if (!ctx.workspaceId && !ctx.agentId)
        return null;
    return {
        userId: ctx.userId,
        channel: ctx.channel,
        workspaceId: ctx.workspaceId ?? null,
        agentId: ctx.agentId ?? null,
    };
}
export async function setScopedMemoryForContext(ctx, key, value, ttlDays) {
    const scope = resolveMemoryScope(ctx);
    if (!scope) {
        await memoryStore.setMemory(ctx.userId, ctx.channel, key, value, ttlDays);
        return;
    }
    await memoryStore.setScopedMemory(scope, key, value, ttlDays);
}
export async function getScopedMemoryForContext(ctx, key) {
    const scope = resolveMemoryScope(ctx);
    return scope
        ? memoryStore.getScopedMemory(scope, key)
        : memoryStore.getMemory(ctx.userId, ctx.channel, key);
}
export async function getAllScopedMemoryForContext(ctx) {
    const scope = resolveMemoryScope(ctx);
    return scope
        ? memoryStore.getAllScopedMemory(scope)
        : memoryStore.getAllMemory(ctx.userId, ctx.channel);
}
export async function deleteScopedMemoryForContext(ctx, key) {
    const scope = resolveMemoryScope(ctx);
    return scope
        ? memoryStore.deleteScopedMemory(scope, key)
        : memoryStore.deleteMemory(ctx.userId, ctx.channel, key);
}
export async function searchScopedMemoryForContext(ctx, query, limit = 10) {
    const scope = resolveMemoryScope(ctx);
    return scope
        ? memoryStore.searchScopedMemory(scope, query, limit)
        : memoryStore.searchMemory(ctx.userId, ctx.channel, query, limit);
}
export async function searchScopedSemanticForContext(ctx, query, limit = 5) {
    const scope = resolveMemoryScope(ctx);
    return scope
        ? memoryStore.searchScopedSemantic(scope, query, limit)
        : memoryStore.searchSemantic(ctx.userId, ctx.channel, query, limit);
}
export function buildLegacyScope(userId, channel) {
    return { userId, channel };
}
//# sourceMappingURL=scoped.js.map