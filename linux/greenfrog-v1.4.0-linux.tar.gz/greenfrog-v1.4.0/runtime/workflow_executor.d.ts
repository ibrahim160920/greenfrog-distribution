/**
 * Workflow executor registry.
 *
 * Solves the circular-dependency problem between workflow.ts (skill layer)
 * and index.ts (application bootstrap):
 *
 *   - workflow.ts needs to trigger executeWorkflow() on run_now
 *   - executeWorkflow() lives in index.ts (depends on runControlledAgentMessage,
 *     channelManager, etc. which are also in index.ts)
 *   - index.ts → skill layer is fine; skill layer → index.ts is circular
 *
 * Solution: index.ts registers the executor here at startup. workflow.ts
 * calls triggerWorkflowNow(), which delegates to the registered executor.
 * No circular dependency — this module has no imports from either layer.
 *
 * Registration must happen before any run_now call. If not registered
 * (e.g. in tests), triggerWorkflowNow() still creates the run record
 * but logs a warning and skips actual execution.
 */
import { type WorkflowRunRecord } from './run_records.js';
import type { WorkflowDef } from '../utils/types.js';
/** Real executor function: runs all steps, writes run record, returns when done. */
export type WorkflowExecutorFn = (wf: WorkflowDef, runId: string) => Promise<void>;
/** Called by index.ts at startup to provide the real executeWorkflow logic. */
export declare function registerWorkflowExecutor(fn: WorkflowExecutorFn): void;
/** Exposed for tests that need to verify an executor was registered. */
export declare function getWorkflowExecutor(): WorkflowExecutorFn | null;
/**
 * Trigger a workflow to execute immediately (fire-and-forget).
 *
 * Creates a run record synchronously (so callers can return the runId
 * to the user immediately), then starts execution asynchronously.
 *
 * Returns the run record. Execution errors are caught internally and
 * written to the run record.
 */
export declare function triggerWorkflowNow(wf: WorkflowDef): WorkflowRunRecord;
//# sourceMappingURL=workflow_executor.d.ts.map