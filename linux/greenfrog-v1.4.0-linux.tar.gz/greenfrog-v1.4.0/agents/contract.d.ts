/**
 * Task Contract layer for GreenFrog P4.
 *
 * A TaskContract is a structured, immutable description of what a task
 * must accomplish and under what constraints. It is derived once at
 * dispatch time from the existing task record (no DB migration needed).
 *
 * The contract shapes:
 *   - The worker prompt (objective + done criteria injected)
 *   - The recovery policy (retryPolicy drives retry logic)
 *   - Evaluation (doneCriteria evaluated post-execution)
 */
import type { TeamTask } from '../utils/types.js';
import type { AcceptanceCheck } from './acceptance.js';
export type { AcceptanceCheck };
export interface RetryPolicy {
    maxAttempts: number;
    /** ms to wait before retry (0 = immediate) */
    retryDelayMs: number;
    /** Which error classes are retryable */
    retryOn: ErrorClass[];
}
export type ErrorClass = 'provider_error' | 'tool_error' | 'context_missing' | 'environment_issue' | 'unclear_goal' | 'quality_insufficient' | 'unknown';
export interface TaskContract {
    taskId: string;
    /** What the task must accomplish (human-readable sentence) */
    objective: string;
    /**
     * Criteria that must be true for the task to be considered done.
     * Empty array = agent decides completion (status=done is sufficient).
     */
    doneCriteria: string[];
    /** Hard constraints the agent must not violate */
    constraints: string[];
    /** Named inputs passed to the task */
    inputs: Record<string, unknown>;
    /** Which tool names the agent is allowed to call (empty = no restriction) */
    allowedTools: string[];
    /** How to handle failures */
    retryPolicy: RetryPolicy;
    /**
     * P4.3: Structured acceptance checks evaluated before text heuristics.
     * Empty = text heuristics only (existing behaviour).
     */
    acceptanceChecks: AcceptanceCheck[];
    /**
     * P4.3: Recovery semantics for interrupted/retried runs.
     *   restartable — start fresh, don't assume prior ops succeeded (default)
     *   resumable   — prior partial work can be continued
     */
    recoveryMode: 'restartable' | 'resumable';
    /** Source context: workflow step, manual, scheduled job, etc. */
    source: string;
    /** ISO timestamp when this contract was built */
    builtAt: string;
}
/**
 * Derive a TaskContract from an existing TeamTask.
 * This is a pure function — no I/O, no DB access.
 */
export declare function buildTaskContract(task: TeamTask): TaskContract;
/**
 * Render a contract into the structured section of a worker prompt.
 * Returns a multi-line string to be injected into the prompt.
 */
export declare function renderContractPrompt(contract: TaskContract): string;
//# sourceMappingURL=contract.d.ts.map