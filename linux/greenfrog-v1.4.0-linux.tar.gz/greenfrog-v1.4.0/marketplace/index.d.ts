/**
 * Plugin Marketplace - MVP implementation
 * Provides a curated list of community plugins that can be installed
 */
export interface MarketplacePlugin {
    id: string;
    name: string;
    description: string;
    author: string;
    version: string;
    category: string;
    tags: string[];
    sourceUrl: string;
    installSize: number;
    downloads: number;
    createdAt: string;
    updatedAt: string;
}
/**
 * Curated marketplace plugins (MVP: hardcoded list)
 * In production, this would come from a database or external API
 */
export declare const MARKETPLACE_PLUGINS: MarketplacePlugin[];
/**
 * Get all marketplace plugins
 */
export declare function getMarketplacePlugins(): MarketplacePlugin[];
/**
 * Get a specific plugin by ID
 */
export declare function getMarketplacePlugin(id: string): MarketplacePlugin | null;
/**
 * Search plugins by query (name, description, tags)
 */
export declare function searchMarketplacePlugins(query: string): MarketplacePlugin[];
/**
 * Filter plugins by category
 */
export declare function getPluginsByCategory(category: string): MarketplacePlugin[];
/**
 * Get all unique categories
 */
export declare function getCategories(): string[];
//# sourceMappingURL=index.d.ts.map