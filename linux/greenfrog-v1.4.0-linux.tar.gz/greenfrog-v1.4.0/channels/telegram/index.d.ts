import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class TelegramChannel extends BaseChannel {
    readonly name: "telegram";
    private bot;
    private _running;
    private _token;
    private _reconnectTimer;
    private _reconnectAttempts;
    private static readonly MAX_RECONNECT_DELAY_MS;
    start(): Promise<void>;
    private connect;
    private scheduleReconnect;
    stop(): Promise<void>;
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
    private splitMessage;
}
//# sourceMappingURL=index.d.ts.map