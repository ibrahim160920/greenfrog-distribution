import type { IncomingMessage, OutgoingMessage, ChannelName } from '../utils/types.js';
export declare abstract class BaseChannel {
    abstract readonly name: ChannelName;
    private _log;
    protected get log(): import("pino").Logger<never, boolean>;
    protected messageHandler: ((msg: IncomingMessage) => Promise<OutgoingMessage>) | null;
    abstract start(): Promise<void>;
    abstract stop(): Promise<void>;
    abstract send(message: OutgoingMessage): Promise<void>;
    abstract isRunning(): boolean;
    onMessage(handler: (msg: IncomingMessage) => Promise<OutgoingMessage>): void;
    protected handleMessage(msg: IncomingMessage): Promise<void>;
}
//# sourceMappingURL=base.d.ts.map