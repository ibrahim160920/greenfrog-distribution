import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class DingTalkChannel extends BaseChannel {
    readonly name: "dingtalk";
    private dwClient;
    private _running;
    private _reconnectTimer;
    private _reconnectAttempts;
    private static readonly MAX_RECONNECT_DELAY_MS;
    private readonly webhookCache;
    start(): Promise<void>;
    private connect;
    private handleRobotMessage;
    private scheduleReconnect;
    stop(): Promise<void>;
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
    private splitMessage;
}
//# sourceMappingURL=index.d.ts.map