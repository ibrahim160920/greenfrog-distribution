export type CodeRepoGateProfile = 'strict' | 'balanced' | 'aggressive' | 'custom';
export type ResolvedCodeRepoGateBaseProfile = Exclude<CodeRepoGateProfile, 'custom'>;
export type CodeRepoGatePolicySource = 'default' | 'named-profile' | 'custom-profile' | 'profile+overrides';
export interface CodeRepoGateThresholds {
    minDecisionScore: number;
    minValidationCount: number;
    minSuccessRate: number;
}
export interface CodeRepoGateConfigInput {
    gateProfile?: CodeRepoGateProfile;
    minDecisionScore?: number;
    minValidationCount?: number;
    minSuccessRate?: number;
}
export interface ResolvedCodeRepoGateConfig {
    requestedProfile: CodeRepoGateProfile;
    effectiveProfile: CodeRepoGateProfile;
    baseProfile: ResolvedCodeRepoGateBaseProfile;
    source: CodeRepoGatePolicySource;
    hasExplicitOverrides: boolean;
    thresholds: CodeRepoGateThresholds;
}
export declare function resolveCodeRepoGateConfig(input?: CodeRepoGateConfigInput | null): ResolvedCodeRepoGateConfig;
//# sourceMappingURL=code_repo_gate_profile.d.ts.map