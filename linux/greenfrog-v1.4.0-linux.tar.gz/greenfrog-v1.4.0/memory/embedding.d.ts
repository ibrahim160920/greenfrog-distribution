export type EmbeddingRuntimeMode = 'uninitialized' | 'ollama' | 'openai' | 'local_hash';
export declare function getEmbeddingRuntimeOverview(): {
    mode: EmbeddingRuntimeMode;
    degraded: boolean;
    ollamaSuccesses: number;
    openaiSuccesses: number;
    localHashFallbacks: number;
    lastSuccessAt: string | null;
    lastDegradedAt: string | null;
    lastFallbackReason: string | null;
    lastWarning: string | null;
    openaiConfigured: boolean;
    ollamaBaseUrl: string;
    embeddingModel: string;
};
export declare function resetEmbeddingRuntimeOverview(): void;
export declare function generateEmbedding(text: string): Promise<number[] | null>;
/**
 * Local hashing-trick embedding — no external service needed.
 * Produces a 256-dimension vector via word hashing + L2 normalization.
 * Quality is lower than neural embeddings but enables offline semantic search.
 */
export declare function generateLocalEmbedding(text: string): number[];
/** Cosine similarity between two vectors. Returns value in [-1, 1]. */
export declare function cosineSimilarity(a: number[], b: number[]): number;
//# sourceMappingURL=embedding.d.ts.map