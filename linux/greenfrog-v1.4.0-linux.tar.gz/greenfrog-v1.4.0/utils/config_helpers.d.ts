/**
 * Shared config helper — extracted so server (web/index.ts) and test suites
 * can import the same function without duplicating it.
 */
export declare const CONFIG_MASKED_SENTINEL = "__GF_MASKED__";
/**
 * Recursively remove sentinel values so configManager.set() does not overwrite
 * unchanged secrets that the client sent back as __GF_MASKED__.
 */
export declare function stripMaskedFields(obj: unknown): unknown;
//# sourceMappingURL=config_helpers.d.ts.map