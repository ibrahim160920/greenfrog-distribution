/**
 * OpenAI-compatible providers: Mistral, Groq, DeepSeek, Qwen, Kimi, GLM
 *
 * All use the OpenAI SDK with a custom baseURL — no extra dependencies needed.
 */
import { OpenAIProvider } from './openai.js';
export declare class MistralProvider extends OpenAIProvider {
    name: string;
    defaultModel: string;
    constructor(apiKey: string, model?: string, baseUrl?: string, authMode?: string, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, disableResponseStorage?: boolean);
    listModels(): Promise<string[]>;
}
export declare class GroqProvider extends OpenAIProvider {
    name: string;
    defaultModel: string;
    constructor(apiKey: string, model?: string, baseUrl?: string, authMode?: string, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, disableResponseStorage?: boolean);
    listModels(): Promise<string[]>;
}
export declare class DeepSeekProvider extends OpenAIProvider {
    name: string;
    defaultModel: string;
    constructor(apiKey: string, model?: string, baseUrl?: string, authMode?: string, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, disableResponseStorage?: boolean);
    listModels(): Promise<string[]>;
}
export declare class QwenProvider extends OpenAIProvider {
    name: string;
    defaultModel: string;
    constructor(apiKey: string, model?: string, baseUrl?: string, authMode?: string, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, disableResponseStorage?: boolean);
    listModels(): Promise<string[]>;
}
export declare class KimiProvider extends OpenAIProvider {
    name: string;
    defaultModel: string;
    constructor(apiKey: string, model?: string, baseUrl?: string, authMode?: string, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, disableResponseStorage?: boolean);
    listModels(): Promise<string[]>;
}
export declare class GLMProvider extends OpenAIProvider {
    name: string;
    defaultModel: string;
    constructor(apiKey: string, model?: string, baseUrl?: string, authMode?: string, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, disableResponseStorage?: boolean);
    listModels(): Promise<string[]>;
}
export declare class GeminiRelayProvider extends OpenAIProvider {
    name: string;
    defaultModel: string;
    constructor(apiKey: string, model?: string, baseUrl?: string, authMode?: string, authHeader?: string, authScheme?: string, extraHeaders?: Record<string, string>, disableResponseStorage?: boolean);
    listModels(): Promise<string[]>;
}
//# sourceMappingURL=compat.d.ts.map