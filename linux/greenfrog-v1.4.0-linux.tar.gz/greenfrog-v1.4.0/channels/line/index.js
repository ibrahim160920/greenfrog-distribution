import express from 'express';
import { middleware as lineMiddleware, messagingApi } from '@line/bot-sdk';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { ChannelError } from '../../utils/errors.js';
import { config } from '../../config/index.js';
export class LineChannel extends BaseChannel {
    name = 'line';
    client = null;
    server = null;
    _running = false;
    // Map chatId → { replyToken, userId, expiresAt }
    // replyToken is valid for ~30 s; fallback to pushMessage with userId
    tokenCache = new Map();
    async start() {
        const cfg = config.channels.line;
        if (!cfg?.enabled || !cfg.channelAccessToken || !cfg.channelSecret) {
            this.log.info('Line not configured, skipping');
            return;
        }
        const port = cfg.port ?? 3980;
        const allowedUsers = cfg.allowedUsers ?? [];
        this.client = new messagingApi.MessagingApiClient({
            channelAccessToken: cfg.channelAccessToken,
        });
        const app = express();
        // Line signature middleware (raw body required)
        app.use('/webhook', lineMiddleware({ channelSecret: cfg.channelSecret }));
        app.post('/webhook', async (req, res) => {
            res.sendStatus(200);
            const body = req.body;
            for (const event of body.events ?? []) {
                if (event.type !== 'message')
                    continue;
                const msgEvent = event;
                if (msgEvent.message.type !== 'text')
                    continue;
                const textMsg = msgEvent.message;
                const source = msgEvent.source;
                const userId = source.userId ?? 'unknown';
                const chatId = source.groupId
                    ?? source.roomId
                    ?? userId;
                if (allowedUsers.length > 0 && !allowedUsers.includes(userId)) {
                    this.log.debug({ userId }, 'Line: user not in allowedUsers, ignoring');
                    continue;
                }
                const text = textMsg.text?.trim() ?? '';
                if (!text)
                    continue;
                // Cache replyToken (valid 30 s)
                if (msgEvent.replyToken) {
                    this.tokenCache.set(chatId, {
                        replyToken: msgEvent.replyToken,
                        userId,
                        expiresAt: Date.now() + 25_000, // 25 s safety margin
                    });
                }
                const msg = {
                    id: textMsg.id ?? nanoid(),
                    channel: 'line',
                    userId,
                    chatId,
                    text,
                    timestamp: new Date(msgEvent.timestamp),
                    raw: event,
                };
                await this.handleMessage(msg).catch((err) => {
                    this.log.error({ err }, 'Line: error handling message');
                });
            }
        });
        await new Promise((resolve, reject) => {
            this.server = app.listen(port, () => {
                this.log.info({ port }, 'Line webhook listener started');
                resolve();
            });
            this.server.on('error', reject);
        });
        this._running = true;
        this.log.info({ port }, 'Line channel started');
    }
    async stop() {
        await new Promise((resolve) => {
            if (this.server) {
                this.server.close(() => resolve());
            }
            else {
                resolve();
            }
        });
        this._running = false;
        this.log.info('Line channel stopped');
    }
    async send(message) {
        if (!this.client || !message.chatId)
            return;
        const chunks = this.splitMessage(message.text ?? '', 5000);
        const cached = this.tokenCache.get(message.chatId);
        for (const chunk of chunks) {
            try {
                if (cached && Date.now() < cached.expiresAt) {
                    await this.client.replyMessage({
                        replyToken: cached.replyToken,
                        messages: [{ type: 'text', text: chunk }],
                    });
                    // replyToken is single-use — clear it
                    this.tokenCache.delete(message.chatId);
                }
                else {
                    // Fallback: push message to userId (requires Messaging API push permission)
                    const targetId = cached?.userId ?? message.chatId;
                    await this.client.pushMessage({
                        to: targetId,
                        messages: [{ type: 'text', text: chunk }],
                    });
                }
            }
            catch (err) {
                throw new ChannelError(`Line send error: ${String(err)}`, 'line');
            }
        }
    }
    isRunning() {
        return this._running;
    }
    splitMessage(text, maxLen) {
        if (text.length <= maxLen)
            return [text];
        const chunks = [];
        let remaining = text;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, maxLen);
            const lastNewline = chunk.lastIndexOf('\n');
            if (lastNewline > maxLen / 2)
                chunk = remaining.slice(0, lastNewline);
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }
        return chunks;
    }
}
//# sourceMappingURL=index.js.map