import { BaseSkill } from './base.js';
import type { ProviderTool, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare const SKILL_RBAC: Record<string, 'admin' | 'user' | 'any'>;
export declare class SkillRegistry {
    private skills;
    constructor();
    private registerBuiltins;
    register(skill: BaseSkill): void;
    unregister(name: string): boolean;
    get(name: string): BaseSkill | undefined;
    list(): BaseSkill[];
    listByCategory(): Record<string, BaseSkill[]>;
    toProviderTools(): ProviderTool[];
    getSkillMeta(name: string): {
        name: string;
        description: string;
        category: string;
        parameters: unknown[];
        examples: string[];
        isCustom: boolean;
        rateLimit: {
            perMinute?: number;
            perHour?: number;
        } | null;
        rbacMinRole: 'admin' | 'user' | 'readonly' | 'any';
    } | undefined;
    listAllMeta(): {
        name: string;
        description: string;
        category: string;
        parameters: unknown[];
        examples: string[];
        isCustom: boolean;
        rateLimit: {
            perMinute?: number;
            perHour?: number;
        } | null;
        rbacMinRole: "admin" | "user" | "readonly" | "any";
    }[];
    call(name: string, params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    /** Load custom skills from data directory — each runs in a Worker thread sandbox */
    loadCustomSkills(): Promise<void>;
}
export declare const skillRegistry: SkillRegistry;
//# sourceMappingURL=registry.d.ts.map