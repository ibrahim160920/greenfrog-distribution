import { BaseSkill } from './base.js';
const conversions = {
    length: {
        'km_to_mi': (v) => v * 0.621371,
        'mi_to_km': (v) => v * 1.60934,
        'm_to_ft': (v) => v * 3.28084,
        'ft_to_m': (v) => v / 3.28084,
        'cm_to_in': (v) => v * 0.393701,
        'in_to_cm': (v) => v * 2.54,
    },
    weight: {
        'kg_to_lb': (v) => v * 2.20462,
        'lb_to_kg': (v) => v / 2.20462,
        'g_to_oz': (v) => v * 0.035274,
        'oz_to_g': (v) => v / 0.035274,
    },
    temperature: {
        'c_to_f': (v) => v * 9 / 5 + 32,
        'f_to_c': (v) => (v - 32) * 5 / 9,
        'c_to_k': (v) => v + 273.15,
        'k_to_c': (v) => v - 273.15,
    },
    volume: {
        'l_to_gal': (v) => v * 0.264172,
        'gal_to_l': (v) => v * 3.78541,
        'ml_to_oz': (v) => v * 0.033814,
        'oz_to_ml': (v) => v / 0.033814,
    },
    area: {
        'sqm_to_sqft': (v) => v * 10.7639,
        'sqft_to_sqm': (v) => v / 10.7639,
        'ha_to_acre': (v) => v * 2.47105,
        'acre_to_ha': (v) => v / 2.47105,
    },
    data: {
        'gb_to_mb': (v) => v * 1024,
        'mb_to_gb': (v) => v / 1024,
        'tb_to_gb': (v) => v * 1024,
        'gb_to_tb': (v) => v / 1024,
    },
};
export class UnitConvertSkill extends BaseSkill {
    definition = {
        name: 'unit_convert',
        description: 'Convert between units: length, weight, temperature, volume, area, data size',
        category: 'utilities',
        parameters: [
            { name: 'value', type: 'number', required: true, description: 'Value to convert' },
            { name: 'from', type: 'string', required: true, description: 'Source unit (e.g. km, lb, C, l, sqm, gb)' },
            { name: 'to', type: 'string', required: true, description: 'Target unit (e.g. mi, kg, F, gal, sqft, mb)' },
        ],
    };
    async execute(params, _ctx) {
        const value = params.value;
        const from = params.from.toLowerCase();
        const to = params.to.toLowerCase();
        const key = `${from}_to_${to}`;
        for (const category of Object.values(conversions)) {
            if (category[key]) {
                const result = category[key](value);
                const formatted = Number.isInteger(result) ? result.toString() : result.toFixed(4).replace(/\.?0+$/, '');
                return this.text(`🔄 **${value} ${from} = ${formatted} ${to}**`);
            }
        }
        // Try reverse
        const reverseKey = `${to}_to_${from}`;
        for (const category of Object.values(conversions)) {
            if (category[reverseKey]) {
                // Use the reverse function
                const testVal = 1;
                const testResult = category[reverseKey](testVal);
                const result = value / testResult;
                const formatted = result.toFixed(4).replace(/\.?0+$/, '');
                return this.text(`🔄 **${value} ${from} ≈ ${formatted} ${to}**`);
            }
        }
        const supported = Object.values(conversions)
            .flatMap((cat) => Object.keys(cat))
            .map((k) => k.replace('_to_', ' → '))
            .slice(0, 10);
        return this.err(`Cannot convert ${from} to ${to}. Supported: ${supported.join(', ')}...`);
    }
}
//# sourceMappingURL=unit_convert.js.map