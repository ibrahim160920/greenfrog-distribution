export type TeamRuntimeWakeupSignal = {
    kind: 'task_created' | 'task_updated';
    workspaceId: string;
    taskId: string;
    assignedAgentId?: string | null;
    status?: string | null;
} | {
    kind: 'mailbox_created' | 'mailbox_updated';
    workspaceId: string;
    messageId: string;
    recipientAgentId?: string | null;
    taskId?: string | null;
    status?: string | null;
} | {
    kind: 'approval_created' | 'approval_updated';
    workspaceId: string;
    approvalId: string;
    taskId: string;
    status?: string | null;
};
type TeamRuntimeWakeupHandlers = {
    processWorkspace: (params: {
        workspaceId: string;
        reasons: string[];
    }) => Promise<void>;
    runAgentHeartbeat: (params: {
        workspaceId: string;
        agentId: string;
        reasons: string[];
    }) => Promise<void>;
    /**
     * Optional fast-path handler invoked instead of runAgentHeartbeat when a
     * mailbox_created event fires for a specific agent.  If omitted, the full
     * heartbeat is used as the fallback (existing behaviour).
     */
    processAgentMailbox?: (params: {
        workspaceId: string;
        agentId: string;
        reasons: string[];
    }) => Promise<void>;
    debounceMs?: number;
};
export declare function configureTeamRuntimeWakeups(nextHandlers: TeamRuntimeWakeupHandlers | null): void;
export declare function publishTeamRuntimeWakeup(signal: TeamRuntimeWakeupSignal): void;
export declare function resetTeamRuntimeWakeupsForTests(): void;
export {};
//# sourceMappingURL=team_runtime_wakeup.d.ts.map