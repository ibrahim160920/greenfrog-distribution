/**
 * manifest_store.ts — Read and query signed release manifests.
 *
 * Manifests are stored as JSON files under release/manifests/*.json.
 * The store reads them from disk on each query (no caching needed for MVP).
 */
import { type ReleaseManifest } from '../inheritance/manifest.js';
/** Load all valid manifests from the manifests directory. */
export declare function loadAllManifests(manifestsDir?: string): ReleaseManifest[];
/** Find the latest manifest compatible with the given currentVersion. */
export declare function findLatestCompatible(currentVersion: string, manifestsDir?: string): ReleaseManifest | null;
/** Find a specific manifest by releaseId. */
export declare function findByReleaseId(releaseId: string, manifestsDir?: string): ReleaseManifest | null;
//# sourceMappingURL=manifest_store.d.ts.map