/**
 * Execution Trace System
 *
 * Provides detailed tracing of agent execution for observability.
 * Records key events during agent runs to enable debugging and performance analysis.
 */
import { nanoid } from 'nanoid';
import { createLogger } from '../utils/logger.js';
const log = createLogger('execution-trace');
// In-memory trace storage (limited to last 100 traces)
const MAX_TRACES = 100;
const traces = new Map();
const tracesByRunId = new Map(); // runId -> traceId
/**
 * Start a new execution trace
 */
export function startTrace(params) {
    const traceId = nanoid();
    const trace = {
        traceId,
        runId: params.runId,
        userId: params.userId,
        channel: params.channel,
        startedAt: Date.now(),
        completedAt: null,
        durationMs: null,
        status: 'running',
        events: [],
        metadata: {
            label: params.label,
            iterationCount: 0,
            toolCallCount: 0,
            providerCallCount: 0,
        },
    };
    traces.set(traceId, trace);
    tracesByRunId.set(params.runId, traceId);
    // Limit trace storage
    if (traces.size > MAX_TRACES) {
        const oldestTraceId = traces.keys().next().value;
        if (typeof oldestTraceId === 'string') {
            const oldestTrace = traces.get(oldestTraceId);
            if (oldestTrace) {
                tracesByRunId.delete(oldestTrace.runId);
            }
            traces.delete(oldestTraceId);
        }
    }
    addTraceEvent(traceId, 'run_start', {
        userId: params.userId,
        channel: params.channel,
        label: params.label,
    });
    log.debug({ traceId, runId: params.runId }, 'Trace started');
    return traceId;
}
/**
 * Add an event to a trace
 */
export function addTraceEvent(traceId, eventType, data = {}) {
    const trace = traces.get(traceId);
    if (!trace) {
        log.warn({ traceId, eventType }, 'Trace not found');
        return;
    }
    const event = {
        eventId: nanoid(),
        traceId,
        runId: trace.runId,
        timestamp: Date.now(),
        eventType,
        data,
    };
    trace.events.push(event);
    // Update metadata counters
    if (eventType === 'iteration_start') {
        trace.metadata.iterationCount = (trace.metadata.iterationCount || 0) + 1;
    }
    else if (eventType === 'tool_call_start') {
        trace.metadata.toolCallCount = (trace.metadata.toolCallCount || 0) + 1;
    }
    else if (eventType === 'provider_call_start') {
        trace.metadata.providerCallCount = (trace.metadata.providerCallCount || 0) + 1;
    }
}
/**
 * Complete a trace
 */
export function completeTrace(traceId, status, errorMessage) {
    const trace = traces.get(traceId);
    if (!trace) {
        log.warn({ traceId }, 'Trace not found');
        return;
    }
    trace.completedAt = Date.now();
    trace.durationMs = trace.completedAt - trace.startedAt;
    trace.status = status;
    if (errorMessage) {
        trace.metadata.errorMessage = errorMessage;
    }
    const eventType = status === 'completed' ? 'run_complete' : 'run_error';
    addTraceEvent(traceId, eventType, {
        durationMs: trace.durationMs,
        status,
        errorMessage,
    });
    log.debug({ traceId, status, durationMs: trace.durationMs }, 'Trace completed');
}
/**
 * Get a trace by ID
 */
export function getTrace(traceId) {
    return traces.get(traceId) || null;
}
/**
 * Get a trace by run ID
 */
export function getTraceByRunId(runId) {
    const traceId = tracesByRunId.get(runId);
    return traceId ? traces.get(traceId) || null : null;
}
/**
 * Get recent traces
 */
export function getRecentTraces(limit = 20) {
    return Array.from(traces.values())
        .sort((a, b) => b.startedAt - a.startedAt)
        .slice(0, limit);
}
/**
 * Get traces by user
 */
export function getTracesByUser(userId, limit = 20) {
    return Array.from(traces.values())
        .filter((trace) => trace.userId === userId)
        .sort((a, b) => b.startedAt - a.startedAt)
        .slice(0, limit);
}
/**
 * Get trace statistics
 */
export function getTraceStatistics() {
    const allTraces = Array.from(traces.values());
    const completedTraces = allTraces.filter((t) => t.status === 'completed');
    const errorTraces = allTraces.filter((t) => t.status === 'error');
    const runningTraces = allTraces.filter((t) => t.status === 'running');
    const avgDuration = completedTraces.length > 0
        ? Math.round(completedTraces.reduce((sum, t) => sum + (t.durationMs || 0), 0) / completedTraces.length)
        : 0;
    const avgIterations = completedTraces.length > 0
        ? Math.round(completedTraces.reduce((sum, t) => sum + (t.metadata.iterationCount || 0), 0) /
            completedTraces.length)
        : 0;
    const avgToolCalls = completedTraces.length > 0
        ? Math.round(completedTraces.reduce((sum, t) => sum + (t.metadata.toolCallCount || 0), 0) /
            completedTraces.length)
        : 0;
    return {
        totalTraces: allTraces.length,
        runningTraces: runningTraces.length,
        completedTraces: completedTraces.length,
        errorTraces: errorTraces.length,
        avgDurationMs: avgDuration,
        avgIterations,
        avgToolCalls,
    };
}
/**
 * Clear old traces (for testing)
 */
export function clearTraces() {
    traces.clear();
    tracesByRunId.clear();
    log.debug('All traces cleared');
}
//# sourceMappingURL=execution_trace.js.map