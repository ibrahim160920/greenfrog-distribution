/**
 * Draw — 全能画图技能
 *
 * 主引擎：Pollinations.ai（完全免费，无需任何 key）
 *   模型：flux (默认) | flux-realism | flux-3d | nanobanana | nanobanana-pro |
 *         kontext | seedream | flux-anime | turbo | dreamshaper
 *   img2img：通过 ?image=URL 传入参考图
 *   最高分辨率：1280×1280 原生，内置 2× upscaler → ~2560×2560
 *
 * 增强引擎（可选 key）：
 *   Fal.ai（FAL_API_KEY）：背景移除、高质量 img2img
 *   本地 SD WebUI（localhost:7860）：任意分辨率、inpainting、ControlNet
 *
 * 功能：
 *   - 文生图（支持超高清、3D 渲染、各种风格）
 *   - 图生图（改风格、换背景、图片编辑）
 *   - 智能模型选择（根据 prompt 关键词自动匹配最优模型）
 *   - 分辨率预设（square / hd / 2k / portrait / landscape / banner）
 */
import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class DrawSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private pollinations;
    private falAi;
    private sdWebUI;
    private dalle3;
}
//# sourceMappingURL=draw.d.ts.map