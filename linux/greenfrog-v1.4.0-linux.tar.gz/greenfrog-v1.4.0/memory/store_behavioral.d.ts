import Database from 'better-sqlite3';
import type { BehavioralRuleHistoryEntry, ChannelName, MemoryScope } from '../utils/types.js';
export declare function createBehavioralStore(db: Database.Database): {
    saveInteractionFeedback(opts: {
        userId: string;
        channel: ChannelName;
        sessionId: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: "positive" | "negative" | "neutral" | "correction" | "rephrase";
        signal?: string;
        score: number;
    }): void;
    saveScopedInteractionFeedback(scope: MemoryScope, opts: {
        sessionId: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: "positive" | "negative" | "neutral" | "correction" | "rephrase";
        signal?: string;
        score: number;
    }): void;
    getRecentFeedback(userId: string, channel: ChannelName, limit?: number): Array<{
        id: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: string;
        signal: string | null;
        score: number;
        createdAt: Date;
    }>;
    getRecentScopedFeedback(scope: MemoryScope, limit?: number): Array<{
        id: string;
        userMessage: string;
        aiResponse: string;
        feedbackType: string;
        signal: string | null;
        score: number;
        createdAt: Date;
    }>;
    getFeedbackStats(userId: string, channel: ChannelName): {
        total: number;
        positive: number;
        negative: number;
        avgScore: number;
    };
    getScopedFeedbackStats(scope: MemoryScope): {
        total: number;
        positive: number;
        negative: number;
        avgScore: number;
    };
    upsertBehavioralRule(opts: {
        userId: string;
        channel: ChannelName;
        rule: string;
        category: string;
        confidence: number;
        source: string;
    }): void;
    recordScopedBehavioralRuleHistory(scope: MemoryScope, entry: {
        rule: string;
        action: BehavioralRuleHistoryEntry["action"];
        relatedHistoryId?: string | null;
        oldCategory?: string | null;
        oldConfidence?: number | null;
        oldSource?: string | null;
        oldEvidenceCount?: number | null;
        newCategory?: string | null;
        newConfidence?: number | null;
        newSource?: string | null;
        newEvidenceCount?: number | null;
    }): void;
    getScopedBehavioralRuleRecord(scope: MemoryScope, rule: string): {
        id: string;
        category: string;
        confidence: number;
        source: string;
        evidence_count: number;
    } | undefined;
    putScopedBehavioralRuleExact(scope: MemoryScope, params: {
        rule: string;
        category: string;
        confidence: number;
        source: string;
        evidenceCount: number;
    }): void;
    upsertScopedBehavioralRule(scope: MemoryScope, opts: {
        rule: string;
        category: string;
        confidence: number;
        source: string;
    }): void;
    getBehavioralRules(userId: string, channel: ChannelName, minConfidence?: number): Array<{
        rule: string;
        category: string;
        confidence: number;
        source: string;
        evidenceCount: number;
    }>;
    getScopedBehavioralRules(scope: MemoryScope, minConfidence?: number): Array<{
        rule: string;
        category: string;
        confidence: number;
        source: string;
        evidenceCount: number;
    }>;
    getBehavioralRuleHistory(userId: string, channel: ChannelName, limit?: number): BehavioralRuleHistoryEntry[];
    getScopedBehavioralRuleHistory(scope: MemoryScope, limit?: number): BehavioralRuleHistoryEntry[];
    rollbackBehavioralRuleHistory(userId: string, channel: ChannelName, historyId: string, source?: string): boolean;
    rollbackScopedBehavioralRuleHistory(scope: MemoryScope, historyId: string, source?: string): boolean;
    deleteBehavioralRule(userId: string, channel: ChannelName, rule: string): boolean;
    deleteScopedBehavioralRule(scope: MemoryScope, rule: string): boolean;
    bulkReplaceScopedBehavioralRules(scope: MemoryScope, rules: Array<{
        rule: string;
        category: string;
        confidence: number;
        source: string;
    }>): void;
    listBehavioralRuleScopes(limit?: number): Array<{
        userId: string;
        channel: ChannelName;
        workspaceId?: string;
        agentId?: string;
        ruleCount: number;
        latestUpdatedAt: Date | null;
    }>;
    decayScopedBehavioralRules(scope: MemoryScope, opts?: {
        staleAfterDays?: number;
        deleteAfterDays?: number;
        lowEvidenceThreshold?: number;
        decayStep?: number;
        floorConfidence?: number;
    }): {
        updated: number;
        deleted: number;
    };
    summarizeBehavioralRules(): {
        totalRules: number;
        compressedRules: number;
        avgConfidence: number;
        lowConfidenceRules: number;
        staleRules: number;
        distinctScopes: number;
    };
};
//# sourceMappingURL=store_behavioral.d.ts.map