/**
 * Execution Trace System
 *
 * Provides detailed tracing of agent execution for observability.
 * Records key events during agent runs to enable debugging and performance analysis.
 */
import type { ChannelName } from '../utils/types.js';
export type TraceEventType = 'run_start' | 'run_complete' | 'run_error' | 'iteration_start' | 'iteration_complete' | 'tool_call_start' | 'tool_call_complete' | 'tool_call_error' | 'provider_call_start' | 'provider_call_complete' | 'provider_call_error';
export interface TraceEvent {
    eventId: string;
    traceId: string;
    runId: string;
    timestamp: number;
    eventType: TraceEventType;
    data: Record<string, unknown>;
}
export interface ExecutionTrace {
    traceId: string;
    runId: string;
    userId: string;
    channel: ChannelName;
    startedAt: number;
    completedAt: number | null;
    durationMs: number | null;
    status: 'running' | 'completed' | 'error' | 'cancelled';
    events: TraceEvent[];
    metadata: {
        label?: string;
        iterationCount?: number;
        toolCallCount?: number;
        providerCallCount?: number;
        errorMessage?: string;
    };
}
/**
 * Start a new execution trace
 */
export declare function startTrace(params: {
    runId: string;
    userId: string;
    channel: ChannelName;
    label?: string;
}): string;
/**
 * Add an event to a trace
 */
export declare function addTraceEvent(traceId: string, eventType: TraceEventType, data?: Record<string, unknown>): void;
/**
 * Complete a trace
 */
export declare function completeTrace(traceId: string, status: 'completed' | 'error' | 'cancelled', errorMessage?: string): void;
/**
 * Get a trace by ID
 */
export declare function getTrace(traceId: string): ExecutionTrace | null;
/**
 * Get a trace by run ID
 */
export declare function getTraceByRunId(runId: string): ExecutionTrace | null;
/**
 * Get recent traces
 */
export declare function getRecentTraces(limit?: number): ExecutionTrace[];
/**
 * Get traces by user
 */
export declare function getTracesByUser(userId: string, limit?: number): ExecutionTrace[];
/**
 * Get trace statistics
 */
export declare function getTraceStatistics(): {
    totalTraces: number;
    runningTraces: number;
    completedTraces: number;
    errorTraces: number;
    avgDurationMs: number;
    avgIterations: number;
    avgToolCalls: number;
};
/**
 * Clear old traces (for testing)
 */
export declare function clearTraces(): void;
//# sourceMappingURL=execution_trace.d.ts.map