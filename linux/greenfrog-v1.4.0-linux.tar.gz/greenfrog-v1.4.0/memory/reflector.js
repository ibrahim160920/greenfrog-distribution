/**
 * Reflection Engine — the "使用越久越智能" 核心
 *
 * 定期（或按需）对最近的交互进行自我反思：
 *   1. 收集最近负向/纠错的交互样本
 *   2. LLM 分析模式，提炼行为规则
 *   3. 将规则持久化到 behavioral_rules 表
 *   4. 规则注入 system prompt，永久改变行为
 *
 * 触发时机：
 *   - 自动：每积累 10 条负向反馈时
 *   - 手动：用户调用 reflect 技能
 *   - 定期：每 N 次交互（由 agent 调用）
 */
import { providerRegistry } from '../providers/index.js';
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('memory:reflector');
// ── 反思提示词 ──────────────────────────────────────────────────────────────
const REFLECTION_SYSTEM = `You are an AI assistant analyzing your own past performance to improve.
You will be given a list of recent interactions where the user gave negative feedback or corrected you.
Your job: identify recurring behavioral patterns and extract actionable rules to improve future responses.

Output a JSON array of rules. Each rule:
{
  "rule": "concise instruction in imperative form (max 120 chars)",
  "category": "style|format|content|tone|workflow",
  "confidence": 50-95,
  "rationale": "brief explanation of the pattern observed (max 100 chars)"
}

Category meanings:
  style   — how to write (length, markdown, bullet points, code blocks)
  format  — structure of responses (headers, lists, tables)
  content — what to include/exclude (examples, explanations, details)
  tone    — voice and register (formal, casual, direct, empathetic)
  workflow — how to approach tasks (ask before doing, show plan first, etc.)

Rules:
- Only extract rules supported by multiple examples in the data
- Rules must be actionable and specific, not generic ("be helpful")
- Prefer rules about things the AI consistently got WRONG
- Return [] if no clear patterns emerge
- Max 5 rules per reflection`;
function buildReflectionPrompt(interactions, corrections, existingRules) {
    const interactionSamples = interactions.slice(0, 15).map((x, i) => `[${i + 1}] Signal: ${x.signal ?? x.feedbackType}\n` +
        `User: ${x.userMessage.slice(0, 200)}\n` +
        `AI: ${x.aiResponse.slice(0, 300)}`).join('\n\n');
    const correctionSamples = corrections.slice(0, 8).map((c) => `- ${c.key}: ${c.value}`).join('\n');
    const existingRulesList = existingRules.map((r) => `- [${r.category}] ${r.rule}`).join('\n');
    return (`Recent negative interactions:\n${interactionSamples || '(none)'}\n\n` +
        `Corrections already learned:\n${correctionSamples || '(none)'}\n\n` +
        `Rules already in effect (do not duplicate):\n${existingRulesList || '(none)'}\n\n` +
        `Analyze the patterns and output new behavioral rules as JSON array:`);
}
export async function runReflection(userId, channel, minSamples = 5) {
    // Gather recent negative/correction interactions
    const allFeedback = await memoryStore.getRecentFeedback(userId, channel, 50);
    const negativeFeedback = allFeedback.filter((f) => f.score < 0 || f.feedbackType === 'correction');
    if (negativeFeedback.length < minSamples) {
        return {
            rulesAdded: 0, rulesReinforced: 0,
            summary: `反思需要至少 ${minSamples} 条负向反馈样本，当前只有 ${negativeFeedback.length} 条。继续使用后再试。`,
            rules: [],
        };
    }
    // Gather existing corrections from memory
    const allMem = await memoryStore.getAllMemory(userId, channel);
    const corrections = Object.entries(allMem)
        .filter(([k]) => k.startsWith('correction:'))
        .map(([k, v]) => ({ key: k, value: v }));
    // Existing behavioral rules (to avoid duplicates)
    const existingRules = await memoryStore.getBehavioralRules(userId, channel, 0);
    const prompt = buildReflectionPrompt(negativeFeedback, corrections, existingRules);
    let newRules = [];
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: prompt }],
            systemPrompt: REFLECTION_SYSTEM,
            maxTokens: 800,
            temperature: 0.2,
        });
        const m = (res.content ?? '').match(/\[[\s\S]*\]/);
        if (m)
            newRules = JSON.parse(m[0]);
    }
    catch (err) {
        log.warn({ err: String(err) }, 'Reflection LLM call failed');
        return { rulesAdded: 0, rulesReinforced: 0, summary: `反思失败: ${String(err)}`, rules: [] };
    }
    const VALID_CATEGORIES = new Set(['style', 'format', 'content', 'tone', 'workflow']);
    let added = 0;
    let reinforced = 0;
    const savedRules = [];
    for (const r of newRules) {
        if (!r.rule || !r.category || !VALID_CATEGORIES.has(r.category))
            continue;
        const rule = String(r.rule).trim().slice(0, 120);
        const confidence = Math.min(95, Math.max(40, typeof r.confidence === 'number' ? r.confidence : 60));
        // Check if rule already exists
        const existing = existingRules.find((e) => e.rule.toLowerCase() === rule.toLowerCase());
        memoryStore.upsertBehavioralRule({
            userId, channel, rule, category: r.category, confidence, source: 'reflection',
        });
        if (existing)
            reinforced++;
        else
            added++;
        savedRules.push({ rule, category: r.category, confidence });
    }
    const stats = await memoryStore.getFeedbackStats(userId, channel);
    const summary = `反思完成。分析了 ${negativeFeedback.length} 条负向交互，` +
        `新增 ${added} 条行为规则，强化 ${reinforced} 条。\n` +
        `总体统计：${stats.total} 次交互，好评率 ${stats.total > 0 ? Math.round(stats.positive / stats.total * 100) : 0}%`;
    log.info({ userId, added, reinforced, total: negativeFeedback.length }, 'Reflection complete');
    return { rulesAdded: added, rulesReinforced: reinforced, summary, rules: savedRules };
}
//# sourceMappingURL=reflector.js.map