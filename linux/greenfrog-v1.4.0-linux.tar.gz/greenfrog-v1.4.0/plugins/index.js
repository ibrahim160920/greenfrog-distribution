/**
 * Plugin hot-loading system
 *
 * Watches {dataDir}/custom_skills/*.js for filesystem events and:
 *   add    → vet + register sandboxed skill (no restart needed)
 *   change → re-vet + re-register (overwrites existing entry by name)
 *   unlink → unregister from skill registry
 *
 * Startup loading (loadCustomSkills) is handled separately by registry.ts.
 * This watcher only handles live changes after the process is running.
 */
import chokidar from 'chokidar';
import { readFileSync } from 'fs';
import { join, resolve as resolvePath } from 'path';
import { createLogger } from '../utils/logger.js';
import { vetCode } from '../skills/vetter.js';
import { SandboxedCustomSkill, registerSkillHash } from '../skills/skill_creator.js';
import { skillRegistry } from '../skills/registry.js';
import { config } from '../config/index.js';
import { BaseSkill } from '../skills/base.js';
const log = createLogger('plugins');
const DEBOUNCE_MS = 200;
export class PluginWatcher {
    watcher = null;
    debounceTimers = new Map();
    get watchDir() {
        return join(config.dataDir, 'custom_skills');
    }
    start() {
        this.watcher = chokidar.watch(`${this.watchDir}/*.js`, {
            ignoreInitial: true, // startup load already done by loadCustomSkills()
            persistent: true,
            awaitWriteFinish: { stabilityThreshold: 150, pollInterval: 50 },
        });
        this.watcher
            .on('add', (path) => this.debounce(path, () => this.handleAdd(path)))
            .on('change', (path) => this.debounce(path, () => this.handleChange(path)))
            .on('unlink', (path) => this.debounce(path, () => this.handleUnlink(path)))
            .on('error', (err) => log.error({ err }, 'Plugin watcher error'));
        log.info({ dir: this.watchDir }, 'Plugin watcher started');
    }
    async stop() {
        for (const t of this.debounceTimers.values())
            clearTimeout(t);
        this.debounceTimers.clear();
        if (this.watcher) {
            await this.watcher.close();
            this.watcher = null;
        }
        log.info('Plugin watcher stopped');
    }
    /**
     * Shared load logic: path-guard → vet → update hash → dynamic import → register.
     * Returns the registered skill name on success, null on any failure.
     */
    async loadFile(filePath) {
        // Path traversal guard — ensure file is inside watchDir
        if (!resolvePath(filePath).startsWith(resolvePath(this.watchDir))) {
            log.error({ filePath }, 'Plugin path traversal attempt blocked');
            return null;
        }
        let code;
        try {
            code = readFileSync(filePath, 'utf8');
        }
        catch {
            log.warn({ filePath }, 'Cannot read plugin file');
            return null;
        }
        const vetResult = vetCode(code);
        if (vetResult.blocked) {
            log.error({ filePath, risk: vetResult.risk, score: vetResult.score }, 'Plugin rejected by security vetter');
            return null;
        }
        const filename = filePath.split(/[/\\]/).pop();
        registerSkillHash(this.watchDir, filename, filePath);
        try {
            // Cache-bust the import so Node re-evaluates the updated file.
            // On Windows, absolute paths need file:/// (three slashes).
            const normalized = filePath.replace(/\\/g, '/');
            const fileUrl = (normalized.match(/^[A-Za-z]:/)
                ? `file:///${normalized}`
                : `file://${normalized}`) + `?t=${Date.now()}`;
            const mod = await import(fileUrl);
            for (const value of Object.values(mod)) {
                if (typeof value === 'function' &&
                    (value.prototype instanceof BaseSkill || typeof value.prototype?.execute === 'function')) {
                    const tmp = new value();
                    skillRegistry.register(new SandboxedCustomSkill(tmp.definition, filePath));
                    return { name: tmp.definition.name };
                }
            }
            log.warn({ filePath }, 'No BaseSkill subclass found in plugin file');
            return null;
        }
        catch (err) {
            log.error({ filePath, err }, 'Failed to import plugin file');
            return null;
        }
    }
    debounce(path, fn) {
        const existing = this.debounceTimers.get(path);
        if (existing)
            clearTimeout(existing);
        this.debounceTimers.set(path, setTimeout(async () => {
            this.debounceTimers.delete(path);
            try {
                await fn();
            }
            catch (err) {
                log.error({ path, err }, 'Plugin event handler failed');
            }
        }, DEBOUNCE_MS));
    }
    async handleAdd(filePath) {
        log.info({ filePath }, 'Plugin file added — loading');
        const result = await this.loadFile(filePath);
        if (result)
            log.info({ skill: result.name }, 'Plugin hot-loaded (add)');
    }
    async handleChange(filePath) {
        log.info({ filePath }, 'Plugin file changed — reloading');
        // register() overwrites the existing Map entry by name — no explicit unregister needed
        const result = await this.loadFile(filePath);
        if (result)
            log.info({ skill: result.name }, 'Plugin hot-reloaded (change)');
    }
    async handleUnlink(filePath) {
        log.info({ filePath }, 'Plugin file removed — unregistering');
        const filename = filePath.split(/[/\\]/).pop();
        // Skill names always match the filename stem (enforced by skill_creator.ts)
        const skillName = filename.replace(/\.js$/, '');
        const removed = skillRegistry.unregister(skillName);
        if (removed)
            log.info({ skill: skillName }, 'Plugin unregistered (unlink)');
    }
}
export const pluginWatcher = new PluginWatcher();
//# sourceMappingURL=index.js.map