import { load as cheerioLoad } from 'cheerio';
import { BaseSkill } from './base.js';
import { config } from '../config/index.js';
// RSS feed sources — no API key required
const RSS_SOURCES = [
    { name: 'BBC World', url: 'https://feeds.bbci.co.uk/news/world/rss.xml', tags: ['world', 'international', 'global'] },
    { name: 'Reuters', url: 'https://feeds.reuters.com/reuters/topNews', tags: ['world', 'finance', 'business'] },
    { name: 'Ars Technica', url: 'https://feeds.arstechnica.com/arstechnica/index', tags: ['tech', 'technology', 'science'] },
    { name: 'Hacker News', url: 'https://news.ycombinator.com/rss', tags: ['tech', 'technology', 'startup', 'ai'] },
    { name: 'The Guardian', url: 'https://www.theguardian.com/world/rss', tags: ['world', 'politics', 'culture'] },
];
async function fetchRss(feedUrl, sourceName) {
    const res = await fetch(feedUrl, {
        headers: { 'User-Agent': 'GreenFrog/1.0 RSS Reader', Accept: 'application/rss+xml, application/xml, text/xml' },
        signal: AbortSignal.timeout(8_000),
    });
    if (!res.ok)
        return [];
    const xml = await res.text();
    const $ = cheerioLoad(xml, { xmlMode: true });
    const items = [];
    $('item').each((_, el) => {
        const $el = $(el);
        const title = $el.find('title').first().text().trim();
        const url = ($el.find('link').first().text().trim() || $el.find('link').first().attr('href') || '').trim();
        const date = $el.find('pubDate').first().text().trim() || $el.find('dc\\:date').first().text().trim();
        const desc = $el.find('description').first().text().replace(/<[^>]+>/g, '').trim().slice(0, 200);
        if (title && url) {
            items.push({ title, url, source: sourceName, date: date || undefined, summary: desc || undefined });
        }
    });
    return items;
}
export class NewsSkill extends BaseSkill {
    definition = {
        name: 'get_news',
        description: 'Get latest news from BBC, Reuters, The Guardian, Ars Technica and Hacker News. No API key required.',
        category: 'information',
        parameters: [
            { name: 'query', type: 'string', description: 'Topic or keyword to filter news (optional — omit for top headlines)' },
            { name: 'source', type: 'string', description: 'Preferred source: bbc, reuters, guardian, ars, hn (optional)', enum: ['bbc', 'reuters', 'guardian', 'ars', 'hn'] },
            { name: 'num_articles', type: 'number', description: 'Number of articles to return (1-10)', default: 5 },
        ],
        examples: ['Get latest tech news', 'Latest world news from BBC', '科技新闻', 'AI news today'],
    };
    async execute(params, _ctx) {
        const query = (params.query ?? '').trim().toLowerCase();
        const num = Math.min(10, Math.max(1, Number(params.num_articles ?? 5)));
        const srcPref = params.source?.toLowerCase();
        // If NewsAPI key is configured, use it for precise topic search
        const apiKey = config.skills.news?.apiKey;
        if (apiKey && query) {
            const result = await this.fetchNewsApi(query, num, apiKey);
            if (result.success)
                return result;
        }
        // Pick RSS sources based on topic keywords or explicit source preference
        const sources = this.selectSources(query, srcPref);
        try {
            const allItems = [];
            const results = await Promise.allSettled(sources.map(s => fetchRss(s.url, s.name)));
            for (const r of results) {
                if (r.status === 'fulfilled')
                    allItems.push(...r.value);
            }
            // Filter by keyword if provided
            const filtered = query
                ? allItems.filter(item => item.title.toLowerCase().includes(query) ||
                    (item.summary?.toLowerCase().includes(query) ?? false))
                : allItems;
            if (filtered.length === 0 && query) {
                // No matches in RSS — fall back to HN API
                return this.fetchHN(num);
            }
            const top = filtered.slice(0, num);
            const header = query ? `📰 **News about "${query}":**` : '📰 **Latest Headlines:**';
            const lines = top.map((a, i) => {
                const dateStr = a.date ? new Date(a.date).toLocaleDateString() : '';
                const meta = [a.source, dateStr].filter(Boolean).join(' · ');
                const summary = a.summary ? `\n   ${a.summary}` : '';
                return `${i + 1}. **${a.title}**\n   📡 ${meta}${summary}\n   🔗 ${a.url}`;
            });
            return this.text(`${header}\n\n${lines.join('\n\n')}`);
        }
        catch {
            return this.fetchHN(num);
        }
    }
    /** Choose RSS feeds based on topic / source preference */
    selectSources(query, srcPref) {
        if (srcPref) {
            const map = { bbc: 'BBC World', reuters: 'Reuters', guardian: 'The Guardian', ars: 'Ars Technica', hn: 'Hacker News' };
            const name = map[srcPref];
            const src = RSS_SOURCES.find(s => s.name === name);
            return src ? [src] : RSS_SOURCES;
        }
        if (!query)
            return RSS_SOURCES;
        // Match sources whose tags overlap with query words
        const words = query.split(/\s+/);
        const matched = RSS_SOURCES.filter(s => s.tags.some(t => words.some(w => t.includes(w) || w.includes(t))));
        return matched.length > 0 ? matched : RSS_SOURCES;
    }
    /** Fallback: Hacker News Firebase API */
    async fetchHN(num) {
        try {
            const res = await fetch('https://hacker-news.firebaseio.com/v0/topstories.json', { signal: AbortSignal.timeout(8_000) });
            const ids = (await res.json());
            const stories = await Promise.all(ids.slice(0, num).map(async (id) => {
                const r = await fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`, { signal: AbortSignal.timeout(5_000) });
                return r.json();
            }));
            const lines = stories.map((s, i) => `${i + 1}. **${s.title}** ⭐${s.score}\n   🔗 ${s.url ?? 'https://news.ycombinator.com'}`);
            return this.text(`📰 **Hacker News Top Stories:**\n\n${lines.join('\n\n')}`);
        }
        catch (err) {
            return this.err(`Failed to fetch news: ${String(err)}`);
        }
    }
    /** Optional: NewsAPI.org (if key configured) */
    async fetchNewsApi(query, num, apiKey) {
        try {
            const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&pageSize=${num}&apiKey=${apiKey}&language=en&sortBy=publishedAt`;
            const res = await fetch(url, { signal: AbortSignal.timeout(8_000) });
            if (!res.ok)
                return { success: false };
            const data = await res.json();
            if (!data.articles?.length)
                return { success: false };
            const lines = data.articles.map((a, i) => [
                `${i + 1}. **${a.title}**`,
                `   📡 ${a.source.name} · ${new Date(a.publishedAt).toLocaleDateString()}`,
                `   ${a.description?.slice(0, 150) ?? ''}`,
                `   🔗 ${a.url}`,
            ].join('\n'));
            return this.text(`📰 **News about "${query}":**\n\n${lines.join('\n\n')}`);
        }
        catch {
            return { success: false };
        }
    }
}
//# sourceMappingURL=news.js.map