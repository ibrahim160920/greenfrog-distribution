import { BaseSkill } from './base.js';
import { providerRegistry } from '../providers/index.js';
const HW_SYSTEM = `你是一位拥有40年经验的资深硬件工程师，精通模拟电路、数字电路、嵌入式系统、PCB设计、EMC/EMI设计。
你熟悉各类主流MCU（STM32、ESP32、Arduino、ARM Cortex等）、通信协议（UART/SPI/I2C/CAN/USB/以太网）、
电源管理、传感器接口、射频电路等。你能够提供专业的硬件设计建议、代码框架和调试指导。`;
export class HardwareDevSkill extends BaseSkill {
    definition = {
        name: 'hardware_dev',
        description: '硬件开发辅助。支持原理图设计建议、PCB设计审查、BOM清单生成、固件代码框架、芯片数据手册要点提取、硬件调试指导。覆盖MCU/传感器/通信/电源等各类硬件开发场景。',
        category: 'engineering',
        parameters: [
            { name: 'task', type: 'string', required: true, description: '任务类型：schematic=原理图设计，pcb_review=PCB审查，bom=BOM清单，firmware=固件代码，datasheet=数据手册解读，debug=调试指导', enum: ['schematic', 'pcb_review', 'bom', 'firmware', 'datasheet', 'debug'] },
            { name: 'description', type: 'string', required: true, description: '硬件描述/需求/问题描述' },
            { name: 'mcu', type: 'string', required: false, description: '主控芯片型号，如：STM32F103C8T6、ESP32-WROOM-32、Arduino Uno等' },
            { name: 'interface', type: 'string', required: false, description: '接口类型，如：UART、SPI、I2C、USB、CAN、以太网等' },
            { name: 'constraints', type: 'string', required: false, description: '设计约束，如：工作电压3.3V、功耗<100mA、尺寸50x50mm、成本<50元等' },
            { name: 'code', type: 'string', required: false, description: '固件代码（firmware/debug任务时提供）' },
        ],
        examples: [
            'hardware_dev task=schematic description="温湿度采集节点，需要DHT22传感器和LoRa无线传输" mcu="STM32L051" constraints="电池供电，功耗<10uA睡眠"',
            'hardware_dev task=firmware description="SPI驱动OLED显示屏SSD1306" mcu="ESP32" interface="SPI"',
            'hardware_dev task=debug description="I2C通信偶发NACK错误" mcu="STM32F4" interface="I2C"',
        ],
    };
    async execute(params, _ctx) {
        const task = String(params.task ?? '').trim();
        const description = String(params.description ?? '').trim();
        const mcu = String(params.mcu ?? '').trim();
        const iface = String(params.interface ?? '').trim();
        const constraints = String(params.constraints ?? '').trim();
        const code = String(params.code ?? '').trim();
        if (!task)
            return this.err('请指定任务类型：schematic/pcb_review/bom/firmware/datasheet/debug');
        if (!description)
            return this.err('请提供硬件描述或需求');
        const ctx = [
            mcu ? `主控芯片：${mcu}` : '',
            iface ? `接口类型：${iface}` : '',
            constraints ? `设计约束：${constraints}` : '',
        ].filter(Boolean).join('\n');
        switch (task) {
            case 'schematic': return this.schematic(description, ctx);
            case 'pcb_review': return this.pcbReview(description, ctx);
            case 'bom': return this.bom(description, ctx);
            case 'firmware': return this.firmware(description, ctx, code);
            case 'datasheet': return this.datasheet(description, ctx);
            case 'debug': return this.debug(description, ctx, code);
            default: return this.err(`不支持的任务类型：${task}`);
        }
    }
    async llm(prompt, maxTokens = 2500) {
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: prompt }],
            systemPrompt: HW_SYSTEM,
            maxTokens,
            temperature: 0.2,
        });
        return res.content?.trim() ?? '';
    }
    async schematic(desc, ctx) {
        const prompt = `请为以下硬件需求提供原理图设计方案：

需求描述：${desc}
${ctx}

请输出：

## 一、系统架构
（模块划分图，文字描述各模块功能和连接关系）

## 二、关键器件选型
| 模块 | 推荐型号 | 规格参数 | 替代型号 | 参考价格 |
|------|---------|---------|---------|---------|

## 三、电源设计
（供电方案、电压域划分、去耦电容配置）

## 四、关键电路设计要点
（各模块的典型电路连接，关键参数计算）

## 五、接口定义
（引脚分配表，信号描述）

## 六、注意事项
（设计陷阱、EMC注意事项、可靠性建议）

## 七、参考设计资源
（推荐参考的官方评估板、应用笔记）`;
        try {
            const out = await this.llm(prompt, 3000);
            if (!out)
                return this.err('原理图设计建议生成失败');
            return this.text(`# 原理图设计方案\n\n**需求：${desc}**\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async pcbReview(desc, ctx) {
        const prompt = `请对以下PCB设计进行专业审查：

设计描述：${desc}
${ctx}

请输出PCB设计审查报告：

## 一、布局审查
- 元器件布局合理性
- 热设计（散热器件位置、热敏元件远离热源）
- 可制造性（DFM）检查

## 二、走线审查
- 电源/地线宽度是否满足电流要求
- 高速信号走线（等长、差分对、阻抗控制）
- 敏感信号隔离

## 三、EMC/EMI设计
- 地平面完整性
- 去耦电容放置
- 滤波设计
- 屏蔽措施

## 四、可靠性检查
- 过孔设计
- 焊盘尺寸
- 丝印标注
- 测试点设置

## 五、问题清单（按严重程度）
### 严重问题（必须修改）
### 一般问题（建议修改）
### 优化建议

## 六、改进建议总结`;
        try {
            const out = await this.llm(prompt, 2500);
            if (!out)
                return this.err('PCB审查报告生成失败');
            return this.text(`# PCB设计审查报告\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async bom(desc, ctx) {
        const prompt = `请为以下硬件项目生成BOM（物料清单）：

项目描述：${desc}
${ctx}

请输出完整BOM清单：

## BOM清单

| 序号 | 位号 | 名称/描述 | 规格参数 | 封装 | 数量 | 推荐型号 | 替代型号 | 参考单价(元) | 采购渠道 |
|------|------|---------|---------|------|------|---------|---------|------------|---------|

## 成本估算
- 物料总成本（单件）：
- 批量折扣（100件）：
- 主要成本构成分析：

## 采购建议
- 长交期器件（需提前备货）：
- 国产替代建议：
- 关键器件替代方案：

## 注意事项
（特殊器件的采购注意事项、认证要求等）`;
        try {
            const out = await this.llm(prompt, 2500);
            if (!out)
                return this.err('BOM清单生成失败');
            return this.text(`# BOM清单\n\n**项目：${desc}**\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async firmware(desc, ctx, code) {
        const codeSection = code ? `\n\n现有代码：\n\`\`\`c\n${code.slice(0, 2000)}\n\`\`\`` : '';
        const prompt = `请为以下需求提供固件代码框架：

功能描述：${desc}
${ctx}${codeSection}

请输出：

## 一、代码框架

\`\`\`c
// 完整的固件代码框架，包含：
// - 头文件包含
// - 宏定义和常量
// - 全局变量
// - 函数声明
// - 初始化函数
// - 主循环
// - 中断服务程序（如需要）
// - 关键驱动函数
\`\`\`

## 二、关键函数说明
（各函数的功能、参数、返回值说明）

## 三、配置说明
（时钟配置、引脚配置、外设初始化参数）

## 四、注意事项
（时序要求、常见问题、调试建议）`;
        try {
            const out = await this.llm(prompt, 3000);
            if (!out)
                return this.err('固件代码框架生成失败');
            return this.text(`# 固件代码框架\n\n**功能：${desc}**\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async datasheet(desc, ctx) {
        const prompt = `请提供以下芯片/模块的数据手册要点解读：

芯片/模块：${desc}
${ctx}

请输出：

## 一、基本参数
（电气特性、工作条件、封装信息）

## 二、功能框图
（内部结构说明，主要功能模块）

## 三、引脚说明
（关键引脚功能、电气特性、注意事项）

## 四、典型应用电路
（最小系统电路、典型外围电路）

## 五、通信协议/时序
（如适用：寄存器配置、通信时序图说明）

## 六、初始化流程
（上电时序、初始化步骤）

## 七、常见问题与注意事项
（设计陷阱、常见错误、可靠性建议）

## 八、参考资源
（官方文档链接、参考设计、社区资源）`;
        try {
            const out = await this.llm(prompt, 2500);
            if (!out)
                return this.err('数据手册解读生成失败');
            return this.text(`# 数据手册要点 — ${desc}\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
    async debug(desc, ctx, code) {
        const codeSection = code ? `\n\n相关代码：\n\`\`\`c\n${code.slice(0, 2000)}\n\`\`\`` : '';
        const prompt = `请提供以下硬件问题的调试指导：

问题描述：${desc}
${ctx}${codeSection}

请输出系统性调试方案：

## 一、问题分析
（可能的原因分析，按概率排序）

## 二、排查步骤
（逐步排查流程，从简单到复杂）

### 步骤1：硬件检查
（电源、连接、元器件）

### 步骤2：信号测量
（用示波器/逻辑分析仪测量的关键测试点和预期波形）

### 步骤3：软件验证
（代码层面的验证方法）

## 三、常见原因及解决方案
| 现象 | 可能原因 | 解决方案 |
|------|---------|---------|

## 四、测试代码
（用于验证的最小测试代码片段）

## 五、预防措施
（避免类似问题的设计建议）`;
        try {
            const out = await this.llm(prompt, 2500);
            if (!out)
                return this.err('调试指导生成失败');
            return this.text(`# 硬件调试指导\n\n**问题：${desc}**\n\n${out}`);
        }
        catch (e) {
            return this.err(`生成失败：${String(e)}`);
        }
    }
}
//# sourceMappingURL=hardware_dev.js.map