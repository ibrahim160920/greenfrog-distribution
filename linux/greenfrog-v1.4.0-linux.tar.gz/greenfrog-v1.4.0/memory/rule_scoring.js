/**
 * Rule Quality Scoring System
 *
 * Implements automatic quality scoring for behavioral rules based on:
 * - Success rate (40%)
 * - Usage frequency (30%)
 * - Confidence (20%)
 * - Recency/time decay (10%)
 */
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
import { getAllRuleUsageStats } from './rule_tracking.js';
const log = createLogger('rule-scoring');
// Scoring weights
const WEIGHTS = {
    successRate: 0.4,
    usageFrequency: 0.3,
    confidence: 0.2,
    recency: 0.1,
};
// Time decay parameters
const DECAY_LAMBDA = 0.01; // Decay coefficient (1% per day)
const MAX_AGE_DAYS = 365; // Rules older than 1 year get minimum recency score
// Quality thresholds
const QUALITY_THRESHOLDS = {
    excellent: 0.85,
    good: 0.70,
    acceptable: 0.50,
    poor: 0.30,
};
/**
 * Calculate time decay factor based on rule age
 */
function calculateRecencyScore(createdAt) {
    const now = new Date();
    const ageMs = now.getTime() - createdAt.getTime();
    const ageDays = ageMs / (1000 * 60 * 60 * 24);
    if (ageDays > MAX_AGE_DAYS) {
        return 0.1; // Minimum score for very old rules
    }
    // Exponential decay: e^(-λ × days)
    return Math.exp(-DECAY_LAMBDA * ageDays);
}
/**
 * Normalize usage frequency to 0-1 scale
 */
function normalizeUsageFrequency(totalApplications, maxApplications) {
    if (maxApplications === 0)
        return 0;
    return Math.min(1.0, totalApplications / maxApplications);
}
/**
 * Calculate overall quality score for a rule
 */
export function calculateRuleQualityScore(stats, confidence, maxApplications) {
    // Success rate (0-1)
    const successRate = stats.totalApplications > 0
        ? stats.successfulApplications / stats.totalApplications
        : 0.5; // Default to neutral if no data
    // Usage frequency (0-1, normalized)
    const usageFrequency = normalizeUsageFrequency(stats.totalApplications, maxApplications);
    // Confidence (0-1, already normalized)
    const confidenceScore = confidence / 100;
    // Recency (0-1, time decay)
    const recency = calculateRecencyScore(stats.createdAt);
    // Overall score (weighted sum)
    const overallScore = successRate * WEIGHTS.successRate +
        usageFrequency * WEIGHTS.usageFrequency +
        confidenceScore * WEIGHTS.confidence +
        recency * WEIGHTS.recency;
    // Determine quality level
    let qualityLevel;
    if (overallScore >= QUALITY_THRESHOLDS.excellent) {
        qualityLevel = 'excellent';
    }
    else if (overallScore >= QUALITY_THRESHOLDS.good) {
        qualityLevel = 'good';
    }
    else if (overallScore >= QUALITY_THRESHOLDS.acceptable) {
        qualityLevel = 'acceptable';
    }
    else {
        qualityLevel = 'poor';
    }
    // Decision flags
    const shouldKeep = overallScore >= QUALITY_THRESHOLDS.acceptable;
    const shouldPromote = overallScore >= QUALITY_THRESHOLDS.excellent;
    const shouldDemote = overallScore < QUALITY_THRESHOLDS.poor;
    return {
        ruleId: stats.ruleId,
        overallScore,
        successRate,
        usageFrequency,
        confidence: confidenceScore,
        recency,
        qualityLevel,
        shouldKeep,
        shouldPromote,
        shouldDemote,
    };
}
/**
 * Batch score all rules in a workspace
 */
export async function scoreAllRules(workspaceId, channel) {
    // Get all rules
    const rules = await memoryStore.getBehavioralRules?.(workspaceId, channel) ?? [];
    if (rules.length === 0) {
        return [];
    }
    // Get real usage stats from the tracking cache
    const trackingStats = await getAllRuleUsageStats(workspaceId, channel);
    const allStats = rules.map(rule => {
        const ruleId = rule.rule; // rule text is the key
        const tracked = trackingStats.get(ruleId);
        if (tracked && tracked.totalApplications > 0) {
            return {
                ruleId,
                totalApplications: tracked.totalApplications,
                successfulApplications: tracked.successfulApplications,
                failedApplications: tracked.failedApplications,
                lastUsedAt: tracked.lastUsedAt ?? new Date(),
                createdAt: tracked.lastUsedAt ?? new Date(), // no creation time in tracking cache; use lastUsed as proxy
            };
        }
        // Rule has not been tracked yet — explicitly untracked (totalApplications=0 is truthful, not mocked)
        return {
            ruleId,
            totalApplications: 0,
            successfulApplications: 0,
            failedApplications: 0,
            lastUsedAt: new Date(),
            createdAt: new Date(),
        };
    });
    // Find max applications for normalization
    const maxApplications = Math.max(...allStats.map(s => s.totalApplications), 1);
    // Score each rule
    const scores = rules.map((rule, index) => {
        return calculateRuleQualityScore(allStats[index], rule.confidence, maxApplications);
    });
    log.info({
        workspaceId,
        totalRules: scores.length,
        excellent: scores.filter(s => s.qualityLevel === 'excellent').length,
        good: scores.filter(s => s.qualityLevel === 'good').length,
        acceptable: scores.filter(s => s.qualityLevel === 'acceptable').length,
        poor: scores.filter(s => s.qualityLevel === 'poor').length,
    }, 'Scored all rules');
    return scores;
}
/**
 * Clean up low-quality rules
 */
export async function cleanupLowQualityRules(workspaceId, channel, dryRun = true) {
    const scores = await scoreAllRules(workspaceId, channel);
    let deleted = 0;
    let demoted = 0;
    for (const score of scores) {
        if (score.shouldDemote) {
            if (!dryRun) {
                // TODO: Implement rule deletion
                // await memoryStore.deleteBehavioralRule(workspaceId, channel, score.ruleId);
            }
            deleted++;
            log.info({ ruleId: score.ruleId, score: score.overallScore }, 'Would delete low-quality rule');
        }
        else if (score.overallScore < QUALITY_THRESHOLDS.good) {
            // Demote but keep
            demoted++;
            log.info({ ruleId: score.ruleId, score: score.overallScore }, 'Would demote rule');
        }
    }
    log.info({ workspaceId, deleted, demoted, dryRun }, 'Cleanup low-quality rules');
    return { deleted, demoted };
}
/**
 * Get high-quality rules for promotion to global library
 */
export async function getHighQualityRules(workspaceId, channel, minScore = QUALITY_THRESHOLDS.excellent) {
    const scores = await scoreAllRules(workspaceId, channel);
    return scores.filter(s => s.overallScore >= minScore);
}
/**
 * Get rule quality statistics
 */
export async function getRuleQualityStats(workspaceId, channel) {
    const scores = await scoreAllRules(workspaceId, channel);
    if (scores.length === 0) {
        return {
            totalRules: 0,
            averageScore: 0,
            qualityDistribution: {},
            topRules: [],
            bottomRules: [],
        };
    }
    const averageScore = scores.reduce((sum, s) => sum + s.overallScore, 0) / scores.length;
    const qualityDistribution = {
        excellent: scores.filter(s => s.qualityLevel === 'excellent').length,
        good: scores.filter(s => s.qualityLevel === 'good').length,
        acceptable: scores.filter(s => s.qualityLevel === 'acceptable').length,
        poor: scores.filter(s => s.qualityLevel === 'poor').length,
    };
    // Sort by score
    const sorted = [...scores].sort((a, b) => b.overallScore - a.overallScore);
    const topRules = sorted.slice(0, 10);
    const bottomRules = sorted.slice(-10).reverse();
    return {
        totalRules: scores.length,
        averageScore,
        qualityDistribution,
        topRules,
        bottomRules,
    };
}
//# sourceMappingURL=rule_scoring.js.map