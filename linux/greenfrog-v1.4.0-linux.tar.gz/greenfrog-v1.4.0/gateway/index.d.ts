import { WebSocket } from 'ws';
interface GatewayClient {
    id: string;
    ws: WebSocket;
    authenticated: boolean;
    name?: string;
    connectedAt: Date;
}
export type GatewayMessageHandler = (type: string, payload: unknown, client: GatewayClient, reply: (type: string, data: unknown) => void) => Promise<void>;
export declare class Gateway {
    private wss;
    private httpServer;
    private clients;
    private handlers;
    private running;
    registerHandler(type: string, handler: GatewayMessageHandler): void;
    start(): Promise<void>;
    broadcast(type: string, data: unknown): void;
    stop(): Promise<void>;
    getStatus(): {
        running: boolean;
        clients: number;
        host: string;
        port: number;
    };
}
export declare const gateway: Gateway;
export {};
//# sourceMappingURL=index.d.ts.map