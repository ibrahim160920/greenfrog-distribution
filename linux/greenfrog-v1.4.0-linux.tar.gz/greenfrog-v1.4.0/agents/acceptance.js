/**
 * Structured Acceptance Checks for GreenFrog P4.3/P4.4.
 *
 * P4.3: Text-based checks against resultSummary (summary_fallback).
 * P4.4: Real I/O verification for file/path/JSON checks (evidence-based).
 *
 * Verification hierarchy per check type:
 *
 *   file_exists  — fs.access + fs.stat on check.target path (evidence)
 *   path_exists  — same as file_exists (evidence)
 *   json_field   — if check.targetPath: reads JSON file, checks field (evidence)
 *                  else: summary text search (summary_fallback)
 *   contains     — if check.targetPath: reads file, checks substring (evidence)
 *                  else: checks resultSummary text (summary_fallback)
 *   regex        — if check.targetPath: reads file, matches regex (evidence)
 *                  else: checks resultSummary text (summary_fallback)
 *
 * Every result includes an EvidenceRecord describing:
 *   - verificationMode: 'evidence' | 'summary_fallback'
 *   - evidenceSnippet: what was actually found / why it failed
 *   - checkedAt: ISO timestamp
 *
 * This module performs async I/O for real verification. It is intentionally
 * not sandboxed — paths come from trusted task metadata in this single-user system.
 */
import { access, stat } from 'fs/promises';
import { constants as fsConstants } from 'fs';
// ── Severity helpers ─────────────────────────────────────────────────────────
/**
 * Compute per-check severity.
 *   evidence + passed  → hard_verified  (real-world proof)
 *   evidence + failed  → contradicted   (real-world disproof — agent said done but it isn't)
 *   fallback + passed  → soft_verified  (text plausibility)
 *   fallback + failed  → unverifiable   (cannot confirm from text alone)
 */
function computeCheckSeverity(mode, passed) {
    if (mode === 'evidence')
        return passed ? 'hard_verified' : 'contradicted';
    return passed ? 'soft_verified' : 'unverifiable';
}
/**
 * Aggregate severity across all checks.
 * Priority: contradicted > unverifiable > soft_verified > hard_verified
 */
function aggregateSeverity(results) {
    if (results.length === 0)
        return 'unverifiable';
    const severities = results.map(r => r.severity);
    if (severities.some(s => s === 'contradicted'))
        return 'contradicted';
    // All passed?
    if (results.every(r => r.passed)) {
        if (severities.every(s => s === 'hard_verified'))
            return 'hard_verified';
        return 'soft_verified'; // mix of hard/soft but all passed
    }
    // Some failed but none contradicted (all failures are summary_fallback)
    return 'unverifiable';
}
// ── I/O helpers ───────────────────────────────────────────────────────────────
/** Max bytes to read from a file for content checks */
const MAX_READ_BYTES = 65536; // 64 KB
/** Read up to MAX_READ_BYTES of a file as UTF-8 text */
async function readFileSafe(filePath) {
    try {
        const buf = Buffer.alloc(MAX_READ_BYTES);
        const fh = await import('fs/promises').then(m => m.open(filePath, 'r'));
        try {
            const { bytesRead } = await fh.read(buf, 0, MAX_READ_BYTES, 0);
            return buf.slice(0, bytesRead).toString('utf8');
        }
        finally {
            await fh.close();
        }
    }
    catch {
        return null;
    }
}
/** Resolve dot-notation path in a parsed JSON object */
function resolveDotPath(obj, path) {
    const parts = path.split('.');
    let cur = obj;
    for (const part of parts) {
        if (cur === null || typeof cur !== 'object' || Array.isArray(cur))
            return undefined;
        cur = cur[part];
    }
    return cur;
}
// ── Evidence-based check implementations ─────────────────────────────────────
async function checkFileExistsEvidence(target, _type) {
    try {
        await access(target, fsConstants.F_OK);
        try {
            const s = await stat(target);
            const detail = s.isDirectory()
                ? `目录存在（${s.size} 字节，修改于 ${s.mtime.toISOString()}）`
                : `文件存在（${s.size} 字节，修改于 ${s.mtime.toISOString()}）`;
            return { passed: true, snippet: detail };
        }
        catch {
            return { passed: true, snippet: '路径可访问' };
        }
    }
    catch (err) {
        const code = err.code ?? 'UNKNOWN';
        return { passed: false, snippet: `路径不存在（${code}）：${target}` };
    }
}
async function checkContainsEvidence(target, filePath) {
    const content = await readFileSafe(filePath);
    if (content === null)
        return { passed: false, snippet: `无法读取文件：${filePath}` };
    const idx = content.toLowerCase().indexOf(target.toLowerCase());
    if (idx === -1)
        return { passed: false, snippet: `文件中未找到：「${target.slice(0, 40)}」` };
    // Return surrounding context
    const start = Math.max(0, idx - 30);
    const end = Math.min(content.length, idx + target.length + 50);
    const snippet = content.slice(start, end).replace(/\n/g, '↵');
    return { passed: true, snippet: `已找到：…${snippet}…` };
}
async function checkRegexEvidence(pattern, filePath) {
    const content = await readFileSafe(filePath);
    if (content === null)
        return { passed: false, snippet: `无法读取文件：${filePath}` };
    let re;
    try {
        re = new RegExp(pattern, 'im');
    }
    catch {
        return { passed: false, snippet: `无效正则表达式：${pattern.slice(0, 40)}` };
    }
    const match = re.exec(content);
    if (!match)
        return { passed: false, snippet: `文件中正则未匹配：/${pattern.slice(0, 40)}/` };
    return { passed: true, snippet: `匹配：「${match[0].slice(0, 80).replace(/\n/g, '↵')}」` };
}
async function checkJsonFieldEvidence(fieldPath, expectedValue, filePath) {
    const content = await readFileSafe(filePath);
    if (content === null)
        return { passed: false, snippet: `无法读取文件：${filePath}` };
    let parsed;
    try {
        parsed = JSON.parse(content);
    }
    catch {
        return { passed: false, snippet: `文件不是有效 JSON：${filePath}` };
    }
    const fieldValue = resolveDotPath(parsed, fieldPath);
    if (fieldValue === undefined) {
        return { passed: false, snippet: `JSON 字段不存在：${fieldPath}` };
    }
    const valueStr = typeof fieldValue === 'string' ? fieldValue : JSON.stringify(fieldValue);
    if (expectedValue !== undefined && expectedValue !== '') {
        const match = valueStr.toLowerCase() === expectedValue.toLowerCase() ||
            valueStr.toLowerCase().includes(expectedValue.toLowerCase());
        return {
            passed: match,
            snippet: match
                ? `${fieldPath} = ${valueStr.slice(0, 80)}`
                : `${fieldPath} = ${valueStr.slice(0, 60)} (期望：${expectedValue.slice(0, 40)})`,
        };
    }
    return { passed: true, snippet: `${fieldPath} = ${valueStr.slice(0, 80)}` };
}
// ── Summary-fallback implementations ─────────────────────────────────────────
function checkContainsFallback(target, text) {
    const idx = text.toLowerCase().indexOf(target.toLowerCase());
    if (idx === -1)
        return { passed: false, snippet: `结果摘要中未找到：「${target.slice(0, 40)}」` };
    const start = Math.max(0, idx - 15);
    const end = Math.min(text.length, idx + target.length + 30);
    return { passed: true, snippet: `摘要中找到：…${text.slice(start, end).replace(/\n/g, ' ')}…` };
}
function checkRegexFallback(pattern, text) {
    try {
        const re = new RegExp(pattern, 'im');
        const match = re.exec(text);
        if (!match)
            return { passed: false, snippet: `摘要中正则未匹配：/${pattern.slice(0, 40)}/` };
        return { passed: true, snippet: `摘要中匹配：「${match[0].slice(0, 60)}」` };
    }
    catch {
        return { passed: false, snippet: `无效正则：${pattern.slice(0, 40)}` };
    }
}
function checkPathFallback(target, text) {
    const lower = text.toLowerCase();
    const targetLower = target.toLowerCase();
    if (lower.includes(targetLower)) {
        return { passed: true, snippet: `摘要中提及路径（仅文本验证，非文件系统确认）` };
    }
    const segments = target.replace(/\\/g, '/').split('/');
    const filename = segments[segments.length - 1];
    if (filename && filename.length > 2 && lower.includes(filename.toLowerCase())) {
        return { passed: true, snippet: `摘要中提及文件名：${filename}（仅文本验证）` };
    }
    return { passed: false, snippet: `摘要中未提及路径：${target.slice(0, 50)}` };
}
function checkJsonFieldFallback(fieldName, expectedValue, text) {
    const lower = text.toLowerCase();
    if (!lower.includes(fieldName.toLowerCase())) {
        return { passed: false, snippet: `摘要中未提及字段：${fieldName}` };
    }
    if (expectedValue !== undefined && expectedValue !== '') {
        const match = lower.includes(expectedValue.toLowerCase());
        return {
            passed: match,
            snippet: match
                ? `摘要中提及字段 ${fieldName} 和期望值 ${expectedValue.slice(0, 30)}`
                : `摘要中提及 ${fieldName} 但未提及期望值 ${expectedValue.slice(0, 30)}`,
        };
    }
    return { passed: true, snippet: `摘要中提及字段：${fieldName}（仅文本验证）` };
}
// ── Core async function ───────────────────────────────────────────────────────
/**
 * Run all acceptance checks. Real I/O for file/path/JSON checks; text fallback otherwise.
 *
 * P4.4: This function is now async to support evidence-based verification.
 * Each result includes a full EvidenceRecord.
 */
export async function runAcceptanceChecks(checks, resultSummary) {
    if (checks.length === 0) {
        return {
            results: [], passed: 0, total: 0, allPassed: true,
            summary: '无结构化验收条件', failures: [],
            evidenceRecords: [], dominantMode: 'summary_fallback',
            overallSeverity: 'unverifiable',
        };
    }
    const text = resultSummary?.trim() ?? '';
    const results = [];
    let hasEvidence = false;
    const now = new Date().toISOString();
    for (const check of checks) {
        const label = check.description ?? `${check.type}(${check.target.slice(0, 30)})`;
        let passed = false;
        let mode = 'summary_fallback';
        let snippet = '';
        let reason = '';
        switch (check.type) {
            case 'file_exists':
            case 'path_exists': {
                // Always attempt real filesystem verification for these types
                const res = await checkFileExistsEvidence(check.target, check.type);
                passed = res.passed;
                snippet = res.snippet;
                mode = 'evidence';
                reason = passed
                    ? `[evidence] 文件系统确认存在：${check.target.slice(0, 60)}`
                    : `[evidence] 文件系统确认不存在：${check.target.slice(0, 60)}`;
                hasEvidence = true;
                break;
            }
            case 'contains': {
                if (check.targetPath) {
                    const res = await checkContainsEvidence(check.target, check.targetPath);
                    passed = res.passed;
                    snippet = res.snippet;
                    mode = 'evidence';
                    reason = passed
                        ? `[evidence] 文件内容包含目标字符串 (${check.targetPath})`
                        : `[evidence] 文件内容不包含目标字符串 (${check.targetPath})`;
                    hasEvidence = true;
                }
                else {
                    const res = checkContainsFallback(check.target, text);
                    passed = res.passed;
                    snippet = res.snippet;
                    mode = 'summary_fallback';
                    reason = passed ? '[fallback] 结果摘要中找到目标字符串' : '[fallback] 结果摘要中未找到目标字符串';
                }
                break;
            }
            case 'regex': {
                if (check.targetPath) {
                    const res = await checkRegexEvidence(check.target, check.targetPath);
                    passed = res.passed;
                    snippet = res.snippet;
                    mode = 'evidence';
                    reason = passed
                        ? `[evidence] 文件内容匹配正则 (${check.targetPath})`
                        : `[evidence] 文件内容不匹配正则 (${check.targetPath})`;
                    hasEvidence = true;
                }
                else {
                    const res = checkRegexFallback(check.target, text);
                    passed = res.passed;
                    snippet = res.snippet;
                    mode = 'summary_fallback';
                    reason = passed ? '[fallback] 结果摘要匹配正则' : '[fallback] 结果摘要不匹配正则';
                }
                break;
            }
            case 'json_field': {
                if (check.targetPath) {
                    const res = await checkJsonFieldEvidence(check.target, check.value, check.targetPath);
                    passed = res.passed;
                    snippet = res.snippet;
                    mode = 'evidence';
                    reason = passed
                        ? `[evidence] JSON文件中字段验证通过 (${check.targetPath})`
                        : `[evidence] JSON文件中字段验证失败 (${check.targetPath})`;
                    hasEvidence = true;
                }
                else {
                    const res = checkJsonFieldFallback(check.target, check.value, text);
                    passed = res.passed;
                    snippet = res.snippet;
                    mode = 'summary_fallback';
                    reason = passed ? '[fallback] 结果摘要中提及JSON字段' : '[fallback] 结果摘要中未提及JSON字段';
                }
                break;
            }
            default:
                passed = false;
                snippet = `不支持的验收类型：${check.type}`;
                reason = snippet;
                mode = 'summary_fallback';
        }
        const severity = computeCheckSeverity(mode, passed);
        const evidenceRecord = {
            checkType: check.type,
            target: check.target,
            targetPath: check.targetPath,
            verificationMode: mode,
            passed,
            evidenceSnippet: snippet || undefined,
            reason,
            checkedAt: now,
            severity,
            autoGenerated: check.autoGenerated,
            generatedFrom: check.generatedFrom,
        };
        const detailPrefix = mode === 'evidence'
            ? (passed ? '✓ 硬验证' : '✗ 证据矛盾')
            : (passed ? '○ 软验证' : '○ 不可验');
        results.push({
            check,
            passed,
            detail: `[${label}] ${detailPrefix}：${snippet.slice(0, 80)}`,
            evidenceRecord,
            severity,
        });
    }
    const passedCount = results.filter(r => r.passed).length;
    const total = results.length;
    const allPassed = passedCount === total;
    const failures = results.filter(r => !r.passed).map(r => r.detail);
    const evidenceRecords = results.map(r => r.evidenceRecord);
    const dominantMode = hasEvidence ? 'evidence' : 'summary_fallback';
    const overallSeverity = aggregateSeverity(results);
    const severityLabel = overallSeverity === 'hard_verified' ? '硬验证'
        : overallSeverity === 'soft_verified' ? '软验证'
            : overallSeverity === 'contradicted' ? '证据矛盾'
                : '不可验证';
    const modeLabel = hasEvidence ? `证据验证(${severityLabel})` : `摘要验证(${severityLabel})`;
    const summary = allPassed
        ? `${modeLabel}全部通过（${total} 项）`
        : `${modeLabel}未通过 ${total - passedCount}/${total} 项：${failures.slice(0, 2).join('；')}`;
    return { results, passed: passedCount, total, allPassed, summary, failures, evidenceRecords, dominantMode, overallSeverity };
}
//# sourceMappingURL=acceptance.js.map