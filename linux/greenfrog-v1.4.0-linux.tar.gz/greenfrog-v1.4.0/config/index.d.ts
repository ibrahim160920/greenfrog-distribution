import { type EffectiveRole, type RoleGroup } from '../authz/roles.js';
/** Sentinel value returned by getPublicConfig() for set sensitive fields */
export declare const CONFIG_MASKED_SENTINEL = "__GF_MASKED__";
/** Shared relay/auth fields for all OpenAI-compatible providers */
export interface RelayProviderConfig {
    apiKey: string;
    model?: string;
    baseUrl?: string;
    authMode?: 'bearer' | 'apikey' | 'raw';
    authHeader?: string;
    authScheme?: string;
    extraHeaders?: Record<string, string>;
    disableResponseStorage?: boolean;
}
export interface GreenFrogConfig {
    dataDir: string;
    gateway: {
        port: number;
        host: string;
        secret: string;
    };
    webui: {
        port: number;
        host: string;
        enabled: boolean;
        publicBaseUrl?: string;
    };
    defaultProvider: 'anthropic' | 'openai' | 'ollama' | 'gemini' | 'mistral' | 'groq' | 'deepseek' | 'qwen' | 'kimi' | 'glm';
    defaultModel: string;
    providers: {
        anthropic?: {
            apiKey: string;
            model?: string;
            baseUrl?: string;
            /** Extra HTTP headers forwarded to the Anthropic SDK (e.g. for domestic relays) */
            extraHeaders?: Record<string, string>;
        };
        openai?: {
            apiKey: string;
            model?: string;
            baseUrl?: string;
            useResponsesApi?: boolean;
            reasoningEffort?: string;
            authMode?: 'bearer' | 'apikey' | 'raw';
            authHeader?: string;
            authScheme?: string;
            extraHeaders?: Record<string, string>;
            sendClientRequestId?: boolean;
            disableResponseStorage?: boolean;
            responsesMaxAttempts?: number;
            responsesRetryBaseDelayMs?: number;
        };
        ollama?: {
            baseUrl: string;
            model?: string;
        };
        gemini?: {
            apiKey: string;
            model?: string;
            /** Set to route through an OpenAI-compatible relay instead of the native Gemini SDK */
            baseUrl?: string;
            authMode?: 'bearer' | 'apikey' | 'raw';
            authHeader?: string;
            authScheme?: string;
            extraHeaders?: Record<string, string>;
            disableResponseStorage?: boolean;
        };
        mistral?: RelayProviderConfig;
        groq?: RelayProviderConfig;
        deepseek?: RelayProviderConfig;
        qwen?: RelayProviderConfig;
        kimi?: RelayProviderConfig;
        glm?: RelayProviderConfig;
    };
    channels: {
        telegram?: {
            enabled: boolean;
            token: string;
            allowedUsers?: string[];
        };
        discord?: {
            enabled: boolean;
            token: string;
            clientId?: string;
            allowedUsers?: string[];
        };
        slack?: {
            enabled: boolean;
            botToken: string;
            appToken: string;
            signingSecret: string;
            allowedUsers?: string[];
        };
        whatsapp?: {
            enabled: boolean;
            allowedUsers?: string[];
            /** Optional: group chat prefix to trigger bot (default: @mention only) */
            groupPrefix?: string;
        };
        wecom?: {
            enabled: boolean;
            /** 群机器人 Webhook URL (send-only; no corpId/appToken needed) */
            webhookUrl?: string;
            /** 自建应用 CorpID */
            corpId?: string;
            /** 自建应用 CorpSecret (encrypted at rest) */
            corpSecret?: string;
            /** 自建应用 AgentID */
            agentId?: string;
            /** 消息接收 Token (for signature verification) */
            token?: string;
            /** 消息加解密密钥 (43-char base64, encrypted at rest) */
            encodingAESKey?: string;
            /** Port for callback HTTP server (default: 18890) */
            callbackPort?: number;
            allowedUsers?: string[];
        };
        web?: {
            enabled: boolean;
            port?: number;
        };
        feishu?: {
            enabled: boolean;
            appId: string;
            appSecret: string;
            allowedUsers?: string[];
        };
        dingtalk?: {
            enabled: boolean;
            clientId: string;
            clientSecret: string;
            allowedUsers?: string[];
        };
        teams?: {
            enabled: boolean;
            appId: string;
            appPassword: string;
            /** Port for the Bot Framework webhook listener (default: 3979) */
            port?: number;
            allowedUsers?: string[];
        };
        line?: {
            enabled: boolean;
            channelAccessToken: string;
            channelSecret: string;
            /** Port for the Line webhook listener (default: 3980) */
            port?: number;
            allowedUsers?: string[];
        };
        matrix?: {
            enabled: boolean;
            homeserverUrl: string;
            accessToken: string;
            allowedUsers?: string[];
        };
    };
    sandbox?: {
        /** Whether to use Docker sandbox. Defaults to true when Docker is available. */
        enabled?: boolean;
        /** Docker image tag for the sandbox. Default: 'greenfrog-sandbox:latest' */
        image?: string;
        /** Memory limit per container in MB. Default: 128 */
        memoryMb?: number;
        /** CPU fraction per container (e.g. 0.5 = half a core). Default: 0.5 */
        cpuLimit?: number;
        /** PID limit per container (prevents fork bombs). Default: 64 */
        pidsLimit?: number;
        /** Disable network inside containers. Default: true */
        networkDisabled?: boolean;
        /** Auto-build sandbox image at startup if missing. Default: true */
        autoRebuildImage?: boolean;
        /**
         * What to do when Docker is unavailable and execution falls back to process/thread sandbox.
         * 'allow' — silently fall back (default, backward-compatible)
         * 'warn'  — fall back but log a warning per invocation
         * 'deny'  — refuse execution entirely when Docker is not available
         */
        fallbackPolicy?: 'allow' | 'warn' | 'deny';
    };
    skills: {
        weather?: {
            apiKey: string;
        };
        github?: {
            token: string;
        };
        news?: {
            apiKey: string;
        };
        search?: {
            apiKey: string;
        };
        wolfram?: {
            appId: string;
        };
    };
    tls?: {
        certFile?: string;
        keyFile?: string;
    };
    systemPrompt?: string;
    persona?: string;
    memory: {
        enabled: boolean;
        maxEntries: number;
        ttlDays: number;
        /** Ollama model name for embeddings (default: 'nomic-embed-text'). Set to '' to disable. */
        embeddingModel?: string;
    };
    roles?: {
        /**
         * Admin users: full access to all skills including shell, code execution,
         * skill_creator, git_ops, and multi_agent orchestration.
         * Format: "<channelName>:<userId>" or just "<userId>" (matches any channel).
         * Examples: "telegram:123456789", "web:abc123def456"
         */
        admin?: string[];
        /**
         * Regular users: access to most skills. Blocked from shell_exec, coding_agent,
         * skill_creator, and git_ops write operations.
         */
        user?: string[];
        /**
         * Read-only users: can only use: web_search, web_fetch, weather, news, calculator,
         * translate, timezone, qrcode, unit_convert, crypto_price, memory (read-only), notes (read), system_info.
         */
        readonly?: string[];
        /**
         * Group-based role grants for departments / teams.
         * Members use the same principal format as direct role lists.
         */
        groups?: Record<string, RoleGroup>;
        /**
         * Default role when a user is not in any list.
         * 'admin' = full access (original behavior, default when roles is not configured)
         * 'user'  = standard access (safe default for public instances)
         * 'readonly' = read-only
         * 'deny'  = block all (must be explicitly allowlisted)
         */
        defaultRole?: EffectiveRole;
    };
    log: {
        level: string;
        pretty: boolean;
    };
    /** Per-skill execution timeout in milliseconds. Default: 60000 (60s). */
    skillTimeoutMs?: number;
    /**
     * Maximum number of agentic loop iterations per message (tool-call cycles).
     * Increase for complex multi-step tasks. Default: 10.
     * Per-message override: set `agentMaxIterationsOverride` in IncomingMessage.metadata.
     */
    agentMaxIterations?: number;
    /**
     * Maximum wall-clock runtime per agent message in milliseconds.
     * Covers the full agent loop across provider calls and tool execution.
     * Default: 120000.
     * Per-message override: set `agentExecutionTimeoutMsOverride` in IncomingMessage.metadata.
     */
    agentMaxExecutionMs?: number;
    /** Maximum number of agent runs allowed concurrently in this process. Default: 4. */
    agentMaxConcurrency?: number;
    /** Maximum concurrent agent runs per end user identity. Default: 2. */
    agentMaxConcurrencyPerUser?: number;
    /**
     * Reserved total-token budget for hard quota pre-allocation.
     * Used to reduce check-then-record quota races. Default: 4096.
     */
    hardQuotaReservationTokens?: number;
    /** PostgreSQL connection (optional — uses SQLite when absent) */
    database?: {
        /** Full connection string, e.g. postgres://user:pass@host:5432/dbname */
        url: string;
        /** Max pool connections (default: 10) */
        poolMax?: number;
        /** Idle timeout in ms (default: 30000) */
        idleTimeoutMs?: number;
    };
    /** Prometheus metrics exposure */
    metrics?: {
        /** Whether to expose /metrics endpoint (default: false) */
        enabled?: boolean;
        /** Optional bearer token to protect /metrics (default: none) */
        token?: string;
    };
    /** Redis / BullMQ task queue */
    queue?: {
        /** Redis connection URL, e.g. redis://localhost:6379 (required to enable queue) */
        redisUrl?: string;
        /** Max concurrency for message-processing workers (default: 4) */
        concurrency?: number;
        /** Maximum waiting/active queue depth before new jobs are rejected. */
        maxPendingJobs?: number;
    };
    /** OAuth2 / OIDC authentication */
    auth?: {
        /** Whether OAuth2 login is enabled (default: false) */
        enabled?: boolean;
        /** OIDC issuer URL (e.g. https://accounts.google.com) */
        issuer?: string;
        /** OAuth2 client ID */
        clientId?: string;
        /** OAuth2 client secret */
        clientSecret?: string;
        /** Redirect URI registered with the provider */
        redirectUri?: string;
        /** JWT secret for signing session tokens (auto-generated if absent) */
        jwtSecret?: string;
        /** JWT expiry (default: '24h') */
        jwtExpiresIn?: string;
        /** Optional extra OIDC scopes, appended to the default openid/email/profile set */
        scopes?: string[];
        /** Claim name to read external group memberships from (default: "groups") */
        groupClaim?: string;
    };
    /** Project-level evolution and source-repo learning loop */
    evolution?: {
        projectMode?: 'off' | 'local' | 'source-owner';
        /**
         * Single-user mode: lowers evidence/workspace thresholds to realistic single-user levels
         * and disables all remote push/PR/auto-apply operations.
         * Enable with GF_EVOLUTION_SINGLE_USER=true.
         */
        singleUser?: boolean;
        ruleSync?: {
            enabled?: boolean;
            mode?: 'manual' | 'auto';
            uploadRules?: boolean;
            uploadStats?: boolean;
            anonymize?: boolean;
            reviewBeforeUpload?: boolean;
            remoteUrl?: string;
            accessToken?: string;
            syncIntervalHours?: number;
        };
        scheduler?: {
            enabled?: boolean;
            scoringIntervalHours?: number;
            uploadIntervalHours?: number;
            syncIntervalHours?: number;
            cleanupIntervalHours?: number;
            sourceRepoIntervalHours?: number;
            trackingCleanupDays?: number;
        };
        sourceRepo?: {
            enabled?: boolean;
            repoPath?: string;
            outputPath?: string;
            summaryPath?: string;
            minConfidence?: number;
            minEvidenceCount?: number;
            minWorkspaceCount?: number;
            autoCommit?: boolean;
            autoPush?: boolean;
            createPullRequest?: boolean;
            remote?: string;
            repo?: string;
            baseBranch?: string;
            headOwner?: string;
            pullRequestTitle?: string;
            branchPrefix?: string;
            commitMessage?: string;
        };
        codeRepo?: {
            enabled?: boolean;
            repoPath?: string;
            manifestPath?: string;
            summaryPath?: string;
            patchPath?: string;
            gateProfile?: 'strict' | 'balanced' | 'aggressive' | 'custom';
            autoGenerateCandidates?: boolean;
            generationLookbackDays?: number;
            generationMaxAuditEntries?: number;
            generationMaxCandidates?: number;
            generationMaxEvidencePerCandidate?: number;
            generationMaxFileContextChars?: number;
            generationMinEvidenceCount?: number;
            generationMinFailureCount?: number;
            generationMinSuccessCount?: number;
            generationProvider?: string;
            generationModel?: string;
            minDecisionScore?: number;
            minValidationCount?: number;
            minSuccessRate?: number;
            autoApplyPatch?: boolean;
            autoCommit?: boolean;
            autoPush?: boolean;
            createPullRequest?: boolean;
            remote?: string;
            repo?: string;
            baseBranch?: string;
            headOwner?: string;
            pullRequestTitle?: string;
            branchPrefix?: string;
            commitMessage?: string;
        };
        release?: {
            enabled?: boolean;
            repoPath?: string;
            manifestPath?: string;
            notesPath?: string;
            bump?: 'none' | 'patch' | 'minor' | 'major';
            approvalWindowStartHourUtc?: number;
            approvalWindowEndHourUtc?: number;
            approvedWeekdaysUtc?: number[];
            healthCheckCommands?: string[];
            minHealthChecksPassing?: number;
            autoCommit?: boolean;
            autoPush?: boolean;
            autoTag?: boolean;
            createGithubRelease?: boolean;
            remote?: string;
            repo?: string;
            baseBranch?: string;
            releaseTitle?: string;
            branchPrefix?: string;
            commitMessage?: string;
            tagPrefix?: string;
        };
        upgrade?: {
            enabled?: boolean;
            repoPath?: string;
            manifestPath?: string;
            remote?: string;
            baseBranch?: string;
            approvalWindowStartHourUtc?: number;
            approvalWindowEndHourUtc?: number;
            approvedWeekdaysUtc?: number[];
            rolloutPercentage?: number;
            rolloutSeed?: string;
            healthCheckCommands?: string[];
            minHealthChecksPassing?: number;
            verificationCommands?: string[];
            minVerificationChecksPassing?: number;
            autoRollbackOnVerificationFailure?: boolean;
            autoApply?: boolean;
            requireCleanWorkingTree?: boolean;
            installCommand?: string;
            buildCommand?: string;
            restartOnApply?: boolean;
        };
    };
}
declare class ConfigManager {
    private _config;
    private configPath;
    constructor();
    get(): GreenFrogConfig;
    getPublicConfig(): Record<string, unknown>;
    set(updates: Partial<GreenFrogConfig>): void;
    save(): void;
    get dataDir(): string;
}
export declare const configManager: ConfigManager;
export declare const config: GreenFrogConfig;
/**
 * Resolve the effective role for a user in a given channel.
 * Format checked: "channel:userId" first, then bare "userId".
 * Returns 'admin' if roles is not configured (backward-compat).
 */
export declare function resolveRole(userId: string, channel: string): 'admin' | 'user' | 'readonly' | 'deny';
export {};
//# sourceMappingURL=index.d.ts.map