/**
 * store_rule_tracking.ts — SQLite persistence for rule application stats (Sprint M4)
 *
 * Provides durable tracking of per-rule success/failure counts.
 * Survives process restarts — the in-memory ruleApplicationCache in rule_tracking.ts
 * is now populated from this table on first access.
 *
 * Table: rule_tracking_stats
 *   PK: (rule_id, workspace_id, channel)
 *   Columns: total_applications, successful_applications, failed_applications,
 *            last_used_at, created_at
 *
 * All writes are synchronous (better-sqlite3). The caller wraps in async to
 * match IMemoryStore async declarations.
 */
import type Database from 'better-sqlite3';
import type { ChannelName } from '../utils/types.js';
export interface PersistedRuleStats {
    ruleId: string;
    workspaceId: string;
    channel: string;
    totalApplications: number;
    successfulApplications: number;
    failedApplications: number;
    lastUsedAt: Date | null;
    createdAt: Date;
}
export declare function createRuleTrackingStore(db: Database.Database): {
    /**
     * Record a rule application event (upsert: +1 to total, +1 to success or failure).
     */
    upsertRuleTrackingStat(workspaceId: string, channel: ChannelName, ruleId: string, success: boolean): void;
    /**
     * Get persisted stats for a single rule in a workspace.
     * Returns null if this rule has never been tracked.
     */
    getPersistedRuleStats(workspaceId: string, channel: ChannelName, ruleId: string): PersistedRuleStats | null;
    /**
     * Get persisted stats for all rules in a workspace.
     * Returns a Map keyed by ruleId.
     */
    getAllPersistedRuleStats(workspaceId: string, channel: ChannelName): Map<string, PersistedRuleStats>;
};
export type RuleTrackingStore = ReturnType<typeof createRuleTrackingStore>;
//# sourceMappingURL=store_rule_tracking.d.ts.map