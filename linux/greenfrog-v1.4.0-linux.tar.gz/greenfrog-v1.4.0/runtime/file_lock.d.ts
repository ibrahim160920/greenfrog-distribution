export declare class FileLock {
    private fd;
    private lockPath;
    constructor(lockPath: string);
    /**
     * Acquire an exclusive lock on the file.
     * Throws if the lock is already held by another process.
     */
    acquire(): Promise<void>;
    /**
     * Release the lock and delete the lock file.
     */
    release(): Promise<void>;
    /**
     * Check if this instance currently holds the lock.
     */
    isHeld(): boolean;
}
export declare function getGlobalSqliteLock(lockPath: string): FileLock;
/**
 * Release global SQLite lock on process exit.
 */
export declare function setupLockCleanup(): void;
//# sourceMappingURL=file_lock.d.ts.map