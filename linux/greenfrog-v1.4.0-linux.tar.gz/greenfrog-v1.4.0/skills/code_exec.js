import { spawnSync } from 'child_process';
import { writeFileSync, unlinkSync, existsSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { nanoid } from 'nanoid';
import { BaseSkill } from './base.js';
import { dockerSandbox } from '../sandbox/docker.js';
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';
// Hard cap regardless of what the AI requests
const MAX_TIMEOUT_SECS = 60;
const log = createLogger('skill:code_exec');
/**
 * Run JavaScript in an isolated child process.
 *
 * Uses Node.js permission model (`--permission` in Node 22+,
 * `--experimental-permission` in Node 20-21) to deny filesystem and
 * network access by default.  Even without the permission flag,
 * subprocess isolation prevents prototype-chain escapes that can
 * compromise the parent process when using `vm.runInContext`.
 *
 * The wrapper intercepts console.* calls and returns their output as
 * JSON on stdout, which the parent then parses.
 */
function runJavaScriptSandboxed(code, timeoutMs) {
    // Determine which permission flag to use
    const nodeVer = parseInt(process.versions.node.split('.')[0], 10);
    // Node 22+ has stable --permission; older has --experimental-permission
    const permFlag = nodeVer >= 22 ? '--permission' : '--experimental-permission';
    // Wrap user code: intercept console, capture output, emit JSON to stdout.
    // Uses CJS eval mode — no top-level await, no import statements.
    const wrapper = `
const __out = [], __err = [];
const console = {
  log:   (...a) => __out.push(a.map(String).join(' ')),
  info:  (...a) => __out.push(a.map(String).join(' ')),
  warn:  (...a) => __err.push('[warn] '  + a.map(String).join(' ')),
  error: (...a) => __err.push('[error] ' + a.map(String).join(' ')),
  dir:   (x)   => __out.push(JSON.stringify(x, null, 2)),
  table: (x)   => __out.push(JSON.stringify(x, null, 2)),
};
try {
${code}
} catch (__e) {
  __err.push('Error: ' + String(__e));
}
process.stdout.write(JSON.stringify({ out: __out, err: __err }));
`.trim();
    // Try sandboxed execution first; fall back to plain subprocess on older nodes
    for (const args of [
        [permFlag, '--eval', wrapper],
        ['--eval', wrapper],
    ]) {
        const result = spawnSync(process.execPath, args, {
            timeout: timeoutMs,
            maxBuffer: 2 * 1024 * 1024, // 2 MB
            encoding: 'utf8',
            // Minimal environment — strip inherited PATH to prevent tool discovery
            env: { PATH: process.env.PATH ?? '' },
            shell: false,
        });
        // If the flag itself caused an error (unrecognised flag), try next args
        if (result.status !== 0 &&
            result.stderr &&
            (result.stderr.includes('bad option') ||
                result.stderr.includes('unrecognized') ||
                result.stderr.includes('Unknown'))) {
            continue;
        }
        if (result.error) {
            const code = result.error.code;
            if (code === 'ETIMEDOUT' || code === 'ESRCH') {
                throw new Error(`Execution timeout (>${timeoutMs / 1000}s)`);
            }
            throw result.error;
        }
        try {
            const parsed = JSON.parse(result.stdout);
            const lines = [...parsed.out, ...parsed.err];
            return lines.join('\n') || '(no output)';
        }
        catch {
            // stdout wasn't JSON — surface raw output (e.g. syntax errors printed before wrapper ran)
            const out = [result.stdout, result.stderr].filter(Boolean).join('\n').trim();
            return out || '(no output)';
        }
    }
    return '(sandbox unavailable)';
}
export class CodeExecSkill extends BaseSkill {
    definition = {
        name: 'execute_code',
        description: 'Execute code in JavaScript, Python, or Bash. Returns stdout/stderr output.',
        category: 'development',
        parameters: [
            {
                name: 'language',
                type: 'string',
                description: 'Programming language to use',
                required: true,
                enum: ['javascript', 'python', 'bash', 'shell'],
            },
            { name: 'code', type: 'string', description: 'Code to execute', required: true },
            { name: 'timeout', type: 'number', description: `Execution timeout in seconds (default: 30, max: ${MAX_TIMEOUT_SECS})`, default: 30 },
        ],
        examples: ['Run this Python code', 'Execute this bash script', 'Calculate with JS'],
    };
    async execute(params, _ctx) {
        const language = params.language;
        const code = params.code;
        // Enforce hard cap — AI cannot request more than MAX_TIMEOUT_SECS
        const timeoutSecs = Math.min(params.timeout ?? 30, MAX_TIMEOUT_SECS);
        const timeoutMs = timeoutSecs * 1000;
        // ── Docker container sandbox (preferred) ─────────────────────────────────
        if (await dockerSandbox.isAvailable()) {
            try {
                const output = await dockerSandbox.runCode(language, code, timeoutMs);
                if (language === 'javascript' || output.startsWith('Exit code')) {
                    return this.text(`\`\`\`\n${output}\n\`\`\``);
                }
                return this.text(`\`\`\`\n${output}\n\`\`\``);
            }
            catch (err) {
                const msg = err instanceof Error ? err.message : String(err);
                // If "Unsupported language" fall through to legacy path
                if (msg.includes('Unsupported language')) {
                    return this.err(msg);
                }
                return this.text(`❌ Execution error:\n\`\`\`\n${msg}\n\`\`\``);
            }
        }
        // ── Fallback policy check ─────────────────────────────────────────────
        const fallbackPolicy = config.sandbox?.fallbackPolicy ?? 'allow';
        const fallbackWarning = dockerSandbox.getFallbackWarning();
        if (fallbackWarning) {
            if (fallbackPolicy === 'deny') {
                return this.err('Docker sandbox is required but unavailable. Code execution denied by fallbackPolicy=deny.');
            }
            if (fallbackPolicy === 'warn') {
                log.warn({ language }, 'Docker unavailable — falling back to process sandbox');
            }
        }
        // ── Fallback: JavaScript — sandboxed via isolated child process ──────────
        if (language === 'javascript') {
            try {
                const output = runJavaScriptSandboxed(code, timeoutMs);
                return this.text(`\`\`\`\n${output}\n\`\`\``);
            }
            catch (err) {
                const msg = err instanceof Error ? err.message : String(err);
                return this.text(`❌ JavaScript error:\n\`\`\`\n${msg}\n\`\`\``);
            }
        }
        // ── Fallback: Python / Bash — subprocess with minimal environment ────────
        const tmpFile = join(tmpdir(), `greenfrog_${nanoid()}`);
        /** Minimal env that allows the interpreter to run but strips API keys etc. */
        const minimalEnv = {
            PATH: process.env.PATH ?? (process.platform === 'win32' ? 'C:\\Windows\\System32' : '/usr/local/bin:/usr/bin:/bin'),
            TEMP: process.env.TEMP ?? tmpdir(),
            TMP: process.env.TMP ?? tmpdir(),
            TMPDIR: process.env.TMPDIR ?? tmpdir(),
            // Python needs HOME for certain fallbacks; provide tmpdir instead
            HOME: tmpdir(),
            // On Windows, Python/node need SYSTEMROOT
            ...(process.platform === 'win32' && process.env.SYSTEMROOT
                ? { SYSTEMROOT: process.env.SYSTEMROOT, SYSTEMDRIVE: process.env.SYSTEMDRIVE ?? 'C:' }
                : {}),
        };
        try {
            let executable;
            let args;
            let filePath;
            // On Unix, prepend resource limits to constrain the fallback subprocess
            // ulimit -v 131072 : 128 MB virtual memory
            // ulimit -t 30     : 30 s CPU time
            // ulimit -f 10240  : 10 MB max file size
            const ulimitPrefix = process.platform !== 'win32'
                ? 'ulimit -v 131072 -t 30 -f 10240 2>/dev/null; '
                : '';
            switch (language) {
                case 'python': {
                    filePath = `${tmpFile}.py`;
                    writeFileSync(filePath, code, 'utf8');
                    executable = process.platform === 'win32' ? 'python' : 'python3';
                    if (ulimitPrefix) {
                        // Wrap through bash so ulimit takes effect
                        args = ['-c', `${ulimitPrefix}${executable} -E -S -B "${filePath}"`];
                        executable = 'bash';
                    }
                    else {
                        args = ['-E', '-S', '-B', filePath];
                    }
                    break;
                }
                case 'bash':
                case 'shell': {
                    filePath = `${tmpFile}.sh`;
                    writeFileSync(filePath, code, 'utf8');
                    if (ulimitPrefix) {
                        executable = 'bash';
                        args = ['-c', `${ulimitPrefix}bash --norc --noprofile -e "${filePath}"`];
                    }
                    else {
                        executable = 'bash';
                        args = ['--norc', '--noprofile', '-e', filePath];
                    }
                    break;
                }
                default:
                    return this.err(`Unsupported language: ${language}`);
            }
            const result = spawnSync(executable, args, {
                timeout: timeoutMs,
                encoding: 'utf8',
                maxBuffer: 1024 * 1024, // 1 MB
                shell: false,
                env: minimalEnv,
            });
            if (result.error) {
                const errCode = result.error.code;
                if (errCode === 'ETIMEDOUT')
                    return this.err(`Execution timeout (>${timeoutSecs}s)`);
                if (errCode === 'ENOENT')
                    return this.err(`Interpreter not found: ${executable}`);
                return this.err(`Execution error: ${String(result.error)}`);
            }
            const stdout = (result.stdout ?? '').trim();
            const stderr = (result.stderr ?? '').trim();
            const combined = [stdout, stderr].filter(Boolean).join('\n');
            if (result.status !== 0) {
                return this.text(`Exit code ${result.status ?? 1}:\n\`\`\`\n${combined || 'No output'}\n\`\`\``);
            }
            return this.text(`\`\`\`\n${combined || '(no output)'}\n\`\`\``);
        }
        finally {
            for (const ext of ['', '.py', '.sh']) {
                const f = `${tmpFile}${ext}`;
                if (existsSync(f)) {
                    try {
                        unlinkSync(f);
                    }
                    catch { /* best-effort cleanup */ }
                }
            }
        }
    }
}
//# sourceMappingURL=code_exec.js.map