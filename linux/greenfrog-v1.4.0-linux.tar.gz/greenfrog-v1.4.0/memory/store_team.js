import { nanoid } from 'nanoid';
import { hydrateTeamTopology, mergeTeamTopologyMetadata } from '../utils/team_topology.js';
import { publishTeamRuntimeWakeup } from '../runtime/team_runtime_wakeup.js';
function mapTeamTaskRow(row) {
    return {
        id: row['id'],
        workspaceId: row['workspace_id'],
        title: row['title'],
        description: row['description'],
        status: row['status'],
        priority: row['priority'],
        assignedAgentId: row['assigned_agent_id'] || null,
        dependsOnTaskIds: row['depends_on_task_ids'] ? JSON.parse(row['depends_on_task_ids']) : [],
        reviewRequired: Boolean(row['review_required']),
        reviewerAgentId: row['reviewer_agent_id'] || null,
        reviewStatus: row['review_status'] ?? 'not_required',
        attemptCount: Number(row['attempt_count'] ?? 0),
        maxAttempts: Math.max(1, Number(row['max_attempts'] ?? 1)),
        lastAttemptAt: row['last_attempt_at'] ? new Date(row['last_attempt_at']) : null,
        escalationStatus: row['escalation_status'] ?? 'none',
        escalationReason: row['escalation_reason'] || null,
        humanOwnerUserId: row['human_owner_user_id'] || null,
        blockedReason: row['blocked_reason'] || null,
        createdBy: row['created_by'],
        resultSummary: row['result_summary'] || null,
        dueAt: row['due_at'] ? new Date(row['due_at']) : null,
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    };
}
function mapTeamPolicyRow(row) {
    const metadata = row['metadata'] ? JSON.parse(row['metadata']) : undefined;
    const autoPropagateLearnings = typeof metadata?.['autoPropagateLearnings'] === 'boolean'
        ? metadata['autoPropagateLearnings']
        : true;
    const autoGovernLearnedRules = typeof metadata?.['autoGovernLearnedRules'] === 'boolean'
        ? metadata['autoGovernLearnedRules']
        : typeof metadata?.['ruleLibraryAutoGovernanceEnabled'] === 'boolean'
            ? metadata['ruleLibraryAutoGovernanceEnabled']
            : false;
    return {
        workspaceId: row['workspace_id'],
        autoDispatch: Boolean(row['auto_dispatch']),
        autoReview: Boolean(row['auto_review']),
        maxAutoRetries: Number(row['max_auto_retries'] ?? 1),
        escalateOnBlocked: Boolean(row['escalate_on_blocked']),
        escalateOnReviewChanges: Boolean(row['escalate_on_review_changes']),
        escalateOnSlaBreach: Boolean(row['escalate_on_sla_breach']),
        autoShareTaskResults: Boolean(row['auto_share_task_results']),
        autoPropagateLearnings,
        autoGovernLearnedRules,
        sharedMemoryPrefix: row['shared_memory_prefix'] || 'team:',
        defaultTaskSlaHours: Number(row['default_task_sla_hours'] ?? 24),
        defaultHumanOwnerUserId: row['default_human_owner_user_id'] || null,
        approvalReminderAfterMinutes: Number(row['approval_reminder_after_minutes'] ?? 30),
        approvalEscalationAfterMinutes: Number(row['approval_escalation_after_minutes'] ?? 120),
        onCallAssignmentTimeoutMinutes: Number(row['oncall_assignment_timeout_minutes'] ?? 10),
        onCallMaxHandoffsPerTask: Number(row['oncall_max_handoffs_per_task'] ?? 4),
        escalationOwnerUserId: row['escalation_owner_user_id'] || null,
        updatedBy: row['updated_by'],
        metadata,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    };
}
function mapTeamTaskApprovalRow(row) {
    return {
        id: row['id'],
        workspaceId: row['workspace_id'],
        taskId: row['task_id'],
        status: row['status'],
        requestedBy: row['requested_by'],
        requestedForUserId: row['requested_for_user_id'],
        reason: row['reason'],
        resolutionNotes: row['resolution_notes'] || null,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
        resolvedAt: row['resolved_at'] ? new Date(row['resolved_at']) : null,
    };
}
function mapTeamTemplateRow(row) {
    return {
        id: row['id'],
        workspaceId: row['workspace_id'],
        name: row['name'],
        description: row['description'] || undefined,
        department: row['department'] || null,
        role: row['role'] || null,
        goalTemplate: row['goal_template'] || null,
        variables: row['variables'] ? JSON.parse(row['variables']) : [],
        taskBlueprints: row['task_blueprints']
            ? JSON.parse(row['task_blueprints'])
            : [],
        createdBy: row['created_by'],
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    };
}
function mapTeamTopologyRow(row) {
    return hydrateTeamTopology({
        id: row['id'],
        workspaceId: row['workspace_id'],
        name: row['name'],
        department: row['department'] || null,
        role: row['role'] || null,
        supervisorAgentId: row['supervisor_agent_id'] || null,
        workerAgentIds: row['worker_agent_ids'] ? JSON.parse(row['worker_agent_ids']) : [],
        defaultTemplateIds: row['default_template_ids'] ? JSON.parse(row['default_template_ids']) : [],
        defaultHumanOwnerUserId: row['default_human_owner_user_id'] || null,
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdBy: row['created_by'],
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    });
}
function mapTeamNotificationRow(row) {
    return {
        id: row['id'],
        workspaceId: row['workspace_id'],
        recipientUserId: row['recipient_user_id'],
        type: row['type'],
        severity: row['severity'],
        status: row['status'],
        deliveryStatus: row['delivery_status'] ?? 'pending',
        deliveryAttemptCount: Number(row['delivery_attempt_count'] ?? 0),
        title: row['title'],
        message: row['message'],
        taskId: row['task_id'] || null,
        approvalId: row['approval_id'] || null,
        lastDeliveryError: row['last_delivery_error'] || null,
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
        readAt: row['read_at'] ? new Date(row['read_at']) : null,
        lastDeliveryAttemptAt: row['last_delivery_attempt_at'] ? new Date(row['last_delivery_attempt_at']) : null,
        deliveredAt: row['delivered_at'] ? new Date(row['delivered_at']) : null,
    };
}
function mapTeamNotificationRouteRow(row) {
    return {
        id: row['id'],
        workspaceId: row['workspace_id'],
        recipientUserId: row['recipient_user_id'],
        channel: row['channel'],
        chatId: row['chat_id'],
        enabled: Boolean(row['enabled']),
        createdBy: row['created_by'],
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    };
}
function mapTeamMailboxMessageRow(row) {
    return {
        id: row['id'],
        workspaceId: row['workspace_id'],
        threadId: row['thread_id'],
        dedupeKey: row['dedupe_key'] || null,
        senderAgentId: row['sender_agent_id'] || null,
        senderUserId: row['sender_user_id'] || null,
        recipientAgentId: row['recipient_agent_id'] || null,
        taskId: row['task_id'] || null,
        type: row['type'] ?? 'direct',
        status: row['status'] ?? 'pending',
        subject: row['subject'] || null,
        message: row['message'],
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
        acknowledgedAt: row['acknowledged_at'] ? new Date(row['acknowledged_at']) : null,
    };
}
function mapTeamOnCallRotationRow(row) {
    return {
        id: row['id'],
        workspaceId: row['workspace_id'],
        name: row['name'],
        enabled: Boolean(row['enabled']),
        scheduleType: row['schedule_type'] ?? 'daily',
        anchorDate: new Date(row['anchor_date']),
        department: row['department'] || null,
        role: row['role'] || null,
        primaryAgentIds: row['primary_agent_ids'] ? JSON.parse(row['primary_agent_ids']) : [],
        secondaryAgentIds: row['secondary_agent_ids'] ? JSON.parse(row['secondary_agent_ids']) : [],
        createdBy: row['created_by'],
        metadata: row['metadata'] ? JSON.parse(row['metadata']) : undefined,
        createdAt: new Date(row['created_at']),
        updatedAt: new Date(row['updated_at']),
    };
}
export function createTeamStore(db) {
    const api = {
        createTeamTask(task) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO team_tasks (
           id, workspace_id, title, description, status, priority, assigned_agent_id,
           depends_on_task_ids, review_required, reviewer_agent_id, review_status,
           attempt_count, max_attempts, last_attempt_at, escalation_status, escalation_reason, human_owner_user_id, blocked_reason,
           created_by, result_summary, due_at, metadata, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, task.workspaceId, task.title, task.description ?? null, task.status ?? (task.assignedAgentId ? 'claimed' : 'open'), task.priority ?? 'medium', task.assignedAgentId ?? null, JSON.stringify(task.dependsOnTaskIds ?? []), task.reviewRequired ? 1 : 0, task.reviewerAgentId ?? null, task.reviewStatus ?? (task.reviewRequired ? 'pending' : 'not_required'), task.attemptCount ?? 0, Math.max(1, task.maxAttempts ?? 1), task.lastAttemptAt ? task.lastAttemptAt.getTime() : null, task.escalationStatus ?? 'none', task.escalationReason ?? null, task.humanOwnerUserId ?? null, task.blockedReason ?? null, task.createdBy, task.resultSummary ?? null, task.dueAt ? task.dueAt.getTime() : null, task.metadata ? JSON.stringify(task.metadata) : null, now, now);
            const row = db.prepare(`SELECT * FROM team_tasks WHERE id = ?`).get(id);
            const created = mapTeamTaskRow(row);
            publishTeamRuntimeWakeup({
                kind: 'task_created',
                workspaceId: created.workspaceId,
                taskId: created.id,
                assignedAgentId: created.assignedAgentId,
                status: created.status,
            });
            return created;
        },
        getTeamTask(id) {
            const row = db.prepare(`SELECT * FROM team_tasks WHERE id = ?`).get(id);
            return row ? mapTeamTaskRow(row) : null;
        },
        listTeamTasks(filter) {
            const conditions = [];
            const args = [];
            if (filter?.workspaceId) {
                conditions.push('workspace_id = ?');
                args.push(filter.workspaceId);
            }
            if (filter?.status) {
                conditions.push('status = ?');
                args.push(filter.status);
            }
            if (filter?.assignedAgentId) {
                conditions.push('assigned_agent_id = ?');
                args.push(filter.assignedAgentId);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const rows = db.prepare(`SELECT * FROM team_tasks ${where} ORDER BY updated_at DESC, created_at DESC`).all(...args);
            return rows.map((row) => mapTeamTaskRow(row));
        },
        updateTeamTask(id, updates) {
            if (!api.getTeamTask(id))
                return null;
            const sets = [];
            const args = [];
            if (updates.title !== undefined) {
                sets.push('title = ?');
                args.push(updates.title);
            }
            if (updates.description !== undefined) {
                sets.push('description = ?');
                args.push(updates.description);
            }
            if (updates.status !== undefined) {
                sets.push('status = ?');
                args.push(updates.status);
            }
            if (updates.priority !== undefined) {
                sets.push('priority = ?');
                args.push(updates.priority);
            }
            if (updates.assignedAgentId !== undefined) {
                sets.push('assigned_agent_id = ?');
                args.push(updates.assignedAgentId);
            }
            if (updates.dependsOnTaskIds !== undefined) {
                sets.push('depends_on_task_ids = ?');
                args.push(JSON.stringify(updates.dependsOnTaskIds));
            }
            if (updates.reviewRequired !== undefined) {
                sets.push('review_required = ?');
                args.push(updates.reviewRequired ? 1 : 0);
            }
            if (updates.reviewerAgentId !== undefined) {
                sets.push('reviewer_agent_id = ?');
                args.push(updates.reviewerAgentId);
            }
            if (updates.reviewStatus !== undefined) {
                sets.push('review_status = ?');
                args.push(updates.reviewStatus);
            }
            if (updates.attemptCount !== undefined) {
                sets.push('attempt_count = ?');
                args.push(updates.attemptCount);
            }
            if (updates.maxAttempts !== undefined) {
                sets.push('max_attempts = ?');
                args.push(Math.max(1, updates.maxAttempts));
            }
            if (updates.lastAttemptAt !== undefined) {
                sets.push('last_attempt_at = ?');
                args.push(updates.lastAttemptAt ? updates.lastAttemptAt.getTime() : null);
            }
            if (updates.escalationStatus !== undefined) {
                sets.push('escalation_status = ?');
                args.push(updates.escalationStatus);
            }
            if (updates.escalationReason !== undefined) {
                sets.push('escalation_reason = ?');
                args.push(updates.escalationReason);
            }
            if (updates.humanOwnerUserId !== undefined) {
                sets.push('human_owner_user_id = ?');
                args.push(updates.humanOwnerUserId);
            }
            if (updates.blockedReason !== undefined) {
                sets.push('blocked_reason = ?');
                args.push(updates.blockedReason);
            }
            if (updates.resultSummary !== undefined) {
                sets.push('result_summary = ?');
                args.push(updates.resultSummary);
            }
            if (updates.dueAt !== undefined) {
                sets.push('due_at = ?');
                args.push(updates.dueAt ? updates.dueAt.getTime() : null);
            }
            if (updates.metadata !== undefined) {
                sets.push('metadata = ?');
                args.push(JSON.stringify(updates.metadata));
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_tasks SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            const updated = api.getTeamTask(id);
            if (updated) {
                publishTeamRuntimeWakeup({
                    kind: 'task_updated',
                    workspaceId: updated.workspaceId,
                    taskId: updated.id,
                    assignedAgentId: updated.assignedAgentId,
                    status: updated.status,
                });
            }
            return updated;
        },
        deleteTeamTask(id) {
            const result = db.prepare(`DELETE FROM team_tasks WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        getTeamPolicy(workspaceId) {
            const row = db.prepare(`SELECT * FROM team_policies WHERE workspace_id = ?`).get(workspaceId);
            return row ? mapTeamPolicyRow(row) : null;
        },
        upsertTeamPolicy(policy) {
            const existing = api.getTeamPolicy(policy.workspaceId);
            const now = Date.now();
            db.prepare(`INSERT INTO team_policies (
           workspace_id, auto_dispatch, auto_review, max_auto_retries, escalate_on_blocked, escalate_on_review_changes,
           escalate_on_sla_breach, auto_share_task_results, shared_memory_prefix, default_task_sla_hours, default_human_owner_user_id,
           approval_reminder_after_minutes, approval_escalation_after_minutes, oncall_assignment_timeout_minutes, oncall_max_handoffs_per_task, escalation_owner_user_id,
           updated_by, metadata, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(workspace_id) DO UPDATE SET
           auto_dispatch = excluded.auto_dispatch,
           auto_review = excluded.auto_review,
           max_auto_retries = excluded.max_auto_retries,
           escalate_on_blocked = excluded.escalate_on_blocked,
           escalate_on_review_changes = excluded.escalate_on_review_changes,
           escalate_on_sla_breach = excluded.escalate_on_sla_breach,
           auto_share_task_results = excluded.auto_share_task_results,
           shared_memory_prefix = excluded.shared_memory_prefix,
           default_task_sla_hours = excluded.default_task_sla_hours,
           default_human_owner_user_id = excluded.default_human_owner_user_id,
           approval_reminder_after_minutes = excluded.approval_reminder_after_minutes,
           approval_escalation_after_minutes = excluded.approval_escalation_after_minutes,
           oncall_assignment_timeout_minutes = excluded.oncall_assignment_timeout_minutes,
           oncall_max_handoffs_per_task = excluded.oncall_max_handoffs_per_task,
           escalation_owner_user_id = excluded.escalation_owner_user_id,
           updated_by = excluded.updated_by,
           metadata = excluded.metadata,
           updated_at = excluded.updated_at`).run(policy.workspaceId, (policy.autoDispatch ?? existing?.autoDispatch ?? true) ? 1 : 0, (policy.autoReview ?? existing?.autoReview ?? true) ? 1 : 0, Math.max(0, policy.maxAutoRetries ?? existing?.maxAutoRetries ?? 1), (policy.escalateOnBlocked ?? existing?.escalateOnBlocked ?? true) ? 1 : 0, (policy.escalateOnReviewChanges ?? existing?.escalateOnReviewChanges ?? true) ? 1 : 0, (policy.escalateOnSlaBreach ?? existing?.escalateOnSlaBreach ?? true) ? 1 : 0, (policy.autoShareTaskResults ?? existing?.autoShareTaskResults ?? false) ? 1 : 0, (policy.sharedMemoryPrefix ?? existing?.sharedMemoryPrefix ?? 'team:').slice(0, 64), Math.max(1, policy.defaultTaskSlaHours ?? existing?.defaultTaskSlaHours ?? 24), policy.defaultHumanOwnerUserId ?? existing?.defaultHumanOwnerUserId ?? null, Math.max(1, policy.approvalReminderAfterMinutes ?? existing?.approvalReminderAfterMinutes ?? 30), Math.max(1, policy.approvalEscalationAfterMinutes ?? existing?.approvalEscalationAfterMinutes ?? 120), Math.max(1, policy.onCallAssignmentTimeoutMinutes ?? existing?.onCallAssignmentTimeoutMinutes ?? 10), Math.max(1, policy.onCallMaxHandoffsPerTask ?? existing?.onCallMaxHandoffsPerTask ?? 4), policy.escalationOwnerUserId ?? existing?.escalationOwnerUserId ?? null, policy.updatedBy, (() => {
                const merged = {
                    ...(existing?.metadata ?? {}),
                    ...(policy.metadata ?? {}),
                };
                if (policy.autoPropagateLearnings !== undefined) {
                    merged['autoPropagateLearnings'] = policy.autoPropagateLearnings;
                }
                if (policy.autoGovernLearnedRules !== undefined) {
                    merged['autoGovernLearnedRules'] = policy.autoGovernLearnedRules;
                    merged['ruleLibraryAutoGovernanceEnabled'] = policy.autoGovernLearnedRules;
                }
                return Object.keys(merged).length > 0 ? JSON.stringify(merged) : null;
            })(), existing?.createdAt.getTime() ?? now, now);
            return api.getTeamPolicy(policy.workspaceId);
        },
        createTeamTaskApproval(approval) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO team_task_approvals (
           id, workspace_id, task_id, status, requested_by, requested_for_user_id, reason, resolution_notes, created_at, updated_at, resolved_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, approval.workspaceId, approval.taskId, approval.status ?? 'pending', approval.requestedBy, approval.requestedForUserId, approval.reason, approval.resolutionNotes ?? null, now, now, approval.resolvedAt ? approval.resolvedAt.getTime() : null);
            const created = mapTeamTaskApprovalRow(db.prepare(`SELECT * FROM team_task_approvals WHERE id = ?`).get(id));
            publishTeamRuntimeWakeup({
                kind: 'approval_created',
                workspaceId: created.workspaceId,
                approvalId: created.id,
                taskId: created.taskId,
                status: created.status,
            });
            return created;
        },
        listTeamTaskApprovals(filter) {
            const conditions = [];
            const args = [];
            if (filter?.workspaceId) {
                conditions.push('workspace_id = ?');
                args.push(filter.workspaceId);
            }
            if (filter?.taskId) {
                conditions.push('task_id = ?');
                args.push(filter.taskId);
            }
            if (filter?.status) {
                conditions.push('status = ?');
                args.push(filter.status);
            }
            if (filter?.requestedForUserId) {
                conditions.push('requested_for_user_id = ?');
                args.push(filter.requestedForUserId);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const rows = db.prepare(`SELECT * FROM team_task_approvals ${where} ORDER BY updated_at DESC, created_at DESC`).all(...args);
            return rows.map((row) => mapTeamTaskApprovalRow(row));
        },
        updateTeamTaskApproval(id, updates) {
            const existing = db.prepare(`SELECT * FROM team_task_approvals WHERE id = ?`).get(id);
            if (!existing)
                return null;
            const sets = [];
            const args = [];
            if (updates.status !== undefined) {
                sets.push('status = ?');
                args.push(updates.status);
            }
            if (updates.resolutionNotes !== undefined) {
                sets.push('resolution_notes = ?');
                args.push(updates.resolutionNotes);
            }
            if (updates.resolvedAt !== undefined) {
                sets.push('resolved_at = ?');
                args.push(updates.resolvedAt ? updates.resolvedAt.getTime() : null);
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_task_approvals SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            const updated = mapTeamTaskApprovalRow(db.prepare(`SELECT * FROM team_task_approvals WHERE id = ?`).get(id));
            publishTeamRuntimeWakeup({
                kind: 'approval_updated',
                workspaceId: updated.workspaceId,
                approvalId: updated.id,
                taskId: updated.taskId,
                status: updated.status,
            });
            return updated;
        },
        createTeamNotification(notification) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO team_notifications (
           id, workspace_id, recipient_user_id, type, severity, status, delivery_status, delivery_attempt_count,
           title, message, task_id, approval_id, last_delivery_error, metadata, created_at, updated_at, read_at, last_delivery_attempt_at, delivered_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, notification.workspaceId, notification.recipientUserId, notification.type, notification.severity ?? 'info', notification.status ?? 'unread', notification.deliveryStatus ?? 'pending', notification.deliveryAttemptCount ?? 0, notification.title, notification.message, notification.taskId ?? null, notification.approvalId ?? null, notification.lastDeliveryError ?? null, notification.metadata ? JSON.stringify(notification.metadata) : null, now, now, notification.readAt ? notification.readAt.getTime() : null, notification.lastDeliveryAttemptAt ? notification.lastDeliveryAttemptAt.getTime() : null, notification.deliveredAt ? notification.deliveredAt.getTime() : null);
            return mapTeamNotificationRow(db.prepare(`SELECT * FROM team_notifications WHERE id = ?`).get(id));
        },
        listTeamNotifications(filter) {
            const conditions = [];
            const args = [];
            if (filter?.workspaceId) {
                conditions.push('workspace_id = ?');
                args.push(filter.workspaceId);
            }
            if (filter?.recipientUserId) {
                conditions.push('recipient_user_id = ?');
                args.push(filter.recipientUserId);
            }
            if (filter?.status) {
                conditions.push('status = ?');
                args.push(filter.status);
            }
            if (filter?.deliveryStatus) {
                conditions.push('delivery_status = ?');
                args.push(filter.deliveryStatus);
            }
            if (filter?.type) {
                conditions.push('type = ?');
                args.push(filter.type);
            }
            if (filter?.taskId) {
                conditions.push('task_id = ?');
                args.push(filter.taskId);
            }
            if (filter?.approvalId) {
                conditions.push('approval_id = ?');
                args.push(filter.approvalId);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const rows = db.prepare(`SELECT * FROM team_notifications ${where} ORDER BY updated_at DESC, created_at DESC`).all(...args);
            return rows.map((row) => mapTeamNotificationRow(row));
        },
        updateTeamNotification(id, updates) {
            const existing = db.prepare(`SELECT * FROM team_notifications WHERE id = ?`).get(id);
            if (!existing)
                return null;
            const sets = [];
            const args = [];
            if (updates.status !== undefined) {
                sets.push('status = ?');
                args.push(updates.status);
            }
            if (updates.deliveryStatus !== undefined) {
                sets.push('delivery_status = ?');
                args.push(updates.deliveryStatus);
            }
            if (updates.deliveryAttemptCount !== undefined) {
                sets.push('delivery_attempt_count = ?');
                args.push(updates.deliveryAttemptCount);
            }
            if (updates.title !== undefined) {
                sets.push('title = ?');
                args.push(updates.title);
            }
            if (updates.message !== undefined) {
                sets.push('message = ?');
                args.push(updates.message);
            }
            if (updates.lastDeliveryError !== undefined) {
                sets.push('last_delivery_error = ?');
                args.push(updates.lastDeliveryError);
            }
            if (updates.metadata !== undefined) {
                sets.push('metadata = ?');
                args.push(JSON.stringify(updates.metadata));
            }
            if (updates.readAt !== undefined) {
                sets.push('read_at = ?');
                args.push(updates.readAt ? updates.readAt.getTime() : null);
            }
            if (updates.lastDeliveryAttemptAt !== undefined) {
                sets.push('last_delivery_attempt_at = ?');
                args.push(updates.lastDeliveryAttemptAt ? updates.lastDeliveryAttemptAt.getTime() : null);
            }
            if (updates.deliveredAt !== undefined) {
                sets.push('delivered_at = ?');
                args.push(updates.deliveredAt ? updates.deliveredAt.getTime() : null);
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_notifications SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            return mapTeamNotificationRow(db.prepare(`SELECT * FROM team_notifications WHERE id = ?`).get(id));
        },
        createTeamNotificationRoute(route) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO team_notification_routes (
           id, workspace_id, recipient_user_id, channel, chat_id, enabled, created_by, metadata, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, route.workspaceId, route.recipientUserId, route.channel, route.chatId, route.enabled === false ? 0 : 1, route.createdBy, route.metadata ? JSON.stringify(route.metadata) : null, now, now);
            return mapTeamNotificationRouteRow(db.prepare(`SELECT * FROM team_notification_routes WHERE id = ?`).get(id));
        },
        listTeamNotificationRoutes(filter) {
            const conditions = [];
            const args = [];
            if (filter?.workspaceId) {
                conditions.push('workspace_id = ?');
                args.push(filter.workspaceId);
            }
            if (filter?.recipientUserId) {
                conditions.push('recipient_user_id = ?');
                args.push(filter.recipientUserId);
            }
            if (filter?.channel) {
                conditions.push('channel = ?');
                args.push(filter.channel);
            }
            if (filter?.enabled !== undefined) {
                conditions.push('enabled = ?');
                args.push(filter.enabled ? 1 : 0);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const rows = db.prepare(`SELECT * FROM team_notification_routes ${where} ORDER BY updated_at DESC, created_at DESC`).all(...args);
            return rows.map((row) => mapTeamNotificationRouteRow(row));
        },
        getTeamNotificationRoute(id) {
            const row = db.prepare(`SELECT * FROM team_notification_routes WHERE id = ?`).get(id);
            return row ? mapTeamNotificationRouteRow(row) : null;
        },
        updateTeamNotificationRoute(id, updates) {
            if (!api.getTeamNotificationRoute(id))
                return null;
            const sets = [];
            const args = [];
            if (updates.recipientUserId !== undefined) {
                sets.push('recipient_user_id = ?');
                args.push(updates.recipientUserId);
            }
            if (updates.channel !== undefined) {
                sets.push('channel = ?');
                args.push(updates.channel);
            }
            if (updates.chatId !== undefined) {
                sets.push('chat_id = ?');
                args.push(updates.chatId);
            }
            if (updates.enabled !== undefined) {
                sets.push('enabled = ?');
                args.push(updates.enabled ? 1 : 0);
            }
            if (updates.metadata !== undefined) {
                sets.push('metadata = ?');
                args.push(JSON.stringify(updates.metadata));
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_notification_routes SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            return api.getTeamNotificationRoute(id);
        },
        deleteTeamNotificationRoute(id) {
            const result = db.prepare(`DELETE FROM team_notification_routes WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        createTeamMailboxMessage(message) {
            const now = Date.now();
            const dedupeKey = message.dedupeKey?.trim() || null;
            if (dedupeKey) {
                const existing = db.prepare(`SELECT * FROM team_mailbox_messages
           WHERE workspace_id = ? AND dedupe_key = ?
           ORDER BY updated_at DESC
           LIMIT 1`).get(message.workspaceId, dedupeKey);
                if (existing) {
                    return mapTeamMailboxMessageRow(existing);
                }
            }
            const id = nanoid();
            const threadId = message.threadId?.trim() || `thread:${message.workspaceId}:${id}`;
            db.prepare(`INSERT INTO team_mailbox_messages (
           id, workspace_id, thread_id, dedupe_key, sender_agent_id, sender_user_id, recipient_agent_id, task_id,
           type, status, subject, message, metadata, acknowledged_at, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, message.workspaceId, threadId, dedupeKey, message.senderAgentId ?? null, message.senderUserId ?? null, message.recipientAgentId ?? null, message.taskId ?? null, message.type ?? 'direct', message.status ?? 'pending', message.subject ?? null, message.message, message.metadata ? JSON.stringify(message.metadata) : null, message.acknowledgedAt ? message.acknowledgedAt.getTime() : null, now, now);
            const created = mapTeamMailboxMessageRow(db.prepare(`SELECT * FROM team_mailbox_messages WHERE id = ?`).get(id));
            publishTeamRuntimeWakeup({
                kind: 'mailbox_created',
                workspaceId: created.workspaceId,
                messageId: created.id,
                recipientAgentId: created.recipientAgentId,
                taskId: created.taskId,
                status: created.status,
            });
            return created;
        },
        listTeamMailboxMessages(filter) {
            const conditions = [];
            const args = [];
            if (filter?.workspaceId) {
                conditions.push('workspace_id = ?');
                args.push(filter.workspaceId);
            }
            if (filter?.threadId) {
                conditions.push('thread_id = ?');
                args.push(filter.threadId);
            }
            if (filter?.dedupeKey) {
                conditions.push('dedupe_key = ?');
                args.push(filter.dedupeKey);
            }
            if (filter?.senderAgentId) {
                conditions.push('sender_agent_id = ?');
                args.push(filter.senderAgentId);
            }
            if (filter?.recipientAgentId) {
                conditions.push('(recipient_agent_id = ? OR recipient_agent_id IS NULL)');
                args.push(filter.recipientAgentId);
            }
            if (filter?.taskId) {
                conditions.push('task_id = ?');
                args.push(filter.taskId);
            }
            if (filter?.type) {
                conditions.push('type = ?');
                args.push(filter.type);
            }
            if (filter?.status) {
                conditions.push('status = ?');
                args.push(filter.status);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const rows = db.prepare(`SELECT * FROM team_mailbox_messages ${where} ORDER BY created_at DESC, updated_at DESC`).all(...args);
            return rows.map((row) => mapTeamMailboxMessageRow(row));
        },
        updateTeamMailboxMessage(id, updates) {
            const existing = db.prepare(`SELECT * FROM team_mailbox_messages WHERE id = ?`).get(id);
            if (!existing)
                return null;
            const sets = [];
            const args = [];
            if (updates.status !== undefined) {
                sets.push('status = ?');
                args.push(updates.status);
            }
            if (updates.subject !== undefined) {
                sets.push('subject = ?');
                args.push(updates.subject);
            }
            if (updates.message !== undefined) {
                sets.push('message = ?');
                args.push(updates.message);
            }
            if (updates.metadata !== undefined) {
                sets.push('metadata = ?');
                args.push(JSON.stringify(updates.metadata));
            }
            if (updates.acknowledgedAt !== undefined) {
                sets.push('acknowledged_at = ?');
                args.push(updates.acknowledgedAt ? updates.acknowledgedAt.getTime() : null);
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_mailbox_messages SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            const updated = mapTeamMailboxMessageRow(db.prepare(`SELECT * FROM team_mailbox_messages WHERE id = ?`).get(id));
            publishTeamRuntimeWakeup({
                kind: 'mailbox_updated',
                workspaceId: updated.workspaceId,
                messageId: updated.id,
                recipientAgentId: updated.recipientAgentId,
                taskId: updated.taskId,
                status: updated.status,
            });
            return updated;
        },
        createTeamOnCallRotation(rotation) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO team_oncall_rotations (
           id, workspace_id, name, enabled, schedule_type, anchor_date, department, role,
           primary_agent_ids, secondary_agent_ids, created_by, metadata, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, rotation.workspaceId, rotation.name, rotation.enabled === false ? 0 : 1, rotation.scheduleType ?? 'daily', (rotation.anchorDate ?? new Date()).getTime(), rotation.department ?? null, rotation.role ?? null, JSON.stringify(rotation.primaryAgentIds ?? []), JSON.stringify(rotation.secondaryAgentIds ?? []), rotation.createdBy, rotation.metadata ? JSON.stringify(rotation.metadata) : null, now, now);
            return mapTeamOnCallRotationRow(db.prepare(`SELECT * FROM team_oncall_rotations WHERE id = ?`).get(id));
        },
        listTeamOnCallRotations(filter) {
            const conditions = [];
            const args = [];
            if (filter?.workspaceId) {
                conditions.push('workspace_id = ?');
                args.push(filter.workspaceId);
            }
            if (filter?.enabled !== undefined) {
                conditions.push('enabled = ?');
                args.push(filter.enabled ? 1 : 0);
            }
            if (filter?.department) {
                conditions.push('department = ?');
                args.push(filter.department);
            }
            if (filter?.role) {
                conditions.push('role = ?');
                args.push(filter.role);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const rows = db.prepare(`SELECT * FROM team_oncall_rotations ${where} ORDER BY updated_at DESC, created_at DESC`).all(...args);
            return rows.map((row) => mapTeamOnCallRotationRow(row));
        },
        getTeamOnCallRotation(id) {
            const row = db.prepare(`SELECT * FROM team_oncall_rotations WHERE id = ?`).get(id);
            return row ? mapTeamOnCallRotationRow(row) : null;
        },
        updateTeamOnCallRotation(id, updates) {
            if (!api.getTeamOnCallRotation(id))
                return null;
            const sets = [];
            const args = [];
            if (updates.name !== undefined) {
                sets.push('name = ?');
                args.push(updates.name);
            }
            if (updates.enabled !== undefined) {
                sets.push('enabled = ?');
                args.push(updates.enabled ? 1 : 0);
            }
            if (updates.scheduleType !== undefined) {
                sets.push('schedule_type = ?');
                args.push(updates.scheduleType);
            }
            if (updates.anchorDate !== undefined) {
                sets.push('anchor_date = ?');
                args.push(updates.anchorDate.getTime());
            }
            if (updates.department !== undefined) {
                sets.push('department = ?');
                args.push(updates.department);
            }
            if (updates.role !== undefined) {
                sets.push('role = ?');
                args.push(updates.role);
            }
            if (updates.primaryAgentIds !== undefined) {
                sets.push('primary_agent_ids = ?');
                args.push(JSON.stringify(updates.primaryAgentIds));
            }
            if (updates.secondaryAgentIds !== undefined) {
                sets.push('secondary_agent_ids = ?');
                args.push(JSON.stringify(updates.secondaryAgentIds));
            }
            if (updates.metadata !== undefined) {
                sets.push('metadata = ?');
                args.push(JSON.stringify(updates.metadata));
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_oncall_rotations SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            return api.getTeamOnCallRotation(id);
        },
        deleteTeamOnCallRotation(id) {
            const result = db.prepare(`DELETE FROM team_oncall_rotations WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        createTeamTemplate(template) {
            const now = Date.now();
            const id = nanoid();
            db.prepare(`INSERT INTO team_templates (
           id, workspace_id, name, description, department, role, goal_template, variables, task_blueprints, created_by, metadata, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, template.workspaceId, template.name, template.description ?? null, template.department ?? null, template.role ?? null, template.goalTemplate ?? null, JSON.stringify(template.variables ?? []), JSON.stringify(template.taskBlueprints ?? []), template.createdBy, template.metadata ? JSON.stringify(template.metadata) : null, now, now);
            return mapTeamTemplateRow(db.prepare(`SELECT * FROM team_templates WHERE id = ?`).get(id));
        },
        listTeamTemplates(workspaceId) {
            const rows = (workspaceId
                ? db.prepare(`SELECT * FROM team_templates WHERE workspace_id = ? ORDER BY updated_at DESC, created_at DESC`).all(workspaceId)
                : db.prepare(`SELECT * FROM team_templates ORDER BY updated_at DESC, created_at DESC`).all());
            return rows.map((row) => mapTeamTemplateRow(row));
        },
        getTeamTemplate(id) {
            const row = db.prepare(`SELECT * FROM team_templates WHERE id = ?`).get(id);
            return row ? mapTeamTemplateRow(row) : null;
        },
        updateTeamTemplate(id, updates) {
            if (!api.getTeamTemplate(id))
                return null;
            const sets = [];
            const args = [];
            if (updates.name !== undefined) {
                sets.push('name = ?');
                args.push(updates.name);
            }
            if (updates.description !== undefined) {
                sets.push('description = ?');
                args.push(updates.description);
            }
            if (updates.department !== undefined) {
                sets.push('department = ?');
                args.push(updates.department);
            }
            if (updates.role !== undefined) {
                sets.push('role = ?');
                args.push(updates.role);
            }
            if (updates.goalTemplate !== undefined) {
                sets.push('goal_template = ?');
                args.push(updates.goalTemplate);
            }
            if (updates.variables !== undefined) {
                sets.push('variables = ?');
                args.push(JSON.stringify(updates.variables));
            }
            if (updates.taskBlueprints !== undefined) {
                sets.push('task_blueprints = ?');
                args.push(JSON.stringify(updates.taskBlueprints));
            }
            if (updates.metadata !== undefined) {
                sets.push('metadata = ?');
                args.push(JSON.stringify(updates.metadata));
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_templates SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            return api.getTeamTemplate(id);
        },
        deleteTeamTemplate(id) {
            const result = db.prepare(`DELETE FROM team_templates WHERE id = ?`).run(id);
            return result.changes > 0;
        },
        createTeamTopology(topology) {
            const now = Date.now();
            const id = nanoid();
            const metadata = mergeTeamTopologyMetadata(topology.metadata, {
                ...(Object.prototype.hasOwnProperty.call(topology, 'orchestratorRules')
                    ? { orchestratorRules: topology.orchestratorRules ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(topology, 'adaptiveModelPolicy')
                    ? { adaptiveModelPolicy: topology.adaptiveModelPolicy ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(topology, 'modelRoutes')
                    ? { modelRoutes: topology.modelRoutes ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(topology, 'candidateStrategy')
                    ? { candidateStrategy: topology.candidateStrategy ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(topology, 'candidateRolloutPolicy')
                    ? { candidateRolloutPolicy: topology.candidateRolloutPolicy ?? null }
                    : {}),
                ...(Object.prototype.hasOwnProperty.call(topology, 'candidateRolloutControl')
                    ? { candidateRolloutControl: topology.candidateRolloutControl ?? null }
                    : {}),
            }, {
                nowIso: new Date(now).toISOString(),
            });
            db.prepare(`INSERT INTO team_topologies (
           id, workspace_id, name, department, role, supervisor_agent_id, worker_agent_ids, default_template_ids,
           default_human_owner_user_id, metadata, created_by, created_at, updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, topology.workspaceId, topology.name, topology.department ?? null, topology.role ?? null, topology.supervisorAgentId ?? null, JSON.stringify(topology.workerAgentIds ?? []), JSON.stringify(topology.defaultTemplateIds ?? []), topology.defaultHumanOwnerUserId ?? null, metadata ? JSON.stringify(metadata) : null, topology.createdBy, now, now);
            return mapTeamTopologyRow(db.prepare(`SELECT * FROM team_topologies WHERE id = ?`).get(id));
        },
        listTeamTopologies(workspaceId) {
            const rows = (workspaceId
                ? db.prepare(`SELECT * FROM team_topologies WHERE workspace_id = ? ORDER BY updated_at DESC, created_at DESC`).all(workspaceId)
                : db.prepare(`SELECT * FROM team_topologies ORDER BY updated_at DESC, created_at DESC`).all());
            return rows.map((row) => mapTeamTopologyRow(row));
        },
        getTeamTopology(id) {
            const row = db.prepare(`SELECT * FROM team_topologies WHERE id = ?`).get(id);
            return row ? mapTeamTopologyRow(row) : null;
        },
        updateTeamTopology(id, updates) {
            const existing = api.getTeamTopology(id);
            if (!existing)
                return null;
            const sets = [];
            const args = [];
            if (updates.name !== undefined) {
                sets.push('name = ?');
                args.push(updates.name);
            }
            if (updates.department !== undefined) {
                sets.push('department = ?');
                args.push(updates.department);
            }
            if (updates.role !== undefined) {
                sets.push('role = ?');
                args.push(updates.role);
            }
            if (updates.supervisorAgentId !== undefined) {
                sets.push('supervisor_agent_id = ?');
                args.push(updates.supervisorAgentId);
            }
            if (updates.workerAgentIds !== undefined) {
                sets.push('worker_agent_ids = ?');
                args.push(JSON.stringify(updates.workerAgentIds));
            }
            if (updates.defaultTemplateIds !== undefined) {
                sets.push('default_template_ids = ?');
                args.push(JSON.stringify(updates.defaultTemplateIds));
            }
            if (updates.defaultHumanOwnerUserId !== undefined) {
                sets.push('default_human_owner_user_id = ?');
                args.push(updates.defaultHumanOwnerUserId);
            }
            const hasTopologyConfigUpdate = Object.prototype.hasOwnProperty.call(updates, 'orchestratorRules')
                || Object.prototype.hasOwnProperty.call(updates, 'adaptiveModelPolicy')
                || Object.prototype.hasOwnProperty.call(updates, 'modelRoutes')
                || Object.prototype.hasOwnProperty.call(updates, 'candidateStrategy')
                || Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutPolicy')
                || Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutControl');
            if (updates.metadata !== undefined || hasTopologyConfigUpdate) {
                const mergedMetadata = mergeTeamTopologyMetadata(updates.metadata !== undefined ? updates.metadata : existing.metadata, {
                    ...(Object.prototype.hasOwnProperty.call(updates, 'orchestratorRules')
                        ? { orchestratorRules: updates.orchestratorRules ?? null }
                        : {}),
                    ...(Object.prototype.hasOwnProperty.call(updates, 'adaptiveModelPolicy')
                        ? { adaptiveModelPolicy: updates.adaptiveModelPolicy ?? null }
                        : {}),
                    ...(Object.prototype.hasOwnProperty.call(updates, 'modelRoutes')
                        ? { modelRoutes: updates.modelRoutes ?? null }
                        : {}),
                    ...(Object.prototype.hasOwnProperty.call(updates, 'candidateStrategy')
                        ? { candidateStrategy: updates.candidateStrategy ?? null }
                        : {}),
                    ...(Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutPolicy')
                        ? { candidateRolloutPolicy: updates.candidateRolloutPolicy ?? null }
                        : {}),
                    ...(Object.prototype.hasOwnProperty.call(updates, 'candidateRolloutControl')
                        ? { candidateRolloutControl: updates.candidateRolloutControl ?? null }
                        : {}),
                }, {
                    existingTopology: existing,
                    nowIso: new Date().toISOString(),
                });
                sets.push('metadata = ?');
                args.push(mergedMetadata ? JSON.stringify(mergedMetadata) : null);
            }
            sets.push('updated_at = ?');
            args.push(Date.now(), id);
            db.prepare(`UPDATE team_topologies SET ${sets.join(', ')} WHERE id = ?`).run(...args);
            return api.getTeamTopology(id);
        },
        deleteTeamTopology(id) {
            const result = db.prepare(`DELETE FROM team_topologies WHERE id = ?`).run(id);
            return result.changes > 0;
        },
    };
    return api;
}
//# sourceMappingURL=store_team.js.map