import { createLogger } from '../utils/logger.js';
import { memoryStore } from './store.js';
import { compressBehavioralRulesIfNeeded } from './rule_compressor.js';
const log = createLogger('memory:rule-maintenance');
function readPositiveIntEnv(name, fallback, min = 1, max = Number.MAX_SAFE_INTEGER) {
    const raw = Number.parseInt(process.env[name] ?? '', 10);
    if (!Number.isFinite(raw))
        return fallback;
    return Math.min(max, Math.max(min, raw));
}
export const RULE_MAINTENANCE_INTERVAL_MS = readPositiveIntEnv('BEHAVIORAL_RULE_MAINTENANCE_INTERVAL_MS', 30 * 60 * 1000, 60_000, 24 * 60 * 60 * 1000);
export const RULE_MAINTENANCE_STARTUP_DELAY_MS = readPositiveIntEnv('BEHAVIORAL_RULE_MAINTENANCE_STARTUP_DELAY_MS', 2 * 60 * 1000, 5_000, 60 * 60 * 1000);
export const RULE_MAINTENANCE_SCOPE_LIMIT = readPositiveIntEnv('BEHAVIORAL_RULE_MAINTENANCE_SCOPE_LIMIT', 200, 1, 2_000);
const maintenanceOverview = {
    running: false,
    intervalMs: RULE_MAINTENANCE_INTERVAL_MS,
    startupDelayMs: RULE_MAINTENANCE_STARTUP_DELAY_MS,
    scopeLimit: RULE_MAINTENANCE_SCOPE_LIMIT,
    cycleCount: 0,
    lastStartedAt: null,
    lastFinishedAt: null,
    lastDurationMs: null,
    lastError: null,
    lastCycle: {
        discoveredScopes: 0,
        processedScopes: 0,
        scopesWithChanges: 0,
        scopesWithErrors: 0,
        decayedRules: 0,
        deletedRules: 0,
        compressionAttempts: 0,
        compressedScopes: 0,
        compressionCooldownSkips: 0,
        rulesBeforeCompression: 0,
        rulesAfterCompression: 0,
    },
    ruleSummary: {
        totalRules: 0,
        compressedRules: 0,
        avgConfidence: 0,
        lowConfidenceRules: 0,
        staleRules: 0,
        distinctScopes: 0,
    },
};
let maintenancePromise = null;
function toScope(entry) {
    return {
        userId: entry.userId,
        channel: entry.channel,
        ...(entry.workspaceId ? { workspaceId: entry.workspaceId } : {}),
        ...(entry.agentId ? { agentId: entry.agentId } : {}),
    };
}
export function getBehavioralRuleMaintenanceOverview() {
    return JSON.parse(JSON.stringify(maintenanceOverview));
}
export async function runBehavioralRuleMaintenanceCycle(opts) {
    if (maintenancePromise)
        return maintenancePromise;
    maintenancePromise = (async () => {
        const startedAt = new Date();
        maintenanceOverview.running = true;
        maintenanceOverview.lastStartedAt = startedAt.toISOString();
        maintenanceOverview.lastError = null;
        const scopeLimit = opts?.scopeLimit ?? RULE_MAINTENANCE_SCOPE_LIMIT;
        const cycle = {
            discoveredScopes: 0,
            processedScopes: 0,
            scopesWithChanges: 0,
            scopesWithErrors: 0,
            decayedRules: 0,
            deletedRules: 0,
            compressionAttempts: 0,
            compressedScopes: 0,
            compressionCooldownSkips: 0,
            rulesBeforeCompression: 0,
            rulesAfterCompression: 0,
        };
        try {
            const scopes = await memoryStore.listBehavioralRuleScopes(scopeLimit);
            cycle.discoveredScopes = scopes.length;
            for (const entry of scopes) {
                const scope = toScope(entry);
                try {
                    const decay = await memoryStore.decayScopedBehavioralRules(scope);
                    const compression = await compressBehavioralRulesIfNeeded(scope, {
                        provider: opts?.provider ?? undefined,
                        model: opts?.model ?? undefined,
                    });
                    cycle.processedScopes += 1;
                    cycle.decayedRules += decay.updated;
                    cycle.deletedRules += decay.deleted;
                    cycle.compressionAttempts += compression.attempted ? 1 : 0;
                    cycle.compressedScopes += compression.compressed ? 1 : 0;
                    cycle.compressionCooldownSkips += compression.cooldownSkipped ? 1 : 0;
                    cycle.rulesBeforeCompression += compression.before;
                    cycle.rulesAfterCompression += compression.after;
                    if (decay.updated > 0 || decay.deleted > 0 || compression.compressed) {
                        cycle.scopesWithChanges += 1;
                    }
                }
                catch (err) {
                    cycle.scopesWithErrors += 1;
                    log.warn({ err: String(err), scope }, 'Behavioral rule maintenance failed for scope');
                }
            }
            maintenanceOverview.ruleSummary = await memoryStore.summarizeBehavioralRules();
            maintenanceOverview.cycleCount += 1;
            maintenanceOverview.lastCycle = cycle;
            maintenanceOverview.lastFinishedAt = new Date().toISOString();
            maintenanceOverview.lastDurationMs = Date.now() - startedAt.getTime();
            log.info({
                discoveredScopes: cycle.discoveredScopes,
                processedScopes: cycle.processedScopes,
                decayedRules: cycle.decayedRules,
                deletedRules: cycle.deletedRules,
                compressedScopes: cycle.compressedScopes,
                durationMs: maintenanceOverview.lastDurationMs,
            }, 'Behavioral rule maintenance cycle completed');
            return getBehavioralRuleMaintenanceOverview();
        }
        catch (err) {
            maintenanceOverview.lastError = String(err);
            maintenanceOverview.lastCycle = cycle;
            maintenanceOverview.lastFinishedAt = new Date().toISOString();
            maintenanceOverview.lastDurationMs = Date.now() - startedAt.getTime();
            log.error({ err }, 'Behavioral rule maintenance cycle failed');
            return getBehavioralRuleMaintenanceOverview();
        }
        finally {
            maintenanceOverview.running = false;
            maintenancePromise = null;
        }
    })();
    return maintenancePromise;
}
//# sourceMappingURL=rule_maintenance.js.map