import { providerRegistry } from '../providers/index.js';
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('memory:challenge-reflection');
const CHALLENGE_REFLECTION_SYSTEM = `You are extracting a behavioral rule from a peer challenge outcome in an AI agent team.
An agent produced work that was challenged and rejected by peer review.
Extract exactly one actionable behavioral rule that would prevent this mistake in future.

Output ONLY JSON: {"rule":"concise imperative instruction (max 120 chars)","category":"style|format|content|tone|workflow","confidence":60-90}

Rules:
- Focus on the root cause, not the symptom
- Rule must be actionable and specific, not generic ("be careful")
- Use "workflow" for process/reasoning errors, "content" for factual/accuracy errors
- Use "style" or "format" for output quality issues`;
export async function runChallengeReflectionSafe(params) {
    if (!params.challengedAgentId || params.objections.length === 0)
        return;
    try {
        await runChallengeReflection(params);
    }
    catch (err) {
        log.warn({ err: String(err), agentId: params.challengedAgentId }, 'Challenge reflection failed');
    }
}
async function runChallengeReflection(params) {
    const prompt = [
        `Task: ${params.taskTitle}`,
        params.taskDescription ? `Description: ${params.taskDescription.slice(0, 300)}` : null,
        params.taskResult ? `Agent output: ${params.taskResult.slice(0, 400)}` : null,
        `Peer objections:\n${params.objections.map((o, i) => `[${i + 1}] ${o}`).join('\n')}`,
        '\nExtract one behavioral rule to prevent this mistake:',
    ].filter(Boolean).join('\n\n');
    const res = await providerRegistry.chatWithFallback({
        messages: [{ role: 'user', content: prompt }],
        systemPrompt: CHALLENGE_REFLECTION_SYSTEM,
        maxTokens: 200,
        temperature: 0.2,
        ...(params.model ? { model: params.model } : {}),
    }, params.provider ?? undefined);
    const match = (res.content ?? '').match(/\{[\s\S]*\}/);
    if (!match)
        return;
    const parsed = JSON.parse(match[0]);
    const rule = typeof parsed.rule === 'string' ? parsed.rule.trim().slice(0, 120) : '';
    const category = typeof parsed.category === 'string' ? parsed.category : '';
    const validCategories = new Set(['style', 'format', 'content', 'tone', 'workflow']);
    if (!rule || !validCategories.has(category))
        return;
    const confidence = Math.min(90, Math.max(60, typeof parsed.confidence === 'number' ? parsed.confidence : 70));
    const agentScope = {
        userId: params.userId,
        channel: params.channel,
        workspaceId: params.workspaceId,
        agentId: params.challengedAgentId,
    };
    memoryStore.upsertScopedBehavioralRule(agentScope, { rule, category, confidence, source: 'challenge' });
    log.info({ workspaceId: params.workspaceId, agentId: params.challengedAgentId, rule }, 'Challenge reflection: rule written to challenged agent');
    if (params.propagateToTeam) {
        const teamScope = {
            userId: params.userId,
            channel: params.channel,
            workspaceId: params.workspaceId,
        };
        memoryStore.upsertScopedBehavioralRule(teamScope, {
            rule,
            category,
            confidence: Math.max(60, confidence - 10),
            source: 'challenge_propagated',
        });
        log.info({ workspaceId: params.workspaceId, rule }, 'Challenge reflection: rule propagated to workspace');
    }
}
//# sourceMappingURL=challenge_reflection.js.map