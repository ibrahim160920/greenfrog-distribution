/**
 * Automatic memory extraction — two parallel pipelines:
 *
 * 1. USER FACT EXTRACTION
 *    After every substantive turn: extracts profile/tech/pref/context facts
 *    the user revealed about themselves.
 *
 * 2. CORRECTION LEARNING
 *    When the user corrects the AI: detects the correction, extracts what was
 *    wrong and what the right answer is, and persists it permanently so the
 *    same mistake is never repeated on similar topics.
 *
 * Both pipelines are fire-and-forget — they never block the response to the user.
 */
import { providerRegistry } from '../providers/index.js';
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
import { getAllScopedMemoryForContext, getScopedMemoryForContext, setScopedMemoryForContext, deleteScopedMemoryForContext, } from './scoped.js';
import { extractionQueue, calculatePriority } from './extraction_queue.js';
import { nanoid } from 'nanoid';
const log = createLogger('memory:extractor');
function scopeCtx(userId, channel, scope) {
    return {
        userId,
        channel,
        workspaceId: scope?.workspaceId ?? undefined,
        agentId: scope?.agentId ?? undefined,
    };
}
function historyScope(userId, channel, scope) {
    return scope ?? { userId, channel };
}
// ─────────────────────────────────────────────────────────────────────────────
// Pipeline 1: User Fact Extraction
// ─────────────────────────────────────────────────────────────────────────────
const FACT_SYSTEM_PROMPT = `You extract factual information about the USER from a short conversation excerpt.
Output ONLY a valid JSON object with string values. Return {} if nothing notable was found.

Allowed key prefixes (use snake_case after the colon):
  profile:   → name, occupation, location, timezone, age
  tech:      → languages, frameworks, tools, os, editor
  pref:      → response_style (brief|detailed), units (metric|imperial), theme (dark|light)
  context:   → project, company, goal, team_size

Rules:
- Extract ONLY facts the user explicitly stated. Never infer or guess.
- Values must be concise (under 80 chars). Comma-separate multiple items.
- Skip any key already listed under "Existing memory" with the same value.
- Return {} for greetings, short confirmations ("ok", "thanks"), or vague inputs.
- Do NOT include anything about the assistant's behaviour.
- For each fact, include a "_confidence" field (0.0-1.0) indicating how certain you are.
- Only include facts where confidence >= 0.7.`;
function buildFactPrompt(exchange, existing) {
    return `Existing memory:\n${existing || '(none)'}\n\nConversation:\n${exchange}\n\nJSON:`;
}
// ─────────────────────────────────────────────────────────────────────────────
// Pipeline 2: Correction Learning
// ─────────────────────────────────────────────────────────────────────────────
/**
 * Signals that indicate the user is correcting a previous AI statement.
 * Covers Chinese, English, and common mixed usage.
 */
const CORRECTION_SIGNALS_RE = /不对|错了|不是|你错了|不正确|纠正|应该是|实际上|其实|准确|说错|搞错|弄错|不对劲|有误|有错|更正|wrong|incorrect|that'?s not|actually,|no,\s|mistake|should be|the correct|not right|you said.*but|i meant|to clarify/i;
const CORRECTION_SYSTEM_PROMPT = `You analyze a conversation where the USER is correcting a previous AI response.

Your job: extract exactly what the AI got wrong and what the correct information is.

Output JSON with these keys:
  topic:      A stable snake_case slug describing the subject (max 35 chars, e.g. "python_async_io", "date_format_iso", "git_rebase_usage")
  was_wrong:  Brief description of what the AI stated incorrectly (max 120 chars)
  correct:    The correct information, approach, or fact (max 180 chars)

Return {} if:
- This is NOT a genuine factual or technical correction (e.g. user is just unhappy with tone)
- The correction is too vague to extract a clear right answer
- The user is expressing displeasure without stating the correct answer`;
function buildCorrectionPrompt(prevAiMsg, userCorrection) {
    return (`Previous AI response that was corrected:\n"${prevAiMsg.slice(0, 400)}"\n\n` +
        `User's correction:\n"${userCorrection.slice(0, 600)}"\n\nJSON:`);
}
// ─────────────────────────────────────────────────────────────────────────────
// Memory Poisoning Defense & Hallucination Guards
// ─────────────────────────────────────────────────────────────────────────────
export const INJECTION_PATTERNS = [
    /ignore\s+(all\s+)?previous\s+instructions/i,
    /^system\s*:/i,
    /^IMPORTANT\s*:/i,
    /you\s+are\s+now/i,
    /forget\s+(all|everything)/i,
    /new\s+instructions?\s*:/i,
];
export function sanitizeExtractedValue(value) {
    let clean = value.trim().slice(0, 120);
    for (const pattern of INJECTION_PATTERNS) {
        if (pattern.test(clean)) {
            return ''; // reject the entire value
        }
    }
    return clean;
}
export function isValidFactValue(value) {
    // Reject code-like values
    if (/[{}<>].*[{}<>]/.test(value) && value.length > 30)
        return false;
    // Reject values that are too long (already handled by truncation, but double-check)
    if (value.length > 120)
        return false;
    // Reject empty
    if (!value.trim())
        return false;
    return true;
}
/** Pending facts for high-impact key protection (requires 2+ turns to overwrite) */
export const pendingFacts = new Map();
const HIGH_IMPACT_KEYS = new Set(['profile:name', 'profile:location', 'profile:occupation']);
export async function shouldPersistHighImpactFact(userId, channel, key, value, memoryScope) {
    if (!HIGH_IMPACT_KEYS.has(key))
        return true;
    const existing = await getScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), key);
    if (!existing)
        return true; // No existing value, safe to set
    const pendingKey = `${userId}:${channel}:${key}`;
    const pending = pendingFacts.get(pendingKey);
    if (pending && pending.value === value.toLowerCase().trim()) {
        pending.count++;
        if (pending.count >= 2) {
            pendingFacts.delete(pendingKey);
            return true; // Confirmed in 2+ turns
        }
        return false;
    }
    // New pending value
    pendingFacts.set(pendingKey, { value: value.toLowerCase().trim(), count: 1, firstSeen: Date.now() });
    return false;
}
// ─────────────────────────────────────────────────────────────────────────────
// Pipeline 4: Implicit Feedback Detection
// ─────────────────────────────────────────────────────────────────────────────
/**
 * Detects implicit feedback signals from user messages without requiring
 * explicit ratings. Covers frustration, satisfaction, and confusion patterns.
 */
// Negative signals (score -1 or -2)
const FRUSTRATION_RE = /不是这个意思|你没有理解|重新|再来一次|再试|完全不对|搞错了|不对劲|你理解错了|答非所问|跑题了|废话|没用|太长了|太啰嗦|简短|不需要这么多|你在说什么|听不懂|what do you mean|that's not what i|try again|completely wrong|not helpful|missed the point|too long|too verbose/i;
const MILD_NEGATIVE_RE = /不太对|有点偏|不够准确|不完全是|差一点|换个方式|换种说法|能不能简单点|能精简|重新解释|not quite|not exactly|rephrase|could you simplify|simpler please/i;
// Positive signals (score +1 or +2)
const STRONG_POSITIVE_RE = /完美|太棒了|正是|就是这个|非常好|很好|很棒|太好了|谢谢，就是这个|完全正确|exactly|perfect|that's exactly|great job|excellent|this is what i needed|spot on/i;
const MILD_POSITIVE_RE = /好的|谢谢|不错|可以|明白了|理解了|ok thanks|got it|makes sense|thank you|that helps/i;
// Rephrase/clarification requests
const REPHRASE_RE = /换个说法|换一种|用更简单的|举个例子|能举例|比如说|能不能再详细|更具体|more specific|can you elaborate|for example|give me an example/i;
function detectFeedback(userMessage) {
    const msg = userMessage.trim();
    // Skip very short messages — insufficient signal
    if (msg.length < 4)
        return null;
    if (FRUSTRATION_RE.test(msg))
        return { feedbackType: 'negative', signal: 'frustration', score: -2 };
    if (MILD_NEGATIVE_RE.test(msg))
        return { feedbackType: 'negative', signal: 'mild_negative', score: -1 };
    if (STRONG_POSITIVE_RE.test(msg))
        return { feedbackType: 'positive', signal: 'strong_positive', score: 2 };
    if (MILD_POSITIVE_RE.test(msg))
        return { feedbackType: 'positive', signal: 'mild_positive', score: 1 };
    if (REPHRASE_RE.test(msg))
        return { feedbackType: 'rephrase', signal: 'rephrase_request', score: -1 };
    return null;
}
async function recordImplicitFeedback(userId, channel, sessionId, userMessage, previousAiMessage, memoryScope) {
    const detected = detectFeedback(userMessage);
    if (!detected)
        return;
    const scope = memoryScope ?? { userId, channel };
    await memoryStore.saveScopedInteractionFeedback(scope, {
        sessionId,
        userMessage: userMessage.slice(0, 500),
        aiResponse: previousAiMessage.slice(0, 800),
        feedbackType: detected.feedbackType,
        signal: detected.signal,
        score: detected.score,
    });
    log.debug({ userId, feedbackType: detected.feedbackType, signal: detected.signal }, 'Implicit feedback recorded');
    // Trigger reflection every 10 negative feedback events
    const stats = await memoryStore.getScopedFeedbackStats(scope);
    if (stats.negative > 0 && stats.negative % 10 === 0) {
        setImmediate(() => {
            import('./reflection.js').then(({ runScopedReflection }) => {
                runScopedReflection(scope).catch((err) => {
                    log.debug({ err: String(err) }, 'Auto-reflection failed (non-fatal)');
                });
            }).catch(() => { });
        });
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Pipeline 3: Entity Extraction (Ontology)
// ─────────────────────────────────────────────────────────────────────────────
const ENTITY_SYSTEM_PROMPT = `You extract named entities from a conversation turn and return structured JSON.

Entity types:
  person       — real people: colleagues, clients, contacts, family members
  project      — projects, products, features, codebases, initiatives
  task         — todos, action items, pending work, things to do
  event        — meetings, deadlines, scheduled occasions
  organization — companies, teams, departments, schools
  concept      — domain concepts, technologies, terms worth remembering

Output a JSON array. Each item:
{
  "type": "person|project|task|event|organization|concept",
  "name": "canonical name (how to refer to this entity)",
  "aliases": ["alt name 1"],          // optional, other names used
  "attributes": {                     // only include what was explicitly stated
    "role": "...",                    // for person: job/relation to user
    "status": "pending|done|...",     // for task/project
    "deadline": "...",                // date string if mentioned
    "description": "...",
    "email": "...",
    "priority": "high|medium|low"
    // any other relevant KV
  },
  "relations": [                      // optional relationships to other entities
    { "type": "member_of", "target": "Other Entity Name" }
  ]
}

Rules:
- Only extract entities explicitly mentioned (no inference or guessing)
- Skip generic nouns ("the app", "the file") — only named entities
- For tasks: name should be a concise description of the action (e.g. "给张三发报告")
- For persons: name = the name used (first name, full name, or nickname)
- Return [] if no named entities found
- Keep attribute values concise (under 100 chars each)`;
function buildEntityPrompt(exchange) {
    return `Conversation:\n${exchange}\n\nExtract named entities as JSON array:`;
}
async function extractEntities(userId, channel, userMessage, assistantResponse, memoryScope) {
    // Gate: skip very short messages
    if (userMessage.trim().length < 10)
        return;
    const exchange = `User: ${userMessage.slice(0, 800)}\n` +
        `Assistant: ${assistantResponse.slice(0, 400)}`;
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: buildEntityPrompt(exchange) }],
            systemPrompt: ENTITY_SYSTEM_PROMPT,
            maxTokens: 600,
            temperature: 0,
        });
        const raw = (res.content ?? '').trim();
        const m = raw.match(/\[[\s\S]*\]/);
        if (!m)
            return;
        const entities = JSON.parse(m[0]);
        if (!Array.isArray(entities))
            return;
        const VALID_TYPES = new Set(['person', 'project', 'task', 'event', 'organization', 'concept']);
        let saved = 0;
        for (const e of entities) {
            if (!e.name || !e.type || !VALID_TYPES.has(e.type))
                continue;
            const name = String(e.name).trim().slice(0, 100);
            if (!name)
                continue;
            if (memoryScope) {
                await memoryStore.upsertScopedEntity(memoryScope, {
                    type: e.type,
                    name,
                    aliases: e.aliases,
                    attributes: e.attributes ?? {},
                    relations: e.relations,
                });
            }
            else {
                await memoryStore.upsertEntity(userId, channel, {
                    type: e.type,
                    name,
                    aliases: e.aliases,
                    attributes: e.attributes ?? {},
                    relations: e.relations,
                });
            }
            saved++;
        }
        if (saved > 0)
            log.debug({ userId, saved }, 'Entities extracted and saved');
    }
    catch (err) {
        log.debug({ err: String(err) }, 'Entity extraction failed (non-fatal)');
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Pipeline 5: Contradiction Detection & Auto-Rollback
// ─────────────────────────────────────────────────────────────────────────────
const CONTRADICTION_SYSTEM_PROMPT = `You are a memory consistency checker.

You are given:
1. A set of stored memory facts about a user
2. The user's latest message

Your job: identify any stored facts that DIRECTLY CONTRADICT what the user just said.

Output a JSON array of contradictions. Each item:
{
  "key": "the memory key that is contradicted",
  "stored_value": "what is currently stored",
  "evidence": "the exact phrase from the user message that contradicts it",
  "confidence": 0.0-1.0
}

Rules:
- Only flag DIRECT contradictions (e.g. stored name="Alice", user says "my name is Bob")
- Do NOT flag vague or ambiguous cases
- Do NOT flag updates or additions (user adding new info is not a contradiction)
- Only flag confidence >= 0.8
- Return [] if no contradictions found`;
/**
 * Checks the current user message against stored memory facts.
 * If a stored fact directly contradicts what the user just said,
 * it is automatically rolled back (deleted or reverted to previous value).
 *
 * This runs fire-and-forget after every turn, before extraction.
 */
export async function detectAndRollbackContradictions(userId, channel, userMessage, memoryScope) {
    if (userMessage.trim().length < 10)
        return;
    const all = await getAllScopedMemoryForContext(scopeCtx(userId, channel, memoryScope));
    const factEntries = Object.entries(all).filter(([k]) => /^(profile:|tech:|pref:|context:)/.test(k));
    if (factEntries.length === 0)
        return;
    // Only check a subset of facts to keep the prompt small
    const factsToCheck = factEntries.slice(-20);
    const factsStr = factsToCheck.map(([k, v]) => `${k}: ${v}`).join('\n');
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{
                    role: 'user',
                    content: `Stored facts:\n${factsStr}\n\nUser message:\n"${userMessage.slice(0, 400)}"\n\nContradictions JSON:`,
                }],
            systemPrompt: CONTRADICTION_SYSTEM_PROMPT,
            maxTokens: 300,
            temperature: 0,
        });
        const m = (res.content ?? '').trim().match(/\[[\s\S]*\]/);
        if (!m)
            return;
        const contradictions = JSON.parse(m[0]);
        if (!Array.isArray(contradictions) || contradictions.length === 0)
            return;
        for (const c of contradictions) {
            if (!c.key || typeof c.key !== 'string')
                continue;
            if (typeof c.confidence !== 'number' || c.confidence < 0.8)
                continue;
            // Verify the key actually exists in our facts
            if (!all[c.key])
                continue;
            log.info({ userId, key: c.key, stored: c.stored_value, evidence: c.evidence, confidence: c.confidence }, 'Contradiction detected — auto-rolling back memory fact');
            // Roll back: find the most recent history entry for this key
            const history = await memoryStore.getScopedMemoryHistory(historyScope(userId, channel, memoryScope), 20);
            const prevEntry = history.find((h) => h.key === c.key && h.source === 'extraction' && h.old_value !== null);
            if (prevEntry?.old_value) {
                // Restore to previous value
                await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), c.key, all[c.key], prevEntry.old_value, 'manual');
                await setScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), c.key, prevEntry.old_value, 365);
                log.info({ userId, key: c.key, restoredTo: prevEntry.old_value }, 'Memory fact restored to previous value');
            }
            else {
                // No previous value — delete the contradicted fact
                await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), c.key, all[c.key], '', 'manual');
                await deleteScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), c.key);
                log.info({ userId, key: c.key }, 'Contradicted memory fact deleted (no prior value)');
            }
        }
    }
    catch (err) {
        log.debug({ err: String(err) }, 'Contradiction detection failed (non-fatal)');
    }
}
/**
 * Fire-and-forget entry point with backpressure control.
 *
 * @param userId           User identifier
 * @param channel          Channel name
 * @param userMessage      The user's message in this turn
 * @param assistantResponse The AI's response in this turn
 * @param previousAiMessage The AI's response in the PREVIOUS turn (for correction context)
 */
export function scheduleMemoryExtraction(userId, channel, userMessage, assistantResponse, previousAiMessage, sessionId, memoryScope) {
    if (userMessage.trim().length < 15)
        return;
    // Implicit feedback detection runs synchronously (pattern matching only, no LLM)
    if (previousAiMessage && sessionId) {
        void recordImplicitFeedback(userId, channel, sessionId, userMessage, previousAiMessage, memoryScope);
    }
    // Use extraction queue with backpressure control
    const priority = calculatePriority(userMessage, assistantResponse);
    const task = {
        id: nanoid(),
        userId,
        channel,
        userMessage,
        assistantResponse,
        previousAiMessage,
        memoryScope,
        priority,
        createdAt: Date.now(),
    };
    const enqueued = extractionQueue.enqueue(task);
    if (!enqueued) {
        log.warn({ userId, queueStats: extractionQueue.getStats() }, 'Memory extraction skipped due to backpressure');
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Internal implementation
// ─────────────────────────────────────────────────────────────────────────────
export async function runExtraction(userId, channel, userMessage, assistantResponse, previousAiMessage, memoryScope) {
    // Step 1: Check for contradictions and auto-rollback before extracting new facts.
    // This ensures stale/hallucinated facts are cleared before new ones are written.
    await detectAndRollbackContradictions(userId, channel, userMessage, memoryScope);
    // Step 2: Run all three extraction pipelines concurrently
    await Promise.allSettled([
        extractUserFacts(userId, channel, userMessage, assistantResponse, memoryScope),
        extractCorrection(userId, channel, userMessage, previousAiMessage, memoryScope),
        extractEntities(userId, channel, userMessage, assistantResponse, memoryScope),
    ]);
}
// ── Pipeline 1 ────────────────────────────────────────────────────────────────
async function extractUserFacts(userId, channel, userMessage, assistantResponse, memoryScope) {
    // Language detection via Unicode (deterministic, no LLM needed)
    const detectedLang = /[\u4e00-\u9fff]/.test(userMessage) ? 'zh' :
        /[\u3040-\u30ff\u31f0-\u31ff]/.test(userMessage) ? 'ja' :
            /[\uac00-\ud7af]/.test(userMessage) ? 'ko' : null;
    const all = await getAllScopedMemoryForContext(scopeCtx(userId, channel, memoryScope));
    const existing = Object.entries(all)
        .filter(([k]) => /^(profile:|tech:|pref:|context:)/.test(k))
        .map(([k, v]) => `${k}: ${v}`)
        .join('\n');
    const exchange = `User: ${userMessage.slice(0, 600)}\n` +
        `Assistant: ${assistantResponse.slice(0, 200)}`;
    let facts = {};
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: buildFactPrompt(exchange, existing) }],
            systemPrompt: FACT_SYSTEM_PROMPT,
            maxTokens: 200,
            temperature: 0,
        });
        const m = (res.content ?? '').trim().match(/\{[\s\S]*\}/);
        if (m) {
            const parsed = JSON.parse(m[0]);
            // Confidence filtering: remove entries below 0.7 threshold
            for (const [k, v] of Object.entries(parsed)) {
                if (k === '_confidence')
                    continue;
                // Per-fact confidence: check if there's a nested _confidence
                if (typeof v === 'object' && v !== null && '_confidence' in v) {
                    const factConf = v['_confidence'];
                    if (typeof factConf === 'number' && factConf < 0.7)
                        continue;
                }
                facts[k] = v;
            }
            // Remove any _confidence keys from the final facts
            delete facts['_confidence'];
            for (const [k, v] of Object.entries(facts)) {
                if (typeof v === 'object' && v !== null && '_confidence' in v) {
                    const obj = { ...v };
                    delete obj['_confidence'];
                    facts[k] = obj;
                }
            }
        }
    }
    catch { /* LLM error — fall through to language detection */ }
    // Language detection overrides LLM (more reliable)
    if (detectedLang && all['pref:language'] !== detectedLang) {
        facts['pref:language'] = detectedLang;
    }
    let saved = 0;
    for (const [key, rawVal] of Object.entries(facts)) {
        if (!/^[a-z]+:[a-z][a-z0-9_]*$/.test(key))
            continue;
        const rawStr = String(rawVal ?? '').trim().slice(0, 120);
        // Sanitize against prompt injection
        const value = sanitizeExtractedValue(rawStr);
        if (!value)
            continue;
        // Hallucination guard: reject code-like or invalid values
        if (!isValidFactValue(value))
            continue;
        // Deduplication: skip if existing value is identical after normalization
        if (all[key] && all[key].toLowerCase().trim() === value.toLowerCase().trim())
            continue;
        if (all[key] === value)
            continue;
        // High-impact key protection: require 2+ turns to overwrite
        if (!(await shouldPersistHighImpactFact(userId, channel, key, value, memoryScope))) {
            log.debug({ userId, key, value }, 'High-impact fact pending confirmation (need 2+ turns)');
            continue;
        }
        const oldValue = await getScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), key);
        await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), key, oldValue, value, 'extraction');
        await setScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), key, value, 365);
        saved++;
    }
    if (saved > 0)
        log.debug({ userId, saved }, 'Auto-saved user facts');
}
// ── Pipeline 2 ────────────────────────────────────────────────────────────────
async function extractCorrection(userId, channel, userMessage, previousAiMessage, memoryScope) {
    // Fast gate: no correction signals → skip entirely (saves LLM calls)
    if (!CORRECTION_SIGNALS_RE.test(userMessage))
        return;
    // Without the previous AI message we can't know what was wrong
    if (!previousAiMessage || previousAiMessage.trim().length < 10)
        return;
    // Correction rate limiting: max 5 per hour per user/channel
    const recentCorrections = await memoryStore.getCorrectionCount(userId, channel, 3600_000);
    if (recentCorrections >= 5) {
        log.warn({ userId, channel, count: recentCorrections }, 'Correction rate limit reached (5/hour)');
        return;
    }
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: buildCorrectionPrompt(previousAiMessage, userMessage) }],
            systemPrompt: CORRECTION_SYSTEM_PROMPT,
            maxTokens: 250,
            temperature: 0,
        });
        const m = (res.content ?? '').trim().match(/\{[\s\S]*\}/);
        if (!m)
            return;
        const extracted = JSON.parse(m[0]);
        const { topic, was_wrong, correct } = extracted;
        if (!topic || !correct || typeof topic !== 'string' || typeof correct !== 'string')
            return;
        // Normalise topic to a safe slug
        const slug = topic.toLowerCase().replace(/[^a-z0-9_]/g, '_').replace(/_+/g, '_').slice(0, 35);
        if (!slug)
            return;
        const key = `correction:${slug}`;
        // Sanitize correction values
        const sanitizedCorrect = sanitizeExtractedValue(correct.slice(0, 160));
        if (!sanitizedCorrect)
            return;
        const sanitizedWrong = was_wrong ? sanitizeExtractedValue(was_wrong.slice(0, 120)) : '';
        // Value format: human-readable enough to be useful in system prompt context
        const value = sanitizedWrong
            ? `[WRONG] ${sanitizedWrong} → [RIGHT] ${sanitizedCorrect}`
            : `[RIGHT] ${sanitizedCorrect}`;
        // Conflict detection: warn if overwriting an existing correction
        const existingCorrection = await getScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), key);
        if (existingCorrection) {
            log.warn({ userId, topic: slug, old: existingCorrection, new: value }, 'Overwriting existing correction');
        }
        // Corrections are permanent — no TTL
        const oldCorrection = await getScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), key);
        await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), key, oldCorrection, value, 'correction');
        await setScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), key, value);
        log.info({ userId, key }, 'Correction learned and saved');
    }
    catch (err) {
        log.debug({ err: String(err) }, 'Correction extraction failed (non-fatal)');
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Pipeline 6: Tool-Result vs Memory Consistency Check
// ─────────────────────────────────────────────────────────────────────────────
//
// After a tool call returns real-world data, we check whether any stored memory
// facts are contradicted by that ground-truth result.  If they are, we roll them
// back immediately — before the agent uses them in its reply.
//
// Example: memory says profile:location = "Beijing", but the weather tool just
// returned data for Shanghai because the user asked "weather in Shanghai".
// That alone is NOT a contradiction (user may be asking about another city).
// But if the tool result contains an explicit user-identity field that differs
// from memory, that IS a contradiction.
//
// We keep the prompt narrow and conservative: only flag high-confidence (≥0.85)
// direct contradictions where the tool result is the ground truth.
// ─────────────────────────────────────────────────────────────────────────────
const TOOL_RESULT_CONSISTENCY_PROMPT = `You are a memory consistency checker.

You are given:
1. A tool name and its result (ground-truth data from an external source)
2. A set of stored memory facts about the user

Your job: identify stored facts that are DIRECTLY CONTRADICTED by the tool result.

Only flag facts where:
- The tool result contains explicit, unambiguous data that contradicts the stored value
- The contradiction is about the SAME entity/attribute (not a different city, person, etc.)
- Confidence is high (≥ 0.85)

Output a JSON array. Each item:
{
  "key": "the memory key that is contradicted",
  "stored_value": "what is currently stored",
  "ground_truth": "the correct value from the tool result",
  "reason": "one sentence explaining the contradiction",
  "confidence": 0.0-1.0
}

Return [] if no contradictions found. Be conservative — false positives are worse than false negatives.`;
/**
 * Called after each tool execution in the agent loop.
 * Checks whether the tool result contradicts any stored memory facts.
 * Rolls back contradicted facts immediately (fire-and-forget safe to await).
 */
export async function checkToolResultVsMemory(userId, channel, toolName, toolResult, memoryScope) {
    // Skip tools that don't return factual user-related data
    const SKIP_TOOLS = new Set([
        'execute_code', 'shell_exec', 'file_ops', 'skill_creator',
        'multi_agent', 'cron_job', 'image_gen', 'qr_code',
    ]);
    if (SKIP_TOOLS.has(toolName))
        return;
    if (toolResult.trim().length < 20)
        return;
    const all = await getAllScopedMemoryForContext(scopeCtx(userId, channel, memoryScope));
    const factEntries = Object.entries(all).filter(([k]) => /^(profile:|tech:|pref:|context:)/.test(k));
    if (factEntries.length === 0)
        return;
    const factsStr = factEntries.slice(-15).map(([k, v]) => `${k}: ${v}`).join('\n');
    const resultSnippet = toolResult.slice(0, 600);
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{
                    role: 'user',
                    content: `Tool: ${toolName}\nTool result:\n${resultSnippet}\n\nStored facts:\n${factsStr}\n\nContradictions JSON:`,
                }],
            systemPrompt: TOOL_RESULT_CONSISTENCY_PROMPT,
            maxTokens: 300,
            temperature: 0,
        });
        const m = (res.content ?? '').trim().match(/\[[\s\S]*\]/);
        if (!m)
            return;
        const contradictions = JSON.parse(m[0]);
        if (!Array.isArray(contradictions) || contradictions.length === 0)
            return;
        for (const c of contradictions) {
            if (!c.key || typeof c.key !== 'string')
                continue;
            if (typeof c.confidence !== 'number' || c.confidence < 0.85)
                continue;
            if (!all[c.key])
                continue; // key no longer exists
            log.warn({ userId, key: c.key, stored: c.stored_value, groundTruth: c.ground_truth, tool: toolName, confidence: c.confidence }, 'Tool result contradicts memory — rolling back hallucinated fact');
            if (c.ground_truth && typeof c.ground_truth === 'string') {
                // Update to the ground-truth value from the tool
                const sanitized = sanitizeExtractedValue(c.ground_truth.slice(0, 120));
                if (sanitized && isValidFactValue(sanitized)) {
                    await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), c.key, all[c.key], sanitized, 'manual');
                    await setScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), c.key, sanitized, 365);
                    log.info({ userId, key: c.key, newValue: sanitized }, 'Memory fact corrected from tool ground truth');
                    continue;
                }
            }
            // No usable ground truth — roll back to previous value or delete
            const history = await memoryStore.getScopedMemoryHistory(historyScope(userId, channel, memoryScope), 20);
            const prevEntry = history.find((h) => h.key === c.key && h.old_value !== null);
            if (prevEntry?.old_value) {
                await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), c.key, all[c.key], prevEntry.old_value, 'manual');
                await setScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), c.key, prevEntry.old_value, 365);
                log.info({ userId, key: c.key, restoredTo: prevEntry.old_value }, 'Memory fact rolled back to previous value');
            }
            else {
                await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), c.key, all[c.key], '', 'manual');
                await deleteScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), c.key);
                log.info({ userId, key: c.key }, 'Hallucinated memory fact deleted (no prior value)');
            }
        }
    }
    catch (err) {
        log.debug({ err: String(err) }, 'Tool-result consistency check failed (non-fatal)');
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// Pipeline 7: Agent Reply Self-Audit (Hallucination Scoring)
// ─────────────────────────────────────────────────────────────────────────────
//
// After the agent produces its final reply, we check whether the reply contains
// any factual claims about the user that are NOT supported by stored memory.
// If the agent "invented" a fact (e.g. said "as a Python developer..." when no
// such fact is stored), we flag it and optionally delete the phantom memory key
// if it somehow got written.
//
// This is the most expensive check — it runs only when the reply is long enough
// to plausibly contain factual claims, and only when memory is non-empty.
// ─────────────────────────────────────────────────────────────────────────────
const REPLY_AUDIT_SYSTEM_PROMPT = `You are a hallucination auditor for an AI assistant.

You are given:
1. The AI's reply to the user
2. The stored memory facts the AI had access to

Your job: identify any factual claims in the reply ABOUT THE USER that are NOT supported by the stored facts and appear to be invented.

Only flag claims that:
- Are specific and verifiable (not vague opinions or general statements)
- Are about the user specifically (not general knowledge)
- Cannot be inferred from the stored facts
- Appear to be stated as fact, not as a question or suggestion

Output a JSON array. Each item:
{
  "claim": "the exact claim made in the reply",
  "unsupported_key": "the memory key this claim implies (e.g. profile:occupation)",
  "severity": "high|medium|low",
  "confidence": 0.0-1.0
}

Return [] if no hallucinated claims found. Be conservative.`;
/**
 * Audits the agent's final reply for hallucinated user facts.
 * If a hallucinated fact was somehow persisted to memory, it is rolled back.
 * Runs fire-and-forget after the reply is sent.
 */
export async function auditReplyForHallucinations(userId, channel, agentReply, memoryScope) {
    // Gate: only run for substantive replies
    if (agentReply.trim().length < 80)
        return;
    const all = await getAllScopedMemoryForContext(scopeCtx(userId, channel, memoryScope));
    const factEntries = Object.entries(all).filter(([k]) => /^(profile:|tech:|pref:|context:)/.test(k));
    // No memory → nothing to hallucinate from
    if (factEntries.length === 0)
        return;
    const factsStr = factEntries.map(([k, v]) => `${k}: ${v}`).join('\n');
    try {
        const res = await providerRegistry.chatWithFallback({
            messages: [{
                    role: 'user',
                    content: `AI reply:\n"${agentReply.slice(0, 800)}"\n\nStored facts the AI had access to:\n${factsStr}\n\nHallucinated claims JSON:`,
                }],
            systemPrompt: REPLY_AUDIT_SYSTEM_PROMPT,
            maxTokens: 400,
            temperature: 0,
        });
        const m = (res.content ?? '').trim().match(/\[[\s\S]*\]/);
        if (!m)
            return;
        const hallucinations = JSON.parse(m[0]);
        if (!Array.isArray(hallucinations) || hallucinations.length === 0)
            return;
        for (const h of hallucinations) {
            if (typeof h.confidence !== 'number' || h.confidence < 0.85)
                continue;
            if (!h.unsupported_key || typeof h.unsupported_key !== 'string')
                continue;
            log.warn({ userId, key: h.unsupported_key, claim: h.claim, severity: h.severity, confidence: h.confidence }, 'Hallucinated user fact detected in agent reply');
            // If this phantom key somehow got written to memory, roll it back
            if (all[h.unsupported_key]) {
                const history = await memoryStore.getScopedMemoryHistory(historyScope(userId, channel, memoryScope), 20);
                const prevEntry = history.find((e) => e.key === h.unsupported_key && e.old_value !== null);
                if (prevEntry?.old_value) {
                    await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), h.unsupported_key, all[h.unsupported_key], prevEntry.old_value, 'manual');
                    await setScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), h.unsupported_key, prevEntry.old_value, 365);
                    log.info({ userId, key: h.unsupported_key }, 'Phantom memory fact rolled back to previous value');
                }
                else {
                    await memoryStore.recordScopedMemoryChange(historyScope(userId, channel, memoryScope), h.unsupported_key, all[h.unsupported_key], '', 'manual');
                    await deleteScopedMemoryForContext(scopeCtx(userId, channel, memoryScope), h.unsupported_key);
                    log.info({ userId, key: h.unsupported_key }, 'Phantom memory fact deleted');
                }
            }
        }
    }
    catch (err) {
        log.debug({ err: String(err) }, 'Reply hallucination audit failed (non-fatal)');
    }
}
//# sourceMappingURL=extractor.js.map