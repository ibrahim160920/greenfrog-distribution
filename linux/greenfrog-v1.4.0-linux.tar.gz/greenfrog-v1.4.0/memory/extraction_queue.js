/**
 * Memory Extraction Task Queue with Backpressure
 *
 * Prevents memory extraction tasks from piling up under high load by:
 * - Limiting concurrent extraction tasks
 * - Queueing tasks with priority
 * - Rejecting new tasks when queue is full (backpressure)
 * - Graceful degradation under load
 */
import { createLogger } from '../utils/logger.js';
const log = createLogger('extraction-queue');
export class ExtractionQueue {
    queue = [];
    activeCount = 0;
    totalProcessed = 0;
    totalRejected = 0;
    totalRetried = 0;
    processingTimes = [];
    maxQueueSize;
    maxConcurrent;
    maxRetries;
    processingTimeWindow = 100; // Keep last 100 times
    constructor(maxQueueSize = 50, maxConcurrent = 3, maxRetries = 2) {
        this.maxQueueSize = maxQueueSize;
        this.maxConcurrent = maxConcurrent;
        this.maxRetries = maxRetries;
    }
    /**
     * Enqueue a new extraction task
     * Returns true if enqueued, false if rejected (backpressure)
     */
    enqueue(task) {
        // Backpressure: reject if queue is full
        if (this.queue.length >= this.maxQueueSize) {
            this.totalRejected++;
            log.warn({ userId: task.userId, queueSize: this.queue.length }, 'Extraction task rejected: queue full (backpressure active)');
            return false;
        }
        // Insert task in priority order (higher priority first)
        const insertIndex = this.queue.findIndex(t => t.priority < task.priority);
        if (insertIndex === -1) {
            this.queue.push(task);
        }
        else {
            this.queue.splice(insertIndex, 0, task);
        }
        log.debug({ userId: task.userId, queueSize: this.queue.length, priority: task.priority }, 'Extraction task enqueued');
        // Try to process immediately if capacity available
        this.processNext();
        return true;
    }
    /**
     * Process next task if capacity available
     */
    processNext() {
        if (this.activeCount >= this.maxConcurrent || this.queue.length === 0) {
            return;
        }
        const task = this.queue.shift();
        if (!task)
            return;
        this.activeCount++;
        const startTime = Date.now();
        log.debug({ userId: task.userId, activeCount: this.activeCount }, 'Processing extraction task');
        // Import and run extraction (dynamic import to avoid circular dependency)
        import('./extractor.js')
            .then(({ runExtraction }) => runExtraction(task.userId, task.channel, task.userMessage, task.assistantResponse, task.previousAiMessage, task.memoryScope))
            .then(() => {
            const duration = Date.now() - startTime;
            this.recordProcessingTime(duration);
            this.totalProcessed++;
            log.debug({ userId: task.userId, durationMs: duration }, 'Extraction task completed');
        })
            .catch((err) => {
            const retryCount = task.retryCount || 0;
            if (retryCount < this.maxRetries) {
                // Retry with lower priority
                const retryTask = { ...task, retryCount: retryCount + 1, priority: Math.max(0, task.priority - 20) };
                this.queue.push(retryTask);
                this.totalRetried++;
                log.debug({ userId: task.userId, retryCount: retryCount + 1, err: String(err) }, 'Extraction task failed, retrying');
            }
            else {
                log.debug({ userId: task.userId, err: String(err) }, 'Extraction task failed after max retries (non-fatal)');
            }
        })
            .finally(() => {
            this.activeCount--;
            // Process next task
            this.processNext();
        });
    }
    recordProcessingTime(ms) {
        this.processingTimes.push(ms);
        if (this.processingTimes.length > this.processingTimeWindow) {
            this.processingTimes.shift();
        }
    }
    /**
     * Get queue statistics
     */
    getStats() {
        const avgTime = this.processingTimes.length > 0
            ? this.processingTimes.reduce((a, b) => a + b, 0) / this.processingTimes.length
            : 0;
        return {
            queueSize: this.queue.length,
            activeCount: this.activeCount,
            totalProcessed: this.totalProcessed,
            totalRejected: this.totalRejected,
            totalRetried: this.totalRetried,
            avgProcessingTimeMs: Math.round(avgTime),
        };
    }
    /**
     * Check if queue is under pressure (>80% full)
     */
    isUnderPressure() {
        return this.queue.length > this.maxQueueSize * 0.8;
    }
}
// Global queue instance
export const extractionQueue = new ExtractionQueue(50, 3);
/**
 * Calculate task priority based on message characteristics
 */
export function calculatePriority(userMessage, assistantResponse) {
    let priority = 50; // Base priority
    // Higher priority for longer conversations (more context)
    const totalLength = userMessage.length + assistantResponse.length;
    if (totalLength > 1000)
        priority += 20;
    else if (totalLength > 500)
        priority += 10;
    // Higher priority for messages with important keywords
    const importantKeywords = [
        'remember', 'important', 'note', 'save', 'don\'t forget',
        '记住', '重要', '保存', '别忘了'
    ];
    const lowerMessage = userMessage.toLowerCase();
    if (importantKeywords.some(kw => lowerMessage.includes(kw))) {
        priority += 30;
    }
    // Lower priority for very short messages
    if (userMessage.length < 30)
        priority -= 20;
    return Math.max(0, Math.min(100, priority));
}
//# sourceMappingURL=extraction_queue.js.map