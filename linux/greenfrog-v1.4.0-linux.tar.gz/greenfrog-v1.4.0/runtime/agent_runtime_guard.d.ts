type ExecutionLease = {
    release: () => void;
};
type RuntimeSnapshot = {
    active: number;
    maxConcurrent: number;
    perUserActive: number;
    maxConcurrentPerUser: number;
    userKey: string;
};
type RuntimeOverview = {
    active: number;
    maxConcurrent: number;
    maxConcurrentPerUser: number;
    activeUsers: number;
    totalRejectedGlobal: number;
    totalRejectedPerUser: number;
    busiestUsers: Array<{
        userKey: string;
        active: number;
    }>;
};
export declare function getAgentRuntimeSnapshot(userId: string, channel?: string | null): RuntimeSnapshot;
export declare function getAgentRuntimeOverview(): RuntimeOverview;
export declare function acquireAgentExecutionLease(params: {
    userId: string;
    channel?: string | null;
    label?: string;
}): ExecutionLease;
export declare function withAgentExecutionLease<T>(params: {
    userId: string;
    channel?: string | null;
    label?: string;
}, fn: () => Promise<T>): Promise<T>;
export {};
//# sourceMappingURL=agent_runtime_guard.d.ts.map