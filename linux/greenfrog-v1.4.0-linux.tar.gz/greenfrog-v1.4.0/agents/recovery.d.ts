/**
 * Recovery Policy layer for GreenFrog P4.
 *
 * Provides structured error classification and differentiated recovery
 * planning. Instead of uniform retry-or-escalate, errors are classified
 * and each class gets a tailored recovery action.
 *
 * This is a pure module — no I/O, no DB access.
 * The caller (team.ts dispatchTeamTaskById) executes the plan.
 */
import type { RetryPolicy, ErrorClass } from './contract.js';
export type RecoveryAction = 'retry_immediately' | 'retry_with_delay' | 'retry_with_hint' | 'escalate' | 'fail_permanent' | 'skip';
export interface RecoveryPlan {
    action: RecoveryAction;
    errorClass: ErrorClass;
    /** Message to inject into the next prompt attempt, if retrying with hint */
    hint?: string;
    /** ms to wait before the retry (0 = immediate) */
    delayMs: number;
    /** Human-readable reason for this plan */
    reason: string;
}
/**
 * Classify an error message into a known ErrorClass.
 * Falls through to 'unknown' if no pattern matches.
 */
export declare function classifyError(err: unknown): ErrorClass;
/**
 * Determine what to do given an error class, remaining attempts, and policy.
 *
 * P4.2: `attemptsRemaining` is now passed explicitly by the caller, computed
 * from the unified `effectiveMaxAttempts` in team.ts. This removes the previous
 * dependency on `task.metadata.retryCount` and makes the boundary consistent
 * with `task.maxAttempts`.
 *
 * @param attemptsRemaining — how many more runs are permitted after this one
 */
export declare function planRecovery(errorClass: ErrorClass, attemptsRemaining: number, policy: RetryPolicy): RecoveryPlan;
//# sourceMappingURL=recovery.d.ts.map