import { BaseSkill } from './base.js';
// Common currency names for display
const CURRENCY_NAMES = {
    USD: 'US Dollar', EUR: 'Euro', GBP: 'British Pound', JPY: 'Japanese Yen',
    CNY: 'Chinese Yuan', KRW: 'Korean Won', HKD: 'Hong Kong Dollar', TWD: 'Taiwan Dollar',
    CAD: 'Canadian Dollar', AUD: 'Australian Dollar', CHF: 'Swiss Franc', SGD: 'Singapore Dollar',
    MXN: 'Mexican Peso', BRL: 'Brazilian Real', INR: 'Indian Rupee', RUB: 'Russian Ruble',
    SEK: 'Swedish Krona', NOK: 'Norwegian Krone', DKK: 'Danish Krone', NZD: 'New Zealand Dollar',
    THB: 'Thai Baht', MYR: 'Malaysian Ringgit', IDR: 'Indonesian Rupiah', PHP: 'Philippine Peso',
    VND: 'Vietnamese Dong', AED: 'UAE Dirham', SAR: 'Saudi Riyal', TRY: 'Turkish Lira',
    ZAR: 'South African Rand', EGP: 'Egyptian Pound',
};
export class ExchangeRateSkill extends BaseSkill {
    definition = {
        name: 'exchange_rate',
        description: 'Get real-time currency exchange rates and convert amounts between currencies. Completely free, no API key required.',
        category: 'information',
        parameters: [
            { name: 'from', type: 'string', required: true, description: 'Source currency code (e.g. USD, EUR, CNY, JPY)' },
            { name: 'to', type: 'string', description: 'Target currency code (optional — show top rates if omitted)' },
            { name: 'amount', type: 'number', description: 'Amount to convert (default: 1)', default: 1 },
        ],
        examples: ['1 USD to CNY', 'How much is 100 EUR in JPY?', '美元兑人民币汇率', 'Exchange rate USD'],
    };
    async execute(params, _ctx) {
        const from = params.from?.toUpperCase().trim();
        const to = params.to?.toUpperCase().trim();
        const amount = Number(params.amount ?? 1);
        if (!from)
            return this.err('Source currency code is required (e.g. USD, EUR, CNY)');
        try {
            const res = await fetch(`https://open.er-api.com/v6/latest/${from}`, { signal: AbortSignal.timeout(8_000) });
            if (!res.ok)
                return this.err(`Exchange rate fetch failed: ${res.status}`);
            const data = await res.json();
            if (data.result !== 'success')
                return this.err(`Invalid currency code: ${from}`);
            const updatedAt = data.time_last_update_utc
                ? new Date(data.time_last_update_utc).toLocaleString()
                : 'recently';
            // Single conversion
            if (to) {
                const rate = data.rates[to];
                if (!rate)
                    return this.err(`Unknown currency: ${to}. Use ISO 4217 codes like USD, EUR, CNY.`);
                const converted = (amount * rate).toFixed(to === 'JPY' || to === 'KRW' || to === 'VND' || to === 'IDR' ? 0 : 2);
                const fromName = CURRENCY_NAMES[from] ?? from;
                const toName = CURRENCY_NAMES[to] ?? to;
                return this.text(`💱 **Currency Conversion**\n\n` +
                    `**${amount.toLocaleString()} ${from}** (${fromName})\n` +
                    `= **${Number(converted).toLocaleString()} ${to}** (${toName})\n\n` +
                    `Rate: 1 ${from} = ${rate.toFixed(6)} ${to}\n` +
                    `📅 Updated: ${updatedAt}`);
            }
            // Show top currencies
            const TOP = ['USD', 'EUR', 'GBP', 'JPY', 'CNY', 'KRW', 'HKD', 'CAD', 'AUD', 'CHF', 'SGD', 'INR'];
            const rows = TOP.filter(c => c !== from && data.rates[c]).map(c => {
                const r = data.rates[c];
                const val = (amount * r).toFixed(c === 'JPY' || c === 'KRW' ? 0 : 4);
                return `  ${c.padEnd(4)} ${val.padStart(12)}   ${CURRENCY_NAMES[c] ?? c}`;
            });
            return this.text(`💱 **${amount} ${from} (${CURRENCY_NAMES[from] ?? from}) Exchange Rates**\n\n` +
                `\`\`\`\n  Code      Amount   Currency\n` +
                `  ─────────────────────────────\n` +
                rows.join('\n') +
                `\n\`\`\`\n📅 Updated: ${updatedAt}`);
        }
        catch (err) {
            return this.err(`Exchange rate error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=exchange_rate.js.map