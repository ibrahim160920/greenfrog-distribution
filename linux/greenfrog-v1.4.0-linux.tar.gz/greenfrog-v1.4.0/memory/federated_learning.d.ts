/**
 * Rule Synchronization System
 *
 * Internal module for syncing behavioral rules across deployments.
 * Not exposed in public documentation.
 */
export interface RuleSyncConfig {
    enabled: boolean;
    mode: 'manual' | 'auto';
    uploadRules: boolean;
    uploadStats: boolean;
    anonymize: boolean;
    reviewBeforeUpload: boolean;
    remoteUrl: string;
    accessToken?: string;
    syncIntervalHours: number;
}
export interface AnonymizedRule {
    rule: string;
    category: string;
    confidence: number;
    evidenceCount: number;
    successRate: number;
    language: string;
    domain: string;
}
export interface RuleSyncPayload {
    version: string;
    timestamp: string;
    instanceId: string;
    rules: AnonymizedRule[];
    stats?: {
        totalTasks: number;
        successfulTasks: number;
        averageConfidence: number;
    };
}
export interface GlobalRule extends AnonymizedRule {
    id: string;
    addedAt: string;
    lastVerified: string;
    votes: {
        upvotes: number;
        downvotes: number;
    };
}
export interface GlobalRuleLibrary {
    version: string;
    lastUpdated: string;
    rules: GlobalRule[];
}
/**
 * 从 workspace 收集可上报的规则
 */
export declare function collectUploadableRules(workspaceId: string, minConfidence?: number, minEvidenceCount?: number): Promise<AnonymizedRule[]>;
/**
 * 收集统计数据（匿名）
 */
export declare function collectAnonymousStats(workspaceId: string): Promise<{
    totalTasks: number;
    successfulTasks: number;
    averageConfidence: number;
}>;
/**
 * Upload rules to remote server
 */
export declare function uploadRulesToServer(config: RuleSyncConfig, workspaceId: string): Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Download global rule library from remote
 */
export declare function downloadGlobalRuleLibrary(config: RuleSyncConfig): Promise<GlobalRuleLibrary | null>;
/**
 * 将全局规则库同步到本地
 */
export declare function syncGlobalRulesToLocal(library: GlobalRuleLibrary, minConfidence?: number, minUpvotes?: number): Promise<{
    imported: number;
    skipped: number;
}>;
/**
 * Start periodic sync (background task)
 */
export declare function startPeriodicSync(config: RuleSyncConfig): Promise<void>;
/**
 * 导出规则为 JSON 文件（用户可以手动提交 PR）
 */
export declare function exportRulesToFile(workspaceId: string, outputPath: string): Promise<{
    success: boolean;
    message: string;
    rulesCount: number;
}>;
/**
 * 从 JSON 文件导入规则
 */
export declare function importRulesFromFile(inputPath: string, targetWorkspaceId: string): Promise<{
    success: boolean;
    message: string;
    imported: number;
}>;
/**
 * Get rule sync statistics
 */
export declare function getRuleSyncStats(workspaceId: string): Promise<{
    localRulesCount: number;
    globalRulesCount: number;
    uploadableRulesCount: number;
    lastSyncTime: string | null;
}>;
//# sourceMappingURL=federated_learning.d.ts.map