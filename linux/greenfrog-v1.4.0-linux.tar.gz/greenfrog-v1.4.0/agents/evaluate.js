/**
 * Evaluate layer for GreenFrog P4.1/P4.4.
 *
 * Provides doneCriteria-based evaluation of execution results.
 * This is the bridge between contract (what was promised) and
 * verdict (what was delivered).
 *
 * Design:
 *   - Empty doneCriteria → trust the agent (pass, high confidence)
 *   - Non-empty doneCriteria → keyword coverage check against resultSummary
 *   - Confidence is a continuous signal (0–1) used by verdict.ts and
 *     the execution loop to decide whether to retry or accept
 *
 * P4.4: evaluateDoneCriteria is now async to support evidence-based I/O
 * verification via runAcceptanceChecks.
 */
import { runAcceptanceChecks } from './acceptance.js';
// ── Helpers ───────────────────────────────────────────────────────────────────
/**
 * Extract the most significant keywords from a criterion string.
 * We strip stop-words and short tokens, keep the substantive terms.
 */
function extractKeywords(criterion) {
    const STOP = new Set([
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
        'has', 'have', 'had', 'do', 'does', 'did', 'will', 'would',
        'should', 'must', 'can', 'could', 'may', 'might', 'shall',
        'and', 'or', 'but', 'not', 'no', 'in', 'on', 'at', 'to',
        'of', 'for', 'with', 'by', 'from', 'this', 'that', 'it',
        '已', '完成', '确认', '验证', '检查', '包含', '包括', '存在',
        'successfully', 'complete', 'completed', 'confirm', 'ensure',
        'verify', 'check', 'include', 'contain',
    ]);
    return criterion
        .toLowerCase()
        .replace(/[^\w\u4e00-\u9fff\s]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length >= 3 && !STOP.has(w));
}
/**
 * Check whether a single criterion is covered by the text.
 * Returns a coverage ratio (0–1).
 */
function criterionCoverage(criterion, text) {
    const keywords = extractKeywords(criterion);
    if (keywords.length === 0) {
        // No extractable keywords — use substring match on first 40 chars
        const stub = criterion.slice(0, 40).toLowerCase();
        return text.toLowerCase().includes(stub) ? 1 : 0;
    }
    const matched = keywords.filter(kw => text.toLowerCase().includes(kw));
    return matched.length / keywords.length;
}
// ── Second-pass structural heuristic (P4.2) ───────────────────────────────────
//
// Applied when first-pass confidence is in the "uncertain zone" (0.22–0.68).
// Analyses the structural quality of the resultSummary independent of keyword
// matching — completion language, specificity signals, depth.
//
// Why this beats "ask a human":
//   - Deterministic, zero-latency, zero-cost
//   - Reduces false-negatives from keyword misses on paraphrased criteria
//   - Bounded: can only adjust by ±0.25, never flip pass↔fail on its own
//   - Downgrade path: if structural score is negative, we lower confidence further,
//     increasing the chance of triggering the quality_insufficient retry
const COMPLETION_TOKENS = [
    'completed', 'created', 'done', 'finished', 'wrote', 'found', 'generated',
    'output', 'produced', 'built', 'saved', 'sent', 'executed', 'resolved',
    '完成', '已完成', '成功', '创建', '生成', '执行', '输出', '写入', '已经', '实现',
];
const NEGATION_TOKENS = [
    'failed', 'error', 'unable', 'cannot', 'could not', 'did not', 'not found',
    'missing', 'undefined', 'null', '失败', '错误', '无法', '没有', '不存在',
];
function structuralQualityScore(text) {
    const lower = text.toLowerCase();
    let score = 0;
    // Depth signals: substantial length
    if (text.length > 80)
        score += 0.08;
    if (text.length > 200)
        score += 0.08;
    // Completion language
    const completionHits = COMPLETION_TOKENS.filter(t => lower.includes(t)).length;
    score += Math.min(completionHits * 0.06, 0.18);
    // Negation signals (reduce confidence)
    const negationHits = NEGATION_TOKENS.filter(t => lower.includes(t)).length;
    score -= Math.min(negationHits * 0.1, 0.25);
    // Specificity: numbers, quoted strings, code-like content
    if (/\d+/.test(text))
        score += 0.05;
    if (/["'`「」【】]/.test(text))
        score += 0.05;
    if (/[./\\:{}()\[\]]/.test(text))
        score += 0.04; // paths, code
    return score; // unbounded; caller clamps
}
/**
 * Second-pass structural evaluation.
 *
 * Triggered when: first-pass confidence is in the uncertain zone [0.22, 0.68].
 * Adjusts confidence using structural quality signals. Never flips pass alone.
 * Returns an updated EvaluateResult with secondPassApplied=true.
 */
function applySecondPass(first, text) {
    const UNCERTAIN_LOW = 0.22;
    const UNCERTAIN_HIGH = 0.68;
    if (first.confidence < UNCERTAIN_LOW || first.confidence > UNCERTAIN_HIGH)
        return first;
    const structScore = structuralQualityScore(text);
    const rawAdjusted = first.confidence + structScore;
    const adjusted = Math.max(0.05, Math.min(0.95, rawAdjusted));
    // Only change pass if confidence crosses the 0.7 threshold AND no missing criteria
    const newPass = first.missingCriteria.length === 0 && adjusted >= 0.70
        ? true
        : first.pass;
    const delta = adjusted - first.confidence;
    const direction = delta > 0 ? '↑' : delta < 0 ? '↓' : '→';
    const note = `第二层结构评估：${direction} ${Math.abs(delta * 100).toFixed(0)}%（结构质量 ${structScore >= 0 ? '+' : ''}${(structScore * 100).toFixed(0)}%）`;
    return {
        ...first,
        pass: newPass,
        confidence: adjusted,
        reason: first.reason + (Math.abs(delta) > 0.03 ? `；${note}` : ''),
        secondPassApplied: true,
        secondPassNote: note,
    };
}
// ── Core function ─────────────────────────────────────────────────────────────
/**
 * Evaluate whether a task's resultSummary satisfies the doneCriteria.
 *
 * P4.3: When acceptanceChecks are provided, they are run first.
 *   - If ALL checks pass → high-confidence structured pass (skips text heuristics)
 *   - If ANY check fails → structured fail; text heuristics still applied to
 *     build the reason string, but overall pass=false is locked
 *
 * P4.4: Now async to support real I/O verification via runAcceptanceChecks.
 *   Returns evidenceRecords and verificationMode for verdict source tracking.
 *
 * @param doneCriteria     — from TaskContract.doneCriteria
 * @param resultSummary    — from the agent's run output
 * @param acceptanceChecks — optional structured checks (P4.3/P4.4)
 */
export async function evaluateDoneCriteria(doneCriteria, resultSummary, acceptanceChecks) {
    // ── P4.4: Structured acceptance checks (run before text heuristics) ────────
    // Evidence-based checks (file_exists, json_field with targetPath, etc.) run
    // real I/O; summary_fallback checks match resultSummary text.
    if (acceptanceChecks && acceptanceChecks.length > 0) {
        const checkSummary = await runAcceptanceChecks(acceptanceChecks, resultSummary);
        const isEvidence = checkSummary.dominantMode === 'evidence';
        const hasAutoGenerated = acceptanceChecks.some(c => c.autoGenerated);
        if (checkSummary.allPassed) {
            // All checks passed
            // hard_verified (real I/O): 0.97. soft_verified (text): 0.92.
            const confidence = checkSummary.overallSeverity === 'hard_verified' ? 0.97 : 0.92;
            const verificationMode = isEvidence ? 'evidence_verified' : 'summary_verified';
            return {
                pass: true,
                confidence,
                reason: checkSummary.summary,
                missingCriteria: [],
                acceptanceMode: 'structured',
                acceptanceChecksPassed: checkSummary.passed,
                acceptanceChecksTotal: checkSummary.total,
                verificationMode,
                evidenceRecords: checkSummary.evidenceRecords,
                evidenceSeverity: checkSummary.overallSeverity,
                hasAutoGeneratedChecks: hasAutoGenerated,
            };
        }
        // Some checks failed — severity tells us how bad
        const failDetail = checkSummary.failures.slice(0, 3).join('；');
        const verificationMode = isEvidence ? 'evidence_failed' : 'summary_failed';
        // contradicted severity: evidence explicitly disproves done → confidence near floor
        const failConfidence = checkSummary.overallSeverity === 'contradicted'
            ? 0.05
            : Math.max(0.08, 0.2 * (checkSummary.passed / Math.max(checkSummary.total, 1)));
        return {
            pass: false,
            confidence: failConfidence,
            reason: `${checkSummary.summary}。失败项：${failDetail}`,
            missingCriteria: checkSummary.failures,
            acceptanceMode: 'structured',
            acceptanceChecksPassed: checkSummary.passed,
            acceptanceChecksTotal: checkSummary.total,
            verificationMode,
            evidenceRecords: checkSummary.evidenceRecords,
            evidenceSeverity: checkSummary.overallSeverity,
            hasAutoGeneratedChecks: hasAutoGenerated,
        };
    }
    // ── No criteria ────────────────────────────────────────────────────────────
    if (doneCriteria.length === 0) {
        const hasSummary = resultSummary && resultSummary.trim().length > 10;
        return {
            pass: true,
            // Lower confidence for honest signalling: no criteria means we genuinely
            // cannot verify anything. 0.62/0.48 vs the old 0.88/0.72 better reflects
            // that verdict.ts's risky-gate logic may still intervene for artifact tasks.
            confidence: hasSummary ? 0.62 : 0.48,
            reason: hasSummary
                ? '无完成标准，智能体已提供结果摘要，系统自动验收'
                : '无完成标准，系统默认验收（无结果摘要）',
            missingCriteria: [],
            acceptanceMode: 'textual',
            verificationMode: 'unverifiable',
            evidenceSeverity: 'unverifiable',
        };
    }
    // ── No result to evaluate against ─────────────────────────────────────────
    if (!resultSummary || resultSummary.trim().length < 5) {
        return {
            pass: false,
            confidence: 0.08,
            reason: '有完成标准但智能体未提供结果摘要，无法验收',
            missingCriteria: doneCriteria,
            acceptanceMode: 'textual',
            verificationMode: 'summary_failed',
            evidenceSeverity: 'unverifiable',
        };
    }
    const text = resultSummary.trim();
    // ── Evaluate each criterion ────────────────────────────────────────────────
    const coverages = doneCriteria.map(c => ({
        criterion: c,
        coverage: criterionCoverage(c, text),
    }));
    const missing = coverages.filter(c => c.coverage < 0.4).map(c => c.criterion);
    const avgCoverage = coverages.reduce((s, c) => s + c.coverage, 0) / coverages.length;
    let firstPass;
    if (missing.length === 0) {
        firstPass = {
            pass: true,
            confidence: 0.75 + avgCoverage * 0.2, // 0.75–0.95
            reason: `所有完成标准已覆盖（${doneCriteria.length} 项）`,
            missingCriteria: [],
            acceptanceMode: 'textual',
            verificationMode: 'summary_verified',
            evidenceSeverity: 'soft_verified',
        };
    }
    else if (missing.length < doneCriteria.length) {
        const coveredCount = doneCriteria.length - missing.length;
        firstPass = {
            pass: false,
            confidence: 0.3 + (coveredCount / doneCriteria.length) * 0.3,
            reason: `完成标准部分覆盖（${coveredCount}/${doneCriteria.length}），缺失：${missing.slice(0, 2).join('；')}`,
            missingCriteria: missing,
            acceptanceMode: 'textual',
            verificationMode: 'summary_failed',
            evidenceSeverity: 'unverifiable',
        };
    }
    else {
        firstPass = {
            pass: false,
            confidence: 0.12,
            reason: `结果摘要未覆盖任何完成标准（${doneCriteria.length} 项均未匹配）`,
            missingCriteria: doneCriteria,
            acceptanceMode: 'textual',
            verificationMode: 'summary_failed',
            evidenceSeverity: 'unverifiable',
        };
    }
    // Apply second-pass structural heuristic for uncertain-zone results
    return applySecondPass(firstPass, text);
}
//# sourceMappingURL=evaluate.js.map