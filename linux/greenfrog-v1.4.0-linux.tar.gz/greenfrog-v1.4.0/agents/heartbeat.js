import { existsSync, readFileSync } from 'fs';
import { join } from 'path';
import { nanoid } from 'nanoid';
import { agent } from './agent.js';
import { memoryStore } from '../memory/store.js';
import { claimTeamTaskById, deliverTeamNotification } from '../skills/team.js';
import { createLogger } from '../utils/logger.js';
import { resolveTeamTopologyModelRoute } from '../utils/team_topology.js';
import { finalizeTaskDone } from './task_finalization.js';
import { recordAutoHardEvidenceForTask } from '../memory/auto_hard_evidence.js';
const log = createLogger('agent-heartbeat');
export const HEARTBEAT_OK = 'HEARTBEAT_OK';
const DEFAULT_HEARTBEAT_FAILURE_THRESHOLD = 3;
const DEFAULT_HEARTBEAT_CIRCUIT_OPEN_MINUTES = 15;
const DEFAULT_MAILBOX_MAX_FAILURES = 3;
const MIN_TRACKABLE_TASK_AGE_MS = 15 * 60_000;
const HEARTBEAT_WATCHDOG_ESCALATION_PREFIX = 'Heartbeat watchdog:';
const DEFAULT_HEARTBEAT_CHECKLIST = `# HEARTBEAT Checklist

1. Review assigned team tasks, on-call duties, and overdue work.
2. For long-running work, check current progress, blockers, deadlines, and the next concrete action.
3. Execute exactly one useful round of work if something actionable exists.
4. If blocked, produce a concise blocker/progress update that can move the task forward.
5. If nothing requires action right now, reply exactly HEARTBEAT_OK.`;
function loadHeartbeatChecklist(cwd = process.cwd()) {
    const heartbeatPath = join(cwd, 'HEARTBEAT.md');
    if (!existsSync(heartbeatPath))
        return DEFAULT_HEARTBEAT_CHECKLIST;
    try {
        const raw = readFileSync(heartbeatPath, 'utf8').trim();
        return raw ? raw.slice(0, 12_000) : DEFAULT_HEARTBEAT_CHECKLIST;
    }
    catch (err) {
        log.warn({ err: String(err), heartbeatPath }, 'Failed to read HEARTBEAT.md, using built-in checklist');
        return DEFAULT_HEARTBEAT_CHECKLIST;
    }
}
function isOpenTask(task) {
    return task.status !== 'done' && task.status !== 'cancelled';
}
function summarizeAgentTasks(tasks) {
    if (tasks.length === 0)
        return '- none';
    const lines = tasks.slice(0, 8).map((task) => [
        `- ${task.id}: ${task.title}`,
        `  status=${task.status}, priority=${task.priority}, attempts=${task.attemptCount}/${task.maxAttempts}`,
        task.blockedReason ? `  blocked=${task.blockedReason}` : null,
        task.dueAt ? `  due_at=${task.dueAt.toISOString()}` : null,
        task.resultSummary ? `  latest=${task.resultSummary.slice(0, 180)}` : null,
    ].filter(Boolean).join('\n'));
    if (tasks.length <= 8)
        return lines.join('\n');
    return `${lines.join('\n')}\n- ... ${tasks.length - 8} more open tasks`;
}
function summarizeOnCallDuties(agentDef, rotations) {
    const roles = rotations.flatMap((rotation) => {
        const duty = [];
        if (rotation.primaryAgentIds.includes(agentDef.id)) {
            duty.push(`primary in ${rotation.name}`);
        }
        if (rotation.secondaryAgentIds.includes(agentDef.id)) {
            duty.push(`secondary in ${rotation.name}`);
        }
        return duty;
    });
    if (roles.length === 0)
        return '- none';
    return roles.map((role) => `- ${role}`).join('\n');
}
function summarizeMailboxMessages(messages) {
    if (messages.length === 0)
        return '- none';
    const lines = messages.slice(0, 8).map((message) => [
        `- ${message.id}: type=${message.type}, from=${message.senderAgentId ?? message.senderUserId ?? 'system'}`,
        message.taskId ? `  task=${message.taskId}` : null,
        message.subject ? `  subject=${message.subject}` : null,
        typeof message.metadata?.['protocolRule'] === 'string' ? `  protocol=${message.metadata['protocolRule']}` : null,
        typeof message.metadata?.['deliberationStage'] === 'string' ? `  deliberation_stage=${message.metadata['deliberationStage']}` : null,
        Number.isFinite(Number(message.metadata?.['deliberationRound'])) ? `  deliberation_round=${Number(message.metadata?.['deliberationRound'])}` : null,
        `  body=${message.message.slice(0, 220)}`,
    ].filter(Boolean).join('\n'));
    if (messages.length <= 8)
        return lines.join('\n');
    return `${lines.join('\n')}\n- ... ${messages.length - 8} more pending mailbox messages`;
}
function canAgentClaimTask(agentDef, task) {
    if (task.workspaceId !== agentDef.workspaceId)
        return false;
    if (!isOpenTask(task))
        return false;
    if (task.assignedAgentId)
        return false;
    if (!(task.status === 'todo' || task.status === 'open' || task.status === 'proposed'))
        return false;
    const metadata = task.metadata ?? {};
    const workerAgentIds = Array.isArray(metadata['topologyWorkerAgentIds'])
        ? metadata['topologyWorkerAgentIds']
            .filter((item) => typeof item === 'string' && item.trim().length > 0)
        : [];
    return workerAgentIds.length === 0 || workerAgentIds.includes(agentDef.id);
}
function summarizeClaimableTasks(tasks) {
    if (tasks.length === 0)
        return '- none';
    const lines = tasks.slice(0, 8).map((task) => [
        `- ${task.id}: ${task.title}`,
        `  status=${task.status}, priority=${task.priority}`,
        task.dependsOnTaskIds && task.dependsOnTaskIds.length > 0 ? `  depends_on=${task.dependsOnTaskIds.join(', ')}` : null,
        task.description ? `  desc=${task.description.slice(0, 180)}` : null,
    ].filter(Boolean).join('\n'));
    if (tasks.length <= 8)
        return lines.join('\n');
    return `${lines.join('\n')}\n- ... ${tasks.length - 8} more claimable shared tasks`;
}
function resolveHeartbeatAgentModel(agentDef) {
    if (typeof agentDef.model === 'string' && agentDef.model.trim())
        return agentDef.model.trim();
    const metadataModel = agentDef.metadata?.['model'];
    return typeof metadataModel === 'string' && metadataModel.trim() ? metadataModel.trim() : null;
}
function summarizeTeammateStates(teammates) {
    if (teammates.length === 0)
        return '- none';
    const lines = teammates.slice(0, 8).map((teammate) => [
        `- ${teammate.id} (${teammate.name}) status=${teammate.status}, open_tasks=${teammate.openTaskCount}`,
        teammate.model ? `  model=${teammate.model}` : null,
        teammate.lastHeartbeatStatus ? `  last_heartbeat=${teammate.lastHeartbeatStatus}` : null,
        teammate.lastHeartbeatSummary ? `  summary=${teammate.lastHeartbeatSummary.slice(0, 220)}` : null,
    ].filter(Boolean).join('\n'));
    if (teammates.length <= 8)
        return lines.join('\n');
    return `${lines.join('\n')}\n- ... ${teammates.length - 8} more teammates`;
}
function summarizeSwarmStatus(statuses) {
    if (statuses.length === 0)
        return '- none';
    const lines = statuses.slice(0, 6).map((status) => [
        `- ${status.topologyName}: on_conflict=${status.onConflict}`,
        status.challengeSuccessRate != null
            ? `  challenge_success_rate=${Math.round(status.challengeSuccessRate * 100)}%`
            : null,
        status.consensusTimeoutRate != null
            ? `  consensus_timeout_rate=${Math.round(status.consensusTimeoutRate * 100)}%`
            : null,
    ].filter(Boolean).join('\n'));
    if (statuses.length <= 6)
        return lines.join('\n');
    return `${lines.join('\n')}\n- ... ${statuses.length - 6} more topologies`;
}
function resolveHeartbeatExecutionRoute(agentDef, topologies) {
    const relevant = topologies.filter((topology) => topology.workspaceId === agentDef.workspaceId
        && (topology.supervisorAgentId === agentDef.id || topology.workerAgentIds.includes(agentDef.id)));
    for (const topology of relevant) {
        const route = resolveTeamTopologyModelRoute(topology, 'heartbeat');
        if (route?.provider || route?.model) {
            return {
                provider: route.provider ?? null,
                model: route.model ?? null,
                topologyId: topology.id,
                topologyName: topology.name,
            };
        }
    }
    return null;
}
function buildHeartbeatMailboxDedupeKey(...parts) {
    return parts
        .map((part) => (part ?? '').trim().toLowerCase())
        .filter(Boolean)
        .join(':')
        .slice(0, 240);
}
function getHeartbeatFailureThreshold(agentDef) {
    const raw = Number((agentDef.metadata ?? {})['heartbeatFailureThreshold']);
    return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : DEFAULT_HEARTBEAT_FAILURE_THRESHOLD;
}
function getHeartbeatCircuitOpenMinutes(agentDef) {
    const raw = Number((agentDef.metadata ?? {})['heartbeatCircuitOpenMinutes']);
    return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : DEFAULT_HEARTBEAT_CIRCUIT_OPEN_MINUTES;
}
function getHeartbeatCircuitOpenUntil(agentDef) {
    const value = (agentDef.metadata ?? {})['heartbeatCircuitOpenUntil'];
    if (typeof value !== 'string' || !value.trim())
        return null;
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
}
function isHeartbeatPausedAgent(agentDef) {
    return Boolean((agentDef.metadata ?? {})['heartbeatPausedBySystem']);
}
function trimText(value, maxLength = 500) {
    if (typeof value !== 'string')
        return undefined;
    const normalized = value.trim();
    return normalized ? normalized.slice(0, maxLength) : undefined;
}
function parseHeartbeatTime(value) {
    if (typeof value !== 'string' || !value.trim())
        return null;
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
}
function getTaskHeartbeatWatchdogThresholdMinutes(task) {
    const raw = Number((task.metadata ?? {})['heartbeatWatchdogMinutes']);
    if (Number.isFinite(raw) && raw > 0)
        return Math.floor(raw);
    switch (task.priority) {
        case 'critical':
            return 30;
        case 'high':
            return 60;
        case 'medium':
            return 180;
        case 'low':
        default:
            return 360;
    }
}
function getTaskHeartbeatWatchdogAlertCooldownMinutes(task, thresholdMinutes) {
    const raw = Number((task.metadata ?? {})['heartbeatWatchdogAlertCooldownMinutes']);
    if (Number.isFinite(raw) && raw > 0)
        return Math.floor(raw);
    return Math.max(30, Math.min(720, thresholdMinutes));
}
function isHeartbeatWatchdogTask(task, now = Date.now()) {
    if (!isOpenTask(task) || !task.assignedAgentId)
        return false;
    const metadata = task.metadata ?? {};
    const ageMs = now - task.createdAt.getTime();
    return task.status === 'in_progress'
        || task.status === 'blocked'
        || task.status === 'review_pending'
        || parseHeartbeatTime(metadata['heartbeatSeenAt']) !== null
        || parseHeartbeatTime(metadata['heartbeatUpdatedAt']) !== null
        || ageMs >= MIN_TRACKABLE_TASK_AGE_MS;
}
function getHeartbeatWatchdogLastSeenAt(task) {
    const metadata = task.metadata ?? {};
    return parseHeartbeatTime(metadata['heartbeatSeenAt'])
        ?? parseHeartbeatTime(metadata['heartbeatUpdatedAt'])
        ?? task.updatedAt.getTime();
}
function isHeartbeatWatchdogEscalation(task) {
    return typeof task.escalationReason === 'string'
        && task.escalationReason.startsWith(HEARTBEAT_WATCHDOG_ESCALATION_PREFIX);
}
async function emitHeartbeatNotificationSafe(params) {
    const recipientUserId = params.recipientUserId?.trim();
    if (!recipientUserId)
        return;
    try {
        const notification = await memoryStore.createTeamNotification({
            workspaceId: params.workspaceId,
            recipientUserId,
            type: params.type,
            severity: params.severity,
            title: params.title,
            message: params.message,
            metadata: {
                agentId: params.agentDef.id,
                agentName: params.agentDef.name,
                heartbeatEventAt: params.at.toISOString(),
                ...params.metadata,
            },
        });
        await deliverTeamNotification(notification);
    }
    catch (err) {
        log.warn({ err: String(err), agentId: params.agentDef.id, workspaceId: params.workspaceId }, 'Failed to deliver heartbeat notification');
    }
}
async function emitTaskWatchdogNotificationSafe(params) {
    const recipientUserId = params.recipientUserId?.trim();
    if (!recipientUserId)
        return;
    try {
        const notification = await memoryStore.createTeamNotification({
            workspaceId: params.workspaceId,
            recipientUserId,
            type: 'task_escalated',
            severity: params.task.priority === 'critical' ? 'critical' : 'warning',
            title: `Heartbeat watchdog: ${params.task.title}`,
            message: `Task ${params.task.title} has not reported a heartbeat check-in for ${params.staleMinutes} minutes (threshold ${params.thresholdMinutes}).`,
            taskId: params.task.id,
            metadata: {
                taskId: params.task.id,
                taskStatus: params.task.status,
                taskPriority: params.task.priority,
                assignedAgentId: params.assignedAgent?.id ?? params.task.assignedAgentId ?? null,
                assignedAgentName: params.assignedAgent?.name ?? null,
                heartbeatWatchdogAlertedAt: params.at.toISOString(),
                heartbeatWatchdogStaleMinutes: params.staleMinutes,
                heartbeatWatchdogThresholdMinutes: params.thresholdMinutes,
            },
        });
        await deliverTeamNotification(notification);
    }
    catch (err) {
        log.warn({ err: String(err), taskId: params.task.id, workspaceId: params.workspaceId }, 'Failed to deliver task watchdog notification');
    }
}
function extractHeartbeatJson(text) {
    const trimmed = text.trim();
    if (!trimmed)
        return null;
    const direct = trimmed.startsWith('{') || trimmed.startsWith('[') ? trimmed : null;
    if (direct) {
        try {
            return JSON.parse(direct);
        }
        catch { /* fall through */ }
    }
    const objectMatch = trimmed.match(/\{[\s\S]*\}/);
    if (objectMatch) {
        try {
            return JSON.parse(objectMatch[0]);
        }
        catch { /* fall through */ }
    }
    const arrayMatch = trimmed.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
        try {
            return JSON.parse(arrayMatch[0]);
        }
        catch { /* fall through */ }
    }
    return null;
}
function parseHeartbeatProtocol(text) {
    const parsed = extractHeartbeatJson(text);
    const record = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
        ? parsed
        : null;
    const updates = parseHeartbeatTaskUpdates(text);
    const mailboxAcks = Array.isArray(record?.['mailboxAcks'])
        ? (record?.['mailboxAcks'])
            .map((item) => typeof item === 'string' ? { messageId: item.trim() } : item)
            .filter((item) => Boolean(item) && typeof item === 'object' && !Array.isArray(item))
            .map((item) => ({ messageId: String(item['messageId'] ?? '').trim() }))
            .filter((item) => item.messageId.length > 0)
        : [];
    const taskClaims = Array.isArray(record?.['taskClaims'])
        ? (record?.['taskClaims'])
            .map((item) => typeof item === 'string' ? { taskId: item.trim() } : item)
            .filter((item) => Boolean(item) && typeof item === 'object' && !Array.isArray(item))
            .map((item) => ({ taskId: String(item['taskId'] ?? '').trim() }))
            .filter((item) => item.taskId.length > 0)
        : [];
    const outboundMessages = Array.isArray(record?.['outboundMessages'])
        ? (record?.['outboundMessages'])
            .filter((item) => Boolean(item) && typeof item === 'object' && !Array.isArray(item))
            .map((item) => ({
            recipientAgentId: trimText(item['recipientAgentId'], 120),
            taskId: trimText(item['taskId'], 120),
            threadId: trimText(item['threadId'], 160),
            type: typeof item['type'] === 'string' ? item['type'] : undefined,
            subject: trimText(item['subject'], 200),
            message: trimText(item['message'], 2_000) ?? '',
            metadata: item['metadata'] && typeof item['metadata'] === 'object' && !Array.isArray(item['metadata'])
                ? { ...item['metadata'] }
                : undefined,
        }))
            .filter((item) => item.message.length > 0)
        : [];
    return { updates, mailboxAcks, taskClaims, outboundMessages };
}
export function parseHeartbeatTaskUpdates(text) {
    const parsed = extractHeartbeatJson(text);
    const rawItems = Array.isArray(parsed) ? parsed
        : parsed && typeof parsed === 'object' && Array.isArray(parsed['updates'])
            ? parsed['updates']
            : parsed && typeof parsed === 'object' && typeof parsed['taskId'] === 'string'
                ? [parsed]
                : [];
    return rawItems
        .filter((item) => Boolean(item) && typeof item === 'object' && !Array.isArray(item))
        .map((item) => ({
        taskId: String(item['taskId'] ?? '').trim(),
        status: typeof item['status'] === 'string' ? item['status'] : undefined,
        progressSummary: trimText(item['progressSummary'], 800),
        nextAction: trimText(item['nextAction'], 300),
        blockedReason: trimText(item['blockedReason'], 500),
    }))
        .filter((item) => item.taskId.length > 0);
}
function toHeartbeatResultSummary(existing, at, progressSummary, nextAction) {
    const parts = [progressSummary, nextAction ? `Next: ${nextAction}` : null].filter(Boolean);
    if (parts.length === 0)
        return undefined;
    const line = `[Heartbeat ${at.toISOString()}] ${parts.join(' | ')}`.slice(0, 1000);
    if (!existing?.trim())
        return line;
    if (existing.includes(line))
        return existing;
    return `${existing}\n\n${line}`.slice(0, 4000);
}
async function applyHeartbeatTaskUpdates(agentDef, tasks, responseText, at) {
    const updates = parseHeartbeatTaskUpdates(responseText);
    if (updates.length === 0)
        return 0;
    const taskMap = new Map(tasks.map((task) => [task.id, task]));
    let applied = 0;
    for (const update of updates) {
        const task = taskMap.get(update.taskId);
        if (!task)
            continue;
        const metadata = task.metadata ?? {};
        const requestedStatus = update.status;
        const canUseStatus = requestedStatus === 'assigned'
            || requestedStatus === 'in_progress'
            || requestedStatus === 'blocked'
            || requestedStatus === 'done';
        const resolvedStatus = canUseStatus
            ? (requestedStatus === 'done' && task.reviewRequired ? 'review_pending' : requestedStatus)
            : task.status;
        const mergedSummary = toHeartbeatResultSummary(task.resultSummary, at, update.progressSummary, update.nextAction);
        // P4.6.2: Run evaluation + artifact detection for heartbeat-completed tasks
        // (same pipeline as the worker loop done path — shared helper)
        const isCompletingDone = resolvedStatus === 'done' || resolvedStatus === 'review_pending';
        const hbRunId = isCompletingDone ? `hb-${nanoid(8)}` : null;
        const completedAt = isCompletingDone ? at.toISOString() : null;
        let doneEval = null;
        let doneEvalError = null;
        if (isCompletingDone && hbRunId) {
            try {
                doneEval = await finalizeTaskDone(task, mergedSummary ?? task.resultSummary ?? null, hbRunId);
            }
            catch (err) {
                doneEvalError = err instanceof Error ? err.message : String(err);
                log.warn({ taskId: task.id, runId: hbRunId, err: doneEvalError }, 'heartbeat finalization failed — evaluation fields will be missing');
            }
        }
        const updated = await memoryStore.updateTeamTask(task.id, {
            status: resolvedStatus,
            ...(isHeartbeatWatchdogEscalation(task)
                ? {
                    escalationStatus: 'none',
                    escalationReason: null,
                }
                : {}),
            ...(resolvedStatus === 'review_pending'
                ? { reviewStatus: 'pending' }
                : resolvedStatus === 'done'
                    ? { reviewStatus: 'not_required' }
                    : {}),
            ...(resolvedStatus === 'blocked'
                ? { blockedReason: update.blockedReason ?? update.progressSummary ?? task.blockedReason ?? 'Heartbeat reported blocked progress' }
                : update.blockedReason === undefined
                    ? { blockedReason: task.blockedReason ?? null }
                    : { blockedReason: update.blockedReason }),
            ...(mergedSummary ? { resultSummary: mergedSummary } : {}),
            metadata: {
                ...metadata,
                heartbeatAgentId: agentDef.id,
                heartbeatSeenAt: at.toISOString(),
                heartbeatSeenStatus: 'actionable',
                heartbeatUpdatedAt: at.toISOString(),
                heartbeatProgressSummary: update.progressSummary ?? null,
                heartbeatNextAction: update.nextAction ?? null,
                heartbeatRawStatus: update.status ?? null,
                heartbeatWatchdogState: 'healthy',
                heartbeatWatchdogThresholdMinutes: getTaskHeartbeatWatchdogThresholdMinutes(task),
                heartbeatWatchdogRecoveredAt: isHeartbeatWatchdogEscalation(task)
                    || metadata['heartbeatWatchdogState'] === 'attention_required'
                    ? at.toISOString()
                    : metadata['heartbeatWatchdogRecoveredAt'] ?? null,
                // P4.6.2: done-path fields — aligned with worker loop done path
                // Written unconditionally when transitioning to done/review_pending,
                // regardless of whether finalization succeeded.
                ...(isCompletingDone ? {
                    lastRunId: hbRunId,
                    currentRunId: null,
                    lastRunCompletedAt: completedAt,
                    executionPhase: 'done',
                    lastRunStatus: resolvedStatus === 'done' ? 'done' : 'review_pending',
                    nextSuggestedAction: null,
                    pendingHint: null,
                    latestError: doneEvalError ? `Finalization error: ${doneEvalError}` : null,
                    latestObservation: mergedSummary
                        ? { text: mergedSummary.slice(0, 300), at: completedAt }
                        : null,
                    // Evaluation fields — only present when finalization succeeded
                    ...(doneEval ? {
                        confidence: doneEval.evalResult.confidence,
                        acceptanceEvidence: doneEval.evalResult.evidenceRecords ?? null,
                        verificationMode: doneEval.evalResult.verificationMode ?? null,
                        acceptanceChecksPassed: doneEval.evalResult.acceptanceChecksPassed ?? null,
                        acceptanceChecksTotal: doneEval.evalResult.acceptanceChecksTotal ?? null,
                        evidenceSeverity: doneEval.evalResult.evidenceSeverity ?? null,
                        hasAutoGeneratedChecks: doneEval.evalResult.hasAutoGeneratedChecks ?? false,
                        artifacts: doneEval.artifacts.length > 0 ? doneEval.artifacts : (metadata['artifacts'] ?? null),
                    } : {}),
                } : {}),
            },
        });
        if (updated) {
            applied++;
            // M5: automated hard evidence — wires evidence_verified heartbeat completions into capability unit promotion
            if (updated.status === 'done' && doneEval && hbRunId) {
                recordAutoHardEvidenceForTask(updated, doneEval.evalResult, hbRunId).catch(() => { });
            }
        }
    }
    return applied;
}
async function applyHeartbeatMailboxActions(agentDef, mailboxMessages, responseText, at) {
    const protocol = parseHeartbeatProtocol(responseText);
    const mailboxMap = new Map(mailboxMessages.map((message) => [message.id, message]));
    let acked = 0;
    let sent = 0;
    for (const ack of protocol.mailboxAcks) {
        const mailbox = mailboxMap.get(ack.messageId);
        if (!mailbox || mailbox.status !== 'pending')
            continue;
        const updated = await memoryStore.updateTeamMailboxMessage(mailbox.id, {
            status: 'acknowledged',
            acknowledgedAt: at,
            metadata: {
                ...(mailbox.metadata ?? {}),
                acknowledgedByAgentId: agentDef.id,
                acknowledgedByHeartbeatAt: at.toISOString(),
            },
        });
        if (updated)
            acked++;
    }
    for (const outbound of protocol.outboundMessages) {
        const type = outbound.type === 'broadcast'
            || outbound.type === 'task_event'
            || outbound.type === 'challenge'
            || outbound.type === 'consensus_request'
            || outbound.type === 'consensus_response'
            || outbound.type === 'direct'
            ? outbound.type
            : 'direct';
        const created = await memoryStore.createTeamMailboxMessage({
            workspaceId: agentDef.workspaceId,
            senderAgentId: agentDef.id,
            recipientAgentId: outbound.recipientAgentId ?? null,
            taskId: outbound.taskId ?? null,
            threadId: outbound.threadId,
            dedupeKey: buildHeartbeatMailboxDedupeKey('heartbeat', agentDef.id, type, outbound.taskId ?? '', outbound.recipientAgentId ?? '', outbound.threadId ?? '', outbound.subject ?? '', outbound.message.slice(0, 80)),
            type,
            subject: outbound.subject ?? null,
            message: outbound.message,
            metadata: {
                heartbeatAgentId: agentDef.id,
                heartbeatCreatedAt: at.toISOString(),
                ...((outbound.metadata && typeof outbound.metadata === 'object' && !Array.isArray(outbound.metadata))
                    ? outbound.metadata
                    : {}),
            },
        });
        if (created)
            sent++;
    }
    return { acked, sent };
}
async function markHeartbeatObservedTasks(agentDef, tasks, at, heartbeatStatus) {
    let observed = 0;
    for (const task of tasks) {
        if (!isHeartbeatWatchdogTask(task, at.getTime()))
            continue;
        const metadata = task.metadata ?? {};
        const updated = await memoryStore.updateTeamTask(task.id, {
            ...(isHeartbeatWatchdogEscalation(task)
                ? {
                    escalationStatus: 'none',
                    escalationReason: null,
                }
                : {}),
            metadata: {
                ...metadata,
                heartbeatAgentId: agentDef.id,
                heartbeatSeenAt: at.toISOString(),
                heartbeatSeenStatus: heartbeatStatus,
                heartbeatWatchdogState: 'healthy',
                heartbeatWatchdogThresholdMinutes: getTaskHeartbeatWatchdogThresholdMinutes(task),
                heartbeatWatchdogRecoveredAt: isHeartbeatWatchdogEscalation(task)
                    || metadata['heartbeatWatchdogState'] === 'attention_required'
                    ? at.toISOString()
                    : metadata['heartbeatWatchdogRecoveredAt'] ?? null,
            },
        });
        if (updated)
            observed++;
    }
    return observed;
}
async function runTaskHeartbeatWatchdog(params) {
    const now = params.at.getTime();
    const agentsById = new Map(params.agents.map((agentDef) => [agentDef.id, agentDef]));
    let alerted = 0;
    for (const task of params.tasks) {
        if (params.workspaceId && task.workspaceId !== params.workspaceId)
            continue;
        if (params.agentId && task.assignedAgentId !== params.agentId)
            continue;
        if (!isHeartbeatWatchdogTask(task, now))
            continue;
        const thresholdMinutes = getTaskHeartbeatWatchdogThresholdMinutes(task);
        const lastSeenAt = getHeartbeatWatchdogLastSeenAt(task);
        if (lastSeenAt + thresholdMinutes * 60_000 > now)
            continue;
        const metadata = task.metadata ?? {};
        const cooldownMinutes = getTaskHeartbeatWatchdogAlertCooldownMinutes(task, thresholdMinutes);
        const lastAlertedAt = parseHeartbeatTime(metadata['heartbeatWatchdogAlertedAt']);
        if (lastAlertedAt !== null && lastAlertedAt + cooldownMinutes * 60_000 > now)
            continue;
        const staleMinutes = Math.max(1, Math.floor((now - lastSeenAt) / 60_000));
        const assignedAgent = task.assignedAgentId ? agentsById.get(task.assignedAgentId) ?? null : null;
        const recipientUserId = task.humanOwnerUserId ?? task.createdBy;
        const escalationReason = `${HEARTBEAT_WATCHDOG_ESCALATION_PREFIX} no task check-in for ${staleMinutes} minutes (threshold ${thresholdMinutes}).`;
        const updated = await memoryStore.updateTeamTask(task.id, {
            escalationStatus: 'pending',
            escalationReason: escalationReason.slice(0, 500),
            humanOwnerUserId: task.humanOwnerUserId ?? recipientUserId,
            metadata: {
                ...metadata,
                heartbeatWatchdogState: 'attention_required',
                heartbeatWatchdogAlertedAt: params.at.toISOString(),
                heartbeatWatchdogLastSeenAt: new Date(lastSeenAt).toISOString(),
                heartbeatWatchdogStaleMinutes: staleMinutes,
                heartbeatWatchdogThresholdMinutes: thresholdMinutes,
                heartbeatWatchdogAssignedAgentId: task.assignedAgentId ?? null,
                heartbeatWatchdogAssignedAgentName: assignedAgent?.name ?? null,
                heartbeatWatchdogAssignedAgentStatus: assignedAgent?.status ?? null,
                heartbeatWatchdogLastKnownAgentHeartbeatAt: typeof assignedAgent?.metadata?.['lastHeartbeatAt'] === 'string'
                    ? assignedAgent.metadata['lastHeartbeatAt']
                    : null,
            },
        });
        if (!updated)
            continue;
        alerted++;
        await emitTaskWatchdogNotificationSafe({
            workspaceId: task.workspaceId,
            recipientUserId,
            task,
            assignedAgent,
            staleMinutes,
            thresholdMinutes,
            at: params.at,
        });
    }
    return alerted;
}
async function applyHeartbeatTaskClaims(agentDef, claimableTasks, responseText) {
    const protocol = parseHeartbeatProtocol(responseText);
    const claimableTaskIds = new Set(claimableTasks.map((task) => task.id));
    let claimed = 0;
    for (const claim of protocol.taskClaims) {
        if (!claimableTaskIds.has(claim.taskId))
            continue;
        const updated = await claimTeamTaskById(claim.taskId, agentDef.id, agentDef.ownerUserId);
        if (updated?.assignedAgentId === agentDef.id) {
            claimed++;
        }
    }
    return claimed;
}
async function updateAgentHeartbeatState(agentDef, updates) {
    const metadata = {
        ...(agentDef.metadata ?? {}),
        heartbeatFailureCount: updates.failureCount ?? 0,
        lastHeartbeatStatus: updates.lastHeartbeatStatus,
        lastHeartbeatAt: updates.lastHeartbeatAt.toISOString(),
        lastHeartbeatSummary: updates.lastHeartbeatSummary ?? null,
        lastHeartbeatError: updates.lastHeartbeatError ?? null,
        heartbeatCircuitOpenUntil: updates.circuitOpenUntil ?? null,
        heartbeatPausedBySystem: updates.pausedBySystem === true,
    };
    await memoryStore.updateAgent(agentDef.id, {
        ...(updates.status ? { status: updates.status } : {}),
        metadata,
    });
}
export function buildAgentHeartbeatPrompt(params) {
    const teamRulesSection = params.teamRules && params.teamRules.length > 0
        ? [
            '',
            'Team shared knowledge (learned by the team — apply these in your work):',
            ...params.teamRules.slice(0, 6).map((r) => `- [${r.category}] ${r.rule}`),
        ]
        : [];
    const teammateSection = [
        '',
        'Teammate state snapshot:',
        summarizeTeammateStates(params.teammates ?? []),
    ];
    const swarmStatusSection = [
        '',
        'Swarm status snapshot:',
        summarizeSwarmStatus(params.swarmStatus ?? []),
    ];
    return [
        'Agent heartbeat cycle.',
        `Time: ${(params.at ?? new Date()).toISOString()}`,
        `Workspace: ${params.agent.workspaceId}`,
        `Agent: ${params.agent.id} (${params.agent.name})`,
        '',
        'HEARTBEAT.md checklist:',
        params.checklist,
        '',
        'Current open tasks assigned to you:',
        summarizeAgentTasks(params.tasks),
        '',
        'Pending mailbox messages for you:',
        summarizeMailboxMessages(params.mailboxMessages),
        '',
        'Claimable shared tasks you may coordinate on:',
        summarizeClaimableTasks(params.claimableTasks),
        '',
        'Current on-call duties:',
        summarizeOnCallDuties(params.agent, params.onCallRotations),
        ...teammateSection,
        ...swarmStatusSection,
        ...teamRulesSection,
        '',
        'Rules:',
        '- Execute at most one concrete round of work.',
        '- For long-running tasks, inspect progress and move the next step forward.',
        '- If you claim shared work, return it in JSON as {"taskClaims":["task-id"]}.',
        '- If you handled mailbox items, return them in JSON as {"mailboxAcks":["mail-id"]}.',
        '- If you need to notify or challenge a teammate, return it in JSON as {"outboundMessages":[{"recipientAgentId":"...","taskId":"optional","threadId":"optional","type":"direct|challenge|consensus_request|consensus_response|task_event|broadcast","subject":"optional","message":"...","metadata":{"optional":"object"}}]}.',
        '- If you receive a consensus_request with protocol=consensus_debate, send a consensus_response that explicitly answers at least one opposing argument before restating your position.',
        '- For consensus_response messages, include metadata.decision="approve|changes_requested" and metadata.rationale with your concise reasoning when possible.',
        '- If work was done or progress changed, return ONLY JSON: {"updates":[{"taskId":"...","status":"assigned|in_progress|blocked|done","progressSummary":"...","nextAction":"...","blockedReason":"optional"}]}.',
        '- If you are blocked, include status="blocked" and blockedReason in that JSON.',
        '- You may combine taskClaims, mailboxAcks, outboundMessages, and updates in the same JSON object.',
        `- If there is nothing actionable right now, reply exactly ${HEARTBEAT_OK}.`,
    ].join('\n');
}
export async function runAgentHeartbeatCycle(options) {
    const checklist = loadHeartbeatChecklist(options?.cwd);
    const at = options?.at ?? new Date();
    const [allAgents, allTasks, allRotations, allTopologies] = await Promise.all([
        memoryStore.listAgents(),
        memoryStore.listTeamTasks(),
        memoryStore.listTeamOnCallRotations({ enabled: true }),
        memoryStore.listTeamTopologies(),
    ]);
    const candidateAgents = allAgents.filter((item) => {
        if (options?.workspaceId && item.workspaceId !== options.workspaceId)
            return false;
        if (options?.agentId && item.id !== options.agentId)
            return false;
        if (item.status === 'active')
            return true;
        const circuitOpenUntil = getHeartbeatCircuitOpenUntil(item);
        return item.status === 'paused'
            && isHeartbeatPausedAgent(item)
            && circuitOpenUntil !== null
            && circuitOpenUntil <= at.getTime();
    });
    let processed = 0;
    let idle = 0;
    let actionable = 0;
    let errors = 0;
    // Pre-load workspace-level team rules — shared knowledge from success/challenge reflection.
    // Keyed by "ownerUserId:workspaceId" to avoid redundant DB calls for agents in the same workspace.
    const teamRulesCache = new Map();
    const getTeamRules = async (agentDef) => {
        const key = `${agentDef.ownerUserId}:${agentDef.workspaceId}`;
        if (!teamRulesCache.has(key)) {
            const all = await memoryStore.getScopedBehavioralRules({ userId: agentDef.ownerUserId, channel: 'web', workspaceId: agentDef.workspaceId }, 50);
            teamRulesCache.set(key, all.filter((r) => r.source === 'success' || r.source === 'challenge_propagated'));
        }
        return teamRulesCache.get(key) ?? [];
    };
    for (const agentDef of candidateAgents) {
        const openTasks = allTasks.filter((task) => task.workspaceId === agentDef.workspaceId
            && task.assignedAgentId === agentDef.id
            && isOpenTask(task));
        const claimableTasks = allTasks.filter((task) => canAgentClaimTask(agentDef, task));
        const mailboxMessages = await memoryStore.listTeamMailboxMessages({
            workspaceId: agentDef.workspaceId,
            recipientAgentId: agentDef.id,
            status: 'pending',
        });
        const onCallRotations = allRotations.filter((rotation) => rotation.workspaceId === agentDef.workspaceId
            && (rotation.primaryAgentIds.includes(agentDef.id) || rotation.secondaryAgentIds.includes(agentDef.id)));
        const teammates = allAgents
            .filter((candidate) => candidate.workspaceId === agentDef.workspaceId && candidate.id !== agentDef.id)
            .map((candidate) => ({
            id: candidate.id,
            name: candidate.name,
            status: candidate.status,
            model: resolveHeartbeatAgentModel(candidate),
            lastHeartbeatStatus: typeof candidate.metadata?.['lastHeartbeatStatus'] === 'string'
                ? candidate.metadata['lastHeartbeatStatus']
                : null,
            lastHeartbeatSummary: typeof candidate.metadata?.['lastHeartbeatSummary'] === 'string'
                ? candidate.metadata['lastHeartbeatSummary']
                : null,
            openTaskCount: allTasks.filter((task) => task.workspaceId === agentDef.workspaceId
                && task.assignedAgentId === candidate.id
                && isOpenTask(task)).length,
        }));
        const swarmStatus = allTopologies
            .filter((topology) => topology.workspaceId === agentDef.workspaceId)
            .map((topology) => {
            const metadata = topology.metadata ?? {};
            const orchestratorRules = metadata['orchestratorRules'];
            const metrics = metadata['lastOrchMetrics'];
            const parsedMetrics = metrics && typeof metrics === 'object' && !Array.isArray(metrics)
                ? metrics
                : null;
            return {
                topologyName: topology.name,
                onConflict: orchestratorRules && typeof orchestratorRules === 'object' && !Array.isArray(orchestratorRules)
                    && orchestratorRules['onConflict'] === 'supervisor_resolve'
                    ? 'supervisor_resolve'
                    : 'consensus',
                challengeSuccessRate: Number.isFinite(Number(parsedMetrics?.['challengeSuccessRate']))
                    ? Number(parsedMetrics?.['challengeSuccessRate'])
                    : null,
                consensusTimeoutRate: Number.isFinite(Number(parsedMetrics?.['consensusTimeoutRate']))
                    ? Number(parsedMetrics?.['consensusTimeoutRate'])
                    : null,
            };
        });
        const heartbeatRoute = resolveHeartbeatExecutionRoute(agentDef, allTopologies);
        const teamRules = await getTeamRules(agentDef);
        const msg = {
            id: nanoid(),
            userId: agentDef.ownerUserId,
            channel: 'web',
            chatId: agentDef.workspaceId,
            text: buildAgentHeartbeatPrompt({
                agent: agentDef,
                checklist,
                tasks: openTasks,
                mailboxMessages,
                claimableTasks,
                onCallRotations,
                teamRules,
                teammates,
                swarmStatus,
                at,
            }),
            timestamp: at,
            metadata: {
                workspaceId: agentDef.workspaceId,
                agentId: agentDef.id,
                sessionKey: `heartbeat:${agentDef.id}`,
                heartbeat: true,
                ...(heartbeatRoute?.provider ? { agentProviderOverride: heartbeatRoute.provider } : {}),
                ...(heartbeatRoute?.model ? { agentModelOverride: heartbeatRoute.model } : {}),
                ...(heartbeatRoute
                    ? {
                        heartbeatTopologyId: heartbeatRoute.topologyId,
                        heartbeatTopologyName: heartbeatRoute.topologyName,
                    }
                    : {}),
            },
        };
        try {
            const { withAgentExecutionLease } = await import('../runtime/agent_runtime_guard.js');
            const result = await withAgentExecutionLease({ userId: msg.userId, channel: msg.channel, label: 'heartbeat_cycle' }, () => agent.processMessage(msg));
            const text = (result.text ?? '').trim();
            const appliedUpdates = await applyHeartbeatTaskUpdates(agentDef, openTasks, text, at);
            const mailboxEffects = await applyHeartbeatMailboxActions(agentDef, mailboxMessages, text, at);
            const claimedTasks = await applyHeartbeatTaskClaims(agentDef, claimableTasks, text);
            processed++;
            if (text === HEARTBEAT_OK || text.length === 0) {
                idle++;
                await markHeartbeatObservedTasks(agentDef, openTasks, at, 'idle');
                await updateAgentHeartbeatState(agentDef, {
                    status: 'active',
                    failureCount: 0,
                    lastHeartbeatStatus: isHeartbeatPausedAgent(agentDef) ? 'recovered' : 'idle',
                    lastHeartbeatAt: at,
                    lastHeartbeatSummary: HEARTBEAT_OK,
                    circuitOpenUntil: null,
                    pausedBySystem: false,
                });
                if (isHeartbeatPausedAgent(agentDef)) {
                    await emitHeartbeatNotificationSafe({
                        workspaceId: agentDef.workspaceId,
                        recipientUserId: agentDef.ownerUserId,
                        type: 'heartbeat_recovered',
                        severity: 'info',
                        title: `Heartbeat recovered: ${agentDef.name}`,
                        message: `Agent ${agentDef.name} recovered and resumed normal heartbeat execution.`,
                        agentDef,
                        at,
                        metadata: {
                            lastHeartbeatStatus: 'recovered',
                            lastHeartbeatSummary: HEARTBEAT_OK,
                        },
                    });
                }
            }
            else {
                actionable++;
                await markHeartbeatObservedTasks(agentDef, openTasks, at, 'actionable');
                await updateAgentHeartbeatState(agentDef, {
                    status: 'active',
                    failureCount: 0,
                    lastHeartbeatStatus: isHeartbeatPausedAgent(agentDef) ? 'recovered' : 'actionable',
                    lastHeartbeatAt: at,
                    lastHeartbeatSummary: text.slice(0, 500),
                    circuitOpenUntil: null,
                    pausedBySystem: false,
                });
                if (isHeartbeatPausedAgent(agentDef)) {
                    await emitHeartbeatNotificationSafe({
                        workspaceId: agentDef.workspaceId,
                        recipientUserId: agentDef.ownerUserId,
                        type: 'heartbeat_recovered',
                        severity: 'info',
                        title: `Heartbeat recovered: ${agentDef.name}`,
                        message: `Agent ${agentDef.name} recovered and reported actionable progress during heartbeat.`,
                        agentDef,
                        at,
                        metadata: {
                            lastHeartbeatStatus: 'recovered',
                            lastHeartbeatSummary: text.slice(0, 500),
                            appliedTaskUpdates: appliedUpdates,
                            mailboxAcks: mailboxEffects.acked,
                            mailboxMessagesSent: mailboxEffects.sent,
                            claimedTasks,
                        },
                    });
                }
                log.info({ agentId: agentDef.id, workspaceId: agentDef.workspaceId, preview: text.slice(0, 180) }, 'Agent heartbeat produced an actionable response');
                if (appliedUpdates === 0 && mailboxEffects.acked === 0 && mailboxEffects.sent === 0 && claimedTasks === 0) {
                    log.warn({ agentId: agentDef.id, workspaceId: agentDef.workspaceId }, 'Heartbeat produced actionable output but no structured task updates were applied');
                }
            }
        }
        catch (err) {
            errors++;
            const priorFailures = Number((agentDef.metadata ?? {})['heartbeatFailureCount']);
            const failureCount = Number.isFinite(priorFailures) ? priorFailures + 1 : 1;
            const failureThreshold = getHeartbeatFailureThreshold(agentDef);
            const shouldOpenCircuit = failureCount >= failureThreshold;
            const circuitOpenUntil = shouldOpenCircuit
                ? new Date(at.getTime() + getHeartbeatCircuitOpenMinutes(agentDef) * 60_000).toISOString()
                : null;
            await updateAgentHeartbeatState(agentDef, {
                ...(shouldOpenCircuit ? { status: 'paused' } : {}),
                failureCount,
                lastHeartbeatStatus: 'error',
                lastHeartbeatAt: at,
                lastHeartbeatError: String(err).slice(0, 500),
                circuitOpenUntil,
                pausedBySystem: shouldOpenCircuit,
            });
            if (shouldOpenCircuit) {
                await emitHeartbeatNotificationSafe({
                    workspaceId: agentDef.workspaceId,
                    recipientUserId: agentDef.ownerUserId,
                    type: 'heartbeat_circuit_opened',
                    severity: 'critical',
                    title: `Heartbeat circuit opened: ${agentDef.name}`,
                    message: `Agent ${agentDef.name} was paused after ${failureCount} consecutive heartbeat failures.`,
                    agentDef,
                    at,
                    metadata: {
                        heartbeatFailureCount: failureCount,
                        heartbeatFailureThreshold: failureThreshold,
                        heartbeatCircuitOpenUntil: circuitOpenUntil,
                        lastHeartbeatError: String(err).slice(0, 500),
                    },
                });
            }
            log.warn({ err: String(err), agentId: agentDef.id, workspaceId: agentDef.workspaceId }, 'Agent heartbeat failed');
        }
    }
    await runTaskHeartbeatWatchdog({
        tasks: allTasks,
        agents: allAgents,
        at,
        workspaceId: options?.workspaceId,
        agentId: options?.agentId,
    });
    return { processed, idle, actionable, errors };
}
// ── Mailbox fast-path ─────────────────────────────────────────────────────────
//
// When a mailbox_created event fires, running a full heartbeat cycle is wasteful:
// it loads all workspace tasks, all agents, all topologies, and makes a big LLM
// call just to tell the agent "you have a new message."
//
// runAgentMailboxCycle is a targeted alternative:
//   1. Auto-ack passive message types (broadcast, task_event) — zero LLM cost.
//   2. For messages requiring reasoning (direct, challenge, consensus_*),
//      make a SMALL focused LLM call with mailbox-only context.
//   3. Never touches the task list or workspace-wide data.
//
// The full heartbeat still runs on its normal schedule for task execution.
/** Message types that the agent needs to reason about before acknowledging. */
const MAILBOX_REASONING_TYPES = new Set([
    'direct',
    'challenge',
    'consensus_request',
    'consensus_response',
]);
function parsePositiveInteger(value) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0)
        return null;
    return Math.floor(parsed);
}
function getMailboxFailureCount(message) {
    return parsePositiveInteger(message.metadata?.['mailboxFailureCount']) ?? 0;
}
function getMailboxMaxFailures(message, agentDef) {
    return parsePositiveInteger(message.metadata?.['mailboxMaxFailures'])
        ?? parsePositiveInteger(agentDef.metadata?.['mailboxMaxFailures'])
        ?? DEFAULT_MAILBOX_MAX_FAILURES;
}
function formatMailboxFailureReason(err) {
    const message = err instanceof Error ? err.message : String(err);
    const trimmed = message.trim();
    return (trimmed || 'Unknown mailbox fast-path failure').slice(0, 300);
}
async function markMailboxMessagesFailed(params) {
    let pending = 0;
    let deadLettered = 0;
    const reason = formatMailboxFailureReason(params.err);
    const failedAt = params.at.toISOString();
    for (const message of params.messages) {
        if (message.status !== 'pending')
            continue;
        const failureCount = getMailboxFailureCount(message) + 1;
        const maxFailures = getMailboxMaxFailures(message, params.agentDef);
        const shouldDeadLetter = failureCount >= maxFailures;
        const metadata = {
            ...(message.metadata ?? {}),
            mailboxFailureCount: failureCount,
            mailboxLastFailureAt: failedAt,
            mailboxLastFailureReason: reason,
            mailboxLastFailedByAgentId: params.agentDef.id,
        };
        if (shouldDeadLetter) {
            metadata['mailboxDeadLetteredAt'] = failedAt;
            metadata['mailboxDeadLetterReason'] = reason;
            metadata['mailboxDeadLetteredByAgentId'] = params.agentDef.id;
        }
        const updated = await memoryStore.updateTeamMailboxMessage(message.id, {
            status: shouldDeadLetter ? 'dead_letter' : 'pending',
            metadata,
        });
        if (!updated)
            continue;
        if (shouldDeadLetter) {
            deadLettered++;
        }
        else {
            pending++;
        }
    }
    return { pending, deadLettered };
}
function buildMailboxOnlyPrompt(agentDef, messages, at) {
    return [
        'Mailbox check — new messages require your attention.',
        `Time: ${at.toISOString()}`,
        `Agent: ${agentDef.id} (${agentDef.name})`,
        '',
        'Pending mailbox messages:',
        summarizeMailboxMessages(messages),
        '',
        'Rules:',
        '- Process only these mailbox messages; do not execute task work.',
        '- If you handled mailbox items, return JSON: {"mailboxAcks":["mail-id",...]}.',
        '- If you need to reply to a teammate, include JSON: {"outboundMessages":[{"recipientAgentId":"...","taskId":"optional","threadId":"optional","type":"direct|consensus_response","subject":"optional","message":"..."}]}.',
        '- For consensus_request with protocol=consensus_debate, send a consensus_response that addresses at least one opposing argument before restating your position.',
        '- For consensus_response, include metadata.decision="approve|changes_requested" and metadata.rationale.',
        `- If nothing requires a reply, return exactly ${HEARTBEAT_OK}.`,
    ].join('\n');
}
/**
 * Lightweight mailbox-only cycle for a single agent.
 * Called when a mailbox_created event fires for that agent.
 * Does NOT run the full heartbeat; loads only the agent and their pending messages.
 */
export async function runAgentMailboxCycle(params) {
    const at = new Date();
    // Load only this agent (skip expensive workspace-wide data)
    const allAgents = await memoryStore.listAgents(params.workspaceId);
    const agentDef = allAgents.find((a) => a.id === params.agentId && a.workspaceId === params.workspaceId);
    if (!agentDef)
        return { acked: 0, sent: 0 };
    // Skip paused/circuit-broken agents
    if (agentDef.status !== 'active') {
        if (agentDef.status === 'paused') {
            // Only allow mailbox processing on the circuit-expiry recovery path:
            // circuit must have been set AND must have already expired.
            const circuitOpenUntil = getHeartbeatCircuitOpenUntil(agentDef);
            const circuitExpired = circuitOpenUntil !== null && circuitOpenUntil <= at.getTime();
            if (!circuitExpired)
                return { acked: 0, sent: 0 };
        }
        else {
            return { acked: 0, sent: 0 };
        }
    }
    const allMessages = await memoryStore.listTeamMailboxMessages({
        workspaceId: params.workspaceId,
        recipientAgentId: params.agentId,
        status: 'pending',
    });
    if (allMessages.length === 0)
        return { acked: 0, sent: 0 };
    // Partition: passive messages auto-ack, reasoning messages go to LLM
    const passive = allMessages.filter((m) => !MAILBOX_REASONING_TYPES.has(m.type));
    const active = allMessages.filter((m) => MAILBOX_REASONING_TYPES.has(m.type));
    let acked = 0;
    // Auto-ack passive messages (broadcast, task_event) without LLM
    for (const msg of passive) {
        const updated = await memoryStore.updateTeamMailboxMessage(msg.id, {
            status: 'acknowledged',
            acknowledgedAt: at,
            metadata: {
                ...(msg.metadata ?? {}),
                acknowledgedByAgentId: agentDef.id,
                acknowledgedByMailboxFastPathAt: at.toISOString(),
            },
        });
        if (updated)
            acked++;
    }
    if (active.length === 0) {
        log.debug({ agentId: params.agentId, workspaceId: params.workspaceId, autoAcked: acked }, 'Mailbox fast-path: all messages auto-acked');
        return { acked, sent: 0 };
    }
    // Targeted LLM call for messages requiring reasoning
    const heartbeatRoute = (() => {
        // Use the same model-override logic as the full heartbeat but without
        // loading all topologies — resolve from agent metadata directly.
        const provider = typeof agentDef.metadata?.['agentProviderOverride'] === 'string'
            ? agentDef.metadata['agentProviderOverride']
            : null;
        const model = typeof agentDef.metadata?.['agentModelOverride'] === 'string'
            ? agentDef.metadata['agentModelOverride']
            : null;
        return { provider, model };
    })();
    const incomingMsg = {
        id: nanoid(),
        userId: agentDef.ownerUserId,
        channel: 'web',
        chatId: agentDef.workspaceId,
        text: buildMailboxOnlyPrompt(agentDef, active, at),
        timestamp: at,
        metadata: {
            workspaceId: agentDef.workspaceId,
            agentId: agentDef.id,
            sessionKey: `mailbox-fast-path:${agentDef.id}`,
            heartbeat: true,
            ...(heartbeatRoute.provider ? { agentProviderOverride: heartbeatRoute.provider } : {}),
            ...(heartbeatRoute.model ? { agentModelOverride: heartbeatRoute.model } : {}),
        },
    };
    try {
        const { withAgentExecutionLease } = await import('../runtime/agent_runtime_guard.js');
        const result = await withAgentExecutionLease({ userId: incomingMsg.userId, channel: incomingMsg.channel, label: 'mailbox_fast_path' }, () => agent.processMessage(incomingMsg));
        const text = (result.text ?? '').trim();
        const effects = await applyHeartbeatMailboxActions(agentDef, active, text, at);
        log.info({
            agentId: params.agentId,
            workspaceId: params.workspaceId,
            autoAcked: acked,
            llmAcked: effects.acked,
            sent: effects.sent,
            active: active.length,
        }, 'Mailbox fast-path: LLM processed active messages');
        return { acked: acked + effects.acked, sent: effects.sent };
    }
    catch (err) {
        const failed = await markMailboxMessagesFailed({ agentDef, messages: active, at, err });
        log.warn({
            err: String(err),
            agentId: params.agentId,
            workspaceId: params.workspaceId,
            failedPending: failed.pending,
            deadLettered: failed.deadLettered,
        }, failed.deadLettered > 0
            ? 'Mailbox fast-path LLM call failed; exhausted messages moved to dead-letter'
            : 'Mailbox fast-path LLM call failed; messages remain pending with failure metadata');
        return { acked, sent: 0 };
    }
}
//# sourceMappingURL=heartbeat.js.map