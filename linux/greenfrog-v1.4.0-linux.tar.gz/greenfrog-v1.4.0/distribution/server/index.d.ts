/**
 * Distribution server handlers.
 *
 * Five endpoints:
 *   POST /api/distribution/enroll              — no auth (first boot)
 *   POST /api/distribution/backflow            — validateChildJwt
 *   GET  /api/distribution/inheritance/latest  — validateChildJwt
 *   GET  /api/distribution/inheritance/:releaseId — validateChildJwt
 *   POST /api/distribution/enroll/revoke       — validateChildJwt
 *
 * Auth model (two-phase):
 *
 *   Phase 1 — Bootstrap (enrollment only):
 *     - Child sends instanceId + enrollmentKey in POST /enroll body (no Bearer header)
 *     - enrollmentKey is 256-bit crypto-random, auto-generated at first boot
 *     - Server validates fields and issues a JWT signed with gateway secret (HMAC-SHA256)
 *
 *   Phase 2 — Ongoing (all subsequent calls):
 *     - Child uses the issued JWT as "Authorization: Bearer <JWT>"
 *     - Server verifies JWT signature + extracts instanceId from sub claim
 *     - Looks up instance in registry by instanceId to check revocation
 *     - enrollmentKey is NOT sent in API headers after enrollment
 *
 *   Revoke:
 *     - Child sends POST /enroll/revoke with its JWT
 *     - Server verifies JWT, marks instance revoked by instanceId
 *     - Subsequent calls with the same JWT are rejected (401)
 */
import type { Request, Response, NextFunction } from 'express';
/** Verify a JWT and return the instanceId (sub), or null if invalid. */
export declare function verifyChildJwt(token: string, secret: string): string | null;
export interface ChildAuthOptions {
    jwtSecret: string;
    baseDir?: string;
}
/**
 * Express middleware that authenticates child instances via their issued JWT.
 *
 * Extracts Bearer token, verifies HMAC-SHA256 signature, extracts instanceId
 * from sub claim, checks registry for revocation, attaches enrolledInstance
 * to the request.
 */
export declare function validateChildJwt(req: Request, res: Response, next: NextFunction, opts: ChildAuthOptions): void;
/** Factory that returns a validateChildJwt middleware bound to options. */
export declare function makeChildAuthMiddleware(opts: ChildAuthOptions): (req: Request, res: Response, next: NextFunction) => void;
export interface EnrollHandlerOptions {
    jwtSecret: string;
    baseDir?: string;
}
export declare function handleEnroll(opts: EnrollHandlerOptions): (req: Request, res: Response) => void;
export declare function handleBackflow(_baseDir?: string): (req: Request, res: Response) => void;
export declare function handleInheritanceLatest(manifestsDir?: string): (req: Request, res: Response) => void;
export declare function handleInheritanceById(manifestsDir?: string): (req: Request, res: Response) => void;
export declare function handleRevoke(opts: {
    baseDir?: string;
}): (req: Request, res: Response) => void;
//# sourceMappingURL=index.d.ts.map