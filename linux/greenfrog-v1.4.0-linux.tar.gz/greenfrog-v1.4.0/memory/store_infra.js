import { nanoid } from 'nanoid';
export function createInfraStore(db, rlCache) {
    const api = {
        checkRateLimit(key, limit, windowMs) {
            const now = Date.now();
            const cached = rlCache.get(key);
            if (cached && now <= cached.resetAt) {
                if (cached.count >= limit)
                    return false;
                cached.count += 1;
                return true;
            }
            const row = db.prepare(`SELECT count, reset_at FROM rate_limits WHERE key = ?`).get(key);
            if (!row || now > row.reset_at) {
                const resetAt = now + windowMs;
                db.prepare(`INSERT OR REPLACE INTO rate_limits (key, count, reset_at) VALUES (?, 1, ?)`).run(key, resetAt);
                rlCache.set(key, { count: 1, resetAt });
                return true;
            }
            if (row.count >= limit) {
                rlCache.set(key, { count: row.count, resetAt: row.reset_at });
                return false;
            }
            db.prepare(`UPDATE rate_limits SET count = count + 1 WHERE key = ?`).run(key);
            rlCache.set(key, { count: row.count + 1, resetAt: row.reset_at });
            return true;
        },
        cleanupRateLimits() {
            const now = Date.now();
            for (const [key, value] of rlCache) {
                if (now > value.resetAt)
                    rlCache.delete(key);
            }
            db.prepare(`DELETE FROM rate_limits WHERE reset_at < ?`).run(now);
        },
        trackError(opts) {
            db.prepare(`INSERT INTO error_events (id, level, message, context, stack, user_id, channel, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), opts.level ?? 'error', opts.message, opts.context ? JSON.stringify(opts.context) : null, opts.stack ?? null, opts.userId ?? null, opts.channel ?? null, Date.now());
        },
        getRecentErrors(limit = 50) {
            const rows = db.prepare(`SELECT id, level, message, context, user_id, channel, created_at
         FROM error_events ORDER BY created_at DESC LIMIT ?`).all(limit);
            return rows.map((row) => ({
                id: row.id,
                level: row.level,
                message: row.message,
                context: row.context ? JSON.parse(row.context) : null,
                userId: row.user_id,
                channel: row.channel,
                createdAt: new Date(row.created_at),
            }));
        },
        logAudit(entry) {
            const sensitiveParams = new Set([
                'apiKey', 'token', 'botToken', 'appToken', 'accessToken', 'refreshToken',
                'secret', 'signingSecret', 'clientSecret', 'appSecret', 'jwtSecret',
                'password', 'passwd', 'passphrase',
                'key', 'privateKey',
                'authorization', 'credential', 'credentials',
                'cookie', 'sessionId', 'authToken',
            ]);
            let params = entry.params;
            if (params) {
                params = Object.fromEntries(Object.entries(params).map(([key, value]) => sensitiveParams.has(key) ? [key, '[REDACTED]'] : [key, value]));
            }
            db.prepare(`INSERT INTO audit_log (id, timestamp, user_id, channel, chat_id, skill_name, params, success, duration_ms, error, role)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(nanoid(), Date.now(), entry.userId, entry.channel, entry.chatId ?? null, entry.skillName, params ? JSON.stringify(params) : null, entry.success ? 1 : 0, entry.durationMs, entry.error ?? null, entry.role ?? null);
            db.prepare(`INSERT INTO skill_stats (skill_name, call_count, success_count, total_duration_ms, last_called_at)
         VALUES (?, 1, ?, ?, ?)
         ON CONFLICT(skill_name) DO UPDATE SET
           call_count = call_count + 1,
           success_count = success_count + excluded.success_count,
           total_duration_ms = total_duration_ms + excluded.total_duration_ms,
           last_called_at = excluded.last_called_at`).run(entry.skillName, entry.success ? 1 : 0, entry.durationMs, Date.now());
        },
        queryAuditLog(opts) {
            const conditions = [];
            const args = [];
            if (opts.userId) {
                conditions.push('user_id = ?');
                args.push(opts.userId);
            }
            if (opts.skillName) {
                conditions.push('skill_name = ?');
                args.push(opts.skillName);
            }
            if (opts.channel) {
                conditions.push('channel = ?');
                args.push(opts.channel);
            }
            if (opts.success !== undefined) {
                conditions.push('success = ?');
                args.push(opts.success ? 1 : 0);
            }
            if (opts.sinceMs) {
                conditions.push('timestamp >= ?');
                args.push(Date.now() - opts.sinceMs);
            }
            const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            args.push(opts.limit ?? 100);
            const rows = db.prepare(`SELECT * FROM audit_log ${where} ORDER BY timestamp DESC LIMIT ?`).all(...args);
            return rows.map((row) => ({
                id: row['id'],
                timestamp: new Date(row['timestamp']),
                userId: row['user_id'],
                channel: row['channel'],
                chatId: row['chat_id'],
                skillName: row['skill_name'],
                params: row['params'] ? JSON.parse(row['params']) : null,
                success: row['success'] === 1,
                durationMs: row['duration_ms'],
                error: row['error'],
                role: row['role'],
            }));
        },
        getSkillStats() {
            const rows = db.prepare(`SELECT skill_name, call_count, success_count, total_duration_ms, last_called_at
         FROM skill_stats ORDER BY call_count DESC`).all();
            return rows.map((row) => ({
                skillName: row.skill_name,
                callCount: row.call_count,
                successCount: row.success_count,
                successRate: row.call_count > 0 ? Math.round((row.success_count / row.call_count) * 100) : 0,
                avgDurationMs: row.call_count > 0 ? Math.round(row.total_duration_ms / row.call_count) : 0,
                lastCalledAt: row.last_called_at ? new Date(row.last_called_at) : null,
            }));
        },
        getAuthRevokedAfter(userId) {
            const row = db.prepare(`SELECT revoked_after FROM auth_revocations WHERE user_id = ?`).get(userId);
            return row?.revoked_after ?? null;
        },
        revokeAuthSessions(userId, opts) {
            const revokedAfter = Math.floor(opts?.revokedAfter ?? Date.now() / 1000);
            const now = Date.now();
            db.prepare(`INSERT INTO auth_revocations (user_id, revoked_after, revoked_by, reason, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET
           revoked_after = excluded.revoked_after,
           revoked_by = excluded.revoked_by,
           reason = excluded.reason,
           updated_at = excluded.updated_at`).run(userId, revokedAfter, opts?.revokedBy ?? null, opts?.reason ?? null, now, now);
        },
        recordTokenUsage(record) {
            const total = record.inputTokens + record.outputTokens;
            db.prepare(`
        INSERT INTO token_usage
          (id, user_id, workspace_id, agent_id, provider, model,
           input_tokens, output_tokens, total_tokens, cost_usd,
           channel, session_key, recorded_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
      `).run(nanoid(), record.userId, record.workspaceId ?? null, record.agentId ?? null, record.provider, record.model, record.inputTokens, record.outputTokens, total, record.costUsd ?? null, record.channel ?? null, record.sessionKey ?? null, Date.now());
        },
        getTokenUsageSummary(filter) {
            const period = filter.period ?? new Date().toISOString().slice(0, 7);
            const start = new Date(`${period}-01T00:00:00Z`);
            const end = new Date(start);
            end.setMonth(end.getMonth() + 1);
            const startMs = start.getTime();
            const endMs = end.getTime();
            const rows = [];
            if (filter.userId) {
                const row = db.prepare(`
          SELECT 'user' AS scope_type, user_id AS scope_id,
                 SUM(input_tokens) AS total_input, SUM(output_tokens) AS total_output,
                 SUM(total_tokens) AS total_tokens, SUM(cost_usd) AS total_cost,
                 COUNT(*) AS call_count
          FROM token_usage
          WHERE user_id = ? AND recorded_at >= ? AND recorded_at < ?
          GROUP BY user_id
        `).get(filter.userId, startMs, endMs);
                if (row)
                    rows.push(row);
            }
            else if (filter.workspaceId) {
                const row = db.prepare(`
          SELECT 'workspace' AS scope_type, workspace_id AS scope_id,
                 SUM(input_tokens) AS total_input, SUM(output_tokens) AS total_output,
                 SUM(total_tokens) AS total_tokens, SUM(cost_usd) AS total_cost,
                 COUNT(*) AS call_count
          FROM token_usage
          WHERE workspace_id = ? AND recorded_at >= ? AND recorded_at < ?
          GROUP BY workspace_id
        `).get(filter.workspaceId, startMs, endMs);
                if (row)
                    rows.push(row);
            }
            else {
                const row = db.prepare(`
          SELECT 'global' AS scope_type, 'global' AS scope_id,
                 SUM(input_tokens) AS total_input, SUM(output_tokens) AS total_output,
                 SUM(total_tokens) AS total_tokens, SUM(cost_usd) AS total_cost,
                 COUNT(*) AS call_count
          FROM token_usage
          WHERE recorded_at >= ? AND recorded_at < ?
        `).get(startMs, endMs);
                if (row)
                    rows.push(row);
            }
            return rows.map((row) => ({
                scopeType: row.scope_type,
                scopeId: row.scope_id,
                period,
                totalInputTokens: Number(row.total_input ?? 0),
                totalOutputTokens: Number(row.total_output ?? 0),
                totalTokens: Number(row.total_tokens ?? 0),
                totalCostUsd: row.total_cost != null ? Number(row.total_cost) : null,
                callCount: Number(row.call_count ?? 0),
            }));
        },
        getTokenUsageDetail(filter) {
            const limit = Math.min(filter.limit ?? 50, 200);
            const offset = filter.offset ?? 0;
            let sql;
            let params;
            if (filter.userId) {
                sql = `SELECT * FROM token_usage WHERE user_id = ? ORDER BY recorded_at DESC LIMIT ? OFFSET ?`;
                params = [filter.userId, limit, offset];
            }
            else if (filter.workspaceId) {
                sql = `SELECT * FROM token_usage WHERE workspace_id = ? ORDER BY recorded_at DESC LIMIT ? OFFSET ?`;
                params = [filter.workspaceId, limit, offset];
            }
            else {
                sql = `SELECT * FROM token_usage ORDER BY recorded_at DESC LIMIT ? OFFSET ?`;
                params = [limit, offset];
            }
            const rows = db.prepare(sql).all(...params);
            return rows.map((row) => ({
                id: row['id'],
                userId: row['user_id'],
                workspaceId: row['workspace_id'] ?? null,
                agentId: row['agent_id'] ?? null,
                provider: row['provider'],
                model: row['model'],
                inputTokens: Number(row['input_tokens']),
                outputTokens: Number(row['output_tokens']),
                totalTokens: Number(row['total_tokens']),
                costUsd: row['cost_usd'] != null ? Number(row['cost_usd']) : null,
                channel: row['channel'] ?? null,
                sessionKey: row['session_key'] ?? null,
                recordedAt: new Date(row['recorded_at']),
            }));
        },
        setUserQuota(quota) {
            db.prepare(`
        INSERT INTO user_quotas (scope_type, scope_id, monthly_token_limit, monthly_cost_limit_usd, limit_behavior, updated_at)
        VALUES (?,?,?,?,?,?)
        ON CONFLICT(scope_type, scope_id) DO UPDATE SET
          monthly_token_limit = excluded.monthly_token_limit,
          monthly_cost_limit_usd = excluded.monthly_cost_limit_usd,
          limit_behavior = excluded.limit_behavior,
          updated_at = excluded.updated_at
      `).run(quota.scopeType, quota.scopeId, quota.monthlyTokenLimit ?? null, quota.monthlyCostLimitUsd ?? null, quota.limitBehavior ?? 'soft', Date.now());
        },
        getUserQuota(scopeType, scopeId) {
            const row = db.prepare(`SELECT * FROM user_quotas WHERE scope_type = ? AND scope_id = ?`).get(scopeType, scopeId);
            if (!row)
                return null;
            return {
                scopeType: row['scope_type'],
                scopeId: row['scope_id'],
                monthlyTokenLimit: row['monthly_token_limit'] != null ? Number(row['monthly_token_limit']) : null,
                monthlyCostLimitUsd: row['monthly_cost_limit_usd'] != null ? Number(row['monthly_cost_limit_usd']) : null,
                limitBehavior: row['limit_behavior'],
                updatedAt: new Date(row['updated_at']),
            };
        },
        listUserQuotas() {
            const rows = db.prepare(`SELECT * FROM user_quotas ORDER BY scope_type, scope_id`).all();
            return rows.map((row) => ({
                scopeType: row['scope_type'],
                scopeId: row['scope_id'],
                monthlyTokenLimit: row['monthly_token_limit'] != null ? Number(row['monthly_token_limit']) : null,
                monthlyCostLimitUsd: row['monthly_cost_limit_usd'] != null ? Number(row['monthly_cost_limit_usd']) : null,
                limitBehavior: row['limit_behavior'],
                updatedAt: new Date(row['updated_at']),
            }));
        },
        addWorkspaceMember(workspaceId, userId, role) {
            db.prepare(`
        INSERT INTO workspace_members (workspace_id, user_id, role, joined_at)
        VALUES (?,?,?,?)
        ON CONFLICT(workspace_id, user_id) DO UPDATE SET role = excluded.role
      `).run(workspaceId, userId, role, Date.now());
        },
        removeWorkspaceMember(workspaceId, userId) {
            db.prepare(`DELETE FROM workspace_members WHERE workspace_id = ? AND user_id = ?`).run(workspaceId, userId);
        },
        getWorkspaceMembership(workspaceId, userId) {
            const row = db.prepare(`SELECT role FROM workspace_members WHERE workspace_id = ? AND user_id = ?`).get(workspaceId, userId);
            if (!row)
                return null;
            return { role: row.role };
        },
        listWorkspaceMembers(workspaceId) {
            const rows = db.prepare(`SELECT user_id, role, joined_at FROM workspace_members WHERE workspace_id = ? ORDER BY joined_at`).all(workspaceId);
            return rows.map((row) => ({ userId: row.user_id, role: row.role, joinedAt: new Date(row.joined_at) }));
        },
        listUserWorkspaces(userId) {
            const rows = db.prepare(`SELECT workspace_id, role, joined_at FROM workspace_members WHERE user_id = ? ORDER BY joined_at`).all(userId);
            return rows.map((row) => ({ workspaceId: row.workspace_id, role: row.role, joinedAt: new Date(row.joined_at) }));
        },
    };
    return api;
}
//# sourceMappingURL=store_infra.js.map