/**
 * Workflow — 自主工作流技能
 *
 * 真正的 Proactive Agent 核心：定义多步骤任务链，每步可以：
 *   1. 用任意 prompt（可引用前步结果）调用完整 agentic loop（含工具）
 *   2. 根据条件决定是否通知用户
 *   3. 根据条件决定是否继续后续步骤
 *
 * 使用场景举例：
 *   竞品监控：抓取页面 → AI 对比变化 → 有变化才推送
 *   每日简报：查天气 → 查新闻 → 查日历 → 合并成一条推送
 *   服务巡检报告：收集各服务状态 → AI 汇总 → 异常时告警
 *   内容助手：收集热点 → AI 草拟内容 → 发给你审核
 *
 * prompt 模板语法：
 *   {{step_id}}   — 引用某步骤的输出
 *   {{context.key}} — 引用运行时上下文变量
 *
 * notify_if / stop_if 条件：
 *   'always'      — 每次都通知/停止
 *   'never'       — 从不通知/停止
 *   'on_alert'    — 响应包含告警关键词时（error/失败/异常/down/❌）
 *   'if_changed'  — 与上次运行结果不同时
 *   'empty'       — 响应为空时（stop_if 专用）
 *   'keyword:XXX' — 响应包含 XXX 时
 */
import { BaseSkill } from './base.js';
import { memoryStore } from '../memory/store.js';
import cron from 'node-cron';
import { triggerWorkflowNow } from '../runtime/workflow_executor.js';
// Alert keywords for 'on_alert' condition
const ALERT_KEYWORDS = ['error', 'fail', 'failed', 'down', 'offline', '异常', '失败', '错误', '告警', '不可用', '❌', '🔴'];
export function matchesCondition(text, condition, lastResult) {
    if (!condition || condition === 'never')
        return false;
    if (condition === 'always')
        return true;
    if (condition === 'on_alert') {
        const lower = text.toLowerCase();
        return ALERT_KEYWORDS.some((kw) => lower.includes(kw.toLowerCase()));
    }
    if (condition === 'if_changed') {
        return lastResult === undefined || text.trim() !== lastResult.trim();
    }
    if (condition === 'empty') {
        return !text.trim();
    }
    if (condition.startsWith('keyword:')) {
        const kw = condition.slice(8);
        return text.includes(kw);
    }
    return false;
}
export function renderTemplate(template, context) {
    return template.replace(/\{\{(\w+(?:\.\w+)?)\}\}/g, (_, key) => context[key] ?? '');
}
export class WorkflowSkill extends BaseSkill {
    definition = {
        name: 'workflow',
        description: '自主工作流：定义多步任务链，每步用 AI+工具完成一项工作，根据条件决定是否推送通知和是否继续。' +
            '实现真正的 Proactive Agent：感知环境 → 判断 → 执行 → 按需汇报。',
        category: 'automation',
        parameters: [
            {
                name: 'action', type: 'string', required: true,
                description: '操作',
                enum: ['create', 'list', 'delete', 'run_now', 'pause', 'resume', 'show'],
            },
            { name: 'name', type: 'string', description: '工作流名称（create 时必填）' },
            { name: 'description', type: 'string', description: '工作流描述' },
            { name: 'trigger', type: 'string', description: 'Cron 表达式（如 "0 9 * * *"）或 "manual"' },
            {
                name: 'steps', type: 'string',
                description: 'JSON 数组，每个步骤：{id, prompt, save_as?, notify_if?, stop_if?}',
            },
            { name: 'workflow_id', type: 'string', description: '工作流 ID（delete/run_now/pause/resume/show 时需要）' },
        ],
        examples: [
            '创建竞品监控工作流：每天早9点抓取竞品网站，有变化才通知我',
            '每日简报：6点运行，查天气+新闻+任务，合并推送一条',
            '服务巡检报告：每小时检查各服务，只有发现异常才推送',
        ],
    };
    async execute(params, ctx) {
        const { userId, channel, chatId } = ctx;
        const action = params.action;
        switch (action) {
            case 'create': return this.create(params, userId, channel, chatId);
            case 'list': return this.list(userId);
            case 'delete': return this.delete(params, userId);
            case 'run_now': return this.runNow(params, userId);
            case 'pause': return this.setStatus(params, userId, 'paused');
            case 'resume': return this.setStatus(params, userId, 'active');
            case 'show': return this.show(params, userId);
            default: return this.err(`未知操作: ${action}`);
        }
    }
    create(params, userId, channel, chatId) {
        const name = (params.name ?? '').trim();
        const trigger = (params.trigger ?? 'manual').trim();
        if (!name)
            return this.err('name 不能为空');
        let steps;
        try {
            const raw = params.steps;
            if (!raw)
                return this.err('steps 不能为空，传入 JSON 数组');
            steps = JSON.parse(raw);
            if (!Array.isArray(steps) || steps.length === 0)
                return this.err('steps 必须是非空 JSON 数组');
            for (const s of steps) {
                if (!s.id || !s.prompt)
                    return this.err(`步骤缺少 id 或 prompt: ${JSON.stringify(s)}`);
            }
        }
        catch (e) {
            return this.err(`steps 格式错误（需要 JSON 数组）: ${String(e)}`);
        }
        if (trigger !== 'manual' && !cron.validate(trigger)) {
            return this.err(`无效的 cron 表达式: "${trigger}"。示例: "0 9 * * *" = 每天早9点`);
        }
        const id = memoryStore.saveWorkflow({
            name,
            description: params.description,
            trigger,
            steps,
            channel,
            chatId,
            userId,
            status: 'active',
        });
        const stepSummary = steps.map((s, i) => `  ${i + 1}. [${s.id}] ${s.prompt.slice(0, 60)}${s.prompt.length > 60 ? '…' : ''}` +
            (s.notifyIf ? ` · 通知: ${s.notifyIf}` : '') +
            (s.stopIf ? ` · 停止: ${s.stopIf}` : '')).join('\n');
        return this.text(`🔄 **工作流已创建**\n\n` +
            `ID: \`${id}\`\n` +
            `名称: ${name}\n` +
            `触发: ${trigger === 'manual' ? '手动' : `定时 \`${trigger}\``}\n` +
            `步骤数: ${steps.length}\n\n` +
            `步骤:\n${stepSummary}\n\n` +
            (trigger !== 'manual'
                ? '工作流已激活，将按计划自动运行。'
                : '工作流已保存，用 workflow run_now 手动触发。'));
    }
    async list(userId) {
        const wfs = await memoryStore.getWorkflows(userId);
        if (wfs.length === 0)
            return this.text('暂无工作流。用 workflow create 创建一个。');
        const lines = wfs.map((wf) => `${wf.status === 'active' ? '✅' : '⏸'} \`${wf.id.slice(0, 8)}\` **${wf.name}**\n` +
            `  触发: ${wf.trigger === 'manual' ? '手动' : wf.trigger} · 步骤: ${wf.steps.length} · 运行: ${wf.runCount}次\n` +
            `  上次运行: ${wf.lastRun ? wf.lastRun.toLocaleString() : '从未'}` +
            (wf.description ? `\n  ${wf.description}` : ''));
        return this.text(`🔄 **工作流列表 (${wfs.length})**\n\n${lines.join('\n\n')}`);
    }
    async show(params, userId) {
        const id = (params.workflow_id ?? '').trim();
        if (!id)
            return this.err('workflow_id 不能为空');
        const wf = (await memoryStore.getWorkflows(userId)).find((w) => w.id === id || w.id.startsWith(id));
        if (!wf)
            return this.err(`未找到工作流: ${id}`);
        const steps = wf.steps.map((s, i) => `**步骤 ${i + 1}: ${s.id}**\n` +
            `Prompt: ${s.prompt}\n` +
            (s.saveAs ? `保存为: \`${s.saveAs}\`\n` : '') +
            (s.notifyIf ? `通知条件: ${s.notifyIf}\n` : '') +
            (s.stopIf ? `停止条件: ${s.stopIf}\n` : '')).join('\n');
        return this.text(`🔄 **${wf.name}**\nID: \`${wf.id}\`\n触发: ${wf.trigger}\n状态: ${wf.status}\n\n${steps}`);
    }
    async delete(params, userId) {
        const id = (params.workflow_id ?? '').trim();
        if (!id)
            return this.err('workflow_id 不能为空');
        const wfs = await memoryStore.getWorkflows(userId);
        const wf = wfs.find((w) => w.id === id || w.id.startsWith(id));
        if (!wf)
            return this.err(`未找到工作流: ${id}`);
        await memoryStore.deleteWorkflow(wf.id);
        // Cancel live cron task if any
        import('../scheduler/index.js').then(({ scheduler }) => {
            scheduler.cancelJob(`wf:${wf.id}`);
        }).catch(() => { });
        return this.text(`已删除工作流: ${wf.name} (\`${wf.id}\`)`);
    }
    async runNow(params, userId) {
        const id = (params.workflow_id ?? '').trim();
        if (!id)
            return this.err('workflow_id 不能为空');
        const wfs = await memoryStore.getWorkflows(userId);
        const wf = wfs.find((w) => w.id === id || w.id.startsWith(id));
        if (!wf)
            return this.err(`未找到工作流: ${id}`);
        // Trigger real execution (fire-and-forget — executor runs asynchronously).
        // triggerWorkflowNow creates the run record synchronously and returns immediately.
        const runRecord = triggerWorkflowNow(wf);
        return this.text(`▶️ 工作流 **${wf.name}** 已开始执行。\n\n` +
            `Run ID: \`${runRecord.runId}\`\n` +
            `状态: ${runRecord.status === 'running' ? '执行中' : runRecord.status}\n` +
            (runRecord.status === 'failed' && runRecord.error
                ? `错误: ${runRecord.error}\n`
                : `步骤执行时会根据各步骤的通知条件决定是否推送结果。`));
    }
    async setStatus(params, userId, status) {
        const id = (params.workflow_id ?? '').trim();
        if (!id)
            return this.err('workflow_id 不能为空');
        const wfs = await memoryStore.getWorkflows(userId);
        const wf = wfs.find((w) => w.id === id || w.id.startsWith(id));
        if (!wf)
            return this.err(`未找到工作流: ${id}`);
        await memoryStore.updateWorkflowStatus(wf.id, status);
        return this.text(`${status === 'paused' ? '⏸ 已暂停' : '▶️ 已恢复'}工作流: ${wf.name}`);
    }
}
//# sourceMappingURL=workflow.js.map