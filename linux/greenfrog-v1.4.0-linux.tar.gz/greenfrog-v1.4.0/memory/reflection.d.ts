import type { ChannelName, MemoryScope } from '../utils/types.js';
export interface ReflectionResult {
    rulesAdded: number;
    rulesReinforced: number;
    summary: string;
    rules: Array<{
        rule: string;
        category: string;
        confidence: number;
    }>;
}
export declare function runReflection(userId: string, channel: ChannelName, minSamples?: number): Promise<ReflectionResult>;
export declare function runScopedReflection(scope: MemoryScope, minSamples?: number): Promise<ReflectionResult>;
//# sourceMappingURL=reflection.d.ts.map