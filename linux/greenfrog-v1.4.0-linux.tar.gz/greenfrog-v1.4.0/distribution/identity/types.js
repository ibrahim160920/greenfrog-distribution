/**
 * Types for the GreenFrog child distribution identity system.
 */
export {};
//# sourceMappingURL=types.js.map