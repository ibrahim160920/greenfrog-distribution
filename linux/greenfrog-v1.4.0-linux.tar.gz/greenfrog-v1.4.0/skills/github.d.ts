import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class GitHubSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    private get headers();
    private gh;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=github.d.ts.map