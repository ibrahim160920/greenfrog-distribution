/**
 * enrollment.ts — Identity generation and enrollment key management.
 *
 * Responsibilities:
 *   - Generate installId (128-bit random UUID, stable per installation)
 *   - Derive instanceId (SHA-256 anonymized, safe to send externally)
 *   - Generate enrollmentKey (256-bit cryptographic random hex)
 *   - Persist to .greenfrog/identity/install.json
 *   - Read back on subsequent boots (idempotent)
 *
 * The enrollmentKey is NEVER user-typed. It is:
 *   1. Auto-generated at first boot
 *   2. Auto-filled in the UI (read-only display)
 *   3. Auto-saved locally
 *   4. Used for registration with the mother-body
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
// ── Path resolution ────────────────────────────────────────────────────────────
function getIdentityDir(baseDir) {
    const root = baseDir ?? path.join(os.homedir(), '.greenfrog');
    return path.join(root, 'identity');
}
function getInstallPath(baseDir) {
    return path.join(getIdentityDir(baseDir), 'install.json');
}
// ── Cryptographic generation ───────────────────────────────────────────────────
/** Generate a stable installation ID (128-bit UUID v4). */
function generateInstallId() {
    return crypto.randomUUID();
}
/**
 * Derive a public-safe instanceId from installId.
 * Uses SHA-256(installId + fixed salt) — one-way, deterministic, anonymized.
 */
function deriveInstanceId(installId) {
    const salt = 'greenfrog-instance-id-v1';
    return crypto.createHash('sha256').update(installId + salt).digest('hex').slice(0, 32);
}
/** Generate a 256-bit cryptographic random enrollment key (64 hex chars). */
function generateEnrollmentKey() {
    return crypto.randomBytes(32).toString('hex');
}
// ���─ Public API ─────────────────────────────────────────────────────────────────
/**
 * Load existing install record, or generate + persist a new one.
 * Idempotent: calling multiple times returns the same record.
 *
 * @param baseDir  Override for the .greenfrog root (used in tests)
 */
export function loadOrCreateInstallRecord(baseDir) {
    const installPath = getInstallPath(baseDir);
    // Return existing record if present
    if (fs.existsSync(installPath)) {
        try {
            const raw = fs.readFileSync(installPath, 'utf-8');
            const record = JSON.parse(raw);
            if (record.installId && record.instanceId && record.enrollmentKey) {
                return record;
            }
        }
        catch {
            // Fall through to regeneration
        }
    }
    // First boot: generate all identifiers
    const installId = generateInstallId();
    const instanceId = deriveInstanceId(installId);
    const enrollmentKey = generateEnrollmentKey();
    const record = {
        installId,
        instanceId,
        enrollmentKey,
        platform: process.platform,
        createdAt: new Date().toISOString(),
    };
    // Persist immediately
    fs.mkdirSync(path.dirname(installPath), { recursive: true });
    fs.writeFileSync(installPath, JSON.stringify(record, null, 2), 'utf-8');
    return record;
}
/**
 * Read an existing install record without creating one.
 * Returns null if not yet initialized.
 */
export function readInstallRecord(baseDir) {
    const installPath = getInstallPath(baseDir);
    if (!fs.existsSync(installPath))
        return null;
    try {
        return JSON.parse(fs.readFileSync(installPath, 'utf-8'));
    }
    catch {
        return null;
    }
}
/**
 * Return true if this installation has been initialized (install.json exists
 * with valid content).
 */
export function isInstallInitialized(baseDir) {
    return readInstallRecord(baseDir) !== null;
}
//# sourceMappingURL=enrollment.js.map