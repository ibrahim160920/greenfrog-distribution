import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class MultiAgentSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    /** Ask the supervisor model which specialist(s) should handle the task. */
    private supervisorRoute;
    /** Run a single specialist's agentic loop and return its output. */
    private runSpecialist;
    /** Synthesise outputs from multiple specialists into a unified answer. */
    private synthesise;
}
//# sourceMappingURL=multi_agent.d.ts.map