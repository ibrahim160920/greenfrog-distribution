import { BaseSkill } from './base.js';
export class IpLookupSkill extends BaseSkill {
    definition = {
        name: 'ip_lookup',
        description: 'Look up geolocation information for any IP address: country, city, ISP, timezone, coordinates. Free, no API key required.',
        category: 'information',
        parameters: [
            { name: 'ip', type: 'string', description: 'IP address to look up (IPv4 or IPv6). Omit to look up your own public IP.' },
        ],
        examples: ['What country is 8.8.8.8 from?', 'Look up IP 1.1.1.1', 'What is my public IP?', '查询IP地址 103.235.46.0'],
    };
    async execute(params, _ctx) {
        const ip = (params.ip ?? '').trim();
        // Validate IP format (basic check)
        if (ip && !/^[\d.:a-fA-F]+$/.test(ip)) {
            return this.err(`Invalid IP address format: "${ip}"`);
        }
        try {
            // ip-api.com: free, 45 req/min, no key
            const url = ip
                ? `http://ip-api.com/json/${ip}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query`
                : 'http://ip-api.com/json/?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query';
            const res = await fetch(url, { signal: AbortSignal.timeout(8_000) });
            if (!res.ok)
                return this.err(`IP lookup failed: HTTP ${res.status}`);
            const data = await res.json();
            if (data.status !== 'success') {
                return this.err(`IP lookup failed: ${data.message ?? 'unknown error'} for "${ip || 'your IP'}"`);
            }
            const flag = countryFlag(data.countryCode);
            const mapsUrl = `https://www.openstreetmap.org/?mlat=${data.lat}&mlon=${data.lon}#map=10/${data.lat}/${data.lon}`;
            const lines = [
                `🔍 **IP Lookup: ${data.query}**\n`,
                `${flag} **Location:** ${data.city}, ${data.regionName}, ${data.country} (${data.countryCode})`,
                `📮 **Postal Code:** ${data.zip || 'N/A'}`,
                `📡 **Coordinates:** ${data.lat}, ${data.lon}`,
                `🕐 **Timezone:** ${data.timezone}`,
                `🌐 **ISP:** ${data.isp}`,
                data.org && data.org !== data.isp ? `🏢 **Organization:** ${data.org}` : '',
                `🔌 **AS:** ${data.as}`,
                `\n🗺️ [View on Map](${mapsUrl})`,
            ].filter(Boolean);
            return this.text(lines.join('\n'));
        }
        catch (err) {
            return this.err(`IP lookup error: ${String(err)}`);
        }
    }
}
/** Convert ISO 3166-1 alpha-2 country code to emoji flag */
function countryFlag(code) {
    if (!code || code.length !== 2)
        return '🌐';
    return String.fromCodePoint(...code.toUpperCase().split('').map(c => 0x1F1E0 + c.charCodeAt(0) - 65));
}
//# sourceMappingURL=ip_lookup.js.map