import { parse as acornParse } from 'acorn';
import { BaseSkill } from './base.js';
// ── Risk weights ──────────────────────────────────────────────────────────────
const WEIGHTS = { critical: 30, high: 15, medium: 8, low: 3 };
/** Dangerous identifiers (Identifier node name → risk) */
const DANGER_IDS = new Map([
    ['eval', { level: 'critical', rule: 'eval', desc: 'eval() — arbitrary JavaScript execution from string' }],
    ['process', { level: 'high', rule: 'process_access', desc: 'process object — may access env vars / credentials' }],
    ['require', { level: 'high', rule: 'require', desc: 'require() — CommonJS dynamic module import' }],
    ['child_process', { level: 'critical', rule: 'child_process', desc: 'child_process — OS command execution' }],
    ['fs', { level: 'medium', rule: 'fs_access', desc: 'fs module — direct file system access' }],
    ['net', { level: 'medium', rule: 'net_module', desc: 'net module — raw TCP/UDP socket access' }],
    ['vm', { level: 'critical', rule: 'vm_module', desc: 'vm module — code execution in alternative context' }],
    ['Worker', { level: 'high', rule: 'worker_thread', desc: 'Worker — spawns thread that bypasses sandbox limits' }],
    ['XMLHttpRequest', { level: 'medium', rule: 'xhr', desc: 'XMLHttpRequest — HTTP call (potential exfiltration)' }],
    ['WebSocket', { level: 'medium', rule: 'websocket', desc: 'WebSocket — persistent channel (potential exfiltration)' }],
    ['os', { level: 'medium', rule: 'os_module', desc: 'os module — reads system info / user dirs' }],
    ['__dirname', { level: 'medium', rule: '__dirname', desc: '__dirname — reveals file system layout' }],
    ['__filename', { level: 'medium', rule: '__filename', desc: '__filename — reveals absolute file path' }],
    ['fetch', { level: 'medium', rule: 'fetch_id', desc: 'fetch — HTTP calls (potential exfiltration)' }],
]);
/** exec/spawn call names */
const DANGER_CALLS = new Map([
    ['exec', { level: 'critical', rule: 'exec', desc: 'exec() — runs shell command' }],
    ['execSync', { level: 'critical', rule: 'execSync', desc: 'execSync() — synchronous shell command' }],
    ['spawn', { level: 'critical', rule: 'spawn', desc: 'spawn() — spawns child process' }],
    ['spawnSync', { level: 'critical', rule: 'spawnSync', desc: 'spawnSync() — synchronous child process' }],
    ['execFile', { level: 'critical', rule: 'execFile', desc: 'execFile() — executes a file directly' }],
    ['fork', { level: 'critical', rule: 'fork', desc: 'fork() — forks current Node.js process' }],
]);
/** Dangerous member-expression paths (obj.prop) */
const DANGER_MEMBER = new Map([
    ['process.env', { level: 'critical', rule: 'process_env', desc: 'process.env — reads API keys / secrets from environment' }],
    ['process.exit', { level: 'high', rule: 'process_exit', desc: 'process.exit() — can crash the entire host process' }],
    ['global.process', { level: 'critical', rule: 'global_process', desc: 'global.process — env access via global scope' }],
    ['globalThis.process', { level: 'critical', rule: 'globalthis_process', desc: 'globalThis.process — env access via globalThis' }],
]);
/** String literal patterns that reveal intent to access sensitive files or modules */
const DANGER_STRINGS = [
    { re: /\.greenfrog[/\\]/i, level: 'critical', rule: 'path_greenfrog', desc: 'Path to ~/.greenfrog/ — GreenFrog config/secrets directory' },
    { re: /config\.yaml/i, level: 'critical', rule: 'path_config', desc: 'Reference to config.yaml — may contain encrypted secrets' },
    { re: /\.env\b/i, level: 'high', rule: 'path_env', desc: 'Reference to .env file — may contain API keys' },
    { re: /\/etc\/passwd/i, level: 'critical', rule: 'path_passwd', desc: '/etc/passwd — Unix system credentials file' },
    { re: /id_rsa|id_ed25519|\.ssh\//i, level: 'critical', rule: 'path_ssh', desc: 'SSH private key path detected' },
    { re: /api[_-]?key|secret[_-]?key|access[_-]?token/i, level: 'medium', rule: 'secret_string', desc: 'String contains "api_key/secret/token" — possible hardcoded credential' },
    // Dangerous module names used as string arguments to require/import
    { re: /^child_process$/, level: 'critical', rule: 'module_child_process', desc: 'child_process module name as string literal — OS command execution' },
    { re: /^shelljs$|^execa$|^cross-spawn$/, level: 'critical', rule: 'module_shell', desc: 'Shell execution npm module as string literal' },
];
/** Regex patterns applied to raw code (catches things AST may miss) */
const REGEX_CHECKS = [
    { re: /process\.env\./g, level: 'critical', rule: 'process_env_regex', desc: 'process.env access (regex)' },
    { re: /String\.fromCharCode/g, level: 'medium', rule: 'fromcharcode', desc: 'String.fromCharCode — common obfuscation technique' },
    { re: /atob\s*\(|btoa\s*\(/g, level: 'medium', rule: 'base64_codec', desc: 'base64 encode/decode — possible payload obfuscation' },
    { re: /\\x[0-9a-fA-F]{2}/g, level: 'low', rule: 'hex_escape', desc: 'Hex-escaped characters — possible string obfuscation' },
    { re: /\\u[0-9a-fA-F]{4}/g, level: 'low', rule: 'unicode_escape', desc: 'Unicode-escaped characters — possible string obfuscation' },
    { re: /setTimeout|setInterval/g, level: 'low', rule: 'timer', desc: 'setTimeout/setInterval — delayed or repeated execution' },
    // Sandbox escape via constructor chain: obj.constructor.constructor('...')()
    { re: /constructor\s*\.\s*constructor/g, level: 'critical', rule: 'constructor_escape', desc: 'constructor.constructor — classic sandbox escape technique' },
    // Prototype pollution
    { re: /__proto__\s*\[|__proto__\s*\./g, level: 'critical', rule: 'proto_pollution', desc: '__proto__ access — prototype pollution attack' },
    { re: /Object\.prototype\s*\[/g, level: 'critical', rule: 'prototype_pollution', desc: 'Object.prototype mutation — prototype pollution attack' },
    // Dynamic import for module loading
    { re: /import\s*\(/g, level: 'high', rule: 'dynamic_import', desc: 'Dynamic import() — may load arbitrary modules at runtime' },
    // Template literal tag abuse: tag`...` can call arbitrary functions
    { re: /\)\s*`[^`]{0,200}process|eval\s*`/g, level: 'critical', rule: 'tagged_template_exec', desc: 'Tagged template with dangerous function — code execution vector' },
    // fetch/XMLHttpRequest data exfiltration
    { re: /fetch\s*\(/g, level: 'medium', rule: 'fetch_call', desc: 'fetch() — HTTP call (potential data exfiltration)' },
    // Buffer.from base64 decode — payload obfuscation
    { re: /Buffer\.from\s*\([^)]*,\s*['"]base64['"]\)/g, level: 'medium', rule: 'base64_buffer_decode', desc: 'Buffer.from(…, "base64") — base64 decode (possible payload obfuscation)' },
    // Reflect API — sandbox bypass vector
    { re: /Reflect\.(get|apply|construct)\s*\(/g, level: 'high', rule: 'reflect_api', desc: 'Reflect.get/apply/construct — may bypass property access restrictions' },
];
// ── AST walker ────────────────────────────────────────────────────────────────
function line(n) {
    return n.loc?.start?.line;
}
function walkNode(n, findings, seen, aliases) {
    if (!n || typeof n !== 'object' || seen.has(n))
        return;
    seen.add(n);
    const node = n;
    // Identifier: dangerous names
    if (node.type === 'Identifier') {
        const name = node.name;
        const d = DANGER_IDS.get(name) ?? DANGER_CALLS.get(name);
        if (d)
            findings.push({ level: d.level, rule: d.rule, detail: d.desc, line: line(node) });
    }
    // MemberExpression: process.env, global.process, etc.
    if (node.type === 'MemberExpression') {
        const obj = node.object;
        const prop = node.property;
        if (obj?.type === 'Identifier' && prop?.type === 'Identifier') {
            const path = `${obj.name}.${prop.name}`;
            const d = DANGER_MEMBER.get(path);
            if (d)
                findings.push({ level: d.level, rule: d.rule, detail: d.desc, line: line(node) });
        }
        // Computed property access: obj['process'], obj['eval'], etc.
        if (node.computed) {
            if (prop?.type === 'Literal' && typeof prop.value === 'string') {
                const val = prop.value;
                const d = DANGER_IDS.get(val);
                if (d)
                    findings.push({ level: d.level, rule: `computed_${d.rule}`, detail: `Computed property access to "${val}" — ${d.desc}`, line: line(node) });
            }
            // String concatenation in computed property: obj['pro' + 'cess']
            if (prop?.type === 'BinaryExpression') {
                findings.push({ level: 'medium', rule: 'computed_concat', detail: 'String concatenation in computed property — possible identifier obfuscation', line: line(node) });
            }
        }
    }
    // NewExpression: new Function(...)
    if (node.type === 'NewExpression') {
        const callee = node.callee;
        if (callee?.type === 'Identifier' && callee.name === 'Function') {
            findings.push({ level: 'critical', rule: 'new_function', detail: 'new Function() — arbitrary code execution from a string', line: line(node) });
        }
    }
    // Literal strings: sensitive path patterns
    if (node.type === 'Literal' && typeof node.value === 'string') {
        const val = node.value;
        for (const p of DANGER_STRINGS) {
            if (p.re.test(val)) {
                findings.push({ level: p.level, rule: p.rule, detail: `${p.desc} — value: "${val.slice(0, 80)}"`, line: line(node) });
            }
        }
    }
    // CallExpression: Reflect.get/apply/construct
    if (node.type === 'CallExpression') {
        const callee = node.callee;
        if (callee?.type === 'MemberExpression') {
            const obj = callee.object;
            const prop = callee.property;
            if (obj?.type === 'Identifier' && obj.name === 'Reflect' &&
                prop?.type === 'Identifier' && ['get', 'apply', 'construct'].includes(prop.name)) {
                findings.push({ level: 'high', rule: 'reflect_api_ast', detail: `Reflect.${prop.name}() — may bypass property access restrictions`, line: line(node) });
            }
        }
        // Variable alias detection: const r = require; r('child_process')
        if (callee?.type === 'Identifier') {
            const aliasName = callee.name;
            const originalName = aliases.get(aliasName);
            if (originalName) {
                const d = DANGER_IDS.get(originalName) ?? DANGER_CALLS.get(originalName);
                if (d)
                    findings.push({ level: d.level, rule: `aliased_${d.rule}`, detail: `Aliased call: "${aliasName}" is an alias for "${originalName}" — ${d.desc}`, line: line(node) });
            }
        }
    }
    // VariableDeclarator: track aliases like `const r = require`
    if (node.type === 'VariableDeclarator') {
        const id = node.id;
        const init = node.init;
        if (id?.type === 'Identifier' && init?.type === 'Identifier') {
            const initName = init.name;
            if (DANGER_IDS.has(initName)) {
                aliases.set(id.name, initName);
            }
        }
    }
    // Recurse
    for (const key of Object.keys(node)) {
        if (key === 'type' || key === 'start' || key === 'end' || key === 'loc')
            continue;
        const child = node[key];
        if (Array.isArray(child)) {
            for (const item of child)
                walkNode(item, findings, seen, aliases);
        }
        else if (child && typeof child === 'object')
            walkNode(child, findings, seen, aliases);
    }
}
// ── Core vetting function (pure — no side effects) ────────────────────────────
export function vetCode(code) {
    const rawFindings = [];
    // 1. AST scan
    try {
        const ast = acornParse(code, { ecmaVersion: 'latest', sourceType: 'module', locations: true });
        walkNode(ast, rawFindings, new Set(), new Map());
    }
    catch (e) {
        rawFindings.push({
            level: 'high',
            rule: 'syntax_error',
            detail: `Syntax error — code cannot be fully parsed: ${e.message}`,
        });
    }
    // 2. Regex scan (catches patterns AST might miss due to dynamic code)
    for (const { re, level, rule, desc } of REGEX_CHECKS) {
        const matches = code.match(re);
        if (!matches)
            continue;
        // Skip if AST already found the same rule
        if (rawFindings.some(f => f.rule === rule || f.rule === rule.replace('_regex', '')))
            continue;
        rawFindings.push({ level, rule, detail: `${desc} (${matches.length} occurrence${matches.length > 1 ? 's' : ''})` });
    }
    // 3. Deduplicate: same rule + same line only once
    const seen = new Set();
    const findings = rawFindings.filter(f => {
        const key = `${f.rule}:${f.line ?? ''}`;
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
    // 4. Score
    let score = 0;
    let hasCritical = false;
    for (const f of findings) {
        score += WEIGHTS[f.level];
        if (f.level === 'critical')
            hasCritical = true;
    }
    score = Math.min(100, score);
    // 5. Risk level
    let risk;
    if (hasCritical || score >= 60)
        risk = 'critical';
    else if (score >= 35)
        risk = 'high';
    else if (score >= 15)
        risk = 'medium';
    else if (score > 0)
        risk = 'low';
    else
        risk = 'safe';
    const blocked = risk === 'critical' || risk === 'high';
    // 6. Summary
    const ICONS = { critical: '🔴', high: '🟠', medium: '🟡', low: '🟢', safe: '✅' };
    let summary;
    if (findings.length === 0) {
        summary = '✅ **SAFE** — No dangerous patterns detected. Code appears clean.';
    }
    else {
        const topFindings = findings
            .sort((a, b) => WEIGHTS[b.level] - WEIGHTS[a.level])
            .slice(0, 6)
            .map(f => `  ${ICONS[f.level]} [${f.level.toUpperCase()}] ${f.detail}${f.line ? ` (line ${f.line})` : ''}`)
            .join('\n');
        summary = [
            `${blocked ? '🚫 **BLOCKED**' : '⚠️ **WARNING**'} — Risk: **${risk.toUpperCase()}** (score: ${score}/100)`,
            `Found ${findings.length} issue${findings.length > 1 ? 's' : ''}:`,
            topFindings,
            findings.length > 6 ? `  ... and ${findings.length - 6} more issues` : '',
        ].filter(Boolean).join('\n');
    }
    return { risk, score, blocked, findings, summary };
}
// ── VetterSkill (callable from chat) ─────────────────────────────────────────
export class VetterSkill extends BaseSkill {
    definition = {
        name: 'vetter',
        description: 'Security scanner for custom skill/plugin code. ' +
            'Analyzes JavaScript/TypeScript for dangerous patterns: env/secret access, ' +
            'file system reads, OS command execution, code injection, and data exfiltration. ' +
            'Use before installing any third-party plugin.',
        category: 'security',
        parameters: [
            {
                name: 'code',
                type: 'string',
                required: true,
                description: 'The JavaScript/TypeScript source code to scan',
            },
            {
                name: 'strict',
                type: 'boolean',
                description: 'Strict mode: block MEDIUM risk in addition to HIGH/CRITICAL (default: false)',
                default: false,
            },
        ],
        examples: [
            'Scan this plugin code for security issues',
            'Check if this skill is safe to install',
        ],
    };
    async execute(params, _ctx) {
        const code = params.code;
        if (!code?.trim())
            return this.err('No code provided to scan');
        const result = vetCode(code);
        const strict = Boolean(params.strict ?? false);
        const blocked = strict ? (result.risk !== 'safe' && result.risk !== 'low') : result.blocked;
        const ICONS = { critical: '🔴', high: '🟠', medium: '🟡', low: '🟢', safe: '✅' };
        const allFindings = result.findings.length === 0
            ? ''
            : '\n\n**Detailed Findings:**\n' +
                result.findings
                    .sort((a, b) => WEIGHTS[b.level] - WEIGHTS[a.level])
                    .map((f, i) => `${i + 1}. ${ICONS[f.level]} **[${f.level.toUpperCase()}]** \`${f.rule}\`\n` +
                    `   ${f.detail}${f.line ? ` *(line ${f.line})*` : ''}`)
                    .join('\n');
        const verdict = blocked
            ? `\n\n🚫 **VERDICT: INSTALLATION BLOCKED** — This plugin poses a ${result.risk.toUpperCase()} security risk.`
            : result.risk === 'safe'
                ? '\n\n✅ **VERDICT: SAFE TO INSTALL**'
                : `\n\n⚠️ **VERDICT: INSTALL WITH CAUTION** (risk: ${result.risk})`;
        return this.text(`${result.summary}${allFindings}${verdict}`);
    }
}
//# sourceMappingURL=vetter.js.map