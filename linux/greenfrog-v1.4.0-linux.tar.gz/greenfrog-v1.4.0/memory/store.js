import { mkdirSync } from 'fs';
import { join } from 'path';
import Database from 'better-sqlite3';
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';
import { FileLock } from '../runtime/file_lock.js';
import { createAgentStore } from './store_agent.js';
import { createBehavioralStore } from './store_behavioral.js';
import { createConversationStore } from './store_conversation.js';
import { createEntityStore } from './store_entity.js';
import { createInfraStore } from './store_infra.js';
import { createMemoryDomainStore } from './store_memory.js';
import { createOpsStore } from './store_ops.js';
import { createTeamStore } from './store_team.js';
import { createRuleTrackingStore } from './store_rule_tracking.js';
const log = createLogger('memory');
function migrate(database) {
    database.exec(`
    CREATE TABLE IF NOT EXISTS memory (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      key TEXT NOT NULL,
      value TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      expires_at INTEGER
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_memory_unique ON memory(user_id, channel, key);
    CREATE INDEX IF NOT EXISTS idx_memory_user ON memory(user_id, channel);

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      tool_call_id TEXT,
      tool_name TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_conv_session ON conversations(session_id);

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      chat_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      last_active INTEGER NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_session_unique ON sessions(user_id, channel, chat_id);

    CREATE TABLE IF NOT EXISTS scheduled_jobs (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      cron TEXT NOT NULL,
      prompt TEXT NOT NULL,
      channel TEXT NOT NULL,
      chat_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      last_run INTEGER,
      next_run INTEGER,
      run_count INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS interaction_feedback (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      workspace_id TEXT NOT NULL DEFAULT '',
      agent_id TEXT NOT NULL DEFAULT '',
      session_id TEXT NOT NULL,
      user_message TEXT NOT NULL,
      ai_response TEXT NOT NULL,
      feedback_type TEXT NOT NULL,
      signal TEXT,
      score INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_feedback_user ON interaction_feedback(user_id, channel, workspace_id, agent_id, created_at);

    CREATE TABLE IF NOT EXISTS behavioral_rules (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      workspace_id TEXT NOT NULL DEFAULT '',
      agent_id TEXT NOT NULL DEFAULT '',
      rule TEXT NOT NULL,
      category TEXT NOT NULL,
      confidence INTEGER NOT NULL DEFAULT 50,
      source TEXT NOT NULL,
      evidence_count INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_rules_unique ON behavioral_rules(user_id, channel, workspace_id, agent_id, rule);

    CREATE TABLE IF NOT EXISTS behavioral_rule_history (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      workspace_id TEXT NOT NULL DEFAULT '',
      agent_id TEXT NOT NULL DEFAULT '',
      rule TEXT NOT NULL,
      action TEXT NOT NULL,
      related_history_id TEXT,
      old_category TEXT,
      old_confidence INTEGER,
      old_source TEXT,
      old_evidence_count INTEGER,
      new_category TEXT,
      new_confidence INTEGER,
      new_source TEXT,
      new_evidence_count INTEGER,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_behavioral_rule_history_scope
      ON behavioral_rule_history(user_id, channel, workspace_id, agent_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS entities (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      workspace_id TEXT NOT NULL DEFAULT '',
      agent_id TEXT NOT NULL DEFAULT '',
      type TEXT NOT NULL,
      name TEXT NOT NULL,
      aliases TEXT,
      attributes TEXT NOT NULL DEFAULT '{}',
      relations TEXT,
      mention_count INTEGER NOT NULL DEFAULT 1,
      last_mentioned INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_entities_unique ON entities(user_id, channel, workspace_id, agent_id, name);
    CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(user_id, channel, workspace_id, agent_id, type);
    CREATE INDEX IF NOT EXISTS idx_entities_last ON entities(user_id, channel, workspace_id, agent_id, last_mentioned);

    CREATE TABLE IF NOT EXISTS patrol_checks (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'http',
      target TEXT NOT NULL,
      interval_min INTEGER NOT NULL DEFAULT 5,
      method TEXT,
      expected_status INTEGER,
      keyword TEXT,
      timeout_ms INTEGER NOT NULL DEFAULT 10000,
      alert_threshold INTEGER NOT NULL DEFAULT 2,
      channel TEXT NOT NULL,
      chat_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      last_check INTEGER,
      last_status TEXT,
      consecutive_failures INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS patrol_results (
      id TEXT PRIMARY KEY,
      check_id TEXT NOT NULL,
      ok INTEGER NOT NULL,
      status_code INTEGER,
      latency_ms INTEGER NOT NULL,
      error TEXT,
      checked_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_patrol_results_check ON patrol_results(check_id, checked_at);

    CREATE TABLE IF NOT EXISTS workflows (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      trigger TEXT NOT NULL,
      steps TEXT NOT NULL,
      channel TEXT NOT NULL,
      chat_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      last_run INTEGER,
      run_count INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS rate_limits (
      key TEXT PRIMARY KEY,
      count INTEGER NOT NULL DEFAULT 0,
      reset_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS error_events (
      id TEXT PRIMARY KEY,
      level TEXT NOT NULL,
      message TEXT NOT NULL,
      context TEXT,
      stack TEXT,
      user_id TEXT,
      channel TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_errors_created ON error_events(created_at);

    CREATE TABLE IF NOT EXISTS audit_log (
      id TEXT PRIMARY KEY,
      timestamp INTEGER NOT NULL,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      chat_id TEXT,
      skill_name TEXT NOT NULL,
      params TEXT,
      success INTEGER NOT NULL,
      duration_ms INTEGER NOT NULL,
      error TEXT,
      role TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id, timestamp);
    CREATE INDEX IF NOT EXISTS idx_audit_skill ON audit_log(skill_name, timestamp);
    CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(timestamp);

    CREATE TABLE IF NOT EXISTS memory_history (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      key TEXT NOT NULL,
      old_value TEXT,
      new_value TEXT NOT NULL,
      source TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_memory_history_user ON memory_history(user_id, channel, created_at DESC);

    CREATE TABLE IF NOT EXISTS scoped_memory (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      workspace_id TEXT NOT NULL DEFAULT '',
      agent_id TEXT NOT NULL DEFAULT '',
      key TEXT NOT NULL,
      value TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      expires_at INTEGER,
      embedding TEXT
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_scoped_memory_unique
      ON scoped_memory(user_id, channel, workspace_id, agent_id, key);
    CREATE INDEX IF NOT EXISTS idx_scoped_memory_scope
      ON scoped_memory(user_id, channel, workspace_id, agent_id);

    CREATE TABLE IF NOT EXISTS agent_registry (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      workspace_id TEXT NOT NULL,
      owner_user_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      memory_scope TEXT NOT NULL DEFAULT 'agent',
      provider TEXT,
      model TEXT,
      system_prompt TEXT,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_agent_registry_workspace ON agent_registry(workspace_id, status);

    CREATE TABLE IF NOT EXISTS agent_bindings (
      id TEXT PRIMARY KEY,
      agent_id TEXT NOT NULL,
      workspace_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      user_id TEXT,
      chat_id TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_agent_bindings_unique
      ON agent_bindings(agent_id, channel, COALESCE(user_id, ''), COALESCE(chat_id, ''));
    CREATE INDEX IF NOT EXISTS idx_agent_bindings_route
      ON agent_bindings(channel, user_id, chat_id, workspace_id);

    CREATE TABLE IF NOT EXISTS team_tasks (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      status TEXT NOT NULL DEFAULT 'todo',
      priority TEXT NOT NULL DEFAULT 'medium',
      assigned_agent_id TEXT,
      depends_on_task_ids TEXT NOT NULL DEFAULT '[]',
      review_required INTEGER NOT NULL DEFAULT 0,
      reviewer_agent_id TEXT,
      review_status TEXT NOT NULL DEFAULT 'not_required',
      attempt_count INTEGER NOT NULL DEFAULT 0,
      max_attempts INTEGER NOT NULL DEFAULT 1,
      last_attempt_at INTEGER,
      escalation_status TEXT NOT NULL DEFAULT 'none',
      escalation_reason TEXT,
      human_owner_user_id TEXT,
      blocked_reason TEXT,
      created_by TEXT NOT NULL,
      result_summary TEXT,
      due_at INTEGER,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_team_tasks_workspace ON team_tasks(workspace_id, status, priority, updated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_team_tasks_agent ON team_tasks(workspace_id, assigned_agent_id, status, updated_at DESC);

    CREATE TABLE IF NOT EXISTS team_policies (
      workspace_id TEXT PRIMARY KEY,
      auto_dispatch INTEGER NOT NULL DEFAULT 1,
      auto_review INTEGER NOT NULL DEFAULT 1,
      max_auto_retries INTEGER NOT NULL DEFAULT 1,
      escalate_on_blocked INTEGER NOT NULL DEFAULT 1,
      escalate_on_review_changes INTEGER NOT NULL DEFAULT 1,
      escalate_on_sla_breach INTEGER NOT NULL DEFAULT 1,
      auto_share_task_results INTEGER NOT NULL DEFAULT 0,
      shared_memory_prefix TEXT NOT NULL DEFAULT 'team:',
      default_task_sla_hours INTEGER NOT NULL DEFAULT 24,
      default_human_owner_user_id TEXT,
      approval_reminder_after_minutes INTEGER NOT NULL DEFAULT 30,
      approval_escalation_after_minutes INTEGER NOT NULL DEFAULT 120,
      oncall_assignment_timeout_minutes INTEGER NOT NULL DEFAULT 10,
      oncall_max_handoffs_per_task INTEGER NOT NULL DEFAULT 4,
      escalation_owner_user_id TEXT,
      updated_by TEXT NOT NULL,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS team_task_approvals (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      task_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      requested_by TEXT NOT NULL,
      requested_for_user_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      resolution_notes TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      resolved_at INTEGER
    );

    CREATE INDEX IF NOT EXISTS idx_team_task_approvals_workspace
      ON team_task_approvals(workspace_id, status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_team_task_approvals_task
      ON team_task_approvals(task_id, status, created_at DESC);

    CREATE TABLE IF NOT EXISTS team_notifications (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      recipient_user_id TEXT NOT NULL,
      type TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'info',
      status TEXT NOT NULL DEFAULT 'unread',
      delivery_status TEXT NOT NULL DEFAULT 'pending',
      delivery_attempt_count INTEGER NOT NULL DEFAULT 0,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      task_id TEXT,
      approval_id TEXT,
      last_delivery_error TEXT,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      read_at INTEGER,
      last_delivery_attempt_at INTEGER,
      delivered_at INTEGER
    );

    CREATE INDEX IF NOT EXISTS idx_team_notifications_recipient
      ON team_notifications(recipient_user_id, status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_team_notifications_workspace
      ON team_notifications(workspace_id, status, created_at DESC);

    CREATE TABLE IF NOT EXISTS team_notification_routes (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      recipient_user_id TEXT NOT NULL,
      channel TEXT NOT NULL,
      chat_id TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,
      created_by TEXT NOT NULL,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_team_notification_routes_unique
      ON team_notification_routes(workspace_id, recipient_user_id, channel, chat_id);
    CREATE INDEX IF NOT EXISTS idx_team_notification_routes_recipient
      ON team_notification_routes(workspace_id, recipient_user_id, enabled, updated_at DESC);

    CREATE TABLE IF NOT EXISTS team_mailbox_messages (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      dedupe_key TEXT,
      sender_agent_id TEXT,
      sender_user_id TEXT,
      recipient_agent_id TEXT,
      task_id TEXT,
      type TEXT NOT NULL DEFAULT 'direct',
      status TEXT NOT NULL DEFAULT 'pending',
      subject TEXT,
      message TEXT NOT NULL,
      metadata TEXT,
      acknowledged_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_team_mailbox_workspace
      ON team_mailbox_messages(workspace_id, status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_team_mailbox_dedupe
      ON team_mailbox_messages(workspace_id, dedupe_key, updated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_team_mailbox_recipient
      ON team_mailbox_messages(workspace_id, recipient_agent_id, status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_team_mailbox_thread
      ON team_mailbox_messages(thread_id, created_at ASC);

    CREATE TABLE IF NOT EXISTS team_oncall_rotations (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      name TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,
      schedule_type TEXT NOT NULL DEFAULT 'daily',
      anchor_date INTEGER NOT NULL,
      department TEXT,
      role TEXT,
      primary_agent_ids TEXT NOT NULL DEFAULT '[]',
      secondary_agent_ids TEXT NOT NULL DEFAULT '[]',
      created_by TEXT NOT NULL,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_team_oncall_rotations_workspace
      ON team_oncall_rotations(workspace_id, enabled, department, role, updated_at DESC);

    CREATE TABLE IF NOT EXISTS team_templates (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      department TEXT,
      role TEXT,
      goal_template TEXT,
      variables TEXT NOT NULL DEFAULT '[]',
      task_blueprints TEXT NOT NULL DEFAULT '[]',
      created_by TEXT NOT NULL,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_team_templates_workspace
      ON team_templates(workspace_id, name, updated_at DESC);

    CREATE TABLE IF NOT EXISTS team_topologies (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL,
      name TEXT NOT NULL,
      department TEXT,
      role TEXT,
      supervisor_agent_id TEXT,
      worker_agent_ids TEXT NOT NULL DEFAULT '[]',
      default_template_ids TEXT NOT NULL DEFAULT '[]',
      default_human_owner_user_id TEXT,
      metadata TEXT,
      created_by TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_team_topologies_workspace
      ON team_topologies(workspace_id, department, role, updated_at DESC);

    CREATE TABLE IF NOT EXISTS skill_stats (
      skill_name TEXT PRIMARY KEY,
      call_count INTEGER NOT NULL DEFAULT 0,
      success_count INTEGER NOT NULL DEFAULT 0,
      total_duration_ms INTEGER NOT NULL DEFAULT 0,
      last_called_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS auth_revocations (
      user_id TEXT PRIMARY KEY,
      revoked_after INTEGER NOT NULL,
      revoked_by TEXT,
      reason TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS token_usage (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      workspace_id TEXT,
      agent_id TEXT,
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      input_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      total_tokens INTEGER NOT NULL DEFAULT 0,
      cost_usd REAL,
      channel TEXT,
      session_key TEXT,
      recorded_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_token_usage_user ON token_usage(user_id, recorded_at DESC);
    CREATE INDEX IF NOT EXISTS idx_token_usage_workspace ON token_usage(workspace_id, recorded_at DESC);

    CREATE TABLE IF NOT EXISTS user_quotas (
      scope_type TEXT NOT NULL CHECK(scope_type IN ('user','workspace')),
      scope_id TEXT NOT NULL,
      monthly_token_limit INTEGER,
      monthly_cost_limit_usd REAL,
      limit_behavior TEXT NOT NULL DEFAULT 'soft',
      updated_at INTEGER NOT NULL,
      PRIMARY KEY (scope_type, scope_id)
    );

    CREATE TABLE IF NOT EXISTS workspace_members (
      workspace_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'member',
      joined_at INTEGER NOT NULL,
      PRIMARY KEY (workspace_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_workspace_members_user ON workspace_members(user_id);
  `);
    // Add embedding column to existing tables (safe to run on first use or upgrade)
    try {
        database.exec(`ALTER TABLE memory ADD COLUMN embedding TEXT`);
    }
    catch { /* already exists */ }
    // Add notify_if / last_result columns to scheduled_jobs (migration)
    try {
        database.exec(`ALTER TABLE scheduled_jobs ADD COLUMN notify_if TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE scheduled_jobs ADD COLUMN last_result TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE memory_history ADD COLUMN workspace_id TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE memory_history ADD COLUMN agent_id TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`CREATE INDEX IF NOT EXISTS idx_memory_history_scope ON memory_history(user_id, channel, workspace_id, agent_id, created_at DESC)`);
    }
    catch { /* old schema race */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN depends_on_task_ids TEXT NOT NULL DEFAULT '[]'`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN review_required INTEGER NOT NULL DEFAULT 0`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN reviewer_agent_id TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN review_status TEXT NOT NULL DEFAULT 'not_required'`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN attempt_count INTEGER NOT NULL DEFAULT 0`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN max_attempts INTEGER NOT NULL DEFAULT 1`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN last_attempt_at INTEGER`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN escalation_status TEXT NOT NULL DEFAULT 'none'`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN escalation_reason TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN human_owner_user_id TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_tasks ADD COLUMN blocked_reason TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_policies ADD COLUMN escalate_on_sla_breach INTEGER NOT NULL DEFAULT 1`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_policies ADD COLUMN default_task_sla_hours INTEGER NOT NULL DEFAULT 24`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_policies ADD COLUMN approval_reminder_after_minutes INTEGER NOT NULL DEFAULT 30`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_policies ADD COLUMN approval_escalation_after_minutes INTEGER NOT NULL DEFAULT 120`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_policies ADD COLUMN oncall_assignment_timeout_minutes INTEGER NOT NULL DEFAULT 10`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_policies ADD COLUMN oncall_max_handoffs_per_task INTEGER NOT NULL DEFAULT 4`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_policies ADD COLUMN escalation_owner_user_id TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_templates ADD COLUMN variables TEXT NOT NULL DEFAULT '[]'`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_notifications ADD COLUMN delivery_status TEXT NOT NULL DEFAULT 'pending'`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_notifications ADD COLUMN delivery_attempt_count INTEGER NOT NULL DEFAULT 0`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_notifications ADD COLUMN last_delivery_error TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_notifications ADD COLUMN last_delivery_attempt_at INTEGER`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_notifications ADD COLUMN delivered_at INTEGER`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE behavioral_rules ADD COLUMN workspace_id TEXT NOT NULL DEFAULT ''`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE behavioral_rules ADD COLUMN agent_id TEXT NOT NULL DEFAULT ''`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE entities ADD COLUMN workspace_id TEXT NOT NULL DEFAULT ''`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE entities ADD COLUMN agent_id TEXT NOT NULL DEFAULT ''`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE interaction_feedback ADD COLUMN workspace_id TEXT NOT NULL DEFAULT ''`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE interaction_feedback ADD COLUMN agent_id TEXT NOT NULL DEFAULT ''`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE agent_registry ADD COLUMN provider TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE agent_registry ADD COLUMN model TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`ALTER TABLE team_mailbox_messages ADD COLUMN dedupe_key TEXT`);
    }
    catch { /* already exists */ }
    try {
        database.exec(`DROP INDEX IF EXISTS idx_feedback_user`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`CREATE INDEX IF NOT EXISTS idx_feedback_user ON interaction_feedback(user_id, channel, workspace_id, agent_id, created_at)`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`DROP INDEX IF EXISTS idx_rules_unique`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_rules_unique ON behavioral_rules(user_id, channel, workspace_id, agent_id, rule)`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`DROP INDEX IF EXISTS idx_entities_unique`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`DROP INDEX IF EXISTS idx_entities_type`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`DROP INDEX IF EXISTS idx_entities_last`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_entities_unique ON entities(user_id, channel, workspace_id, agent_id, name)`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(user_id, channel, workspace_id, agent_id, type)`);
    }
    catch { /* ignore */ }
    try {
        database.exec(`CREATE INDEX IF NOT EXISTS idx_entities_last ON entities(user_id, channel, workspace_id, agent_id, last_mentioned)`);
    }
    catch { /* ignore */ }
    // ── Sprint M4: durable rule tracking ──────────────────────────────────────
    database.exec(`
    CREATE TABLE IF NOT EXISTS rule_tracking_stats (
      rule_id TEXT NOT NULL,
      workspace_id TEXT NOT NULL DEFAULT '',
      channel TEXT NOT NULL,
      total_applications INTEGER NOT NULL DEFAULT 0,
      successful_applications INTEGER NOT NULL DEFAULT 0,
      failed_applications INTEGER NOT NULL DEFAULT 0,
      last_used_at INTEGER,
      created_at INTEGER NOT NULL DEFAULT (unixepoch('now') * 1000),
      PRIMARY KEY (rule_id, workspace_id, channel)
    );
    CREATE INDEX IF NOT EXISTS idx_rule_tracking_ws
      ON rule_tracking_stats(workspace_id, channel);
  `);
}
export class MemoryStore {
    db;
    lock = null;
    _agent;
    _behavioral;
    _conversation;
    _entity;
    _infra;
    _memory;
    _ops;
    _team;
    _ruleTracking;
    /**
     * L1 in-memory cache for rate limit hot path.
     * Eliminates SQLite I/O on repeated calls within the same window.
     * key -> { count, resetAt }
     */
    _rlCache = new Map();
    /**
     * @param dbPath  Optional path override. Pass ':memory:' for in-memory SQLite
     *                (used by unit tests). Defaults to config.dataDir/memory.db.
     */
    constructor(dbPath) {
        // Resolve effective path: explicit arg > ':memory:' sentinel in dataDir > regular file path
        // ':memory:' is the only SQLite in-memory special path; other ':...:' values are test sentinels.
        const effective = dbPath ?? (config.dataDir === ':memory:' ? ':memory:' : undefined);
        if (effective) {
            // SQLite special path (e.g. ':memory:') or explicit override; no directory creation needed.
            this.db = new Database(effective);
        }
        else {
            const dir = config.dataDir;
            mkdirSync(dir, { recursive: true });
            const dbFilePath = join(dir, 'memory.db');
            const lockPath = join(dir, 'memory.db.lock');
            // Acquire OS-level file lock before opening database
            this.lock = new FileLock(lockPath);
            try {
                // Synchronous lock acquisition - blocks until lock is available or throws
                // We use a sync wrapper here since constructor can't be async
                const lockPromise = this.lock.acquire();
                // For now, we'll handle this in init() instead
                this.db = new Database(dbFilePath);
                log.info({ dbPath: dbFilePath }, 'Memory store initialized');
                // Acquire lock asynchronously after DB is open
                lockPromise.catch((err) => {
                    log.error({ err, lockPath }, 'Failed to acquire database lock');
                    // Lock failure is non-fatal - SQLite has its own locking
                });
            }
            catch (err) {
                log.error({ err, lockPath }, 'Failed to acquire database lock');
                // Continue anyway - SQLite has its own locking mechanism
                this.db = new Database(dbFilePath);
                log.info({ dbPath: dbFilePath }, 'Memory store initialized (without file lock)');
            }
        }
        this.db.pragma('journal_mode = WAL');
        this.db.pragma('foreign_keys = ON');
        migrate(this.db);
        this._agent = createAgentStore(this.db);
        Object.assign(this, this._agent);
        this._behavioral = createBehavioralStore(this.db);
        Object.assign(this, this._behavioral);
        this._conversation = createConversationStore(this.db);
        Object.assign(this, this._conversation);
        this._entity = createEntityStore(this.db);
        Object.assign(this, this._entity);
        this._infra = createInfraStore(this.db, this._rlCache);
        Object.assign(this, this._infra);
        this._memory = createMemoryDomainStore(this.db);
        Object.assign(this, this._memory);
        this._ops = createOpsStore(this.db);
        Object.assign(this, this._ops);
        this._team = createTeamStore(this.db);
        Object.assign(this, this._team);
        this._ruleTracking = createRuleTrackingStore(this.db);
        Object.assign(this, this._ruleTracking);
        // Run cleanup on startup so stale data is pruned before first request
        setImmediate(() => { if (this.db.open)
            this.cleanup(); });
    }
    /** No-op kept for backward compatibility with callers that await init(). */
    async init() { }
    async close() {
        // Release file lock before closing database
        if (this.lock?.isHeld()) {
            await this.lock.release();
        }
        this.db.close();
    }
    // Cross-domain queries
    /**
     * Return all known users derived from sessions, ordered by most-recently active.
     * Used by the admin user-management API.
     */
    listUsers() {
        const rows = this.db.prepare(`SELECT s.user_id,
              GROUP_CONCAT(DISTINCT s.channel) AS channels,
              MAX(s.last_active)               AS last_active,
              COUNT(c.id)                      AS message_count
       FROM sessions s
       LEFT JOIN conversations c ON c.session_id = s.id AND c.role = 'user'
       WHERE s.user_id != '[DELETED]'
       GROUP BY s.user_id
       ORDER BY last_active DESC
       LIMIT 500`).all();
        return rows.map((r) => ({
            userId: r.user_id,
            channels: r.channels ? r.channels.split(',') : [],
            lastActive: new Date(r.last_active),
            messageCount: r.message_count,
        }));
    }
    /**
     * Delete all personal data for a user across every table.
     * Audit log entries are anonymised (`user_id = '[DELETED]'`) rather than
     * deleted so the security/compliance trail is preserved.
     *
     * Returns a summary of what was removed.
     */
    deleteUserData(userId) {
        const affected = [];
        let total = 0;
        const del = (table, where, ...args) => {
            const r = this.db.prepare(`DELETE FROM ${table} WHERE ${where}`).run(...args);
            if (r.changes > 0) {
                affected.push(table);
                total += r.changes;
            }
        };
        // Personal memory and derived data
        del('memory', 'user_id = ?', userId);
        del('scoped_memory', 'user_id = ?', userId);
        del('memory_history', 'user_id = ?', userId);
        del('behavioral_rules', 'user_id = ?', userId);
        del('behavioral_rule_history', 'user_id = ?', userId);
        del('entities', 'user_id = ?', userId);
        del('interaction_feedback', 'user_id = ?', userId);
        del('team_tasks', 'created_by = ?', userId);
        del('team_notifications', 'recipient_user_id = ?', userId);
        del('team_notification_routes', 'recipient_user_id = ?', userId);
        del('scheduled_jobs', 'user_id = ?', userId);
        del('workflows', 'user_id = ?', userId);
        del('patrol_checks', 'user_id = ?', userId);
        del('auth_revocations', 'user_id = ?', userId);
        del('agent_bindings', 'user_id = ?', userId);
        del('agent_registry', 'owner_user_id = ?', userId);
        // Conversations (via session join)
        const sessions = this.db.prepare(`SELECT id FROM sessions WHERE user_id = ?`).all(userId);
        if (sessions.length > 0) {
            const placeholders = sessions.map(() => '?').join(',');
            const ids = sessions.map((s) => s.id);
            const r = this.db.prepare(`DELETE FROM conversations WHERE session_id IN (${placeholders})`).run(...ids);
            if (r.changes > 0) {
                affected.push('conversations');
                total += r.changes;
            }
        }
        del('sessions', 'user_id = ?', userId);
        // Anonymise audit log to preserve the compliance trail without keeping PII.
        const anon = this.db.prepare(`UPDATE audit_log SET user_id = '[DELETED]' WHERE user_id = ?`).run(userId);
        if (anon.changes > 0)
            affected.push('audit_log (anonymised)');
        // Clear any cached rate limit entries for this user
        for (const k of this._rlCache.keys()) {
            if (k.includes(userId))
                this._rlCache.delete(k);
        }
        this.db.prepare(`DELETE FROM rate_limits WHERE key LIKE ?`).run(`%${userId}%`);
        log.info({ userId, tablesAffected: affected, rowsDeleted: total }, 'User data deleted (GDPR)');
        return { tablesAffected: affected, rowsDeleted: total };
    }
    // Cross-domain cleanup
    cleanup() {
        const cutoff = Date.now() - 90 * 24 * 3600 * 1000;
        this.db.prepare(`DELETE FROM conversations WHERE created_at < ?`).run(cutoff);
        this.db.prepare(`DELETE FROM scoped_memory WHERE expires_at IS NOT NULL AND expires_at <= ?`).run(Date.now());
        this.db.prepare(`DELETE FROM error_events WHERE created_at < ?`).run(Date.now() - 30 * 24 * 3600 * 1000);
        // Keep patrol results for 30 days to prevent unbounded table growth
        this.db.prepare(`DELETE FROM patrol_results WHERE checked_at < ?`).run(Date.now() - 30 * 24 * 3600 * 1000);
        // Keep audit log for 90 days
        this.db.prepare(`DELETE FROM audit_log WHERE timestamp < ?`).run(Date.now() - 90 * 24 * 3600 * 1000);
        this.cleanupRateLimits();
        log.debug('Memory cleanup complete');
    }
}
function createDefaultMemoryStore() {
    try {
        return new MemoryStore();
    }
    catch {
        // Fallback to in-memory DB when dataDir is a test sentinel or non-writable path
        return new MemoryStore(':memory:');
    }
}
/**
 * Live-binding singleton that can be swapped at startup via `setMemoryStore()`
 * to point at a PostgresMemoryStore or any other `IMemoryStore` implementation.
 * All ESM importers of this binding will automatically see the new store.
 */
export let memoryStore = createDefaultMemoryStore();
/** Replace the backing store (call once during startPlatform before any requests). */
export function setMemoryStore(store) {
    memoryStore = store;
}
//# sourceMappingURL=store.js.map