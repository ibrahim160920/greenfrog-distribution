import Database from 'better-sqlite3';
import type { AgentBinding, AgentDefinition, ChannelName, ResolvedAgentBinding } from '../utils/types.js';
export declare function createAgentStore(db: Database.Database): {
    createAgent(agent: {
        name: string;
        description?: string;
        workspaceId: string;
        ownerUserId: string;
        status?: AgentDefinition["status"];
        memoryScope?: AgentDefinition["memoryScope"];
        provider?: string | null;
        model?: string | null;
        systemPrompt?: string;
        metadata?: Record<string, unknown>;
    }): AgentDefinition;
    getAgent(id: string): AgentDefinition | null;
    listAgents(workspaceId?: string): AgentDefinition[];
    updateAgent(id: string, updates: Partial<{
        name: string;
        description: string;
        status: AgentDefinition["status"];
        memoryScope: AgentDefinition["memoryScope"];
        provider: string | null;
        model: string | null;
        systemPrompt: string;
        metadata: Record<string, unknown>;
    }>): AgentDefinition | null;
    deleteAgent(id: string): boolean;
    createAgentBinding(binding: {
        agentId: string;
        workspaceId: string;
        channel: ChannelName;
        userId?: string | null;
        chatId?: string | null;
    }): AgentBinding;
    listAgentBindings(filter?: {
        workspaceId?: string;
        agentId?: string;
        channel?: ChannelName;
    }): AgentBinding[];
    deleteAgentBinding(id: string): boolean;
    resolveAgentBinding(params: {
        channel: ChannelName;
        userId: string;
        chatId: string;
    }): ResolvedAgentBinding | null;
};
//# sourceMappingURL=store_agent.d.ts.map