import { BaseSkill } from './base.js';
import { config } from '../config/index.js';
export class GitHubSkill extends BaseSkill {
    definition = {
        name: 'github',
        description: 'Interact with GitHub: search repos, list issues, create issues, get PR info, view file contents',
        category: 'development',
        parameters: [
            {
                name: 'action',
                type: 'string',
                description: 'Action to perform',
                required: true,
                enum: ['search_repos', 'list_issues', 'create_issue', 'create_pr', 'get_pr', 'get_file', 'list_prs', 'get_repo'],
            },
            { name: 'repo', type: 'string', description: 'Repository in format "owner/repo"' },
            { name: 'query', type: 'string', description: 'Search query' },
            { name: 'issue_title', type: 'string', description: 'Issue title (for create_issue)' },
            { name: 'issue_body', type: 'string', description: 'Issue body (for create_issue)' },
            { name: 'pr_title', type: 'string', description: 'Pull request title (for create_pr)' },
            { name: 'pr_body', type: 'string', description: 'Pull request body (for create_pr)' },
            { name: 'head', type: 'string', description: 'Head branch name for create_pr, e.g. owner:greenfrog-evolution/my-branch' },
            { name: 'base', type: 'string', description: 'Base branch name for create_pr, default: main' },
            { name: 'pr_number', type: 'number', description: 'PR number (for get_pr)' },
            { name: 'file_path', type: 'string', description: 'File path in repo (for get_file)' },
            { name: 'state', type: 'string', description: 'Issue/PR state', enum: ['open', 'closed', 'all'], default: 'open' },
        ],
    };
    get headers() {
        const token = config.skills.github?.token;
        return {
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'GreenFrog-Agent/1.0',
            ...(token ? { 'Authorization': `token ${token}` } : {}),
        };
    }
    async gh(path, options) {
        const res = await fetch(`https://api.github.com${path}`, {
            ...options,
            headers: { ...this.headers, ...(options?.headers ?? {}) },
        });
        if (!res.ok) {
            const err = await res.json();
            throw new Error(`GitHub API ${res.status}: ${err.message}`);
        }
        return res.json();
    }
    async execute(params, _ctx) {
        try {
            switch (params.action) {
                case 'search_repos': {
                    const data = await this.gh(`/search/repositories?q=${encodeURIComponent(params.query)}&per_page=5`);
                    const lines = data.items.map((r) => `• **${r.full_name}** ⭐${r.stargazers_count} [${r.language ?? 'unknown'}]\n  ${r.description ?? 'No description'}`);
                    return this.text(`🔍 GitHub search results:\n\n${lines.join('\n\n')}`);
                }
                case 'get_repo': {
                    const r = await this.gh(`/repos/${params.repo}`);
                    return this.text([
                        `📦 **${r.full_name}**`,
                        `📝 ${r.description ?? 'No description'}`,
                        `⭐ Stars: ${r.stargazers_count} | 🍴 Forks: ${r.forks_count}`,
                        `🐛 Open issues: ${r.open_issues_count}`,
                        `💻 Language: ${r.language ?? 'unknown'}`,
                        `🌿 Default branch: ${r.default_branch}`,
                        `🔗 ${r.html_url}`,
                    ].join('\n'));
                }
                case 'list_issues': {
                    const state = params.state ?? 'open';
                    const issues = await this.gh(`/repos/${params.repo}/issues?state=${state}&per_page=10`);
                    const lines = issues.map((i) => `#${i.number} [${i.state}] ${i.title} (@${i.user.login})`);
                    return this.text(`🐛 Issues in **${params.repo}** (${state}):\n\n${lines.join('\n') || 'No issues found'}`);
                }
                case 'create_issue': {
                    const issue = await this.gh(`/repos/${params.repo}/issues`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ title: params.issue_title, body: params.issue_body }),
                    });
                    return this.text(`✅ Issue created: #${issue.number}\n🔗 ${issue.html_url}`);
                }
                case 'create_pr': {
                    const title = params.pr_title?.trim();
                    const head = params.head?.trim();
                    const base = params.base?.trim() || 'main';
                    if (!title)
                        return this.err('pr_title is required');
                    if (!head)
                        return this.err('head is required');
                    const pr = await this.gh(`/repos/${params.repo}/pulls`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            title,
                            body: params.pr_body ?? '',
                            head,
                            base,
                        }),
                    });
                    return this.text(`PR created: #${pr.number} [${pr.state}]\n${pr.html_url}`);
                }
                case 'list_prs': {
                    const state = params.state ?? 'open';
                    const prs = await this.gh(`/repos/${params.repo}/pulls?state=${state}&per_page=10`);
                    const lines = prs.map((p) => `#${p.number} ${p.title} (@${p.user.login})`);
                    return this.text(`🔀 PRs in **${params.repo}** (${state}):\n\n${lines.join('\n') || 'No PRs found'}`);
                }
                case 'get_pr': {
                    const pr = await this.gh(`/repos/${params.repo}/pulls/${params.pr_number}`);
                    return this.text([
                        `🔀 **PR #${pr.number}: ${pr.title}**`,
                        `👤 By: @${pr.user.login} | State: ${pr.state}`,
                        `➕ +${pr.additions} ➖ -${pr.deletions}`,
                        `📝 ${pr.body?.slice(0, 500) ?? 'No description'}`,
                        `🔗 ${pr.html_url}`,
                    ].join('\n'));
                }
                case 'get_file': {
                    const file = await this.gh(`/repos/${params.repo}/contents/${params.file_path}`);
                    const content = Buffer.from(file.content, 'base64').toString('utf8');
                    return this.text(`📄 **${params.file_path}** (${file.size} bytes)\n\`\`\`\n${content.slice(0, 3000)}\n\`\`\``);
                }
                default:
                    return this.err(`Unknown action: ${params.action}`);
            }
        }
        catch (err) {
            return this.err(`GitHub error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=github.js.map