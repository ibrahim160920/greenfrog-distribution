import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class HardwareTestSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private llm;
    private testPlan;
    private testCases;
    private testReport;
    private debugGuide;
}
//# sourceMappingURL=hardware_test.d.ts.map