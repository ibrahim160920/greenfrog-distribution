import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class SystemInfoSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private tryExec;
}
//# sourceMappingURL=system_info.d.ts.map