import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class CronJobSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=cron_job.d.ts.map