import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class WeatherSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    /** Primary: Open-Meteo (fully free, no key) */
    private fetchOpenMeteo;
    /** Fallback: wttr.in */
    private fetchWttr;
}
//# sourceMappingURL=weather.d.ts.map