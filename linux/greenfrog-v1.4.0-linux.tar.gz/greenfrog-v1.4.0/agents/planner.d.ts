/**
 * Execution Planner for GreenFrog P4.3.
 *
 * Inserts a `plan` phase between PREPARE and ACT in the dispatch loop.
 * The plan is NOT a submodel call — it is derived deterministically from
 * the contract, feedback state, and execution context. This keeps it
 * zero-latency and predictable.
 *
 * The plan outputs:
 *   strategy         — overall approach for this iteration
 *   keyAssumption    — what the plan assumes to be true
 *   primaryAction    — the main step the agent should take
 *   expectedEvidence — what a passing resultSummary should contain
 *   fallbackAction   — what to try if the primary action fails
 *   promptSuffix     — text injected into the worker prompt to shape behaviour
 *   planSummary      — one-line string for logging and metadata
 *
 * The promptSuffix is appended after the worker prompt but before the
 * contract prompt — it frames the agent's strategy for this attempt.
 *
 * This is a pure module — no I/O, no DB access.
 */
import type { TaskContract } from './contract.js';
import type { FeedbackSnapshot } from './context_assembly.js';
export type PlanStrategy = 'direct_execution' | 'repair_prior_output' | 'conservative_last_attempt' | 'resume_from_observation' | 'clarify_and_act';
export interface ExecutionPlan {
    strategy: PlanStrategy;
    keyAssumption: string;
    primaryAction: string;
    expectedEvidence: string;
    fallbackAction: string;
    /**
     * Injected into the worker prompt to frame the agent's approach.
     * Appended after context, before contract.
     */
    promptSuffix: string;
    /** One-line for logging / metadata */
    planSummary: string;
}
/**
 * Derive an execution plan for the current iteration.
 *
 * @param contract          — task contract for this dispatch
 * @param feedback          — feedback snapshot from prior iterations
 * @param attemptsRemaining — how many more runs are permitted AFTER this one
 * @param options           — optional signals from caller
 */
export declare function buildExecutionPlan(contract: TaskContract, feedback: FeedbackSnapshot, attemptsRemaining: number, options?: {
    recoveryMode?: 'restartable' | 'resumable';
    lastHumanDecision?: string | null;
    lastRunStatus?: string | null;
    missingCriteria?: string[];
}): ExecutionPlan;
//# sourceMappingURL=planner.d.ts.map