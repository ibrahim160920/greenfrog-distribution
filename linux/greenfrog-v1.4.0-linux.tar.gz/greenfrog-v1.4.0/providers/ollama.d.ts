import type { ProviderRequest, ProviderResponse } from '../utils/types.js';
import { BaseProvider, type StreamingCall } from './base.js';
export declare class OllamaProvider extends BaseProvider {
    readonly name = "ollama";
    readonly defaultModel = "llama3.2";
    private baseUrl;
    private model;
    constructor(baseUrl?: string, model?: string);
    /** Build the Ollama messages array from a ProviderRequest */
    private buildMessages;
    /** Build the Ollama tools array from a ProviderRequest */
    private buildTools;
    chat(request: ProviderRequest): Promise<ProviderResponse>;
    chatStream(request: ProviderRequest): StreamingCall;
    isAvailable(): Promise<boolean>;
    listModels(): Promise<string[]>;
}
//# sourceMappingURL=ollama.d.ts.map