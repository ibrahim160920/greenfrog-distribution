export declare function manageConfig(opts: {
    show?: boolean;
    set?: string;
}): Promise<void>;
//# sourceMappingURL=config.d.ts.map