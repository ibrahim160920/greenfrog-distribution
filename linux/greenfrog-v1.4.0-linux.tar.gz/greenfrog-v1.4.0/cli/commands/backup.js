/**
 * greenfrog backup  — pack DB + config into a timestamped .tar.gz
 * greenfrog restore — unpack and restore from a backup archive
 *
 * Archive layout:
 *   greenfrog-backup/
 *     greenfrog.db        ← SQLite database
 *     config.yaml         ← encrypted config (secrets stay encrypted)
 *     custom_skills/      ← user-created skills (if any)
 *     MANIFEST.json       ← backup metadata (version, timestamp, platform)
 */
import { existsSync, mkdirSync, copyFileSync, readdirSync, statSync, unlinkSync } from 'fs';
import { join, basename } from 'path';
import { tmpdir } from 'os';
import { execSync } from 'child_process';
import { readFileSync } from 'fs';
import chalk from 'chalk';
import archiver from 'archiver';
import { createWriteStream } from 'fs';
// ── helpers ───────────────────────────────────────────────────────────────────
function timestamp() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return (`${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` +
        `T${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`);
}
function formatBytes(bytes) {
    if (bytes < 1024)
        return `${bytes} B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}
// ── backup ────────────────────────────────────────────────────────────────────
export async function backupData(outputPath) {
    const { configManager } = await import('../../config/index.js');
    const dataDir = configManager.dataDir;
    const dbPath = join(dataDir, 'greenfrog.db');
    const configPath = join(dataDir, 'config.yaml');
    const skillsDir = join(dataDir, 'custom_skills');
    // Verify source files exist
    if (!existsSync(dbPath) && !existsSync(configPath)) {
        console.error(chalk.red('❌ No GreenFrog data found at:'), dataDir);
        console.error(chalk.yellow('   Run `greenfrog start` at least once to create initial data.'));
        process.exit(1);
    }
    const outFile = outputPath ?? `greenfrog-backup-${timestamp()}.tar.gz`;
    console.log(chalk.cyan('📦 Creating backup...'));
    // Build MANIFEST
    const manifest = {
        version: '1',
        createdAt: new Date().toISOString(),
        platform: process.platform,
        nodeVersion: process.version,
        dataDir,
        files: [],
    };
    // Create the archive
    await new Promise((resolve, reject) => {
        const output = createWriteStream(outFile);
        const archive = archiver('tar', { gzip: true, gzipOptions: { level: 6 } });
        output.on('close', resolve);
        archive.on('error', reject);
        archive.pipe(output);
        // Add database
        if (existsSync(dbPath)) {
            archive.file(dbPath, { name: 'greenfrog-backup/greenfrog.db' });
            manifest.files.push('greenfrog.db');
            console.log(chalk.gray(`  + greenfrog.db (${formatBytes(statSync(dbPath).size)})`));
        }
        // Add config (secrets remain AES-256-GCM encrypted inside the file)
        if (existsSync(configPath)) {
            archive.file(configPath, { name: 'greenfrog-backup/config.yaml' });
            manifest.files.push('config.yaml');
            console.log(chalk.gray(`  + config.yaml`));
        }
        // Add custom skills directory
        if (existsSync(skillsDir)) {
            archive.directory(skillsDir, 'greenfrog-backup/custom_skills');
            manifest.files.push('custom_skills/');
            console.log(chalk.gray(`  + custom_skills/`));
        }
        // Write MANIFEST inline
        const manifestJson = JSON.stringify(manifest, null, 2);
        archive.append(manifestJson, { name: 'greenfrog-backup/MANIFEST.json' });
        archive.finalize();
    });
    const size = statSync(outFile).size;
    console.log(chalk.green(`\n✅ Backup saved:`), chalk.bold(outFile));
    console.log(chalk.gray(`   Size: ${formatBytes(size)}`));
    console.log(chalk.yellow('\n💡 Tip: store this file in a safe location (encrypted storage, offsite backup).'));
    console.log(chalk.yellow('   Secrets in config.yaml are already AES-256-GCM encrypted inside the archive.'));
}
// ── autoBackup ────────────────────────────────────────────────────────────────
/**
 * Run a scheduled backup, saving to `config.backup.dir` (default: dataDir).
 * Automatically prunes backups older than `config.backup.keepDays` (default: 7).
 * Safe to call from a cron scheduler — logs to pino, never throws.
 */
export async function autoBackup() {
    const { configManager } = await import('../../config/index.js');
    const { createLogger } = await import('../../utils/logger.js');
    const log = createLogger('backup');
    const cfg = configManager.get();
    const backupDir = cfg.backup?.dir ?? configManager.dataDir;
    const keepDays = cfg.backup?.keepDays ?? 7;
    try {
        mkdirSync(backupDir, { recursive: true });
        const outFile = join(backupDir, `greenfrog-backup-${timestamp()}.tar.gz`);
        await backupData(outFile);
        log.info({ outFile }, 'Auto-backup completed');
    }
    catch (err) {
        log.error({ err }, 'Auto-backup failed');
        return;
    }
    // Prune old backups beyond keepDays
    try {
        const cutoff = Date.now() - keepDays * 86_400_000;
        for (const f of readdirSync(backupDir).filter((f) => /^greenfrog-backup-.*\.tar\.gz$/.test(f))) {
            const full = join(backupDir, f);
            if (statSync(full).mtimeMs < cutoff) {
                try {
                    unlinkSync(full);
                }
                catch { /* best-effort */ }
            }
        }
    }
    catch { /* non-fatal */ }
}
// ── restore ───────────────────────────────────────────────────────────────────
export async function restoreData(archivePath, opts = {}) {
    if (!existsSync(archivePath)) {
        console.error(chalk.red(`❌ Archive not found: ${archivePath}`));
        process.exit(1);
    }
    const { configManager } = await import('../../config/index.js');
    const dataDir = configManager.dataDir;
    const dbPath = join(dataDir, 'greenfrog.db');
    console.log(chalk.cyan('🔍 Inspecting archive...'));
    // Extract to a temp directory
    const tmpDir = join(tmpdir(), `gf-restore-${Date.now()}`);
    mkdirSync(tmpDir, { recursive: true });
    try {
        // Use system tar (available on macOS, Linux, Windows 10+)
        execSync(`tar -xzf "${archivePath}" -C "${tmpDir}"`, { stdio: 'pipe' });
    }
    catch (err) {
        console.error(chalk.red('❌ Failed to extract archive:'), String(err));
        console.error(chalk.yellow('   Ensure the file is a valid .tar.gz created by `greenfrog backup`.'));
        process.exit(1);
    }
    const extractedBase = join(tmpDir, 'greenfrog-backup');
    if (!existsSync(extractedBase)) {
        console.error(chalk.red('❌ Archive does not contain a greenfrog-backup/ directory.'));
        console.error(chalk.yellow('   This file may not be a valid GreenFrog backup.'));
        process.exit(1);
    }
    // Read and display manifest
    const manifestPath = join(extractedBase, 'MANIFEST.json');
    if (existsSync(manifestPath)) {
        try {
            const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
            console.log(chalk.bold('\nBackup details:'));
            console.log(`  Created:  ${chalk.cyan(manifest.createdAt)}`);
            console.log(`  Platform: ${manifest.platform}  Node: ${manifest.nodeVersion}`);
            console.log(`  Files:    ${manifest.files.join(', ')}`);
        }
        catch { /* non-fatal */ }
    }
    // Safety check: warn if DB already exists
    if (existsSync(dbPath) && !opts.force) {
        console.log(chalk.yellow('\n⚠️  An existing database was found at:'), dbPath);
        console.log(chalk.yellow('   Run with --force to overwrite it, or backup the existing data first.'));
        console.log(chalk.gray('\n   greenfrog backup                # backup current data'));
        console.log(chalk.gray(`   greenfrog restore ${basename(archivePath)} --force  # then restore\n`));
        process.exit(1);
    }
    console.log(chalk.cyan('\n🔄 Restoring files...'));
    mkdirSync(dataDir, { recursive: true });
    // Restore database
    const srcDb = join(extractedBase, 'greenfrog.db');
    if (existsSync(srcDb)) {
        copyFileSync(srcDb, dbPath);
        console.log(chalk.gray(`  ✓ greenfrog.db → ${dbPath}`));
    }
    // Restore config (keep existing if not in archive — e.g. user re-ran on same machine)
    const srcConfig = join(extractedBase, 'config.yaml');
    if (existsSync(srcConfig)) {
        copyFileSync(srcConfig, join(dataDir, 'config.yaml'));
        console.log(chalk.gray(`  ✓ config.yaml → ${join(dataDir, 'config.yaml')}`));
    }
    // Restore custom skills
    const srcSkills = join(extractedBase, 'custom_skills');
    if (existsSync(srcSkills)) {
        const destSkills = join(dataDir, 'custom_skills');
        mkdirSync(destSkills, { recursive: true });
        for (const f of readdirSync(srcSkills)) {
            copyFileSync(join(srcSkills, f), join(destSkills, f));
        }
        console.log(chalk.gray(`  ✓ custom_skills/ → ${destSkills}`));
    }
    // Cleanup temp dir
    try {
        execSync(`rm -rf "${tmpDir}"`, { stdio: 'ignore' });
    }
    catch { /* best-effort */ }
    console.log(chalk.green('\n✅ Restore complete!'));
    console.log(chalk.yellow('   Note: if the backup was from a different machine, you may need to'));
    console.log(chalk.yellow('   set GF_CONFIG_PASSPHRASE so the config secrets decrypt correctly.'));
    console.log(chalk.cyan('\n   Run `greenfrog start` to launch with restored data.'));
}
//# sourceMappingURL=backup.js.map