import { BaseSkill } from './base.js';
import { WeatherSkill } from './weather.js';
import { GitHubSkill } from './github.js';
import { WebSearchSkill } from './web_search.js';
import { CodeExecSkill } from './code_exec.js';
import { FileOpsSkill } from './file_ops.js';
import { SystemInfoSkill } from './system_info.js';
import { ShellExecSkill } from './shell_exec.js';
import { NotesSkill } from './notes.js';
import { ReminderSkill } from './reminder.js';
import { NewsSkill } from './news.js';
import { CalculatorSkill } from './calculator.js';
import { TranslateSkill } from './translate.js';
import { QRCodeSkill } from './qrcode.js';
import { TimezoneSkill } from './timezone.js';
import { MemorySkill } from './memory_skill.js';
import { SkillCreatorSkill } from './skill_creator.js';
import { CodingAgentSkill } from './coding_agent.js';
import { UnitConvertSkill } from './unit_convert.js';
import { WebFetchSkill } from './web_fetch.js';
import { GitOpsSkill } from './git_ops.js';
import { CryptoPriceSkill } from './crypto_price.js';
import { TodoSkill } from './todo.js';
import { ImageGenSkill } from './image_gen.js';
import { CronJobSkill } from './cron_job.js';
import { MultiAgentSkill } from './multi_agent.js';
import { VetterSkill } from './vetter.js';
import { WikipediaSkill } from './wikipedia.js';
import { ExchangeRateSkill } from './exchange_rate.js';
import { IpLookupSkill } from './ip_lookup.js';
import { SummarizeSkill } from './summarize.js';
import { ReaderSkill } from './reader.js';
import { PdfEditSkill } from './pdf_edit.js';
import { HumanizeSkill } from './humanize.js';
import { DrawSkill } from './draw.js';
import { PatrolSkill } from './patrol.js';
import { WorkflowSkill } from './workflow.js';
import { ReflectSkill } from './reflect_scoped.js';
import { ResearchSkill } from './research.js';
import { AuditSkill } from './audit.js';
import { BidDocumentSkill } from './bid_document.js';
import { PresentationSkill } from './presentation.js';
import { HardwareDevSkill } from './hardware_dev.js';
import { HardwareTestSkill } from './hardware_test.js';
import { PatentWriterSkill } from './patent_writer.js';
import { PaperWriterSkill } from './paper_writer.js';
import { TeamSkill } from './team.js';
import { createLogger } from '../utils/logger.js';
import { SkillError } from '../utils/errors.js';
import { config } from '../config/index.js';
import { resolveRoleFromConfig } from '../authz/roles.js';
import { readdirSync, existsSync, readFileSync, renameSync } from 'fs';
import { join } from 'path';
import { memoryStore } from '../memory/store.js';
import { skillCallsTotal, skillDurationMs } from '../metrics/index.js';
// ── Single source of truth for RBAC ──────────────────────────────────────────
//
// Each entry defines the MINIMUM role required to call that skill.
// Anything not listed defaults to 'any' (all authenticated users).
//
// Roles hierarchy:  admin > user > readonly > any
//   'admin'   — only admins may call (dangerous/destructive)
//   'user'    — readonly role is blocked (write/execution capabilities)
//   'any'     — all authenticated users, including readonly
//
export const SKILL_RBAC = {
    // Admin-only: code execution, shell, AI orchestration, plugin creation, audit
    shell: 'admin',
    coding_agent: 'admin',
    skill_creator: 'admin',
    audit: 'admin',
    // User+: blocked for readonly (stateful / resource-intensive)
    execute_code: 'user',
    file_ops: 'user',
    git: 'user',
    multi_agent: 'user',
    generate_image: 'user',
    schedule_job: 'user',
    reminder: 'user',
    patrol: 'user',
    workflow: 'user',
    pdf_edit: 'user',
    notes: 'user',
    todo: 'user',
    reflect: 'user',
    research: 'user',
};
/**
 * Per-skill rate limits for non-admin users.
 * Admins bypass all rate limits.
 * Keys match skill definition names.
 */
const SKILL_RATE_LIMITS = {
    generate_image: { perMinute: 3, perHour: 20 },
    draw: { perMinute: 3, perHour: 20 },
    execute_code: { perMinute: 10, perHour: 60 },
    shell: { perMinute: 5, perHour: 30 },
    research: { perMinute: 2, perHour: 10 },
    multi_agent: { perMinute: 2, perHour: 10 },
    coding_agent: { perMinute: 3, perHour: 15 },
    web_fetch: { perMinute: 15, perHour: 100 },
    web_search: { perMinute: 10, perHour: 80 },
    pdf_edit: { perMinute: 5, perHour: 30 },
    summarize: { perMinute: 5, perHour: 40 },
    bid_document: { perMinute: 2, perHour: 10 },
    presentation: { perMinute: 2, perHour: 10 },
    hardware_dev: { perMinute: 3, perHour: 20 },
    hardware_test: { perMinute: 3, perHour: 20 },
    patent_writer: { perMinute: 1, perHour: 5 },
    paper_writer: { perMinute: 2, perHour: 10 },
};
const log = createLogger('skills');
export class SkillRegistry {
    skills = new Map();
    constructor() {
        this.registerBuiltins();
    }
    registerBuiltins() {
        const builtins = [
            new WeatherSkill(),
            new GitHubSkill(),
            new WebSearchSkill(),
            new CodeExecSkill(),
            new FileOpsSkill(),
            new SystemInfoSkill(),
            new ShellExecSkill(),
            new NotesSkill(),
            new ReminderSkill(),
            new NewsSkill(),
            new CalculatorSkill(),
            new TranslateSkill(),
            new QRCodeSkill(),
            new TimezoneSkill(),
            new MemorySkill(),
            new SkillCreatorSkill(),
            new CodingAgentSkill(),
            new UnitConvertSkill(),
            new WebFetchSkill(),
            new GitOpsSkill(),
            new CryptoPriceSkill(),
            new TodoSkill(),
            new ImageGenSkill(),
            new CronJobSkill(),
            new MultiAgentSkill(),
            new VetterSkill(),
            new WikipediaSkill(),
            new ExchangeRateSkill(),
            new IpLookupSkill(),
            new SummarizeSkill(),
            new ReaderSkill(),
            new PdfEditSkill(),
            new HumanizeSkill(),
            new DrawSkill(),
            new PatrolSkill(),
            new WorkflowSkill(),
            new ReflectSkill(),
            new ResearchSkill(),
            new AuditSkill(),
            new BidDocumentSkill(),
            new PresentationSkill(),
            new HardwareDevSkill(),
            new HardwareTestSkill(),
            new PatentWriterSkill(),
            new PaperWriterSkill(),
            new TeamSkill(),
        ];
        for (const skill of builtins) {
            this.register(skill);
        }
        log.info({ count: this.skills.size }, 'Built-in skills registered');
    }
    register(skill) {
        this.skills.set(skill.definition.name, skill);
        log.debug({ skill: skill.definition.name }, 'Skill registered');
    }
    unregister(name) {
        const had = this.skills.has(name);
        this.skills.delete(name);
        if (had)
            log.info({ skill: name }, 'Skill unregistered');
        return had;
    }
    get(name) {
        return this.skills.get(name);
    }
    list() {
        return [...this.skills.values()];
    }
    listByCategory() {
        const result = {};
        for (const skill of this.skills.values()) {
            const cat = skill.definition.category;
            if (!result[cat])
                result[cat] = [];
            result[cat].push(skill);
        }
        return result;
    }
    toProviderTools() {
        return this.list().map((s) => s.toProviderTool());
    }
    getSkillMeta(name) {
        const skill = this.skills.get(name);
        if (!skill)
            return undefined;
        const rbacMinRole = SKILL_RBAC[name] ?? 'any';
        return {
            name: skill.definition.name,
            description: skill.definition.description,
            category: skill.definition.category,
            parameters: skill.definition.parameters,
            examples: skill.definition.examples ?? [],
            isCustom: skill.isCustom === true,
            rateLimit: SKILL_RATE_LIMITS[name] ?? null,
            rbacMinRole,
        };
    }
    listAllMeta() {
        return this.list().map((s) => this.getSkillMeta(s.definition.name));
    }
    async call(name, params, ctx) {
        const skill = this.skills.get(name);
        if (!skill) {
            throw new SkillError(`Skill "${name}" not found`, name);
        }
        // ── Role-based permission check ──────────────────────────────────────────
        const role = resolveRoleFromConfig(config.roles, ctx.userId, ctx.channel);
        if (role === 'deny') {
            return { success: false, error: 'Access denied: your account is not authorized to use AI skills.' };
        }
        // Check minimum required role from the single RBAC source of truth
        const minRole = SKILL_RBAC[name] ?? 'any';
        if (minRole === 'admin' && role !== 'admin') {
            return { success: false, error: `Skill "${name}" requires admin role.` };
        }
        if (minRole === 'user' && role === 'readonly') {
            return { success: false, error: `Skill "${name}" requires user or admin role.` };
        }
        // 'admin' role: unrestricted; 'any': all roles pass
        // ── Per-skill rate limiting (non-admin users only) ────────────────────────
        if (role !== 'admin') {
            const limits = SKILL_RATE_LIMITS[name];
            if (limits) {
                if (limits.perMinute) {
                    const rlKey = `skill_rl:${name}:${ctx.userId}:min`;
                    if (!memoryStore.checkRateLimit(rlKey, limits.perMinute, 60_000)) {
                        log.warn({ skill: name, userId: ctx.userId, role }, 'Skill per-minute rate limit exceeded');
                        return {
                            success: false,
                            error: `Rate limit: "${name}" can be called at most ${limits.perMinute} times per minute. Please wait.`,
                        };
                    }
                }
                if (limits.perHour) {
                    const rlKey = `skill_rl:${name}:${ctx.userId}:hour`;
                    if (!memoryStore.checkRateLimit(rlKey, limits.perHour, 3_600_000)) {
                        log.warn({ skill: name, userId: ctx.userId, role }, 'Skill per-hour rate limit exceeded');
                        return {
                            success: false,
                            error: `Rate limit: "${name}" can be called at most ${limits.perHour} times per hour. Please wait.`,
                        };
                    }
                }
            }
        }
        log.debug({ skill: name, userId: ctx.userId, role }, 'Calling skill');
        // ── Execute with audit logging + timeout ──────────────────────────────────
        const t0 = Date.now();
        const timeoutMs = config.skillTimeoutMs ?? 60_000;
        let result;
        try {
            let timeoutHandle;
            const timeoutPromise = new Promise((_, reject) => {
                timeoutHandle = setTimeout(() => reject(new Error(`Skill "${name}" timed out after ${timeoutMs}ms`)), timeoutMs);
            });
            result = await Promise.race([skill.execute(params, ctx), timeoutPromise]);
            clearTimeout(timeoutHandle);
            log.debug({ skill: name, success: result.success }, 'Skill completed');
        }
        catch (err) {
            const durationMs = Date.now() - t0;
            const errMsg = String(err);
            const isTimeout = errMsg.includes('timed out');
            if (isTimeout) {
                log.warn({ skill: name, timeoutMs }, 'Skill timed out');
            }
            else {
                log.error({ skill: name, err }, 'Skill execution error');
            }
            skillCallsTotal.inc({ skill: name, success: 'false' });
            skillDurationMs.observe({ skill: name }, durationMs);
            memoryStore.logAudit({
                userId: ctx.userId, channel: ctx.channel, chatId: ctx.chatId,
                skillName: name, params, success: false,
                durationMs, error: errMsg, role,
            });
            return { success: false, error: isTimeout
                    ? `Skill "${name}" timed out — it took longer than ${timeoutMs / 1000}s.`
                    : `Skill "${name}" failed: ${errMsg}` };
        }
        const durationMs = Date.now() - t0;
        skillCallsTotal.inc({ skill: name, success: String(result.success) });
        skillDurationMs.observe({ skill: name }, durationMs);
        memoryStore.logAudit({
            userId: ctx.userId, channel: ctx.channel, chatId: ctx.chatId,
            skillName: name, params, success: result.success,
            durationMs,
            error: result.success ? undefined : result.error,
            role,
        });
        return result;
    }
    /** Load custom skills from data directory — each runs in a Worker thread sandbox */
    async loadCustomSkills() {
        const customDir = join(config.dataDir, 'custom_skills');
        if (!existsSync(customDir))
            return;
        const { SandboxedCustomSkill, verifySkillHash, registerSkillHash } = await import('./skill_creator.js');
        const { vetCode } = await import('./vetter.js');
        const files = readdirSync(customDir).filter((f) => f.endsWith('.js'));
        for (const file of files) {
            const filePath = join(customDir, file);
            // ── File integrity check ─────────────────────────────────────────────
            const integrity = verifySkillHash(customDir, file, filePath);
            if (integrity === 'tampered') {
                // Re-vet the modified file; quarantine if it now contains dangerous code
                log.warn({ file }, 'Custom skill file hash mismatch — re-vetting modified file');
                let code;
                try {
                    code = readFileSync(filePath, 'utf8');
                }
                catch {
                    code = '';
                }
                const vetResult = vetCode(code);
                if (vetResult.blocked) {
                    // Quarantine: rename to .quarantined so it can be inspected but not loaded
                    const quarantinePath = `${filePath}.quarantined`;
                    try {
                        renameSync(filePath, quarantinePath);
                    }
                    catch { /* fs error — still skip */ }
                    log.error({ file, risk: vetResult.risk, score: vetResult.score, quarantined: quarantinePath }, 'Tampered custom skill quarantined — dangerous code detected after modification');
                    continue;
                }
                // Code is still safe — update the manifest hash and continue loading
                log.warn({ file }, 'Tampered skill re-vetted as safe — updating manifest hash');
                registerSkillHash(customDir, file, filePath);
            }
            else if (integrity === 'new') {
                // File exists but has no manifest entry (e.g. manually copied in).
                // Vet it before loading; register hash if safe.
                let code;
                try {
                    code = readFileSync(filePath, 'utf8');
                }
                catch {
                    code = '';
                }
                const vetResult = vetCode(code);
                if (vetResult.blocked) {
                    log.error({ file, risk: vetResult.risk }, 'Unregistered custom skill rejected by vetter — skipping');
                    continue;
                }
                log.info({ file }, 'Unregistered custom skill vetted and accepted');
                registerSkillHash(customDir, file, filePath);
            }
            // integrity === 'ok': hash matches, load without re-vetting
            try {
                // On Windows, convert absolute path to file:// URL for ESM compatibility
                const normalized = filePath.replace(/\\/g, '/');
                const fileUrl = normalized.match(/^[A-Za-z]:/) ? `file:///${normalized}` : filePath;
                const mod = await import(fileUrl);
                for (const value of Object.values(mod)) {
                    if (typeof value === 'function' &&
                        (value.prototype instanceof BaseSkill || typeof value.prototype?.execute === 'function')) {
                        // Read definition from a temporary instance
                        const tmp = new value();
                        const sandboxed = new SandboxedCustomSkill(tmp.definition, filePath);
                        this.register(sandboxed);
                        log.info({ skill: tmp.definition.name }, 'Custom skill loaded (sandboxed)');
                        break;
                    }
                }
            }
            catch (err) {
                log.warn({ file, err }, 'Failed to load custom skill');
            }
        }
    }
}
export const skillRegistry = new SkillRegistry();
//# sourceMappingURL=registry.js.map