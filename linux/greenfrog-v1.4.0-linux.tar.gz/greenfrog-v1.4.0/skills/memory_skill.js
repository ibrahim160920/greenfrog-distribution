import { BaseSkill } from './base.js';
import { setScopedMemoryForContext, getScopedMemoryForContext, deleteScopedMemoryForContext, getAllScopedMemoryForContext, searchScopedMemoryForContext, } from '../memory/index.js';
export class MemorySkill extends BaseSkill {
    definition = {
        name: 'memory',
        description: 'Store and retrieve information across conversations. Remember user preferences, facts, and context.',
        category: 'system',
        parameters: [
            { name: 'action', type: 'string', required: true, description: 'Action', enum: ['remember', 'recall', 'forget', 'list', 'search'] },
            { name: 'key', type: 'string', description: 'Memory key/label' },
            { name: 'value', type: 'string', description: 'Value to remember' },
            { name: 'query', type: 'string', description: 'Search query (for search action)' },
        ],
        examples: [
            'Remember my name is John',
            'Remember I prefer dark mode',
            'What do you remember about me?',
        ],
    };
    async execute(params, ctx) {
        switch (params.action) {
            case 'remember': {
                if (!params.key || !params.value)
                    return this.err('key and value are required');
                await setScopedMemoryForContext(ctx, params.key, params.value, 365);
                return this.text(`💾 Remembered: **${params.key}** = ${params.value}`);
            }
            case 'recall': {
                if (!params.key)
                    return this.err('key is required');
                const value = await getScopedMemoryForContext(ctx, params.key);
                if (!value)
                    return this.text(`I don't have anything stored for "${params.key}"`);
                return this.text(`💡 **${params.key}**: ${value}`);
            }
            case 'forget': {
                if (!params.key)
                    return this.err('key is required');
                const deleted = await deleteScopedMemoryForContext(ctx, params.key);
                return this.text(deleted ? `🗑 Forgot: ${params.key}` : `Nothing to forget for "${params.key}"`);
            }
            case 'list': {
                const all = await getAllScopedMemoryForContext(ctx);
                const entries = Object.entries(all).filter(([k]) => !k.startsWith('note:') && !k.startsWith('reminder:'));
                if (entries.length === 0)
                    return this.text("I don't have any memories yet!");
                const lines = entries.map(([k, v]) => `• **${k}**: ${v.slice(0, 100)}`);
                return this.text(`🧠 **What I remember about you (${entries.length} items):**\n\n${lines.join('\n')}`);
            }
            case 'search': {
                if (!params.query)
                    return this.err('query is required');
                const results = await searchScopedMemoryForContext(ctx, params.query);
                if (results.length === 0)
                    return this.text(`No memories matching "${params.query}"`);
                const lines = results.map((r) => `• **${r.key}**: ${r.value.slice(0, 100)}`);
                return this.text(`🔍 Memories matching "${params.query}":\n\n${lines.join('\n')}`);
            }
            default:
                return this.err(`Unknown action: ${params.action}`);
        }
    }
}
//# sourceMappingURL=memory_skill.js.map