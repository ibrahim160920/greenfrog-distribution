import cluster from 'node:cluster';
import { existsSync, readFileSync, unlinkSync } from 'fs';
import { join } from 'path';
import { ConfigError } from '../utils/errors.js';
function isProcessAlive(pid) {
    try {
        process.kill(pid, 0);
        return true;
    }
    catch {
        return false;
    }
}
function isLockFileStale(lockPath) {
    try {
        const content = readFileSync(lockPath, 'utf8').trim();
        if (!content)
            return true; // empty lock file = killed before PID was written
        const data = JSON.parse(content);
        if (typeof data.pid !== 'number')
            return true;
        return !isProcessAlive(data.pid);
    }
    catch {
        return true; // unreadable / malformed = treat as stale
    }
}
function parsePositiveInteger(value) {
    if (typeof value !== 'string' || !value.trim())
        return null;
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0)
        return null;
    return Math.floor(parsed);
}
function isTruthyEnv(value) {
    return typeof value === 'string' && /^(1|true|yes|on)$/i.test(value.trim());
}
export function detectLikelySqliteMultiProcessRuntime(env = process.env, isClusterWorker = cluster.isWorker, dataDir) {
    const reasons = new Set();
    if (isClusterWorker)
        reasons.add('node_cluster_worker');
    const execMode = String(env.pm_exec_mode ?? env.PM2_EXEC_MODE ?? env.exec_mode ?? '').trim().toLowerCase();
    if (execMode === 'cluster_mode')
        reasons.add('pm2_cluster_mode');
    const nodeAppInstance = parsePositiveInteger(env.NODE_APP_INSTANCE);
    if (nodeAppInstance != null && nodeAppInstance > 0)
        reasons.add(`NODE_APP_INSTANCE=${nodeAppInstance}`);
    const pmId = parsePositiveInteger(env.pm_id ?? env.PM2_INSTANCE_ID);
    if (pmId != null && pmId > 0)
        reasons.add(`pm_id=${pmId}`);
    const webConcurrency = parsePositiveInteger(env.WEB_CONCURRENCY);
    if (webConcurrency != null && webConcurrency > 1)
        reasons.add(`WEB_CONCURRENCY=${webConcurrency}`);
    const pm2Instances = parsePositiveInteger(env.PM2_INSTANCES ?? env.INSTANCES);
    if (pm2Instances != null && pm2Instances > 1)
        reasons.add(`PM2_INSTANCES=${pm2Instances}`);
    if (typeof env.NODE_UNIQUE_ID === 'string' && env.NODE_UNIQUE_ID.trim()) {
        reasons.add('NODE_UNIQUE_ID');
    }
    // Check for existing database lock file (skip stale locks from crashed processes)
    if (dataDir && dataDir !== ':memory:') {
        const lockPath = join(dataDir, 'memory.db.lock');
        if (existsSync(lockPath)) {
            if (isLockFileStale(lockPath)) {
                try {
                    unlinkSync(lockPath);
                }
                catch { /* ignore */ }
            }
            else {
                reasons.add('database_lock_file_exists');
            }
        }
    }
    return { detected: reasons.size > 0, reasons: [...reasons] };
}
export function assertSafeSqliteRuntime(params) {
    if (!params.usingSqlite)
        return;
    const env = params.env ?? process.env;
    if (isTruthyEnv(env.ALLOW_SQLITE_MULTIPROCESS))
        return;
    const detected = detectLikelySqliteMultiProcessRuntime(env, params.isClusterWorker, params.dataDir);
    if (!detected.detected)
        return;
    throw new ConfigError(`SQLite direct mode is blocked in multi-process runtime (${detected.reasons.join(', ')}). `
        + 'Use PostgreSQL for multi-instance deployment, or force a single app process. '
        + 'Set ALLOW_SQLITE_MULTIPROCESS=1 only if you explicitly accept SQLite lock and corruption risk.', { reasons: detected.reasons });
}
//# sourceMappingURL=sqlite_runtime_guard.js.map