/**
 * agent_heartbeat.ts
 *
 * In-memory heartbeat registry for core runtime actors.
 * Each actor (agent-loop, scheduler, workflow-runner) calls touchHeartbeat()
 * after completing real work. Status is computed on read — no background timer needed.
 *
 * Thresholds:
 *   healthy  = last heartbeat < 2 min ago
 *   stale    = 2–10 min ago
 *   dead     = > 10 min ago (or never seen)
 */
const HEALTHY_MS = 2 * 60_000; //  2 minutes
const STALE_MS = 10 * 60_000; // 10 minutes
const registry = new Map();
function computeStatus(lastHeartbeatAt) {
    const age = Date.now() - lastHeartbeatAt;
    if (age < HEALTHY_MS)
        return 'healthy';
    if (age < STALE_MS)
        return 'stale';
    return 'dead';
}
/**
 * Record a heartbeat from a runtime actor.
 * @param id     Stable actor identifier (e.g. 'agent-loop')
 * @param name   Human-readable name (e.g. 'Agent Loop')
 * @param source Optional extra context (e.g. userId, workflowId)
 * @param error  If this beat is recording a failure, pass the error string
 */
export function touchHeartbeat(id, name, source, error) {
    const now = Date.now();
    const existing = registry.get(id);
    registry.set(id, {
        id,
        name,
        source: source ?? existing?.source ?? '',
        lastHeartbeatAt: now,
        lastSuccessAt: error ? (existing?.lastSuccessAt ?? null) : now,
        lastError: error ?? null,
    });
}
/**
 * Return all registered heartbeat entries with freshly-computed status.
 */
export function getHeartbeats() {
    return Array.from(registry.values()).map((e) => ({
        ...e,
        status: computeStatus(e.lastHeartbeatAt),
    }));
}
//# sourceMappingURL=agent_heartbeat.js.map