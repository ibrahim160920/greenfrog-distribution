import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class PatentWriterSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    private writePatent;
    private reviewPatent;
    private searchPriorArt;
}
//# sourceMappingURL=patent_writer.d.ts.map