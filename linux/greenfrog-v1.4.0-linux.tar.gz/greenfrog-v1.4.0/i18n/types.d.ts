/**
 * i18n types for GreenFrog child distribution system.
 * Shared by installer, first-boot, and runtime.
 */
/** Supported locale codes — add here to register a new language. */
export type SupportedLocale = 'en' | 'zh-CN' | 'zh-TW' | 'ja' | 'ko' | 'de' | 'it' | 'fr' | 'es' | 'pt';
/** All locale metadata in one place. */
export interface LocaleDescriptor {
    code: SupportedLocale;
    name: string;
    nativeName: string;
    dir: 'ltr' | 'rtl';
}
export declare const SUPPORTED_LOCALES: LocaleDescriptor[];
export declare const DEFAULT_LOCALE: SupportedLocale;
/**
 * Flat key-value messages. All values are strings; nested keys use dot notation
 * internally but the JSON files use nested objects for readability.
 */
export type Messages = Record<string, string>;
/** Raw nested structure from JSON files — flattened at load time. */
export type RawMessages = {
    [key: string]: string | RawMessages;
};
//# sourceMappingURL=types.d.ts.map