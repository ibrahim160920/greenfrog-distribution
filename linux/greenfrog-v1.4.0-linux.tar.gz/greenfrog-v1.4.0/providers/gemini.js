import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from '@google/generative-ai';
import { BaseProvider } from './base.js';
import { ProviderError } from '../utils/errors.js';
export class GeminiProvider extends BaseProvider {
    name = 'gemini';
    defaultModel = 'gemini-2.0-flash';
    client;
    model;
    // Safety settings — permissive for general assistant use
    safetySettings = [
        { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
        { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
        { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
        { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
    ];
    constructor(apiKey, model) {
        super();
        this.client = new GoogleGenerativeAI(apiKey);
        this.model = model ?? this.defaultModel;
    }
    async chat(request) {
        const modelName = request.model ?? this.model;
        const { history, lastUserParts } = this.buildContents(request);
        const tools = this.buildTools(request);
        try {
            const genModel = this.client.getGenerativeModel({
                model: modelName,
                systemInstruction: request.systemPrompt,
                safetySettings: this.safetySettings,
                generationConfig: {
                    maxOutputTokens: request.maxTokens ?? 4096,
                    temperature: request.temperature,
                },
                ...(tools ? { tools } : {}),
            });
            const chat = genModel.startChat({ history });
            const result = await chat.sendMessage(lastUserParts);
            const response = result.response;
            // Extract text content
            const content = response.text();
            // Extract function calls
            const toolCalls = [];
            for (const candidate of response.candidates ?? []) {
                for (const part of candidate.content?.parts ?? []) {
                    if (part.functionCall) {
                        toolCalls.push({
                            id: `gemini-${Date.now()}-${toolCalls.length}`,
                            name: part.functionCall.name,
                            arguments: (part.functionCall.args ?? {}),
                        });
                    }
                }
            }
            return {
                content,
                toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                rawContent: toolCalls.length > 0 ? { functionCalls: toolCalls } : undefined,
                usage: response.usageMetadata
                    ? {
                        inputTokens: response.usageMetadata.promptTokenCount ?? 0,
                        outputTokens: response.usageMetadata.candidatesTokenCount ?? 0,
                    }
                    : undefined,
                model: modelName,
            };
        }
        catch (err) {
            throw new ProviderError(`Gemini API error: ${String(err)}`, err);
        }
    }
    chatStream(request) {
        const modelName = request.model ?? this.model;
        const { history, lastUserParts } = this.buildContents(request);
        const tools = this.buildTools(request);
        let content = '';
        const toolCalls = [];
        let streamDone = false;
        let streamError;
        const genModel = this.client.getGenerativeModel({
            model: modelName,
            systemInstruction: request.systemPrompt,
            safetySettings: this.safetySettings,
            generationConfig: {
                maxOutputTokens: request.maxTokens ?? 4096,
                temperature: request.temperature,
            },
            ...(tools ? { tools } : {}),
        });
        async function* textStream() {
            try {
                const chat = genModel.startChat({ history });
                const result = await chat.sendMessageStream(lastUserParts);
                for await (const chunk of result.stream) {
                    const text = chunk.text();
                    if (text) {
                        content += text;
                        yield text;
                    }
                    // Accumulate function calls from chunks
                    for (const candidate of chunk.candidates ?? []) {
                        for (const part of candidate.content?.parts ?? []) {
                            if (part.functionCall) {
                                toolCalls.push({
                                    id: `gemini-${Date.now()}-${toolCalls.length}`,
                                    name: part.functionCall.name,
                                    arguments: (part.functionCall.args ?? {}),
                                });
                            }
                        }
                    }
                }
                streamDone = true;
            }
            catch (err) {
                streamError = err;
                streamDone = true;
                throw new ProviderError(`Gemini stream error: ${String(err)}`, err);
            }
        }
        const ts = textStream();
        const complete = async () => {
            if (!streamDone) {
                for await (const _ of ts) { /* drain */ }
            }
            if (streamError)
                throw streamError;
            return {
                content,
                toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                rawContent: toolCalls.length > 0 ? { functionCalls: toolCalls } : undefined,
                model: modelName,
            };
        };
        return { textStream: ts, complete };
    }
    async isAvailable() {
        try {
            const genModel = this.client.getGenerativeModel({ model: this.model });
            await genModel.generateContent('ping');
            return true;
        }
        catch {
            return false;
        }
    }
    async listModels() {
        // Gemini SDK doesn't expose a list-models endpoint; return known models
        return [
            'gemini-2.0-flash',
            'gemini-2.0-flash-lite',
            'gemini-1.5-pro',
            'gemini-1.5-flash',
            'gemini-1.5-flash-8b',
        ];
    }
    // ── Private helpers ──────────────────────────────────────────────────────────
    buildContents(request) {
        const history = [];
        const messages = request.messages;
        // All messages except the last user message go into history
        for (let i = 0; i < messages.length - 1; i++) {
            const m = messages[i];
            if (m.role === 'user') {
                history.push({ role: 'user', parts: [{ text: m.content }] });
            }
            else if (m.role === 'assistant') {
                // Check for function call rawContent
                if (m.rawContent && typeof m.rawContent === 'object') {
                    const raw = m.rawContent;
                    if (raw.functionCalls && raw.functionCalls.length > 0) {
                        history.push({
                            role: 'model',
                            parts: raw.functionCalls.map((fc) => ({
                                functionCall: { name: fc.name, args: fc.arguments },
                            })),
                        });
                        continue;
                    }
                }
                history.push({ role: 'model', parts: [{ text: m.content }] });
            }
            else if (m.toolResults && m.toolResults.length > 0) {
                // Tool results go as function responses
                history.push({
                    role: 'user',
                    parts: m.toolResults.map((r) => ({
                        functionResponse: {
                            name: r.id, // Gemini uses name, not id
                            response: { content: r.content },
                        },
                    })),
                });
            }
        }
        // Last message — build parts (may include images)
        const last = messages[messages.length - 1];
        const lastUserParts = [];
        if (last) {
            if (last.imageAttachments && last.imageAttachments.length > 0) {
                for (const img of last.imageAttachments) {
                    lastUserParts.push({
                        inlineData: { mimeType: img.mimeType, data: img.base64 },
                    });
                }
            }
            if (last.content) {
                lastUserParts.push({ text: last.content });
            }
        }
        if (lastUserParts.length === 0)
            lastUserParts.push({ text: '' });
        return { history, lastUserParts };
    }
    buildTools(request) {
        if (!request.tools || request.tools.length === 0)
            return undefined;
        return [{
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                functionDeclarations: request.tools.map((t) => ({
                    name: t.name,
                    description: t.description,
                    parameters: t.parameters,
                })),
            }];
    }
}
//# sourceMappingURL=gemini.js.map