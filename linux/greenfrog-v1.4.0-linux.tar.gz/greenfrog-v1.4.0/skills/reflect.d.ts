/**
 * Reflect — 自我反思技能
 *
 * 让 AI 主动回顾自己的表现，从错误中学习，更新行为规则。
 * 使用越久，积累的交互越多，反思质量越高。
 *
 * 功能：
 *   reflect run        — 触发一次完整反思
 *   reflect status     — 查看学习统计（好评率、规则数、反馈量）
 *   reflect rules      — 列出已学会的行为规则
 *   reflect delete     — 删除某条错误的规则
 *   reflect reset      — 清除所有规则（重新学习）
 */
import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class ReflectSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    private runReflect;
    private showStatus;
    private maturityLevel;
    private showRules;
    private deleteRule;
    private resetRules;
}
//# sourceMappingURL=reflect.d.ts.map