/**
 * Behavioral Rule Compressor
 *
 * When a scope accumulates too many behavioral rules, the system prompt grows
 * unboundedly and dilutes reasoning quality.  This module uses a cheap LLM call
 * (default: whatever is configured, prefer a small/fast model) to deduplicate,
 * merge, and prune the rule set down to a manageable size.
 *
 * Design principles:
 *  - Fire-and-forget: compression runs in the background, never blocks responses
 *  - Conservative: only runs when count exceeds COMPRESS_THRESHOLD
 *  - Safe: if LLM call fails, the original rules are left unchanged
 *  - Traceable: compressed rules are tagged source='compressed'
 *  - Cooldown: prevents re-compression within COOLDOWN_MS of the last run
 */
import { providerRegistry } from '../providers/index.js';
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('memory:rule-compressor');
/** Compress when a scope exceeds this many rules. */
export const COMPRESS_THRESHOLD = 25;
/** Never emit more than this many rules after compression. */
const COMPRESS_TARGET = 15;
/** Don't re-compress a scope within this window (ms). */
const COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes
/** Tracks the last compression timestamp per scope key. */
const lastCompressedAt = new Map();
function scopeKey(scope) {
    return [scope.userId, scope.channel, scope.workspaceId ?? '', scope.agentId ?? ''].join('::');
}
const COMPRESS_SYSTEM = `You are consolidating a list of behavioral rules for an AI agent.
Your goal: reduce the list to the most valuable, non-redundant rules.

Output ONLY a JSON array of objects, no other text:
[{"rule":"...","category":"style|format|content|tone|workflow","confidence":40-100}]

Rules for compression:
- Merge near-duplicate rules into one (keep highest confidence)
- Remove rules that are too generic to be actionable (e.g. "be careful", "do good work")
- Keep rules that encode specific, hard-learned lessons
- Preserve category and assign the highest confidence of the merged group
- Target ${COMPRESS_TARGET} rules or fewer; fewer is better if quality is maintained
- Output exactly the compressed list — no commentary`;
/**
 * Compress behavioral rules for a scope if the count exceeds COMPRESS_THRESHOLD.
 * Safe to call concurrently — duplicate triggers for the same scope are deduplicated
 * via the cooldown map.
 *
 * @param scope   The memory scope whose rules should be compressed
 * @param model   Optional model override (prefer a cheap/fast model like haiku)
 * @param provider Optional provider override
 */
export async function compressBehavioralRulesIfNeeded(scope, opts) {
    const key = scopeKey(scope);
    const now = Date.now();
    const lastRun = lastCompressedAt.get(key) ?? 0;
    if (now - lastRun < COOLDOWN_MS) {
        return { attempted: false, compressed: false, cooldownSkipped: true, before: 0, after: 0 };
    }
    const rules = await memoryStore.getScopedBehavioralRules(scope, 0); // minConfidence=0 to see all
    if (rules.length <= COMPRESS_THRESHOLD) {
        return { attempted: false, compressed: false, cooldownSkipped: false, before: rules.length, after: rules.length };
    }
    // Mark as running immediately to prevent concurrent compression of the same scope
    lastCompressedAt.set(key, now);
    try {
        const rulesText = rules
            .map((r, i) => `${i + 1}. [${r.category}, conf=${r.confidence}] ${r.rule}`)
            .join('\n');
        const prompt = `Compress these ${rules.length} behavioral rules down to ${COMPRESS_TARGET} or fewer.\n\n${rulesText}`;
        const res = await providerRegistry.chatWithFallback({
            messages: [{ role: 'user', content: prompt }],
            systemPrompt: COMPRESS_SYSTEM,
            maxTokens: 1200,
            temperature: 0.1,
            ...(opts?.model ? { model: opts.model } : {}),
        }, opts?.provider ?? undefined);
        const match = (res.content ?? '').match(/\[[\s\S]*\]/);
        if (!match) {
            log.warn({ scope }, 'Rule compression: LLM returned no JSON array');
            return { attempted: true, compressed: false, cooldownSkipped: false, before: rules.length, after: rules.length };
        }
        const parsed = JSON.parse(match[0]);
        const validCategories = new Set(['style', 'format', 'content', 'tone', 'workflow']);
        const compressed = [];
        for (const item of parsed) {
            if (typeof item !== 'object' || item === null)
                continue;
            const r = item;
            const rule = typeof r['rule'] === 'string' ? r['rule'].trim().slice(0, 120) : '';
            const category = typeof r['category'] === 'string' ? r['category'] : '';
            if (!rule || !validCategories.has(category))
                continue;
            const rawConf = typeof r['confidence'] === 'number' ? r['confidence'] : 60;
            compressed.push({
                rule,
                category,
                confidence: Math.min(100, Math.max(40, rawConf)),
                source: 'compressed',
            });
            if (compressed.length >= COMPRESS_TARGET)
                break;
        }
        if (compressed.length === 0) {
            log.warn({ scope }, 'Rule compression: LLM returned no valid rules, aborting');
            return { attempted: true, compressed: false, cooldownSkipped: false, before: rules.length, after: rules.length };
        }
        await memoryStore.bulkReplaceScopedBehavioralRules(scope, compressed);
        log.info({ scope, before: rules.length, after: compressed.length }, 'Rule compression: behavioral rules compacted');
        return {
            attempted: true,
            compressed: true,
            cooldownSkipped: false,
            before: rules.length,
            after: compressed.length,
        };
    }
    catch (err) {
        // Compression is best-effort — never crash or block the calling path
        log.warn({ err: String(err), scope }, 'Rule compression failed (non-fatal, original rules unchanged)');
        // Reset cooldown so a transient error doesn't permanently suppress compression
        lastCompressedAt.delete(key);
        return { attempted: true, compressed: false, cooldownSkipped: false, before: rules.length, after: rules.length };
    }
}
//# sourceMappingURL=rule_compressor.js.map