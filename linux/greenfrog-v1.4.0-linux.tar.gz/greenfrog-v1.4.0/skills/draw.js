/**
 * Draw — 全能画图技能
 *
 * 主引擎：Pollinations.ai（完全免费，无需任何 key）
 *   模型：flux (默认) | flux-realism | flux-3d | nanobanana | nanobanana-pro |
 *         kontext | seedream | flux-anime | turbo | dreamshaper
 *   img2img：通过 ?image=URL 传入参考图
 *   最高分辨率：1280×1280 原生，内置 2× upscaler → ~2560×2560
 *
 * 增强引擎（可选 key）：
 *   Fal.ai（FAL_API_KEY）：背景移除、高质量 img2img
 *   本地 SD WebUI（localhost:7860）：任意分辨率、inpainting、ControlNet
 *
 * 功能：
 *   - 文生图（支持超高清、3D 渲染、各种风格）
 *   - 图生图（改风格、换背景、图片编辑）
 *   - 智能模型选择（根据 prompt 关键词自动匹配最优模型）
 *   - 分辨率预设（square / hd / 2k / portrait / landscape / banner）
 */
import { BaseSkill } from './base.js';
import { config } from '../config/index.js';
// ─── 分辨率预设 ────────────────────────────────────────────────────────────────
const SIZES = {
    square: [1024, 1024],
    hd: [1280, 720],
    'hd-v': [720, 1280],
    portrait: [768, 1344],
    landscape: [1344, 768],
    '2k': [1536, 1536],
    '4k': [2048, 2048], // Pollinations 2× upscaler 模式
    banner: [1600, 400],
    wide: [1920, 1080],
};
// ─── Pollinations 模型清单 ─────────────────────────────────────────────────────
const POLLINATIONS_MODELS = [
    'flux', 'flux-realism', 'flux-3d', 'flux-anime', 'flux-pro',
    'nanobanana', 'nanobanana-pro', 'kontext', 'seedream', 'turbo', 'dreamshaper',
];
// 关键词 → 推荐模型映射（根据 prompt 自动选型）
const KEYWORD_MODEL_MAP = [
    { keywords: /\b(3d|三维|立体|render|渲染|cinema\s*4d|blender|octane|3d\s*design|3d\s*model|三维模型|产品渲染)\b/i, model: 'flux-3d' },
    { keywords: /\b(anime|动漫|二次元|cartoon|漫画|插画|illustration|手绘|manga)\b/i, model: 'flux-anime' },
    { keywords: /\b(photo|照片|realistic|写实|真实感|portrait|人像|摄影|hyperrealistic|8k photo)\b/i, model: 'flux-realism' },
    { keywords: /\b(nanobanana|nano.?banana)\b/i, model: 'nanobanana-pro' },
    { keywords: /\b(dreamshaper|梦幻|fantasy|奇幻)\b/i, model: 'dreamshaper' },
    { keywords: /\b(fast|quick|快速|草图|sketch|概念图)\b/i, model: 'turbo' },
];
function autoSelectModel(prompt) {
    for (const { keywords, model } of KEYWORD_MODEL_MAP) {
        if (keywords.test(prompt))
            return model;
    }
    return 'flux';
}
// ─── 3D 风格 prompt 增强 ────────────────────────────────────────────────────────
function enhance3DPrompt(prompt) {
    const keywords3D = /\b(3d|render|blender|octane|cinema|3d\s*model|三维|渲染)\b/i;
    if (keywords3D.test(prompt))
        return prompt;
    return `${prompt}, 3D render, octane render, cinema 4D, physically based rendering, studio lighting, high detail`;
}
// ─── 技能主类 ──────────────────────────────────────────────────────────────────
export class DrawSkill extends BaseSkill {
    definition = {
        name: 'draw',
        description: '全能画图技能：文生图、图生图、换背景、换风格、3D渲染、超高清。' +
            '完全免费无需 API key（基于 Pollinations.ai + nanobanana-pro / flux-3d 等模型）。' +
            '支持直接在对话中画图，一句话描述即可，无需打开其他工具。',
        category: 'creative',
        parameters: [
            {
                name: 'prompt',
                type: 'string',
                required: true,
                description: '描述想要的图片内容，或对参考图做什么修改',
            },
            {
                name: 'image_url',
                type: 'string',
                description: '参考图 URL（用于图生图：换风格、换背景、图片编辑）。需要是公开可访问的 HTTP/HTTPS URL',
            },
            {
                name: 'size',
                type: 'string',
                description: '分辨率：square=1024² | hd=1280×720 | portrait=768×1344 | landscape=1344×768 | 2k=1536² | 4k=2048² | banner=1600×400 | wide=1920×1080',
                enum: ['square', 'hd', 'hd-v', 'portrait', 'landscape', '2k', '4k', 'banner', 'wide'],
                default: 'square',
            },
            {
                name: 'model',
                type: 'string',
                description: '模型（默认自动选择）：auto=智能匹配 | flux=通用 | flux-realism=写实 | flux-3d=三维渲染 | flux-anime=动漫 | nanobanana-pro=高质量 | kontext=图文一致 | turbo=极速',
                enum: ['auto', ...POLLINATIONS_MODELS],
                default: 'auto',
            },
            {
                name: 'engine',
                type: 'string',
                description: '引擎：pollinations=免费云端（默认） | sd=本地SD WebUI(localhost:7860) | dalle3=DALL-E3(需OpenAI key) | fal=Fal.ai(需FAL_API_KEY)',
                enum: ['pollinations', 'sd', 'dalle3', 'fal'],
                default: 'pollinations',
            },
            {
                name: 'steps',
                type: 'number',
                description: 'SD WebUI 专用：生成步数（越高越精细，越慢），默认 25',
            },
        ],
        examples: [
            '画一幅赛博朋克风格的夜晚城市街道',
            '帮我画一个3D渲染的未来感产品概念图，黑色底，蓝色科技感',
            '把这张图改成水彩画风格 image_url=https://... ',
            '给这张图换一个星空背景 image_url=https://...',
            '画一张4K超清的森林晨雾照片 size=4k model=flux-realism',
        ],
    };
    async execute(params, _ctx) {
        const prompt = (params.prompt ?? '').trim();
        const imageUrl = (params.image_url ?? '').trim();
        const sizeName = (params.size ?? 'square');
        const modelParm = (params.model ?? 'auto');
        const engine = (params.engine ?? 'pollinations');
        const steps = typeof params.steps === 'number' ? params.steps : 25;
        if (!prompt)
            return this.err('prompt 不能为空');
        const [width, height] = SIZES[sizeName] ?? [1024, 1024];
        const model = (modelParm === 'auto' || !POLLINATIONS_MODELS.includes(modelParm))
            ? autoSelectModel(prompt)
            : modelParm;
        // 3D 模式自动增强 prompt
        const finalPrompt = model === 'flux-3d' ? enhance3DPrompt(prompt) : prompt;
        switch (engine) {
            case 'dalle3': return this.dalle3(finalPrompt, width, height);
            case 'sd': return this.sdWebUI(finalPrompt, imageUrl, width, height, steps);
            case 'fal': return this.falAi(finalPrompt, imageUrl, width, height);
            default: return this.pollinations(finalPrompt, imageUrl, model, width, height);
        }
    }
    // ── Pollinations.ai（主引擎，完全免费）────────────────────────────────────────
    async pollinations(prompt, imageUrl, model, width, height) {
        const seed = Math.floor(Math.random() * 1_000_000);
        const encoded = encodeURIComponent(prompt);
        const params = new URLSearchParams({
            model,
            width: String(width),
            height: String(height),
            seed: String(seed),
            nologo: '1',
            enhance: 'false',
        });
        // img2img：传入参考图 URL
        if (imageUrl) {
            params.set('image', imageUrl);
        }
        const url = `https://image.pollinations.ai/prompt/${encoded}?${params.toString()}`;
        const mode = imageUrl ? '图生图' : '文生图';
        const label = imageUrl ? `(参考图: ${imageUrl.slice(0, 60)}...)` : '';
        try {
            const check = await fetch(url, {
                method: 'HEAD',
                signal: AbortSignal.timeout(30_000),
            });
            if (!check.ok) {
                return this.err(`Pollinations 返回 HTTP ${check.status}，换个 prompt 再试`);
            }
            const ct = check.headers.get('content-type') ?? '';
            if (!ct.startsWith('image/')) {
                return this.err('Pollinations 未返回图片，稍后重试或换个描述');
            }
        }
        catch (err) {
            return this.err(`图片生成超时/失败: ${String(err)}`);
        }
        return this.text(`🎨 **${mode}完成** · 模型: \`${model}\` · ${width}×${height}\n` +
            `${label}\n\n` +
            `${url}\n\n` +
            `*Prompt: "${prompt}"*`);
    }
    // ── Fal.ai（需 FAL_API_KEY，更高质量 + 背景移除）─────────────────────────────
    async falAi(prompt, imageUrl, width, height) {
        const apiKey = process.env.FAL_API_KEY ?? '';
        if (!apiKey) {
            return this.err('Fal.ai 需要设置 FAL_API_KEY 环境变量。不需要 key 请使用默认引擎 (pollinations)。');
        }
        // 背景移除 / 替换：先用 birefnet 移除背景，再用 FLUX 合成
        const endpoint = imageUrl
            ? 'https://fal.run/fal-ai/flux/dev/image-to-image'
            : 'https://fal.run/fal-ai/flux-pro/v1.1';
        const body = imageUrl
            ? { prompt, image_url: imageUrl, strength: 0.75, image_size: { width, height }, num_images: 1 }
            : { prompt, image_size: { width, height }, num_images: 1, safety_tolerance: '5' };
        try {
            const res = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Authorization': `Key ${apiKey}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(body),
                signal: AbortSignal.timeout(120_000),
            });
            if (!res.ok) {
                const errText = await res.text();
                return this.err(`Fal.ai 错误: ${res.status} — ${errText}`);
            }
            const data = await res.json();
            const imgUrl = data.images?.[0]?.url;
            if (!imgUrl)
                return this.err('Fal.ai 未返回图片 URL');
            return this.text(`🎨 **图片生成完成** · Fal.ai FLUX · ${width}×${height}\n\n${imgUrl}\n\n*Prompt: "${prompt}"*`);
        }
        catch (err) {
            return this.err(`Fal.ai 错误: ${String(err)}`);
        }
    }
    // ── 本地 Stable Diffusion WebUI ────────────────────────────────────────────
    async sdWebUI(prompt, imageUrl, width, height, steps) {
        const baseUrl = 'http://localhost:7860';
        // img2img：需要把参考图转 base64
        if (imageUrl) {
            let imageB64;
            try {
                const imgRes = await fetch(imageUrl, { signal: AbortSignal.timeout(30_000) });
                if (!imgRes.ok)
                    return this.err(`无法下载参考图: ${imgRes.status}`);
                const buf = Buffer.from(await imgRes.arrayBuffer());
                imageB64 = buf.toString('base64');
            }
            catch (err) {
                return this.err(`下载参考图失败: ${String(err)}`);
            }
            try {
                const res = await fetch(`${baseUrl}/sdapi/v1/img2img`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        prompt,
                        init_images: [`data:image/jpeg;base64,${imageB64}`],
                        denoising_strength: 0.75,
                        steps,
                        width,
                        height,
                        cfg_scale: 7,
                    }),
                    signal: AbortSignal.timeout(180_000),
                });
                if (!res.ok)
                    return this.err(`SD WebUI img2img 错误: ${res.status}`);
                const data = await res.json();
                const b64 = data.images?.[0];
                if (!b64)
                    return this.err('SD WebUI 未返回图片');
                return this.text(`🎨 **图生图完成** · SD WebUI · ${width}×${height}\n\ndata:image/png;base64,${b64}\n\n*Prompt: "${prompt}"*`);
            }
            catch (err) {
                return this.err(`SD WebUI 错误: ${String(err)}。确认 SD WebUI 以 --api 参数运行在 localhost:7860`);
            }
        }
        // txt2img
        try {
            const res = await fetch(`${baseUrl}/sdapi/v1/txt2img`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt, steps, width, height, cfg_scale: 7 }),
                signal: AbortSignal.timeout(180_000),
            });
            if (!res.ok)
                return this.err(`SD WebUI 错误: ${res.status}`);
            const data = await res.json();
            const b64 = data.images?.[0];
            if (!b64)
                return this.err('SD WebUI 未返回图片');
            return this.text(`🎨 **文生图完成** · SD WebUI · ${width}×${height}\n\ndata:image/png;base64,${b64}\n\n*Prompt: "${prompt}"*`);
        }
        catch (err) {
            return this.err(`SD WebUI 错误: ${String(err)}。确认 SD WebUI 以 --api 参数运行在 localhost:7860`);
        }
    }
    // ── DALL-E 3（需 OpenAI key）────────────────────────────────────────────────
    async dalle3(prompt, width, height) {
        const apiKey = config.providers.openai?.apiKey;
        if (!apiKey)
            return this.err('DALL-E 3 需要 OpenAI API key。免费替代方案：使用 engine=pollinations（默认）');
        // DALL-E 3 只支持固定尺寸
        const size = width > height ? '1792x1024' : width < height ? '1024x1792' : '1024x1024';
        try {
            const res = await fetch('https://api.openai.com/v1/images/generations', {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: 'dall-e-3', prompt, n: 1, size }),
                signal: AbortSignal.timeout(60_000),
            });
            if (!res.ok)
                return this.err(`DALL-E 3 错误: ${res.status}`);
            const data = await res.json();
            const url = data.data[0]?.url;
            if (!url)
                return this.err('DALL-E 3 未返回图片 URL');
            return this.text(`🎨 **文生图完成** · DALL-E 3 · ${size}\n\n${url}\n\n*Prompt: "${prompt}"*`);
        }
        catch (err) {
            return this.err(`DALL-E 3 错误: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=draw.js.map