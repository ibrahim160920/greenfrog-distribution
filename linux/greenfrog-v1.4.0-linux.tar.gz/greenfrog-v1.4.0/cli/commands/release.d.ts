export declare function manageRelease(opts: {
    bump?: 'none' | 'patch' | 'minor' | 'major';
}): Promise<void>;
//# sourceMappingURL=release.d.ts.map