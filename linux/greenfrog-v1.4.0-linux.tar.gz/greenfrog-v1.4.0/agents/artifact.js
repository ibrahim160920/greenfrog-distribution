/**
 * Artifact Protocol for GreenFrog P4.5.
 *
 * A TaskArtifact is a structured record of something a task produced:
 *   a file, a JSON result, a report, a config patch, etc.
 *
 * Artifacts serve as:
 *   1. Evidence anchors — acceptance checks can target artifact.path directly
 *   2. Downstream inputs — later tasks can reference a prior task's artifact
 *   3. Audit trail — system knows what each run actually produced
 *
 * Artifacts can come from:
 *   - auto_detected: extracted from resultSummary via pattern matching (best-effort)
 *   - agent_declared: agent explicitly emits a structured artifact block
 *
 * Written to metadata.artifacts[]. No DB migration required.
 *
 * Auto-detection is CONSERVATIVE:
 *   Only extract paths where there is clear action language nearby
 *   (created/wrote/generated/saved/output) AND a recognized file extension.
 *   Aim for zero false positives over maximum recall.
 */
// ── Type inference ────────────────────────────────────────────────────────────
const EXT_TYPE_MAP = {
    json: 'json',
    jsonl: 'json',
    yaml: 'config',
    yml: 'config',
    toml: 'config',
    ini: 'config',
    env: 'config',
    md: 'report',
    markdown: 'report',
    html: 'report',
    htm: 'report',
    pdf: 'report',
    rst: 'report',
    csv: 'dataset',
    tsv: 'dataset',
    patch: 'patch',
    diff: 'patch',
};
const EXT_MIME_MAP = {
    json: 'application/json',
    jsonl: 'application/jsonl',
    yaml: 'application/x-yaml',
    yml: 'application/x-yaml',
    md: 'text/markdown',
    html: 'text/html',
    pdf: 'application/pdf',
    csv: 'text/csv',
    tsv: 'text/tab-separated-values',
    patch: 'text/x-patch',
    diff: 'text/x-diff',
    txt: 'text/plain',
    log: 'text/plain',
};
function inferTypeFromExt(ext) {
    return EXT_TYPE_MAP[ext.toLowerCase()] ?? 'file';
}
function inferMimeFromExt(ext) {
    return EXT_MIME_MAP[ext.toLowerCase()];
}
function inferFormatFromExt(ext) {
    return ext.toLowerCase();
}
function extractFilename(path) {
    return path.replace(/\\/g, '/').split('/').pop() ?? path;
}
function extractExt(filename) {
    const parts = filename.split('.');
    return parts.length > 1 ? parts[parts.length - 1] : '';
}
// ── Auto-detection from resultSummary ─────────────────────────────────────────
/**
 * Recognized file extensions for output artifacts.
 * Conservative — avoids matching source code files (ts, js, etc.)
 * unless they appear in an explicit action context.
 */
const OUTPUT_EXTENSIONS = new Set([
    'json', 'jsonl', 'yaml', 'yml', 'toml', 'ini',
    'csv', 'tsv', 'txt', 'log', 'md', 'markdown',
    'html', 'htm', 'pdf',
    'patch', 'diff',
    'zip', 'tar', 'gz',
    'report', 'out', 'result',
]);
/**
 * Action words that indicate a file was produced (before the path).
 * Used to reduce false positives.
 */
const ACTION_PATTERN = /(?:created?|wrote|written|generated?|saved?|produced?|output(?:ted)?|wrote to|saved to|写入|生成|创建|保存|输出)\s+(?:file\s+|to\s+|at\s+)?/i;
/**
 * Detect file path patterns in text.
 * Returns matches with their surrounding context.
 * Includes backtick (`) as a valid path delimiter — agents commonly use `file.txt` syntax.
 */
const PATH_PATTERN = /(?:^|[\s(「"'`])((?:[A-Z]:[/\\][\w\-\.][\\\/\w\-\.]*|(?:\.\/|\/)?[\w\-\.]+(?:\/[\w\-\.]+)*)\.([a-z]{2,8}))(?:[\s)」"'`]|$)/gim;
/**
 * Extract artifacts from a resultSummary string.
 * Conservative: only extract paths with recognized extensions in action contexts.
 * Returns deduplicated list.
 */
export function detectArtifactsFromSummary(summary, sourceRunId) {
    if (!summary || summary.trim().length < 5)
        return [];
    const seen = new Set();
    const artifacts = [];
    const now = new Date().toISOString();
    // Strategy: scan for action + path patterns
    // We look for lines/sentences containing action words AND file paths
    const lines = summary.split(/[。\n]/);
    for (const line of lines) {
        const hasAction = ACTION_PATTERN.test(line);
        // Reset regex lastIndex
        PATH_PATTERN.lastIndex = 0;
        let match;
        while ((match = PATH_PATTERN.exec(line)) !== null) {
            const rawPath = match[1];
            const ext = match[2].toLowerCase();
            if (!OUTPUT_EXTENSIONS.has(ext))
                continue;
            if (seen.has(rawPath))
                continue;
            // For non-action lines, only accept if the path is very explicit
            // (backtick/quote delimited OR absolute path)
            const isExplicitlyQuoted = /[`「"']/.test(match[0].charAt(0)) || /[`」"']/.test(match[0].charAt(match[0].length - 1)) || match[0].includes('`');
            const isAbsolute = rawPath.startsWith('/') || /^[A-Z]:[\\\/]/.test(rawPath);
            if (!hasAction && !isExplicitlyQuoted && !isAbsolute)
                continue;
            seen.add(rawPath);
            const filename = extractFilename(rawPath);
            const type = inferTypeFromExt(ext);
            const mime = inferMimeFromExt(ext);
            artifacts.push({
                id: `auto:${rawPath.replace(/[^a-z0-9]/gi, '_').slice(0, 32)}`,
                type,
                name: filename,
                path: rawPath,
                mime,
                format: inferFormatFromExt(ext),
                summary: `Auto-detected: ${filename}`,
                producedAt: now,
                sourceRunId,
                detectionMethod: 'auto_detected',
            });
        }
    }
    return artifacts;
}
/**
 * Parse agent-declared artifacts from a structured block in resultSummary.
 *
 * Agents can emit a JSON block like:
 *   ```artifacts
 *   [{"type":"json","name":"result.json","path":"/tmp/result.json","summary":"..."}]
 *   ```
 *   or plain text with key:value pairs.
 *
 * Returns parsed artifacts marked as 'agent_declared'.
 */
export function parseAgentDeclaredArtifacts(summary, sourceRunId) {
    if (!summary)
        return [];
    // Look for ```artifacts ... ``` block
    const blockMatch = /```(?:artifacts?|产物)\s*\n([\s\S]*?)```/i.exec(summary);
    if (!blockMatch)
        return [];
    const now = new Date().toISOString();
    try {
        const parsed = JSON.parse(blockMatch[1].trim());
        if (!Array.isArray(parsed))
            return [];
        return parsed.filter((x) => x !== null && typeof x === 'object' && !Array.isArray(x)).map((item, i) => {
            const rawPath = typeof item['path'] === 'string' ? item['path'] : undefined;
            const ext = rawPath ? extractExt(extractFilename(rawPath)) : '';
            const rawType = typeof item['type'] === 'string' ? item['type'] : undefined;
            const inferredType = rawType && ['file', 'json', 'report', 'config', 'patch', 'dataset'].includes(rawType)
                ? rawType
                : inferTypeFromExt(ext);
            return {
                id: `decl:${i}:${(rawPath ?? String(i)).replace(/[^a-z0-9]/gi, '_').slice(0, 24)}`,
                type: inferredType,
                name: typeof item['name'] === 'string' ? item['name'] : rawPath ? extractFilename(rawPath) : `artifact_${i}`,
                path: rawPath,
                mime: typeof item['mime'] === 'string' ? item['mime'] : inferMimeFromExt(ext),
                format: typeof item['format'] === 'string' ? item['format'] : ext || undefined,
                summary: typeof item['summary'] === 'string' ? item['summary'] : undefined,
                producedAt: typeof item['producedAt'] === 'string' ? item['producedAt'] : now,
                sourceRunId,
                detectionMethod: 'agent_declared',
            };
        });
    }
    catch {
        return [];
    }
}
/**
 * Merge new artifacts into existing list.
 * Agent-declared always wins over auto-detected for the same path.
 * Deduplicates by path (or id if no path).
 */
export function mergeArtifacts(existing, incoming) {
    const byPath = new Map();
    // Add existing (lower priority)
    for (const a of existing) {
        const key = a.path ?? a.id;
        byPath.set(key, a);
    }
    // Add/overwrite with incoming (agent_declared overwrites auto_detected for same path)
    for (const a of incoming) {
        const key = a.path ?? a.id;
        const prev = byPath.get(key);
        if (!prev || a.detectionMethod === 'agent_declared' || prev.detectionMethod === 'auto_detected') {
            byPath.set(key, a);
        }
    }
    return Array.from(byPath.values());
}
//# sourceMappingURL=artifact.js.map