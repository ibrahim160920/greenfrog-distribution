/**
 * Context Assembly layer for GreenFrog P4.
 *
 * Assembles the three-tier context window for a task execution:
 *
 *   pinnedContext   — always present, high priority (workspace identity,
 *                     global constraints, agent persona)
 *   workingContext  — task-specific, medium priority (prior run results,
 *                     blocked reasons, dependency summaries)
 *   ephemeralContext — freshly fetched this run (current time, run ID)
 *
 * The assembled context is serialised into the worker prompt so the agent
 * has maximum relevant signal without reading unrelated memory chunks.
 */
// ── Core function ─────────────────────────────────────────────────────────────
/** Extract feedback snapshot from task metadata (written by execution loop) */
export function extractFeedback(m) {
    const pendingHint = typeof m['pendingHint'] === 'string' ? m['pendingHint'] : null;
    const nextSuggestedAction = typeof m['nextSuggestedAction'] === 'string' ? m['nextSuggestedAction'] : null;
    const confidence = typeof m['confidence'] === 'number' ? m['confidence'] : null;
    let latestObservation = null;
    if (m['latestObservation'] !== null && typeof m['latestObservation'] === 'object' && !Array.isArray(m['latestObservation'])) {
        const lo = m['latestObservation'];
        if (typeof lo['text'] === 'string') {
            latestObservation = { text: lo['text'], at: typeof lo['at'] === 'string' ? lo['at'] : '' };
        }
    }
    let latestError = null;
    if (m['latestError'] !== null && typeof m['latestError'] === 'object' && !Array.isArray(m['latestError'])) {
        const le = m['latestError'];
        if (typeof le['message'] === 'string') {
            latestError = {
                message: le['message'],
                errorClass: typeof le['errorClass'] === 'string' ? le['errorClass'] : 'unknown',
                at: typeof le['at'] === 'string' ? le['at'] : '',
            };
        }
    }
    return { pendingHint, latestObservation, latestError, nextSuggestedAction, confidence };
}
export function assembleTaskContext(input) {
    const { task, contract, dependencyResults, agentName, workspaceName, runId, previousResultHint, humanDecisionContext, effectiveMaxAttempts, relatedMemoryHints, } = input;
    const m = task.metadata ?? {};
    // ── Pinned context ──────────────────────────────────────────────────────────
    const pinnedLines = [];
    pinnedLines.push(`## Agent Identity`);
    if (agentName)
        pinnedLines.push(`You are **${agentName}**, an autonomous agent in the GreenFrog workspace.`);
    else
        pinnedLines.push(`You are an autonomous agent in the GreenFrog workspace.`);
    if (workspaceName)
        pinnedLines.push(`Workspace: ${workspaceName}`);
    pinnedLines.push(``, `## Operating Principles`);
    pinnedLines.push(`- Complete the task objective completely and report a concise resultSummary.`);
    pinnedLines.push(`- Do not ask for clarification unless you are genuinely blocked with no path forward.`);
    pinnedLines.push(`- If you encounter an error, attempt a reasonable recovery before giving up.`);
    pinnedLines.push(`- Mark the task done only when the done criteria are met (or there are none).`);
    if (contract.constraints.length > 0) {
        pinnedLines.push(``, `## Hard Constraints`);
        for (const c of contract.constraints)
            pinnedLines.push(`- ${c}`);
    }
    if (contract.allowedTools.length > 0) {
        pinnedLines.push(``, `## Allowed Tools`);
        pinnedLines.push(contract.allowedTools.join(', '));
    }
    // ── Working context ─────────────────────────────────────────────────────────
    const workingLines = [];
    // Prior run results (if this is a retry)
    const priorRunCount = typeof m['retryCount'] === 'number' ? m['retryCount'] : 0;
    const lastRunError = typeof m['lastRunError'] === 'string' ? m['lastRunError'] : null;
    const lastRunStatus = typeof m['lastRunStatus'] === 'string' ? m['lastRunStatus'] : null;
    if (priorRunCount > 0) {
        workingLines.push(`## Prior Attempt Context`);
        workingLines.push(`This is attempt **${priorRunCount + 1}** (${priorRunCount} prior attempt(s) failed).`);
        if (lastRunError)
            workingLines.push(`Last error: ${lastRunError}`);
        if (lastRunStatus)
            workingLines.push(`Last run status: ${lastRunStatus}`);
        workingLines.push(``);
    }
    // ── Feedback loop data (P4.1) — written by observe/evaluate/recover phases ─
    const fb = extractFeedback(m);
    if (fb.latestObservation?.text) {
        workingLines.push(`## Previous Observation`);
        workingLines.push(fb.latestObservation.text.slice(0, 300));
        workingLines.push(``);
    }
    if (fb.latestError) {
        workingLines.push(`## Previous Error`);
        workingLines.push(`Type: ${fb.latestError.errorClass}`);
        workingLines.push(`Message: ${fb.latestError.message.slice(0, 200)}`);
        workingLines.push(``);
    }
    if (fb.nextSuggestedAction) {
        workingLines.push(`## Suggested Approach for This Attempt`);
        workingLines.push(fb.nextSuggestedAction);
        workingLines.push(``);
    }
    if (fb.pendingHint) {
        workingLines.push(`## Recovery Hint (from previous attempt)`);
        workingLines.push(fb.pendingHint);
        workingLines.push(``);
    }
    // ── P4.2: Human decision context ────────────────────────────────────────────
    // If a human has previously reviewed this task, include their reasoning.
    // This is high-signal: a human's explicit decision beats any automated inference.
    if (humanDecisionContext) {
        workingLines.push(`## Human Decision Context`);
        workingLines.push(humanDecisionContext);
        workingLines.push(`Please take this into account when executing.`);
        workingLines.push(``);
    }
    // ── P4.2: Previous result from workspace shared memory ───────────────────────
    // If a previous successful run result exists in shared memory for this task,
    // include it as reference context (useful for retry-after-human-rejection).
    if (previousResultHint) {
        workingLines.push(`## Previous Run Result (reference)`);
        workingLines.push(previousResultHint.slice(0, 400));
        workingLines.push(`(This is what a previous attempt produced — you may build on or improve it.)`);
        workingLines.push(``);
    }
    // ── P4.2: Attempt budget awareness ──────────────────────────────────────────
    // Tell the agent how many attempts remain so it can calibrate effort.
    if (effectiveMaxAttempts !== undefined && priorRunCount > 0) {
        const remaining = Math.max(0, effectiveMaxAttempts - (priorRunCount + 1));
        if (remaining === 0) {
            workingLines.push(`> **注意：这是最后一次自动尝试机会。** 请不要请求澄清，直接输出最佳结果。`);
            workingLines.push(``);
        }
        else if (remaining === 1) {
            workingLines.push(`> 当前还剩 ${remaining} 次自动重试机会。请尽量在本次完成。`);
            workingLines.push(``);
        }
    }
    // Blocked / escalation reason (if task was previously stuck)
    const blockedReason = task.blockedReason ?? (typeof m['blockedReason'] === 'string' ? m['blockedReason'] : null);
    const escalationReason = task.escalationReason ?? (typeof m['escalationReason'] === 'string' ? m['escalationReason'] : null);
    if (blockedReason || escalationReason) {
        workingLines.push(`## Previous Blocker`);
        if (blockedReason)
            workingLines.push(`Blocked reason: ${blockedReason}`);
        if (escalationReason)
            workingLines.push(`Escalation reason: ${escalationReason}`);
        workingLines.push(`Please attempt to resolve or work around this.`);
        workingLines.push(``);
    }
    // Dependency results
    if (dependencyResults && dependencyResults.length > 0) {
        workingLines.push(`## Dependency Results (already completed)`);
        for (const dep of dependencyResults) {
            workingLines.push(`- **${dep.title}** (${dep.id}): ${dep.resultSummary ?? '(no summary)'}`);
        }
        workingLines.push(``);
    }
    // ── P4.3: Related workspace memory (first-run context strengthening) ────────
    // Recalled by keyword from shared memory at dispatch time. Provides relevant
    // prior work context without dumping the full memory store.
    if (relatedMemoryHints && relatedMemoryHints.length > 0) {
        workingLines.push(`## 相关工作区记忆（关键词召回）`);
        for (const hint of relatedMemoryHints.slice(0, 3)) {
            workingLines.push(`### ${hint.key}`);
            workingLines.push(hint.value.slice(0, 300));
        }
        workingLines.push(``);
    }
    // Task description as additional working context
    if (task.description && task.description.trim()) {
        workingLines.push(`## Task Description`);
        workingLines.push(task.description.trim());
        workingLines.push(``);
    }
    // Inputs from contract
    if (Object.keys(contract.inputs).length > 0) {
        workingLines.push(`## Task Inputs`);
        for (const [k, v] of Object.entries(contract.inputs)) {
            workingLines.push(`- **${k}:** ${JSON.stringify(v)}`);
        }
        workingLines.push(``);
    }
    // ── Ephemeral context ───────────────────────────────────────────────────────
    const ephemeralLines = [
        `## Execution Metadata`,
        `Run ID: ${runId}`,
        `Started at: ${new Date().toISOString()}`,
        `Task ID: ${task.id}`,
    ];
    // ── Summary ─────────────────────────────────────────────────────────────────
    const parts = [];
    if (priorRunCount > 0)
        parts.push(`retry=${priorRunCount}`);
    if (dependencyResults && dependencyResults.length > 0)
        parts.push(`deps=${dependencyResults.length}`);
    if (blockedReason || escalationReason)
        parts.push('has_blocker');
    if (fb.pendingHint)
        parts.push('hint');
    if (fb.latestObservation)
        parts.push('has_obs');
    if (fb.latestError)
        parts.push(`err=${fb.latestError.errorClass}`);
    if (humanDecisionContext)
        parts.push('human_ctx');
    if (previousResultHint)
        parts.push('prev_result');
    if (relatedMemoryHints && relatedMemoryHints.length > 0)
        parts.push(`mem=${relatedMemoryHints.length}`);
    const summary = parts.length > 0 ? `context[${parts.join(',')}]` : 'context[fresh]';
    return {
        pinnedContext: pinnedLines.join('\n'),
        workingContext: workingLines.join('\n'),
        ephemeralContext: ephemeralLines.join('\n'),
        summary,
    };
}
// ── Prompt rendering ──────────────────────────────────────────────────────────
/**
 * Combine all context tiers into a single worker prompt string.
 * Order: pinned → working → ephemeral → (caller appends contract)
 */
export function renderContextPrompt(ctx) {
    const sections = [];
    if (ctx.pinnedContext.trim())
        sections.push(ctx.pinnedContext.trim());
    if (ctx.workingContext.trim())
        sections.push(ctx.workingContext.trim());
    if (ctx.ephemeralContext.trim())
        sections.push(ctx.ephemeralContext.trim());
    return sections.join('\n\n');
}
//# sourceMappingURL=context_assembly.js.map