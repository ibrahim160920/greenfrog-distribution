/**
 * BM25 (Best Match 25) — industry-standard probabilistic ranking function.
 *
 * Significantly more accurate than plain TF-IDF:
 *  - Term-frequency saturation (k1 parameter) prevents high-frequency terms
 *    from dominating unrealistically.
 *  - Document-length normalisation (b parameter) prevents shorter documents
 *    from being artificially penalised.
 *
 * Used by Elasticsearch, Solr, Lucene, and SQLite FTS5 as the default scorer.
 *
 * No external dependencies — operates purely in memory.
 */
export interface BM25Document {
    id: string;
    text: string;
}
export interface ScoredDocument {
    id: string;
    score: number;
}
export declare class BM25Index {
    private docs;
    private tfMaps;
    private docLengths;
    private avgDocLength;
    private idf;
    private built;
    build(docs: BM25Document[]): void;
    /**
     * Score all documents against the query and return the top-k by BM25 score.
     * Adds a small substring-match bonus for exact phrase hits.
     */
    query(queryText: string, topK?: number): ScoredDocument[];
    /** Returns the number of indexed documents */
    get size(): number;
}
//# sourceMappingURL=bm25.d.ts.map