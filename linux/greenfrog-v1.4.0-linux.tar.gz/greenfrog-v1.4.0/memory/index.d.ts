export { MemoryStore, memoryStore, setMemoryStore } from './store.js';
export { BM25Index } from './bm25.js';
export { scheduleMemoryExtraction } from './extractor.js';
export { compressBehavioralRulesIfNeeded, COMPRESS_THRESHOLD } from './rule_compressor.js';
export { GLOBAL_RULE_LIBRARY_WORKSPACE_ID } from './constants.js';
export { resolveMemoryScope, setScopedMemoryForContext, getScopedMemoryForContext, getAllScopedMemoryForContext, deleteScopedMemoryForContext, searchScopedMemoryForContext, searchScopedSemanticForContext, } from './scoped.js';
export type { Entity } from '../utils/types.js';
import type { ChannelName, ConversationContext } from '../utils/types.js';
export declare function remember(userId: string, channel: ChannelName, key: string, value: string): Promise<void>;
export declare function recall(userId: string, channel: ChannelName, key: string): Promise<string | null>;
export declare function forget(userId: string, channel: ChannelName, key: string): Promise<boolean>;
export declare function allMemory(userId: string, channel: ChannelName): Promise<Record<string, string>>;
/**
 * Build a memory summary enriched with semantically relevant entries for
 * the current query.  Combines recency (up to 10 recent entries) with
 * semantic relevance (up to 5 TF-IDF hits for the query).
 *
 * Also injects:
 *   - Structured entity context (people, projects, tasks, events)
 *   - Pending tasks with deadlines (proactive reminder)
 */
export declare function buildContextualMemorySummary(userId: string, channel: ChannelName, query: string): Promise<string>;
export declare function buildContextualMemorySummaryForContext(ctx: Pick<ConversationContext, 'userId' | 'channel' | 'workspaceId' | 'agentId'>, query: string): Promise<string>;
//# sourceMappingURL=index.d.ts.map