import { Client, GatewayIntentBits, Partials, REST, Routes, SlashCommandBuilder, } from 'discord.js';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { config } from '../../config/index.js';
export class DiscordChannel extends BaseChannel {
    name = 'discord';
    client = null;
    _running = false;
    async start() {
        const cfg = config.channels.discord;
        if (!cfg?.enabled || !cfg.token) {
            this.log.info('Discord not configured, skipping');
            return;
        }
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.DirectMessages,
            ],
            partials: [Partials.Channel],
        });
        const allowedUsers = cfg.allowedUsers ?? [];
        const isAllowed = (userId) => {
            if (allowedUsers.length === 0)
                return true;
            return allowedUsers.includes(userId);
        };
        this.client.on('ready', async () => {
            this.log.info({ tag: this.client?.user?.tag }, 'Discord bot ready');
            this._running = true;
            if (cfg.clientId) {
                await this.registerCommands(cfg.token, cfg.clientId).catch((err) => {
                    this.log.warn({ err }, 'Failed to register slash commands');
                });
            }
        });
        this.client.on('messageCreate', async (discordMsg) => {
            if (discordMsg.author.bot)
                return;
            if (!isAllowed(discordMsg.author.id))
                return;
            const isMentioned = discordMsg.mentions.has(this.client.user);
            const isDM = discordMsg.channel.type === 1; // DM channel
            if (!isDM && !isMentioned)
                return;
            const text = discordMsg.content
                .replace(/<@!?\d+>/g, '')
                .trim();
            if (!text)
                return;
            const msg = {
                id: discordMsg.id,
                channel: 'discord',
                userId: discordMsg.author.id,
                username: discordMsg.author.username,
                chatId: discordMsg.channelId,
                chatName: 'name' in discordMsg.channel ? discordMsg.channel.name : 'DM',
                text,
                timestamp: discordMsg.createdAt,
                raw: discordMsg,
            };
            // sendTyping only exists on text-like channels — guard before calling
            if ('sendTyping' in discordMsg.channel) {
                await discordMsg.channel.sendTyping().catch(() => { });
            }
            await this.handleMessage(msg);
        });
        this.client.on('interactionCreate', async (interaction) => {
            if (!interaction.isChatInputCommand())
                return;
            const cmd = interaction;
            if (cmd.commandName === 'ask') {
                if (!isAllowed(interaction.user.id)) {
                    await cmd.reply({ content: '⛔ You are not authorized.', ephemeral: true });
                    return;
                }
                const question = cmd.options.getString('question', true);
                await cmd.deferReply();
                const msg = {
                    id: nanoid(),
                    channel: 'discord',
                    userId: interaction.user.id,
                    username: interaction.user.username,
                    chatId: interaction.channelId ?? interaction.user.id,
                    text: question,
                    timestamp: new Date(),
                };
                const response = await this.messageHandler?.(msg);
                if (response?.text) {
                    const chunks = response.text.match(/.{1,1900}/gs) ?? [response.text];
                    await cmd.editReply(chunks[0] ?? '…');
                    for (const chunk of chunks.slice(1)) {
                        await cmd.followUp(chunk);
                    }
                }
            }
            else if (cmd.commandName === 'clear') {
                const { memoryStore } = await import('../../memory/store.js');
                const sessionId = await memoryStore.getOrCreateSession(interaction.user.id, 'discord', interaction.channelId ?? interaction.user.id);
                await memoryStore.clearHistory(sessionId);
                await cmd.reply({ content: '🧹 Conversation history cleared!', ephemeral: true });
            }
        });
        this.client.on('error', (err) => {
            this.log.error({ err }, 'Discord client error');
        });
        await this.client.login(cfg.token);
    }
    async registerCommands(token, clientId) {
        const commands = [
            new SlashCommandBuilder()
                .setName('ask')
                .setDescription('Ask GreenFrog AI')
                .addStringOption((opt) => opt.setName('question').setDescription('Your question').setRequired(true)),
            new SlashCommandBuilder()
                .setName('clear')
                .setDescription('Clear conversation history'),
        ].map((c) => c.toJSON());
        const rest = new REST().setToken(token);
        await rest.put(Routes.applicationCommands(clientId), { body: commands });
        this.log.info('Discord slash commands registered');
    }
    async stop() {
        this.client?.destroy();
        this._running = false;
    }
    async send(message) {
        if (!this.client || !message.chatId)
            return;
        try {
            const channel = await this.client.channels.fetch(message.chatId);
            if (!channel || !('send' in channel))
                return;
            const text = message.text ?? '';
            const chunks = text.match(/.{1,1900}/gs) ?? [text];
            for (const chunk of chunks) {
                await channel.send({ content: chunk });
            }
        }
        catch (err) {
            this.log.error({ err }, 'Discord send error');
        }
    }
    isRunning() {
        return this._running;
    }
}
//# sourceMappingURL=index.js.map