import chalk from 'chalk';
import { join } from 'path';
import { homedir } from 'os';
import { config } from '../../config/index.js';
import { skillRegistry } from '../../skills/registry.js';
import { memoryStore } from '../../memory/store.js';
export async function showStatus() {
    console.log(chalk.bold('\n🐸 GreenFrog Status\n'));
    // System
    const uptime = process.uptime();
    const uptimeStr = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m ${Math.floor(uptime % 60)}s`;
    const mem = process.memoryUsage();
    const memMB = Math.round(mem.rss / 1024 / 1024);
    console.log(chalk.bold('  System:'));
    console.log(`    Uptime: ${uptimeStr}`);
    console.log(`    Memory: ${memMB}MB`);
    console.log(`    Node: ${process.version}`);
    // Configuration
    console.log(chalk.bold('\n  Configuration:'));
    console.log(`    Provider: ${chalk.cyan(config.defaultProvider)}`);
    console.log(`    Model: ${chalk.cyan(config.defaultModel)}`);
    console.log(`    Data dir: ${config.dataDir}`);
    // Skills
    const totalSkills = skillRegistry.list().length;
    console.log(chalk.bold('\n  Skills:'));
    console.log(`    Total: ${chalk.green(totalSkills.toString())} skills available`);
    // Channels
    const channels = config.channels;
    const enabledChannels = Object.entries(channels)
        .filter(([, v]) => v?.enabled)
        .map(([name]) => name);
    console.log(chalk.bold('\n  Channels configured:'));
    if (enabledChannels.length === 0) {
        console.log('    No channels configured. Run: greenfrog setup');
    }
    else {
        enabledChannels.forEach((ch) => console.log(`    ${chalk.green('✓')} ${ch}`));
    }
    // Jobs
    const jobs = await memoryStore.getJobs();
    const activeJobs = jobs.filter((j) => j.status === 'active');
    console.log(chalk.bold('\n  Scheduled Jobs:'));
    console.log(`    ${activeJobs.length} active, ${jobs.length} total`);
    // Gateway & Web UI
    const gw = config.gateway;
    const ui = config.webui;
    console.log(chalk.bold('\n  Access:'));
    console.log(`    Gateway WS:  ${chalk.cyan(`ws://${gw.host}:${gw.port}`)}`);
    if (ui.enabled) {
        console.log(`    Web UI:      ${chalk.cyan(`http://${ui.host}:${ui.port}`)}`);
    }
    const secretPreview = gw.secret.slice(0, 8) + '…' + gw.secret.slice(-4);
    console.log(`    Secret:      ${chalk.yellow(secretPreview)}  (full value in ${join(homedir(), '.greenfrog', 'config.yaml')})`);
    console.log();
}
//# sourceMappingURL=status.js.map