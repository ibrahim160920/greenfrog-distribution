export type EffectiveRole = 'admin' | 'user' | 'readonly' | 'deny';
export type GroupAssignableRole = Exclude<EffectiveRole, 'deny'>;
export interface RoleGroup {
    role: GroupAssignableRole;
    members: string[];
    externalGroups?: string[];
}
export interface RolesConfigLike {
    admin?: string[];
    user?: string[];
    readonly?: string[];
    groups?: Record<string, RoleGroup>;
    defaultRole?: EffectiveRole;
}
export declare const MAX_ROLE_GROUP_MEMBERS = 1000;
export declare const MAX_ROLE_GROUP_EXTERNALS = 100;
export declare function isValidRoleGroupId(groupId: string): boolean;
export declare function normalizeRoleGroupMembers(members: unknown): string[];
export declare function normalizeExternalGroups(groups: unknown): string[];
export declare function resolveRoleFromConfig(roles: RolesConfigLike | undefined, userId: string, channel: string, opts?: {
    externalGroups?: string[];
}): EffectiveRole;
//# sourceMappingURL=roles.d.ts.map