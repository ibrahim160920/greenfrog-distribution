/**
 * Behavioral Rule Compressor
 *
 * When a scope accumulates too many behavioral rules, the system prompt grows
 * unboundedly and dilutes reasoning quality.  This module uses a cheap LLM call
 * (default: whatever is configured, prefer a small/fast model) to deduplicate,
 * merge, and prune the rule set down to a manageable size.
 *
 * Design principles:
 *  - Fire-and-forget: compression runs in the background, never blocks responses
 *  - Conservative: only runs when count exceeds COMPRESS_THRESHOLD
 *  - Safe: if LLM call fails, the original rules are left unchanged
 *  - Traceable: compressed rules are tagged source='compressed'
 *  - Cooldown: prevents re-compression within COOLDOWN_MS of the last run
 */
import type { MemoryScope } from '../utils/types.js';
/** Compress when a scope exceeds this many rules. */
export declare const COMPRESS_THRESHOLD = 25;
export interface RuleCompressionResult {
    attempted: boolean;
    compressed: boolean;
    cooldownSkipped: boolean;
    before: number;
    after: number;
}
/**
 * Compress behavioral rules for a scope if the count exceeds COMPRESS_THRESHOLD.
 * Safe to call concurrently — duplicate triggers for the same scope are deduplicated
 * via the cooldown map.
 *
 * @param scope   The memory scope whose rules should be compressed
 * @param model   Optional model override (prefer a cheap/fast model like haiku)
 * @param provider Optional provider override
 */
export declare function compressBehavioralRulesIfNeeded(scope: MemoryScope, opts?: {
    model?: string | null;
    provider?: string | null;
}): Promise<RuleCompressionResult>;
//# sourceMappingURL=rule_compressor.d.ts.map