/**
 * first_boot.ts — Registration state machine.
 *
 * States:
 *   unregistered → generating → pending → submitted → enrolled
 *                                                   ↘ failed (retriable)
 *
 * Rules:
 *   - NO local-only mode: instances MUST register before normal operation
 *   - State is persisted to .greenfrog/identity/state.json after every transition
 *   - Failed state is recoverable via retryEnrollment()
 *   - Enrolled state is terminal (no re-enrollment without clearEnrollment())
 */
import type { EnrollmentState, EnrollmentStateRecord } from './types.js';
export interface FirstBootOptions {
    /** Mother-body enrollment endpoint URL. */
    enrollmentUrl: string;
    /** GreenFrog app version string. */
    appVersion: string;
    /** Override for .greenfrog root (used in tests). */
    baseDir?: string;
    /** Override fetch function (used in tests). */
    fetchFn?: (url: string, opts: RequestInit) => Promise<Response>;
    /** BCP-47 locale for i18n log messages (e.g. 'en', 'zh-CN'). Defaults to system locale. */
    locale?: string;
}
export interface FirstBootResult {
    ok: boolean;
    state: EnrollmentState;
    instanceId: string;
    enrollmentKey: string;
    error?: string;
}
/**
 * Run the first-boot enrollment flow end-to-end.
 *
 * 1. Load or create install record (generates enrollmentKey if first time)
 * 2. Transition: generating → pending
 * 3. POST to enrollmentUrl
 * 4. On success: save credential, transition → enrolled
 * 5. On failure: transition → failed
 *
 * If already enrolled, returns enrolled state immediately.
 * No-op if currently submitted (prevents double-submission).
 */
export declare function runFirstBoot(opts: FirstBootOptions): Promise<FirstBootResult>;
/**
 * Retry enrollment after a previous failure.
 * Resets state to 'pending' and re-runs the submission step.
 */
export declare function retryEnrollment(opts: FirstBootOptions): Promise<FirstBootResult>;
/** Return the current enrollment state record without modifying it. */
export declare function getEnrollmentState(baseDir?: string): EnrollmentStateRecord;
/**
 * Return true if this instance is fully enrolled and has a credential.
 * This is the gate for entering normal operation.
 */
export declare function isEnrolled(baseDir?: string): boolean;
/**
 * Clear all enrollment state and credentials.
 * Used only when re-enrollment is explicitly requested (e.g., support workflow).
 */
export declare function clearEnrollment(baseDir?: string): void;
//# sourceMappingURL=first_boot.d.ts.map