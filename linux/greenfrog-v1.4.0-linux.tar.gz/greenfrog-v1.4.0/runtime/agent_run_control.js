import { nanoid } from 'nanoid';
const activeRuns = new Map();
function cloneRunState(run) {
    return {
        runId: run.runId,
        userId: run.userId,
        channel: run.channel,
        label: run.label,
        taskId: run.taskId,
        workspaceId: run.workspaceId,
        agentId: run.agentId,
        startedAt: new Date(run.startedAt).toISOString(),
        cancelledAt: run.cancelledAt ? new Date(run.cancelledAt).toISOString() : null,
        cancellationReason: run.cancellationReason,
        cancellationPending: run.cancelledAt !== null,
        runningMs: Math.max(0, Date.now() - run.startedAt),
    };
}
export function startAgentRun(params) {
    const runId = params.runId?.trim() || nanoid();
    activeRuns.set(runId, {
        runId,
        userId: params.userId,
        channel: params.channel,
        label: params.label?.trim() || null,
        taskId: params.taskId?.trim() || null,
        workspaceId: params.workspaceId?.trim() || null,
        agentId: params.agentId?.trim() || null,
        startedAt: Date.now(),
        cancelledAt: null,
        cancellationReason: null,
    });
    let released = false;
    return {
        runId,
        release: () => {
            if (released)
                return;
            released = true;
            activeRuns.delete(runId);
        },
    };
}
export function cancelAgentRun(runId, reason) {
    const normalizedRunId = runId.trim();
    if (!normalizedRunId)
        return false;
    const run = activeRuns.get(normalizedRunId);
    if (!run)
        return false;
    if (run.cancelledAt !== null)
        return true;
    run.cancelledAt = Date.now();
    run.cancellationReason = reason?.trim() || 'Cancelled by operator';
    return true;
}
export function getAgentRun(runId) {
    const normalizedRunId = runId.trim();
    if (!normalizedRunId)
        return null;
    const run = activeRuns.get(normalizedRunId);
    return run ? cloneRunState(run) : null;
}
export function isAgentRunCancelled(runId) {
    const normalizedRunId = runId.trim();
    if (!normalizedRunId)
        return null;
    return activeRuns.get(normalizedRunId)?.cancellationReason ?? null;
}
/**
 * Cancel any active runs that have been running longer than thresholdMs.
 * Returns the number of runs that were newly cancelled.
 * Safe to call repeatedly — already-cancelled runs are skipped.
 */
export function cancelStuckRuns(thresholdMs) {
    const now = Date.now();
    let cancelled = 0;
    for (const run of activeRuns.values()) {
        if (run.cancelledAt === null && now - run.startedAt > thresholdMs) {
            run.cancelledAt = now;
            run.cancellationReason = `Auto-cancelled: run exceeded ${thresholdMs}ms limit`;
            cancelled++;
        }
    }
    return cancelled;
}
/**
 * Force-remove runs that have been in cancellation-pending state longer than
 * cancelledForMs.  Called by the stuck-run sweep in index.ts, after
 * cancelStuckRuns() has had time to signal the agent loop.
 *
 * This is the structural GC step that prevents stuck-cancelled runs from
 * accumulating in activeRuns indefinitely when the underlying async call
 * never returns.
 *
 * Returns the number of runs force-released.
 */
export function releaseStuckCancelledRuns(cancelledForMs) {
    const now = Date.now();
    let released = 0;
    for (const [runId, run] of activeRuns.entries()) {
        if (run.cancelledAt !== null && now - run.cancelledAt > cancelledForMs) {
            activeRuns.delete(runId);
            released++;
        }
    }
    return released;
}
export function getActiveAgentRunsOverview() {
    const runs = Array.from(activeRuns.values())
        .sort((a, b) => b.startedAt - a.startedAt)
        .map((run) => cloneRunState(run));
    return {
        activeRuns: runs.length,
        cancellationPending: runs.filter((run) => run.cancellationPending).length,
        runs,
    };
}
//# sourceMappingURL=agent_run_control.js.map