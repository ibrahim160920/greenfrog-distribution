import { BaseProvider } from './base.js';
import { ProviderError } from '../utils/errors.js';
export class OllamaProvider extends BaseProvider {
    name = 'ollama';
    defaultModel = 'llama3.2';
    baseUrl;
    model;
    constructor(baseUrl = 'http://localhost:11434', model) {
        super();
        this.baseUrl = baseUrl.replace(/\/$/, '');
        this.model = model ?? this.defaultModel;
    }
    /** Build the Ollama messages array from a ProviderRequest */
    buildMessages(request) {
        const messages = [];
        if (request.systemPrompt) {
            messages.push({ role: 'system', content: request.systemPrompt });
        }
        for (const m of request.messages) {
            if (m.toolResults && m.toolResults.length > 0) {
                // Ollama has no native tool_result turn — inline results as user text
                const resultText = m.toolResults
                    .map((r) => `[Tool: ${r.name}]\n${r.content}`)
                    .join('\n\n');
                messages.push({ role: 'user', content: resultText });
                continue;
            }
            messages.push({ role: m.role, content: m.content });
        }
        return messages;
    }
    /** Build the Ollama tools array from a ProviderRequest */
    buildTools(request) {
        return request.tools?.map((t) => ({
            type: 'function',
            function: {
                name: t.name,
                description: t.description,
                parameters: t.parameters,
            },
        }));
    }
    async chat(request) {
        const model = request.model ?? this.model;
        try {
            const ollamaSignal = request.signal ?? AbortSignal.timeout(120_000);
            const res = await fetch(`${this.baseUrl}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                signal: ollamaSignal,
                body: JSON.stringify({
                    model,
                    messages: this.buildMessages(request),
                    tools: this.buildTools(request),
                    stream: false,
                    options: {
                        temperature: request.temperature ?? 0.7,
                        num_predict: request.maxTokens ?? 4096,
                    },
                }),
            });
            if (!res.ok) {
                const errText = await res.text();
                throw new ProviderError(`Ollama error ${res.status}: ${errText}`);
            }
            const data = (await res.json());
            const msg = data.message;
            const toolCalls = (msg.tool_calls ?? []).map((tc, i) => ({
                id: `call_${i}`,
                name: tc.function.name,
                arguments: tc.function.arguments,
            }));
            return {
                content: msg.content,
                toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                usage: {
                    inputTokens: data.prompt_eval_count ?? 0,
                    outputTokens: data.eval_count ?? 0,
                },
                model: data.model,
            };
        }
        catch (err) {
            if (err instanceof ProviderError)
                throw err;
            throw new ProviderError(`Ollama connection error: ${String(err)}`);
        }
    }
    chatStream(request) {
        const model = request.model ?? this.model;
        const baseUrl = this.baseUrl;
        const messages = this.buildMessages(request);
        const tools = this.buildTools(request);
        // Bridge: textStream generator resolves this promise when done
        let resolveComplete;
        let rejectComplete;
        const completePromise = new Promise((res, rej) => {
            resolveComplete = res;
            rejectComplete = rej;
        });
        async function* textStream() {
            try {
                const streamSignal = request.signal ?? AbortSignal.timeout(120_000);
                const res = await fetch(`${baseUrl}/api/chat`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    signal: streamSignal,
                    body: JSON.stringify({
                        model,
                        messages,
                        tools,
                        stream: true,
                        options: {
                            temperature: request.temperature ?? 0.7,
                            num_predict: request.maxTokens ?? 4096,
                        },
                    }),
                });
                if (!res.ok) {
                    const errText = await res.text();
                    throw new ProviderError(`Ollama error ${res.status}: ${errText}`);
                }
                const reader = res.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';
                let fullContent = '';
                let finalChunk = null;
                // Read NDJSON stream line by line
                outer: while (true) {
                    const { done, value } = await reader.read();
                    if (done)
                        break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split('\n');
                    // Last element may be an incomplete line — keep it in buffer
                    buffer = lines.pop() ?? '';
                    for (const line of lines) {
                        if (!line.trim())
                            continue;
                        try {
                            const chunk = JSON.parse(line);
                            if (chunk.message?.content) {
                                fullContent += chunk.message.content;
                                yield chunk.message.content;
                            }
                            if (chunk.done) {
                                finalChunk = chunk;
                                break outer;
                            }
                        }
                        catch {
                            // Malformed JSON line — skip
                        }
                    }
                }
                // Flush any remaining buffered text
                if (buffer.trim()) {
                    try {
                        const chunk = JSON.parse(buffer);
                        if (chunk.message?.content) {
                            fullContent += chunk.message.content;
                            yield chunk.message.content;
                        }
                        if (chunk.done)
                            finalChunk = chunk;
                    }
                    catch { /* ignore */ }
                }
                // Build ProviderResponse from accumulated data
                const toolCalls = (finalChunk?.message?.tool_calls ?? []).map((tc, i) => ({
                    id: `call_${i}`,
                    name: tc.function.name,
                    arguments: tc.function.arguments,
                }));
                resolveComplete({
                    content: fullContent,
                    toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                    usage: {
                        inputTokens: finalChunk?.prompt_eval_count ?? 0,
                        outputTokens: finalChunk?.eval_count ?? 0,
                    },
                    model: finalChunk?.model ?? model,
                });
            }
            catch (err) {
                rejectComplete(err);
                if (err instanceof ProviderError)
                    throw err;
                throw new ProviderError(`Ollama stream error: ${String(err)}`);
            }
        }
        return {
            textStream: textStream(),
            complete: () => completePromise,
        };
    }
    async isAvailable() {
        try {
            const res = await fetch(`${this.baseUrl}/api/tags`, { signal: AbortSignal.timeout(5_000) });
            return res.ok;
        }
        catch {
            return false;
        }
    }
    async listModels() {
        try {
            const res = await fetch(`${this.baseUrl}/api/tags`, { signal: AbortSignal.timeout(5_000) });
            if (!res.ok)
                return [];
            const data = (await res.json());
            return data.models.map((m) => m.name);
        }
        catch {
            return [];
        }
    }
}
//# sourceMappingURL=ollama.js.map