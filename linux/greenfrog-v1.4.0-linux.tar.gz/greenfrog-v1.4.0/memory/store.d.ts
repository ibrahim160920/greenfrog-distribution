import type { IMemoryStore } from '../db/types.js';
import { createAgentStore } from './store_agent.js';
import { createBehavioralStore } from './store_behavioral.js';
import { createConversationStore } from './store_conversation.js';
import { createEntityStore } from './store_entity.js';
import { createInfraStore } from './store_infra.js';
import { createMemoryDomainStore } from './store_memory.js';
import { createOpsStore } from './store_ops.js';
import { createTeamStore } from './store_team.js';
type AgentStore = ReturnType<typeof createAgentStore>;
type BehavioralStore = ReturnType<typeof createBehavioralStore>;
type ConversationStore = ReturnType<typeof createConversationStore>;
type EntityStore = ReturnType<typeof createEntityStore>;
type InfraStore = ReturnType<typeof createInfraStore>;
type MemoryDomainStore = ReturnType<typeof createMemoryDomainStore>;
type OpsStore = ReturnType<typeof createOpsStore>;
type TeamStore = ReturnType<typeof createTeamStore>;
export declare class MemoryStore {
    private db;
    private lock;
    private readonly _agent;
    private readonly _behavioral;
    private readonly _conversation;
    private readonly _entity;
    private readonly _infra;
    private readonly _memory;
    private readonly _ops;
    private readonly _team;
    private readonly _ruleTracking;
    /**
     * L1 in-memory cache for rate limit hot path.
     * Eliminates SQLite I/O on repeated calls within the same window.
     * key -> { count, resetAt }
     */
    private _rlCache;
    /**
     * @param dbPath  Optional path override. Pass ':memory:' for in-memory SQLite
     *                (used by unit tests). Defaults to config.dataDir/memory.db.
     */
    constructor(dbPath?: string);
    /** No-op kept for backward compatibility with callers that await init(). */
    init(): Promise<void>;
    close(): Promise<void>;
    /**
     * Return all known users derived from sessions, ordered by most-recently active.
     * Used by the admin user-management API.
     */
    listUsers(): Array<{
        userId: string;
        channels: string[];
        lastActive: Date;
        messageCount: number;
    }>;
    /**
     * Delete all personal data for a user across every table.
     * Audit log entries are anonymised (`user_id = '[DELETED]'`) rather than
     * deleted so the security/compliance trail is preserved.
     *
     * Returns a summary of what was removed.
     */
    deleteUserData(userId: string): {
        tablesAffected: string[];
        rowsDeleted: number;
    };
    cleanup(): void;
}
export interface MemoryStore extends AgentStore, BehavioralStore, ConversationStore, EntityStore, InfraStore, MemoryDomainStore, OpsStore, TeamStore {
}
/**
 * Live-binding singleton that can be swapped at startup via `setMemoryStore()`
 * to point at a PostgresMemoryStore or any other `IMemoryStore` implementation.
 * All ESM importers of this binding will automatically see the new store.
 */
export declare let memoryStore: IMemoryStore;
/** Replace the backing store (call once during startPlatform before any requests). */
export declare function setMemoryStore(store: IMemoryStore): void;
export {};
//# sourceMappingURL=store.d.ts.map