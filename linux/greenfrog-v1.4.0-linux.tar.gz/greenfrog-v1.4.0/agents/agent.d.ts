import type { IncomingMessage, OutgoingMessage, AgentStreamEvent } from '../utils/types.js';
export declare class GreenFrogAgent {
    private systemPrompt;
    constructor();
    processMessage(msg: IncomingMessage): Promise<OutgoingMessage>;
    /**
     * Streaming version of processMessage.
     *
     * Yields AgentStreamEvents:
     *   - { type: 'token', text }  — individual text deltas from the model
     *   - { type: 'thinking', tool } — a tool is about to be executed
     *   - { type: 'done', response } — stream finished, full OutgoingMessage attached
     *   - { type: 'error', error }  — an error occurred
     */
    processMessageStream(msg: IncomingMessage): AsyncGenerator<AgentStreamEvent>;
    clearHistory(userId: string, channel: IncomingMessage['channel'], chatId: string): Promise<void>;
}
export declare const agent: GreenFrogAgent;
//# sourceMappingURL=agent.d.ts.map