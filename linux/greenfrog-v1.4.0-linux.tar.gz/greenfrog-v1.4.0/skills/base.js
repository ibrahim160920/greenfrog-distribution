export class BaseSkill {
    /** Convert to AI provider tool format */
    toProviderTool() {
        const { name, description, parameters } = this.definition;
        const properties = {};
        const required = [];
        for (const param of parameters) {
            properties[param.name] = {
                type: param.type,
                description: param.description,
                // Responses API requires array schemas to have an items field
                ...(param.type === 'array' ? { items: { type: 'string' } } : {}),
                ...(param.enum ? { enum: param.enum } : {}),
                ...(param.default !== undefined ? { default: param.default } : {}),
            };
            if (param.required)
                required.push(param.name);
        }
        return {
            name,
            description,
            parameters: {
                type: 'object',
                properties,
                ...(required.length > 0 ? { required } : {}),
            },
        };
    }
    ok(data, text) {
        return { success: true, data, text: text ?? JSON.stringify(data, null, 2) };
    }
    err(message) {
        return { success: false, error: message };
    }
    text(message) {
        return { success: true, text: message };
    }
}
//# sourceMappingURL=base.js.map