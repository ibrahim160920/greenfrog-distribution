/**
 * auto_hard_evidence.ts — Sprint M5 + Federated Sprint
 *
 * Wires task verification results into two paths:
 *
 *   Path 1 (M5): Local hard evidence
 *     task workspace rules → findUnitsByPayload() → recordHardEvidence()
 *     Updates the local capability_units.json store.
 *
 *   Path 2 (Federated Sprint): Instance federated upload
 *     Same eligible events → buildFederatedEvidenceEntry() → appendToInstanceUploadBundle()
 *     Appends to the local instance_upload_bundle.json (bundleType: 'instance_upload').
 *     This bundle is the uplink artifact — it must NOT be directly imported by any instance.
 *     It can only enter another instance after passing through mother-body aggregation.
 *
 * Gate (all three required for both paths):
 *   1. evalResult.pass === true
 *   2. evalResult.verificationMode === 'evidence_verified'  (real I/O checks passed)
 *   3. evalResult.acceptanceChecksPassed > 0                (at least one check confirmed)
 *
 * Skip semantics: safe to call unconditionally — never throws.
 */
import { type FederatedEvidenceEntry } from './federated_aggregate.js';
import type { EvaluateResult } from '../agents/evaluate.js';
import type { TeamTask } from '../utils/types.js';
export type AutoHardEvidenceSkipReason = 'task_not_passed' | 'not_evidence_verified' | 'no_checks_passed' | 'no_rules_found' | 'no_units_matched';
export interface AutoHardEvidenceResult {
    /** Whether the gate was open (eligible event) */
    eligible: boolean;
    /** Reason skipped — only set when eligible=false or matched=0 */
    skipReason?: AutoHardEvidenceSkipReason;
    /** How many behavioral rules were checked against capability units */
    rulesChecked: number;
    /** How many capability units were matched by payload */
    unitsMatched: number;
    /** How many recordHardEvidence() calls succeeded (local path) */
    evidenceRecorded: number;
    /** How many units advanced their promotion status as a result (local path) */
    unitsAdvanced: number;
    /**
     * How many evidence entries were appended to the instance upload bundle (federated path).
     * 0 = either not eligible or no units matched. Check skipReason for details.
     */
    federatedUploadCount: number;
}
/**
 * Append federated evidence entries to this instance's upload bundle.
 * Creates the bundle file (with correct bundleType: 'instance_upload' header) if it
 * does not yet exist. Safe to call repeatedly — idempotent per entry.
 *
 * The bundleType tag is the governance marker: any import path that calls
 * validateMotherApprovedBundle() will reject this file, ensuring it cannot
 * bypass the mother-body aggregation step.
 */
export declare function appendToInstanceUploadBundle(entries: FederatedEvidenceEntry[]): Promise<void>;
/**
 * Attempt to record automated hard evidence for all capability units whose
 * payload matches a behavioral rule active in the task's workspace.
 *
 * Also appends eligible evidence to the local instance upload bundle for
 * future mother-body federated aggregation.
 *
 * Safe to call unconditionally — never throws.
 */
export declare function recordAutoHardEvidenceForTask(task: TeamTask, evalResult: EvaluateResult, runId: string): Promise<AutoHardEvidenceResult>;
//# sourceMappingURL=auto_hard_evidence.d.ts.map