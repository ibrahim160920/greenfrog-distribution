export declare function manageUpgrade(opts: {
    apply?: boolean;
}): Promise<void>;
//# sourceMappingURL=upgrade.d.ts.map