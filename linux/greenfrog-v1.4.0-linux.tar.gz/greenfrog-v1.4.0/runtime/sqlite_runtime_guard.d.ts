export declare function detectLikelySqliteMultiProcessRuntime(env?: NodeJS.ProcessEnv, isClusterWorker?: boolean, dataDir?: string): {
    detected: boolean;
    reasons: string[];
};
export declare function assertSafeSqliteRuntime(params: {
    usingSqlite: boolean;
    env?: NodeJS.ProcessEnv;
    isClusterWorker?: boolean;
    dataDir?: string;
}): void;
//# sourceMappingURL=sqlite_runtime_guard.d.ts.map