import Database from 'better-sqlite3';
import type { ChannelName, MemoryEntry, MemoryHistoryEntry, MemoryScope } from '../utils/types.js';
export declare function createMemoryDomainStore(db: Database.Database): {
    setMemory(userId: string, channel: ChannelName, key: string, value: string, ttlDays?: number): void;
    getMemory(userId: string, channel: ChannelName, key: string): string | null;
    getAllMemory(userId: string, channel: ChannelName): Record<string, string>;
    deleteMemory(userId: string, channel: ChannelName, key: string): boolean;
    searchSemantic(userId: string, channel: ChannelName, query: string, limit?: number): MemoryEntry[];
    warmQueryEmbedding(query: string): Promise<void>;
    searchMemory(userId: string, channel: ChannelName, query: string, limit?: number): MemoryEntry[];
    getCorrectionCount(userId: string, channel: string, windowMs: number): number;
    setScopedMemory(scope: MemoryScope, key: string, value: string, ttlDays?: number): void;
    getScopedMemory(scope: MemoryScope, key: string): string | null;
    getAllScopedMemory(scope: MemoryScope): Record<string, string>;
    deleteScopedMemory(scope: MemoryScope, key: string): boolean;
    searchScopedSemantic(scope: MemoryScope, query: string, limit?: number): MemoryEntry[];
    searchScopedMemory(scope: MemoryScope, query: string, limit?: number): MemoryEntry[];
    getDueReminders(): Array<{
        userId: string;
        channel: string;
        key: string;
        value: string;
    }>;
    markReminderDone(userId: string, channel: string, key: string): void;
    recordMemoryChange(userId: string, channel: string, key: string, oldValue: string | null, newValue: string, source: "extraction" | "correction" | "manual"): void;
    recordScopedMemoryChange(scope: MemoryScope, key: string, oldValue: string | null, newValue: string, source: "extraction" | "correction" | "manual"): void;
    getMemoryHistory(userId: string, channel: string, limit?: number): MemoryHistoryEntry[];
    getScopedMemoryHistory(scope: MemoryScope, limit?: number): MemoryHistoryEntry[];
    rollbackMemory(userId: string, channel: ChannelName, historyId: string): boolean;
    rollbackScopedMemory(scope: MemoryScope, historyId: string): boolean;
};
//# sourceMappingURL=store_memory.d.ts.map