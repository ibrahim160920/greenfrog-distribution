/**
 * Lightweight TF-IDF implementation for semantic memory search.
 *
 * No external dependencies — operates purely on the in-memory document set.
 * Suitable for personal-scale corpora (hundreds to low thousands of entries).
 */
/** Tokenise a string into lowercase alphanumeric tokens */
function tokenise(text) {
    return text.toLowerCase().match(/[a-z0-9\u4e00-\u9fff]+/g) ?? [];
}
/** Term-frequency map for a single document */
function termFreq(tokens) {
    const tf = new Map();
    for (const t of tokens)
        tf.set(t, (tf.get(t) ?? 0) + 1);
    return tf;
}
export class TFIDFIndex {
    docs = [];
    tfMaps = [];
    idf = new Map();
    built = false;
    /** Add documents and (re)build the index */
    build(docs) {
        this.docs = docs;
        this.tfMaps = docs.map((d) => termFreq(tokenise(d.text)));
        this.idf = new Map();
        // IDF: log(N / df_t + 1) + 1  (smoothed to avoid zero division)
        const N = docs.length;
        if (N === 0) {
            this.built = true;
            return;
        }
        const df = new Map();
        for (const tf of this.tfMaps) {
            for (const term of tf.keys()) {
                df.set(term, (df.get(term) ?? 0) + 1);
            }
        }
        for (const [term, count] of df) {
            this.idf.set(term, Math.log(N / (count + 1)) + 1);
        }
        this.built = true;
    }
    /** TF-IDF vector for arbitrary text (uses corpus IDF) */
    vector(text) {
        const tf = termFreq(tokenise(text));
        const vec = new Map();
        for (const [term, freq] of tf) {
            const idf = this.idf.get(term) ?? 1;
            vec.set(term, (freq / (tf.size || 1)) * idf);
        }
        return vec;
    }
    /** Cosine similarity between two sparse vectors */
    cosine(a, b) {
        let dot = 0;
        let normA = 0;
        let normB = 0;
        for (const [term, va] of a) {
            normA += va * va;
            const vb = b.get(term) ?? 0;
            dot += va * vb;
        }
        for (const [, vb] of b)
            normB += vb * vb;
        const denom = Math.sqrt(normA) * Math.sqrt(normB);
        return denom === 0 ? 0 : dot / denom;
    }
    /**
     * Return the top-k most relevant document IDs for the given query.
     * Combines TF-IDF cosine similarity with exact substring match bonus.
     */
    query(queryText, topK = 5) {
        if (!this.built || this.docs.length === 0)
            return [];
        const queryVec = this.vector(queryText);
        const queryLower = queryText.toLowerCase();
        const scores = this.docs.map((doc, idx) => {
            const docVec = this.vector(doc.text);
            let score = this.cosine(queryVec, docVec);
            // Small bonus for substring match (rewards exact keyword hits)
            if (doc.text.toLowerCase().includes(queryLower))
                score += 0.15;
            return { id: doc.id, score };
        });
        return scores
            .filter((s) => s.score > 0)
            .sort((a, b) => b.score - a.score)
            .slice(0, topK);
    }
}
//# sourceMappingURL=tfidf.js.map