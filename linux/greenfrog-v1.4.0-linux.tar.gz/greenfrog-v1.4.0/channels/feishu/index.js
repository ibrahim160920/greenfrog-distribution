import { Client, WSClient, EventDispatcher } from '@larksuiteoapi/node-sdk';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { ChannelError } from '../../utils/errors.js';
import { config } from '../../config/index.js';
export class FeishuChannel extends BaseChannel {
    name = 'feishu';
    client = null;
    wsClient = null;
    _running = false;
    _reconnectTimer = null;
    _reconnectAttempts = 0;
    static MAX_RECONNECT_DELAY_MS = 60_000;
    async start() {
        const cfg = config.channels.feishu;
        if (!cfg?.enabled || !cfg.appId || !cfg.appSecret) {
            this.log.info('Feishu not configured, skipping');
            return;
        }
        await this.connect(cfg.appId, cfg.appSecret);
    }
    async connect(appId, appSecret) {
        const allowedUsers = config.channels.feishu?.allowedUsers ?? [];
        this.client = new Client({ appId, appSecret });
        const dispatcher = new EventDispatcher({})
            .register({
            'im.message.receive_v1': async (data) => {
                try {
                    const sender = data.sender;
                    const message = data.message;
                    const userId = sender?.sender_id?.open_id ?? sender?.sender_id?.union_id ?? 'unknown';
                    const chatId = message.chat_id;
                    if (allowedUsers.length > 0 && !allowedUsers.includes(userId)) {
                        this.log.debug({ userId }, 'Feishu: user not in allowedUsers, ignoring');
                        return;
                    }
                    if (message.message_type !== 'text')
                        return;
                    let text = '';
                    try {
                        const content = JSON.parse(message.content);
                        text = content.text ?? '';
                    }
                    catch {
                        text = message.content;
                    }
                    if (!text.trim())
                        return;
                    const msg = {
                        id: message.message_id ?? nanoid(),
                        channel: 'feishu',
                        userId,
                        chatId,
                        text: text.trim(),
                        timestamp: new Date(Number(message.create_time)),
                        raw: data,
                    };
                    await this.handleMessage(msg);
                }
                catch (err) {
                    this.log.error({ err }, 'Feishu: error handling message');
                }
            },
        });
        this.wsClient = new WSClient({ appId, appSecret });
        this.wsClient
            .start({ eventDispatcher: dispatcher })
            .then(() => {
            this.log.info('Feishu WebSocket connection closed');
            this._running = false;
            this.scheduleReconnect(appId, appSecret);
        })
            .catch((err) => {
            this.log.error({ err }, 'Feishu WebSocket error');
            this._running = false;
            this.scheduleReconnect(appId, appSecret);
        });
        this._running = true;
        this._reconnectAttempts = 0;
        this.log.info('Feishu channel started');
    }
    scheduleReconnect(appId, appSecret) {
        if (this._reconnectTimer)
            return;
        const delay = Math.min(1000 * Math.pow(2, this._reconnectAttempts), FeishuChannel.MAX_RECONNECT_DELAY_MS);
        this._reconnectAttempts++;
        this.log.info({ delay, attempt: this._reconnectAttempts }, 'Scheduling Feishu reconnect');
        this._reconnectTimer = setTimeout(async () => {
            this._reconnectTimer = null;
            try {
                await this.connect(appId, appSecret);
            }
            catch (err) {
                this.log.error({ err }, 'Feishu reconnect failed');
                this.scheduleReconnect(appId, appSecret);
            }
        }, delay);
    }
    async stop() {
        if (this._reconnectTimer) {
            clearTimeout(this._reconnectTimer);
            this._reconnectTimer = null;
        }
        try {
            this.wsClient?.close({ force: true });
        }
        catch { /* ignore */ }
        this._running = false;
        this.log.info('Feishu channel stopped');
    }
    async send(message) {
        if (!this.client || !message.chatId)
            return;
        try {
            const chunks = this.splitMessage(message.text ?? '', 4000);
            for (const chunk of chunks) {
                await this.client.im.message.create({
                    params: { receive_id_type: 'chat_id' },
                    data: {
                        receive_id: message.chatId,
                        msg_type: 'text',
                        content: JSON.stringify({ text: chunk }),
                    },
                });
            }
        }
        catch (err) {
            throw new ChannelError(`Feishu send error: ${String(err)}`, 'feishu');
        }
    }
    isRunning() {
        return this._running;
    }
    splitMessage(text, maxLen) {
        if (text.length <= maxLen)
            return [text];
        const chunks = [];
        let remaining = text;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, maxLen);
            const lastNewline = chunk.lastIndexOf('\n');
            if (lastNewline > maxLen / 2)
                chunk = remaining.slice(0, lastNewline);
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }
        return chunks;
    }
}
//# sourceMappingURL=index.js.map