import { BaseSkill } from './base.js';
import { memoryStore } from '../memory/store.js';
import { getAllScopedMemoryForContext, resolveMemoryScope } from '../memory/index.js';
import { runReflection, runScopedReflection } from '../memory/reflection.js';
export class ReflectSkill extends BaseSkill {
    definition = {
        name: 'reflect',
        description: 'Self-reflection and continuous learning from feedback, corrections, and repeated interaction patterns.',
        category: 'system',
        parameters: [
            {
                name: 'action',
                type: 'string',
                required: true,
                description: 'Action to perform',
                enum: ['run', 'status', 'rules', 'delete', 'reset'],
            },
            { name: 'rule', type: 'string', description: 'Rule text to delete when using the delete action' },
        ],
        examples: [
            'reflect run',
            'reflect status',
            'reflect rules',
        ],
    };
    async execute(params, ctx) {
        const action = params.action;
        const scope = resolveMemoryScope(ctx);
        switch (action) {
            case 'run':
                return this.runReflect(ctx, scope);
            case 'status':
                return this.showStatus(ctx, scope);
            case 'rules':
                return this.showRules(ctx, scope);
            case 'delete':
                return this.deleteRule(params, ctx, scope);
            case 'reset':
                return this.resetRules(ctx, scope);
            default:
                return this.err(`Unknown action: ${action}`);
        }
    }
    async runReflect(ctx, scope) {
        const result = scope
            ? await runScopedReflection(scope)
            : await runReflection(ctx.userId, ctx.channel);
        if (result.rulesAdded === 0 && result.rulesReinforced === 0) {
            return this.text(`Reflection complete.\n\n${result.summary}`);
        }
        const ruleLines = result.rules.map((rule) => `- [${rule.category}] ${rule.rule} (${rule.confidence}%)`).join('\n');
        return this.text(`Reflection complete.\n\n${result.summary}\n\n` +
            (result.rules.length > 0 ? `Updated rules:\n${ruleLines}` : ''));
    }
    async showStatus(ctx, scope) {
        const stats = scope
            ? await memoryStore.getScopedFeedbackStats(scope)
            : await memoryStore.getFeedbackStats(ctx.userId, ctx.channel);
        const rules = scope
            ? await memoryStore.getScopedBehavioralRules(scope, 0)
            : await memoryStore.getBehavioralRules(ctx.userId, ctx.channel, 0);
        const allMem = await getAllScopedMemoryForContext(ctx);
        const corrections = Object.keys(allMem).filter((key) => key.startsWith('correction:')).length;
        const satisfaction = stats.total > 0 ? Math.round((stats.positive / stats.total) * 100) : 0;
        const bar = (value, total, len = 20) => {
            const filled = total > 0 ? Math.round((value / total) * len) : 0;
            return `${'#'.repeat(filled)}${'-'.repeat(len - filled)}`;
        };
        return this.text(`Learning status\n\n` +
            `Interactions: ${stats.total}\n` +
            `Positive: ${stats.positive} ${bar(stats.positive, stats.total)}\n` +
            `Negative: ${stats.negative} ${bar(stats.negative, stats.total)}\n` +
            `Satisfaction: ${satisfaction}%\n` +
            `Rules: ${rules.length}\n` +
            `Corrections: ${corrections}\n` +
            `Maturity: ${this.maturityLevel(stats.total, rules.length)}`);
    }
    maturityLevel(totalInteractions, ruleCount) {
        const score = totalInteractions * 0.5 + ruleCount * 10;
        if (score < 20)
            return 'early';
        if (score < 100)
            return 'growing';
        if (score < 300)
            return 'mature';
        return 'expert';
    }
    async showRules(ctx, scope) {
        const rules = scope
            ? await memoryStore.getScopedBehavioralRules(scope, 0)
            : await memoryStore.getBehavioralRules(ctx.userId, ctx.channel, 0);
        if (rules.length === 0) {
            return this.text('No learned behavioral rules yet.');
        }
        const grouped = new Map();
        for (const rule of rules) {
            if (!grouped.has(rule.category))
                grouped.set(rule.category, []);
            grouped.get(rule.category).push(rule);
        }
        const sections = [];
        for (const [category, categoryRules] of grouped) {
            const lines = categoryRules.map((rule) => `- ${rule.rule} (${rule.confidence}% | ${rule.source} | evidence ${rule.evidenceCount})`);
            sections.push(`${category}\n${lines.join('\n')}`);
        }
        return this.text(`Learned behavioral rules (${rules.length})\n\n${sections.join('\n\n')}`);
    }
    async deleteRule(params, ctx, scope) {
        const rule = (params.rule ?? '').trim();
        if (!rule)
            return this.err('rule is required');
        const rules = scope
            ? await memoryStore.getScopedBehavioralRules(scope, 0)
            : await memoryStore.getBehavioralRules(ctx.userId, ctx.channel, 0);
        const match = rules.find((entry) => entry.rule.toLowerCase().includes(rule.toLowerCase()) ||
            rule.toLowerCase().includes(entry.rule.toLowerCase()));
        if (!match)
            return this.err(`No matching rule found: "${rule}"`);
        const deleted = scope
            ? await memoryStore.deleteScopedBehavioralRule(scope, match.rule)
            : await memoryStore.deleteBehavioralRule(ctx.userId, ctx.channel, match.rule);
        if (!deleted)
            return this.err('Delete failed');
        return this.text(`Deleted rule: "${match.rule}"`);
    }
    async resetRules(ctx, scope) {
        const rules = scope
            ? await memoryStore.getScopedBehavioralRules(scope, 0)
            : await memoryStore.getBehavioralRules(ctx.userId, ctx.channel, 0);
        let deleted = 0;
        for (const rule of rules) {
            const ok = scope
                ? await memoryStore.deleteScopedBehavioralRule(scope, rule.rule)
                : await memoryStore.deleteBehavioralRule(ctx.userId, ctx.channel, rule.rule);
            if (ok)
                deleted++;
        }
        return this.text(`Cleared ${deleted} behavioral rules.`);
    }
}
//# sourceMappingURL=reflect_scoped.js.map