export interface SourceRepoCodeGenerationConfig {
    enabled: boolean;
    repoPath: string;
    lookbackDays: number;
    maxAuditEntries: number;
    maxCandidates: number;
    maxEvidencePerCandidate: number;
    maxFileContextChars: number;
    minEvidenceCount: number;
    minFailureCount: number;
    minSuccessCount: number;
    skills: string[];
    provider?: string;
    model?: string;
}
export interface SourceRepoCodeGenerationResult {
    generated: number;
    consideredFiles: number;
    candidateIds: string[];
    skippedReason: string | null;
}
export declare function generateSourceRepoCodeCandidates(partial?: Partial<SourceRepoCodeGenerationConfig>): Promise<SourceRepoCodeGenerationResult>;
//# sourceMappingURL=source_repo_code_generator.d.ts.map