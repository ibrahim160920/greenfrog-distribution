import { Command } from 'commander';
import { randomBytes } from 'crypto';
import chalk from 'chalk';
import { createLogger } from '../utils/logger.js';
const log = createLogger('cli');
export function createCLI() {
    const program = new Command();
    program
        .name('greenfrog')
        .description('🐸 GreenFrog - Your local-first personal AI Agent platform')
        .version('1.0.0');
    // ── start command ─────────────────────────────────────────────────────────
    program
        .command('start')
        .description('Start the GreenFrog agent platform')
        .option('-d, --debug', 'Enable debug logging')
        .option('--no-web', 'Disable web UI')
        .option('--no-gateway', 'Disable WebSocket gateway')
        .action(async (opts) => {
        if (opts.debug)
            process.env.LOG_LEVEL = 'debug';
        const { startPlatform } = await import('../index.js');
        await startPlatform({
            webEnabled: opts.web !== false,
            gatewayEnabled: opts.gateway !== false,
        });
    });
    // ── setup command ─────────────────────────────────────────────────────────
    program
        .command('setup')
        .description('Interactive setup wizard')
        .action(async () => {
        const { runSetupWizard } = await import('./commands/setup.js');
        await runSetupWizard();
    });
    // ── send command ──────────────────────────────────────────────────────────
    program
        .command('send <message>')
        .description('Send a message to GreenFrog and get a response')
        .option('-c, --channel <channel>', 'Channel to use', 'web')
        .option('-j, --json', 'Output as JSON')
        .action(async (message, opts) => {
        const { sendMessage } = await import('./commands/send.js');
        await sendMessage(message, opts);
    });
    // ── skills command ─────────────────────────────────────────────────────────
    program
        .command('skills')
        .description('List and manage skills')
        .option('-c, --category <category>', 'Filter by category')
        .action(async (opts) => {
        const { listSkills } = await import('./commands/skills.js');
        await listSkills(opts);
    });
    // ── jobs command ──────────────────────────────────────────────────────────
    program
        .command('jobs')
        .description('Manage scheduled jobs')
        .option('-l, --list', 'List all jobs')
        .option('-d, --delete <id>', 'Delete a job')
        .action(async (opts) => {
        const { manageJobs } = await import('./commands/jobs.js');
        await manageJobs(opts);
    });
    // ── config command ────────────────────────────────────────────────────────
    program
        .command('config')
        .description('View or update configuration')
        .option('-s, --show', 'Show current config')
        .option('--set <key=value>', 'Set a config value')
        .action(async (opts) => {
        const { manageConfig } = await import('./commands/config.js');
        await manageConfig(opts);
    });
    // ── status command ────────────────────────────────────────────────────────
    program
        .command('status')
        .description('Show platform status')
        .action(async () => {
        const { showStatus } = await import('./commands/status.js');
        await showStatus();
    });
    program
        .command('release')
        .description('Generate release metadata, tags, and GitHub release artifacts for the source repository')
        .option('-b, --bump <type>', 'Semver bump: none|patch|minor|major')
        .action(async (opts) => {
        const { manageRelease } = await import('./commands/release.js');
        await manageRelease(opts);
    });
    program
        .command('upgrade')
        .description('Check for or apply project upgrades from the source repository')
        .option('-a, --apply', 'Apply the available upgrade')
        .action(async (opts) => {
        const { manageUpgrade } = await import('./commands/upgrade.js');
        await manageUpgrade(opts);
    });
    program
        .command('record-recovery-signal')
        .description('Record an internal project-evolution recovery signal for CI or private ops automation')
        .requiredOption('--kind <kind>', 'Signal kind: smoke|e2e|capacity')
        .requiredOption('--title <title>', 'Human-readable signal title')
        .requiredOption('--summary <summary>', 'Short verification summary')
        .requiredOption('--source <source>', 'Signal source identifier, for example github-actions or ci-smoke')
        .option('--repo <path>', 'Repository path (defaults to configured evolution repo or cwd)')
        .option('--priority <priority>', 'Signal priority: critical|high|medium', 'high')
        .option('--details <json>', 'Additional JSON object details')
        .option('--failed', 'Record the signal as failed instead of passed')
        .option('--id <id>', 'Optional stable signal id')
        .action(async (opts) => {
        const { recordRecoverySignalCommand } = await import('./commands/recovery_signal.js');
        await recordRecoverySignalCommand({
            repo: opts.repo,
            kind: opts.kind,
            priority: opts.priority,
            title: opts.title,
            summary: opts.summary,
            source: opts.source,
            details: opts.details,
            passed: !opts.failed,
            id: opts.id,
        });
    });
    // ── rotate-secret command ─────────────────────────────────────────────────
    program
        .command('rotate-secret')
        .description('Generate a new random gateway/WS secret and save it to config')
        .action(async () => {
        const { configManager } = await import('../config/index.js');
        const newSecret = randomBytes(32).toString('hex');
        configManager.set({ gateway: { ...configManager.get().gateway, secret: newSecret } });
        console.log(chalk.green('Gateway secret rotated successfully.'));
        console.log(chalk.cyan('New secret:'), newSecret);
        console.log(chalk.yellow('Update your Web UI / API clients to use the new secret.'));
        console.log(chalk.yellow('Old sessions will be disconnected on next restart.'));
    });
    // ── clear command ─────────────────────────────────────────────────────────
    program
        .command('clear')
        .description('Clear conversation history')
        .option('-u, --user <userId>', 'User ID', 'default-user')
        .action(async (opts) => {
        const { memoryStore } = await import('../memory/store.js');
        const sessionId = await memoryStore.getOrCreateSession(opts.user, 'web', 'cli');
        await memoryStore.clearHistory(sessionId);
        console.log(chalk.green('✅ Conversation history cleared'));
    });
    // ── backup command ────────────────────────────────────────────────────────
    program
        .command('backup [output]')
        .description('Back up the database and config to a .tar.gz archive')
        .action(async (output) => {
        const { backupData } = await import('./commands/backup.js');
        await backupData(output);
    });
    // ── restore command ───────────────────────────────────────────────────────
    program
        .command('restore <archive>')
        .description('Restore database and config from a backup archive')
        .option('-f, --force', 'Overwrite existing data without prompting')
        .action(async (archive, opts) => {
        const { restoreData } = await import('./commands/backup.js');
        await restoreData(archive, opts);
    });
    return program;
}
//# sourceMappingURL=index.js.map