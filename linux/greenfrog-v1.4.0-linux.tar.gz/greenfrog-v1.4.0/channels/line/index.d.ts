import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class LineChannel extends BaseChannel {
    readonly name: "line";
    private client;
    private server;
    private _running;
    private readonly tokenCache;
    start(): Promise<void>;
    stop(): Promise<void>;
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
    private splitMessage;
}
//# sourceMappingURL=index.d.ts.map