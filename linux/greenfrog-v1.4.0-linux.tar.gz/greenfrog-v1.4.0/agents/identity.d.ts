import type { AgentDefinition, ConversationContext, IncomingMessage } from '../utils/types.js';
export declare function resolveConversationAgentIdentity(msg: IncomingMessage): Promise<{
    workspaceId?: string;
    agentId?: string;
    agent?: AgentDefinition;
}>;
export declare function deriveSpecialistContext(ctx: ConversationContext, specialistName: string): ConversationContext;
//# sourceMappingURL=identity.d.ts.map