import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class WebFetchSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
}
//# sourceMappingURL=web_fetch.d.ts.map