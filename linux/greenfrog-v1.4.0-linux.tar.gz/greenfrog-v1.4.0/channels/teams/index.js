import express from 'express';
import { CloudAdapter, ConfigurationBotFrameworkAuthentication, TurnContext } from 'botbuilder';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { ChannelError } from '../../utils/errors.js';
import { config } from '../../config/index.js';
export class TeamsChannel extends BaseChannel {
    name = 'teams';
    adapter = null;
    server = null;
    _running = false;
    _appId = '';
    // Map chatId → ConversationReference for proactive send
    convRefs = new Map();
    async start() {
        const cfg = config.channels.teams;
        if (!cfg?.enabled || !cfg.appId || !cfg.appPassword) {
            this.log.info('Teams not configured, skipping');
            return;
        }
        this._appId = cfg.appId;
        const port = cfg.port ?? 3979;
        const allowedUsers = cfg.allowedUsers ?? [];
        const auth = new ConfigurationBotFrameworkAuthentication({
            MicrosoftAppId: cfg.appId,
            MicrosoftAppPassword: cfg.appPassword,
        });
        this.adapter = new CloudAdapter(auth);
        this.adapter.onTurnError = async (context, err) => {
            this.log.error({ err }, 'Teams adapter error');
            await context.sendActivity('⚠️ An error occurred.');
        };
        const app = express();
        app.use(express.json());
        app.post('/api/messages', async (req, res) => {
            await this.adapter.process(req, res, async (context) => {
                if (context.activity.type !== 'message')
                    return;
                const userId = context.activity.from?.id ?? 'unknown';
                const chatId = context.activity.conversation?.id ?? nanoid();
                if (allowedUsers.length > 0 && !allowedUsers.includes(userId)) {
                    await context.sendActivity('⛔ You are not authorized to use this bot.');
                    return;
                }
                // Store conversation reference for proactive sends
                this.convRefs.set(chatId, TurnContext.getConversationReference(context.activity));
                const text = (context.activity.text ?? '').trim();
                if (!text)
                    return;
                const msg = {
                    id: context.activity.id ?? nanoid(),
                    channel: 'teams',
                    userId,
                    username: context.activity.from?.name,
                    chatId,
                    text,
                    timestamp: new Date(context.activity.timestamp ?? Date.now()),
                    raw: context.activity,
                };
                await this.handleMessage(msg);
            });
        });
        await new Promise((resolve, reject) => {
            this.server = app.listen(port, () => {
                this.log.info({ port }, 'Teams webhook listener started');
                resolve();
            });
            this.server.on('error', reject);
        });
        this._running = true;
        this.log.info({ port }, 'Teams channel started');
    }
    async stop() {
        await new Promise((resolve) => {
            if (this.server) {
                this.server.close(() => resolve());
            }
            else {
                resolve();
            }
        });
        this._running = false;
        this.log.info('Teams channel stopped');
    }
    async send(message) {
        if (!this.adapter || !message.chatId)
            return;
        const ref = this.convRefs.get(message.chatId);
        if (!ref) {
            this.log.warn({ chatId: message.chatId }, 'Teams: no ConversationReference for chatId');
            return;
        }
        const chunks = this.splitMessage(message.text ?? '', 4000);
        for (const chunk of chunks) {
            try {
                await this.adapter.continueConversationAsync(this._appId, ref, async (context) => {
                    await context.sendActivity(chunk);
                });
            }
            catch (err) {
                throw new ChannelError(`Teams send error: ${String(err)}`, 'teams');
            }
        }
    }
    isRunning() {
        return this._running;
    }
    splitMessage(text, maxLen) {
        if (text.length <= maxLen)
            return [text];
        const chunks = [];
        let remaining = text;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, maxLen);
            const lastNewline = chunk.lastIndexOf('\n');
            if (lastNewline > maxLen / 2)
                chunk = remaining.slice(0, lastNewline);
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }
        return chunks;
    }
}
//# sourceMappingURL=index.js.map