import type { ChannelName, MemoryScope } from '../utils/types.js';
export declare const INJECTION_PATTERNS: RegExp[];
export declare function sanitizeExtractedValue(value: string): string;
export declare function isValidFactValue(value: string): boolean;
/** Pending facts for high-impact key protection (requires 2+ turns to overwrite) */
export declare const pendingFacts: Map<string, {
    value: string;
    count: number;
    firstSeen: number;
}>;
export declare function shouldPersistHighImpactFact(userId: string, channel: string, key: string, value: string, memoryScope?: MemoryScope): Promise<boolean>;
/**
 * Checks the current user message against stored memory facts.
 * If a stored fact directly contradicts what the user just said,
 * it is automatically rolled back (deleted or reverted to previous value).
 *
 * This runs fire-and-forget after every turn, before extraction.
 */
export declare function detectAndRollbackContradictions(userId: string, channel: ChannelName, userMessage: string, memoryScope?: MemoryScope): Promise<void>;
/**
 * Fire-and-forget entry point with backpressure control.
 *
 * @param userId           User identifier
 * @param channel          Channel name
 * @param userMessage      The user's message in this turn
 * @param assistantResponse The AI's response in this turn
 * @param previousAiMessage The AI's response in the PREVIOUS turn (for correction context)
 */
export declare function scheduleMemoryExtraction(userId: string, channel: ChannelName, userMessage: string, assistantResponse: string, previousAiMessage?: string, sessionId?: string, memoryScope?: MemoryScope): void;
export declare function runExtraction(userId: string, channel: ChannelName, userMessage: string, assistantResponse: string, previousAiMessage?: string, memoryScope?: MemoryScope): Promise<void>;
/**
 * Called after each tool execution in the agent loop.
 * Checks whether the tool result contradicts any stored memory facts.
 * Rolls back contradicted facts immediately (fire-and-forget safe to await).
 */
export declare function checkToolResultVsMemory(userId: string, channel: ChannelName, toolName: string, toolResult: string, memoryScope?: MemoryScope): Promise<void>;
/**
 * Audits the agent's final reply for hallucinated user facts.
 * If a hallucinated fact was somehow persisted to memory, it is rolled back.
 * Runs fire-and-forget after the reply is sent.
 */
export declare function auditReplyForHallucinations(userId: string, channel: ChannelName, agentReply: string, memoryScope?: MemoryScope): Promise<void>;
//# sourceMappingURL=extractor.d.ts.map