import { providerRegistry } from '../providers/index.js';
import { memoryStore } from './store.js';
import { createLogger } from '../utils/logger.js';
const log = createLogger('memory:success-reflection');
const SUCCESS_REFLECTION_SYSTEM = `You are extracting a best practice from a successfully completed AI agent task.
The agent produced output that was accepted. Extract one actionable best practice that contributed to this success.

Output ONLY JSON: {"rule":"concise imperative instruction (max 120 chars)","category":"style|format|content|tone|workflow","confidence":50-75}

Rules:
- Extract what made THIS task succeed specifically — not generic advice like "do good work"
- If nothing specific is evident from the result, output {}
- Use "workflow" for process/reasoning that worked, "content" for accuracy/depth, "style"/"format" for output quality
- Confidence range is intentionally lower than challenge rules — one success is weaker evidence than a peer challenge`;
export async function runSuccessReflectionSafe(params) {
    if (!params.completedAgentId || !params.taskResult.trim())
        return null;
    try {
        return await runSuccessReflection(params);
    }
    catch (err) {
        log.warn({ err: String(err), agentId: params.completedAgentId }, 'Success reflection failed');
        return null;
    }
}
async function runSuccessReflection(params) {
    const prompt = [
        `Task: ${params.taskTitle}`,
        params.taskDescription ? `Description: ${params.taskDescription.slice(0, 300)}` : null,
        `Agent output (accepted):\n${params.taskResult.slice(0, 500)}`,
        '\nWhat best practice made this task succeed?',
    ].filter(Boolean).join('\n\n');
    const res = await providerRegistry.chatWithFallback({
        messages: [{ role: 'user', content: prompt }],
        systemPrompt: SUCCESS_REFLECTION_SYSTEM,
        maxTokens: 200,
        temperature: 0.3,
        ...(params.model ? { model: params.model } : {}),
    }, params.provider ?? undefined);
    const match = (res.content ?? '').match(/\{[\s\S]*\}/);
    if (!match)
        return null;
    const parsed = JSON.parse(match[0]);
    const rule = typeof parsed.rule === 'string' ? parsed.rule.trim().slice(0, 120) : '';
    const category = typeof parsed.category === 'string' ? parsed.category : '';
    const validCategories = new Set(['style', 'format', 'content', 'tone', 'workflow']);
    if (!rule || !validCategories.has(category))
        return null;
    // Confidence is lower for success rules — single positive example is weaker evidence than a peer rejection
    const confidence = Math.min(75, Math.max(50, typeof parsed.confidence === 'number' ? parsed.confidence : 60));
    // Write to workspace scope — the whole team learns from this agent's success
    if (params.propagateToTeam !== false) {
        const teamScope = {
            userId: params.userId,
            channel: params.channel,
            workspaceId: params.workspaceId,
        };
        memoryStore.upsertScopedBehavioralRule(teamScope, { rule, category, confidence, source: 'success' });
        log.info({ workspaceId: params.workspaceId, rule }, 'Success reflection: best practice written to workspace');
    }
    // Also reinforce the completing agent individually (positive feedback loop)
    const agentScope = {
        userId: params.userId,
        channel: params.channel,
        workspaceId: params.workspaceId,
        agentId: params.completedAgentId,
    };
    memoryStore.upsertScopedBehavioralRule(agentScope, {
        rule,
        category,
        confidence: Math.min(75, confidence + 5),
        source: 'success_agent',
    });
    log.info({ workspaceId: params.workspaceId, agentId: params.completedAgentId, rule }, 'Success reflection: best practice reinforced on completing agent');
    return { rule, category, confidence };
}
//# sourceMappingURL=success_reflection.js.map