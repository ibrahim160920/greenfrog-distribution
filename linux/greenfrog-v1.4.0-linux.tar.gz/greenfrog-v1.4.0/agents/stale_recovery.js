/**
 * Stale Task Recovery for GreenFrog P4.2.
 *
 * Detects and recovers tasks that are stuck in `in_progress` due to:
 *   - Process crash / restart mid-execution
 *   - Synchronous loop timeout (runDispatchLoop hung)
 *   - Network failure that never triggered the catch block
 *
 * Design:
 *   - A task is "stale" if: status=in_progress AND lastRunAt older than
 *     STALE_THRESHOLD_MS AND currentRunId is set (meaning a run was started
 *     but never completed the cleanup path).
 *   - Recovery: reset to queued state (claimed/open), set executionPhase=
 *     'interrupted', write lastRunStatus='interrupted' so the next run's
 *     context assembly can inject a "previous attempt was interrupted" hint.
 *   - Called at startup and optionally on a periodic schedule.
 *
 * Hardening principle:
 *   System must never leave tasks in semantically ambiguous in_progress state.
 *   A stale task is better reset to queued than left hanging indefinitely.
 */
import { memoryStore } from '../memory/store.js';
import { createLogger } from '../utils/logger.js';
const logger = createLogger('stale-recovery');
/** A task is considered stale if it has been in_progress longer than this */
export const STALE_THRESHOLD_MS = 30 * 60 * 1000; // 30 minutes
/**
 * Detect tasks stuck in `in_progress` past the stale threshold and reset them
 * to their queued state so they can be re-dispatched.
 *
 * Returns the number of tasks recovered and diagnostic details.
 */
export async function detectAndRecoverStaleTasks() {
    let inProgressTasks;
    try {
        inProgressTasks = await memoryStore.listTeamTasks({ status: 'in_progress' });
    }
    catch (err) {
        logger.warn({ err }, '[stale-recovery] Could not list in_progress tasks');
        return { recovered: 0, details: [] };
    }
    const now = Date.now();
    let recovered = 0;
    const details = [];
    for (const task of inProgressTasks) {
        const m = task.metadata ?? {};
        // Only consider tasks that have a currentRunId — meaning a run was started
        const currentRunId = typeof m['currentRunId'] === 'string' ? m['currentRunId'] : null;
        if (!currentRunId)
            continue;
        // Check age from lastRunAt
        const lastRunAt = typeof m['lastRunAt'] === 'string'
            ? new Date(m['lastRunAt']).getTime()
            : null;
        if (!lastRunAt)
            continue;
        const ageMs = now - lastRunAt;
        if (ageMs < STALE_THRESHOLD_MS)
            continue;
        // ── This task is stale ────────────────────────────────────────────────────
        const ageMin = Math.floor(ageMs / 60000);
        const interruptReason = `执行中断：任务在 in_progress 状态已超 ${ageMin} 分钟（运行 ID: ${currentRunId.slice(0, 24)}...）`;
        // P4.3: recovery hint wording depends on recoveryMode
        const recoveryMode = m['recoveryMode'] === 'resumable' ? 'resumable' : 'restartable';
        // Reset to queued — assigned agent keeps its assignment
        const resetStatus = task.assignedAgentId ? 'claimed' : 'open';
        try {
            await memoryStore.updateTeamTask(task.id, {
                status: resetStatus,
                blockedReason: null,
                escalationStatus: 'none',
                escalationReason: null,
                metadata: {
                    ...m,
                    currentRunId: null,
                    lastRunStatus: 'interrupted',
                    lastRunError: interruptReason,
                    lastRunCompletedAt: new Date().toISOString(),
                    executionPhase: 'interrupted',
                    lastErrorClass: 'environment_issue',
                    // Hint for the next attempt's context assembly (P4.3: wording by recoveryMode)
                    pendingHint: recoveryMode === 'resumable'
                        ? '上一次执行因进程中断而未完成。任务支持继续模式——请检查已完成的部分，从中断处继续，避免重复已完成的步骤。'
                        : '上一次执行因进程中断而未完成。请从头开始执行任务，不要假设上一次的操作已经生效。',
                },
            });
            recovered++;
            details.push(`${task.id.slice(0, 8)} "${task.title.slice(0, 40)}" (${ageMin}min stale → reset to ${resetStatus})`);
            logger.info(`[stale-recovery] Recovered stale task ${task.id}: "${task.title.slice(0, 40)}" after ${ageMin}min`);
        }
        catch (updateErr) {
            logger.warn({ err: updateErr }, `[stale-recovery] Failed to recover task ${task.id}`);
        }
    }
    if (recovered > 0) {
        logger.info(`[stale-recovery] Recovered ${recovered} stale task(s)`);
    }
    return { recovered, details };
}
/**
 * Check a single task for staleness.
 * Returns true if the task was stale and has been reset.
 */
export async function recoverStaleTaskIfNeeded(taskId) {
    try {
        const task = await memoryStore.getTeamTask(taskId);
        if (!task || task.status !== 'in_progress')
            return false;
        const m = task.metadata ?? {};
        const currentRunId = typeof m['currentRunId'] === 'string' ? m['currentRunId'] : null;
        if (!currentRunId)
            return false;
        const lastRunAt = typeof m['lastRunAt'] === 'string'
            ? new Date(m['lastRunAt']).getTime()
            : null;
        if (!lastRunAt)
            return false;
        if (Date.now() - lastRunAt < STALE_THRESHOLD_MS)
            return false;
        const result = await detectAndRecoverStaleTasks();
        return result.recovered > 0;
    }
    catch {
        return false;
    }
}
//# sourceMappingURL=stale_recovery.js.map