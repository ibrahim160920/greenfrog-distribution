import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class SlackChannel extends BaseChannel {
    readonly name: "slack";
    private app;
    private _running;
    start(): Promise<void>;
    stop(): Promise<void>;
    send(message: OutgoingMessage): Promise<void>;
    isRunning(): boolean;
}
//# sourceMappingURL=index.d.ts.map