import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class NewsSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
    /** Choose RSS feeds based on topic / source preference */
    private selectSources;
    /** Fallback: Hacker News Firebase API */
    private fetchHN;
    /** Optional: NewsAPI.org (if key configured) */
    private fetchNewsApi;
}
//# sourceMappingURL=news.d.ts.map