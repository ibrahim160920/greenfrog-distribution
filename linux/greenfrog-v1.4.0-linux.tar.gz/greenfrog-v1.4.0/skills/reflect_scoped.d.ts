import { BaseSkill } from './base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
export declare class ReflectSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, ctx: ConversationContext): Promise<SkillCallResult>;
    private runReflect;
    private showStatus;
    private maturityLevel;
    private showRules;
    private deleteRule;
    private resetRules;
}
//# sourceMappingURL=reflect_scoped.d.ts.map