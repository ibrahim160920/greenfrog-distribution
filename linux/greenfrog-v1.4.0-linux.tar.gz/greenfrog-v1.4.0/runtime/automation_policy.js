import { createHash } from 'crypto';
function normalizeWeekdays(weekdays) {
    return [...new Set((weekdays ?? []).filter((day) => Number.isInteger(day) && day >= 0 && day <= 6))].sort((a, b) => a - b);
}
function isHourInsideWindow(hour, start, end) {
    if (start == null || end == null)
        return true;
    if (start === end)
        return true;
    if (start < end)
        return hour >= start && hour < end;
    return hour >= start || hour < end;
}
export function evaluateApprovalWindow(policy, now = new Date()) {
    const currentHourUtc = now.getUTCHours();
    const currentWeekdayUtc = now.getUTCDay();
    const approvedWeekdaysUtc = normalizeWeekdays(policy?.approvedWeekdaysUtc);
    const weekdayAllowed = approvedWeekdaysUtc.length === 0 || approvedWeekdaysUtc.includes(currentWeekdayUtc);
    const hourAllowed = isHourInsideWindow(currentHourUtc, policy?.startHourUtc, policy?.endHourUtc);
    let reason = null;
    if (!weekdayAllowed) {
        reason = `current UTC weekday ${currentWeekdayUtc} is outside approved weekdays [${approvedWeekdaysUtc.join(', ')}]`;
    }
    else if (!hourAllowed) {
        reason = `current UTC hour ${currentHourUtc} is outside approval window ${policy?.startHourUtc ?? 0}-${policy?.endHourUtc ?? 24}`;
    }
    return {
        allowed: weekdayAllowed && hourAllowed,
        currentHourUtc,
        currentWeekdayUtc,
        hourAllowed,
        weekdayAllowed,
        reason,
    };
}
export async function evaluateHealthChecks(policy, runCommand) {
    const commands = (policy?.commands ?? []).map((command) => command.trim()).filter(Boolean);
    const required = Math.max(0, Math.min(commands.length, policy?.minPassing ?? commands.length));
    const results = [];
    let passed = 0;
    for (const command of commands) {
        try {
            await runCommand(command);
            results.push({ command, success: true, error: null });
            passed += 1;
        }
        catch (err) {
            results.push({
                command,
                success: false,
                error: err instanceof Error ? err.message : String(err),
            });
        }
    }
    const allowed = passed >= required;
    return {
        allowed,
        total: commands.length,
        passed,
        required,
        results,
        reason: allowed ? null : `health checks passed ${passed}/${commands.length}, below required ${required}`,
    };
}
export function evaluateRollout(policy, fallbackSeed) {
    const percentage = Math.max(0, Math.min(100, Math.floor(policy?.percentage ?? 100)));
    const seed = (policy?.seed?.trim() || fallbackSeed).trim();
    const digest = createHash('sha1').update(seed).digest();
    const bucket = digest.readUInt32BE(0) % 100;
    const allowed = percentage >= 100 || bucket < percentage;
    return {
        allowed,
        percentage,
        bucket,
        seed,
        reason: allowed ? null : `instance rollout bucket ${bucket} is outside rollout percentage ${percentage}`,
    };
}
//# sourceMappingURL=automation_policy.js.map