import { BaseSkill } from './base.js';
export class TranslateSkill extends BaseSkill {
    definition = {
        name: 'translate',
        description: 'Translate text between languages using free translation APIs',
        category: 'utilities',
        parameters: [
            { name: 'text', type: 'string', description: 'Text to translate', required: true },
            { name: 'target_lang', type: 'string', description: 'Target language code (e.g. en, zh, es, fr, de, ja, ko, ar, ru)', required: true },
            { name: 'source_lang', type: 'string', description: 'Source language code (auto-detect if not specified)', default: 'auto' },
        ],
    };
    async execute(params, _ctx) {
        const text = params.text;
        const target = params.target_lang;
        const source = params.source_lang ?? 'auto';
        // Use MyMemory free translation API
        try {
            const langPair = source === 'auto' ? `${target}` : `${source}|${target}`;
            const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${encodeURIComponent(langPair)}`;
            const res = await fetch(url);
            if (!res.ok)
                return this.err(`Translation API error: ${res.status}`);
            const data = await res.json();
            if (data.responseStatus !== 200) {
                return this.err(`Translation failed: status ${data.responseStatus}`);
            }
            const translated = data.responseData.translatedText;
            return this.text(`🌐 **Translation (→ ${target}):**\n\n${translated}`);
        }
        catch (err) {
            return this.err(`Translation error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=translate.js.map