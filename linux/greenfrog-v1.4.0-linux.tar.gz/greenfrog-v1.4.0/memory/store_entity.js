import { nanoid } from 'nanoid';
function normalizeScope(scope) {
    return {
        userId: scope.userId,
        channel: scope.channel,
        workspaceId: scope.workspaceId ?? '',
        agentId: scope.agentId ?? '',
    };
}
function rowToEntity(r) {
    return {
        id: r['id'],
        userId: r['user_id'],
        channel: r['channel'],
        type: r['type'],
        name: r['name'],
        aliases: r['aliases'] ? JSON.parse(r['aliases']) : undefined,
        attributes: JSON.parse(r['attributes']),
        relations: r['relations'] ? JSON.parse(r['relations']) : undefined,
        mentionCount: r['mention_count'],
        lastMentioned: new Date(r['last_mentioned']),
        createdAt: new Date(r['created_at']),
    };
}
export function createEntityStore(db) {
    const api = {
        upsertEntity(userId, channel, entity) {
            return api.upsertScopedEntity({ userId, channel }, entity);
        },
        upsertScopedEntity(scope, entity) {
            const normalized = normalizeScope(scope);
            const now = Date.now();
            const existing = db.prepare(`SELECT id, attributes, relations, mention_count FROM entities
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND name = ?`).get(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, entity.name);
            if (existing) {
                const oldAttrs = JSON.parse(existing.attributes);
                const merged = { ...oldAttrs, ...entity.attributes };
                const oldRels = existing.relations ? JSON.parse(existing.relations) : [];
                const newRels = entity.relations ?? [];
                const relMap = new Map((oldRels ?? []).map((r) => [`${r.type}:${r.target}`, r]));
                for (const r of newRels)
                    relMap.set(`${r.type}:${r.target}`, r);
                const mergedRels = [...relMap.values()];
                db.prepare(`UPDATE entities SET
            type = ?, attributes = ?, relations = ?,
            aliases = ?, mention_count = mention_count + 1, last_mentioned = ?
           WHERE id = ?`).run(entity.type, JSON.stringify(merged), mergedRels.length > 0 ? JSON.stringify(mergedRels) : null, entity.aliases ? JSON.stringify(entity.aliases) : null, now, existing.id);
                return existing.id;
            }
            const id = nanoid();
            db.prepare(`INSERT INTO entities (id, user_id, channel, workspace_id, agent_id, type, name, aliases, attributes, relations, mention_count, last_mentioned, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`).run(id, normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, entity.type, entity.name, entity.aliases ? JSON.stringify(entity.aliases) : null, JSON.stringify(entity.attributes), entity.relations && entity.relations.length > 0 ? JSON.stringify(entity.relations) : null, now, now);
            return id;
        },
        getEntities(userId, channel, type) {
            return api.getScopedEntities({ userId, channel }, type);
        },
        getScopedEntities(scope, type) {
            const normalized = normalizeScope(scope);
            const rows = (type
                ? db.prepare(`SELECT * FROM entities WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND type = ?
             ORDER BY last_mentioned DESC`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, type)
                : db.prepare(`SELECT * FROM entities WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?
             ORDER BY last_mentioned DESC`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId));
            return rows.map(rowToEntity);
        },
        getEntity(userId, channel, name) {
            return api.getScopedEntity({ userId, channel }, name);
        },
        getScopedEntity(scope, name) {
            const normalized = normalizeScope(scope);
            const row = db.prepare(`SELECT * FROM entities WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND name = ?`).get(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, name);
            if (row)
                return rowToEntity(row);
            const all = db.prepare(`SELECT * FROM entities
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ? AND aliases IS NOT NULL`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId);
            for (const r of all) {
                try {
                    const aliases = JSON.parse(r['aliases']);
                    if (aliases.some((a) => a.toLowerCase() === name.toLowerCase())) {
                        return rowToEntity(r);
                    }
                }
                catch { /* skip */ }
            }
            return null;
        },
        searchEntities(userId, channel, query, limit = 10) {
            return api.searchScopedEntities({ userId, channel }, query, limit);
        },
        searchScopedEntities(scope, query, limit = 10) {
            const normalized = normalizeScope(scope);
            const q = `%${query}%`;
            const rows = db.prepare(`SELECT * FROM entities
         WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?
           AND (name LIKE ? OR attributes LIKE ? OR aliases LIKE ?)
         ORDER BY last_mentioned DESC LIMIT ?`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, q, q, q, limit);
            return rows.map(rowToEntity);
        },
        getRecentEntities(userId, channel, limit = 15) {
            return api.getRecentScopedEntities({ userId, channel }, limit);
        },
        getRecentScopedEntities(scope, limit = 15) {
            const normalized = normalizeScope(scope);
            const rows = db.prepare(`SELECT * FROM entities WHERE user_id = ? AND channel = ? AND workspace_id = ? AND agent_id = ?
         ORDER BY last_mentioned DESC LIMIT ?`).all(normalized.userId, normalized.channel, normalized.workspaceId, normalized.agentId, limit);
            return rows.map(rowToEntity);
        },
        getPendingTasks(userId, channel) {
            return api.getPendingScopedTasks({ userId, channel });
        },
        getPendingScopedTasks(scope) {
            const tasks = api.getScopedEntities(scope, 'task');
            return tasks.filter((t) => {
                const status = (t.attributes['status'] ?? '').toLowerCase();
                return status !== 'done' && status !== 'completed' && status !== 'cancelled';
            });
        },
        deleteEntity(userId, channel, name) {
            const result = db.prepare(`DELETE FROM entities WHERE user_id = ? AND channel = ? AND name = ?`).run(userId, channel, name);
            return result.changes > 0;
        },
    };
    return api;
}
//# sourceMappingURL=store_entity.js.map