import { BaseChannel } from '../base.js';
import type { OutgoingMessage } from '../../utils/types.js';
export declare class WhatsAppChannel extends BaseChannel {
    readonly name: "whatsapp";
    private sock;
    private _running;
    private _stopped;
    private authDir;
    private reconnectDelay;
    constructor();
    start(): Promise<void>;
    private connect;
    send(message: OutgoingMessage): Promise<void>;
    stop(): Promise<void>;
    isRunning(): boolean;
}
//# sourceMappingURL=index.d.ts.map