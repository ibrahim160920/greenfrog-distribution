export declare function runSetupWizard(): Promise<void>;
//# sourceMappingURL=setup.d.ts.map