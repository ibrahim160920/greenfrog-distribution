/**
 * manifest_store.ts — Read and query signed release manifests.
 *
 * Manifests are stored as JSON files under release/manifests/*.json.
 * The store reads them from disk on each query (no caching needed for MVP).
 */
import fs from 'node:fs';
import path from 'node:path';
import { validateManifest } from '../inheritance/manifest.js';
import { checkCompatibility } from '../inheritance/client.js';
// ── Path resolution ───────────────────────────────────────────────────────────
function getManifestsDir(manifestsDir) {
    return manifestsDir ?? path.join(process.cwd(), 'release', 'manifests');
}
// ── Public API ────────────────────────────────────────────────────────────────
/** Load all valid manifests from the manifests directory. */
export function loadAllManifests(manifestsDir) {
    const dir = getManifestsDir(manifestsDir);
    if (!fs.existsSync(dir))
        return [];
    const files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
    const manifests = [];
    for (const file of files) {
        try {
            const raw = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf-8'));
            if (validateManifest(raw)) {
                manifests.push(raw);
            }
        }
        catch {
            // Skip invalid files
        }
    }
    return manifests;
}
/** Find the latest manifest compatible with the given currentVersion. */
export function findLatestCompatible(currentVersion, manifestsDir) {
    const all = loadAllManifests(manifestsDir);
    const compatible = all.filter(m => checkCompatibility(m.compatibilityConstraint, currentVersion));
    if (compatible.length === 0)
        return null;
    // Sort by releasedAt descending, return the newest
    compatible.sort((a, b) => new Date(b.releasedAt).getTime() - new Date(a.releasedAt).getTime());
    return compatible[0] ?? null;
}
/** Find a specific manifest by releaseId. */
export function findByReleaseId(releaseId, manifestsDir) {
    const all = loadAllManifests(manifestsDir);
    return all.find(m => m.releaseId === releaseId) ?? null;
}
//# sourceMappingURL=manifest_store.js.map