/**
 * queue.ts — Local backflow queue.
 *
 * Ring buffer (max 1000 entries) persisted at .greenfrog/backflow/queue.json.
 * Entries are appended locally and flushed to the mother-body in batches.
 * On flush failure, entries are retained for retry (up to 5 attempts, 1h window).
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const QUEUE_MAX = 1000;
function getQueuePath(baseDir) {
    const root = baseDir ?? path.join(os.homedir(), '.greenfrog');
    return path.join(root, 'backflow', 'queue.json');
}
function readQueue(baseDir) {
    const queuePath = getQueuePath(baseDir);
    if (!fs.existsSync(queuePath)) {
        return { version: 1, entries: [], nextId: 1 };
    }
    try {
        return JSON.parse(fs.readFileSync(queuePath, 'utf-8'));
    }
    catch {
        return { version: 1, entries: [], nextId: 1 };
    }
}
function writeQueue(queue, baseDir) {
    const queuePath = getQueuePath(baseDir);
    fs.mkdirSync(path.dirname(queuePath), { recursive: true });
    fs.writeFileSync(queuePath, JSON.stringify(queue, null, 2), 'utf-8');
}
/** Append a sanitized entry to the local queue. Trims oldest if over cap. */
export function enqueue(data, baseDir) {
    const queue = readQueue(baseDir);
    const entry = {
        id: String(queue.nextId++),
        data,
        enqueuedAt: new Date().toISOString(),
        attempts: 0,
    };
    queue.entries.push(entry);
    // Ring buffer: drop oldest entries if over cap
    if (queue.entries.length > QUEUE_MAX) {
        queue.entries = queue.entries.slice(queue.entries.length - QUEUE_MAX);
    }
    writeQueue(queue, baseDir);
}
/** Peek at the oldest N entries without removing them. */
export function peekBatch(n, baseDir) {
    const queue = readQueue(baseDir);
    return queue.entries.slice(0, n);
}
/** Mark entries as successfully sent — remove them from the queue. */
export function ackBatch(ids, baseDir) {
    const queue = readQueue(baseDir);
    const idSet = new Set(ids);
    queue.entries = queue.entries.filter(e => !idSet.has(e.id));
    writeQueue(queue, baseDir);
}
/** Increment attempt count on entries (called when a flush attempt fails). */
export function nackBatch(ids, baseDir) {
    const queue = readQueue(baseDir);
    const now = new Date().toISOString();
    for (const entry of queue.entries) {
        if (ids.includes(entry.id)) {
            entry.attempts++;
            entry.lastAttemptAt = now;
        }
    }
    // Drop entries that have exceeded max retries or are too old
    const MAX_ATTEMPTS = 5;
    const MAX_AGE_MS = 60 * 60 * 1000; // 1 hour
    const cutoff = Date.now() - MAX_AGE_MS;
    queue.entries = queue.entries.filter(e => {
        if (e.attempts >= MAX_ATTEMPTS)
            return false;
        if (new Date(e.enqueuedAt).getTime() < cutoff)
            return false;
        return true;
    });
    writeQueue(queue, baseDir);
}
/** Return current queue depth. */
export function queueDepth(baseDir) {
    return readQueue(baseDir).entries.length;
}
/** Clear entire queue (used in tests). */
export function clearQueue(baseDir) {
    writeQueue({ version: 1, entries: [], nextId: 1 }, baseDir);
}
//# sourceMappingURL=queue.js.map