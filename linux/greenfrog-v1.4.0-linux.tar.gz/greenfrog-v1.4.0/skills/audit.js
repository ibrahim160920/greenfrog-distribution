import { BaseSkill } from './base.js';
import { memoryStore } from '../memory/store.js';
/**
 * audit — Admin-only skill for querying the persistent audit log.
 * Records every skill call: who, when, what skill, success/failure, duration.
 */
export class AuditSkill extends BaseSkill {
    definition = {
        name: 'audit',
        description: 'Query the persistent audit log. Shows every skill call made by users: ' +
            'timestamp, user, channel, skill name, success/failure, duration. Admin only.',
        category: 'system',
        parameters: [
            {
                name: 'action',
                type: 'string',
                required: true,
                description: 'What to do',
                enum: ['recent', 'by_user', 'by_skill', 'failures'],
            },
            {
                name: 'userId',
                type: 'string',
                description: 'Filter by userId (for by_user action)',
            },
            {
                name: 'skillName',
                type: 'string',
                description: 'Filter by skill name (for by_skill action)',
            },
            {
                name: 'limit',
                type: 'number',
                description: 'Max records to return (default: 20, max: 100)',
            },
            {
                name: 'hours',
                type: 'number',
                description: 'Look back N hours (default: 24)',
            },
        ],
        examples: [
            'Show the last 20 skill calls (audit recent)',
            'Show all calls by user 123 (audit by_user)',
            'Show all failures in the last 48 hours',
        ],
    };
    async execute(params, _ctx) {
        const action = params.action;
        const limit = Math.min(Number(params.limit ?? 20), 100);
        const hours = Number(params.hours ?? 24);
        const sinceMs = hours * 3_600_000;
        switch (action) {
            case 'recent': {
                const rows = await memoryStore.queryAuditLog({ sinceMs, limit });
                return this.text(this._formatRows(rows, `Recent ${limit} skill calls (last ${hours}h)`));
            }
            case 'by_user': {
                const userId = params.userId;
                if (!userId)
                    return this.err('userId is required for by_user action');
                const rows = await memoryStore.queryAuditLog({ userId, sinceMs, limit });
                return this.text(this._formatRows(rows, `Skill calls by user "${userId}" (last ${hours}h)`));
            }
            case 'by_skill': {
                const skillName = params.skillName;
                if (!skillName)
                    return this.err('skillName is required for by_skill action');
                const rows = await memoryStore.queryAuditLog({ skillName, sinceMs, limit });
                return this.text(this._formatRows(rows, `Calls to skill "${skillName}" (last ${hours}h)`));
            }
            case 'failures': {
                const rows = await memoryStore.queryAuditLog({ success: false, sinceMs, limit });
                return this.text(this._formatRows(rows, `Failed skill calls (last ${hours}h)`));
            }
            default:
                return this.err(`Unknown action: ${action}`);
        }
    }
    _formatRows(rows, title) {
        if (rows.length === 0)
            return `**${title}**\n\nNo records found.`;
        const lines = rows.map((r) => {
            const ts = r.timestamp.toISOString().replace('T', ' ').slice(0, 19);
            const ok = r.success ? '✅' : '❌';
            const dur = `${r.durationMs}ms`;
            const err = r.error ? ` — ${r.error.slice(0, 80)}` : '';
            return `${ok} \`${ts}\` **${r.skillName}** · ${r.userId}@${r.channel} · ${dur}${err}`;
        });
        return `**${title}** (${rows.length} records)\n\n${lines.join('\n')}`;
    }
}
//# sourceMappingURL=audit.js.map