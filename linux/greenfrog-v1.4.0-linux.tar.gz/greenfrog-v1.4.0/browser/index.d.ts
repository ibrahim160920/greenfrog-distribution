import { type Page } from 'playwright';
import { BaseSkill } from '../skills/base.js';
import type { SkillDefinition, SkillCallResult, ConversationContext } from '../utils/types.js';
declare class BrowserManager {
    private browser;
    private context;
    private page;
    launch(): Promise<void>;
    getPage(): Promise<Page>;
    navigate(url: string): Promise<void>;
    screenshot(path?: string): Promise<Buffer>;
    getContent(): Promise<string>;
    getTitle(): Promise<string>;
    getCurrentUrl(): Promise<string>;
    click(selector: string): Promise<void>;
    type(selector: string, text: string): Promise<void>;
    evaluate(script: string): Promise<unknown>;
    /**
     * Execute a script in a fully isolated BrowserContext.
     *
     * Security guarantees (defence-in-depth):
     *  1. Fresh BrowserContext — completely isolated from the main session's
     *     cookies, localStorage, IndexedDB, and service workers.
     *  2. Network封锁 via context.route() — ALL requests are aborted at the
     *     network layer, including fetch/XHR/WebSocket upgrade frames.
     *     This is enforced by the browser process, not bypassable from JS.
     *  3. addInitScript with Object.defineProperty(writable:false, configurable:false)
     *     — prevents script from restoring globals via `window.fetch = realFetch`.
     *     Unlike `var fetch = undefined`, defineProperty with these flags is
     *     permanent and survives prototype-chain introspection attempts.
     *  4. 30-second timeout kills runaway scripts.
     *  5. finally block guarantees page + context are always closed.
     */
    evaluateSandboxed(script: string): Promise<unknown>;
    close(): Promise<void>;
}
export declare const browserManager: BrowserManager;
export declare class BrowserSkill extends BaseSkill {
    readonly definition: SkillDefinition;
    execute(params: Record<string, unknown>, _ctx: ConversationContext): Promise<SkillCallResult>;
}
export {};
//# sourceMappingURL=index.d.ts.map