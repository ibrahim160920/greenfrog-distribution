import { execSync } from 'child_process';
import { BaseSkill } from './base.js';
export class SystemInfoSkill extends BaseSkill {
    definition = {
        name: 'system_info',
        description: 'Get system information: CPU, memory, disk, processes, network interfaces, OS info',
        category: 'system',
        parameters: [
            {
                name: 'type',
                type: 'string',
                description: 'Type of system info',
                required: true,
                enum: ['overview', 'cpu', 'memory', 'disk', 'processes', 'network', 'os'],
            },
        ],
    };
    async execute(params, _ctx) {
        const type = params.type;
        try {
            switch (type) {
                case 'overview':
                case 'os': {
                    const platform = process.platform;
                    const arch = process.arch;
                    const nodeVersion = process.version;
                    const uptime = process.uptime();
                    const uptimeStr = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`;
                    const memUsage = process.memoryUsage();
                    const totalMem = this.tryExec('node -e "console.log(require(\'os\').totalmem())"');
                    const freeMem = this.tryExec('node -e "console.log(require(\'os\').freemem())"');
                    return this.text([
                        `💻 **System Overview**`,
                        `OS: ${platform} (${arch})`,
                        `Node: ${nodeVersion}`,
                        `Uptime: ${uptimeStr}`,
                        `Memory: ${Math.round(memUsage.heapUsed / 1024 / 1024)}MB heap used`,
                        ...(totalMem && freeMem ? [
                            `RAM: ${Math.round(parseInt(freeMem) / 1024 / 1024)}MB free / ${Math.round(parseInt(totalMem) / 1024 / 1024)}MB total`,
                        ] : []),
                    ].join('\n'));
                }
                case 'memory': {
                    const mem = process.memoryUsage();
                    return this.text([
                        `🧠 **Memory Usage**`,
                        `RSS: ${Math.round(mem.rss / 1024 / 1024)} MB`,
                        `Heap Used: ${Math.round(mem.heapUsed / 1024 / 1024)} MB`,
                        `Heap Total: ${Math.round(mem.heapTotal / 1024 / 1024)} MB`,
                        `External: ${Math.round(mem.external / 1024 / 1024)} MB`,
                    ].join('\n'));
                }
                case 'cpu': {
                    const cpuInfo = this.tryExec('node -e "const os=require(\'os\');console.log(JSON.stringify(os.cpus().slice(0,1)))"');
                    const cpus = cpuInfo ? JSON.parse(cpuInfo) : null;
                    return this.text([
                        `⚙️ **CPU Info**`,
                        ...(cpus ? [`Model: ${cpus[0].model}`, `Speed: ${cpus[0].speed} MHz`] : []),
                        `Load: ${process.cpuUsage().user / 1000000}s user, ${process.cpuUsage().system / 1000000}s system`,
                    ].join('\n'));
                }
                case 'disk': {
                    const isWin = process.platform === 'win32';
                    const diskOut = isWin
                        ? this.tryExec('wmic logicaldisk get caption,freespace,size /format:csv')
                        : this.tryExec('df -h /');
                    return this.text(`💾 **Disk Usage**\n\`\`\`\n${diskOut || 'Unable to get disk info'}\n\`\`\``);
                }
                case 'processes': {
                    const isWin = process.platform === 'win32';
                    const out = isWin
                        ? this.tryExec('tasklist /fo csv /nh | head -20')
                        : this.tryExec('ps aux --sort=-%mem | head -20');
                    return this.text(`🔄 **Top Processes**\n\`\`\`\n${out || 'Unable to get process list'}\n\`\`\``);
                }
                case 'network': {
                    const out = this.tryExec('node -e "const os=require(\'os\');const ifaces=os.networkInterfaces();Object.keys(ifaces).forEach(k=>{(ifaces[k]||[]).filter(i=>!i.internal).forEach(i=>console.log(k+\': \'+i.address+\' (\'+i.family+\')\'));})"');
                    return this.text(`🌐 **Network Interfaces**\n${out || 'Unable to get network info'}`);
                }
                default:
                    return this.err(`Unknown type: ${type}`);
            }
        }
        catch (err) {
            return this.err(`System info error: ${String(err)}`);
        }
    }
    tryExec(cmd) {
        try {
            return execSync(cmd, { encoding: 'utf8', timeout: 5000 }).trim();
        }
        catch {
            return '';
        }
    }
}
//# sourceMappingURL=system_info.js.map