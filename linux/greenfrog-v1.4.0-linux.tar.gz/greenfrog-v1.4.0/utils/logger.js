import pino from 'pino';
const isDev = process.env.NODE_ENV !== 'production';
const pretty = process.env.LOG_PRETTY !== 'false';
/** Sensitive field paths redacted from all log output. */
const REDACT_PATHS = [
    // Top-level fields
    'apiKey', 'token', 'secret', 'password', 'appSecret', 'corpSecret',
    'channelSecret', 'channelAccessToken', 'botToken', 'accessToken',
    'encodingAESKey', 'signingSecret', 'appToken', 'clientSecret',
    'authToken', 'refreshToken', 'privateKey', 'appPassword',
    // One level deep (e.g. err.apiKey, config.token)
    '*.apiKey', '*.token', '*.secret', '*.password', '*.appSecret',
    '*.corpSecret', '*.channelSecret', '*.channelAccessToken', '*.botToken',
    '*.accessToken', '*.encodingAESKey', '*.signingSecret', '*.appToken',
    '*.clientSecret', '*.authToken', '*.refreshToken', '*.privateKey', '*.appPassword',
    // Two levels deep (e.g. config.providers.anthropic.apiKey)
    '*.*.apiKey', '*.*.token', '*.*.secret', '*.*.password', '*.*.appSecret',
    '*.*.corpSecret', '*.*.channelSecret', '*.*.channelAccessToken', '*.*.botToken',
    '*.*.accessToken', '*.*.encodingAESKey', '*.*.signingSecret',
    // Common HTTP header paths
    'headers.authorization', 'headers.Authorization',
    '*.headers.authorization', '*.headers.Authorization',
];
export const logger = pino({
    level: process.env.LOG_LEVEL ?? 'info',
    redact: {
        paths: REDACT_PATHS,
        censor: '[REDACTED]',
    },
    transport: isDev && pretty ? {
        target: 'pino-pretty',
        options: {
            colorize: true,
            translateTime: 'SYS:HH:MM:ss',
            ignore: 'pid,hostname',
            messageFormat: '{msg}',
        },
    } : undefined,
});
export function createLogger(name) {
    return logger.child({ module: name });
}
//# sourceMappingURL=logger.js.map