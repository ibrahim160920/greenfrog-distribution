export class GreenFrogError extends Error {
    code;
    details;
    constructor(message, code, details) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = 'GreenFrogError';
    }
}
export class ProviderError extends GreenFrogError {
    constructor(message, details) {
        super(message, 'PROVIDER_ERROR', details);
        this.name = 'ProviderError';
    }
}
export class ChannelError extends GreenFrogError {
    constructor(message, channel, details) {
        super(message, `CHANNEL_ERROR:${channel}`, details);
        this.name = 'ChannelError';
    }
}
export class SkillError extends GreenFrogError {
    constructor(message, skill, details) {
        super(message, `SKILL_ERROR:${skill}`, details);
        this.name = 'SkillError';
    }
}
export class ConfigError extends GreenFrogError {
    constructor(message, details) {
        super(message, 'CONFIG_ERROR', details);
        this.name = 'ConfigError';
    }
}
export class RuntimeLimitError extends GreenFrogError {
    constructor(message, details) {
        super(message, 'RUNTIME_LIMIT', details);
        this.name = 'RuntimeLimitError';
    }
}
export function isGreenFrogError(err) {
    return err instanceof GreenFrogError;
}
export function toErrorMessage(err) {
    if (err instanceof Error)
        return err.message;
    if (typeof err === 'string')
        return err;
    return String(err);
}
//# sourceMappingURL=errors.js.map