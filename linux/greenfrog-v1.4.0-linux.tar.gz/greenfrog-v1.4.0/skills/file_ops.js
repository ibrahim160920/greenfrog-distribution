import { readFileSync, writeFileSync, appendFileSync, unlinkSync, readdirSync, statSync, existsSync, mkdirSync, renameSync, realpathSync } from 'fs';
import { join, resolve, basename, dirname } from 'path';
import { homedir, tmpdir } from 'os';
import { BaseSkill } from './base.js';
/**
 * Allowed roots — operations are restricted to these directories.
 *
 * Using dynamic values (homedir, cwd, tmpdir) rather than hardcoded paths
 * makes this portable across machines and avoids accidentally exposing
 * entire drives or other users' home directories.
 */
function getSafeRoots() {
    return [
        resolve(homedir()),
        resolve(process.cwd()),
        resolve(tmpdir()),
    ];
}
function isSafePath(p) {
    const resolved = resolve(p);
    // Also resolve symlinks to prevent symlink-based traversal attacks
    let realResolved = resolved;
    try {
        realResolved = realpathSync(resolved);
    }
    catch { /* path may not exist yet — use resolved path */ }
    return getSafeRoots().some((root) => {
        const r = root + '/';
        const rb = root + '\\';
        return (resolved.startsWith(r) || resolved.startsWith(rb) || resolved === root ||
            realResolved.startsWith(r) || realResolved.startsWith(rb) || realResolved === root);
    });
}
/** Reject paths that point directly at sensitive system files even within safe roots. */
const SENSITIVE_PATTERNS = [
    /[/\\]\.ssh[/\\]/i,
    /[/\\]\.gnupg[/\\]/i,
    /[/\\]\.aws[/\\]/i,
    /[/\\]\.azure[/\\]/i,
    /[/\\]\.kube[/\\]/i,
    /[/\\]\.config[/\\]gcloud/i,
    /[/\\]\.config[/\\]gh[/\\]/i, // GitHub CLI credentials
    /[/\\]\.docker[/\\]config\.json/i, // Docker registry auth
    /\.greenfrog[/\\]/i, // GreenFrog own config/secrets
    /\.env$/,
    /\.env\./,
    /id_rsa/i,
    /id_ed25519/i,
    /id_ecdsa/i,
    /id_dsa/i,
    /\.pem$/i,
    /\.key$/i,
    /\.pfx$/i,
    /\.p12$/i,
    /\.pkcs12$/i,
    /credentials$/i, // e.g. ~/.aws/credentials
    /authinfo$/i, // e.g. ~/.authinfo (GPG-encrypted passwords)
];
function isSensitiveFile(p) {
    const resolved = resolve(p);
    return SENSITIVE_PATTERNS.some((pattern) => pattern.test(resolved));
}
export class FileOpsSkill extends BaseSkill {
    definition = {
        name: 'file_ops',
        description: 'Read, write, list, and manage files and directories on the local filesystem',
        category: 'system',
        parameters: [
            {
                name: 'action',
                type: 'string',
                description: 'File operation to perform',
                required: true,
                enum: ['read', 'write', 'append', 'list', 'delete', 'mkdir', 'rename', 'exists', 'info'],
            },
            { name: 'path', type: 'string', description: 'File or directory path', required: true },
            { name: 'content', type: 'string', description: 'Content to write (for write/append operations)' },
            { name: 'new_path', type: 'string', description: 'New path (for rename operation)' },
            { name: 'encoding', type: 'string', description: 'File encoding (default: utf8)', default: 'utf8' },
        ],
    };
    async execute(params, _ctx) {
        const path = params.path;
        if (!isSafePath(path)) {
            return this.err(`Access denied: "${path}" is outside allowed directories (home, project, tmp)`);
        }
        if (isSensitiveFile(path)) {
            return this.err(`Access denied: "${path}" matches a protected file pattern (keys, credentials, .env)`);
        }
        try {
            switch (params.action) {
                case 'read': {
                    if (!existsSync(path))
                        return this.err(`File not found: ${path}`);
                    const content = readFileSync(path, (params.encoding ?? 'utf8'));
                    const lines = content.split('\n').length;
                    const preview = content.length > 5000 ? content.slice(0, 5000) + '\n... (truncated)' : content;
                    return this.text(`📄 **${basename(path)}** (${content.length} chars, ${lines} lines)\n\`\`\`\n${preview}\n\`\`\``);
                }
                case 'write': {
                    mkdirSync(dirname(path), { recursive: true });
                    writeFileSync(path, (params.content ?? ''), (params.encoding ?? 'utf8'));
                    return this.text(`✅ Written to ${path}`);
                }
                case 'append': {
                    appendFileSync(path, (params.content ?? ''), (params.encoding ?? 'utf8'));
                    return this.text(`✅ Appended to ${path}`);
                }
                case 'list': {
                    if (!existsSync(path))
                        return this.err(`Directory not found: ${path}`);
                    const entries = readdirSync(path);
                    const details = entries.map((name) => {
                        const fullPath = join(path, name);
                        const stat = statSync(fullPath);
                        const type = stat.isDirectory() ? '📁' : '📄';
                        const size = stat.isDirectory() ? '' : ` (${(stat.size / 1024).toFixed(1)}KB)`;
                        return `${type} ${name}${size}`;
                    });
                    return this.text(`📁 **${path}** (${entries.length} items)\n\n${details.join('\n')}`);
                }
                case 'delete': {
                    if (!existsSync(path))
                        return this.err(`Not found: ${path}`);
                    const stat = statSync(path);
                    if (stat.isDirectory())
                        return this.err(`Cannot delete directories with this skill. Use shell skill instead.`);
                    unlinkSync(path);
                    return this.text(`🗑 Deleted: ${path}`);
                }
                case 'mkdir': {
                    mkdirSync(path, { recursive: true });
                    return this.text(`✅ Directory created: ${path}`);
                }
                case 'rename': {
                    if (!params.new_path)
                        return this.err('new_path is required for rename');
                    if (!isSafePath(params.new_path))
                        return this.err('Access denied for new path');
                    if (isSensitiveFile(params.new_path))
                        return this.err('Access denied: new path matches a protected file pattern');
                    renameSync(path, params.new_path);
                    return this.text(`✅ Renamed ${path} → ${params.new_path}`);
                }
                case 'exists': {
                    const exists = existsSync(path);
                    return this.text(exists ? `✅ ${path} exists` : `❌ ${path} does not exist`);
                }
                case 'info': {
                    if (!existsSync(path))
                        return this.err(`Not found: ${path}`);
                    const stat = statSync(path);
                    return this.text([
                        `📄 **${basename(path)}**`,
                        `Type: ${stat.isDirectory() ? 'directory' : 'file'}`,
                        `Size: ${(stat.size / 1024).toFixed(2)} KB`,
                        `Created: ${stat.birthtime.toISOString()}`,
                        `Modified: ${stat.mtime.toISOString()}`,
                    ].join('\n'));
                }
                default:
                    return this.err(`Unknown action: ${params.action}`);
            }
        }
        catch (err) {
            return this.err(`File operation error: ${String(err)}`);
        }
    }
}
//# sourceMappingURL=file_ops.js.map