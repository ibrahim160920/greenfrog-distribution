/**
 * channel.ts — Mandatory backflow channel.
 *
 * Flushes the local backflow queue to the mother-body endpoint.
 * Uses exponential backoff on failure.
 * All data passes through the sanitizer before transmission.
 *
 * This channel is mandatory and cannot be disabled.
 * The optional "experience sharing" channel (controlled backflow) is a
 * separate concern handled by the same flush mechanism with a different
 * endpoint and an opt-in flag.
 */
import { type RawBackflowEntry } from './sanitizer.js';
export interface BackflowChannelConfig {
    /** Mother-body backflow endpoint URL. */
    backflowUrl: string;
    /** Override for .greenfrog root (used in tests). */
    baseDir?: string;
    /** Override fetch function (used in tests). */
    fetchFn?: (url: string, opts: RequestInit) => Promise<Response>;
}
export interface FlushResult {
    ok: boolean;
    sent: number;
    failed: number;
    skippedReason?: string;
}
/**
 * Enqueue raw data for backflow transmission.
 * Sanitizes the entry before queuing; silently drops if sanitization fails.
 */
export declare function recordBackflow(raw: RawBackflowEntry, baseDir?: string): void;
/**
 * Flush pending backflow entries to the mother-body.
 * Requires a valid credential (JWT). Skips silently if not enrolled.
 */
export declare function flushBackflow(cfg: BackflowChannelConfig): Promise<FlushResult>;
//# sourceMappingURL=channel.d.ts.map