export declare function listSkills(opts: {
    category?: string;
}): Promise<void>;
//# sourceMappingURL=skills.d.ts.map