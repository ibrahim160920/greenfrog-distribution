/**
 * registry.ts — Enrolled child instance store.
 *
 * Stores enrolled instances in memory (Map) with file-backed JSON persistence.
 * Persisted at <baseDir>/distribution/instances.json (default: .greenfrog/).
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
// ── Path helpers ──────────────────────────────────────────────────────────────
function getRegistryPath(baseDir) {
    const root = baseDir ?? path.join(os.homedir(), '.greenfrog');
    return path.join(root, 'distribution', 'instances.json');
}
// ── In-memory store ───────────────────────────────────────────────────────────
let store = null;
let storeBaseDir;
function getStore(baseDir) {
    if (!store || storeBaseDir !== baseDir) {
        store = loadFromDisk(baseDir);
        storeBaseDir = baseDir;
    }
    return store;
}
function loadFromDisk(baseDir) {
    const registryPath = getRegistryPath(baseDir);
    if (!fs.existsSync(registryPath))
        return new Map();
    try {
        const raw = JSON.parse(fs.readFileSync(registryPath, 'utf-8'));
        return new Map(raw.map(i => [i.enrollmentKey, i]));
    }
    catch {
        return new Map();
    }
}
function saveToDisk(map, baseDir) {
    const registryPath = getRegistryPath(baseDir);
    fs.mkdirSync(path.dirname(registryPath), { recursive: true });
    fs.writeFileSync(registryPath, JSON.stringify([...map.values()], null, 2), 'utf-8');
}
// ── Public API ────────────────────────────────────────────────────────────────
/** Register a new instance or return the existing record if already enrolled. */
export function registerInstance(data, baseDir) {
    const map = getStore(baseDir);
    const existing = map.get(data.enrollmentKey);
    if (existing && !existing.revoked) {
        // Idempotent: return existing
        existing.lastSeenAt = new Date().toISOString();
        saveToDisk(map, baseDir);
        return existing;
    }
    const record = {
        ...data,
        enrolledAt: new Date().toISOString(),
        lastSeenAt: new Date().toISOString(),
        revoked: false,
    };
    map.set(data.enrollmentKey, record);
    saveToDisk(map, baseDir);
    return record;
}
/** Look up an enrolled instance by enrollmentKey. Returns null if not found or revoked. */
export function lookupInstance(enrollmentKey, baseDir) {
    const map = getStore(baseDir);
    const instance = map.get(enrollmentKey);
    if (!instance || instance.revoked)
        return null;
    return instance;
}
/** Look up an enrolled instance by instanceId. Returns null if not found or revoked. */
export function lookupByInstanceId(instanceId, baseDir) {
    const map = getStore(baseDir);
    for (const instance of map.values()) {
        if (instance.instanceId === instanceId && !instance.revoked)
            return instance;
    }
    return null;
}
/** Mark an enrollment key as revoked. */
export function revokeInstance(enrollmentKey, baseDir) {
    const map = getStore(baseDir);
    const instance = map.get(enrollmentKey);
    if (!instance)
        return false;
    instance.revoked = true;
    instance.lastSeenAt = new Date().toISOString();
    saveToDisk(map, baseDir);
    return true;
}
/** Revoke an instance by instanceId (used when authenticating via JWT). */
export function revokeByInstanceId(instanceId, baseDir) {
    const map = getStore(baseDir);
    for (const instance of map.values()) {
        if (instance.instanceId === instanceId) {
            instance.revoked = true;
            instance.lastSeenAt = new Date().toISOString();
            saveToDisk(map, baseDir);
            return true;
        }
    }
    return false;
}
/** Update lastSeenAt for a key (called on each authenticated request). */
export function touchInstance(enrollmentKey, baseDir) {
    const map = getStore(baseDir);
    const instance = map.get(enrollmentKey);
    if (instance && !instance.revoked) {
        instance.lastSeenAt = new Date().toISOString();
        saveToDisk(map, baseDir);
    }
}
/** Update lastSeenAt by instanceId. */
export function touchByInstanceId(instanceId, baseDir) {
    const map = getStore(baseDir);
    for (const instance of map.values()) {
        if (instance.instanceId === instanceId && !instance.revoked) {
            instance.lastSeenAt = new Date().toISOString();
            saveToDisk(map, baseDir);
            return;
        }
    }
}
/** Reset in-memory cache (used in tests). */
export function resetRegistry() {
    store = null;
    storeBaseDir = undefined;
}
//# sourceMappingURL=registry.js.map