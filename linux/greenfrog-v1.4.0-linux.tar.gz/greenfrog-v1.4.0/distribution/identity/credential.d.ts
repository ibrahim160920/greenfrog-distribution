/**
 * credential.ts — Local credential storage.
 *
 * Stores the JWT issued by the mother-body after successful enrollment.
 * Persisted at .greenfrog/identity/credential.json.
 */
import type { CredentialRecord } from './types.js';
/** Save a credential record to disk. Overwrites any existing credential. */
export declare function saveCredential(credential: CredentialRecord, baseDir?: string): void;
/** Load credential from disk, or null if not present. */
export declare function loadCredential(baseDir?: string): CredentialRecord | null;
/** Return true if a valid (non-expired) credential exists. */
export declare function hasValidCredential(baseDir?: string): boolean;
/** Delete the stored credential (used on re-enrollment). */
export declare function clearCredential(baseDir?: string): void;
//# sourceMappingURL=credential.d.ts.map