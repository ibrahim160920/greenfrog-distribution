/**
 * OAuth2 / OIDC authentication + JWT session tokens.
 *
 * Flow:
 *   1. GET  /auth/login           → redirect to OIDC provider (PKCE + nonce)
 *   2. GET  /auth/callback        → exchange code, issue GreenFrog JWT, redirect to UI
 *   3. GET  /auth/logout          → clear cookie, redirect to /
 *   4. GET  /auth/userinfo        → return claims from current JWT (JSON)
 *   5. All protected API routes   → verify JWT Bearer token or session cookie
 *
 * Backwards compat:
 *   When auth.enabled = false (default) the existing HMAC/Bearer flow is unchanged.
 *
 * JWT payload:
 *   { sub, email, name, picture, role: 'admin'|'user'|'readonly', iat, exp }
 */
import type { Request, Response, NextFunction } from 'express';
export interface AuthUser {
    sub: string;
    email?: string;
    name?: string;
    picture?: string;
    groups?: string[];
    role: 'admin' | 'user' | 'readonly';
}
/** Attached to req by verifyJwt middleware */
declare global {
    namespace Express {
        interface Request {
            authUser?: AuthUser;
        }
    }
}
export declare function initAuth(): Promise<void>;
export declare function resolveAuthRole(sub: string, email?: string, externalGroups?: string[]): Promise<'admin' | 'user' | 'readonly' | 'deny'>;
/** GET /auth/login — initiate OIDC authorization code + PKCE flow */
export declare function handleLogin(req: Request, res: Response): Promise<void>;
/** GET /auth/callback — OIDC code exchange → issue JWT → redirect to UI */
export declare function handleCallback(req: Request, res: Response): Promise<void>;
/** GET /auth/logout */
export declare function handleLogout(_req: Request, res: Response): void;
export declare function handleLogoutAll(req: Request, res: Response): Promise<void>;
/** GET /auth/userinfo */
export declare function handleUserinfo(req: Request, res: Response): Promise<void>;
/**
 * Express middleware — verifies JWT from Authorization header or cookie.
 * Falls back to the existing gateway.secret Bearer check when OIDC is disabled.
 *
 * On success: attaches req.authUser and calls next().
 * On failure: 401 JSON response.
 */
export declare function requireAuthMiddleware(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=index.d.ts.map