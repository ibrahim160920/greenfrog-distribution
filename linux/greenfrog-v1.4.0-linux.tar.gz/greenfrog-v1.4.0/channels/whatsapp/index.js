import makeWASocket, { useMultiFileAuthState, DisconnectReason, Browsers, jidNormalizedUser, } from '@whiskeysockets/baileys';
import { join } from 'path';
import { mkdirSync } from 'fs';
import QRCode from 'qrcode';
import pino from 'pino';
import { nanoid } from 'nanoid';
import { BaseChannel } from '../base.js';
import { config } from '../../config/index.js';
// WhatsApp message content extractor
function extractText(msg) {
    const m = msg.message;
    if (!m)
        return null;
    return (m.conversation ??
        m.extendedTextMessage?.text ??
        m.imageMessage?.caption ??
        m.videoMessage?.caption ??
        null);
}
// Normalise a phone number / JID to bare number string (e.g. "8613800138000")
function jidToUserId(jid) {
    return jidNormalizedUser(jid).split('@')[0];
}
export class WhatsAppChannel extends BaseChannel {
    name = 'whatsapp';
    sock = null;
    _running = false;
    _stopped = false; // true after stop() is called — prevents reconnects
    authDir;
    reconnectDelay = 3_000; // ms, doubles on each failure up to 60s
    constructor() {
        super();
        this.authDir = join(config.dataDir, 'whatsapp-auth');
    }
    async start() {
        const cfg = config.channels.whatsapp;
        if (!cfg?.enabled) {
            this.log.info('WhatsApp not configured, skipping');
            return;
        }
        mkdirSync(this.authDir, { recursive: true });
        await this.connect();
    }
    async connect() {
        if (this._stopped)
            return;
        const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
        // Suppress Baileys internal logs — it uses pino internally
        const baileysLogger = pino({ level: 'silent' });
        this.sock = makeWASocket({
            auth: state,
            browser: Browsers.ubuntu('GreenFrog'),
            printQRInTerminal: false, // we print our own QR
            logger: baileysLogger,
            markOnlineOnConnect: false,
            syncFullHistory: false, // save memory — only load recent msgs
        });
        // ── Persist credentials ─────────────────────────────────────────────────
        this.sock.ev.on('creds.update', saveCreds);
        // ── Connection lifecycle ────────────────────────────────────────────────
        this.sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;
            // New QR code available — print to terminal and log URL
            if (qr) {
                this.log.info('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n' +
                    '  Scan the QR code below with WhatsApp\n' +
                    '  (Linked Devices → Link a Device)\n' +
                    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
                try {
                    // Print as terminal ASCII art
                    const ascii = await QRCode.toString(qr, { type: 'terminal', small: true });
                    process.stdout.write(ascii + '\n');
                }
                catch {
                    this.log.info({ qr }, 'WhatsApp QR (raw string — paste into a QR generator)');
                }
            }
            if (connection === 'open') {
                this._running = true;
                this.reconnectDelay = 3_000; // reset backoff
                this.log.info('WhatsApp connected');
            }
            if (connection === 'close') {
                this._running = false;
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const reason = statusCode;
                this.log.warn({ statusCode }, 'WhatsApp connection closed');
                if (this._stopped)
                    return;
                if (reason === DisconnectReason.loggedOut ||
                    reason === DisconnectReason.forbidden) {
                    // Session invalidated — wipe auth and re-pair
                    this.log.warn('WhatsApp session logged out — clearing auth, will re-pair on reconnect');
                    try {
                        const { rmSync } = await import('fs');
                        rmSync(this.authDir, { recursive: true, force: true });
                        mkdirSync(this.authDir, { recursive: true });
                    }
                    catch { /* ignore */ }
                }
                // Exponential backoff reconnect (max 60s)
                const delay = this.reconnectDelay;
                this.reconnectDelay = Math.min(this.reconnectDelay * 2, 60_000);
                this.log.info(`WhatsApp reconnecting in ${delay / 1000}s…`);
                setTimeout(() => this.connect(), delay);
            }
        });
        // ── Incoming messages ───────────────────────────────────────────────────
        this.sock.ev.on('messages.upsert', async ({ messages, type }) => {
            // 'notify' = new messages pushed from server; 'append' = history sync
            if (type !== 'notify')
                return;
            for (const raw of messages) {
                if (raw.key.fromMe)
                    continue; // ignore our own messages
                if (!raw.message)
                    continue; // ignore status updates / receipts
                const text = extractText(raw);
                if (!text?.trim())
                    continue; // no text content
                const senderJid = raw.key.participant ?? raw.key.remoteJid ?? '';
                const chatJid = raw.key.remoteJid ?? '';
                const isGroup = chatJid.endsWith('@g.us');
                const userId = jidToUserId(senderJid || chatJid);
                // ── AllowedUsers check ──────────────────────────────────────────────
                const allowed = config.channels.whatsapp?.allowedUsers;
                if (allowed && allowed.length > 0) {
                    if (!allowed.includes(userId)) {
                        this.log.debug({ userId }, 'WhatsApp: user not in allowedUsers, ignoring');
                        continue;
                    }
                }
                // ── Group messages: respond only when @mentioned or prefix matched ──
                if (isGroup) {
                    const botJid = this.sock.user?.id ?? '';
                    const botNumber = jidToUserId(botJid);
                    const mentioned = raw.message?.extendedTextMessage?.contextInfo?.mentionedJid ?? [];
                    const isMentioned = mentioned.some((j) => jidToUserId(j) === botNumber);
                    const startsWithAt = text.trim().startsWith('@' + botNumber);
                    const prefix = config.channels.whatsapp?.groupPrefix;
                    const startsWithPrefix = prefix ? text.trim().startsWith(prefix) : false;
                    if (!isMentioned && !startsWithAt && !startsWithPrefix)
                        continue;
                }
                const incoming = {
                    id: raw.key.id ?? nanoid(),
                    channel: 'whatsapp',
                    userId,
                    username: raw.pushName ?? undefined,
                    chatId: chatJid,
                    text: text.trim(),
                    timestamp: new Date((raw.messageTimestamp ?? Date.now() / 1000) * 1000),
                    raw,
                };
                // Send typing indicator
                try {
                    await this.sock.sendPresenceUpdate('composing', chatJid);
                }
                catch { /* non-fatal */ }
                // Handle message (calls AI, gets response, calls send())
                await this.handleMessage(incoming);
                // Clear typing
                try {
                    await this.sock.sendPresenceUpdate('paused', chatJid);
                }
                catch { /* non-fatal */ }
            }
        });
    }
    async send(message) {
        if (!this.sock || !this._running) {
            this.log.warn('WhatsApp send() called but not connected');
            return;
        }
        if (!message.chatId) {
            this.log.warn('WhatsApp send() called without chatId');
            return;
        }
        // Split long messages (WhatsApp has ~65KB limit but ~4096 chars is practical)
        const MAX = 4000;
        const text = message.text;
        const chunks = [];
        for (let i = 0; i < text.length; i += MAX) {
            chunks.push(text.slice(i, i + MAX));
        }
        for (const chunk of chunks) {
            try {
                await this.sock.sendMessage(message.chatId, { text: chunk });
            }
            catch (err) {
                this.log.error({ err, chatId: message.chatId }, 'WhatsApp send error');
                throw err;
            }
        }
    }
    async stop() {
        this._stopped = true;
        this._running = false;
        try {
            await this.sock?.logout();
        }
        catch { /* ignore */ }
        this.sock?.end(undefined);
        this.sock = null;
    }
    isRunning() {
        return this._running;
    }
}
//# sourceMappingURL=index.js.map