import Anthropic from '@anthropic-ai/sdk';
import { BaseProvider } from './base.js';
import { ProviderError } from '../utils/errors.js';
export class AnthropicProvider extends BaseProvider {
    name = 'anthropic';
    defaultModel = 'claude-sonnet-4-6';
    client;
    model;
    constructor(apiKey, model, baseUrl, extraHeaders) {
        super();
        this.client = new Anthropic({
            apiKey,
            ...(baseUrl ? { baseURL: baseUrl } : {}),
            ...(extraHeaders && Object.keys(extraHeaders).length > 0 ? { defaultHeaders: extraHeaders } : {}),
        });
        this.model = model ?? this.defaultModel;
    }
    async chat(request) {
        const model = request.model ?? this.model;
        const tools = request.tools?.map((t) => ({
            name: t.name,
            description: t.description,
            input_schema: t.parameters,
        }));
        const apiMessages = this.buildApiMessages(request);
        try {
            const response = await this.client.messages.create({
                model,
                max_tokens: request.maxTokens ?? 4096,
                system: request.systemPrompt,
                messages: apiMessages,
                tools,
                temperature: request.temperature,
            }, { signal: request.signal });
            let content = '';
            const toolCalls = [];
            for (const block of response.content) {
                if (block.type === 'text') {
                    content += block.text;
                }
                else if (block.type === 'tool_use') {
                    toolCalls.push({
                        id: block.id,
                        name: block.name,
                        arguments: block.input,
                    });
                }
            }
            return {
                content,
                toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                // Preserve the full content array so the agent can thread it back correctly
                rawContent: response.content,
                usage: {
                    inputTokens: response.usage.input_tokens,
                    outputTokens: response.usage.output_tokens,
                },
                model,
            };
        }
        catch (err) {
            if (err instanceof Anthropic.APIError) {
                throw new ProviderError(`Anthropic API error: ${err.message}`, {
                    status: err.status,
                    error: err.error,
                });
            }
            throw err;
        }
    }
    chatStream(request) {
        const model = request.model ?? this.model;
        const tools = request.tools?.map((t) => ({
            name: t.name,
            description: t.description,
            input_schema: t.parameters,
        }));
        const apiMessages = this.buildApiMessages(request);
        const streamObj = this.client.messages.stream({
            model,
            max_tokens: request.maxTokens ?? 4096,
            system: request.systemPrompt,
            messages: apiMessages,
            tools,
            temperature: request.temperature,
        }, { signal: request.signal });
        // Expose text tokens as an AsyncIterable
        async function* textStream() {
            for await (const event of streamObj) {
                if (event.type === 'content_block_delta' &&
                    event.delta.type === 'text_delta') {
                    yield event.delta.text;
                }
            }
        }
        const complete = async () => {
            const response = await streamObj.finalMessage();
            let content = '';
            const toolCalls = [];
            for (const block of response.content) {
                if (block.type === 'text')
                    content += block.text;
                else if (block.type === 'tool_use') {
                    toolCalls.push({ id: block.id, name: block.name, arguments: block.input });
                }
            }
            return {
                content,
                toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
                rawContent: response.content,
                usage: { inputTokens: response.usage.input_tokens, outputTokens: response.usage.output_tokens },
                model,
            };
        };
        return { textStream: textStream(), complete };
    }
    /** Extract the api messages array for reuse between chat() and chatStream() */
    buildApiMessages(request) {
        const apiMessages = [];
        for (const m of request.messages) {
            if (m.role === 'system')
                continue;
            if (m.role === 'assistant') {
                if (m.rawContent) {
                    apiMessages.push({ role: 'assistant', content: m.rawContent });
                }
                else {
                    apiMessages.push({ role: 'assistant', content: m.content });
                }
                continue;
            }
            if (m.toolResults && m.toolResults.length > 0) {
                const blocks = m.toolResults.map((r) => ({
                    type: 'tool_result',
                    tool_use_id: r.id,
                    content: r.content,
                }));
                const content = m.content ? [{ type: 'text', text: m.content }, ...blocks] : blocks;
                apiMessages.push({ role: 'user', content });
            }
            else if (m.imageAttachments && m.imageAttachments.length > 0) {
                // Multimodal message with images
                const contentBlocks = [];
                for (const img of m.imageAttachments) {
                    contentBlocks.push({
                        type: 'image',
                        source: {
                            type: 'base64',
                            media_type: img.mimeType,
                            data: img.base64,
                        },
                    });
                }
                if (m.content) {
                    contentBlocks.push({ type: 'text', text: m.content });
                }
                apiMessages.push({ role: 'user', content: contentBlocks });
            }
            else {
                apiMessages.push({ role: 'user', content: m.content });
            }
        }
        return apiMessages;
    }
    async isAvailable() {
        try {
            await this.client.messages.create({
                model: this.model,
                max_tokens: 10,
                messages: [{ role: 'user', content: 'ping' }],
            });
            return true;
        }
        catch {
            return false;
        }
    }
    async listModels() {
        return [
            'claude-opus-4-6',
            'claude-sonnet-4-6',
            'claude-haiku-4-5-20251001',
        ];
    }
}
//# sourceMappingURL=anthropic.js.map